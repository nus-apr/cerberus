std::string toSMTLIB2(const clang::Stmt* stmt);
