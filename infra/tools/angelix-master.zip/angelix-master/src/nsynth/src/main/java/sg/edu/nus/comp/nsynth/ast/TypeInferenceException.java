package sg.edu.nus.comp.nsynth.ast;

/**
 * Created by Sergey Mechtaev on 7/4/2016.
 */
public class TypeInferenceException extends Exception {
}
