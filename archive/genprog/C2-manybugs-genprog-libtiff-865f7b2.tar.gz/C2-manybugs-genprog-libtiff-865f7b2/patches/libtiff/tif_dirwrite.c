typedef long __off_t;
typedef long __off64_t;
typedef unsigned long size_t;
typedef signed char int8;
typedef unsigned char uint8;
typedef short int16;
typedef unsigned short uint16;
typedef int int32;
typedef unsigned int uint32;
typedef long int64;
typedef unsigned long uint64;
struct __anonstruct_TIFFHeaderCommon_4 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
};
typedef struct __anonstruct_TIFFHeaderCommon_4 TIFFHeaderCommon;
struct __anonstruct_TIFFHeaderClassic_5 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
   uint32 tiff_diroff ;
};
typedef struct __anonstruct_TIFFHeaderClassic_5 TIFFHeaderClassic;
struct __anonstruct_TIFFHeaderBig_6 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
   uint16 tiff_offsetsize ;
   uint16 tiff_unused ;
   uint64 tiff_diroff ;
};
typedef struct __anonstruct_TIFFHeaderBig_6 TIFFHeaderBig;
enum __anonenum_TIFFDataType_7 {
    TIFF_NOTYPE = 0,
    TIFF_BYTE = 1,
    TIFF_ASCII = 2,
    TIFF_SHORT = 3,
    TIFF_LONG = 4,
    TIFF_RATIONAL = 5,
    TIFF_SBYTE = 6,
    TIFF_UNDEFINED = 7,
    TIFF_SSHORT = 8,
    TIFF_SLONG = 9,
    TIFF_SRATIONAL = 10,
    TIFF_FLOAT = 11,
    TIFF_DOUBLE = 12,
    TIFF_IFD = 13,
    TIFF_LONG8 = 16,
    TIFF_SLONG8 = 17,
    TIFF_IFD8 = 18
} ;
typedef enum __anonenum_TIFFDataType_7 TIFFDataType;
struct tiff;
struct tiff;
typedef struct tiff TIFF;
typedef long tmsize_t;
typedef uint64 toff_t;
typedef void *thandle_t;
struct _IO_FILE;
struct _IO_FILE;
struct _IO_FILE;
typedef struct _IO_FILE FILE;
typedef __builtin_va_list __gnuc_va_list;
struct _IO_FILE;
typedef void _IO_lock_t;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
struct _IO_FILE {
   int _flags ;
   char *_IO_read_ptr ;
   char *_IO_read_end ;
   char *_IO_read_base ;
   char *_IO_write_base ;
   char *_IO_write_ptr ;
   char *_IO_write_end ;
   char *_IO_buf_base ;
   char *_IO_buf_end ;
   char *_IO_save_base ;
   char *_IO_backup_base ;
   char *_IO_save_end ;
   struct _IO_marker *_markers ;
   struct _IO_FILE *_chain ;
   int _fileno ;
   int _flags2 ;
   __off_t _old_offset ;
   unsigned short _cur_column ;
   signed char _vtable_offset ;
   char _shortbuf[1] ;
   _IO_lock_t *_lock ;
   __off64_t _offset ;
   void *__pad1 ;
   void *__pad2 ;
   void *__pad3 ;
   void *__pad4 ;
   size_t __pad5 ;
   int _mode ;
   char _unused2[(15UL * sizeof(int ) - 4UL * sizeof(void *)) - sizeof(size_t )] ;
};
typedef __gnuc_va_list va_list;
struct _TIFFField;
struct _TIFFField;
typedef struct _TIFFField TIFFField;
struct _TIFFFieldArray;
struct _TIFFFieldArray;
typedef struct _TIFFFieldArray TIFFFieldArray;
struct __anonstruct_TIFFTagMethods_17 {
   int (*vsetfield)(TIFF * , uint32  , va_list  ) ;
   int (*vgetfield)(TIFF * , uint32  , va_list  ) ;
   void (*printdir)(TIFF * , FILE * , long  ) ;
};
typedef struct __anonstruct_TIFFTagMethods_17 TIFFTagMethods;
struct __anonstruct_TIFFTagValue_19 {
   TIFFField const   *info ;
   int count ;
   void *value ;
};
typedef struct __anonstruct_TIFFTagValue_19 TIFFTagValue;
struct __anonstruct_TIFFDirectory_20 {
   unsigned long td_fieldsset[4] ;
   uint32 td_imagewidth ;
   uint32 td_imagelength ;
   uint32 td_imagedepth ;
   uint32 td_tilewidth ;
   uint32 td_tilelength ;
   uint32 td_tiledepth ;
   uint32 td_subfiletype ;
   uint16 td_bitspersample ;
   uint16 td_sampleformat ;
   uint16 td_compression ;
   uint16 td_photometric ;
   uint16 td_threshholding ;
   uint16 td_fillorder ;
   uint16 td_orientation ;
   uint16 td_samplesperpixel ;
   uint32 td_rowsperstrip ;
   uint16 td_minsamplevalue ;
   uint16 td_maxsamplevalue ;
   double td_sminsamplevalue ;
   double td_smaxsamplevalue ;
   float td_xresolution ;
   float td_yresolution ;
   uint16 td_resolutionunit ;
   uint16 td_planarconfig ;
   float td_xposition ;
   float td_yposition ;
   uint16 td_pagenumber[2] ;
   uint16 *td_colormap[3] ;
   uint16 td_halftonehints[2] ;
   uint16 td_extrasamples ;
   uint16 *td_sampleinfo ;
   uint32 td_stripsperimage ;
   uint32 td_nstrips ;
   uint64 *td_stripoffset ;
   uint64 *td_stripbytecount ;
   int td_stripbytecountsorted ;
   uint16 td_nsubifd ;
   uint64 *td_subifd ;
   uint16 td_ycbcrsubsampling[2] ;
   uint16 td_ycbcrpositioning ;
   uint16 *td_transferfunction[3] ;
   int td_inknameslen ;
   char *td_inknames ;
   int td_customValueCount ;
   TIFFTagValue *td_customValues ;
};
typedef struct __anonstruct_TIFFDirectory_20 TIFFDirectory;
enum __anonenum_TIFFSetGetFieldType_21 {
    TIFF_SETGET_UNDEFINED = 0,
    TIFF_SETGET_ASCII = 1,
    TIFF_SETGET_UINT8 = 2,
    TIFF_SETGET_SINT8 = 3,
    TIFF_SETGET_UINT16 = 4,
    TIFF_SETGET_SINT16 = 5,
    TIFF_SETGET_UINT32 = 6,
    TIFF_SETGET_SINT32 = 7,
    TIFF_SETGET_UINT64 = 8,
    TIFF_SETGET_SINT64 = 9,
    TIFF_SETGET_FLOAT = 10,
    TIFF_SETGET_DOUBLE = 11,
    TIFF_SETGET_IFD8 = 12,
    TIFF_SETGET_INT = 13,
    TIFF_SETGET_UINT16_PAIR = 14,
    TIFF_SETGET_C0_ASCII = 15,
    TIFF_SETGET_C0_UINT8 = 16,
    TIFF_SETGET_C0_SINT8 = 17,
    TIFF_SETGET_C0_UINT16 = 18,
    TIFF_SETGET_C0_SINT16 = 19,
    TIFF_SETGET_C0_UINT32 = 20,
    TIFF_SETGET_C0_SINT32 = 21,
    TIFF_SETGET_C0_UINT64 = 22,
    TIFF_SETGET_C0_SINT64 = 23,
    TIFF_SETGET_C0_FLOAT = 24,
    TIFF_SETGET_C0_DOUBLE = 25,
    TIFF_SETGET_C0_IFD8 = 26,
    TIFF_SETGET_C16_ASCII = 27,
    TIFF_SETGET_C16_UINT8 = 28,
    TIFF_SETGET_C16_SINT8 = 29,
    TIFF_SETGET_C16_UINT16 = 30,
    TIFF_SETGET_C16_SINT16 = 31,
    TIFF_SETGET_C16_UINT32 = 32,
    TIFF_SETGET_C16_SINT32 = 33,
    TIFF_SETGET_C16_UINT64 = 34,
    TIFF_SETGET_C16_SINT64 = 35,
    TIFF_SETGET_C16_FLOAT = 36,
    TIFF_SETGET_C16_DOUBLE = 37,
    TIFF_SETGET_C16_IFD8 = 38,
    TIFF_SETGET_C32_ASCII = 39,
    TIFF_SETGET_C32_UINT8 = 40,
    TIFF_SETGET_C32_SINT8 = 41,
    TIFF_SETGET_C32_UINT16 = 42,
    TIFF_SETGET_C32_SINT16 = 43,
    TIFF_SETGET_C32_UINT32 = 44,
    TIFF_SETGET_C32_SINT32 = 45,
    TIFF_SETGET_C32_UINT64 = 46,
    TIFF_SETGET_C32_SINT64 = 47,
    TIFF_SETGET_C32_FLOAT = 48,
    TIFF_SETGET_C32_DOUBLE = 49,
    TIFF_SETGET_C32_IFD8 = 50,
    TIFF_SETGET_OTHER = 51
} ;
typedef enum __anonenum_TIFFSetGetFieldType_21 TIFFSetGetFieldType;
enum __anonenum_TIFFFieldArrayType_22 {
    tfiatImage = 0,
    tfiatExif = 1,
    tfiatOther = 2
} ;
typedef enum __anonenum_TIFFFieldArrayType_22 TIFFFieldArrayType;
struct _TIFFFieldArray {
   TIFFFieldArrayType type ;
   uint32 allocated_size ;
   uint32 count ;
   TIFFField *fields ;
};
struct _TIFFField {
   uint32 field_tag ;
   short field_readcount ;
   short field_writecount ;
   TIFFDataType field_type ;
   uint32 reserved ;
   TIFFSetGetFieldType set_field_type ;
   TIFFSetGetFieldType get_field_type ;
   unsigned short field_bit ;
   unsigned char field_oktochange ;
   unsigned char field_passcount ;
   char *field_name ;
   TIFFFieldArray *field_subfields ;
};
struct __anonstruct_TIFFDirEntry_23 {
   uint16 tdir_tag ;
   uint16 tdir_type ;
   uint64 tdir_count ;
   uint64 tdir_offset ;
};
typedef struct __anonstruct_TIFFDirEntry_23 TIFFDirEntry;
struct client_info {
   struct client_info *next ;
   void *data ;
   char *name ;
};
typedef struct client_info TIFFClientInfoLink;
union __anonunion_tif_header_24 {
   TIFFHeaderCommon common ;
   TIFFHeaderClassic classic ;
   TIFFHeaderBig big ;
};
struct tiff {
   char *tif_name ;
   int tif_fd ;
   int tif_mode ;
   uint32 tif_flags ;
   uint64 tif_diroff ;
   uint64 tif_nextdiroff ;
   uint64 *tif_dirlist ;
   uint16 tif_dirlistsize ;
   uint16 tif_dirnumber ;
   TIFFDirectory tif_dir ;
   TIFFDirectory tif_customdir ;
   union __anonunion_tif_header_24 tif_header ;
   uint16 tif_header_size ;
   uint32 tif_row ;
   uint16 tif_curdir ;
   uint32 tif_curstrip ;
   uint64 tif_curoff ;
   uint64 tif_dataoff ;
   uint16 tif_nsubifd ;
   uint64 tif_subifdoff ;
   uint32 tif_col ;
   uint32 tif_curtile ;
   tmsize_t tif_tilesize ;
   int tif_decodestatus ;
   int (*tif_fixuptags)(TIFF * ) ;
   int (*tif_setupdecode)(TIFF * ) ;
   int (*tif_predecode)(TIFF * , uint16  ) ;
   int (*tif_setupencode)(TIFF * ) ;
   int tif_encodestatus ;
   int (*tif_preencode)(TIFF * , uint16  ) ;
   int (*tif_postencode)(TIFF * ) ;
   int (*tif_decoderow)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_encoderow)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_decodestrip)(TIFF *tif , uint8 *buf , tmsize_t size ,
                          uint16 sample ) ;
   int (*tif_encodestrip)(TIFF *tif , uint8 *buf , tmsize_t size ,
                          uint16 sample ) ;
   int (*tif_decodetile)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_encodetile)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   void (*tif_close)(TIFF * ) ;
   int (*tif_seek)(TIFF * , uint32  ) ;
   void (*tif_cleanup)(TIFF * ) ;
   uint32 (*tif_defstripsize)(TIFF * , uint32  ) ;
   void (*tif_deftilesize)(TIFF * , uint32 * , uint32 * ) ;
   uint8 *tif_data ;
   tmsize_t tif_scanlinesize ;
   tmsize_t tif_scanlineskew ;
   uint8 *tif_rawdata ;
   tmsize_t tif_rawdatasize ;
   uint8 *tif_rawcp ;
   tmsize_t tif_rawcc ;
   uint8 *tif_base ;
   tmsize_t tif_size ;
   int (*tif_mapproc)(thandle_t  , void **base , toff_t *size ) ;
   void (*tif_unmapproc)(thandle_t  , void *base , toff_t size ) ;
   thandle_t tif_clientdata ;
   tmsize_t (*tif_readproc)(thandle_t  , void * , tmsize_t  ) ;
   tmsize_t (*tif_writeproc)(thandle_t  , void * , tmsize_t  ) ;
   uint64 (*tif_seekproc)(thandle_t  , uint64  , int  ) ;
   int (*tif_closeproc)(thandle_t  ) ;
   uint64 (*tif_sizeproc)(thandle_t  ) ;
   void (*tif_postdecode)(TIFF *tif , uint8 *buf , tmsize_t size ) ;
   TIFFField **tif_fields ;
   uint32 tif_nfields ;
   TIFFField const   *tif_foundfield ;
   TIFFTagMethods tif_tagmethods ;
   TIFFClientInfoLink *tif_clientinfo ;
   TIFFFieldArray *tif_fieldscompat ;
   uint32 tif_nfieldscompat ;
};
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__nonnull__(1),
__leaf__)) strlen)(char const   *__s )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void ( __attribute__((__leaf__)) __assert_fail)(char const   *__assertion ,
                                                               char const   *__file ,
                                                               unsigned int __line ,
                                                               char const   *__function ) ;
extern void *_TIFFmalloc(tmsize_t s ) ;
extern void _TIFFmemcpy(void *d , void const   *s , tmsize_t c ) ;
extern int _TIFFmemcmp(void const   *p1 , void const   *p2 , tmsize_t c ) ;
extern void _TIFFfree(void *p ) ;
extern int TIFFGetField(TIFF *tif , uint32 tag  , ...) ;
extern int TIFFGetFieldDefaulted(TIFF *tif , uint32 tag  , ...) ;
extern int TIFFSetupStrips(TIFF * ) ;
extern void TIFFFreeDirectory(TIFF * ) ;
extern int TIFFCreateDirectory(TIFF * ) ;
int TIFFWriteDirectory(TIFF *tif ) ;
int TIFFCheckpointDirectory(TIFF *tif ) ;
int TIFFRewriteDirectory(TIFF *tif ) ;
extern void TIFFErrorExt(thandle_t  , char const   * , char const   *  , ...) ;
extern void TIFFSetWriteOffset(TIFF *tif , uint64 off ) ;
extern void TIFFSwabShort(uint16 * ) ;
extern void TIFFSwabLong(uint32 * ) ;
extern void TIFFSwabLong8(uint64 * ) ;
extern void TIFFSwabArrayOfShort(uint16 *wp , tmsize_t n ) ;
extern void TIFFSwabArrayOfLong(uint32 *lp , tmsize_t n ) ;
extern void TIFFSwabArrayOfLong8(uint64 *lp , tmsize_t n ) ;
extern void TIFFSwabArrayOfFloat(float *fp , tmsize_t n ) ;
extern void TIFFSwabArrayOfDouble(double *dp , tmsize_t n ) ;
extern int TIFFFlushData1(TIFF *tif ) ;
static int TIFFWriteDirectorySec(TIFF *tif , int isimage , int imagedone ,
                                 uint64 *pdiroff ) ;
static int TIFFWriteDirectoryTagSampleformatPerSample(TIFF *tif , uint32 *ndir ,
                                                      TIFFDirEntry *dir ,
                                                      uint16 tag , double value ) ;
static int TIFFWriteDirectoryTagAscii(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      uint32 count , char *value ) ;
static int TIFFWriteDirectoryTagUndefinedArray(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint32 count , uint8 *value ) ;
static int TIFFWriteDirectoryTagByteArray(TIFF *tif , uint32 *ndir ,
                                          TIFFDirEntry *dir , uint16 tag ,
                                          uint32 count , uint8 *value ) ;
static int TIFFWriteDirectoryTagBytePerSample(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              uint8 value ) ;
static int TIFFWriteDirectoryTagSbyteArray(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , int8 *value ) ;
static int TIFFWriteDirectoryTagSbytePerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               int8 value ) ;
static int TIFFWriteDirectoryTagShort(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      uint16 value ) ;
static int TIFFWriteDirectoryTagShortArray(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , uint16 *value ) ;
static int TIFFWriteDirectoryTagShortPerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint16 value ) ;
static int TIFFWriteDirectoryTagSshortArray(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint32 count , int16 *value ) ;
static int TIFFWriteDirectoryTagSshortPerSample(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                int16 value ) ;
static int TIFFWriteDirectoryTagLong(TIFF *tif , uint32 *ndir ,
                                     TIFFDirEntry *dir , uint16 tag ,
                                     uint32 value ) ;
static int TIFFWriteDirectoryTagLongArray(TIFF *tif , uint32 *ndir ,
                                          TIFFDirEntry *dir , uint16 tag ,
                                          uint32 count , uint32 *value ) ;
static int TIFFWriteDirectoryTagLongPerSample(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              uint32 value ) ;
static int TIFFWriteDirectoryTagSlongArray(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , int32 *value ) ;
static int TIFFWriteDirectoryTagSlongPerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               int32 value ) ;
static int TIFFWriteDirectoryTagLong8Array(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , uint64 *value ) ;
static int TIFFWriteDirectoryTagSlong8Array(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint32 count , int64 *value ) ;
static int TIFFWriteDirectoryTagRational(TIFF *tif , uint32 *ndir ,
                                         TIFFDirEntry *dir , uint16 tag ,
                                         double value ) ;
static int TIFFWriteDirectoryTagRationalArray(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              uint32 count , float *value ) ;
static int TIFFWriteDirectoryTagSrationalArray(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint32 count , float *value ) ;
static int TIFFWriteDirectoryTagFloatArray(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , float *value ) ;
static int TIFFWriteDirectoryTagFloatPerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               float value ) ;
static int TIFFWriteDirectoryTagDoubleArray(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint32 count , double *value ) ;
static int TIFFWriteDirectoryTagDoublePerSample(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                double value ) ;
static int TIFFWriteDirectoryTagIfdArray(TIFF *tif , uint32 *ndir ,
                                         TIFFDirEntry *dir , uint16 tag ,
                                         uint32 count , uint32 *value ) ;
static int TIFFWriteDirectoryTagIfd8Array(TIFF *tif , uint32 *ndir ,
                                          TIFFDirEntry *dir , uint16 tag ,
                                          uint32 count , uint64 *value ) ;
static int TIFFWriteDirectoryTagShortLong(TIFF *tif , uint32 *ndir ,
                                          TIFFDirEntry *dir , uint16 tag ,
                                          uint32 value ) ;
static int TIFFWriteDirectoryTagLongLong8Array(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint32 count , uint64 *value ) ;
static int TIFFWriteDirectoryTagColormap(TIFF *tif , uint32 *ndir ,
                                         TIFFDirEntry *dir ) ;
static int TIFFWriteDirectoryTagTransferfunction(TIFF *tif , uint32 *ndir ,
                                                 TIFFDirEntry *dir ) ;
static int TIFFWriteDirectoryTagSubifd(TIFF *tif , uint32 *ndir ,
                                       TIFFDirEntry *dir ) ;
static int TIFFWriteDirectoryTagCheckedAscii(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             uint32 count , char *value ) ;
static int TIFFWriteDirectoryTagCheckedUndefinedArray(TIFF *tif , uint32 *ndir ,
                                                      TIFFDirEntry *dir ,
                                                      uint16 tag ,
                                                      uint32 count ,
                                                      uint8 *value ) ;
static int TIFFWriteDirectoryTagCheckedByteArray(TIFF *tif , uint32 *ndir ,
                                                 TIFFDirEntry *dir ,
                                                 uint16 tag , uint32 count ,
                                                 uint8 *value ) ;
static int TIFFWriteDirectoryTagCheckedSbyteArray(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  int8 *value ) ;
static int TIFFWriteDirectoryTagCheckedShort(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             uint16 value ) ;
static int TIFFWriteDirectoryTagCheckedShortArray(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  uint16 *value ) ;
static int TIFFWriteDirectoryTagCheckedSshortArray(TIFF *tif , uint32 *ndir ,
                                                   TIFFDirEntry *dir ,
                                                   uint16 tag , uint32 count ,
                                                   int16 *value ) ;
static int TIFFWriteDirectoryTagCheckedLong(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint32 value ) ;
static int TIFFWriteDirectoryTagCheckedLongArray(TIFF *tif , uint32 *ndir ,
                                                 TIFFDirEntry *dir ,
                                                 uint16 tag , uint32 count ,
                                                 uint32 *value ) ;
static int TIFFWriteDirectoryTagCheckedSlongArray(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  int32 *value ) ;
static int TIFFWriteDirectoryTagCheckedLong8Array(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  uint64 *value ) ;
static int TIFFWriteDirectoryTagCheckedSlong8Array(TIFF *tif , uint32 *ndir ,
                                                   TIFFDirEntry *dir ,
                                                   uint16 tag , uint32 count ,
                                                   int64 *value ) ;
static int TIFFWriteDirectoryTagCheckedRational(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                double value ) ;
static int TIFFWriteDirectoryTagCheckedRationalArray(TIFF *tif , uint32 *ndir ,
                                                     TIFFDirEntry *dir ,
                                                     uint16 tag , uint32 count ,
                                                     float *value ) ;
static int TIFFWriteDirectoryTagCheckedSrationalArray(TIFF *tif , uint32 *ndir ,
                                                      TIFFDirEntry *dir ,
                                                      uint16 tag ,
                                                      uint32 count ,
                                                      float *value ) ;
static int TIFFWriteDirectoryTagCheckedFloatArray(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  float *value ) ;
static int TIFFWriteDirectoryTagCheckedDoubleArray(TIFF *tif , uint32 *ndir ,
                                                   TIFFDirEntry *dir ,
                                                   uint16 tag , uint32 count ,
                                                   double *value ) ;
static int TIFFWriteDirectoryTagCheckedIfdArray(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                uint32 count , uint32 *value ) ;
static int TIFFWriteDirectoryTagCheckedIfd8Array(TIFF *tif , uint32 *ndir ,
                                                 TIFFDirEntry *dir ,
                                                 uint16 tag , uint32 count ,
                                                 uint64 *value ) ;
static int TIFFWriteDirectoryTagData(TIFF *tif , uint32 *ndir ,
                                     TIFFDirEntry *dir , uint16 tag ,
                                     uint16 datatype , uint32 count ,
                                     uint32 datalength , void *data ) ;
static int TIFFLinkDirectory(TIFF *tif ) ;
int TIFFWriteDirectory(TIFF *tif ) 
{ 
  int tmp ;

  {
  tmp = TIFFWriteDirectorySec(tif, 1, 1, (uint64 *)((void *)0));
  return (tmp);
}
}
int TIFFCheckpointDirectory(TIFF *tif ) 
{ 
  int rc ;
  uint64 tmp ;

  {
  if ((unsigned long )tif->tif_dir.td_stripoffset == (unsigned long )((void *)0)) {
    TIFFSetupStrips(tif);
  } else {

  }
  rc = TIFFWriteDirectorySec(tif, 1, 0, (uint64 *)((void *)0));
  tmp = (*(tif->tif_seekproc))(tif->tif_clientdata, (uint64 )0, 2);
  TIFFSetWriteOffset(tif, tmp);
  return (rc);
}
}
int TIFFWriteCustomDirectory(TIFF *tif , uint64 *pdiroff ) 
{ 
  int tmp ;

  {
  tmp = TIFFWriteDirectorySec(tif, 0, 0, pdiroff);
  return (tmp);
}
}
static char const   module[21]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'R',      (char const   )'e',      (char const   )'w',      (char const   )'r', 
        (char const   )'i',      (char const   )'t',      (char const   )'e',      (char const   )'D', 
        (char const   )'i',      (char const   )'r',      (char const   )'e',      (char const   )'c', 
        (char const   )'t',      (char const   )'o',      (char const   )'r',      (char const   )'y', 
        (char const   )'\000'};
int TIFFRewriteDirectory(TIFF *tif ) 
{ 
  int tmp ;
  tmsize_t tmp___0 ;
  uint32 nextdir ;
  uint16 dircount ;
  uint32 nextnextdir ;
  uint64 tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  uint32 m ;
  tmsize_t tmp___4 ;
  tmsize_t tmp___5 ;
  uint64 nextdir___0 ;
  uint64 dircount64 ;
  uint16 dircount___0 ;
  uint64 nextnextdir___0 ;
  uint64 tmp___6 ;
  tmsize_t tmp___7 ;
  tmsize_t tmp___8 ;
  uint64 m___0 ;
  tmsize_t tmp___9 ;
  int tmp___10 ;

  {
  if (tif->tif_diroff == 0UL) {
    tmp = TIFFWriteDirectory(tif);
    return (tmp);
  } else {

  }
  if (! (tif->tif_flags & 524288U)) {
    if ((uint64 )tif->tif_header.classic.tiff_diroff == tif->tif_diroff) {
      tif->tif_header.classic.tiff_diroff = (uint32 )0;
      tif->tif_diroff = (uint64 )0;
      (*(tif->tif_seekproc))(tif->tif_clientdata, (uint64 )4, 0);
      tmp___0 = (*(tif->tif_writeproc))(tif->tif_clientdata,
                                        (void *)(& tif->tif_header.classic.tiff_diroff),
                                        (tmsize_t )4);
      if (! (tmp___0 == 4L)) {
        TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                     "Error updating TIFF header");
        return (0);
      } else {

      }
    } else {
      nextdir = tif->tif_header.classic.tiff_diroff;
      while (1) {
        tmp___1 = (*(tif->tif_seekproc))(tif->tif_clientdata, (uint64 )nextdir,
                                         0);
        if (tmp___1 == (uint64 )nextdir) {
          tmp___2 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                           (void *)(& dircount), (tmsize_t )2);
          if (! (tmp___2 == 2L)) {
            TIFFErrorExt(tif->tif_clientdata, module,
                         "Error fetching directory count");
            return (0);
          } else {

          }
        } else {
          TIFFErrorExt(tif->tif_clientdata, module,
                       "Error fetching directory count");
          return (0);
        }
        if (tif->tif_flags & 128U) {
          TIFFSwabShort(& dircount);
        } else {

        }
        (*(tif->tif_seekproc))(tif->tif_clientdata,
                               (uint64 )((nextdir + 2U) + (uint32 )((int )dircount * 12)),
                               0);
        tmp___3 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                         (void *)(& nextnextdir), (tmsize_t )4);
        if (! (tmp___3 == 4L)) {
          TIFFErrorExt(tif->tif_clientdata, module,
                       "Error fetching directory link");
          return (0);
        } else {

        }
        if (tif->tif_flags & 128U) {
          TIFFSwabLong(& nextnextdir);
        } else {

        }
        if ((uint64 )nextnextdir == tif->tif_diroff) {
          m = (uint32 )0;
          (*(tif->tif_seekproc))(tif->tif_clientdata,
                                 (uint64 )((nextdir + 2U) + (uint32 )((int )dircount * 12)),
                                 0);
          tmp___4 = (*(tif->tif_writeproc))(tif->tif_clientdata, (void *)(& m),
                                            (tmsize_t )4);
          if (! (tmp___4 == 4L)) {
            TIFFErrorExt(tif->tif_clientdata, module,
                         "Error writing directory link");
            return (0);
          } else {

          }
          tif->tif_diroff = (uint64 )0;
          break;
        } else {

        }
        nextdir = nextnextdir;
      }
    }
  } else
  if (tif->tif_header.big.tiff_diroff == tif->tif_diroff) {
    tif->tif_header.big.tiff_diroff = (uint64 )0;
    tif->tif_diroff = (uint64 )0;
    (*(tif->tif_seekproc))(tif->tif_clientdata, (uint64 )8, 0);
    tmp___5 = (*(tif->tif_writeproc))(tif->tif_clientdata,
                                      (void *)(& tif->tif_header.big.tiff_diroff),
                                      (tmsize_t )8);
    if (! (tmp___5 == 8L)) {
      TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                   "Error updating TIFF header");
      return (0);
    } else {

    }
  } else {
    nextdir___0 = tif->tif_header.big.tiff_diroff;
    while (1) {
      tmp___6 = (*(tif->tif_seekproc))(tif->tif_clientdata, nextdir___0, 0);
      if (tmp___6 == nextdir___0) {
        tmp___7 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                         (void *)(& dircount64), (tmsize_t )8);
        if (! (tmp___7 == 8L)) {
          TIFFErrorExt(tif->tif_clientdata, module,
                       "Error fetching directory count");
          return (0);
        } else {

        }
      } else {
        TIFFErrorExt(tif->tif_clientdata, module,
                     "Error fetching directory count");
        return (0);
      }
      if (tif->tif_flags & 128U) {
        TIFFSwabLong8(& dircount64);
      } else {

      }
      if (dircount64 > 65535UL) {
        TIFFErrorExt(tif->tif_clientdata, module,
                     "Sanity check on tag count failed, likely corrupt TIFF");
        return (0);
      } else {

      }
      dircount___0 = (uint16 )dircount64;
      (*(tif->tif_seekproc))(tif->tif_clientdata,
                             (nextdir___0 + 8UL) + (uint64 )((int )dircount___0 * 20),
                             0);
      tmp___8 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                       (void *)(& nextnextdir___0), (tmsize_t )8);
      if (! (tmp___8 == 8L)) {
        TIFFErrorExt(tif->tif_clientdata, module,
                     "Error fetching directory link");
        return (0);
      } else {

      }
      if (tif->tif_flags & 128U) {
        TIFFSwabLong8(& nextnextdir___0);
      } else {

      }
      if (nextnextdir___0 == tif->tif_diroff) {
        m___0 = (uint64 )0;
        (*(tif->tif_seekproc))(tif->tif_clientdata,
                               (nextdir___0 + 8UL) + (uint64 )((int )dircount___0 * 20),
                               0);
        tmp___9 = (*(tif->tif_writeproc))(tif->tif_clientdata,
                                          (void *)(& m___0), (tmsize_t )8);
        if (! (tmp___9 == 8L)) {
          TIFFErrorExt(tif->tif_clientdata, module,
                       "Error writing directory link");
          return (0);
        } else {

        }
        tif->tif_diroff = (uint64 )0;
        break;
      } else {

      }
      nextdir___0 = nextnextdir___0;
    }
  }
  tmp___10 = TIFFWriteDirectory(tif);
  return (tmp___10);
}
}
static char const   module___0[22]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'S',      (char const   )'e', 
        (char const   )'c',      (char const   )'\000'};
static int TIFFWriteDirectorySec(TIFF *tif , int isimage , int imagedone ,
                                 uint64 *pdiroff ) 
{ 
  uint32 ndir ;
  TIFFDirEntry *dir ;
  uint32 dirsize ;
  void *dirmem ;
  uint32 m ;
  tmsize_t orig_rawcc ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;
  int tmp___8 ;
  int tmp___9 ;
  int tmp___10 ;
  int tmp___11 ;
  int tmp___12 ;
  int tmp___13 ;
  int tmp___14 ;
  int tmp___15 ;
  int tmp___16 ;
  int tmp___17 ;
  int tmp___18 ;
  int tmp___19 ;
  int tmp___20 ;
  int tmp___21 ;
  int tmp___22 ;
  int tmp___23 ;
  int tmp___24 ;
  int tmp___25 ;
  int tmp___26 ;
  int tmp___27 ;
  uint16 na ;
  uint16 *nb ;
  int tmp___28 ;
  int tmp___29 ;
  int tmp___30 ;
  int tmp___31 ;
  int tmp___32 ;
  int tmp___33 ;
  int tmp___34 ;
  int tmp___35 ;
  int tmp___36 ;
  int tmp___37 ;
  int tmp___38 ;
  int tmp___39 ;
  uint32 n ;
  TIFFField const   *o ;
  uint32 pa ;
  char *pb ;
  size_t tmp___40 ;
  int tmp___41 ;
  uint16 p ;
  int tmp___42 ;
  uint32 p___0 ;
  int tmp___43 ;
  uint32 pa___0 ;
  void *pb___0 ;
  int tmp___44 ;
  int tmp___45 ;
  int tmp___46 ;
  int tmp___47 ;
  int tmp___48 ;
  int tmp___49 ;
  int tmp___50 ;
  int tmp___51 ;
  int tmp___52 ;
  int tmp___53 ;
  int tmp___54 ;
  int tmp___55 ;
  int tmp___56 ;
  int tmp___57 ;
  int tmp___58 ;
  int tmp___59 ;
  int tmp___60 ;
  void *tmp___61 ;
  int tmp___62 ;
  uint64 tmp___63 ;
  uint32 na___0 ;
  TIFFDirEntry *nb___0 ;
  uint8 *n___0 ;
  TIFFDirEntry *o___0 ;
  uint8 *n___1 ;
  TIFFDirEntry *o___1 ;
  uint64 tmp___64 ;
  tmsize_t tmp___65 ;

  {
  if (tif->tif_mode == 0) {
    return (1);
  } else {

  }
  if (imagedone) {
    orig_rawcc = tif->tif_rawcc;
    if (tif->tif_flags & 4096U) {
      tif->tif_flags &= 4294963199U;
      tmp = (*(tif->tif_postencode))(tif);
      if (! tmp) {
        TIFFErrorExt(tif->tif_clientdata, module___0,
                     "Error post-encoding before directory write");
        return (0);
      } else {

      }
    } else {

    }
    (*(tif->tif_close))(tif);
    if (tif->tif_rawcc > 0L) {
      __repair_app_127__0: /* CIL Label */ 
      {
      if (tif->tif_rawcc != orig_rawcc) {
        if ((tif->tif_flags & 64U) != 0U) {
          tmp___0 = TIFFFlushData1(tif);
          if (! tmp___0) {
            TIFFErrorExt(tif->tif_clientdata, module___0,
                         "Error flushing data before directory write");
            return (0);
          } else {

          }
        } else {

        }
      } else {

      }
      return (1);
      }
    } else {

    }
    if (tif->tif_flags & 512U) {
      if (tif->tif_rawdata) {
        _TIFFfree((void *)tif->tif_rawdata);
        tif->tif_rawdata = (uint8 *)((void *)0);
        tif->tif_rawcc = (tmsize_t )0;
        tif->tif_rawdatasize = (tmsize_t )0;
      } else {

      }
    } else {

    }
    tif->tif_flags &= 4294967215U;
  } else {

  }
  dir = (TIFFDirEntry *)((void *)0);
  dirmem = (void *)0;
  dirsize = (uint32 )0;
  while (1) {
    ndir = (uint32 )0;
    if (isimage) {
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 1)) {
        tmp___1 = TIFFWriteDirectoryTagShortLong(tif, & ndir, dir, (uint16 )256,
                                                 tif->tif_dir.td_imagewidth);
        if (! tmp___1) {
          goto bad;
        } else {

        }
        tmp___2 = TIFFWriteDirectoryTagShortLong(tif, & ndir, dir, (uint16 )257,
                                                 tif->tif_dir.td_imagelength);
        if (! tmp___2) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 2)) {
        tmp___3 = TIFFWriteDirectoryTagShortLong(tif, & ndir, dir, (uint16 )322,
                                                 tif->tif_dir.td_tilewidth);
        if (! tmp___3) {
          goto bad;
        } else {

        }
        tmp___4 = TIFFWriteDirectoryTagShortLong(tif, & ndir, dir, (uint16 )323,
                                                 tif->tif_dir.td_tilelength);
        if (! tmp___4) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 3)) {
        tmp___5 = TIFFWriteDirectoryTagRational(tif, & ndir, dir, (uint16 )282,
                                                (double )tif->tif_dir.td_xresolution);
        if (! tmp___5) {
          goto bad;
        } else {

        }
        tmp___6 = TIFFWriteDirectoryTagRational(tif, & ndir, dir, (uint16 )283,
                                                (double )tif->tif_dir.td_yresolution);
        if (! tmp___6) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 4)) {
        tmp___7 = TIFFWriteDirectoryTagRational(tif, & ndir, dir, (uint16 )286,
                                                (double )tif->tif_dir.td_xposition);
        if (! tmp___7) {
          goto bad;
        } else {

        }
        tmp___8 = TIFFWriteDirectoryTagRational(tif, & ndir, dir, (uint16 )287,
                                                (double )tif->tif_dir.td_yposition);
        if (! tmp___8) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 5)) {
        tmp___9 = TIFFWriteDirectoryTagLong(tif, & ndir, dir, (uint16 )254,
                                            tif->tif_dir.td_subfiletype);
        if (! tmp___9) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 6)) {
        tmp___10 = TIFFWriteDirectoryTagShortPerSample(tif, & ndir, dir,
                                                       (uint16 )258,
                                                       tif->tif_dir.td_bitspersample);
        if (! tmp___10) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 7)) {
        tmp___11 = TIFFWriteDirectoryTagShort(tif, & ndir, dir, (uint16 )259,
                                              tif->tif_dir.td_compression);
        if (! tmp___11) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 8)) {
        tmp___12 = TIFFWriteDirectoryTagShort(tif, & ndir, dir, (uint16 )262,
                                              tif->tif_dir.td_photometric);
        if (! tmp___12) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 9)) {
        tmp___13 = TIFFWriteDirectoryTagShort(tif, & ndir, dir, (uint16 )263,
                                              tif->tif_dir.td_threshholding);
        if (! tmp___13) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 10)) {
        tmp___14 = TIFFWriteDirectoryTagShort(tif, & ndir, dir, (uint16 )266,
                                              tif->tif_dir.td_fillorder);
        if (! tmp___14) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 15)) {
        tmp___15 = TIFFWriteDirectoryTagShort(tif, & ndir, dir, (uint16 )274,
                                              tif->tif_dir.td_orientation);
        if (! tmp___15) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 16)) {
        tmp___16 = TIFFWriteDirectoryTagShort(tif, & ndir, dir, (uint16 )277,
                                              tif->tif_dir.td_samplesperpixel);
        if (! tmp___16) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 17)) {
        tmp___17 = TIFFWriteDirectoryTagShortLong(tif, & ndir, dir,
                                                  (uint16 )278,
                                                  tif->tif_dir.td_rowsperstrip);
        if (! tmp___17) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 18)) {
        tmp___18 = TIFFWriteDirectoryTagShortPerSample(tif, & ndir, dir,
                                                       (uint16 )280,
                                                       tif->tif_dir.td_minsamplevalue);
        if (! tmp___18) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 19)) {
        tmp___19 = TIFFWriteDirectoryTagShortPerSample(tif, & ndir, dir,
                                                       (uint16 )281,
                                                       tif->tif_dir.td_maxsamplevalue);
        if (! tmp___19) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 20)) {
        tmp___20 = TIFFWriteDirectoryTagShort(tif, & ndir, dir, (uint16 )284,
                                              tif->tif_dir.td_planarconfig);
        if (! tmp___20) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 22)) {
        tmp___21 = TIFFWriteDirectoryTagShort(tif, & ndir, dir, (uint16 )296,
                                              tif->tif_dir.td_resolutionunit);
        if (! tmp___21) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 23)) {
        tmp___22 = TIFFWriteDirectoryTagShortArray(tif, & ndir, dir,
                                                   (uint16 )297, (uint32 )2,
                                                   & tif->tif_dir.td_pagenumber[0]);
        if (! tmp___22) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 24)) {
        if (! ((tif->tif_flags & 1024U) != 0U)) {
          tmp___23 = TIFFWriteDirectoryTagLongLong8Array(tif, & ndir, dir,
                                                         (uint16 )279,
                                                         tif->tif_dir.td_nstrips,
                                                         tif->tif_dir.td_stripbytecount);
          if (! tmp___23) {
            goto bad;
          } else {

          }
        } else {
          tmp___24 = TIFFWriteDirectoryTagLongLong8Array(tif, & ndir, dir,
                                                         (uint16 )325,
                                                         tif->tif_dir.td_nstrips,
                                                         tif->tif_dir.td_stripbytecount);
          if (! tmp___24) {
            goto bad;
          } else {

          }
        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 25)) {
        if (! ((tif->tif_flags & 1024U) != 0U)) {
          tmp___25 = TIFFWriteDirectoryTagLongLong8Array(tif, & ndir, dir,
                                                         (uint16 )273,
                                                         tif->tif_dir.td_nstrips,
                                                         tif->tif_dir.td_stripoffset);
          if (! tmp___25) {
            goto bad;
          } else {

          }
        } else {
          tmp___26 = TIFFWriteDirectoryTagLongLong8Array(tif, & ndir, dir,
                                                         (uint16 )324,
                                                         tif->tif_dir.td_nstrips,
                                                         tif->tif_dir.td_stripoffset);
          if (! tmp___26) {
            goto bad;
          } else {

          }
        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 26)) {
        tmp___27 = TIFFWriteDirectoryTagColormap(tif, & ndir, dir);
        if (! tmp___27) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 31)) {
        if (tif->tif_dir.td_extrasamples) {
          TIFFGetFieldDefaulted(tif, (uint32 )338, & na, & nb);
          tmp___28 = TIFFWriteDirectoryTagShortArray(tif, & ndir, dir,
                                                     (uint16 )338, (uint32 )na,
                                                     nb);
          if (! tmp___28) {
            goto bad;
          } else {

          }
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[1] & 1UL) {
        tmp___29 = TIFFWriteDirectoryTagShortPerSample(tif, & ndir, dir,
                                                       (uint16 )339,
                                                       tif->tif_dir.td_sampleformat);
        if (! tmp___29) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 1)) {
        tmp___30 = TIFFWriteDirectoryTagSampleformatPerSample(tif, & ndir, dir,
                                                              (uint16 )340,
                                                              tif->tif_dir.td_sminsamplevalue);
        if (! tmp___30) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 2)) {
        tmp___31 = TIFFWriteDirectoryTagSampleformatPerSample(tif, & ndir, dir,
                                                              (uint16 )341,
                                                              tif->tif_dir.td_smaxsamplevalue);
        if (! tmp___31) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 3)) {
        tmp___32 = TIFFWriteDirectoryTagLong(tif, & ndir, dir, (uint16 )32997,
                                             tif->tif_dir.td_imagedepth);
        if (! tmp___32) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 4)) {
        tmp___33 = TIFFWriteDirectoryTagLong(tif, & ndir, dir, (uint16 )32998,
                                             tif->tif_dir.td_tiledepth);
        if (! tmp___33) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 5)) {
        tmp___34 = TIFFWriteDirectoryTagShortArray(tif, & ndir, dir,
                                                   (uint16 )321, (uint32 )2,
                                                   & tif->tif_dir.td_halftonehints[0]);
        if (! tmp___34) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 7)) {
        tmp___35 = TIFFWriteDirectoryTagShortArray(tif, & ndir, dir,
                                                   (uint16 )530, (uint32 )2,
                                                   & tif->tif_dir.td_ycbcrsubsampling[0]);
        if (! tmp___35) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 8)) {
        tmp___36 = TIFFWriteDirectoryTagShort(tif, & ndir, dir, (uint16 )531,
                                              tif->tif_dir.td_ycbcrpositioning);
        if (! tmp___36) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 12)) {
        tmp___37 = TIFFWriteDirectoryTagTransferfunction(tif, & ndir, dir);
        if (! tmp___37) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 14)) {
        tmp___38 = TIFFWriteDirectoryTagAscii(tif, & ndir, dir, (uint16 )333,
                                              (uint32 )tif->tif_dir.td_inknameslen,
                                              tif->tif_dir.td_inknames);
        if (! tmp___38) {
          goto bad;
        } else {

        }
      } else {

      }
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 17)) {
        tmp___39 = TIFFWriteDirectoryTagSubifd(tif, & ndir, dir);
        if (! tmp___39) {
          goto bad;
        } else {

        }
      } else {

      }
      n = (uint32 )0;
      while (n < tif->tif_nfields) {
        o = (TIFFField const   *)*(tif->tif_fields + n);
        if ((int const   )o->field_bit >= 66) {
          if (tif->tif_dir.td_fieldsset[(int const   )o->field_bit / 32] & (1UL << ((int const   )o->field_bit & 31))) {
            switch ((unsigned int const   )o->get_field_type) {
            case 1U: 
            if (! ((unsigned int const   )o->field_type == 2U)) {
              __assert_fail("o->field_type==TIFF_ASCII", "tif_dirwrite.c", 579U,
                            "TIFFWriteDirectorySec");
            } else {

            }
            if (! ((int const   )o->field_readcount == -1)) {
              __assert_fail("o->field_readcount==TIFF_VARIABLE",
                            "tif_dirwrite.c", 580U, "TIFFWriteDirectorySec");
            } else {

            }
            if (! ((int const   )o->field_passcount == 0)) {
              __assert_fail("o->field_passcount==0", "tif_dirwrite.c", 581U,
                            "TIFFWriteDirectorySec");
            } else {

            }
            TIFFGetField(tif, (uint32 )o->field_tag, & pb);
            tmp___40 = strlen((char const   *)pb);
            pa = (uint32 )tmp___40;
            tmp___41 = TIFFWriteDirectoryTagAscii(tif, & ndir, dir,
                                                  (uint16 )o->field_tag, pa, pb);
            if (! tmp___41) {
              goto bad;
            } else {

            }
            break;
            case 4U: 
            if (! ((unsigned int const   )o->field_type == 3U)) {
              __assert_fail("o->field_type==TIFF_SHORT", "tif_dirwrite.c", 591U,
                            "TIFFWriteDirectorySec");
            } else {

            }
            if (! ((int const   )o->field_readcount == 1)) {
              __assert_fail("o->field_readcount==1", "tif_dirwrite.c", 592U,
                            "TIFFWriteDirectorySec");
            } else {

            }
            if (! ((int const   )o->field_passcount == 0)) {
              __assert_fail("o->field_passcount==0", "tif_dirwrite.c", 593U,
                            "TIFFWriteDirectorySec");
            } else {

            }
            TIFFGetField(tif, (uint32 )o->field_tag, & p);
            tmp___42 = TIFFWriteDirectoryTagShort(tif, & ndir, dir,
                                                  (uint16 )o->field_tag, p);
            if (! tmp___42) {
              goto bad;
            } else {

            }
            break;
            case 6U: 
            if (! ((unsigned int const   )o->field_type == 4U)) {
              __assert_fail("o->field_type==TIFF_LONG", "tif_dirwrite.c", 602U,
                            "TIFFWriteDirectorySec");
            } else {

            }
            if (! ((int const   )o->field_readcount == 1)) {
              __assert_fail("o->field_readcount==1", "tif_dirwrite.c", 603U,
                            "TIFFWriteDirectorySec");
            } else {

            }
            if (! ((int const   )o->field_passcount == 0)) {
              __assert_fail("o->field_passcount==0", "tif_dirwrite.c", 604U,
                            "TIFFWriteDirectorySec");
            } else {

            }
            TIFFGetField(tif, (uint32 )o->field_tag, & p___0);
            tmp___43 = TIFFWriteDirectoryTagLong(tif, & ndir, dir,
                                                 (uint16 )o->field_tag, p___0);
            if (! tmp___43) {
              goto bad;
            } else {

            }
            break;
            case 40U: 
            if (! ((unsigned int const   )o->field_type == 7U)) {
              __assert_fail("o->field_type==TIFF_UNDEFINED", "tif_dirwrite.c",
                            614U, "TIFFWriteDirectorySec");
            } else {

            }
            if (! ((int const   )o->field_readcount == -3)) {
              __assert_fail("o->field_readcount==TIFF_VARIABLE2",
                            "tif_dirwrite.c", 615U, "TIFFWriteDirectorySec");
            } else {

            }
            if (! ((int const   )o->field_passcount == 1)) {
              __assert_fail("o->field_passcount==1", "tif_dirwrite.c", 616U,
                            "TIFFWriteDirectorySec");
            } else {

            }
            TIFFGetField(tif, (uint32 )o->field_tag, & pa___0, & pb___0);
            tmp___44 = TIFFWriteDirectoryTagUndefinedArray(tif, & ndir, dir,
                                                           (uint16 )o->field_tag,
                                                           pa___0,
                                                           (uint8 *)pb___0);
            if (! tmp___44) {
              goto bad;
            } else {

            }
            break;
            default: 
            __assert_fail("0", "tif_dirwrite.c", 623U, "TIFFWriteDirectorySec");
            break;
            }
          } else {

          }
        } else {

        }
        n ++;
      }
    } else {

    }
    m = (uint32 )0;
    while (m < (uint32 )tif->tif_dir.td_customValueCount) {
      switch ((unsigned int const   )((tif->tif_dir.td_customValues + m)->info)->field_type) {
      case 2U: 
      tmp___45 = TIFFWriteDirectoryTagAscii(tif, & ndir, dir,
                                            (uint16 )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                            (uint32 )(tif->tif_dir.td_customValues + m)->count,
                                            (char *)(tif->tif_dir.td_customValues + m)->value);
      if (! tmp___45) {
        goto bad;
      } else {

      }
      break;
      case 7U: 
      tmp___46 = TIFFWriteDirectoryTagUndefinedArray(tif, & ndir, dir,
                                                     (uint16 )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                     (uint32 )(tif->tif_dir.td_customValues + m)->count,
                                                     (uint8 *)(tif->tif_dir.td_customValues + m)->value);
      if (! tmp___46) {
        goto bad;
      } else {

      }
      break;
      case 1U: 
      tmp___47 = TIFFWriteDirectoryTagByteArray(tif, & ndir, dir,
                                                (uint16 )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                (uint32 )(tif->tif_dir.td_customValues + m)->count,
                                                (uint8 *)(tif->tif_dir.td_customValues + m)->value);
      if (! tmp___47) {
        goto bad;
      } else {

      }
      break;
      case 6U: 
      tmp___48 = TIFFWriteDirectoryTagSbyteArray(tif, & ndir, dir,
                                                 (uint16 )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                 (uint32 )(tif->tif_dir.td_customValues + m)->count,
                                                 (int8 *)(tif->tif_dir.td_customValues + m)->value);
      if (! tmp___48) {
        goto bad;
      } else {

      }
      break;
      case 3U: 
      tmp___49 = TIFFWriteDirectoryTagShortArray(tif, & ndir, dir,
                                                 (uint16 )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                 (uint32 )(tif->tif_dir.td_customValues + m)->count,
                                                 (uint16 *)(tif->tif_dir.td_customValues + m)->value);
      if (! tmp___49) {
        goto bad;
      } else {

      }
      break;
      case 8U: 
      tmp___50 = TIFFWriteDirectoryTagSshortArray(tif, & ndir, dir,
                                                  (uint16 )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                  (uint32 )(tif->tif_dir.td_customValues + m)->count,
                                                  (int16 *)(tif->tif_dir.td_customValues + m)->value);
      if (! tmp___50) {
        goto bad;
      } else {

      }
      break;
      case 4U: 
      tmp___51 = TIFFWriteDirectoryTagLongArray(tif, & ndir, dir,
                                                (uint16 )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                (uint32 )(tif->tif_dir.td_customValues + m)->count,
                                                (uint32 *)(tif->tif_dir.td_customValues + m)->value);
      if (! tmp___51) {
        goto bad;
      } else {

      }
      break;
      case 9U: 
      tmp___52 = TIFFWriteDirectoryTagSlongArray(tif, & ndir, dir,
                                                 (uint16 )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                 (uint32 )(tif->tif_dir.td_customValues + m)->count,
                                                 (int32 *)(tif->tif_dir.td_customValues + m)->value);
      if (! tmp___52) {
        goto bad;
      } else {

      }
      break;
      case 16U: 
      tmp___53 = TIFFWriteDirectoryTagLong8Array(tif, & ndir, dir,
                                                 (uint16 )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                 (uint32 )(tif->tif_dir.td_customValues + m)->count,
                                                 (uint64 *)(tif->tif_dir.td_customValues + m)->value);
      if (! tmp___53) {
        goto bad;
      } else {

      }
      break;
      case 17U: 
      tmp___54 = TIFFWriteDirectoryTagSlong8Array(tif, & ndir, dir,
                                                  (uint16 )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                  (uint32 )(tif->tif_dir.td_customValues + m)->count,
                                                  (int64 *)(tif->tif_dir.td_customValues + m)->value);
      if (! tmp___54) {
        goto bad;
      } else {

      }
      break;
      case 5U: 
      tmp___55 = TIFFWriteDirectoryTagRationalArray(tif, & ndir, dir,
                                                    (uint16 )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                    (uint32 )(tif->tif_dir.td_customValues + m)->count,
                                                    (float *)(tif->tif_dir.td_customValues + m)->value);
      if (! tmp___55) {
        goto bad;
      } else {

      }
      break;
      case 10U: 
      tmp___56 = TIFFWriteDirectoryTagSrationalArray(tif, & ndir, dir,
                                                     (uint16 )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                     (uint32 )(tif->tif_dir.td_customValues + m)->count,
                                                     (float *)(tif->tif_dir.td_customValues + m)->value);
      if (! tmp___56) {
        goto bad;
      } else {

      }
      break;
      case 11U: 
      tmp___57 = TIFFWriteDirectoryTagFloatArray(tif, & ndir, dir,
                                                 (uint16 )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                 (uint32 )(tif->tif_dir.td_customValues + m)->count,
                                                 (float *)(tif->tif_dir.td_customValues + m)->value);
      if (! tmp___57) {
        goto bad;
      } else {

      }
      break;
      case 12U: 
      tmp___58 = TIFFWriteDirectoryTagDoubleArray(tif, & ndir, dir,
                                                  (uint16 )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                  (uint32 )(tif->tif_dir.td_customValues + m)->count,
                                                  (double *)(tif->tif_dir.td_customValues + m)->value);
      if (! tmp___58) {
        goto bad;
      } else {

      }
      break;
      case 13U: 
      tmp___59 = TIFFWriteDirectoryTagIfdArray(tif, & ndir, dir,
                                               (uint16 )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                               (uint32 )(tif->tif_dir.td_customValues + m)->count,
                                               (uint32 *)(tif->tif_dir.td_customValues + m)->value);
      if (! tmp___59) {
        goto bad;
      } else {

      }
      break;
      case 18U: 
      tmp___60 = TIFFWriteDirectoryTagIfd8Array(tif, & ndir, dir,
                                                (uint16 )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                (uint32 )(tif->tif_dir.td_customValues + m)->count,
                                                (uint64 *)(tif->tif_dir.td_customValues + m)->value);
      if (! tmp___60) {
        goto bad;
      } else {

      }
      break;
      default: 
      __assert_fail("0", "tif_dirwrite.c", 699U, "TIFFWriteDirectorySec");
      break;
      }
      m ++;
    }
    if ((unsigned long )dir != (unsigned long )((void *)0)) {
      break;
    } else {

    }
    tmp___61 = _TIFFmalloc((tmsize_t )((unsigned long )ndir * sizeof(TIFFDirEntry )));
    dir = (TIFFDirEntry *)tmp___61;
    if ((unsigned long )dir == (unsigned long )((void *)0)) {
      TIFFErrorExt(tif->tif_clientdata, module___0, "Out of memory");
      goto bad;
    } else {

    }
    if (isimage) {
      if (tif->tif_diroff == 0UL) {
        tmp___62 = TIFFLinkDirectory(tif);
        if (! tmp___62) {
          goto bad;
        } else {

        }
      } else {

      }
    } else {
      tmp___63 = (*(tif->tif_seekproc))(tif->tif_clientdata, (uint64 )0, 2);
      tif->tif_diroff = (tmp___63 + 1UL) & 0xfffffffffffffffeUL;
    }
    if ((unsigned long )pdiroff != (unsigned long )((void *)0)) {
      *pdiroff = tif->tif_diroff;
    } else {

    }
    if (! (tif->tif_flags & 524288U)) {
      dirsize = (2U + ndir * 12U) + 4U;
    } else {
      dirsize = (8U + ndir * 20U) + 8U;
    }
    tif->tif_dataoff = tif->tif_diroff + (uint64 )dirsize;
    if (! (tif->tif_flags & 524288U)) {
      tif->tif_dataoff = (uint64 )((uint32 )tif->tif_dataoff);
    } else {

    }
    if (tif->tif_dataoff < tif->tif_diroff) {
      TIFFErrorExt(tif->tif_clientdata, module___0,
                   "Maximum TIFF file size exceeded");
      goto bad;
    } else
    if (tif->tif_dataoff < (uint64 )dirsize) {
      TIFFErrorExt(tif->tif_clientdata, module___0,
                   "Maximum TIFF file size exceeded");
      goto bad;
    } else {

    }
    if (tif->tif_dataoff & 1UL) {
      (tif->tif_dataoff) ++;
    } else {

    }
    if (isimage) {
      tif->tif_curdir = (uint16 )((int )tif->tif_curdir + 1);
    } else {

    }
  }
  if (isimage) {
    if (tif->tif_dir.td_fieldsset[1] & (1UL << 17)) {
      if (tif->tif_subifdoff == 0UL) {
        na___0 = (uint32 )0;
        nb___0 = dir;
        while (1) {
          if (! (na___0 < ndir)) {
            __assert_fail("na<ndir", "tif_dirwrite.c", 745U,
                          "TIFFWriteDirectorySec");
          } else {

          }
          if ((int )nb___0->tdir_tag == 330) {
            break;
          } else {

          }
          na___0 ++;
          nb___0 ++;
        }
        if (! (tif->tif_flags & 524288U)) {
          tif->tif_subifdoff = ((tif->tif_diroff + 2UL) + (uint64 )(na___0 * 12U)) + 8UL;
        } else {
          tif->tif_subifdoff = ((tif->tif_diroff + 8UL) + (uint64 )(na___0 * 20U)) + 12UL;
        }
      } else {

      }
    } else {

    }
  } else {

  }
  dirmem = _TIFFmalloc((tmsize_t )dirsize);
  if ((unsigned long )dirmem == (unsigned long )((void *)0)) {
    TIFFErrorExt(tif->tif_clientdata, module___0, "Out of memory");
    goto bad;
  } else {

  }
  if (! (tif->tif_flags & 524288U)) {
    n___0 = (uint8 *)dirmem;
    *((uint16 *)n___0) = (uint16 )ndir;
    if (tif->tif_flags & 128U) {
      TIFFSwabShort((uint16 *)n___0);
    } else {

    }
    n___0 += 2;
    o___0 = dir;
    m = (uint32 )0;
    while (m < ndir) {
      *((uint16 *)n___0) = o___0->tdir_tag;
      if (tif->tif_flags & 128U) {
        TIFFSwabShort((uint16 *)n___0);
      } else {

      }
      n___0 += 2;
      *((uint16 *)n___0) = o___0->tdir_type;
      if (tif->tif_flags & 128U) {
        TIFFSwabShort((uint16 *)n___0);
      } else {

      }
      n___0 += 2;
      *((uint32 *)n___0) = (uint32 )o___0->tdir_count;
      if (tif->tif_flags & 128U) {
        TIFFSwabLong((uint32 *)n___0);
      } else {

      }
      n___0 += 4;
      _TIFFmemcpy((void *)n___0, (void const   *)(& o___0->tdir_offset),
                  (tmsize_t )4);
      n___0 += 4;
      o___0 ++;
      m ++;
    }
    *((uint32 *)n___0) = (uint32 )tif->tif_nextdiroff;
  } else {
    n___1 = (uint8 *)dirmem;
    *((uint64 *)n___1) = (uint64 )ndir;
    if (tif->tif_flags & 128U) {
      TIFFSwabLong8((uint64 *)n___1);
    } else {

    }
    n___1 += 8;
    o___1 = dir;
    m = (uint32 )0;
    while (m < ndir) {
      *((uint16 *)n___1) = o___1->tdir_tag;
      if (tif->tif_flags & 128U) {
        TIFFSwabShort((uint16 *)n___1);
      } else {

      }
      n___1 += 2;
      *((uint16 *)n___1) = o___1->tdir_type;
      if (tif->tif_flags & 128U) {
        TIFFSwabShort((uint16 *)n___1);
      } else {

      }
      n___1 += 2;
      *((uint64 *)n___1) = o___1->tdir_count;
      if (tif->tif_flags & 128U) {
        TIFFSwabLong8((uint64 *)n___1);
      } else {

      }
      n___1 += 8;
      _TIFFmemcpy((void *)n___1, (void const   *)(& o___1->tdir_offset),
                  (tmsize_t )8);
      n___1 += 8;
      o___1 ++;
      m ++;
    }
    *((uint64 *)n___1) = tif->tif_nextdiroff;
  }
  _TIFFfree((void *)dir);
  dir = (TIFFDirEntry *)((void *)0);
  tmp___64 = (*(tif->tif_seekproc))(tif->tif_clientdata, tif->tif_diroff, 0);
  if (! (tmp___64 == tif->tif_diroff)) {
    TIFFErrorExt(tif->tif_clientdata, module___0, "IO error writing directory");
    goto bad;
  } else {

  }
  tmp___65 = (*(tif->tif_writeproc))(tif->tif_clientdata, dirmem,
                                     (tmsize_t )dirsize);
  if (! (tmp___65 == (tmsize_t )dirsize)) {
    TIFFErrorExt(tif->tif_clientdata, module___0, "IO error writing directory");
    goto bad;
  } else {

  }
  _TIFFfree(dirmem);
  if (imagedone) {
    TIFFFreeDirectory(tif);
    tif->tif_flags &= 4294967287U;
    (*(tif->tif_cleanup))(tif);
    TIFFCreateDirectory(tif);
  } else {

  }
  return (1);
  bad: 
  if ((unsigned long )dir != (unsigned long )((void *)0)) {
    _TIFFfree((void *)dir);
  } else {

  }
  if ((unsigned long )dirmem != (unsigned long )((void *)0)) {
    _TIFFfree(dirmem);
  } else {

  }
  return (0);
}
}
static int TIFFWriteDirectoryTagSampleformatPerSample(TIFF *tif , uint32 *ndir ,
                                                      TIFFDirEntry *dir ,
                                                      uint16 tag , double value ) 
{ 
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;

  {
  switch ((int )tif->tif_dir.td_sampleformat) {
  case 3: 
  if ((int )tif->tif_dir.td_bitspersample <= 32) {
    tmp = TIFFWriteDirectoryTagFloatPerSample(tif, ndir, dir, tag, (float )value);
    return (tmp);
  } else {
    tmp___0 = TIFFWriteDirectoryTagDoublePerSample(tif, ndir, dir, tag, value);
    return (tmp___0);
  }
  case 2: 
  if ((int )tif->tif_dir.td_bitspersample <= 8) {
    tmp___1 = TIFFWriteDirectoryTagSbytePerSample(tif, ndir, dir, tag,
                                                  (int8 )value);
    return (tmp___1);
  } else
  if ((int )tif->tif_dir.td_bitspersample <= 16) {
    tmp___2 = TIFFWriteDirectoryTagSshortPerSample(tif, ndir, dir, tag,
                                                   (int16 )value);
    return (tmp___2);
  } else {
    tmp___3 = TIFFWriteDirectoryTagSlongPerSample(tif, ndir, dir, tag,
                                                  (int32 )value);
    return (tmp___3);
  }
  case 1: 
  if ((int )tif->tif_dir.td_bitspersample <= 8) {
    tmp___4 = TIFFWriteDirectoryTagBytePerSample(tif, ndir, dir, tag,
                                                 (uint8 )value);
    return (tmp___4);
  } else
  if ((int )tif->tif_dir.td_bitspersample <= 16) {
    tmp___5 = TIFFWriteDirectoryTagShortPerSample(tif, ndir, dir, tag,
                                                  (uint16 )value);
    return (tmp___5);
  } else {
    tmp___6 = TIFFWriteDirectoryTagLongPerSample(tif, ndir, dir, tag,
                                                 (uint32 )value);
    return (tmp___6);
  }
  default: 
  return (1);
  }
}
}
static int TIFFWriteDirectoryTagAscii(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      uint32 count , char *value ) 
{ 
  int tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = TIFFWriteDirectoryTagCheckedAscii(tif, ndir, dir, tag, count, value);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagUndefinedArray(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint32 count , uint8 *value ) 
{ 
  int tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = TIFFWriteDirectoryTagCheckedUndefinedArray(tif, ndir, dir, tag, count,
                                                   value);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagByteArray(TIFF *tif , uint32 *ndir ,
                                          TIFFDirEntry *dir , uint16 tag ,
                                          uint32 count , uint8 *value ) 
{ 
  int tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = TIFFWriteDirectoryTagCheckedByteArray(tif, ndir, dir, tag, count, value);
  return (tmp);
}
}
static char const   module___1[35]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'B',      (char const   )'y',      (char const   )'t', 
        (char const   )'e',      (char const   )'P',      (char const   )'e',      (char const   )'r', 
        (char const   )'S',      (char const   )'a',      (char const   )'m',      (char const   )'p', 
        (char const   )'l',      (char const   )'e',      (char const   )'\000'};
static int TIFFWriteDirectoryTagBytePerSample(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              uint8 value ) 
{ 
  uint8 *m ;
  uint8 *na ;
  uint16 nb ;
  int o ;
  void *tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = _TIFFmalloc((tmsize_t )((unsigned long )tif->tif_dir.td_samplesperpixel * sizeof(uint8 )));
  m = (uint8 *)tmp;
  if ((unsigned long )m == (unsigned long )((void *)0)) {
    TIFFErrorExt(tif->tif_clientdata, module___1, "Out of memory");
    return (0);
  } else {

  }
  na = m;
  nb = (uint16 )0;
  while ((int )nb < (int )tif->tif_dir.td_samplesperpixel) {
    *na = value;
    na ++;
    nb = (uint16 )((int )nb + 1);
  }
  o = TIFFWriteDirectoryTagCheckedByteArray(tif, ndir, dir, tag,
                                            (uint32 )tif->tif_dir.td_samplesperpixel,
                                            m);
  _TIFFfree((void *)m);
  return (o);
}
}
static int TIFFWriteDirectoryTagSbyteArray(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , int8 *value ) 
{ 
  int tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = TIFFWriteDirectoryTagCheckedSbyteArray(tif, ndir, dir, tag, count, value);
  return (tmp);
}
}
static char const   module___2[36]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'S',      (char const   )'b',      (char const   )'y', 
        (char const   )'t',      (char const   )'e',      (char const   )'P',      (char const   )'e', 
        (char const   )'r',      (char const   )'S',      (char const   )'a',      (char const   )'m', 
        (char const   )'p',      (char const   )'l',      (char const   )'e',      (char const   )'\000'};
static int TIFFWriteDirectoryTagSbytePerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               int8 value ) 
{ 
  int8 *m ;
  int8 *na ;
  uint16 nb ;
  int o ;
  void *tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = _TIFFmalloc((tmsize_t )((unsigned long )tif->tif_dir.td_samplesperpixel * sizeof(int8 )));
  m = (int8 *)tmp;
  if ((unsigned long )m == (unsigned long )((void *)0)) {
    TIFFErrorExt(tif->tif_clientdata, module___2, "Out of memory");
    return (0);
  } else {

  }
  na = m;
  nb = (uint16 )0;
  while ((int )nb < (int )tif->tif_dir.td_samplesperpixel) {
    *na = value;
    na ++;
    nb = (uint16 )((int )nb + 1);
  }
  o = TIFFWriteDirectoryTagCheckedSbyteArray(tif, ndir, dir, tag,
                                             (uint32 )tif->tif_dir.td_samplesperpixel,
                                             m);
  _TIFFfree((void *)m);
  return (o);
}
}
static int TIFFWriteDirectoryTagShort(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      uint16 value ) 
{ 
  int tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = TIFFWriteDirectoryTagCheckedShort(tif, ndir, dir, tag, value);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagShortArray(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , uint16 *value ) 
{ 
  int tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = TIFFWriteDirectoryTagCheckedShortArray(tif, ndir, dir, tag, count, value);
  return (tmp);
}
}
static char const   module___3[36]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'S',      (char const   )'h',      (char const   )'o', 
        (char const   )'r',      (char const   )'t',      (char const   )'P',      (char const   )'e', 
        (char const   )'r',      (char const   )'S',      (char const   )'a',      (char const   )'m', 
        (char const   )'p',      (char const   )'l',      (char const   )'e',      (char const   )'\000'};
static int TIFFWriteDirectoryTagShortPerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint16 value ) 
{ 
  uint16 *m ;
  uint16 *na ;
  uint16 nb ;
  int o ;
  void *tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = _TIFFmalloc((tmsize_t )((unsigned long )tif->tif_dir.td_samplesperpixel * sizeof(uint16 )));
  m = (uint16 *)tmp;
  if ((unsigned long )m == (unsigned long )((void *)0)) {
    TIFFErrorExt(tif->tif_clientdata, module___3, "Out of memory");
    return (0);
  } else {

  }
  na = m;
  nb = (uint16 )0;
  while ((int )nb < (int )tif->tif_dir.td_samplesperpixel) {
    *na = value;
    na ++;
    nb = (uint16 )((int )nb + 1);
  }
  o = TIFFWriteDirectoryTagCheckedShortArray(tif, ndir, dir, tag,
                                             (uint32 )tif->tif_dir.td_samplesperpixel,
                                             m);
  _TIFFfree((void *)m);
  return (o);
}
}
static int TIFFWriteDirectoryTagSshortArray(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint32 count , int16 *value ) 
{ 
  int tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = TIFFWriteDirectoryTagCheckedSshortArray(tif, ndir, dir, tag, count,
                                                value);
  return (tmp);
}
}
static char const   module___4[37]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'S',      (char const   )'s',      (char const   )'h', 
        (char const   )'o',      (char const   )'r',      (char const   )'t',      (char const   )'P', 
        (char const   )'e',      (char const   )'r',      (char const   )'S',      (char const   )'a', 
        (char const   )'m',      (char const   )'p',      (char const   )'l',      (char const   )'e', 
        (char const   )'\000'};
static int TIFFWriteDirectoryTagSshortPerSample(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                int16 value ) 
{ 
  int16 *m ;
  int16 *na ;
  uint16 nb ;
  int o ;
  void *tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = _TIFFmalloc((tmsize_t )((unsigned long )tif->tif_dir.td_samplesperpixel * sizeof(int16 )));
  m = (int16 *)tmp;
  if ((unsigned long )m == (unsigned long )((void *)0)) {
    TIFFErrorExt(tif->tif_clientdata, module___4, "Out of memory");
    return (0);
  } else {

  }
  na = m;
  nb = (uint16 )0;
  while ((int )nb < (int )tif->tif_dir.td_samplesperpixel) {
    *na = value;
    na ++;
    nb = (uint16 )((int )nb + 1);
  }
  o = TIFFWriteDirectoryTagCheckedSshortArray(tif, ndir, dir, tag,
                                              (uint32 )tif->tif_dir.td_samplesperpixel,
                                              m);
  _TIFFfree((void *)m);
  return (o);
}
}
static int TIFFWriteDirectoryTagLong(TIFF *tif , uint32 *ndir ,
                                     TIFFDirEntry *dir , uint16 tag ,
                                     uint32 value ) 
{ 
  int tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = TIFFWriteDirectoryTagCheckedLong(tif, ndir, dir, tag, value);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagLongArray(TIFF *tif , uint32 *ndir ,
                                          TIFFDirEntry *dir , uint16 tag ,
                                          uint32 count , uint32 *value ) 
{ 
  int tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = TIFFWriteDirectoryTagCheckedLongArray(tif, ndir, dir, tag, count, value);
  return (tmp);
}
}
static char const   module___5[35]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'L',      (char const   )'o',      (char const   )'n', 
        (char const   )'g',      (char const   )'P',      (char const   )'e',      (char const   )'r', 
        (char const   )'S',      (char const   )'a',      (char const   )'m',      (char const   )'p', 
        (char const   )'l',      (char const   )'e',      (char const   )'\000'};
static int TIFFWriteDirectoryTagLongPerSample(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              uint32 value ) 
{ 
  uint32 *m ;
  uint32 *na ;
  uint16 nb ;
  int o ;
  void *tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = _TIFFmalloc((tmsize_t )((unsigned long )tif->tif_dir.td_samplesperpixel * sizeof(uint32 )));
  m = (uint32 *)tmp;
  if ((unsigned long )m == (unsigned long )((void *)0)) {
    TIFFErrorExt(tif->tif_clientdata, module___5, "Out of memory");
    return (0);
  } else {

  }
  na = m;
  nb = (uint16 )0;
  while ((int )nb < (int )tif->tif_dir.td_samplesperpixel) {
    *na = value;
    na ++;
    nb = (uint16 )((int )nb + 1);
  }
  o = TIFFWriteDirectoryTagCheckedLongArray(tif, ndir, dir, tag,
                                            (uint32 )tif->tif_dir.td_samplesperpixel,
                                            m);
  _TIFFfree((void *)m);
  return (o);
}
}
static int TIFFWriteDirectoryTagSlongArray(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , int32 *value ) 
{ 
  int tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = TIFFWriteDirectoryTagCheckedSlongArray(tif, ndir, dir, tag, count, value);
  return (tmp);
}
}
static char const   module___6[36]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'S',      (char const   )'l',      (char const   )'o', 
        (char const   )'n',      (char const   )'g',      (char const   )'P',      (char const   )'e', 
        (char const   )'r',      (char const   )'S',      (char const   )'a',      (char const   )'m', 
        (char const   )'p',      (char const   )'l',      (char const   )'e',      (char const   )'\000'};
static int TIFFWriteDirectoryTagSlongPerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               int32 value ) 
{ 
  int32 *m ;
  int32 *na ;
  uint16 nb ;
  int o ;
  void *tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = _TIFFmalloc((tmsize_t )((unsigned long )tif->tif_dir.td_samplesperpixel * sizeof(int32 )));
  m = (int32 *)tmp;
  if ((unsigned long )m == (unsigned long )((void *)0)) {
    TIFFErrorExt(tif->tif_clientdata, module___6, "Out of memory");
    return (0);
  } else {

  }
  na = m;
  nb = (uint16 )0;
  while ((int )nb < (int )tif->tif_dir.td_samplesperpixel) {
    *na = value;
    na ++;
    nb = (uint16 )((int )nb + 1);
  }
  o = TIFFWriteDirectoryTagCheckedSlongArray(tif, ndir, dir, tag,
                                             (uint32 )tif->tif_dir.td_samplesperpixel,
                                             m);
  _TIFFfree((void *)m);
  return (o);
}
}
static int TIFFWriteDirectoryTagLong8Array(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , uint64 *value ) 
{ 
  int tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = TIFFWriteDirectoryTagCheckedLong8Array(tif, ndir, dir, tag, count, value);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagSlong8Array(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint32 count , int64 *value ) 
{ 
  int tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = TIFFWriteDirectoryTagCheckedSlong8Array(tif, ndir, dir, tag, count,
                                                value);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagRational(TIFF *tif , uint32 *ndir ,
                                         TIFFDirEntry *dir , uint16 tag ,
                                         double value ) 
{ 
  int tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = TIFFWriteDirectoryTagCheckedRational(tif, ndir, dir, tag, value);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagRationalArray(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              uint32 count , float *value ) 
{ 
  int tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = TIFFWriteDirectoryTagCheckedRationalArray(tif, ndir, dir, tag, count,
                                                  value);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagSrationalArray(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint32 count , float *value ) 
{ 
  int tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = TIFFWriteDirectoryTagCheckedSrationalArray(tif, ndir, dir, tag, count,
                                                   value);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagFloatArray(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , float *value ) 
{ 
  int tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = TIFFWriteDirectoryTagCheckedFloatArray(tif, ndir, dir, tag, count, value);
  return (tmp);
}
}
static char const   module___7[36]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'F',      (char const   )'l',      (char const   )'o', 
        (char const   )'a',      (char const   )'t',      (char const   )'P',      (char const   )'e', 
        (char const   )'r',      (char const   )'S',      (char const   )'a',      (char const   )'m', 
        (char const   )'p',      (char const   )'l',      (char const   )'e',      (char const   )'\000'};
static int TIFFWriteDirectoryTagFloatPerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               float value ) 
{ 
  float *m ;
  float *na ;
  uint16 nb ;
  int o ;
  void *tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = _TIFFmalloc((tmsize_t )((unsigned long )tif->tif_dir.td_samplesperpixel * sizeof(float )));
  m = (float *)tmp;
  if ((unsigned long )m == (unsigned long )((void *)0)) {
    TIFFErrorExt(tif->tif_clientdata, module___7, "Out of memory");
    return (0);
  } else {

  }
  na = m;
  nb = (uint16 )0;
  while ((int )nb < (int )tif->tif_dir.td_samplesperpixel) {
    *na = value;
    na ++;
    nb = (uint16 )((int )nb + 1);
  }
  o = TIFFWriteDirectoryTagCheckedFloatArray(tif, ndir, dir, tag,
                                             (uint32 )tif->tif_dir.td_samplesperpixel,
                                             m);
  _TIFFfree((void *)m);
  return (o);
}
}
static int TIFFWriteDirectoryTagDoubleArray(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint32 count , double *value ) 
{ 
  int tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = TIFFWriteDirectoryTagCheckedDoubleArray(tif, ndir, dir, tag, count,
                                                value);
  return (tmp);
}
}
static char const   module___8[37]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'D',      (char const   )'o',      (char const   )'u', 
        (char const   )'b',      (char const   )'l',      (char const   )'e',      (char const   )'P', 
        (char const   )'e',      (char const   )'r',      (char const   )'S',      (char const   )'a', 
        (char const   )'m',      (char const   )'p',      (char const   )'l',      (char const   )'e', 
        (char const   )'\000'};
static int TIFFWriteDirectoryTagDoublePerSample(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                double value ) 
{ 
  double *m ;
  double *na ;
  uint16 nb ;
  int o ;
  void *tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = _TIFFmalloc((tmsize_t )((unsigned long )tif->tif_dir.td_samplesperpixel * sizeof(double )));
  m = (double *)tmp;
  if ((unsigned long )m == (unsigned long )((void *)0)) {
    TIFFErrorExt(tif->tif_clientdata, module___8, "Out of memory");
    return (0);
  } else {

  }
  na = m;
  nb = (uint16 )0;
  while ((int )nb < (int )tif->tif_dir.td_samplesperpixel) {
    *na = value;
    na ++;
    nb = (uint16 )((int )nb + 1);
  }
  o = TIFFWriteDirectoryTagCheckedDoubleArray(tif, ndir, dir, tag,
                                              (uint32 )tif->tif_dir.td_samplesperpixel,
                                              m);
  _TIFFfree((void *)m);
  return (o);
}
}
static int TIFFWriteDirectoryTagIfdArray(TIFF *tif , uint32 *ndir ,
                                         TIFFDirEntry *dir , uint16 tag ,
                                         uint32 count , uint32 *value ) 
{ 
  int tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = TIFFWriteDirectoryTagCheckedIfdArray(tif, ndir, dir, tag, count, value);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagIfd8Array(TIFF *tif , uint32 *ndir ,
                                          TIFFDirEntry *dir , uint16 tag ,
                                          uint32 count , uint64 *value ) 
{ 
  int tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  tmp = TIFFWriteDirectoryTagCheckedIfd8Array(tif, ndir, dir, tag, count, value);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagShortLong(TIFF *tif , uint32 *ndir ,
                                          TIFFDirEntry *dir , uint16 tag ,
                                          uint32 value ) 
{ 
  int tmp ;
  int tmp___0 ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  if (value <= 65535U) {
    tmp = TIFFWriteDirectoryTagCheckedShort(tif, ndir, dir, tag, (uint16 )value);
    return (tmp);
  } else {
    tmp___0 = TIFFWriteDirectoryTagCheckedLong(tif, ndir, dir, tag, value);
    return (tmp___0);
  }
}
}
static char const   module___9[36]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'L',      (char const   )'o',      (char const   )'n', 
        (char const   )'g',      (char const   )'L',      (char const   )'o',      (char const   )'n', 
        (char const   )'g',      (char const   )'8',      (char const   )'A',      (char const   )'r', 
        (char const   )'r',      (char const   )'a',      (char const   )'y',      (char const   )'\000'};
static int TIFFWriteDirectoryTagLongLong8Array(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint32 count , uint64 *value ) 
{ 
  uint64 *ma ;
  uint32 mb ;
  uint32 *p ;
  uint32 *q ;
  int o ;
  int tmp ;
  void *tmp___0 ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  if (tif->tif_flags & 524288U) {
    tmp = TIFFWriteDirectoryTagCheckedLong8Array(tif, ndir, dir, tag, count,
                                                 value);
    return (tmp);
  } else {

  }
  tmp___0 = _TIFFmalloc((tmsize_t )((unsigned long )count * sizeof(uint32 )));
  p = (uint32 *)tmp___0;
  if ((unsigned long )p == (unsigned long )((void *)0)) {
    TIFFErrorExt(tif->tif_clientdata, module___9, "Out of memory");
    return (0);
  } else {

  }
  q = p;
  ma = value;
  mb = (uint32 )0;
  while (mb < count) {
    if (*ma > 4294967295UL) {
      TIFFErrorExt(tif->tif_clientdata, module___9,
                   "Attempt to write value larger than 0xFFFFFFFF in Classic TIFF file.");
      _TIFFfree((void *)p);
      return (0);
    } else {

    }
    *q = (uint32 )*ma;
    ma ++;
    mb ++;
    q ++;
  }
  o = TIFFWriteDirectoryTagCheckedLongArray(tif, ndir, dir, tag, count, p);
  _TIFFfree((void *)p);
  return (o);
}
}
static char const   module___11[30]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'C',      (char const   )'o',      (char const   )'l', 
        (char const   )'o',      (char const   )'r',      (char const   )'m',      (char const   )'a', 
        (char const   )'p',      (char const   )'\000'};
static int TIFFWriteDirectoryTagColormap(TIFF *tif , uint32 *ndir ,
                                         TIFFDirEntry *dir ) 
{ 
  uint32 m ;
  uint16 *n ;
  int o ;
  void *tmp ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  m = (uint32 )(1 << (int )tif->tif_dir.td_bitspersample);
  tmp = _TIFFmalloc((tmsize_t )((unsigned long )(3U * m) * sizeof(uint16 )));
  n = (uint16 *)tmp;
  if ((unsigned long )n == (unsigned long )((void *)0)) {
    TIFFErrorExt(tif->tif_clientdata, module___11, "Out of memory");
    return (0);
  } else {

  }
  _TIFFmemcpy((void *)(n + 0), (void const   *)tif->tif_dir.td_colormap[0],
              (tmsize_t )((unsigned long )m * sizeof(uint16 )));
  _TIFFmemcpy((void *)(n + m), (void const   *)tif->tif_dir.td_colormap[1],
              (tmsize_t )((unsigned long )m * sizeof(uint16 )));
  _TIFFmemcpy((void *)(n + 2U * m), (void const   *)tif->tif_dir.td_colormap[2],
              (tmsize_t )((unsigned long )m * sizeof(uint16 )));
  o = TIFFWriteDirectoryTagCheckedShortArray(tif, ndir, dir, (uint16 )320,
                                             3U * m, n);
  _TIFFfree((void *)n);
  return (o);
}
}
static char const   module___12[38]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'T',      (char const   )'r',      (char const   )'a', 
        (char const   )'n',      (char const   )'s',      (char const   )'f',      (char const   )'e', 
        (char const   )'r',      (char const   )'f',      (char const   )'u',      (char const   )'n', 
        (char const   )'c',      (char const   )'t',      (char const   )'i',      (char const   )'o', 
        (char const   )'n',      (char const   )'\000'};
static int TIFFWriteDirectoryTagTransferfunction(TIFF *tif , uint32 *ndir ,
                                                 TIFFDirEntry *dir ) 
{ 
  uint32 m ;
  uint16 n ;
  uint16 *o ;
  int p ;
  int tmp ;
  int tmp___0 ;
  void *tmp___1 ;

  {
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  m = (uint32 )(1 << (int )tif->tif_dir.td_bitspersample);
  n = (uint16 )((int )tif->tif_dir.td_samplesperpixel - (int )tif->tif_dir.td_extrasamples);
  if ((int )n > 3) {
    n = (uint16 )3;
  } else {

  }
  if ((int )n == 3) {
    tmp = _TIFFmemcmp((void const   *)tif->tif_dir.td_transferfunction[0],
                      (void const   *)tif->tif_dir.td_transferfunction[2],
                      (tmsize_t )((unsigned long )m * sizeof(uint16 )));
    if (! tmp) {
      n = (uint16 )2;
    } else {

    }
  } else {

  }
  if ((int )n == 2) {
    tmp___0 = _TIFFmemcmp((void const   *)tif->tif_dir.td_transferfunction[0],
                          (void const   *)tif->tif_dir.td_transferfunction[1],
                          (tmsize_t )((unsigned long )m * sizeof(uint16 )));
    if (! tmp___0) {
      n = (uint16 )1;
    } else {

    }
  } else {

  }
  if ((int )n == 0) {
    n = (uint16 )1;
  } else {

  }
  tmp___1 = _TIFFmalloc((tmsize_t )((unsigned long )((uint32 )n * m) * sizeof(uint16 )));
  o = (uint16 *)tmp___1;
  if ((unsigned long )o == (unsigned long )((void *)0)) {
    TIFFErrorExt(tif->tif_clientdata, module___12, "Out of memory");
    return (0);
  } else {

  }
  _TIFFmemcpy((void *)(o + 0),
              (void const   *)tif->tif_dir.td_transferfunction[0],
              (tmsize_t )((unsigned long )m * sizeof(uint16 )));
  if ((int )n > 1) {
    _TIFFmemcpy((void *)(o + m),
                (void const   *)tif->tif_dir.td_transferfunction[1],
                (tmsize_t )((unsigned long )m * sizeof(uint16 )));
  } else {

  }
  if ((int )n > 2) {
    _TIFFmemcpy((void *)(o + 2U * m),
                (void const   *)tif->tif_dir.td_transferfunction[2],
                (tmsize_t )((unsigned long )m * sizeof(uint16 )));
  } else {

  }
  p = TIFFWriteDirectoryTagCheckedShortArray(tif, ndir, dir, (uint16 )301,
                                             (uint32 )n * m, o);
  _TIFFfree((void *)o);
  return (p);
}
}
static char const   module___13[28]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'S',      (char const   )'u',      (char const   )'b', 
        (char const   )'i',      (char const   )'f',      (char const   )'d',      (char const   )'\000'};
static int TIFFWriteDirectoryTagSubifd(TIFF *tif , uint32 *ndir ,
                                       TIFFDirEntry *dir ) 
{ 
  uint64 m ;
  int n ;
  uint32 *o ;
  uint64 *pa ;
  uint32 *pb ;
  uint16 p ;
  void *tmp ;
  uint32 *tmp___0 ;
  uint64 *tmp___1 ;

  {
  if ((int )tif->tif_dir.td_nsubifd == 0) {
    return (1);
  } else {

  }
  if ((unsigned long )dir == (unsigned long )((void *)0)) {
    (*ndir) ++;
    return (1);
  } else {

  }
  m = tif->tif_dataoff;
  if (! (tif->tif_flags & 524288U)) {
    tmp = _TIFFmalloc((tmsize_t )((unsigned long )tif->tif_dir.td_nsubifd * sizeof(uint32 )));
    o = (uint32 *)tmp;
    if ((unsigned long )o == (unsigned long )((void *)0)) {
      TIFFErrorExt(tif->tif_clientdata, module___13, "Out of memory");
      return (0);
    } else {

    }
    pa = tif->tif_dir.td_subifd;
    pb = o;
    p = (uint16 )0;
    while ((int )p < (int )tif->tif_dir.td_nsubifd) {
      if (! (*pa <= 4294967295UL)) {
        __assert_fail("*pa<=0xFFFFFFFFUL", "tif_dirwrite.c", 1625U,
                      "TIFFWriteDirectoryTagSubifd");
      } else {

      }
      tmp___0 = pb;
      pb ++;
      tmp___1 = pa;
      pa ++;
      *tmp___0 = (uint32 )*tmp___1;
      p = (uint16 )((int )p + 1);
    }
    n = TIFFWriteDirectoryTagCheckedIfdArray(tif, ndir, dir, (uint16 )330,
                                             (uint32 )tif->tif_dir.td_nsubifd, o);
    _TIFFfree((void *)o);
  } else {
    n = TIFFWriteDirectoryTagCheckedIfd8Array(tif, ndir, dir, (uint16 )330,
                                              (uint32 )tif->tif_dir.td_nsubifd,
                                              tif->tif_dir.td_subifd);
  }
  if (! n) {
    return (0);
  } else {

  }
  tif->tif_flags |= 8192U;
  tif->tif_nsubifd = tif->tif_dir.td_nsubifd;
  if ((int )tif->tif_dir.td_nsubifd == 1) {
    tif->tif_subifdoff = (uint64 )0;
  } else {
    tif->tif_subifdoff = m;
  }
  return (1);
}
}
static int TIFFWriteDirectoryTagCheckedAscii(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             uint32 count , char *value ) 
{ 
  int tmp ;

  {
  if (! (sizeof(char ) == 1UL)) {
    __assert_fail("sizeof(char)==1", "tif_dirwrite.c", 1655U,
                  "TIFFWriteDirectoryTagCheckedAscii");
  } else {

  }
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (uint16 )2, count, count,
                                  (void *)value);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedUndefinedArray(TIFF *tif , uint32 *ndir ,
                                                      TIFFDirEntry *dir ,
                                                      uint16 tag ,
                                                      uint32 count ,
                                                      uint8 *value ) 
{ 
  int tmp ;

  {
  if (! (sizeof(uint8 ) == 1UL)) {
    __assert_fail("sizeof(uint8)==1", "tif_dirwrite.c", 1662U,
                  "TIFFWriteDirectoryTagCheckedUndefinedArray");
  } else {

  }
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (uint16 )7, count, count,
                                  (void *)value);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedByteArray(TIFF *tif , uint32 *ndir ,
                                                 TIFFDirEntry *dir ,
                                                 uint16 tag , uint32 count ,
                                                 uint8 *value ) 
{ 
  int tmp ;

  {
  if (! (sizeof(uint8 ) == 1UL)) {
    __assert_fail("sizeof(uint8)==1", "tif_dirwrite.c", 1676U,
                  "TIFFWriteDirectoryTagCheckedByteArray");
  } else {

  }
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (uint16 )1, count, count,
                                  (void *)value);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedSbyteArray(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  int8 *value ) 
{ 
  int tmp ;

  {
  if (! (sizeof(int8 ) == 1UL)) {
    __assert_fail("sizeof(int8)==1", "tif_dirwrite.c", 1690U,
                  "TIFFWriteDirectoryTagCheckedSbyteArray");
  } else {

  }
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (uint16 )6, count, count,
                                  (void *)value);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedShort(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             uint16 value ) 
{ 
  uint16 m ;
  int tmp ;

  {
  if (! (sizeof(uint16 ) == 2UL)) {
    __assert_fail("sizeof(uint16)==2", "tif_dirwrite.c", 1698U,
                  "TIFFWriteDirectoryTagCheckedShort");
  } else {

  }
  m = value;
  if (tif->tif_flags & 128U) {
    TIFFSwabShort(& m);
  } else {

  }
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (uint16 )3, (uint32 )1,
                                  (uint32 )2, (void *)(& m));
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedShortArray(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  uint16 *value ) 
{ 
  int tmp ;

  {
  if (! (count < 2147483648U)) {
    __assert_fail("count<0x80000000", "tif_dirwrite.c", 1708U,
                  "TIFFWriteDirectoryTagCheckedShortArray");
  } else {

  }
  if (! (sizeof(uint16 ) == 2UL)) {
    __assert_fail("sizeof(uint16)==2", "tif_dirwrite.c", 1709U,
                  "TIFFWriteDirectoryTagCheckedShortArray");
  } else {

  }
  if (tif->tif_flags & 128U) {
    TIFFSwabArrayOfShort(value, (tmsize_t )count);
  } else {

  }
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (uint16 )3, count,
                                  count * 2U, (void *)value);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedSshortArray(TIFF *tif , uint32 *ndir ,
                                                   TIFFDirEntry *dir ,
                                                   uint16 tag , uint32 count ,
                                                   int16 *value ) 
{ 
  int tmp ;

  {
  if (! (count < 2147483648U)) {
    __assert_fail("count<0x80000000", "tif_dirwrite.c", 1729U,
                  "TIFFWriteDirectoryTagCheckedSshortArray");
  } else {

  }
  if (! (sizeof(int16 ) == 2UL)) {
    __assert_fail("sizeof(int16)==2", "tif_dirwrite.c", 1730U,
                  "TIFFWriteDirectoryTagCheckedSshortArray");
  } else {

  }
  if (tif->tif_flags & 128U) {
    TIFFSwabArrayOfShort((uint16 *)value, (tmsize_t )count);
  } else {

  }
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (uint16 )8, count,
                                  count * 2U, (void *)value);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedLong(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint32 value ) 
{ 
  uint32 m ;
  int tmp ;

  {
  if (! (sizeof(uint32 ) == 4UL)) {
    __assert_fail("sizeof(uint32)==4", "tif_dirwrite.c", 1740U,
                  "TIFFWriteDirectoryTagCheckedLong");
  } else {

  }
  m = value;
  if (tif->tif_flags & 128U) {
    TIFFSwabLong(& m);
  } else {

  }
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (uint16 )4, (uint32 )1,
                                  (uint32 )4, (void *)(& m));
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedLongArray(TIFF *tif , uint32 *ndir ,
                                                 TIFFDirEntry *dir ,
                                                 uint16 tag , uint32 count ,
                                                 uint32 *value ) 
{ 
  int tmp ;

  {
  if (! (count < 1073741824U)) {
    __assert_fail("count<0x40000000", "tif_dirwrite.c", 1750U,
                  "TIFFWriteDirectoryTagCheckedLongArray");
  } else {

  }
  if (! (sizeof(uint32 ) == 4UL)) {
    __assert_fail("sizeof(uint32)==4", "tif_dirwrite.c", 1751U,
                  "TIFFWriteDirectoryTagCheckedLongArray");
  } else {

  }
  if (tif->tif_flags & 128U) {
    TIFFSwabArrayOfLong(value, (tmsize_t )count);
  } else {

  }
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (uint16 )4, count,
                                  count * 4U, (void *)value);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedSlongArray(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  int32 *value ) 
{ 
  int tmp ;

  {
  if (! (count < 1073741824U)) {
    __assert_fail("count<0x40000000", "tif_dirwrite.c", 1771U,
                  "TIFFWriteDirectoryTagCheckedSlongArray");
  } else {

  }
  if (! (sizeof(int32 ) == 4UL)) {
    __assert_fail("sizeof(int32)==4", "tif_dirwrite.c", 1772U,
                  "TIFFWriteDirectoryTagCheckedSlongArray");
  } else {

  }
  if (tif->tif_flags & 128U) {
    TIFFSwabArrayOfLong((uint32 *)value, (tmsize_t )count);
  } else {

  }
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (uint16 )9, count,
                                  count * 4U, (void *)value);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedLong8Array(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  uint64 *value ) 
{ 
  int tmp ;

  {
  if (! (count < 536870912U)) {
    __assert_fail("count<0x20000000", "tif_dirwrite.c", 1793U,
                  "TIFFWriteDirectoryTagCheckedLong8Array");
  } else {

  }
  if (! (sizeof(uint64 ) == 8UL)) {
    __assert_fail("sizeof(uint64)==8", "tif_dirwrite.c", 1794U,
                  "TIFFWriteDirectoryTagCheckedLong8Array");
  } else {

  }
  if (! (tif->tif_flags & 524288U)) {
    __assert_fail("tif->tif_flags&TIFF_BIGTIFF", "tif_dirwrite.c", 1795U,
                  "TIFFWriteDirectoryTagCheckedLong8Array");
  } else {

  }
  if (tif->tif_flags & 128U) {
    TIFFSwabArrayOfLong8(value, (tmsize_t )count);
  } else {

  }
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (uint16 )16, count,
                                  count * 8U, (void *)value);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedSlong8Array(TIFF *tif , uint32 *ndir ,
                                                   TIFFDirEntry *dir ,
                                                   uint16 tag , uint32 count ,
                                                   int64 *value ) 
{ 
  int tmp ;

  {
  if (! (count < 536870912U)) {
    __assert_fail("count<0x20000000", "tif_dirwrite.c", 1816U,
                  "TIFFWriteDirectoryTagCheckedSlong8Array");
  } else {

  }
  if (! (sizeof(int64 ) == 8UL)) {
    __assert_fail("sizeof(int64)==8", "tif_dirwrite.c", 1817U,
                  "TIFFWriteDirectoryTagCheckedSlong8Array");
  } else {

  }
  if (! (tif->tif_flags & 524288U)) {
    __assert_fail("tif->tif_flags&TIFF_BIGTIFF", "tif_dirwrite.c", 1818U,
                  "TIFFWriteDirectoryTagCheckedSlong8Array");
  } else {

  }
  if (tif->tif_flags & 128U) {
    TIFFSwabArrayOfLong8((uint64 *)value, (tmsize_t )count);
  } else {

  }
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (uint16 )17, count,
                                  count * 8U, (void *)value);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedRational(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                double value ) 
{ 
  uint32 m[2] ;
  int tmp ;

  {
  if (! (value >= 0.0)) {
    __assert_fail("value>=0.0", "tif_dirwrite.c", 1828U,
                  "TIFFWriteDirectoryTagCheckedRational");
  } else {

  }
  if (! (sizeof(uint32 ) == 4UL)) {
    __assert_fail("sizeof(uint32)==4", "tif_dirwrite.c", 1829U,
                  "TIFFWriteDirectoryTagCheckedRational");
  } else {

  }
  if (value <= 0.0) {
    m[0] = (uint32 )0;
    m[1] = (uint32 )1;
  } else
  if (value == (double )((uint32 )value)) {
    m[0] = (uint32 )value;
    m[1] = (uint32 )1;
  } else
  if (value < 1.0) {
    m[0] = (uint32 )(value * (double )4294967295U);
    m[1] = 4294967295U;
  } else {
    m[0] = 4294967295U;
    m[1] = (uint32 )((double )4294967295U / value);
  }
  if (tif->tif_flags & 128U) {
    TIFFSwabLong(& m[0]);
    TIFFSwabLong(& m[1]);
  } else {

  }
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (uint16 )5, (uint32 )1,
                                  (uint32 )8, (void *)(& m[0]));
  return (tmp);
}
}
static char const   module___14[42]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'C',      (char const   )'h',      (char const   )'e', 
        (char const   )'c',      (char const   )'k',      (char const   )'e',      (char const   )'d', 
        (char const   )'R',      (char const   )'a',      (char const   )'t',      (char const   )'i', 
        (char const   )'o',      (char const   )'n',      (char const   )'a',      (char const   )'l', 
        (char const   )'A',      (char const   )'r',      (char const   )'r',      (char const   )'a', 
        (char const   )'y',      (char const   )'\000'};
static int TIFFWriteDirectoryTagCheckedRationalArray(TIFF *tif , uint32 *ndir ,
                                                     TIFFDirEntry *dir ,
                                                     uint16 tag , uint32 count ,
                                                     float *value ) 
{ 
  uint32 *m ;
  float *na ;
  uint32 *nb ;
  uint32 nc ;
  int o ;
  void *tmp ;

  {
  if (! (sizeof(uint32 ) == 4UL)) {
    __assert_fail("sizeof(uint32)==4", "tif_dirwrite.c", 1867U,
                  "TIFFWriteDirectoryTagCheckedRationalArray");
  } else {

  }
  tmp = _TIFFmalloc((tmsize_t )((unsigned long )(count * 2U) * sizeof(uint32 )));
  m = (uint32 *)tmp;
  if ((unsigned long )m == (unsigned long )((void *)0)) {
    TIFFErrorExt(tif->tif_clientdata, module___14, "Out of memory");
    return (0);
  } else {

  }
  na = value;
  nb = m;
  nc = (uint32 )0;
  while (nc < count) {
    if ((double )*na <= 0.0) {
      *(nb + 0) = (uint32 )0;
      *(nb + 1) = (uint32 )1;
    } else
    if (*na == (float )((uint32 )*na)) {
      *(nb + 0) = (uint32 )*na;
      *(nb + 1) = (uint32 )1;
    } else
    if ((double )*na < 1.0) {
      *(nb + 0) = (uint32 )(*na * (float )4294967295U);
      *(nb + 1) = 4294967295U;
    } else {
      *(nb + 0) = 4294967295U;
      *(nb + 1) = (uint32 )((float )4294967295U / *na);
    }
    na ++;
    nb += 2;
    nc ++;
  }
  if (tif->tif_flags & 128U) {
    TIFFSwabArrayOfLong(m, (tmsize_t )(count * 2U));
  } else {

  }
  o = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (uint16 )5, count,
                                count * 8U, (void *)(m + 0));
  _TIFFfree((void *)m);
  return (o);
}
}
static char const   module___15[43]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'C',      (char const   )'h',      (char const   )'e', 
        (char const   )'c',      (char const   )'k',      (char const   )'e',      (char const   )'d', 
        (char const   )'S',      (char const   )'r',      (char const   )'a',      (char const   )'t', 
        (char const   )'i',      (char const   )'o',      (char const   )'n',      (char const   )'a', 
        (char const   )'l',      (char const   )'A',      (char const   )'r',      (char const   )'r', 
        (char const   )'a',      (char const   )'y',      (char const   )'\000'};
static int TIFFWriteDirectoryTagCheckedSrationalArray(TIFF *tif , uint32 *ndir ,
                                                      TIFFDirEntry *dir ,
                                                      uint16 tag ,
                                                      uint32 count ,
                                                      float *value ) 
{ 
  int32 *m ;
  float *na ;
  int32 *nb ;
  uint32 nc ;
  int o ;
  void *tmp ;

  {
  if (! (sizeof(int32 ) == 4UL)) {
    __assert_fail("sizeof(int32)==4", "tif_dirwrite.c", 1913U,
                  "TIFFWriteDirectoryTagCheckedSrationalArray");
  } else {

  }
  tmp = _TIFFmalloc((tmsize_t )((unsigned long )(count * 2U) * sizeof(int32 )));
  m = (int32 *)tmp;
  if ((unsigned long )m == (unsigned long )((void *)0)) {
    TIFFErrorExt(tif->tif_clientdata, module___15, "Out of memory");
    return (0);
  } else {

  }
  na = value;
  nb = m;
  nc = (uint32 )0;
  while (nc < count) {
    if ((double )*na < 0.0) {
      if (*na == (float )((int32 )*na)) {
        *(nb + 0) = (int32 )*na;
        *(nb + 1) = 1;
      } else
      if ((double )*na > - 1.0) {
        *(nb + 0) = - ((int32 )(- *na * (float )2147483647));
        *(nb + 1) = 2147483647;
      } else {
        *(nb + 0) = -2147483647;
        *(nb + 1) = (int32 )((float )2147483647 / - *na);
      }
    } else
    if (*na == (float )((int32 )*na)) {
      *(nb + 0) = (int32 )*na;
      *(nb + 1) = 1;
    } else
    if ((double )*na < 1.0) {
      *(nb + 0) = (int32 )(*na * (float )2147483647);
      *(nb + 1) = 2147483647;
    } else {
      *(nb + 0) = 2147483647;
      *(nb + 1) = (int32 )((float )2147483647 / *na);
    }
    na ++;
    nb += 2;
    nc ++;
  }
  if (tif->tif_flags & 128U) {
    TIFFSwabArrayOfLong((uint32 *)m, (tmsize_t )(count * 2U));
  } else {

  }
  o = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (uint16 )10, count,
                                count * 8U, (void *)(m + 0));
  _TIFFfree((void *)m);
  return (o);
}
}
static int TIFFWriteDirectoryTagCheckedFloatArray(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  float *value ) 
{ 
  int tmp ;

  {
  if (! (count < 1073741824U)) {
    __assert_fail("count<0x40000000", "tif_dirwrite.c", 1981U,
                  "TIFFWriteDirectoryTagCheckedFloatArray");
  } else {

  }
  if (! (sizeof(float ) == 4UL)) {
    __assert_fail("sizeof(float)==4", "tif_dirwrite.c", 1982U,
                  "TIFFWriteDirectoryTagCheckedFloatArray");
  } else {

  }
  if (tif->tif_flags & 128U) {
    TIFFSwabArrayOfFloat(value, (tmsize_t )count);
  } else {

  }
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (uint16 )11, count,
                                  count * 4U, (void *)value);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedDoubleArray(TIFF *tif , uint32 *ndir ,
                                                   TIFFDirEntry *dir ,
                                                   uint16 tag , uint32 count ,
                                                   double *value ) 
{ 
  int tmp ;

  {
  if (! (count < 536870912U)) {
    __assert_fail("count<0x20000000", "tif_dirwrite.c", 2004U,
                  "TIFFWriteDirectoryTagCheckedDoubleArray");
  } else {

  }
  if (! (sizeof(double ) == 8UL)) {
    __assert_fail("sizeof(double)==8", "tif_dirwrite.c", 2005U,
                  "TIFFWriteDirectoryTagCheckedDoubleArray");
  } else {

  }
  if (tif->tif_flags & 128U) {
    TIFFSwabArrayOfDouble(value, (tmsize_t )count);
  } else {

  }
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (uint16 )12, count,
                                  count * 8U, (void *)value);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedIfdArray(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                uint32 count , uint32 *value ) 
{ 
  int tmp ;

  {
  if (! (count < 1073741824U)) {
    __assert_fail("count<0x40000000", "tif_dirwrite.c", 2015U,
                  "TIFFWriteDirectoryTagCheckedIfdArray");
  } else {

  }
  if (! (sizeof(uint32 ) == 4UL)) {
    __assert_fail("sizeof(uint32)==4", "tif_dirwrite.c", 2016U,
                  "TIFFWriteDirectoryTagCheckedIfdArray");
  } else {

  }
  if (tif->tif_flags & 128U) {
    TIFFSwabArrayOfLong(value, (tmsize_t )count);
  } else {

  }
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (uint16 )13, count,
                                  count * 4U, (void *)value);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedIfd8Array(TIFF *tif , uint32 *ndir ,
                                                 TIFFDirEntry *dir ,
                                                 uint16 tag , uint32 count ,
                                                 uint64 *value ) 
{ 
  int tmp ;

  {
  if (! (count < 536870912U)) {
    __assert_fail("count<0x20000000", "tif_dirwrite.c", 2025U,
                  "TIFFWriteDirectoryTagCheckedIfd8Array");
  } else {

  }
  if (! (sizeof(uint64 ) == 8UL)) {
    __assert_fail("sizeof(uint64)==8", "tif_dirwrite.c", 2026U,
                  "TIFFWriteDirectoryTagCheckedIfd8Array");
  } else {

  }
  if (! (tif->tif_flags & 524288U)) {
    __assert_fail("tif->tif_flags&TIFF_BIGTIFF", "tif_dirwrite.c", 2027U,
                  "TIFFWriteDirectoryTagCheckedIfd8Array");
  } else {

  }
  if (tif->tif_flags & 128U) {
    TIFFSwabArrayOfLong8(value, (tmsize_t )count);
  } else {

  }
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (uint16 )18, count,
                                  count * 8U, (void *)value);
  return (tmp);
}
}
static char const   module___16[26]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'D',      (char const   )'a',      (char const   )'t', 
        (char const   )'a',      (char const   )'\000'};
static int TIFFWriteDirectoryTagData(TIFF *tif , uint32 *ndir ,
                                     TIFFDirEntry *dir , uint16 tag ,
                                     uint16 datatype , uint32 count ,
                                     uint32 datalength , void *data ) 
{ 
  uint32 m ;
  uint32 n ;
  uint64 na ;
  uint64 nb ;
  uint64 tmp ;
  tmsize_t tmp___0 ;
  uint32 o ;
  unsigned int tmp___1 ;

  {
  m = (uint32 )0;
  while (m < *ndir) {
    if (! ((int )(dir + m)->tdir_tag != (int )tag)) {
      __assert_fail("dir[m].tdir_tag!=tag", "tif_dirwrite.c", 2041U,
                    "TIFFWriteDirectoryTagData");
    } else {

    }
    if ((int )(dir + m)->tdir_tag > (int )tag) {
      break;
    } else {

    }
    m ++;
  }
  if (m < *ndir) {
    n = *ndir;
    while (n > m) {
      *(dir + n) = *(dir + (n - 1U));
      n --;
    }
  } else {

  }
  (dir + m)->tdir_tag = tag;
  (dir + m)->tdir_type = datatype;
  (dir + m)->tdir_count = (uint64 )count;
  (dir + m)->tdir_offset = (uint64 )0;
  if (tif->tif_flags & 524288U) {
    tmp___1 = 8U;
  } else {
    tmp___1 = 4U;
  }
  if (datalength <= tmp___1) {
    _TIFFmemcpy((void *)(& (dir + m)->tdir_offset), (void const   *)data,
                (tmsize_t )datalength);
  } else {
    na = tif->tif_dataoff;
    nb = na + (uint64 )datalength;
    if (! (tif->tif_flags & 524288U)) {
      nb = (uint64 )((uint32 )nb);
    } else {

    }
    if (nb < na) {
      TIFFErrorExt(tif->tif_clientdata, module___16,
                   "Maximum TIFF file size exceeded");
      return (0);
    } else
    if (nb < (uint64 )datalength) {
      TIFFErrorExt(tif->tif_clientdata, module___16,
                   "Maximum TIFF file size exceeded");
      return (0);
    } else {

    }
    tmp = (*(tif->tif_seekproc))(tif->tif_clientdata, na, 0);
    if (! (tmp == na)) {
      TIFFErrorExt(tif->tif_clientdata, module___16, "IO error writing tag data");
      return (0);
    } else {

    }
    if (! ((unsigned long )datalength < 2147483648UL)) {
      __assert_fail("datalength<0x80000000UL", "tif_dirwrite.c", 2075U,
                    "TIFFWriteDirectoryTagData");
    } else {

    }
    tmp___0 = (*(tif->tif_writeproc))(tif->tif_clientdata, data,
                                      (tmsize_t )datalength);
    if (! (tmp___0 == (tmsize_t )datalength)) {
      TIFFErrorExt(tif->tif_clientdata, module___16, "IO error writing tag data");
      return (0);
    } else {

    }
    tif->tif_dataoff = nb;
    if (tif->tif_dataoff & 1UL) {
      (tif->tif_dataoff) ++;
    } else {

    }
    if (! (tif->tif_flags & 524288U)) {
      o = (uint32 )na;
      if (tif->tif_flags & 128U) {
        TIFFSwabLong(& o);
      } else {

      }
      _TIFFmemcpy((void *)(& (dir + m)->tdir_offset), (void const   *)(& o),
                  (tmsize_t )4);
    } else {
      (dir + m)->tdir_offset = na;
      if (tif->tif_flags & 128U) {
        TIFFSwabLong8(& (dir + m)->tdir_offset);
      } else {

      }
    }
  }
  (*ndir) ++;
  return (1);
}
}
static char const   module___17[18]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'L',      (char const   )'i',      (char const   )'n',      (char const   )'k', 
        (char const   )'D',      (char const   )'i',      (char const   )'r',      (char const   )'e', 
        (char const   )'c',      (char const   )'t',      (char const   )'o',      (char const   )'r', 
        (char const   )'y',      (char const   )'\000'};
static int TIFFLinkDirectory(TIFF *tif ) 
{ 
  uint64 tmp ;
  uint32 m ;
  tmsize_t tmp___0 ;
  uint64 m___0 ;
  tmsize_t tmp___1 ;
  uint32 m___1 ;
  uint32 nextdir ;
  tmsize_t tmp___2 ;
  uint16 dircount ;
  uint32 nextnextdir ;
  uint64 tmp___3 ;
  tmsize_t tmp___4 ;
  tmsize_t tmp___5 ;
  tmsize_t tmp___6 ;
  uint64 m___2 ;
  uint64 nextdir___0 ;
  tmsize_t tmp___7 ;
  uint64 dircount64 ;
  uint16 dircount___0 ;
  uint64 nextnextdir___0 ;
  uint64 tmp___8 ;
  tmsize_t tmp___9 ;
  tmsize_t tmp___10 ;
  tmsize_t tmp___11 ;

  {
  tmp = (*(tif->tif_seekproc))(tif->tif_clientdata, (uint64 )0, 2);
  tif->tif_diroff = (tmp + 1UL) & 0xfffffffffffffffeUL;
  if (tif->tif_flags & 8192U) {
    if (! (tif->tif_flags & 524288U)) {
      m = (uint32 )tif->tif_diroff;
      if (tif->tif_flags & 128U) {
        TIFFSwabLong(& m);
      } else {

      }
      (*(tif->tif_seekproc))(tif->tif_clientdata, tif->tif_subifdoff, 0);
      tmp___0 = (*(tif->tif_writeproc))(tif->tif_clientdata, (void *)(& m),
                                        (tmsize_t )4);
      if (! (tmp___0 == 4L)) {
        TIFFErrorExt(tif->tif_clientdata, module___17,
                     "Error writing SubIFD directory link");
        return (0);
      } else {

      }
      tif->tif_nsubifd = (uint16 )((int )tif->tif_nsubifd - 1);
      if (tif->tif_nsubifd) {
        tif->tif_subifdoff += 4UL;
      } else {
        tif->tif_flags &= 4294959103U;
      }
      return (1);
    } else {
      m___0 = tif->tif_diroff;
      if (tif->tif_flags & 128U) {
        TIFFSwabLong8(& m___0);
      } else {

      }
      (*(tif->tif_seekproc))(tif->tif_clientdata, tif->tif_subifdoff, 0);
      tmp___1 = (*(tif->tif_writeproc))(tif->tif_clientdata, (void *)(& m___0),
                                        (tmsize_t )8);
      if (! (tmp___1 == 8L)) {
        TIFFErrorExt(tif->tif_clientdata, module___17,
                     "Error writing SubIFD directory link");
        return (0);
      } else {

      }
      tif->tif_nsubifd = (uint16 )((int )tif->tif_nsubifd - 1);
      if (tif->tif_nsubifd) {
        tif->tif_subifdoff += 8UL;
      } else {
        tif->tif_flags &= 4294959103U;
      }
      return (1);
    }
  } else {

  }
  if (! (tif->tif_flags & 524288U)) {
    m___1 = (uint32 )tif->tif_diroff;
    if (tif->tif_flags & 128U) {
      TIFFSwabLong(& m___1);
    } else {

    }
    if (tif->tif_header.classic.tiff_diroff == 0U) {
      tif->tif_header.classic.tiff_diroff = (uint32 )tif->tif_diroff;
      (*(tif->tif_seekproc))(tif->tif_clientdata, (uint64 )4, 0);
      tmp___2 = (*(tif->tif_writeproc))(tif->tif_clientdata, (void *)(& m___1),
                                        (tmsize_t )4);
      if (! (tmp___2 == 4L)) {
        TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                     "Error writing TIFF header");
        return (0);
      } else {

      }
      return (1);
    } else {

    }
    nextdir = tif->tif_header.classic.tiff_diroff;
    while (1) {
      tmp___3 = (*(tif->tif_seekproc))(tif->tif_clientdata, (uint64 )nextdir, 0);
      if (tmp___3 == (uint64 )nextdir) {
        tmp___4 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                         (void *)(& dircount), (tmsize_t )2);
        if (! (tmp___4 == 2L)) {
          TIFFErrorExt(tif->tif_clientdata, module___17,
                       "Error fetching directory count");
          return (0);
        } else {

        }
      } else {
        TIFFErrorExt(tif->tif_clientdata, module___17,
                     "Error fetching directory count");
        return (0);
      }
      if (tif->tif_flags & 128U) {
        TIFFSwabShort(& dircount);
      } else {

      }
      (*(tif->tif_seekproc))(tif->tif_clientdata,
                             (uint64 )((nextdir + 2U) + (uint32 )((int )dircount * 12)),
                             0);
      tmp___5 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                       (void *)(& nextnextdir), (tmsize_t )4);
      if (! (tmp___5 == 4L)) {
        TIFFErrorExt(tif->tif_clientdata, module___17,
                     "Error fetching directory link");
        return (0);
      } else {

      }
      if (tif->tif_flags & 128U) {
        TIFFSwabLong(& nextnextdir);
      } else {

      }
      if (nextnextdir == 0U) {
        (*(tif->tif_seekproc))(tif->tif_clientdata,
                               (uint64 )((nextdir + 2U) + (uint32 )((int )dircount * 12)),
                               0);
        tmp___6 = (*(tif->tif_writeproc))(tif->tif_clientdata,
                                          (void *)(& m___1), (tmsize_t )4);
        if (! (tmp___6 == 4L)) {
          TIFFErrorExt(tif->tif_clientdata, module___17,
                       "Error writing directory link");
          return (0);
        } else {

        }
        break;
      } else {

      }
      nextdir = nextnextdir;
    }
  } else {
    m___2 = tif->tif_diroff;
    if (tif->tif_flags & 128U) {
      TIFFSwabLong8(& m___2);
    } else {

    }
    if (tif->tif_header.big.tiff_diroff == 0UL) {
      tif->tif_header.big.tiff_diroff = tif->tif_diroff;
      (*(tif->tif_seekproc))(tif->tif_clientdata, (uint64 )8, 0);
      tmp___7 = (*(tif->tif_writeproc))(tif->tif_clientdata, (void *)(& m___2),
                                        (tmsize_t )8);
      if (! (tmp___7 == 8L)) {
        TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                     "Error writing TIFF header");
        return (0);
      } else {

      }
      return (1);
    } else {

    }
    nextdir___0 = tif->tif_header.big.tiff_diroff;
    while (1) {
      tmp___8 = (*(tif->tif_seekproc))(tif->tif_clientdata, nextdir___0, 0);
      if (tmp___8 == nextdir___0) {
        tmp___9 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                         (void *)(& dircount64), (tmsize_t )8);
        if (! (tmp___9 == 8L)) {
          TIFFErrorExt(tif->tif_clientdata, module___17,
                       "Error fetching directory count");
          return (0);
        } else {

        }
      } else {
        TIFFErrorExt(tif->tif_clientdata, module___17,
                     "Error fetching directory count");
        return (0);
      }
      if (tif->tif_flags & 128U) {
        TIFFSwabLong8(& dircount64);
      } else {

      }
      if (dircount64 > 65535UL) {
        TIFFErrorExt(tif->tif_clientdata, module___17,
                     "Sanity check on tag count failed, likely corrupt TIFF");
        return (0);
      } else {

      }
      dircount___0 = (uint16 )dircount64;
      (*(tif->tif_seekproc))(tif->tif_clientdata,
                             (nextdir___0 + 8UL) + (uint64 )((int )dircount___0 * 20),
                             0);
      tmp___10 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                        (void *)(& nextnextdir___0),
                                        (tmsize_t )8);
      if (! (tmp___10 == 8L)) {
        TIFFErrorExt(tif->tif_clientdata, module___17,
                     "Error fetching directory link");
        return (0);
      } else {

      }
      if (tif->tif_flags & 128U) {
        TIFFSwabLong8(& nextnextdir___0);
      } else {

      }
      if (nextnextdir___0 == 0UL) {
        (*(tif->tif_seekproc))(tif->tif_clientdata,
                               (nextdir___0 + 8UL) + (uint64 )((int )dircount___0 * 20),
                               0);
        tmp___11 = (*(tif->tif_writeproc))(tif->tif_clientdata,
                                           (void *)(& m___2), (tmsize_t )8);
        if (! (tmp___11 == 8L)) {
          TIFFErrorExt(tif->tif_clientdata, module___17,
                       "Error writing directory link");
          return (0);
        } else {

        }
        break;
      } else {

      }
      nextdir___0 = nextnextdir___0;
    }
  }
  return (1);
}
}
