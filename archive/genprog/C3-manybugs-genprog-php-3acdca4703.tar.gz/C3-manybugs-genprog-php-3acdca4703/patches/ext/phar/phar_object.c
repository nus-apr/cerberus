typedef unsigned long size_t;
typedef unsigned long __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long __ino_t;
typedef unsigned int __mode_t;
typedef unsigned long __nlink_t;
typedef long __off_t;
typedef long __off64_t;
typedef long __time_t;
typedef long __blksize_t;
typedef long __blkcnt_t;
typedef long __syscall_slong_t;
typedef __time_t time_t;
struct timespec {
   __time_t tv_sec ;
   __syscall_slong_t tv_nsec ;
};
typedef __gid_t gid_t;
typedef __mode_t mode_t;
typedef __uid_t uid_t;
typedef __off_t off_t;
typedef unsigned long ulong;
typedef unsigned int uint;
struct __anonstruct___sigset_t_9 {
   unsigned long __val[1024UL / (8UL * sizeof(unsigned long ))] ;
};
typedef struct __anonstruct___sigset_t_9 __sigset_t;
struct _IO_FILE;
struct _IO_FILE;
struct _IO_FILE;
typedef struct _IO_FILE FILE;
struct _IO_FILE;
typedef void _IO_lock_t;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
struct _IO_FILE {
   int _flags ;
   char *_IO_read_ptr ;
   char *_IO_read_end ;
   char *_IO_read_base ;
   char *_IO_write_base ;
   char *_IO_write_ptr ;
   char *_IO_write_end ;
   char *_IO_buf_base ;
   char *_IO_buf_end ;
   char *_IO_save_base ;
   char *_IO_backup_base ;
   char *_IO_save_end ;
   struct _IO_marker *_markers ;
   struct _IO_FILE *_chain ;
   int _fileno ;
   int _flags2 ;
   __off_t _old_offset ;
   unsigned short _cur_column ;
   signed char _vtable_offset ;
   char _shortbuf[1] ;
   _IO_lock_t *_lock ;
   __off64_t _offset ;
   void *__pad1 ;
   void *__pad2 ;
   void *__pad3 ;
   void *__pad4 ;
   size_t __pad5 ;
   int _mode ;
   char _unused2[(15UL * sizeof(int ) - 4UL * sizeof(void *)) - sizeof(size_t )] ;
};
typedef unsigned char zend_bool;
typedef unsigned char zend_uchar;
typedef unsigned int zend_uint;
typedef unsigned long zend_ulong;
typedef unsigned int zend_object_handle;
struct _zend_object_handlers;
struct _zend_object_handlers;
typedef struct _zend_object_handlers zend_object_handlers;
struct _zend_object_value {
   zend_object_handle handle ;
   zend_object_handlers *handlers ;
};
typedef struct _zend_object_value zend_object_value;
struct _hashtable;
struct _hashtable;
struct _hashtable;
struct bucket {
   ulong h ;
   uint nKeyLength ;
   void *pData ;
   void *pDataPtr ;
   struct bucket *pListNext ;
   struct bucket *pListLast ;
   struct bucket *pNext ;
   struct bucket *pLast ;
   char *arKey ;
};
typedef struct bucket Bucket;
struct _hashtable {
   uint nTableSize ;
   uint nTableMask ;
   uint nNumOfElements ;
   ulong nNextFreeElement ;
   Bucket *pInternalPointer ;
   Bucket *pListHead ;
   Bucket *pListTail ;
   Bucket **arBuckets ;
   void (*pDestructor)(void *pDest ) ;
   zend_bool persistent ;
   unsigned char nApplyCount ;
   zend_bool bApplyProtection ;
};
typedef struct _hashtable HashTable;
typedef Bucket *HashPosition;
struct _HashPointer {
   HashPosition pos ;
   ulong h ;
};
typedef struct _HashPointer HashPointer;
struct _zend_llist_element {
   struct _zend_llist_element *next ;
   struct _zend_llist_element *prev ;
   char data[1] ;
};
typedef struct _zend_llist_element zend_llist_element;
struct _zend_llist {
   zend_llist_element *head ;
   zend_llist_element *tail ;
   size_t count ;
   size_t size ;
   void (*dtor)(void * ) ;
   unsigned char persistent ;
   zend_llist_element *traverse_ptr ;
};
typedef struct _zend_llist zend_llist;
struct _zval_struct;
struct _zval_struct;
typedef struct _zval_struct zval;
struct _zend_class_entry;
struct _zend_class_entry;
typedef struct _zend_class_entry zend_class_entry;
struct _zend_object {
   zend_class_entry *ce ;
   HashTable *properties ;
   zval **properties_table ;
   HashTable *guards ;
};
typedef struct _zend_object zend_object;
union _zend_function;
union _zend_function;
union _zend_function;
struct _zend_property_info;
struct _zend_property_info;
struct _zend_property_info;
struct _zend_literal;
struct _zend_literal;
struct _zend_literal;
struct _zend_object_handlers {
   void (*add_ref)(zval *object ) ;
   void (*del_ref)(zval *object ) ;
   zend_object_value (*clone_obj)(zval *object ) ;
   zval *(*read_property)(zval *object , zval *member , int type ,
                          struct _zend_literal  const  *key ) ;
   void (*write_property)(zval *object , zval *member , zval *value ,
                          struct _zend_literal  const  *key ) ;
   zval *(*read_dimension)(zval *object , zval *offset , int type ) ;
   void (*write_dimension)(zval *object , zval *offset , zval *value ) ;
   zval **(*get_property_ptr_ptr)(zval *object , zval *member ,
                                  struct _zend_literal  const  *key ) ;
   zval *(*get)(zval *object ) ;
   void (*set)(zval **object , zval *value ) ;
   int (*has_property)(zval *object , zval *member , int has_set_exists ,
                       struct _zend_literal  const  *key ) ;
   void (*unset_property)(zval *object , zval *member ,
                          struct _zend_literal  const  *key ) ;
   int (*has_dimension)(zval *object , zval *member , int check_empty ) ;
   void (*unset_dimension)(zval *object , zval *offset ) ;
   HashTable *(*get_properties)(zval *object ) ;
   union _zend_function *(*get_method)(zval **object_ptr , char *method ,
                                       int method_len ,
                                       struct _zend_literal  const  *key ) ;
   int (*call_method)(char *method , int ht , zval *return_value ,
                      zval **return_value_ptr , zval *this_ptr ,
                      int return_value_used ) ;
   union _zend_function *(*get_constructor)(zval *object ) ;
   zend_class_entry *(*get_class_entry)(zval const   *object ) ;
   int (*get_class_name)(zval const   *object , char **class_name ,
                         zend_uint *class_name_len , int parent ) ;
   int (*compare_objects)(zval *object1 , zval *object2 ) ;
   int (*cast_object)(zval *readobj , zval *retval , int type ) ;
   int (*count_elements)(zval *object , long *count ) ;
   HashTable *(*get_debug_info)(zval *object , int *is_temp ) ;
   int (*get_closure)(zval *obj , zend_class_entry **ce_ptr ,
                      union _zend_function **fptr_ptr , zval **zobj_ptr ) ;
};
struct __anonstruct_str_28 {
   char *val ;
   int len ;
};
union _zvalue_value {
   long lval ;
   double dval ;
   struct __anonstruct_str_28 str ;
   HashTable *ht ;
   zend_object_value obj ;
};
typedef union _zvalue_value zvalue_value;
struct _zval_struct {
   zvalue_value value ;
   zend_uint refcount__gc ;
   zend_uchar type ;
   zend_uchar is_ref__gc ;
};
union _zend_function;
struct _zend_object_iterator;
struct _zend_object_iterator;
typedef struct _zend_object_iterator zend_object_iterator;
struct _zend_object_iterator_funcs {
   void (*dtor)(zend_object_iterator *iter ) ;
   int (*valid)(zend_object_iterator *iter ) ;
   void (*get_current_data)(zend_object_iterator *iter , zval ***data ) ;
   int (*get_current_key)(zend_object_iterator *iter , char **str_key ,
                          uint *str_key_len , ulong *int_key ) ;
   void (*move_forward)(zend_object_iterator *iter ) ;
   void (*rewind)(zend_object_iterator *iter ) ;
   void (*invalidate_current)(zend_object_iterator *iter ) ;
};
typedef struct _zend_object_iterator_funcs zend_object_iterator_funcs;
struct _zend_object_iterator {
   void *data ;
   zend_object_iterator_funcs *funcs ;
   ulong index ;
};
struct _zend_class_iterator_funcs {
   zend_object_iterator_funcs *funcs ;
   union _zend_function *zf_new_iterator ;
   union _zend_function *zf_valid ;
   union _zend_function *zf_current ;
   union _zend_function *zf_key ;
   union _zend_function *zf_next ;
   union _zend_function *zf_rewind ;
};
typedef struct _zend_class_iterator_funcs zend_class_iterator_funcs;
struct _zend_serialize_data;
struct _zend_serialize_data;
struct _zend_serialize_data;
struct _zend_unserialize_data;
struct _zend_unserialize_data;
struct _zend_unserialize_data;
typedef struct _zend_serialize_data zend_serialize_data;
typedef struct _zend_unserialize_data zend_unserialize_data;
struct _zend_trait_method_reference {
   char *method_name ;
   unsigned int mname_len ;
   zend_class_entry *ce ;
   char *class_name ;
   unsigned int cname_len ;
};
typedef struct _zend_trait_method_reference zend_trait_method_reference;
struct _zend_trait_precedence {
   zend_trait_method_reference *trait_method ;
   zend_class_entry **exclude_from_classes ;
   union _zend_function *function ;
};
typedef struct _zend_trait_precedence zend_trait_precedence;
struct _zend_trait_alias {
   zend_trait_method_reference *trait_method ;
   char *alias ;
   unsigned int alias_len ;
   zend_uint modifiers ;
   union _zend_function *function ;
};
typedef struct _zend_trait_alias zend_trait_alias;
struct __anonstruct_user_30 {
   char *filename ;
   zend_uint line_start ;
   zend_uint line_end ;
   char *doc_comment ;
   zend_uint doc_comment_len ;
};
struct _zend_function_entry;
struct _zend_function_entry;
struct _zend_module_entry;
struct _zend_module_entry;
struct __anonstruct_internal_31 {
   struct _zend_function_entry  const  *builtin_functions ;
   struct _zend_module_entry *module ;
};
union __anonunion_info_29 {
   struct __anonstruct_user_30 user ;
   struct __anonstruct_internal_31 internal ;
};
struct _zend_class_entry {
   char type ;
   char const   *name ;
   zend_uint name_length ;
   struct _zend_class_entry *parent ;
   int refcount ;
   zend_uint ce_flags ;
   HashTable function_table ;
   HashTable properties_info ;
   zval **default_properties_table ;
   zval **default_static_members_table ;
   zval **static_members_table ;
   HashTable constants_table ;
   int default_properties_count ;
   int default_static_members_count ;
   union _zend_function *constructor ;
   union _zend_function *destructor ;
   union _zend_function *clone ;
   union _zend_function *__get ;
   union _zend_function *__set ;
   union _zend_function *__unset ;
   union _zend_function *__isset ;
   union _zend_function *__call ;
   union _zend_function *__callstatic ;
   union _zend_function *__tostring ;
   union _zend_function *serialize_func ;
   union _zend_function *unserialize_func ;
   zend_class_iterator_funcs iterator_funcs ;
   zend_object_value (*create_object)(zend_class_entry *class_type ) ;
   zend_object_iterator *(*get_iterator)(zend_class_entry *ce , zval *object ,
                                         int by_ref ) ;
   int (*interface_gets_implemented)(zend_class_entry *iface ,
                                     zend_class_entry *class_type ) ;
   union _zend_function *(*get_static_method)(zend_class_entry *ce ,
                                              char *method , int method_len ) ;
   int (*serialize)(zval *object , unsigned char **buffer , zend_uint *buf_len ,
                    zend_serialize_data *data ) ;
   int (*unserialize)(zval **object , zend_class_entry *ce ,
                      unsigned char const   *buf , zend_uint buf_len ,
                      zend_unserialize_data *data ) ;
   zend_class_entry **interfaces ;
   zend_uint num_interfaces ;
   zend_class_entry **traits ;
   zend_uint num_traits ;
   zend_trait_alias **trait_aliases ;
   zend_trait_precedence **trait_precedences ;
   union __anonunion_info_29 info ;
};
enum __anonenum_zend_stream_type_32 {
    ZEND_HANDLE_FILENAME = 0,
    ZEND_HANDLE_FD = 1,
    ZEND_HANDLE_FP = 2,
    ZEND_HANDLE_STREAM = 3,
    ZEND_HANDLE_MAPPED = 4
} ;
typedef enum __anonenum_zend_stream_type_32 zend_stream_type;
struct _zend_mmap {
   size_t len ;
   size_t pos ;
   void *map ;
   char *buf ;
   void *old_handle ;
   void (*old_closer)(void *handle ) ;
};
typedef struct _zend_mmap zend_mmap;
struct _zend_stream {
   void *handle ;
   int isatty ;
   zend_mmap mmap ;
   size_t (*reader)(void *handle , char *buf , size_t len ) ;
   size_t (*fsizer)(void *handle ) ;
   void (*closer)(void *handle ) ;
};
typedef struct _zend_stream zend_stream;
union __anonunion_handle_33 {
   int fd ;
   FILE *fp ;
   zend_stream stream ;
};
struct _zend_file_handle {
   zend_stream_type type ;
   char *filename ;
   char *opened_path ;
   union __anonunion_handle_33 handle ;
   zend_bool free_filename ;
};
typedef struct _zend_file_handle zend_file_handle;
union __anonunion_u_34 {
   zval *pz ;
   zend_object_handlers *handlers ;
};
struct _gc_root_buffer {
   struct _gc_root_buffer *prev ;
   struct _gc_root_buffer *next ;
   zend_object_handle handle ;
   union __anonunion_u_34 u ;
};
typedef struct _gc_root_buffer gc_root_buffer;
struct _zval_gc_info;
union __anonunion_u_35 {
   gc_root_buffer *buffered ;
   struct _zval_gc_info *next ;
};
struct _zval_gc_info {
   zval z ;
   union __anonunion_u_35 u ;
};
typedef struct _zval_gc_info zval_gc_info;
enum __anonenum_zend_error_handling_t_36 {
    EH_NORMAL = 0,
    EH_SUPPRESS = 1,
    EH_THROW = 2
} ;
typedef enum __anonenum_zend_error_handling_t_36 zend_error_handling_t;
struct _zend_op_array;
struct _zend_op_array;
typedef struct _zend_op_array zend_op_array;
struct _zend_op;
struct _zend_op;
typedef struct _zend_op zend_op;
struct _zend_literal {
   zval constant ;
   zend_ulong hash_value ;
   zend_uint cache_slot ;
};
typedef struct _zend_literal zend_literal;
union _znode_op {
   zend_uint constant ;
   zend_uint var ;
   zend_uint num ;
   zend_ulong hash ;
   zend_uint opline_num ;
   zend_op *jmp_addr ;
   zval *zv ;
   zend_literal *literal ;
   void *ptr ;
};
typedef union _znode_op znode_op;
struct _zend_execute_data;
struct _zend_execute_data;
typedef struct _zend_execute_data zend_execute_data;
struct _zend_op {
   int (*handler)(zend_execute_data *execute_data ) ;
   znode_op op1 ;
   znode_op op2 ;
   znode_op result ;
   ulong extended_value ;
   uint lineno ;
   zend_uchar opcode ;
   zend_uchar op1_type ;
   zend_uchar op2_type ;
   zend_uchar result_type ;
};
struct _zend_brk_cont_element {
   int start ;
   int cont ;
   int brk ;
   int parent ;
};
typedef struct _zend_brk_cont_element zend_brk_cont_element;
struct _zend_try_catch_element {
   zend_uint try_op ;
   zend_uint catch_op ;
};
typedef struct _zend_try_catch_element zend_try_catch_element;
struct _zend_property_info {
   zend_uint flags ;
   char *name ;
   int name_length ;
   ulong h ;
   int offset ;
   char *doc_comment ;
   int doc_comment_len ;
   zend_class_entry *ce ;
};
typedef struct _zend_property_info zend_property_info;
struct _zend_arg_info {
   char const   *name ;
   zend_uint name_len ;
   char const   *class_name ;
   zend_uint class_name_len ;
   zend_uchar type_hint ;
   zend_bool allow_null ;
   zend_bool pass_by_reference ;
};
typedef struct _zend_arg_info zend_arg_info;
struct _zend_compiled_variable {
   char *name ;
   int name_len ;
   ulong hash_value ;
};
typedef struct _zend_compiled_variable zend_compiled_variable;
struct _zend_op_array {
   zend_uchar type ;
   char *function_name ;
   zend_class_entry *scope ;
   zend_uint fn_flags ;
   union _zend_function *prototype ;
   zend_uint num_args ;
   zend_uint required_num_args ;
   zend_arg_info *arg_info ;
   zend_uint *refcount ;
   zend_op *opcodes ;
   zend_uint last ;
   zend_compiled_variable *vars ;
   int last_var ;
   zend_uint T ;
   zend_brk_cont_element *brk_cont_array ;
   int last_brk_cont ;
   zend_try_catch_element *try_catch_array ;
   int last_try_catch ;
   HashTable *static_variables ;
   zend_uint this_var ;
   char *filename ;
   zend_uint line_start ;
   zend_uint line_end ;
   char *doc_comment ;
   zend_uint doc_comment_len ;
   zend_uint early_binding ;
   zend_literal *literals ;
   int last_literal ;
   void **run_time_cache ;
   int last_cache_slot ;
   void *reserved[4] ;
};
struct _zend_internal_function {
   zend_uchar type ;
   char *function_name ;
   zend_class_entry *scope ;
   zend_uint fn_flags ;
   union _zend_function *prototype ;
   zend_uint num_args ;
   zend_uint required_num_args ;
   zend_arg_info *arg_info ;
   void (*handler)(int ht , zval *return_value , zval **return_value_ptr ,
                   zval *this_ptr , int return_value_used ) ;
   struct _zend_module_entry *module ;
};
typedef struct _zend_internal_function zend_internal_function;
struct __anonstruct_common_39 {
   zend_uchar type ;
   char *function_name ;
   zend_class_entry *scope ;
   zend_uint fn_flags ;
   union _zend_function *prototype ;
   zend_uint num_args ;
   zend_uint required_num_args ;
   zend_arg_info *arg_info ;
};
union _zend_function {
   zend_uchar type ;
   struct __anonstruct_common_39 common ;
   zend_op_array op_array ;
   zend_internal_function internal_function ;
};
typedef union _zend_function zend_function;
struct _zend_function_state {
   zend_function *function ;
   void **arguments ;
};
typedef struct _zend_function_state zend_function_state;
union _temp_variable;
union _temp_variable;
union _temp_variable;
struct _zend_execute_data {
   struct _zend_op *opline ;
   zend_function_state function_state ;
   zend_function *fbc ;
   zend_class_entry *called_scope ;
   zend_op_array *op_array ;
   zval *object ;
   union _temp_variable *Ts ;
   zval ***CVs ;
   HashTable *symbol_table ;
   struct _zend_execute_data *prev_execute_data ;
   zval *old_error_reporting ;
   zend_bool nested ;
   zval **original_return_value ;
   zend_class_entry *current_scope ;
   zend_class_entry *current_called_scope ;
   zval *current_this ;
   zval *current_object ;
};
typedef long __jmp_buf[8];
struct __jmp_buf_tag {
   __jmp_buf __jmpbuf ;
   int __mask_was_saved ;
   __sigset_t __saved_mask ;
};
typedef struct __jmp_buf_tag jmp_buf[1];
struct _zend_executor_globals;
struct _zend_executor_globals;
typedef struct _zend_executor_globals zend_executor_globals;
struct _zend_stack {
   int top ;
   int max ;
   void **elements ;
};
typedef struct _zend_stack zend_stack;
struct _zend_ptr_stack {
   int top ;
   int max ;
   void **elements ;
   void **top_element ;
   zend_bool persistent ;
};
typedef struct _zend_ptr_stack zend_ptr_stack;
struct _store_object {
   void *object ;
   void (*dtor)(void *object , zend_object_handle handle ) ;
   void (*free_storage)(void *object ) ;
   void (*clone)(void *object , void **object_clone ) ;
   zend_object_handlers const   *handlers ;
   zend_uint refcount ;
   gc_root_buffer *buffered ;
};
struct __anonstruct_free_list_40 {
   int next ;
};
union _store_bucket {
   struct _store_object obj ;
   struct __anonstruct_free_list_40 free_list ;
};
struct _zend_object_store_bucket {
   zend_bool destructor_called ;
   zend_bool valid ;
   union _store_bucket bucket ;
};
typedef struct _zend_object_store_bucket zend_object_store_bucket;
struct _zend_objects_store {
   zend_object_store_bucket *object_buckets ;
   zend_uint top ;
   zend_uint size ;
   int free_list_head ;
};
typedef struct _zend_objects_store zend_objects_store;
typedef unsigned short fpu_control_t;
struct _zend_vm_stack;
struct _zend_vm_stack;
typedef struct _zend_vm_stack *zend_vm_stack;
struct _zend_ini_entry;
struct _zend_ini_entry;
typedef struct _zend_ini_entry zend_ini_entry;
struct _zend_executor_globals {
   zval **return_value_ptr_ptr ;
   zval uninitialized_zval ;
   zval *uninitialized_zval_ptr ;
   zval error_zval ;
   zval *error_zval_ptr ;
   zend_ptr_stack arg_types_stack ;
   HashTable *symtable_cache[32] ;
   HashTable **symtable_cache_limit ;
   HashTable **symtable_cache_ptr ;
   zend_op **opline_ptr ;
   HashTable *active_symbol_table ;
   HashTable symbol_table ;
   HashTable included_files ;
   jmp_buf *bailout ;
   int error_reporting ;
   int orig_error_reporting ;
   int exit_status ;
   zend_op_array *active_op_array ;
   HashTable *function_table ;
   HashTable *class_table ;
   HashTable *zend_constants ;
   zend_class_entry *scope ;
   zend_class_entry *called_scope ;
   zval *This ;
   long precision ;
   int ticks_count ;
   zend_bool in_execution ;
   HashTable *in_autoload ;
   zend_function *autoload_func ;
   zend_bool full_tables_cleanup ;
   zend_bool no_extensions ;
   HashTable regular_list ;
   HashTable persistent_list ;
   zend_vm_stack argument_stack ;
   int user_error_handler_error_reporting ;
   zval *user_error_handler ;
   zval *user_exception_handler ;
   zend_stack user_error_handlers_error_reporting ;
   zend_ptr_stack user_error_handlers ;
   zend_ptr_stack user_exception_handlers ;
   zend_error_handling_t error_handling ;
   zend_class_entry *exception_class ;
   int timeout_seconds ;
   int lambda_count ;
   HashTable *ini_directives ;
   HashTable *modified_ini_directives ;
   zend_ini_entry *error_reporting_ini_entry ;
   zend_objects_store objects_store ;
   zval *exception ;
   zval *prev_exception ;
   zend_op *opline_before_exception ;
   zend_op exception_op[3] ;
   struct _zend_execute_data *current_execute_data ;
   struct _zend_module_entry *current_module ;
   zend_property_info std_property_info ;
   zend_bool active ;
   zend_op *start_op ;
   void *saved_fpu_cw_ptr ;
   fpu_control_t saved_fpu_cw ;
   void *reserved[4] ;
};
struct _zend_ini_entry;
typedef struct _zend_module_entry zend_module_entry;
struct _zend_module_dep;
struct _zend_module_dep;
struct _zend_module_entry {
   unsigned short size ;
   unsigned int zend_api ;
   unsigned char zend_debug ;
   unsigned char zts ;
   struct _zend_ini_entry  const  *ini_entry ;
   struct _zend_module_dep  const  *deps ;
   char const   *name ;
   struct _zend_function_entry  const  *functions ;
   int (*module_startup_func)(int type , int module_number ) ;
   int (*module_shutdown_func)(int type , int module_number ) ;
   int (*request_startup_func)(int type , int module_number ) ;
   int (*request_shutdown_func)(int type , int module_number ) ;
   void (*info_func)(zend_module_entry *zend_module ) ;
   char const   *version ;
   size_t globals_size ;
   void *globals_ptr ;
   void (*globals_ctor)(void *global ) ;
   void (*globals_dtor)(void *global ) ;
   int (*post_deactivate_func)(void) ;
   int module_started ;
   unsigned char type ;
   void *handle ;
   int module_number ;
   char const   *build_id ;
};
struct _zend_module_dep {
   char const   *name ;
   char const   *rel ;
   char const   *version ;
   unsigned char type ;
};
struct __anonstruct_var_41 {
   zval **ptr_ptr ;
   zval *ptr ;
   zend_bool fcall_returned_reference ;
};
struct __anonstruct_str_offset_42 {
   zval **ptr_ptr ;
   zval *str ;
   zend_uint offset ;
};
struct __anonstruct_fe_43 {
   zval **ptr_ptr ;
   zval *ptr ;
   HashPointer fe_pos ;
};
union _temp_variable {
   zval tmp_var ;
   struct __anonstruct_var_41 var ;
   struct __anonstruct_str_offset_42 str_offset ;
   struct __anonstruct_fe_43 fe ;
   zend_class_entry *class_entry ;
};
struct _zend_vm_stack {
   void **top ;
   void **end ;
   zend_vm_stack prev ;
};
struct _zend_function_entry {
   char const   *fname ;
   void (*handler)(int ht , zval *return_value , zval **return_value_ptr ,
                   zval *this_ptr , int return_value_used ) ;
   struct _zend_arg_info  const  *arg_info ;
   zend_uint num_args ;
   zend_uint flags ;
};
typedef struct _zend_function_entry zend_function_entry;
struct _zend_fcall_info {
   size_t size ;
   HashTable *function_table ;
   zval *function_name ;
   HashTable *symbol_table ;
   zval **retval_ptr_ptr ;
   zend_uint param_count ;
   zval ***params ;
   zval *object_ptr ;
   zend_bool no_separation ;
};
typedef struct _zend_fcall_info zend_fcall_info;
struct _zend_fcall_info_cache {
   zend_bool initialized ;
   zend_function *function_handler ;
   zend_class_entry *calling_scope ;
   zend_class_entry *called_scope ;
   zval *object_ptr ;
};
typedef struct _zend_fcall_info_cache zend_fcall_info_cache;
struct stat {
   __dev_t st_dev ;
   __ino_t st_ino ;
   __nlink_t st_nlink ;
   __mode_t st_mode ;
   __uid_t st_uid ;
   __gid_t st_gid ;
   int __pad0 ;
   __dev_t st_rdev ;
   __off_t st_size ;
   __blksize_t st_blksize ;
   __blkcnt_t st_blocks ;
   struct timespec st_atim ;
   struct timespec st_mtim ;
   struct timespec st_ctim ;
   __syscall_slong_t __glibc_reserved[3] ;
};
struct _php_stream;
struct _php_stream;
typedef struct _php_stream php_stream;
struct _php_stream_wrapper;
struct _php_stream_wrapper;
typedef struct _php_stream_wrapper php_stream_wrapper;
struct _php_stream_context;
struct _php_stream_context;
typedef struct _php_stream_context php_stream_context;
struct _php_stream_filter;
struct _php_stream_filter;
typedef struct _php_stream_filter php_stream_filter;
struct _php_stream_notifier;
struct _php_stream_notifier;
typedef struct _php_stream_notifier php_stream_notifier;
struct _php_stream_notifier {
   void (*func)(php_stream_context *context , int notifycode , int severity ,
                char *xmsg , int xcode , size_t bytes_sofar , size_t bytes_max ,
                void *ptr ) ;
   void (*dtor)(php_stream_notifier *notifier ) ;
   void *ptr ;
   int mask ;
   size_t progress ;
   size_t progress_max ;
};
struct _php_stream_context {
   php_stream_notifier *notifier ;
   zval *options ;
   zval *links ;
   int rsrc_id ;
};
struct _php_stream_bucket;
struct _php_stream_bucket;
typedef struct _php_stream_bucket php_stream_bucket;
struct _php_stream_bucket_brigade;
struct _php_stream_bucket_brigade;
typedef struct _php_stream_bucket_brigade php_stream_bucket_brigade;
struct _php_stream_bucket {
   php_stream_bucket *next ;
   php_stream_bucket *prev ;
   php_stream_bucket_brigade *brigade ;
   char *buf ;
   size_t buflen ;
   int own_buf ;
   int is_persistent ;
   int refcount ;
};
struct _php_stream_bucket_brigade {
   php_stream_bucket *head ;
   php_stream_bucket *tail ;
};
enum __anonenum_php_stream_filter_status_t_75 {
    PSFS_ERR_FATAL = 0,
    PSFS_FEED_ME = 1,
    PSFS_PASS_ON = 2
} ;
typedef enum __anonenum_php_stream_filter_status_t_75 php_stream_filter_status_t;
struct _php_stream_filter_ops {
   php_stream_filter_status_t (*filter)(php_stream *stream ,
                                        php_stream_filter *thisfilter ,
                                        php_stream_bucket_brigade *buckets_in ,
                                        php_stream_bucket_brigade *buckets_out ,
                                        size_t *bytes_consumed , int flags ) ;
   void (*dtor)(php_stream_filter *thisfilter ) ;
   char const   *label ;
};
typedef struct _php_stream_filter_ops php_stream_filter_ops;
struct _php_stream_filter_chain {
   php_stream_filter *head ;
   php_stream_filter *tail ;
   php_stream *stream ;
};
typedef struct _php_stream_filter_chain php_stream_filter_chain;
struct _php_stream_filter {
   php_stream_filter_ops *fops ;
   void *abstract ;
   php_stream_filter *next ;
   php_stream_filter *prev ;
   int is_persistent ;
   php_stream_filter_chain *chain ;
   php_stream_bucket_brigade buffer ;
   int rsrc_id ;
};
struct _php_stream_statbuf {
   struct stat sb ;
};
typedef struct _php_stream_statbuf php_stream_statbuf;
struct _php_stream_dirent {
   char d_name[4096] ;
};
typedef struct _php_stream_dirent php_stream_dirent;
struct _php_stream_ops {
   size_t (*write)(php_stream *stream , char const   *buf , size_t count ) ;
   size_t (*read)(php_stream *stream , char *buf , size_t count ) ;
   int (*close)(php_stream *stream , int close_handle ) ;
   int (*flush)(php_stream *stream ) ;
   char const   *label ;
   int (*seek)(php_stream *stream , off_t offset , int whence ,
               off_t *newoffset ) ;
   int (*cast)(php_stream *stream , int castas , void **ret ) ;
   int (*stat)(php_stream *stream , php_stream_statbuf *ssb ) ;
   int (*set_option)(php_stream *stream , int option , int value ,
                     void *ptrparam ) ;
};
typedef struct _php_stream_ops php_stream_ops;
struct _php_stream_wrapper_ops {
   php_stream *(*stream_opener)(php_stream_wrapper *wrapper , char *filename ,
                                char *mode , int options , char **opened_path ,
                                php_stream_context *context ) ;
   int (*stream_closer)(php_stream_wrapper *wrapper , php_stream *stream ) ;
   int (*stream_stat)(php_stream_wrapper *wrapper , php_stream *stream ,
                      php_stream_statbuf *ssb ) ;
   int (*url_stat)(php_stream_wrapper *wrapper , char *url , int flags ,
                   php_stream_statbuf *ssb , php_stream_context *context ) ;
   php_stream *(*dir_opener)(php_stream_wrapper *wrapper , char *filename ,
                             char *mode , int options , char **opened_path ,
                             php_stream_context *context ) ;
   char const   *label ;
   int (*unlink)(php_stream_wrapper *wrapper , char *url , int options ,
                 php_stream_context *context ) ;
   int (*rename)(php_stream_wrapper *wrapper , char *url_from , char *url_to ,
                 int options , php_stream_context *context ) ;
   int (*stream_mkdir)(php_stream_wrapper *wrapper , char *url , int mode ,
                       int options , php_stream_context *context ) ;
   int (*stream_rmdir)(php_stream_wrapper *wrapper , char *url , int options ,
                       php_stream_context *context ) ;
};
typedef struct _php_stream_wrapper_ops php_stream_wrapper_ops;
struct _php_stream_wrapper {
   php_stream_wrapper_ops *wops ;
   void *abstract ;
   int is_url ;
   int err_count ;
   char **err_stack ;
};
struct _php_stream {
   php_stream_ops *ops ;
   void *abstract ;
   php_stream_filter_chain readfilters ;
   php_stream_filter_chain writefilters ;
   php_stream_wrapper *wrapper ;
   void *wrapperthis ;
   zval *wrapperdata ;
   int fgetss_state ;
   int is_persistent ;
   char mode[16] ;
   int rsrc_id ;
   int in_free ;
   int fclose_stdiocast ;
   FILE *stdiocast ;
   char *orig_path ;
   php_stream_context *context ;
   int flags ;
   off_t position ;
   unsigned char *readbuf ;
   size_t readbuflen ;
   off_t readpos ;
   off_t writepos ;
   size_t chunk_size ;
   int eof ;
   struct _php_stream *enclosing_stream ;
};
struct _php_core_globals;
struct _php_core_globals;
struct _arg_separators {
   char *output ;
   char *input ;
};
typedef struct _arg_separators arg_separators;
struct _php_core_globals {
   zend_bool magic_quotes_gpc ;
   zend_bool magic_quotes_runtime ;
   zend_bool magic_quotes_sybase ;
   zend_bool implicit_flush ;
   long output_buffering ;
   zend_bool sql_safe_mode ;
   zend_bool enable_dl ;
   char *output_handler ;
   char *unserialize_callback_func ;
   long serialize_precision ;
   long memory_limit ;
   long max_input_time ;
   zend_bool track_errors ;
   zend_bool display_errors ;
   zend_bool display_startup_errors ;
   zend_bool log_errors ;
   long log_errors_max_len ;
   zend_bool ignore_repeated_errors ;
   zend_bool ignore_repeated_source ;
   zend_bool report_memleaks ;
   char *error_log ;
   char *doc_root ;
   char *user_dir ;
   char *include_path ;
   char *open_basedir ;
   char *extension_dir ;
   char *upload_tmp_dir ;
   long upload_max_filesize ;
   char *error_append_string ;
   char *error_prepend_string ;
   char *auto_prepend_file ;
   char *auto_append_file ;
   arg_separators arg_separator ;
   char *variables_order ;
   HashTable rfc1867_protected_variables ;
   short connection_status ;
   short ignore_user_abort ;
   unsigned char header_is_being_sent ;
   zend_llist tick_functions ;
   zval *http_globals[6] ;
   zend_bool expose_php ;
   zend_bool register_argc_argv ;
   zend_bool auto_globals_jit ;
   char *docref_root ;
   char *docref_ext ;
   zend_bool html_errors ;
   zend_bool xmlrpc_errors ;
   long xmlrpc_error_number ;
   zend_bool activated_auto_globals[8] ;
   zend_bool modules_activated ;
   zend_bool file_uploads ;
   zend_bool during_request_startup ;
   zend_bool allow_url_fopen ;
   zend_bool enable_post_data_reading ;
   zend_bool always_populate_raw_post_data ;
   zend_bool report_zend_debug ;
   int last_error_type ;
   char *last_error_message ;
   char *last_error_file ;
   int last_error_lineno ;
   char *disable_functions ;
   char *disable_classes ;
   zend_bool allow_url_include ;
   zend_bool exit_on_timeout ;
   long max_input_nesting_level ;
   zend_bool in_user_include ;
   char *user_ini_filename ;
   long user_ini_cache_ttl ;
   char *request_order ;
   zend_bool mail_x_header ;
   char *mail_log ;
   zend_bool in_error_log ;
};
struct _zend_ini_entry {
   int module_number ;
   int modifiable ;
   char *name ;
   uint name_length ;
   int (*on_modify)(zend_ini_entry *entry , char *new_value ,
                    uint new_value_length , void *mh_arg1 , void *mh_arg2 ,
                    void *mh_arg3 , int stage ) ;
   void *mh_arg1 ;
   void *mh_arg2 ;
   void *mh_arg3 ;
   char *value ;
   uint value_length ;
   char *orig_value ;
   uint orig_value_length ;
   int orig_modifiable ;
   int modified ;
   void (*displayer)(zend_ini_entry *ini_entry , int type ) ;
};
struct __anonstruct_sapi_header_struct_91 {
   char *header ;
   uint header_len ;
};
typedef struct __anonstruct_sapi_header_struct_91 sapi_header_struct;
struct __anonstruct_sapi_headers_struct_92 {
   zend_llist headers ;
   int http_response_code ;
   unsigned char send_default_content_type ;
   char *mimetype ;
   char *http_status_line ;
};
typedef struct __anonstruct_sapi_headers_struct_92 sapi_headers_struct;
struct _sapi_post_entry;
struct _sapi_post_entry;
typedef struct _sapi_post_entry sapi_post_entry;
struct _sapi_module_struct;
struct _sapi_module_struct;
typedef struct _sapi_module_struct sapi_module_struct;
struct __anonstruct_sapi_request_info_93 {
   char const   *request_method ;
   char *query_string ;
   char *post_data ;
   char *raw_post_data ;
   char *cookie_data ;
   long content_length ;
   uint post_data_length ;
   uint raw_post_data_length ;
   char *path_translated ;
   char *request_uri ;
   char const   *content_type ;
   zend_bool headers_only ;
   zend_bool no_headers ;
   zend_bool headers_read ;
   sapi_post_entry *post_entry ;
   char *content_type_dup ;
   char *auth_user ;
   char *auth_password ;
   char *auth_digest ;
   char *argv0 ;
   char *current_user ;
   int current_user_length ;
   int argc ;
   char **argv ;
   int proto_num ;
};
typedef struct __anonstruct_sapi_request_info_93 sapi_request_info;
struct _sapi_globals_struct {
   void *server_context ;
   sapi_request_info request_info ;
   sapi_headers_struct sapi_headers ;
   int read_post_bytes ;
   unsigned char headers_sent ;
   struct stat global_stat ;
   char *default_mimetype ;
   char *default_charset ;
   HashTable *rfc1867_uploaded_files ;
   long post_max_size ;
   int options ;
   zend_bool sapi_started ;
   double global_request_time ;
   HashTable known_post_content_types ;
   zval *callback_func ;
   zend_fcall_info_cache fci_cache ;
   zend_bool callback_run ;
};
typedef struct _sapi_globals_struct sapi_globals_struct;
struct __anonstruct_sapi_header_line_94 {
   char *line ;
   uint line_len ;
   long response_code ;
};
typedef struct __anonstruct_sapi_header_line_94 sapi_header_line;
enum __anonenum_sapi_header_op_enum_95 {
    SAPI_HEADER_REPLACE = 0,
    SAPI_HEADER_ADD = 1,
    SAPI_HEADER_DELETE = 2,
    SAPI_HEADER_DELETE_ALL = 3,
    SAPI_HEADER_SET_STATUS = 4
} ;
typedef enum __anonenum_sapi_header_op_enum_95 sapi_header_op_enum;
struct _sapi_module_struct {
   char *name ;
   char *pretty_name ;
   int (*startup)(struct _sapi_module_struct *sapi_module ) ;
   int (*shutdown)(struct _sapi_module_struct *sapi_module ) ;
   int (*activate)(void) ;
   int (*deactivate)(void) ;
   int (*ub_write)(char const   *str , unsigned int str_length ) ;
   void (*flush)(void *server_context ) ;
   struct stat *(*get_stat)(void) ;
   char *(*getenv)(char *name , size_t name_len ) ;
   void (*sapi_error)(int type , char const   *error_msg  , ...) ;
   int (*header_handler)(sapi_header_struct *sapi_header ,
                         sapi_header_op_enum op ,
                         sapi_headers_struct *sapi_headers ) ;
   int (*send_headers)(sapi_headers_struct *sapi_headers ) ;
   void (*send_header)(sapi_header_struct *sapi_header , void *server_context ) ;
   int (*read_post)(char *buffer , uint count_bytes ) ;
   char *(*read_cookies)(void) ;
   void (*register_server_variables)(zval *track_vars_array ) ;
   void (*log_message)(char *message ) ;
   time_t (*get_request_time)(void) ;
   void (*terminate_process)(void) ;
   char *php_ini_path_override ;
   void (*block_interruptions)(void) ;
   void (*unblock_interruptions)(void) ;
   void (*default_post_reader)(void) ;
   void (*treat_data)(int arg , char *str , zval *destArray ) ;
   char *executable_location ;
   int php_ini_ignore ;
   int php_ini_ignore_cwd ;
   int (*get_fd)(int *fd ) ;
   int (*force_http_10)(void) ;
   int (*get_target_uid)(uid_t * ) ;
   int (*get_target_gid)(gid_t * ) ;
   unsigned int (*input_filter)(int arg , char *var , char **val ,
                                unsigned int val_len ,
                                unsigned int *new_val_len ) ;
   void (*ini_defaults)(HashTable *configuration_hash ) ;
   int phpinfo_as_text ;
   char *ini_entries ;
   zend_function_entry const   *additional_functions ;
   unsigned int (*input_filter_init)(void) ;
};
struct _sapi_post_entry {
   char *content_type ;
   uint content_type_len ;
   void (*post_reader)(void) ;
   void (*post_handler)(char *content_type_dup , void *arg ) ;
};
typedef int php_stat_len;
struct _zend_syntax_highlighter_ini {
   char *highlight_html ;
   char *highlight_comment ;
   char *highlight_default ;
   char *highlight_string ;
   char *highlight_keyword ;
};
typedef struct _zend_syntax_highlighter_ini zend_syntax_highlighter_ini;
struct __anonstruct_smart_str_96 {
   char *c ;
   size_t len ;
   size_t a ;
};
typedef struct __anonstruct_smart_str_96 smart_str;
struct __anonstruct_url_adapt_state_ex_t_97 {
   smart_str tag ;
   smart_str arg ;
   smart_str val ;
   smart_str buf ;
   smart_str result ;
   smart_str form_app ;
   smart_str url_app ;
   int active ;
   char *lookup_data ;
   int state ;
   HashTable *tags ;
};
typedef struct __anonstruct_url_adapt_state_ex_t_97 url_adapt_state_ex_t;
typedef unsigned int php_uint32;
struct __anonstruct_serialize_98 {
   void *var_hash ;
   unsigned int level ;
};
struct __anonstruct_unserialize_99 {
   void *var_hash ;
   unsigned int level ;
};
struct _php_basic_globals {
   HashTable *user_shutdown_function_names ;
   HashTable putenv_ht ;
   zval *strtok_zval ;
   char *strtok_string ;
   char *locale_string ;
   char *strtok_last ;
   char strtok_table[256] ;
   ulong strtok_len ;
   char str_ebuf[40] ;
   zend_fcall_info array_walk_fci ;
   zend_fcall_info_cache array_walk_fci_cache ;
   zend_fcall_info user_compare_fci ;
   zend_fcall_info_cache user_compare_fci_cache ;
   zend_llist *user_tick_functions ;
   zval *active_ini_file_section ;
   long page_uid ;
   long page_gid ;
   long page_inode ;
   time_t page_mtime ;
   char *CurrentStatFile ;
   char *CurrentLStatFile ;
   php_stream_statbuf ssb ;
   php_stream_statbuf lssb ;
   php_uint32 state[625] ;
   php_uint32 *next ;
   int left ;
   unsigned int rand_seed ;
   zend_bool rand_is_seeded ;
   zend_bool mt_rand_is_seeded ;
   char *syslog_device ;
   zend_class_entry *incomplete_class ;
   struct __anonstruct_serialize_98 serialize ;
   struct __anonstruct_unserialize_99 unserialize ;
   url_adapt_state_ex_t url_adapt_state_ex ;
   void *mmap_file ;
   size_t mmap_len ;
   HashTable *user_filter_map ;
   int umask ;
};
typedef struct _php_basic_globals php_basic_globals;
enum __anonenum_SPL_FS_OBJ_TYPE_117 {
    SPL_FS_INFO = 0,
    SPL_FS_DIR = 1,
    SPL_FS_FILE = 2
} ;
typedef enum __anonenum_SPL_FS_OBJ_TYPE_117 SPL_FS_OBJ_TYPE;
struct _spl_filesystem_object;
struct _spl_filesystem_object;
typedef struct _spl_filesystem_object spl_filesystem_object;
struct _spl_other_handler {
   void (*dtor)(spl_filesystem_object *object ) ;
   void (*clone)(spl_filesystem_object *src , spl_filesystem_object *dst ) ;
};
typedef struct _spl_other_handler spl_other_handler;
struct __anonstruct_spl_filesystem_iterator_118 {
   zend_object_iterator intern ;
   zval *current ;
   spl_filesystem_object *object ;
};
typedef struct __anonstruct_spl_filesystem_iterator_118 spl_filesystem_iterator;
struct __anonstruct_dir_120 {
   php_stream *dirp ;
   php_stream_dirent entry ;
   char *sub_path ;
   int sub_path_len ;
   int index ;
   int is_recursive ;
   zend_function *func_rewind ;
   zend_function *func_next ;
   zend_function *func_valid ;
};
struct __anonstruct_file_121 {
   php_stream *stream ;
   php_stream_context *context ;
   zval *zcontext ;
   char *open_mode ;
   int open_mode_len ;
   zval *current_zval ;
   char *current_line ;
   size_t current_line_len ;
   size_t max_line_len ;
   long current_line_num ;
   zval zresource ;
   zend_function *func_getCurr ;
   char delimiter ;
   char enclosure ;
   char escape ;
};
union __anonunion_u_119 {
   struct __anonstruct_dir_120 dir ;
   struct __anonstruct_file_121 file ;
};
struct _spl_filesystem_object {
   zend_object std ;
   void *oth ;
   spl_other_handler *oth_handler ;
   char *_path ;
   int _path_len ;
   char *orig_path ;
   char *file_name ;
   int file_name_len ;
   SPL_FS_OBJ_TYPE type ;
   long flags ;
   zend_class_entry *file_class ;
   zend_class_entry *info_class ;
   union __anonunion_u_119 u ;
   spl_filesystem_iterator it ;
};
struct _phar_entry_fp;
struct _phar_entry_fp;
typedef struct _phar_entry_fp phar_entry_fp;
struct _phar_archive_data;
struct _phar_archive_data;
typedef struct _phar_archive_data phar_archive_data;
struct _zend_phar_globals {
   HashTable phar_persist_map ;
   HashTable phar_fname_map ;
   phar_entry_fp *cached_fp ;
   HashTable phar_alias_map ;
   int phar_SERVER_mung_list ;
   int readonly ;
   char *cache_list ;
   int manifest_cached ;
   int persist ;
   int has_zlib ;
   int has_bz2 ;
   zend_bool readonly_orig ;
   zend_bool require_hash_orig ;
   zend_bool intercepted ;
   int request_init ;
   int require_hash ;
   int request_done ;
   int request_ends ;
   void (*orig_fopen)(int ht , zval *return_value , zval **return_value_ptr ,
                      zval *this_ptr , int return_value_used ) ;
   void (*orig_file_get_contents)(int ht , zval *return_value ,
                                  zval **return_value_ptr , zval *this_ptr ,
                                  int return_value_used ) ;
   void (*orig_is_file)(int ht , zval *return_value , zval **return_value_ptr ,
                        zval *this_ptr , int return_value_used ) ;
   void (*orig_is_link)(int ht , zval *return_value , zval **return_value_ptr ,
                        zval *this_ptr , int return_value_used ) ;
   void (*orig_is_dir)(int ht , zval *return_value , zval **return_value_ptr ,
                       zval *this_ptr , int return_value_used ) ;
   void (*orig_opendir)(int ht , zval *return_value , zval **return_value_ptr ,
                        zval *this_ptr , int return_value_used ) ;
   void (*orig_file_exists)(int ht , zval *return_value ,
                            zval **return_value_ptr , zval *this_ptr ,
                            int return_value_used ) ;
   void (*orig_fileperms)(int ht , zval *return_value ,
                          zval **return_value_ptr , zval *this_ptr ,
                          int return_value_used ) ;
   void (*orig_fileinode)(int ht , zval *return_value ,
                          zval **return_value_ptr , zval *this_ptr ,
                          int return_value_used ) ;
   void (*orig_filesize)(int ht , zval *return_value , zval **return_value_ptr ,
                         zval *this_ptr , int return_value_used ) ;
   void (*orig_fileowner)(int ht , zval *return_value ,
                          zval **return_value_ptr , zval *this_ptr ,
                          int return_value_used ) ;
   void (*orig_filegroup)(int ht , zval *return_value ,
                          zval **return_value_ptr , zval *this_ptr ,
                          int return_value_used ) ;
   void (*orig_fileatime)(int ht , zval *return_value ,
                          zval **return_value_ptr , zval *this_ptr ,
                          int return_value_used ) ;
   void (*orig_filemtime)(int ht , zval *return_value ,
                          zval **return_value_ptr , zval *this_ptr ,
                          int return_value_used ) ;
   void (*orig_filectime)(int ht , zval *return_value ,
                          zval **return_value_ptr , zval *this_ptr ,
                          int return_value_used ) ;
   void (*orig_filetype)(int ht , zval *return_value , zval **return_value_ptr ,
                         zval *this_ptr , int return_value_used ) ;
   void (*orig_is_writable)(int ht , zval *return_value ,
                            zval **return_value_ptr , zval *this_ptr ,
                            int return_value_used ) ;
   void (*orig_is_readable)(int ht , zval *return_value ,
                            zval **return_value_ptr , zval *this_ptr ,
                            int return_value_used ) ;
   void (*orig_is_executable)(int ht , zval *return_value ,
                              zval **return_value_ptr , zval *this_ptr ,
                              int return_value_used ) ;
   void (*orig_lstat)(int ht , zval *return_value , zval **return_value_ptr ,
                      zval *this_ptr , int return_value_used ) ;
   void (*orig_readfile)(int ht , zval *return_value , zval **return_value_ptr ,
                         zval *this_ptr , int return_value_used ) ;
   void (*orig_stat)(int ht , zval *return_value , zval **return_value_ptr ,
                     zval *this_ptr , int return_value_used ) ;
   char *cwd ;
   int cwd_len ;
   int cwd_init ;
   char *openssl_privatekey ;
   int openssl_privatekey_len ;
   char *last_phar_name ;
   int last_phar_name_len ;
   char *last_alias ;
   int last_alias_len ;
   phar_archive_data *last_phar ;
   HashTable mime_types ;
};
typedef struct _zend_phar_globals zend_phar_globals;
union _phar_archive_object;
union _phar_archive_object;
typedef union _phar_archive_object phar_archive_object;
union _phar_entry_object;
union _phar_entry_object;
typedef union _phar_entry_object phar_entry_object;
enum phar_fp_type {
    PHAR_FP = 0,
    PHAR_UFP = 1,
    PHAR_MOD = 2,
    PHAR_TMP = 3
} ;
struct _phar_entry_info {
   php_uint32 uncompressed_filesize ;
   php_uint32 timestamp ;
   php_uint32 compressed_filesize ;
   php_uint32 crc32 ;
   php_uint32 flags ;
   php_uint32 old_flags ;
   zval *metadata ;
   int metadata_len ;
   php_uint32 filename_len ;
   char *filename ;
   enum phar_fp_type fp_type ;
   long offset_abs ;
   long offset ;
   long header_offset ;
   php_stream *fp ;
   php_stream *cfp ;
   int fp_refcount ;
   char *tmp ;
   phar_archive_data *phar ;
   smart_str metadata_str ;
   char *link ;
   char tar_type ;
   uint manifest_pos ;
   unsigned short inode ;
   unsigned int is_crc_checked : 1 ;
   unsigned int is_modified : 1 ;
   unsigned int is_deleted : 1 ;
   unsigned int is_dir : 1 ;
   unsigned int is_mounted : 1 ;
   unsigned int is_temp_dir : 1 ;
   unsigned int is_tar : 1 ;
   unsigned int is_zip : 1 ;
   unsigned int is_persistent : 1 ;
};
typedef struct _phar_entry_info phar_entry_info;
struct _phar_archive_data {
   char *fname ;
   int fname_len ;
   char *ext ;
   int ext_len ;
   char *alias ;
   int alias_len ;
   char version[12] ;
   size_t internal_file_start ;
   size_t halt_offset ;
   HashTable manifest ;
   HashTable virtual_dirs ;
   HashTable mounted_dirs ;
   php_uint32 flags ;
   php_uint32 min_timestamp ;
   php_uint32 max_timestamp ;
   php_stream *fp ;
   php_stream *ufp ;
   int refcount ;
   php_uint32 sig_flags ;
   int sig_len ;
   char *signature ;
   zval *metadata ;
   int metadata_len ;
   uint phar_pos ;
   unsigned int is_temporary_alias : 1 ;
   unsigned int is_modified : 1 ;
   unsigned int is_writeable : 1 ;
   unsigned int is_brandnew : 1 ;
   unsigned int donotflush : 1 ;
   unsigned int is_zip : 1 ;
   unsigned int is_tar : 1 ;
   unsigned int is_data : 1 ;
   unsigned int is_persistent : 1 ;
};
struct _phar_entry_fp_info {
   enum phar_fp_type fp_type ;
   long offset ;
};
typedef struct _phar_entry_fp_info phar_entry_fp_info;
struct _phar_entry_fp {
   php_stream *fp ;
   php_stream *ufp ;
   phar_entry_fp_info *manifest ;
};
struct _phar_mime_type {
   char *mime ;
   int len ;
   char type ;
};
typedef struct _phar_mime_type phar_mime_type;
struct _phar_entry_data {
   phar_archive_data *phar ;
   php_stream *fp ;
   off_t position ;
   off_t zero ;
   int for_write : 1 ;
   int is_zip : 1 ;
   int is_tar : 1 ;
   phar_entry_info *internal_file ;
};
typedef struct _phar_entry_data phar_entry_data;
struct __anonstruct_arc_126 {
   zend_object std ;
   phar_archive_data *archive ;
};
union _phar_archive_object {
   zend_object std ;
   spl_filesystem_object spl ;
   struct __anonstruct_arc_126 arc ;
};
struct __anonstruct_ent_127 {
   zend_object std ;
   phar_entry_info *entry ;
};
union _phar_entry_object {
   zend_object std ;
   spl_filesystem_object spl ;
   struct __anonstruct_ent_127 ent ;
};
typedef char *phar_zstr;
enum __anonenum_phar_path_check_result_128 {
    pcr_use_query = 0,
    pcr_is_ok = 1,
    pcr_err_double_slash = 2,
    pcr_err_up_dir = 3,
    pcr_err_curr_dir = 4,
    pcr_err_back_slash = 5,
    pcr_err_star = 6,
    pcr_err_illegal_char = 7,
    pcr_err_empty_entry = 8
} ;
typedef enum __anonenum_phar_path_check_result_128 phar_path_check_result;
struct _phar_t {
   phar_archive_object *p ;
   zend_class_entry *c ;
   char *b ;
   uint l ;
   zval *ret ;
   int count ;
   php_stream *fp ;
};
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1,2),
__leaf__)) memcpy)(void * __restrict  __dest ,
                   void const   * __restrict  __src , size_t __n ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2),
__leaf__)) memcmp)(void const   *__s1 , void const   *__s2 , size_t __n )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1),
__leaf__)) memchr)(void const   *__s , int __c , size_t __n )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2),
__leaf__)) strcmp)(char const   *__s1 , char const   *__s2 )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2),
__leaf__)) strncmp)(char const   *__s1 , char const   *__s2 , size_t __n )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1),
__leaf__)) strrchr)(char const   *__s , int __c )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1,2),
__leaf__)) strstr)(char const   *__haystack , char const   *__needle )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(2),
__leaf__)) strtok)(char * __restrict  __s , char const   * __restrict  __delim ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__nonnull__(1),
__leaf__)) strlen)(char const   *__s )  __attribute__((__pure__)) ;
extern char __attribute__((__visibility__("default")))  *zend_strndup(char const   *s ,
                                                                      unsigned int length )  __attribute__((__malloc__)) ;
extern void __attribute__((__visibility__("default")))  *_emalloc(size_t size )  __attribute__((__malloc__)) ;
extern void __attribute__((__visibility__("default")))  *_safe_emalloc(size_t nmemb ,
                                                                       size_t size ,
                                                                       size_t offset )  __attribute__((__malloc__)) ;
extern void __attribute__((__visibility__("default")))  _efree(void *ptr ) ;
extern void __attribute__((__visibility__("default")))  *_ecalloc(size_t nmemb ,
                                                                  size_t size )  __attribute__((__malloc__)) ;
extern char __attribute__((__visibility__("default")))  *_estrdup(char const   *s )  __attribute__((__malloc__)) ;
extern char __attribute__((__visibility__("default")))  *_estrndup(char const   *s ,
                                                                   unsigned int length )  __attribute__((__malloc__)) ;
extern char const __attribute__((__visibility__("default")))  *(*zend_new_interned_string)(char const   *str ,
                                                                                           int len ,
                                                                                           int free_src ) ;
extern int __attribute__((__visibility__("default")))  _zend_hash_init(HashTable *ht ,
                                                                       uint nSize ,
                                                                       ulong (*pHashFunction)(char const   *arKey ,
                                                                                              uint nKeyLength ) ,
                                                                       void (*pDestructor)(void *pDest ) ,
                                                                       zend_bool persistent ) ;
extern void __attribute__((__visibility__("default")))  zend_hash_destroy(HashTable *ht ) ;
extern int __attribute__((__visibility__("default")))  _zend_hash_add_or_update(HashTable *ht ,
                                                                                char const   *arKey ,
                                                                                uint nKeyLength ,
                                                                                void *pData ,
                                                                                uint nDataSize ,
                                                                                void **pDest ,
                                                                                int flag ) ;
extern void __attribute__((__visibility__("default")))  zend_hash_apply_with_argument(HashTable *ht ,
                                                                                      int (*apply_func)(void *pDest ,
                                                                                                        void *argument ) ,
                                                                                      void * ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_del_key_or_index(HashTable *ht ,
                                                                                  char const   *arKey ,
                                                                                  uint nKeyLength ,
                                                                                  ulong h ,
                                                                                  int flag ) ;
extern ulong __attribute__((__visibility__("default")))  zend_get_hash_value(char const   *arKey ,
                                                                             uint nKeyLength ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_find(HashTable const   *ht ,
                                                                      char const   *arKey ,
                                                                      uint nKeyLength ,
                                                                      void **pData ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_index_find(HashTable const   *ht ,
                                                                            ulong h ,
                                                                            void **pData ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_exists(HashTable const   *ht ,
                                                                        char const   *arKey ,
                                                                        uint nKeyLength ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_move_forward_ex(HashTable *ht ,
                                                                                 HashPosition *pos ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_get_current_key_type_ex(HashTable *ht ,
                                                                                         HashPosition *pos ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_get_current_data_ex(HashTable *ht ,
                                                                                     void **pData ,
                                                                                     HashPosition *pos ) ;
extern void __attribute__((__visibility__("default")))  zend_hash_internal_pointer_reset_ex(HashTable *ht ,
                                                                                            HashPosition *pos ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_num_elements(HashTable const   *ht ) ;
__inline static zend_uint ( __attribute__((__always_inline__)) zval_refcount_p)(zval *pz ) 
{ 


  {
  return (pz->refcount__gc);
}
}
__inline static zend_uint ( __attribute__((__always_inline__)) zval_set_refcount_p)(zval *pz ,
                                                                                    zend_uint rc ) 
{ 
  zend_uint tmp ;

  {
  tmp = rc;
  pz->refcount__gc = tmp;
  return (tmp);
}
}
__inline static zend_uint ( __attribute__((__always_inline__)) zval_addref_p)(zval *pz ) 
{ 


  {
  (pz->refcount__gc) ++;
  return (pz->refcount__gc);
}
}
__inline static zend_bool ( __attribute__((__always_inline__)) zval_isref_p)(zval *pz ) 
{ 


  {
  return (pz->is_ref__gc);
}
}
__inline static zend_bool ( __attribute__((__always_inline__)) zval_set_isref_to_p)(zval *pz ,
                                                                                    zend_bool isref ) 
{ 
  zend_uchar tmp ;

  {
  tmp = isref;
  pz->is_ref__gc = tmp;
  return (tmp);
}
}
extern void __attribute__((__visibility__("default")))  _zend_bailout(char *filename ,
                                                                      uint lineno ) ;
extern zend_bool __attribute__((__visibility__("default")))  instanceof_function(zend_class_entry const   *instance_ce ,
                                                                                 zend_class_entry const   *ce ) ;
__inline static void const   *zend_memrchr(void const   *s , int c , size_t n ) 
{ 
  register unsigned char const   *e ;

  {
  if (n <= 0UL) {
    return ((void const   *)((void *)0));
  } else {

  }
  e = ((unsigned char const   *)s + n) - 1;
  while ((unsigned long )e >= (unsigned long )((unsigned char const   *)s)) {
    if ((int const   )*e == (int const   )((unsigned char const   )c)) {
      return ((void const   *)e);
    } else {

    }
    e --;
  }
  return ((void const   *)((void *)0));
}
}
extern void __attribute__((__visibility__("default")))  _zval_dtor_func(zval *zvalue ) ;
__inline static void ( __attribute__((__always_inline__)) _zval_dtor)(zval *zvalue ) 
{ 


  {
  if ((int )zvalue->type <= 3) {
    return;
  } else {

  }
  _zval_dtor_func(zvalue);
  return;
}
}
extern void __attribute__((__visibility__("default")))  _zval_copy_ctor_func(zval *zvalue ) ;
__inline static void ( __attribute__((__always_inline__)) _zval_copy_ctor)(zval *zvalue ) 
{ 


  {
  if ((int )zvalue->type <= 3) {
    return;
  } else {

  }
  _zval_copy_ctor_func(zvalue);
  return;
}
}
extern void __attribute__((__visibility__("default")))  _zval_ptr_dtor(zval **zval_ptr ) ;
extern  __attribute__((__nothrow__)) int _setjmp(struct __jmp_buf_tag *__env ) ;
extern zend_executor_globals __attribute__((__visibility__("default")))  executor_globals ;
extern void __attribute__((__visibility__("default")))  *zend_object_store_get_object(zval const   *object ) ;
extern zend_op_array __attribute__((__visibility__("default")))  *(*zend_compile_file)(zend_file_handle *file_handle ,
                                                                                       int type ) ;
extern void __attribute__((__visibility__("default")))  destroy_op_array(zend_op_array *op_array ) ;
extern void __attribute__((__visibility__("default")))  zend_destroy_file_handle(zend_file_handle *file_handle ) ;
extern HashTable __attribute__((__visibility__("default")))  module_registry ;
extern void __attribute__((__visibility__("default")))  *zend_fetch_resource(zval **passed_id ,
                                                                             int default_id ,
                                                                             char const   *resource_type_name ,
                                                                             int *found_resource_type ,
                                                                             int num_resource_types 
                                                                             , ...) ;
extern void __attribute__((__visibility__("default")))  (*zend_execute)(zend_op_array *op_array ) ;
extern char __attribute__((__visibility__("default")))  *zend_get_executed_filename(void) ;
extern int __attribute__((__visibility__("default")))  zend_parse_parameters(int num_args ,
                                                                             char const   *type_spec 
                                                                             , ...) ;
extern int __attribute__((__visibility__("default")))  zend_parse_parameters_ex(int flags ,
                                                                                int num_args ,
                                                                                char const   *type_spec 
                                                                                , ...) ;
extern zend_class_entry __attribute__((__visibility__("default")))  *zend_register_internal_class_ex(zend_class_entry *class_entry ,
                                                                                                     zend_class_entry *parent_ce ,
                                                                                                     char *parent_name ) ;
extern void __attribute__((__visibility__("default")))  zend_class_implements(zend_class_entry *class_entry ,
                                                                              int num_interfaces 
                                                                              , ...) ;
extern int __attribute__((__visibility__("default")))  zend_declare_class_constant_long(zend_class_entry *ce ,
                                                                                        char const   *name ,
                                                                                        size_t name_length ,
                                                                                        long value ) ;
extern zend_class_entry __attribute__((__visibility__("default")))  *zend_get_class_entry(zval const   *zobject ) ;
extern int __attribute__((__visibility__("default")))  _array_init(zval *arg ,
                                                                   uint size ) ;
extern int __attribute__((__visibility__("default")))  _object_init_ex(zval *arg ,
                                                                       zend_class_entry *ce ) ;
extern int __attribute__((__visibility__("default")))  add_assoc_string_ex(zval *arg ,
                                                                           char const   *key ,
                                                                           uint key_len ,
                                                                           char *str ,
                                                                           int duplicate ) ;
extern int __attribute__((__visibility__("default")))  add_assoc_stringl_ex(zval *arg ,
                                                                            char const   *key ,
                                                                            uint key_len ,
                                                                            char *str ,
                                                                            uint length ,
                                                                            int duplicate ) ;
extern int __attribute__((__visibility__("default")))  add_next_index_stringl(zval *arg ,
                                                                              char const   *str ,
                                                                              uint length ,
                                                                              int duplicate ) ;
extern int __attribute__((__visibility__("default")))  zend_fcall_info_init(zval *callable ,
                                                                            uint check_flags ,
                                                                            zend_fcall_info *fci ,
                                                                            zend_fcall_info_cache *fcc ,
                                                                            char **callable_name ,
                                                                            char **error ) ;
extern int __attribute__((__visibility__("default")))  zend_call_function(zend_fcall_info *fci ,
                                                                          zend_fcall_info_cache *fci_cache ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1),
__leaf__)) unlink)(char const   *__name ) ;
extern int __attribute__((__visibility__("default")))  spprintf(char **pbuf ,
                                                                size_t max_len ,
                                                                char const   *format 
                                                                , ...) ;
extern void __attribute__((__visibility__("default")))  php_error_docref0(char const   *docref ,
                                                                          int type ,
                                                                          char const   *format 
                                                                          , ...) ;
extern int __attribute__((__visibility__("default")))  php_output_write(char const   *str ,
                                                                        size_t len ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1),
__leaf__)) chmod)(char const   *__file , __mode_t __mode ) ;
extern int __attribute__((__visibility__("default")))  php_file_le_stream(void) ;
extern int __attribute__((__visibility__("default")))  php_file_le_pstream(void) ;
extern void __attribute__((__visibility__("default")))  _php_stream_filter_append(php_stream_filter_chain *chain ,
                                                                                  php_stream_filter *filter ) ;
extern int __attribute__((__visibility__("default")))  _php_stream_filter_flush(php_stream_filter *filter ,
                                                                                int finish ) ;
extern php_stream_filter __attribute__((__visibility__("default")))  *php_stream_filter_remove(php_stream_filter *filter ,
                                                                                               int call_dtor ) ;
extern php_stream_filter __attribute__((__visibility__("default")))  *php_stream_filter_create(char const   *filtername ,
                                                                                               zval *filterparams ,
                                                                                               int persistent ) ;
extern int __attribute__((__visibility__("default")))  _php_stream_free(php_stream *stream ,
                                                                        int close_options ) ;
extern int __attribute__((__visibility__("default")))  _php_stream_seek(php_stream *stream ,
                                                                        off_t offset ,
                                                                        int whence ) ;
extern off_t __attribute__((__visibility__("default")))  _php_stream_tell(php_stream *stream ) ;
extern size_t __attribute__((__visibility__("default")))  _php_stream_read(php_stream *stream ,
                                                                           char *buf ,
                                                                           size_t count ) ;
extern size_t __attribute__((__visibility__("default")))  _php_stream_write(php_stream *stream ,
                                                                            char const   *buf ,
                                                                            size_t count ) ;
extern int __attribute__((__visibility__("default")))  _php_stream_stat_path(char *path ,
                                                                             int flags ,
                                                                             php_stream_statbuf *ssb ,
                                                                             php_stream_context *context ) ;
extern int __attribute__((__visibility__("default")))  _php_stream_mkdir(char *path ,
                                                                         int mode ,
                                                                         int options ,
                                                                         php_stream_context *context ) ;
extern size_t __attribute__((__visibility__("default")))  _php_stream_copy_to_stream_ex(php_stream *src ,
                                                                                        php_stream *dest ,
                                                                                        size_t maxlen ,
                                                                                        size_t *len ) ;
extern size_t __attribute__((__visibility__("default")))  _php_stream_copy_to_mem(php_stream *src ,
                                                                                  char **buf ,
                                                                                  size_t maxlen ,
                                                                                  int persistent ) ;
extern php_stream __attribute__((__visibility__("default")))  *_php_stream_fopen_tmpfile(int dummy ) ;
extern php_stream __attribute__((__visibility__("default")))  *_php_stream_open_wrapper_ex(char *path ,
                                                                                           char *mode ,
                                                                                           int options ,
                                                                                           char **opened_path ,
                                                                                           php_stream_context *context ) ;
extern struct _php_core_globals  __attribute__((__visibility__("default"))) core_globals ;
extern char __attribute__((__visibility__("default")))  *expand_filepath(char const   *filepath ,
                                                                         char *real_path ) ;
extern int __attribute__((__visibility__("default")))  php_check_open_basedir(char const   *path ) ;
extern zend_class_entry __attribute__((__visibility__("default")))  *zend_exception_get_default(void) ;
extern zval __attribute__((__visibility__("default")))  *zend_throw_exception_ex(zend_class_entry *exception_ce ,
                                                                                 long code ,
                                                                                 char *format 
                                                                                 , ...) ;
extern zend_class_entry __attribute__((__visibility__("default")))  *zend_ce_traversable ;
extern zend_class_entry __attribute__((__visibility__("default")))  *zend_ce_arrayaccess ;
extern zval __attribute__((__visibility__("default")))  *zend_call_method(zval **object_pp ,
                                                                          zend_class_entry *obj_ce ,
                                                                          zend_function **fn_proxy ,
                                                                          char *function_name ,
                                                                          int function_name_len ,
                                                                          zval **retval_ptr_ptr ,
                                                                          int param_count ,
                                                                          zval *arg1 ,
                                                                          zval *arg2 ) ;
extern sapi_module_struct __attribute__((__visibility__("default")))  sapi_module ;
extern sapi_globals_struct __attribute__((__visibility__("default")))  sapi_globals ;
extern int __attribute__((__visibility__("default")))  sapi_header_op(sapi_header_op_enum op ,
                                                                      void *arg ) ;
extern int __attribute__((__visibility__("default")))  sapi_send_headers(void) ;
extern char __attribute__((__visibility__("default")))  *sapi_getenv(char *name ,
                                                                     size_t name_len ) ;
extern void __attribute__((__visibility__("default")))  php_stat(char const   *filename ,
                                                                 php_stat_len filename_length ,
                                                                 int type ,
                                                                 zval *return_value ) ;
extern int __attribute__((__visibility__("default")))  highlight_file(char *filename ,
                                                                      zend_syntax_highlighter_ini *syntax_highlighter_ini ) ;
extern void __attribute__((__visibility__("default")))  php_get_highlight_struct(zend_syntax_highlighter_ini *syntax_highlighter_ini ) ;
extern php_basic_globals __attribute__((__visibility__("default")))  basic_globals ;
extern zend_class_entry __attribute__((__visibility__("default")))  *spl_ce_RecursiveIteratorIterator ;
extern zend_class_entry __attribute__((__visibility__("default")))  *spl_ce_RegexIterator ;
extern zend_class_entry __attribute__((__visibility__("default")))  *spl_ce_Countable ;
extern int __attribute__((__visibility__("default")))  spl_iterator_apply(zval *obj ,
                                                                          int (*apply_func)(zend_object_iterator *iter ,
                                                                                            void *puser ) ,
                                                                          void *puser ) ;
extern zend_class_entry __attribute__((__visibility__("default")))  *spl_ce_SplFileInfo ;
extern zend_class_entry __attribute__((__visibility__("default")))  *spl_ce_RecursiveDirectoryIterator ;
extern char __attribute__((__visibility__("default")))  *spl_filesystem_object_get_path(spl_filesystem_object *intern ,
                                                                                        int *len ) ;
extern void __attribute__((__visibility__("default")))  spl_instantiate(zend_class_entry *pce ,
                                                                        zval **object ,
                                                                        int alloc ) ;
__inline static int spl_instantiate_arg_ex1(zend_class_entry *pce ,
                                            zval **retval , int alloc ,
                                            zval *arg1 ) 
{ 
  size_t tmp ;

  {
  spl_instantiate(pce, retval, alloc);
  tmp = strlen((char const   *)(pce->constructor)->common.function_name);
  zend_call_method(retval, pce, & pce->constructor,
                   (pce->constructor)->common.function_name, (int )tmp,
                   (zval **)((void *)0), 1, arg1, (zval *)((void *)0));
  return (0);
}
}
extern zend_class_entry __attribute__((__visibility__("default")))  *spl_ce_BadMethodCallException ;
extern zend_class_entry __attribute__((__visibility__("default")))  *spl_ce_InvalidArgumentException ;
extern zend_class_entry __attribute__((__visibility__("default")))  *spl_ce_RuntimeException ;
extern zend_class_entry __attribute__((__visibility__("default")))  *spl_ce_UnexpectedValueException ;
extern zend_phar_globals phar_globals ;
__inline static int phar_validate_alias(char const   *alias , int alias_len ) 
{ 
  void *tmp ;
  void *tmp___0 ;
  void *tmp___1 ;
  void *tmp___2 ;
  void *tmp___3 ;
  void *tmp___4 ;
  int tmp___5 ;

  {
  tmp = memchr((void const   *)alias, '/', (size_t )alias_len);
  if (tmp) {
    tmp___5 = 0;
  } else {
    tmp___0 = memchr((void const   *)alias, '\\', (size_t )alias_len);
    if (tmp___0) {
      tmp___5 = 0;
    } else {
      tmp___1 = memchr((void const   *)alias, ':', (size_t )alias_len);
      if (tmp___1) {
        tmp___5 = 0;
      } else {
        tmp___2 = memchr((void const   *)alias, ';', (size_t )alias_len);
        if (tmp___2) {
          tmp___5 = 0;
        } else {
          tmp___3 = memchr((void const   *)alias, '\n', (size_t )alias_len);
          if (tmp___3) {
            tmp___5 = 0;
          } else {
            tmp___4 = memchr((void const   *)alias, '\r', (size_t )alias_len);
            if (tmp___4) {
              tmp___5 = 0;
            } else {
              tmp___5 = 1;
            }
          }
        }
      }
    }
  }
  return (tmp___5);
}
}
__inline static void phar_set_inode(phar_entry_info *entry ) 
{ 
  char tmp[4096] ;
  int tmp_len ;
  ulong __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp_len = (int )(entry->filename_len + (php_uint32 )(entry->phar)->fname_len);
  memcpy((void */* __restrict  */)(tmp),
         (void const   */* __restrict  */)(entry->phar)->fname,
         (size_t )(entry->phar)->fname_len);
  memcpy((void */* __restrict  */)(tmp + (entry->phar)->fname_len),
         (void const   */* __restrict  */)entry->filename,
         (size_t )entry->filename_len);
  tmp___0 = zend_get_hash_value((char const   *)(tmp), (uint )tmp_len);
  entry->inode = (unsigned short )tmp___0;
  return;
}
}
extern void phar_request_initialize(void) ;
void phar_object_init(void) ;
extern void phar_destroy_phar_data(phar_archive_data *phar ) ;
extern int phar_open_from_filename(char *fname , int fname_len , char *alias ,
                                   int alias_len , int options ,
                                   phar_archive_data **pphar , char **error ) ;
extern int phar_open_or_create_filename(char *fname , int fname_len ,
                                        char *alias , int alias_len ,
                                        int is_data , int options ,
                                        phar_archive_data **pphar ,
                                        char **error ) ;
extern int phar_open_executed_filename(char *alias , int alias_len ,
                                       char **error ) ;
extern int phar_free_alias(phar_archive_data *phar , char *alias ,
                           int alias_len ) ;
extern int phar_get_archive(phar_archive_data **archive , char *fname ,
                            int fname_len , char *alias , int alias_len ,
                            char **error ) ;
extern char *phar_create_default_stub(char const   *index_php ,
                                      char const   *web_index , size_t *len ,
                                      char **error ) ;
extern char *phar_decompress_filter(phar_entry_info *entry , int return_unknown ) ;
extern void phar_add_virtual_dirs(phar_archive_data *phar , char *filename ,
                                  int filename_len ) ;
extern int phar_mount_entry(phar_archive_data *phar , char *filename ,
                            int filename_len , char *path , int path_len ) ;
extern phar_entry_info *phar_open_jit(phar_archive_data *phar ,
                                      phar_entry_info *entry , char **error ) ;
extern int phar_parse_metadata(char **buffer , zval **metadata ,
                               int zip_metadata_len ) ;
extern void destroy_phar_manifest_entry(void *pDest ) ;
extern int phar_seek_efp(phar_entry_info *entry , off_t offset , int whence ,
                         off_t position , int follow_links ) ;
extern php_stream *phar_get_efp(phar_entry_info *entry , int follow_links ) ;
extern int phar_copy_entry_fp(phar_entry_info *source , phar_entry_info *dest ,
                              char **error ) ;
extern int phar_open_entry_fp(phar_entry_info *entry , char **error ,
                              int follow_links ) ;
extern phar_entry_info *phar_get_link_source(phar_entry_info *entry ) ;
extern int phar_open_archive_fp(phar_archive_data *phar ) ;
extern int phar_copy_on_write(phar_archive_data **pphar ) ;
extern HashTable cached_phars ;
extern int phar_archive_delref(phar_archive_data *phar ) ;
extern int phar_entry_delref(phar_entry_data *idata ) ;
extern phar_entry_info *phar_get_entry_info(phar_archive_data *phar ,
                                            char *path , int path_len ,
                                            char **error , int security ) ;
extern phar_entry_info *phar_get_entry_info_dir(phar_archive_data *phar ,
                                                char *path , int path_len ,
                                                char dir , char **error ,
                                                int security ) ;
extern phar_entry_data *phar_get_or_create_entry_data(char *fname ,
                                                      int fname_len ,
                                                      char *path ,
                                                      int path_len ,
                                                      char *mode ,
                                                      char allow_dir ,
                                                      char **error ,
                                                      int security ) ;
extern int phar_flush(phar_archive_data *archive , char *user_stub , long len ,
                      int convert , char **error ) ;
extern int phar_detect_phar_fname_ext(char const   *filename ,
                                      int filename_len ,
                                      char const   **ext_str , int *ext_len ,
                                      int executable , int for_create ,
                                      int is_complete ) ;
extern int phar_split_fname(char *filename , int filename_len , char **arch ,
                            int *arch_len , char **entry , int *entry_len ,
                            int executable , int for_create ) ;
extern phar_path_check_result phar_path_check(char **p , int *len ,
                                              char const   **error ) ;
extern void phar_intercept_functions(void) ;
static zend_class_entry *phar_ce_archive  ;
static zend_class_entry *phar_ce_data  ;
static zend_class_entry *phar_ce_PharException  ;
static zend_class_entry *phar_ce_entry  ;
static int phar_file_type(HashTable *mimes , char *file , char **mime_type ) 
{ 
  char *ext ;
  phar_mime_type *mime ;
  size_t tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  ext = strrchr((char const   *)file, '.');
  if (! ext) {
    *mime_type = (char *)"text/plain";
    return ('\002');
  } else {

  }
  ext ++;
  tmp = strlen((char const   *)ext);
  tmp___0 = zend_hash_find((HashTable const   *)mimes, (char const   *)ext,
                           (uint )tmp, (void **)(& mime));
  if (0 != (int )tmp___0) {
    *mime_type = (char *)"application/octet-stream";
    return ('\002');
  } else {

  }
  *mime_type = mime->mime;
  return ((int )mime->type);
}
}
static void phar_mung_server_vars(char *fname , char *entry , int entry_len ,
                                  char *basename , int request_uri_len ) 
{ 
  HashTable *_SERVER ;
  zval **stuff ;
  char *path_info ;
  int basename_len ;
  size_t tmp ;
  int code ;
  zval *temp ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  char const   *__s___0 ;
  int __l___0 ;
  zval *__z___0 ;
  int tmp___3 ;
  int __attribute__((__visibility__("default")))  tmp___4 ;
  int __attribute__((__visibility__("default")))  tmp___5 ;
  void __attribute__((__visibility__("default")))  *tmp___6 ;
  char const   *__s___1 ;
  int __l___1 ;
  zval *__z___1 ;
  int __attribute__((__visibility__("default")))  tmp___8 ;
  char const   *__s___2 ;
  int __l___2 ;
  zval *__z___2 ;
  char __attribute__((__visibility__("default")))  *tmp___9 ;
  void __attribute__((__visibility__("default")))  *tmp___10 ;
  char const   *__s___3 ;
  int __l___3 ;
  zval *__z___3 ;
  int tmp___12 ;
  int __attribute__((__visibility__("default")))  tmp___13 ;
  char const   *__s___4 ;
  int __l___4 ;
  zval *__z___4 ;
  char __attribute__((__visibility__("default")))  *tmp___14 ;
  void __attribute__((__visibility__("default")))  *tmp___15 ;
  char const   *__s___5 ;
  int __l___5 ;
  zval *__z___5 ;
  int tmp___17 ;
  int __attribute__((__visibility__("default")))  tmp___18 ;
  char const   *__s___6 ;
  int __l___6 ;
  zval *__z___6 ;
  char __attribute__((__visibility__("default")))  *tmp___19 ;
  void __attribute__((__visibility__("default")))  *tmp___20 ;
  char const   *__s___7 ;
  int __l___7 ;
  zval *__z___7 ;
  int __attribute__((__visibility__("default")))  tmp___22 ;
  int __attribute__((__visibility__("default")))  tmp___23 ;
  void __attribute__((__visibility__("default")))  *tmp___24 ;
  char const   *__s___8 ;
  int __l___8 ;
  zval *__z___8 ;
  int __attribute__((__visibility__("default")))  tmp___26 ;

  {
  tmp = strlen((char const   *)basename);
  basename_len = (int )tmp;
  if (! core_globals.http_globals[3]) {
    return;
  } else {

  }
  _SERVER = (core_globals.http_globals[3])->value.ht;
  tmp___4 = zend_hash_find((HashTable const   *)_SERVER, "PATH_INFO",
                           (uint )sizeof("PATH_INFO"), (void **)(& stuff));
  if (0 == (int )tmp___4) {
    path_info = (*stuff)->value.str.val;
    code = (*stuff)->value.str.len;
    if ((*stuff)->value.str.len > entry_len) {
      tmp___3 = memcmp((void const   *)(*stuff)->value.str.val,
                       (void const   *)entry, (size_t )entry_len);
      if (! tmp___3) {
        while (1) {
          __s = (char const   *)((*stuff)->value.str.val + entry_len);
          __l = request_uri_len;
          __z = *stuff;
          __z->value.str.len = __l;
          tmp___0 = _estrndup(__s, (unsigned int )__l);
          __z->value.str.val = (char *)tmp___0;
          __z->type = (zend_uchar )6;
          break;
        }
        while (1) {
          tmp___1 = _emalloc(sizeof(zval_gc_info ));
          temp = (zval *)tmp___1;
          ((zval_gc_info *)temp)->u.buffered = (gc_root_buffer *)((void *)0);
          break;
        }
        temp->refcount__gc = (zend_uint )1;
        temp->is_ref__gc = (zend_uchar )0;
        while (1) {
          __s___0 = (char const   *)path_info;
          __l___0 = code;
          __z___0 = temp;
          __z___0->value.str.len = __l___0;
          __z___0->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s___0));
          __z___0->type = (zend_uchar )6;
          break;
        }
        _zend_hash_add_or_update(_SERVER, "PHAR_PATH_INFO",
                                 (uint )sizeof("PHAR_PATH_INFO"),
                                 (void *)(& temp), (uint )sizeof(zval **),
                                 (void **)((void *)0), 1);
      } else {

      }
    } else {

    }
  } else {

  }
  tmp___8 = zend_hash_find((HashTable const   *)_SERVER, "PATH_TRANSLATED",
                           (uint )sizeof("PATH_TRANSLATED"), (void **)(& stuff));
  if (0 == (int )tmp___8) {
    path_info = (*stuff)->value.str.val;
    code = (*stuff)->value.str.len;
    tmp___5 = spprintf(& (*stuff)->value.str.val, (size_t )4096, "phar://%s%s",
                       fname, entry);
    (*stuff)->value.str.len = (int )tmp___5;
    while (1) {
      tmp___6 = _emalloc(sizeof(zval_gc_info ));
      temp = (zval *)tmp___6;
      ((zval_gc_info *)temp)->u.buffered = (gc_root_buffer *)((void *)0);
      break;
    }
    temp->refcount__gc = (zend_uint )1;
    temp->is_ref__gc = (zend_uchar )0;
    while (1) {
      __s___1 = (char const   *)path_info;
      __l___1 = code;
      __z___1 = temp;
      __z___1->value.str.len = __l___1;
      __z___1->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s___1));
      __z___1->type = (zend_uchar )6;
      break;
    }
    _zend_hash_add_or_update(_SERVER, "PHAR_PATH_TRANSLATED",
                             (uint )sizeof("PHAR_PATH_TRANSLATED"),
                             (void *)(& temp), (uint )sizeof(zval **),
                             (void **)((void *)0), 1);
  } else {

  }
  if (! phar_globals.phar_SERVER_mung_list) {
    return;
  } else {

  }
  if (phar_globals.phar_SERVER_mung_list & (1 << 1)) {
    tmp___13 = zend_hash_find((HashTable const   *)_SERVER, "REQUEST_URI",
                              (uint )sizeof("REQUEST_URI"), (void **)(& stuff));
    if (0 == (int )tmp___13) {
      path_info = (*stuff)->value.str.val;
      code = (*stuff)->value.str.len;
      if ((*stuff)->value.str.len > basename_len) {
        tmp___12 = memcmp((void const   *)(*stuff)->value.str.val,
                          (void const   *)basename, (size_t )basename_len);
        if (! tmp___12) {
          while (1) {
            __s___2 = (char const   *)((*stuff)->value.str.val + basename_len);
            __l___2 = (*stuff)->value.str.len - basename_len;
            __z___2 = *stuff;
            __z___2->value.str.len = __l___2;
            tmp___9 = _estrndup(__s___2, (unsigned int )__l___2);
            __z___2->value.str.val = (char *)tmp___9;
            __z___2->type = (zend_uchar )6;
            break;
          }
          while (1) {
            tmp___10 = _emalloc(sizeof(zval_gc_info ));
            temp = (zval *)tmp___10;
            ((zval_gc_info *)temp)->u.buffered = (gc_root_buffer *)((void *)0);
            break;
          }
          temp->refcount__gc = (zend_uint )1;
          temp->is_ref__gc = (zend_uchar )0;
          while (1) {
            __s___3 = (char const   *)path_info;
            __l___3 = code;
            __z___3 = temp;
            __z___3->value.str.len = __l___3;
            __z___3->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s___3));
            __z___3->type = (zend_uchar )6;
            break;
          }
          _zend_hash_add_or_update(_SERVER, "PHAR_REQUEST_URI",
                                   (uint )sizeof("PHAR_REQUEST_URI"),
                                   (void *)(& temp), (uint )sizeof(zval **),
                                   (void **)((void *)0), 1);
        } else {

        }
      } else {

      }
    } else {

    }
  } else {

  }
  if (phar_globals.phar_SERVER_mung_list & 1) {
    tmp___18 = zend_hash_find((HashTable const   *)_SERVER, "PHP_SELF",
                              (uint )sizeof("PHP_SELF"), (void **)(& stuff));
    if (0 == (int )tmp___18) {
      path_info = (*stuff)->value.str.val;
      code = (*stuff)->value.str.len;
      if ((*stuff)->value.str.len > basename_len) {
        tmp___17 = memcmp((void const   *)(*stuff)->value.str.val,
                          (void const   *)basename, (size_t )basename_len);
        if (! tmp___17) {
          while (1) {
            __s___4 = (char const   *)((*stuff)->value.str.val + basename_len);
            __l___4 = (*stuff)->value.str.len - basename_len;
            __z___4 = *stuff;
            __z___4->value.str.len = __l___4;
            tmp___14 = _estrndup(__s___4, (unsigned int )__l___4);
            __z___4->value.str.val = (char *)tmp___14;
            __z___4->type = (zend_uchar )6;
            break;
          }
          while (1) {
            tmp___15 = _emalloc(sizeof(zval_gc_info ));
            temp = (zval *)tmp___15;
            ((zval_gc_info *)temp)->u.buffered = (gc_root_buffer *)((void *)0);
            break;
          }
          temp->refcount__gc = (zend_uint )1;
          temp->is_ref__gc = (zend_uchar )0;
          while (1) {
            __s___5 = (char const   *)path_info;
            __l___5 = code;
            __z___5 = temp;
            __z___5->value.str.len = __l___5;
            __z___5->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s___5));
            __z___5->type = (zend_uchar )6;
            break;
          }
          _zend_hash_add_or_update(_SERVER, "PHAR_PHP_SELF",
                                   (uint )sizeof("PHAR_PHP_SELF"),
                                   (void *)(& temp), (uint )sizeof(zval **),
                                   (void **)((void *)0), 1);
        } else {

        }
      } else {

      }
    } else {

    }
  } else {

  }
  if (phar_globals.phar_SERVER_mung_list & (1 << 2)) {
    tmp___22 = zend_hash_find((HashTable const   *)_SERVER, "SCRIPT_NAME",
                              (uint )sizeof("SCRIPT_NAME"), (void **)(& stuff));
    if (0 == (int )tmp___22) {
      path_info = (*stuff)->value.str.val;
      code = (*stuff)->value.str.len;
      while (1) {
        __s___6 = (char const   *)entry;
        __l___6 = entry_len;
        __z___6 = *stuff;
        __z___6->value.str.len = __l___6;
        tmp___19 = _estrndup(__s___6, (unsigned int )__l___6);
        __z___6->value.str.val = (char *)tmp___19;
        __z___6->type = (zend_uchar )6;
        break;
      }
      while (1) {
        tmp___20 = _emalloc(sizeof(zval_gc_info ));
        temp = (zval *)tmp___20;
        ((zval_gc_info *)temp)->u.buffered = (gc_root_buffer *)((void *)0);
        break;
      }
      temp->refcount__gc = (zend_uint )1;
      temp->is_ref__gc = (zend_uchar )0;
      while (1) {
        __s___7 = (char const   *)path_info;
        __l___7 = code;
        __z___7 = temp;
        __z___7->value.str.len = __l___7;
        __z___7->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s___7));
        __z___7->type = (zend_uchar )6;
        break;
      }
      _zend_hash_add_or_update(_SERVER, "PHAR_SCRIPT_NAME",
                               (uint )sizeof("PHAR_SCRIPT_NAME"),
                               (void *)(& temp), (uint )sizeof(zval **),
                               (void **)((void *)0), 1);
    } else {

    }
  } else {

  }
  if (phar_globals.phar_SERVER_mung_list & (1 << 3)) {
    tmp___26 = zend_hash_find((HashTable const   *)_SERVER, "SCRIPT_FILENAME",
                              (uint )sizeof("SCRIPT_FILENAME"),
                              (void **)(& stuff));
    if (0 == (int )tmp___26) {
      path_info = (*stuff)->value.str.val;
      code = (*stuff)->value.str.len;
      tmp___23 = spprintf(& (*stuff)->value.str.val, (size_t )4096,
                          "phar://%s%s", fname, entry);
      (*stuff)->value.str.len = (int )tmp___23;
      while (1) {
        tmp___24 = _emalloc(sizeof(zval_gc_info ));
        temp = (zval *)tmp___24;
        ((zval_gc_info *)temp)->u.buffered = (gc_root_buffer *)((void *)0);
        break;
      }
      temp->refcount__gc = (zend_uint )1;
      temp->is_ref__gc = (zend_uchar )0;
      while (1) {
        __s___8 = (char const   *)path_info;
        __l___8 = code;
        __z___8 = temp;
        __z___8->value.str.len = __l___8;
        __z___8->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s___8));
        __z___8->type = (zend_uchar )6;
        break;
      }
      _zend_hash_add_or_update(_SERVER, "PHAR_SCRIPT_FILENAME",
                               (uint )sizeof("PHAR_SCRIPT_FILENAME"),
                               (void *)(& temp), (uint )sizeof(zval **),
                               (void **)((void *)0), 1);
    } else {

    }
  } else {

  }
  return;
}
}
static int phar_file_action(phar_archive_data *phar , phar_entry_info *info ,
                            char *mime_type , int code , char *entry ,
                            int entry_len , char *arch , char *basename ,
                            char *ru , int ru_len ) 
{ 
  char *name ;
  char buf[8192] ;
  char const   *cwd ;
  zend_syntax_highlighter_ini syntax_highlighter_ini___0 ;
  sapi_header_line ctr ;
  size_t got ;
  int dummy ;
  int name_len ;
  zend_file_handle file_handle ;
  zend_op_array *new_op_array ;
  zval *result ;
  php_stream *fp ;
  off_t position ;
  int __attribute__((__visibility__("default")))  tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;
  int __attribute__((__visibility__("default")))  tmp___2 ;
  int __attribute__((__visibility__("default")))  tmp___3 ;
  char *error ;
  phar_entry_info *tmp___4 ;
  off_t tmp___5 ;
  size_t __attribute__((__visibility__("default")))  tmp___6 ;
  int __attribute__((__visibility__("default")))  tmp___7 ;
  int __attribute__((__visibility__("default")))  tmp___8 ;
  char __attribute__((__visibility__("default")))  *tmp___9 ;
  char __attribute__((__visibility__("default")))  *tmp___10 ;
  void const   *tmp___11 ;
  zend_op_array __attribute__((__visibility__("default")))  *tmp___12 ;
  int __attribute__((__visibility__("default")))  tmp___13 ;
  jmp_buf *__orig_bailout ;
  jmp_buf __bailout ;
  int tmp___14 ;

  {
  name = (char *)((void *)0);
  ctr.line = (char *)0;
  ctr.line_len = 0U;
  ctr.response_code = 0L;
  dummy = 1;
  result = (zval *)((void *)0);
  switch (code) {
  case 1: 
  _efree((void *)basename);
  if ((int )*(entry + 0) == 47) {
    tmp = spprintf(& name, (size_t )4096, "phar://%s%s", arch, entry);
    name_len = (int )tmp;
  } else {
    tmp___0 = spprintf(& name, (size_t )4096, "phar://%s/%s", arch, entry);
    name_len = (int )tmp___0;
  }
  php_get_highlight_struct(& syntax_highlighter_ini___0);
  highlight_file(name, & syntax_highlighter_ini___0);
  _efree((void *)name);
  _zend_bailout((char *)"/data/manybugs/php/3acdca4703/src/ext/phar/phar_object.c",
                (uint )289);
  case 2: 
  _efree((void *)basename);
  tmp___1 = spprintf(& ctr.line, (size_t )0, "Content-type: %s", mime_type);
  ctr.line_len = (uint )tmp___1;
  sapi_header_op((sapi_header_op_enum )0, (void *)(& ctr));
  _efree((void *)ctr.line);
  tmp___2 = spprintf(& ctr.line, (size_t )0, "Content-length: %u",
                     info->uncompressed_filesize);
  ctr.line_len = (uint )tmp___2;
  sapi_header_op((sapi_header_op_enum )0, (void *)(& ctr));
  _efree((void *)ctr.line);
  tmp___3 = sapi_send_headers();
  if (-1 == (int )tmp___3) {
    _zend_bailout((char *)"/data/manybugs/php/3acdca4703/src/ext/phar/phar_object.c",
                  (uint )301);
  } else {

  }
  fp = phar_get_efp(info, 1);
  if (! fp) {
    tmp___4 = phar_open_jit(phar, info, & error);
    if (! tmp___4) {
      if (error) {
        zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
        _efree((void *)error);
      } else {

      }
      return (-1);
    } else {

    }
    fp = phar_get_efp(info, 1);
  } else {

  }
  position = (off_t )0;
  phar_seek_efp(info, (off_t )0, 0, (off_t )0, 1);
  while (1) {
    if (8192L < (off_t )info->uncompressed_filesize - position) {
      tmp___5 = (off_t )8192;
    } else {
      tmp___5 = (off_t )info->uncompressed_filesize - position;
    }
    tmp___6 = _php_stream_read(fp, buf, (size_t )tmp___5);
    got = (size_t )tmp___6;
    if (got > 0UL) {
      php_output_write((char const   *)(buf), got);
      position = (off_t )((size_t )position + got);
      if (position == (off_t )info->uncompressed_filesize) {
        break;
      } else {

      }
    } else {

    }
  }
  _zend_bailout((char *)"/data/manybugs/php/3acdca4703/src/ext/phar/phar_object.c",
                (uint )332);
  case 0: 
  if (basename) {
    phar_mung_server_vars(arch, entry, entry_len, basename, ru_len);
    _efree((void *)basename);
  } else {

  }
  if ((int )*(entry + 0) == 47) {
    tmp___7 = spprintf(& name, (size_t )4096, "phar://%s%s", arch, entry);
    name_len = (int )tmp___7;
  } else {
    tmp___8 = spprintf(& name, (size_t )4096, "phar://%s/%s", arch, entry);
    name_len = (int )tmp___8;
  }
  file_handle.type = (zend_stream_type )0;
  file_handle.handle.fd = 0;
  file_handle.filename = name;
  file_handle.opened_path = (char *)((void *)0);
  file_handle.free_filename = (zend_bool )0;
  phar_globals.cwd = (char *)((void *)0);
  phar_globals.cwd_len = 0;
  tmp___13 = _zend_hash_add_or_update(& executor_globals.included_files,
                                      (char const   *)name,
                                      (uint )(name_len + 1), (void *)(& dummy),
                                      (uint )sizeof(int ), (void **)((void *)0),
                                      1 << 1);
  if (tmp___13 == (int __attribute__((__visibility__("default")))  )0) {
    tmp___11 = zend_memrchr((void const   *)entry, '/', (size_t )entry_len);
    cwd = (char const   *)tmp___11;
    if (cwd) {
      phar_globals.cwd_init = 1;
      if ((unsigned long )entry == (unsigned long )cwd) {
        phar_globals.cwd_len = 0;
        phar_globals.cwd = (char *)((void *)0);
      } else
      if ((int )*(entry + 0) == 47) {
        phar_globals.cwd_len = (int )(cwd - (char const   *)(entry + 1));
        tmp___9 = _estrndup((char const   *)(entry + 1),
                            (unsigned int )phar_globals.cwd_len);
        phar_globals.cwd = (char *)tmp___9;
      } else {
        phar_globals.cwd_len = (int )(cwd - (char const   *)entry);
        tmp___10 = _estrndup((char const   *)entry,
                             (unsigned int )phar_globals.cwd_len);
        phar_globals.cwd = (char *)tmp___10;
      }
    } else {

    }
    tmp___12 = (*zend_compile_file)(& file_handle, 1 << 3);
    new_op_array = (zend_op_array *)tmp___12;
    if (! new_op_array) {
      zend_hash_del_key_or_index(& executor_globals.included_files,
                                 (char const   *)name, (uint )(name_len + 1),
                                 (ulong )0, 0);
    } else {

    }
    zend_destroy_file_handle(& file_handle);
  } else {
    _efree((void *)name);
    new_op_array = (zend_op_array *)((void *)0);
  }
  if (new_op_array) {
    executor_globals.return_value_ptr_ptr = & result;
    executor_globals.active_op_array = new_op_array;
    __orig_bailout = executor_globals.bailout;
    executor_globals.bailout = & __bailout;
    tmp___14 = _setjmp(__bailout);
    if (tmp___14 == 0) {
      (*zend_execute)(new_op_array);
      if (phar_globals.cwd) {
        _efree((void *)phar_globals.cwd);
        phar_globals.cwd = (char *)((void *)0);
        phar_globals.cwd_len = 0;
      } else {

      }
      phar_globals.cwd_init = 0;
      _efree((void *)name);
      destroy_op_array(new_op_array);
      _efree((void *)new_op_array);
      if (executor_globals.return_value_ptr_ptr) {
        if (*(executor_globals.return_value_ptr_ptr)) {
          _zval_ptr_dtor(executor_globals.return_value_ptr_ptr);
        } else {

        }
      } else {

      }
    } else {
      executor_globals.bailout = __orig_bailout;
      if (phar_globals.cwd) {
        _efree((void *)phar_globals.cwd);
        phar_globals.cwd = (char *)((void *)0);
        phar_globals.cwd_len = 0;
      } else {

      }
      phar_globals.cwd_init = 0;
      _efree((void *)name);
    }
    executor_globals.bailout = __orig_bailout;
    _zend_bailout((char *)"/data/manybugs/php/3acdca4703/src/ext/phar/phar_object.c",
                  (uint )417);
  } else {

  }
  return ('\000');
  }
  return (-1);
}
}
static void phar_do_403(char *entry , int entry_len ) 
{ 
  sapi_header_line ctr ;

  {
  ctr.line = (char *)0;
  ctr.line_len = 0U;
  ctr.response_code = 0L;
  ctr.response_code = 403L;
  ctr.line_len = (uint )sizeof("HTTP/1.0 403 Access Denied");
  ctr.line = (char *)"HTTP/1.0 403 Access Denied";
  sapi_header_op((sapi_header_op_enum )0, (void *)(& ctr));
  sapi_send_headers();
  php_output_write("<html>\n <head>\n  <title>Access Denied</title>\n </head>\n <body>\n  <h1>403 - File ",
                   sizeof("<html>\n <head>\n  <title>Access Denied</title>\n </head>\n <body>\n  <h1>403 - File ") - 1UL);
  php_output_write((char const   *)entry, (size_t )entry_len);
  php_output_write(" Access Denied</h1>\n </body>\n</html>",
                   sizeof(" Access Denied</h1>\n </body>\n</html>") - 1UL);
  return;
}
}
static void phar_do_404(phar_archive_data *phar , char *fname , int fname_len ,
                        char *f404 , int f404_len , char *entry , int entry_len ) 
{ 
  sapi_header_line ctr ;
  phar_entry_info *info ;

  {
  ctr.line = (char *)0;
  ctr.line_len = 0U;
  ctr.response_code = 0L;
  if (phar) {
    if (f404_len) {
      info = phar_get_entry_info(phar, f404, f404_len, (char **)((void *)0), 1);
      if (info) {
        phar_file_action(phar, info, (char *)"text/html", '\000', f404,
                         f404_len, fname, (char *)((void *)0),
                         (char *)((void *)0), 0);
        return;
      } else {

      }
    } else {

    }
  } else {

  }
  ctr.response_code = 404L;
  ctr.line_len = (uint )(sizeof("HTTP/1.0 404 Not Found") + 1UL);
  ctr.line = (char *)"HTTP/1.0 404 Not Found";
  sapi_header_op((sapi_header_op_enum )0, (void *)(& ctr));
  sapi_send_headers();
  php_output_write("<html>\n <head>\n  <title>File Not Found</title>\n </head>\n <body>\n  <h1>404 - File ",
                   sizeof("<html>\n <head>\n  <title>File Not Found</title>\n </head>\n <body>\n  <h1>404 - File ") - 1UL);
  php_output_write((char const   *)entry, (size_t )entry_len);
  php_output_write(" Not Found</h1>\n </body>\n</html>",
                   sizeof(" Not Found</h1>\n </body>\n</html>") - 1UL);
  return;
}
}
static void phar_postprocess_ru_web(char *fname , int fname_len , char **entry ,
                                    int *entry_len , char **ru , int *ru_len ) 
{ 
  char *e ;
  char *u ;
  char *u1 ;
  char *saveu ;
  int e_len ;
  int u_len ;
  phar_archive_data **pphar ;
  char __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  size_t tmp___1 ;

  {
  e = *entry + 1;
  u = (char *)((void *)0);
  u1 = (char *)((void *)0);
  saveu = (char *)((void *)0);
  e_len = *entry_len - 1;
  u_len = 0;
  pphar = (phar_archive_data **)((void *)0);
  zend_hash_find((HashTable const   *)(& phar_globals.phar_fname_map),
                 (char const   *)fname, (uint )fname_len, (void **)(& pphar));
  if (! pphar) {
    if (phar_globals.manifest_cached) {
      zend_hash_find((HashTable const   *)(& cached_phars),
                     (char const   *)fname, (uint )fname_len, (void **)(& pphar));
    } else {

    }
  } else {

  }
  while (1) {
    tmp___0 = zend_hash_exists((HashTable const   *)(& (*pphar)->manifest),
                               (char const   *)e, (uint )e_len);
    if (tmp___0) {
      if (u) {
        *(u + 0) = (char )'/';
        tmp = _estrndup((char const   *)u, (unsigned int )(u_len + 1));
        *ru = (char *)tmp;
        u_len ++;
        *(u + 0) = (char )'\000';
      } else {
        *ru = (char *)((void *)0);
      }
      *ru_len = u_len;
      *entry_len = e_len + 1;
      return;
    } else {

    }
    if (u) {
      u1 = strrchr((char const   *)e, '/');
      *(u + 0) = (char )'/';
      saveu = u;
      e_len += u_len + 1;
      u = u1;
      if (! u) {
        return;
      } else {

      }
    } else {
      u = strrchr((char const   *)e, '/');
      if (! u) {
        if (saveu) {
          *(saveu + 0) = (char )'/';
        } else {

        }
        return;
      } else {

      }
    }
    *(u + 0) = (char )'\000';
    tmp___1 = strlen((char const   *)(u + 1));
    u_len = (int )tmp___1;
    e_len -= u_len + 1;
    if (e_len < 0) {
      if (saveu) {
        *(saveu + 0) = (char )'/';
      } else {

      }
      return;
    } else {

    }
  }
}
}
void zim_Phar_running(int ht , zval *return_value , zval **return_value_ptr ,
                      zval *this_ptr , int return_value_used ) 
{ 
  char *fname ;
  char *arch ;
  char *entry ;
  int fname_len ;
  int arch_len ;
  int entry_len ;
  zend_bool retphar ;
  int __attribute__((__visibility__("default")))  tmp ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  size_t tmp___1 ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;
  char const   *__s___0 ;
  int __l___0 ;
  zval *__z___0 ;
  int tmp___4 ;
  int tmp___5 ;
  char const   *__s___1 ;
  int __l___1 ;
  zval *__z___1 ;
  char __attribute__((__visibility__("default")))  *tmp___6 ;

  {
  retphar = (zend_bool )1;
  tmp = zend_parse_parameters(ht, "|b", & retphar);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  tmp___0 = zend_get_executed_filename();
  fname = (char *)tmp___0;
  tmp___1 = strlen((char const   *)fname);
  fname_len = (int )tmp___1;
  if (fname_len > 7) {
    tmp___4 = memcmp((void const   *)fname, (void const   *)"phar://",
                     (size_t )7);
    if (! tmp___4) {
      tmp___5 = phar_split_fname(fname, fname_len, & arch, & arch_len, & entry,
                                 & entry_len, 2, 0);
      if (0 == tmp___5) {
        _efree((void *)entry);
        if (retphar) {
          while (1) {
            __s = (char const   *)fname;
            __l = arch_len + 7;
            __z = return_value;
            __z->value.str.len = __l;
            tmp___2 = _estrndup(__s, (unsigned int )__l);
            __z->value.str.val = (char *)tmp___2;
            __z->type = (zend_uchar )6;
            break;
          }
          _efree((void *)arch);
          return;
        } else {
          while (1) {
            __s___0 = (char const   *)arch;
            __l___0 = arch_len;
            __z___0 = return_value;
            __z___0->value.str.len = __l___0;
            __z___0->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s___0));
            __z___0->type = (zend_uchar )6;
            break;
          }
          return;
        }
      } else {

      }
    } else {

    }
  } else {

  }
  while (1) {
    __s___1 = "";
    __l___1 = 0;
    __z___1 = return_value;
    __z___1->value.str.len = __l___1;
    tmp___6 = _estrndup(__s___1, (unsigned int )__l___1);
    __z___1->value.str.val = (char *)tmp___6;
    __z___1->type = (zend_uchar )6;
    break;
  }
  return;
}
}
void zim_Phar_mount(int ht , zval *return_value , zval **return_value_ptr ,
                    zval *this_ptr , int return_value_used ) 
{ 
  char *fname ;
  char *arch ;
  char *entry ;
  char *path ;
  char *actual ;
  int fname_len ;
  int arch_len ;
  int entry_len ;
  int path_len ;
  int actual_len ;
  phar_archive_data **pphar ;
  int __attribute__((__visibility__("default")))  tmp ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  size_t tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int __attribute__((__visibility__("default")))  tmp___4 ;
  int __attribute__((__visibility__("default")))  tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;
  int tmp___8 ;
  int __attribute__((__visibility__("default")))  tmp___9 ;
  int __attribute__((__visibility__("default")))  tmp___10 ;
  int tmp___11 ;
  int tmp___12 ;

  {
  arch = (char *)((void *)0);
  entry = (char *)((void *)0);
  tmp = zend_parse_parameters(ht, "ss", & path, & path_len, & actual,
                              & actual_len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  tmp___0 = zend_get_executed_filename();
  fname = (char *)tmp___0;
  tmp___1 = strlen((char const   *)fname);
  fname_len = (int )tmp___1;
  if (fname_len > 7) {
    tmp___11 = memcmp((void const   *)fname, (void const   *)"phar://",
                      (size_t )7);
    if (tmp___11) {
      goto _L___1;
    } else {
      tmp___12 = phar_split_fname(fname, fname_len, & arch, & arch_len, & entry,
                                  & entry_len, 2, 0);
      if (0 == tmp___12) {
        _efree((void *)entry);
        entry = (char *)((void *)0);
        if (path_len > 7) {
          tmp___2 = memcmp((void const   *)path, (void const   *)"phar://",
                           (size_t )7);
          if (! tmp___2) {
            zend_throw_exception_ex(phar_ce_PharException, 0L,
                                    (char *)"Can only mount internal paths within a phar archive, use a relative path instead of \"%s\"",
                                    path);
            _efree((void *)arch);
            return;
          } else {

          }
        } else {

        }
        carry_on2: 
        tmp___5 = zend_hash_find((HashTable const   *)(& phar_globals.phar_fname_map),
                                 (char const   *)arch, (uint )arch_len,
                                 (void **)(& pphar));
        if (0 != (int )tmp___5) {
          if (phar_globals.manifest_cached) {
            tmp___4 = zend_hash_find((HashTable const   *)(& cached_phars),
                                     (char const   *)arch, (uint )arch_len,
                                     (void **)(& pphar));
            if (0 == (int )tmp___4) {
              tmp___3 = phar_copy_on_write(pphar);
              if (0 == tmp___3) {
                goto carry_on;
              } else {

              }
            } else {

            }
          } else {

          }
          zend_throw_exception_ex(phar_ce_PharException, 0L,
                                  (char *)"%s is not a phar archive, cannot mount",
                                  arch);
          if (arch) {
            _efree((void *)arch);
          } else {

          }
          return;
        } else {

        }
        carry_on: 
        tmp___6 = phar_mount_entry(*pphar, actual, actual_len, path, path_len);
        if (0 != tmp___6) {
          zend_throw_exception_ex(phar_ce_PharException, 0L,
                                  (char *)"Mounting of %s to %s within phar %s failed",
                                  path, actual, arch);
          if (path) {
            if ((unsigned long )path == (unsigned long )entry) {
              _efree((void *)entry);
            } else {

            }
          } else {

          }
          if (arch) {
            _efree((void *)arch);
          } else {

          }
          return;
        } else {

        }
        if (entry) {
          if (path) {
            if ((unsigned long )path == (unsigned long )entry) {
              _efree((void *)entry);
            } else {

            }
          } else {

          }
        } else {

        }
        if (arch) {
          _efree((void *)arch);
        } else {

        }
        return;
      } else {
        goto _L___1;
      }
    }
  } else {
    __repair_del_614__0: /* CIL Label */ 
    _L___1: ;
    if (0 == (int )tmp___10) {
      goto carry_on;
    } else
    if (phar_globals.manifest_cached) {
      tmp___9 = zend_hash_find((HashTable const   *)(& cached_phars),
                               (char const   *)fname, (uint )fname_len,
                               (void **)(& pphar));
      if (0 == (int )tmp___9) {
        tmp___7 = phar_copy_on_write(pphar);
        if (0 == tmp___7) {
          goto carry_on;
        } else {

        }
        goto carry_on;
      } else {
        goto _L;
      }
    } else {
      _L: 
      tmp___8 = phar_split_fname(path, path_len, & arch, & arch_len, & entry,
                                 & entry_len, 2, 0);
      if (0 == tmp___8) {
        path = entry;
        path_len = entry_len;
        goto carry_on2;
      } else {

      }
    }
  }
  zend_throw_exception_ex(phar_ce_PharException, 0L,
                          (char *)"Mounting of %s to %s failed", path, actual);
  return;
}
}
void zim_Phar_webPhar(int ht , zval *return_value , zval **return_value_ptr ,
                      zval *this_ptr , int return_value_used ) 
{ 
  zval *mimeoverride ;
  zval *rewrite ;
  char *alias ;
  char *error ;
  char *index_php ;
  char *f404 ;
  char *ru ;
  int alias_len ;
  int ret ;
  int f404_len ;
  int free_pathinfo ;
  int ru_len ;
  char *fname ;
  char *path_info ;
  char *mime_type ;
  char *entry ;
  char *pt ;
  char const   *basename ;
  int fname_len ;
  int entry_len ;
  int code ;
  int index_php_len ;
  int not_cgi ;
  phar_archive_data *phar ;
  phar_entry_info *info ;
  int __attribute__((__visibility__("default")))  tmp ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  size_t tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  void const   *tmp___5 ;
  HashTable *_server ;
  zval **z_script_name ;
  zval **z_path_info ;
  int __attribute__((__visibility__("default")))  tmp___6 ;
  char *tmp___7 ;
  char __attribute__((__visibility__("default")))  *tmp___8 ;
  void __attribute__((__visibility__("default")))  *tmp___9 ;
  char __attribute__((__visibility__("default")))  *tmp___10 ;
  int __attribute__((__visibility__("default")))  tmp___11 ;
  char __attribute__((__visibility__("default")))  *tmp___12 ;
  char *testit ;
  char __attribute__((__visibility__("default")))  *tmp___13 ;
  char __attribute__((__visibility__("default")))  *tmp___14 ;
  size_t tmp___15 ;
  char __attribute__((__visibility__("default")))  *tmp___16 ;
  char __attribute__((__visibility__("default")))  *tmp___17 ;
  size_t tmp___18 ;
  char __attribute__((__visibility__("default")))  *tmp___19 ;
  char __attribute__((__visibility__("default")))  *tmp___20 ;
  size_t tmp___21 ;
  int tmp___22 ;
  size_t tmp___23 ;
  int tmp___24 ;
  zend_fcall_info fci ;
  zend_fcall_info_cache fcc ;
  zval *params ;
  zval *retval_ptr ;
  zval **zp[1] ;
  void __attribute__((__visibility__("default")))  *tmp___25 ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___26 ;
  int __attribute__((__visibility__("default")))  tmp___27 ;
  int __attribute__((__visibility__("default")))  tmp___28 ;
  char __attribute__((__visibility__("default")))  *tmp___29 ;
  char __attribute__((__visibility__("default")))  *tmp___30 ;
  char *tmp___31 ;
  char sa ;
  sapi_header_line ctr ;
  char *tmp___32 ;
  int __attribute__((__visibility__("default")))  tmp___33 ;
  int __attribute__((__visibility__("default")))  tmp___34 ;
  size_t tmp___35 ;
  int tmp___36 ;
  int tmp___37 ;
  char const   *ext ;
  void const   *tmp___38 ;
  zval **val ;
  zval *__z___0 ;
  zval *__z___1 ;
  size_t tmp___39 ;
  int __attribute__((__visibility__("default")))  tmp___40 ;
  int __attribute__((__visibility__("default")))  tmp___41 ;

  {
  mimeoverride = (zval *)((void *)0);
  rewrite = (zval *)((void *)0);
  alias = (char *)((void *)0);
  index_php = (char *)((void *)0);
  f404 = (char *)((void *)0);
  ru = (char *)((void *)0);
  alias_len = 0;
  f404_len = 0;
  free_pathinfo = 0;
  ru_len = 0;
  mime_type = (char *)((void *)0);
  index_php_len = 0;
  phar = (phar_archive_data *)((void *)0);
  tmp = zend_parse_parameters(ht, "|s!s!saz", & alias, & alias_len, & index_php,
                              & index_php_len, & f404, & f404_len,
                              & mimeoverride, & rewrite);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  phar_request_initialize();
  tmp___0 = zend_get_executed_filename();
  fname = (char *)tmp___0;
  tmp___1 = strlen((char const   *)fname);
  fname_len = (int )tmp___1;
  tmp___2 = phar_open_executed_filename(alias, alias_len, & error);
  if (tmp___2 != 0) {
    if (error) {
      zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
      _efree((void *)error);
    } else {

    }
    return;
  } else {

  }
  if (sapi_globals.request_info.request_method) {
    if (sapi_globals.request_info.request_uri) {
      tmp___3 = strcmp(sapi_globals.request_info.request_method, "GET");
      if (tmp___3) {
        tmp___4 = strcmp(sapi_globals.request_info.request_method, "POST");
        if (tmp___4) {
          return;
        } else {

        }
      } else {

      }
    } else {
      return;
    }
  } else {
    return;
  }
  tmp___5 = zend_memrchr((void const   *)fname, '/', (size_t )fname_len);
  basename = (char const   *)tmp___5;
  if (! basename) {
    basename = (char const   *)fname;
  } else {
    basename ++;
  }
  tmp___21 = strlen((char const   *)sapi_module.name);
  if (tmp___21 == sizeof("cgi-fcgi") - 1UL) {
    tmp___22 = strncmp((char const   *)sapi_module.name, "cgi-fcgi",
                       sizeof("cgi-fcgi") - 1UL);
    if (tmp___22) {
      goto _L___1;
    } else {
      goto _L;
    }
  } else {
    _L___1: 
    tmp___23 = strlen((char const   *)sapi_module.name);
    if (tmp___23 == sizeof("cgi") - 1UL) {
      tmp___24 = strncmp((char const   *)sapi_module.name, "cgi",
                         sizeof("cgi") - 1UL);
      if (tmp___24) {
        goto _L___0;
      } else {
        _L: 
        if (core_globals.http_globals[3]) {
          _server = (core_globals.http_globals[3])->value.ht;
          tmp___6 = zend_hash_find((HashTable const   *)_server, "SCRIPT_NAME",
                                   (uint )sizeof("SCRIPT_NAME"),
                                   (void **)(& z_script_name));
          if (0 != (int )tmp___6) {
            return;
          } else
          if (6 != (int )(*z_script_name)->type) {
            return;
          } else {
            tmp___7 = strstr((char const   *)(*z_script_name)->value.str.val,
                             basename);
            if (! tmp___7) {
              return;
            } else {

            }
          }
          tmp___11 = zend_hash_find((HashTable const   *)_server, "PATH_INFO",
                                    (uint )sizeof("PATH_INFO"),
                                    (void **)(& z_path_info));
          if (0 == (int )tmp___11) {
            if (6 == (int )(*z_path_info)->type) {
              entry_len = (*z_path_info)->value.str.len;
              tmp___8 = _estrndup((char const   *)(*z_path_info)->value.str.val,
                                  (unsigned int )entry_len);
              entry = (char *)tmp___8;
              tmp___9 = _emalloc((size_t )(((*z_script_name)->value.str.len + entry_len) + 1));
              path_info = (char *)tmp___9;
              memcpy((void */* __restrict  */)path_info,
                     (void const   */* __restrict  */)(*z_script_name)->value.str.val,
                     (size_t )(*z_script_name)->value.str.len);
              memcpy((void */* __restrict  */)(path_info + (*z_script_name)->value.str.len),
                     (void const   */* __restrict  */)entry,
                     (size_t )(entry_len + 1));
              free_pathinfo = 1;
            } else {
              entry_len = 0;
              tmp___10 = _estrndup("", 0U);
              entry = (char *)tmp___10;
              path_info = (*z_script_name)->value.str.val;
            }
          } else {
            entry_len = 0;
            tmp___10 = _estrndup("", 0U);
            entry = (char *)tmp___10;
            path_info = (*z_script_name)->value.str.val;
          }
          tmp___12 = _estrndup((char const   *)(*z_script_name)->value.str.val,
                               (unsigned int )(*z_script_name)->value.str.len);
          pt = (char *)tmp___12;
        } else {
          tmp___13 = sapi_getenv((char *)"SCRIPT_NAME",
                                 sizeof("SCRIPT_NAME") - 1UL);
          testit = (char *)tmp___13;
          pt = strstr((char const   *)testit, basename);
          if (! pt) {
            _efree((void *)testit);
            return;
          } else {

          }
          tmp___14 = sapi_getenv((char *)"PATH_INFO", sizeof("PATH_INFO") - 1UL);
          path_info = (char *)tmp___14;
          if (path_info) {
            entry = path_info;
            tmp___15 = strlen((char const   *)entry);
            entry_len = (int )tmp___15;
            spprintf(& path_info, (size_t )0, "%s%s", testit, path_info);
            free_pathinfo = 1;
          } else {
            path_info = testit;
            free_pathinfo = 1;
            tmp___16 = _estrndup("", 0U);
            entry = (char *)tmp___16;
            entry_len = 0;
          }
          tmp___17 = _estrndup((char const   *)testit,
                               (unsigned int )((pt - testit) + ((long )fname_len - (basename - (char const   *)fname))));
          pt = (char *)tmp___17;
        }
        not_cgi = 0;
      }
    } else {
      _L___0: 
      path_info = sapi_globals.request_info.request_uri;
      pt = strstr((char const   *)path_info, basename);
      if (! pt) {
        return;
      } else {

      }
      tmp___18 = strlen((char const   *)path_info);
      entry_len = (int )tmp___18;
      entry_len = (int )((long )entry_len - ((pt - path_info) + ((long )fname_len - (basename - (char const   *)fname))));
      tmp___19 = _estrndup((char const   *)(pt + ((long )fname_len - (basename - (char const   *)fname))),
                           (unsigned int )entry_len);
      entry = (char *)tmp___19;
      tmp___20 = _estrndup((char const   *)path_info,
                           (unsigned int )((pt - path_info) + ((long )fname_len - (basename - (char const   *)fname))));
      pt = (char *)tmp___20;
      not_cgi = 1;
    }
  }
  if (rewrite) {
    while (1) {
      tmp___25 = _emalloc(sizeof(zval_gc_info ));
      params = (zval *)tmp___25;
      ((zval_gc_info *)params)->u.buffered = (gc_root_buffer *)((void *)0);
      break;
    }
    params->refcount__gc = (zend_uint )1;
    params->is_ref__gc = (zend_uchar )0;
    while (1) {
      __s = (char const   *)entry;
      __l = entry_len;
      __z = params;
      __z->value.str.len = __l;
      tmp___26 = _estrndup(__s, (unsigned int )__l);
      __z->value.str.val = (char *)tmp___26;
      __z->type = (zend_uchar )6;
      break;
    }
    zp[0] = & params;
    tmp___27 = zend_fcall_info_init(rewrite, (uint )0, & fci, & fcc,
                                    (char **)((void *)0), (char **)((void *)0));
    if (-1 == (int )tmp___27) {
      zend_throw_exception_ex(phar_ce_PharException, 0L,
                              (char *)"phar error: invalid rewrite callback");
      if (free_pathinfo) {
        _efree((void *)path_info);
      } else {

      }
      return;
    } else {

    }
    fci.param_count = (zend_uint )1;
    fci.params = zp;
    zval_addref_p(params);
    fci.retval_ptr_ptr = & retval_ptr;
    tmp___28 = zend_call_function(& fci, & fcc);
    if (-1 == (int )tmp___28) {
      if (! executor_globals.exception) {
        zend_throw_exception_ex(phar_ce_PharException, 0L,
                                (char *)"phar error: failed to call rewrite callback");
      } else {

      }
      if (free_pathinfo) {
        _efree((void *)path_info);
      } else {

      }
      return;
    } else {

    }
    if (! fci.retval_ptr_ptr) {
      goto _L___2;
    } else
    if (! retval_ptr) {
      _L___2: 
      if (free_pathinfo) {
        _efree((void *)path_info);
      } else {

      }
      zend_throw_exception_ex(phar_ce_PharException, 0L,
                              (char *)"phar error: rewrite callback must return a string or false");
      return;
    } else {

    }
    switch ((int )retval_ptr->type) {
    case 6: 
    _efree((void *)entry);
    if ((unsigned long )fci.retval_ptr_ptr != (unsigned long )(& retval_ptr)) {
      tmp___29 = _estrndup((char const   *)(*(fci.retval_ptr_ptr))->value.str.val,
                           (unsigned int )(*(fci.retval_ptr_ptr))->value.str.len);
      entry = (char *)tmp___29;
      entry_len = (*(fci.retval_ptr_ptr))->value.str.len;
    } else {
      entry = retval_ptr->value.str.val;
      entry_len = retval_ptr->value.str.len;
    }
    break;
    case 3: 
    phar_do_403(entry, entry_len);
    if (free_pathinfo) {
      _efree((void *)path_info);
    } else {

    }
    _zend_bailout((char *)"/data/manybugs/php/3acdca4703/src/ext/phar/phar_object.c",
                  (uint )849);
    return;
    default: 
    _efree((void *)retval_ptr);
    if (free_pathinfo) {
      _efree((void *)path_info);
    } else {

    }
    zend_throw_exception_ex(phar_ce_PharException, 0L,
                            (char *)"phar error: rewrite callback must return a string or false");
    return;
    }
  } else {

  }
  if (entry_len) {
    phar_postprocess_ru_web(fname, fname_len, & entry, & entry_len, & ru,
                            & ru_len);
  } else {

  }
  if (! entry_len) {
    goto _L___4;
  } else
  if (entry_len == 1) {
    if ((int )*(entry + 0) == 47) {
      _L___4: 
      _efree((void *)entry);
      if (index_php_len) {
        entry = index_php;
        entry_len = index_php_len;
        if ((int )*(entry + 0) != 47) {
          spprintf(& entry, (size_t )0, "/%s", index_php);
          entry_len ++;
        } else {

        }
      } else {
        tmp___30 = _estrndup("/index.php", (unsigned int )sizeof("/index.php"));
        entry = (char *)tmp___30;
        entry_len = (int )(sizeof("/index.php") - 1UL);
      }
      tmp___36 = phar_get_archive(& phar, fname, fname_len, (char *)((void *)0),
                                  0, (char **)((void *)0));
      if (-1 == tmp___36) {
        goto _L___3;
      } else {
        info = phar_get_entry_info(phar, entry, entry_len, (char **)((void *)0),
                                   0);
        if ((unsigned long )info == (unsigned long )((void *)0)) {
          _L___3: 
          phar_do_404(phar, fname, fname_len, f404, f404_len, entry, entry_len);
          if (free_pathinfo) {
            _efree((void *)path_info);
          } else {

          }
          _zend_bailout((char *)"/data/manybugs/php/3acdca4703/src/ext/phar/phar_object.c",
                        (uint )891);
        } else {
          ctr.line = (char *)0;
          ctr.line_len = 0U;
          ctr.response_code = 0L;
          ctr.response_code = 301L;
          ctr.line_len = (uint )(sizeof("HTTP/1.1 301 Moved Permanently") + 1UL);
          ctr.line = (char *)"HTTP/1.1 301 Moved Permanently";
          sapi_header_op((sapi_header_op_enum )0, (void *)(& ctr));
          if (not_cgi) {
            tmp___32 = strstr((char const   *)path_info, basename);
            tmp___31 = tmp___32 + fname_len;
            sa = *tmp___31;
            *tmp___31 = (char )'\000';
          } else {

          }
          ctr.response_code = 0L;
          tmp___35 = strlen((char const   *)path_info);
          if ((int )*(path_info + (tmp___35 - 1UL)) == 47) {
            tmp___33 = spprintf(& ctr.line, (size_t )4096, "Location: %s%s",
                                path_info, entry + 1);
            ctr.line_len = (uint )tmp___33;
          } else {
            tmp___34 = spprintf(& ctr.line, (size_t )4096, "Location: %s%s",
                                path_info, entry);
            ctr.line_len = (uint )tmp___34;
          }
          if (not_cgi) {
            *tmp___31 = sa;
          } else {

          }
          if (free_pathinfo) {
            _efree((void *)path_info);
          } else {

          }
          sapi_header_op((sapi_header_op_enum )0, (void *)(& ctr));
          sapi_send_headers();
          _efree((void *)ctr.line);
          _zend_bailout((char *)"/data/manybugs/php/3acdca4703/src/ext/phar/phar_object.c",
                        (uint )925);
        }
      }
    } else {

    }
  } else {

  }
  tmp___37 = phar_get_archive(& phar, fname, fname_len, (char *)((void *)0), 0,
                              (char **)((void *)0));
  if (-1 == tmp___37) {
    phar_do_404(phar, fname, fname_len, f404, f404_len, entry, entry_len);
    _zend_bailout((char *)"/data/manybugs/php/3acdca4703/src/ext/phar/phar_object.c",
                  (uint )935);
  } else {
    info = phar_get_entry_info(phar, entry, entry_len, (char **)((void *)0), 0);
    if ((unsigned long )info == (unsigned long )((void *)0)) {
      phar_do_404(phar, fname, fname_len, f404, f404_len, entry, entry_len);
      _zend_bailout((char *)"/data/manybugs/php/3acdca4703/src/ext/phar/phar_object.c",
                    (uint )935);
    } else {

    }
  }
  if (mimeoverride) {
    tmp___41 = zend_hash_num_elements((HashTable const   *)mimeoverride->value.ht);
    if (tmp___41) {
      tmp___38 = zend_memrchr((void const   *)entry, '.', (size_t )entry_len);
      ext = (char const   *)tmp___38;
      if (ext) {
        ext ++;
        tmp___39 = strlen(ext);
        tmp___40 = zend_hash_find((HashTable const   *)mimeoverride->value.ht,
                                  ext, (uint )(tmp___39 + 1UL), (void **)(& val));
        if (0 == (int )tmp___40) {
          switch ((int )(*val)->type) {
          case 1: 
          if ((*val)->value.lval == 0L) {
            mime_type = (char *)"";
            code = (int )(*val)->value.lval;
          } else
          if ((*val)->value.lval == 1L) {
            mime_type = (char *)"";
            code = (int )(*val)->value.lval;
          } else {
            zend_throw_exception_ex(phar_ce_PharException, 0L,
                                    (char *)"Unknown mime type specifier used, only Phar::PHP, Phar::PHPS and a mime type string are allowed");
            while (1) {
              __z___0 = return_value;
              __z___0->value.lval = 0L;
              __z___0->type = (zend_uchar )3;
              break;
            }
            return;
          }
          break;
          case 6: 
          mime_type = (*val)->value.str.val;
          code = '\002';
          break;
          default: 
          zend_throw_exception_ex(phar_ce_PharException, 0L,
                                  (char *)"Unknown mime type specifier used (not a string or int), only Phar::PHP, Phar::PHPS and a mime type string are allowed");
          while (1) {
            __z___1 = return_value;
            __z___1->value.lval = 0L;
            __z___1->type = (zend_uchar )3;
            break;
          }
          return;
          }
        } else {

        }
      } else {

      }
    } else {

    }
  } else {

  }
  if (! mime_type) {
    code = phar_file_type(& phar_globals.mime_types, entry, & mime_type);
  } else {

  }
  ret = phar_file_action(phar, info, mime_type, code, entry, entry_len, fname,
                         pt, ru, ru_len);
  return;
}
}
void zim_Phar_mungServer(int ht , zval *return_value , zval **return_value_ptr ,
                         zval *this_ptr , int return_value_used ) 
{ 
  zval *mungvalues ;
  int __attribute__((__visibility__("default")))  tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;
  zval **data ;
  int __attribute__((__visibility__("default")))  tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;
  int tmp___8 ;
  int __attribute__((__visibility__("default")))  tmp___9 ;

  {
  tmp = zend_parse_parameters(ht, "a", & mungvalues);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  tmp___0 = zend_hash_num_elements((HashTable const   *)mungvalues->value.ht);
  if (! tmp___0) {
    zend_throw_exception_ex(phar_ce_PharException, 0L,
                            (char *)"No values passed to Phar::mungServer(), expecting an array of any of these strings: PHP_SELF, REQUEST_URI, SCRIPT_FILENAME, SCRIPT_NAME");
    return;
  } else {

  }
  tmp___1 = zend_hash_num_elements((HashTable const   *)mungvalues->value.ht);
  if (tmp___1 > (int __attribute__((__visibility__("default")))  )4) {
    zend_throw_exception_ex(phar_ce_PharException, 0L,
                            (char *)"Too many values passed to Phar::mungServer(), expecting an array of any of these strings: PHP_SELF, REQUEST_URI, SCRIPT_FILENAME, SCRIPT_NAME");
    return;
  } else {

  }
  phar_request_initialize();
  zend_hash_internal_pointer_reset_ex(mungvalues->value.ht,
                                      (HashPosition *)((void *)0));
  while (1) {
    tmp___9 = zend_hash_get_current_key_type_ex(mungvalues->value.ht,
                                                (HashPosition *)((void *)0));
    if (tmp___9 == (int __attribute__((__visibility__("default")))  )3) {
      tmp___8 = -1;
    } else {
      tmp___8 = 0;
    }
    if (! (0 == tmp___8)) {
      break;
    } else {

    }
    data = (zval **)((void *)0);
    tmp___2 = zend_hash_get_current_data_ex(mungvalues->value.ht,
                                            (void **)(& data),
                                            (HashPosition *)((void *)0));
    if (0 != (int )tmp___2) {
      zend_throw_exception_ex(phar_ce_PharException, 0L,
                              (char *)"unable to retrieve array value in Phar::mungServer()");
      return;
    } else {

    }
    if ((int )(*data)->type != 6) {
      zend_throw_exception_ex(phar_ce_PharException, 0L,
                              (char *)"Non-string value passed to Phar::mungServer(), expecting an array of any of these strings: PHP_SELF, REQUEST_URI, SCRIPT_FILENAME, SCRIPT_NAME");
      return;
    } else {

    }
    if ((unsigned long )(*data)->value.str.len == sizeof("PHP_SELF") - 1UL) {
      tmp___3 = strncmp((char const   *)(*data)->value.str.val, "PHP_SELF",
                        sizeof("PHP_SELF") - 1UL);
      if (! tmp___3) {
        phar_globals.phar_SERVER_mung_list |= 1;
      } else {

      }
    } else {

    }
    if ((unsigned long )(*data)->value.str.len == sizeof("REQUEST_URI") - 1UL) {
      tmp___4 = strncmp((char const   *)(*data)->value.str.val, "REQUEST_URI",
                        sizeof("REQUEST_URI") - 1UL);
      if (! tmp___4) {
        phar_globals.phar_SERVER_mung_list |= 1 << 1;
      } else {

      }
      tmp___5 = strncmp((char const   *)(*data)->value.str.val, "SCRIPT_NAME",
                        sizeof("SCRIPT_NAME") - 1UL);
      if (! tmp___5) {
        phar_globals.phar_SERVER_mung_list |= 1 << 2;
      } else {

      }
    } else {

    }
    if ((unsigned long )(*data)->value.str.len == sizeof("SCRIPT_FILENAME") - 1UL) {
      tmp___6 = strncmp((char const   *)(*data)->value.str.val,
                        "SCRIPT_FILENAME", sizeof("SCRIPT_FILENAME") - 1UL);
      if (! tmp___6) {
        phar_globals.phar_SERVER_mung_list |= 1 << 3;
      } else {

      }
    } else {

    }
    zend_hash_move_forward_ex(mungvalues->value.ht, (HashPosition *)((void *)0));
  }
  return;
}
}
void zim_Phar_interceptFileFuncs(int ht , zval *return_value ,
                                 zval **return_value_ptr , zval *this_ptr ,
                                 int return_value_used ) 
{ 


  {
  phar_intercept_functions();
  return;
}
}
void zim_Phar_createDefaultStub(int ht , zval *return_value ,
                                zval **return_value_ptr , zval *this_ptr ,
                                int return_value_used ) 
{ 
  char *index___0 ;
  char *webindex ;
  char *stub ;
  char *error ;
  int index_len ;
  int webindex_len ;
  size_t stub_len ;
  int __attribute__((__visibility__("default")))  tmp ;
  char const   *__s ;
  int __l ;
  zval *__z ;

  {
  index___0 = (char *)((void *)0);
  webindex = (char *)((void *)0);
  index_len = 0;
  webindex_len = 0;
  tmp = zend_parse_parameters(ht, "|ss", & index___0, & index_len, & webindex,
                              & webindex_len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  stub = phar_create_default_stub((char const   *)index___0,
                                  (char const   *)webindex, & stub_len, & error);
  if (error) {
    zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
    _efree((void *)error);
    return;
  } else {

  }
  while (1) {
    __s = (char const   *)stub;
    __l = (int )stub_len;
    __z = return_value;
    __z->value.str.len = __l;
    __z->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z->type = (zend_uchar )6;
    break;
  }
  return;
}
}
void zim_Phar_mapPhar(int ht , zval *return_value , zval **return_value_ptr ,
                      zval *this_ptr , int return_value_used ) 
{ 
  char *alias ;
  char *error ;
  int alias_len ;
  long dataoffset ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  int tmp___0 ;

  {
  alias = (char *)((void *)0);
  alias_len = 0;
  dataoffset = 0L;
  tmp = zend_parse_parameters(ht, "|s!l", & alias, & alias_len, & dataoffset);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  phar_request_initialize();
  while (1) {
    __z = return_value;
    tmp___0 = phar_open_executed_filename(alias, alias_len, & error);
    __z->value.lval = (long )((tmp___0 == 0) != 0);
    __z->type = (zend_uchar )3;
    break;
  }
  if (error) {
    zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
    _efree((void *)error);
  } else {

  }
  return;
}
}
void zim_Phar_loadPhar(int ht , zval *return_value , zval **return_value_ptr ,
                       zval *this_ptr , int return_value_used ) 
{ 
  char *fname ;
  char *alias ;
  char *error ;
  int fname_len ;
  int alias_len ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  int tmp___0 ;

  {
  alias = (char *)((void *)0);
  alias_len = 0;
  tmp = zend_parse_parameters(ht, "s|s!", & fname, & fname_len, & alias,
                              & alias_len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  phar_request_initialize();
  while (1) {
    __z = return_value;
    tmp___0 = phar_open_from_filename(fname, fname_len, alias, alias_len, 8,
                                      (phar_archive_data **)((void *)0), & error);
    __z->value.lval = (long )((tmp___0 == 0) != 0);
    __z->type = (zend_uchar )3;
    break;
  }
  if (error) {
    zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
    _efree((void *)error);
  } else {

  }
  return;
}
}
void zim_Phar_apiVersion(int ht , zval *return_value , zval **return_value_ptr ,
                         zval *this_ptr , int return_value_used ) 
{ 
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp ;

  {
  while (1) {
    __s = "1.1.1";
    __l = (int )(sizeof("1.1.1") - 1UL);
    __z = return_value;
    __z->value.str.len = __l;
    tmp = _estrndup(__s, (unsigned int )__l);
    __z->value.str.val = (char *)tmp;
    __z->type = (zend_uchar )6;
    break;
  }
  return;
}
}
void zim_Phar_canCompress(int ht , zval *return_value ,
                          zval **return_value_ptr , zval *this_ptr ,
                          int return_value_used ) 
{ 
  long method ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  zval *__z___0 ;
  zval *__z___1 ;
  zval *__z___2 ;
  zval *__z___3 ;
  zval *__z___4 ;

  {
  method = 0L;
  tmp = zend_parse_parameters(ht, "|l", & method);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  phar_request_initialize();
  switch (method) {
  case 4096L: 
  if (phar_globals.has_zlib) {
    while (1) {
      __z = return_value;
      __z->value.lval = 1L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {
    while (1) {
      __z___0 = return_value;
      __z___0->value.lval = 0L;
      __z___0->type = (zend_uchar )3;
      break;
    }
    return;
  }
  case 8192L: 
  if (phar_globals.has_bz2) {
    while (1) {
      __z___1 = return_value;
      __z___1->value.lval = 1L;
      __z___1->type = (zend_uchar )3;
      break;
    }
    return;
  } else {
    while (1) {
      __z___2 = return_value;
      __z___2->value.lval = 0L;
      __z___2->type = (zend_uchar )3;
      break;
    }
    return;
  }
  default: 
  if (phar_globals.has_zlib) {
    goto _L;
  } else
  if (phar_globals.has_bz2) {
    _L: 
    while (1) {
      __z___3 = return_value;
      __z___3->value.lval = 1L;
      __z___3->type = (zend_uchar )3;
      break;
    }
    return;
  } else {
    while (1) {
      __z___4 = return_value;
      __z___4->value.lval = 0L;
      __z___4->type = (zend_uchar )3;
      break;
    }
    return;
  }
  }
}
}
void zim_Phar_canWrite(int ht , zval *return_value , zval **return_value_ptr ,
                       zval *this_ptr , int return_value_used ) 
{ 
  zval *__z ;

  {
  while (1) {
    __z = return_value;
    __z->value.lval = (long )(! phar_globals.readonly != 0);
    __z->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zim_Phar_isValidPharFilename(int ht , zval *return_value ,
                                  zval **return_value_ptr , zval *this_ptr ,
                                  int return_value_used ) 
{ 
  char *fname ;
  char const   *ext_str ;
  int fname_len ;
  int ext_len ;
  int is_executable ;
  zend_bool executable ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  int tmp___0 ;

  {
  executable = (zend_bool )1;
  tmp = zend_parse_parameters(ht, "s|b", & fname, & fname_len, & executable);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  is_executable = (int )executable;
  while (1) {
    __z = return_value;
    tmp___0 = phar_detect_phar_fname_ext((char const   *)fname, fname_len,
                                         & ext_str, & ext_len, is_executable, 2,
                                         1);
    __z->value.lval = (long )((tmp___0 == 0) != 0);
    __z->type = (zend_uchar )3;
    break;
  }
  return;
}
}
static void phar_spl_foreign_dtor(spl_filesystem_object *object ) 
{ 
  phar_archive_data *phar ;

  {
  phar = (phar_archive_data *)object->oth;
  if (! phar->is_persistent) {
    phar_archive_delref(phar);
  } else {

  }
  object->oth = (void *)0;
  return;
}
}
static void phar_spl_foreign_clone(spl_filesystem_object *src ,
                                   spl_filesystem_object *dst ) 
{ 
  phar_archive_data *phar_data ;

  {
  phar_data = (phar_archive_data *)dst->oth;
  if (! phar_data->is_persistent) {
    (phar_data->refcount) ++;
  } else {

  }
  return;
}
}
static spl_other_handler phar_spl_foreign_handler  =    {& phar_spl_foreign_dtor, & phar_spl_foreign_clone};
void zim_Phar___construct(int ht , zval *return_value ,
                          zval **return_value_ptr , zval *this_ptr ,
                          int return_value_used ) 
{ 
  char *fname ;
  char *alias ;
  char *error ;
  char *arch ;
  char *entry ;
  char *save_fname ;
  int fname_len ;
  int alias_len ;
  int arch_len ;
  int entry_len ;
  int is_data ;
  long flags ;
  long format ;
  phar_archive_object *phar_obj ;
  phar_archive_data *phar_data ;
  zval *zobj ;
  zval arg1 ;
  zval arg2 ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp___0 ;
  zend_bool __attribute__((__visibility__("default")))  tmp___1 ;
  int __attribute__((__visibility__("default")))  tmp___2 ;
  int __attribute__((__visibility__("default")))  tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  int __attribute__((__visibility__("default")))  tmp___6 ;
  int __attribute__((__visibility__("default")))  tmp___7 ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  zval *__z___0 ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp___9 ;

  {
  alias = (char *)((void *)0);
  arch = (char *)((void *)0);
  entry = (char *)((void *)0);
  alias_len = 0;
  flags = 12288L;
  format = 0L;
  zobj = this_ptr;
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  tmp___0 = zend_get_class_entry((zval const   *)zobj);
  tmp___1 = instanceof_function((zend_class_entry const   *)tmp___0,
                                (zend_class_entry const   *)phar_ce_data);
  is_data = (int )tmp___1;
  if (is_data) {
    tmp___2 = zend_parse_parameters(ht, "s|ls!l", & fname, & fname_len, & flags,
                                    & alias, & alias_len, & format);
    if (tmp___2 == (int __attribute__((__visibility__("default")))  )-1) {
      return;
    } else {

    }
  } else {
    tmp___3 = zend_parse_parameters(ht, "s|ls!", & fname, & fname_len, & flags,
                                    & alias, & alias_len);
    if (tmp___3 == (int __attribute__((__visibility__("default")))  )-1) {
      return;
    } else {

    }
  }
  if (phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L, (char *)"Cannot call constructor twice");
    return;
  } else {

  }
  save_fname = fname;
  tmp___4 = phar_split_fname(fname, fname_len, & arch, & arch_len, & entry,
                             & entry_len, ! is_data, 2);
  if (0 == tmp___4) {
    fname = arch;
    fname_len = arch_len;
  } else {

  }
  tmp___5 = phar_open_or_create_filename(fname, fname_len, alias, alias_len,
                                         is_data, 8, & phar_data, & error);
  if (tmp___5 == -1) {
    if ((unsigned long )fname == (unsigned long )arch) {
      if ((unsigned long )fname != (unsigned long )save_fname) {
        _efree((void *)arch);
        fname = save_fname;
      } else {

      }
    } else {

    }
    if (entry) {
      _efree((void *)entry);
    } else {

    }
    if (error) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L, (char *)"%s", error);
      _efree((void *)error);
    } else {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L, (char *)"Phar creation or opening failed");
    }
    return;
  } else {

  }
  if (is_data) {
    if (phar_data->is_tar) {
      if (phar_data->is_brandnew) {
        if (format == 3L) {
          phar_data->is_zip = 1U;
          phar_data->is_tar = 0U;
        } else {

        }
      } else {

      }
    } else {

    }
  } else {

  }
  if ((unsigned long )fname == (unsigned long )arch) {
    _efree((void *)arch);
    fname = save_fname;
  } else {

  }
  if (is_data) {
    if (! phar_data->is_data) {
      goto _L;
    } else {
      goto _L___0;
    }
  } else
  _L___0: 
  if (! is_data) {
    if (phar_data->is_data) {
      _L: 
      if (is_data) {
        zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                                0L,
                                (char *)"PharData class can only be used for non-executable tar and zip archives");
      } else {
        zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                                0L,
                                (char *)"Phar class can only be used for executable tar and zip archives");
      }
      _efree((void *)entry);
      return;
    } else {

    }
  } else {

  }
  is_data = (int )phar_data->is_data;
  if (! phar_data->is_persistent) {
    (phar_data->refcount) ++;
  } else {

  }
  phar_obj->arc.archive = phar_data;
  phar_obj->spl.oth_handler = & phar_spl_foreign_handler;
  if (entry) {
    tmp___6 = spprintf(& fname, (size_t )0, "phar://%s%s", phar_data->fname,
                       entry);
    fname_len = (int )tmp___6;
    _efree((void *)entry);
  } else {
    tmp___7 = spprintf(& fname, (size_t )0, "phar://%s", phar_data->fname);
    fname_len = (int )tmp___7;
  }
  arg1.refcount__gc = (zend_uint )1;
  arg1.is_ref__gc = (zend_uchar )0;
  while (1) {
    __s = (char const   *)fname;
    __l = fname_len;
    __z = & arg1;
    __z->value.str.len = __l;
    __z->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z->type = (zend_uchar )6;
    break;
  }
  arg2.refcount__gc = (zend_uint )1;
  arg2.is_ref__gc = (zend_uchar )0;
  __z___0 = & arg2;
  __z___0->value.lval = flags;
  __z___0->type = (zend_uchar )1;
  tmp___9 = zend_get_class_entry((zval const   *)zobj);
  zend_call_method(& zobj, (zend_class_entry *)tmp___9,
                   & spl_ce_RecursiveDirectoryIterator->constructor,
                   (char *)"__construct", (int )(sizeof("__construct") - 1UL),
                   (zval **)((void *)0), 2, & arg1, & arg2);
  if (! phar_data->is_persistent) {
    (phar_obj->arc.archive)->is_data = (unsigned int )is_data;
  } else
  if (! executor_globals.exception) {
    _zend_hash_add_or_update(& phar_globals.phar_persist_map,
                             (char const   *)phar_obj->arc.archive,
                             (uint )sizeof(phar_obj->arc.archive),
                             (void *)(& phar_obj),
                             (uint )sizeof(phar_archive_object **),
                             (void **)((void *)0), 1 << 1);
  } else {

  }
  phar_obj->spl.info_class = phar_ce_entry;
  _efree((void *)fname);
  return;
}
}
void zim_Phar_getSupportedSignatures(int ht , zval *return_value ,
                                     zval **return_value_ptr , zval *this_ptr ,
                                     int return_value_used ) 
{ 
  int __attribute__((__visibility__("default")))  tmp ;

  {
  _array_init(return_value, (uint )0);
  add_next_index_stringl(return_value, "MD5", (uint )3, 1);
  add_next_index_stringl(return_value, "SHA-1", (uint )5, 1);
  add_next_index_stringl(return_value, "SHA-256", (uint )7, 1);
  add_next_index_stringl(return_value, "SHA-512", (uint )7, 1);
  tmp = zend_hash_exists((HashTable const   *)(& module_registry), "openssl",
                         (uint )sizeof("openssl"));
  if (tmp) {
    add_next_index_stringl(return_value, "OpenSSL", (uint )7, 1);
  } else {

  }
  return;
}
}
void zim_Phar_getSupportedCompression(int ht , zval *return_value ,
                                      zval **return_value_ptr , zval *this_ptr ,
                                      int return_value_used ) 
{ 


  {
  _array_init(return_value, (uint )0);
  phar_request_initialize();
  if (phar_globals.has_zlib) {
    add_next_index_stringl(return_value, "GZ", (uint )2, 1);
  } else {

  }
  if (phar_globals.has_bz2) {
    add_next_index_stringl(return_value, "BZIP2", (uint )5, 1);
  } else {

  }
  return;
}
}
void zim_Phar_unlinkArchive(int ht , zval *return_value ,
                            zval **return_value_ptr , zval *this_ptr ,
                            int return_value_used ) 
{ 
  char *fname ;
  char *error ;
  char *zname ;
  char *arch ;
  char *entry ;
  int fname_len ;
  int zname_len ;
  int arch_len ;
  int entry_len ;
  phar_archive_data *phar ;
  zval *__z ;
  int __attribute__((__visibility__("default")))  tmp ;
  int tmp___0 ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  size_t tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  char __attribute__((__visibility__("default")))  *tmp___6 ;
  zval *__z___0 ;

  {
  tmp = zend_parse_parameters(ht, "s", & fname, & fname_len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  if (! fname_len) {
    zend_throw_exception_ex(phar_ce_PharException, 0L,
                            (char *)"Unknown phar archive \"\"");
    return;
  } else {

  }
  tmp___0 = phar_open_from_filename(fname, fname_len, (char *)((void *)0), 0, 8,
                                    & phar, & error);
  if (-1 == tmp___0) {
    if (error) {
      zend_throw_exception_ex(phar_ce_PharException, 0L,
                              (char *)"Unknown phar archive \"%s\": %s", fname,
                              error);
      _efree((void *)error);
    } else {
      zend_throw_exception_ex(phar_ce_PharException, 0L,
                              (char *)"Unknown phar archive \"%s\"", fname);
    }
    return;
  } else {

  }
  tmp___1 = zend_get_executed_filename();
  zname = (char *)tmp___1;
  tmp___2 = strlen((char const   *)zname);
  zname_len = (int )tmp___2;
  if (zname_len > 7) {
    tmp___4 = memcmp((void const   *)zname, (void const   *)"phar://",
                     (size_t )7);
    if (! tmp___4) {
      tmp___5 = phar_split_fname(zname, zname_len, & arch, & arch_len, & entry,
                                 & entry_len, 2, 0);
      if (0 == tmp___5) {
        if (arch_len == fname_len) {
          tmp___3 = memcmp((void const   *)arch, (void const   *)fname,
                           (size_t )arch_len);
          if (! tmp___3) {
            zend_throw_exception_ex(phar_ce_PharException, 0L,
                                    (char *)"phar archive \"%s\" cannot be unlinked from within itself",
                                    fname);
            _efree((void *)arch);
            _efree((void *)entry);
            return;
          } else {

          }
        } else {

        }
        _efree((void *)arch);
        _efree((void *)entry);
      } else {

      }
    } else {

    }
  } else {

  }
  if (phar->is_persistent) {
    zend_throw_exception_ex(phar_ce_PharException, 0L,
                            (char *)"phar archive \"%s\" is in phar.cache_list, cannot unlinkArchive()",
                            fname);
    return;
  } else {

  }
  if (phar->refcount) {
    zend_throw_exception_ex(phar_ce_PharException, 0L,
                            (char *)"phar archive \"%s\" has open file handles or objects.  fclose() all file handles, and unset() all objects prior to calling unlinkArchive()",
                            fname);
    return;
  } else {

  }
  tmp___6 = _estrndup((char const   *)phar->fname,
                      (unsigned int )phar->fname_len);
  fname = (char *)tmp___6;
  phar_globals.last_phar = (phar_archive_data *)((void *)0);
  phar_globals.last_alias = (char *)((void *)0);
  phar_globals.last_phar_name = phar_globals.last_alias;
  phar_archive_delref(phar);
  unlink((char const   *)fname);
  _efree((void *)fname);
  while (1) {
    __z___0 = return_value;
    __z___0->value.lval = 1L;
    __z___0->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zim_Phar___destruct(int ht , zval *return_value , zval **return_value_ptr ,
                         zval *this_ptr , int return_value_used ) 
{ 
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (phar_obj->arc.archive) {
    if ((phar_obj->arc.archive)->is_persistent) {
      zend_hash_del_key_or_index(& phar_globals.phar_persist_map,
                                 (char const   *)phar_obj->arc.archive,
                                 (uint )sizeof(phar_obj->arc.archive),
                                 (ulong )0, 0);
    } else {

    }
  } else {

  }
  return;
}
}
static int phar_build(zend_object_iterator *iter , void *puser ) 
{ 
  zval **value ;
  zend_uchar key_type ;
  zend_bool close_fp ;
  ulong int_key ;
  struct _phar_t *p_obj ;
  uint str_key_len ;
  uint base_len ;
  uint fname_len ;
  phar_entry_data *data ;
  php_stream *fp ;
  size_t contents_len ;
  char *fname ;
  char *error ;
  char *base ;
  char *opened ;
  char *save ;
  char *temp ;
  phar_zstr key ;
  char *str_key ;
  zend_class_entry *ce ;
  phar_archive_object *phar_obj ;
  char *str ;
  int __attribute__((__visibility__("default")))  tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  int tmp___2 ;
  char __attribute__((__visibility__("default")))  *tmp___3 ;
  char *test ;
  zval dummy ;
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp___4 ;
  char __attribute__((__visibility__("default")))  *tmp___5 ;
  int __attribute__((__visibility__("default")))  tmp___6 ;
  char __attribute__((__visibility__("default")))  *tmp___7 ;
  size_t tmp___8 ;
  char __attribute__((__visibility__("default")))  *tmp___9 ;
  size_t tmp___10 ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp___11 ;
  zend_bool __attribute__((__visibility__("default")))  tmp___12 ;
  char __attribute__((__visibility__("default")))  *tmp___13 ;
  size_t tmp___14 ;
  char *tmp___15 ;
  int tmp___16 ;
  int __attribute__((__visibility__("default")))  tmp___17 ;
  php_stream __attribute__((__visibility__("default")))  *tmp___18 ;
  int tmp___19 ;
  long tmp___20 ;
  off_t __attribute__((__visibility__("default")))  tmp___21 ;
  php_uint32 tmp___22 ;
  off_t __attribute__((__visibility__("default")))  tmp___23 ;
  size_t tmp___24 ;
  php_uint32 tmp___25 ;

  {
  close_fp = (zend_bool )1;
  p_obj = (struct _phar_t *)puser;
  base_len = p_obj->l;
  error = (char *)((void *)0);
  base = p_obj->b;
  save = (char *)((void *)0);
  temp = (char *)((void *)0);
  ce = p_obj->c;
  phar_obj = p_obj->p;
  str = (char *)"[stream]";
  (*((iter->funcs)->get_current_data))(iter, & value);
  if (executor_globals.exception) {
    return (1 << 1);
  } else {

  }
  if (! value) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                            0L, (char *)"Iterator %v returned no value",
                            ce->name);
    return (1 << 1);
  } else {

  }
  switch ((int )(*value)->type) {
  case 6: 
  break;
  case 7: 
  tmp = php_file_le_pstream();
  tmp___0 = php_file_le_stream();
  tmp___1 = zend_fetch_resource(value, -1, "stream", (int *)((void *)0), 2,
                                tmp___0, tmp);
  fp = (php_stream *)tmp___1;
  if (! fp) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Iterator %v returned an invalid stream handle",
                            ce->name);
    return (1 << 1);
  } else {

  }
  if ((iter->funcs)->get_current_key) {
    tmp___2 = (*((iter->funcs)->get_current_key))(iter, & key, & str_key_len,
                                                  & int_key);
    key_type = (zend_uchar )tmp___2;
    if (executor_globals.exception) {
      return (1 << 1);
    } else {

    }
    if ((int )key_type == 2) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"Iterator %v returned an invalid key (must return a string)",
                              ce->name);
      return (1 << 1);
    } else {

    }
    if ((int )key_type > 9) {
      spprintf(& str_key, (size_t )0, "%s", key);
    } else {
      str_key = key;
    }
    save = str_key;
    if ((int )*(str_key + (str_key_len - 1U)) == 0) {
      str_key_len --;
    } else {

    }
  } else {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                            0L,
                            (char *)"Iterator %v returned an invalid key (must return a string)",
                            ce->name);
    return (1 << 1);
  }
  close_fp = (zend_bool )0;
  tmp___3 = _estrndup((char const   *)str,
                      (unsigned int )(sizeof("[stream]") + 1UL));
  opened = (char *)tmp___3;
  goto after_open_fp;
  case 5: 
  tmp___11 = zend_get_class_entry((zval const   *)*value);
  tmp___12 = instanceof_function((zend_class_entry const   *)tmp___11,
                                 (zend_class_entry const   *)spl_ce_SplFileInfo);
  if (tmp___12) {
    test = (char *)((void *)0);
    tmp___4 = zend_object_store_get_object((zval const   *)*value);
    intern = (spl_filesystem_object *)tmp___4;
    if (! base_len) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Iterator %v returns an SplFileInfo object, so base directory must be specified",
                              ce->name);
      return (1 << 1);
    } else {

    }
    switch ((unsigned int )intern->type) {
    case 1U: 
    tmp___5 = spl_filesystem_object_get_path(intern, (int *)((void *)0));
    test = (char *)tmp___5;
    tmp___6 = spprintf(& fname, (size_t )0, "%s%c%s", test, '/',
                       intern->u.dir.entry.d_name);
    fname_len = (uint )tmp___6;
    php_stat((char const   *)fname, (php_stat_len )fname_len, 13, & dummy);
    if ((zend_bool )dummy.value.lval) {
      _efree((void *)fname);
      return (0);
    } else {

    }
    tmp___7 = expand_filepath((char const   *)fname, (char *)((void *)0));
    test = (char *)tmp___7;
    if (test) {
      _efree((void *)fname);
      fname = test;
      tmp___8 = strlen((char const   *)fname);
      fname_len = (uint )tmp___8;
    } else {

    }
    save = fname;
    goto phar_spl_fileinfo;
    case 0U: 
    case 2U: 
    tmp___9 = expand_filepath((char const   *)intern->file_name,
                              (char *)((void *)0));
    fname = (char *)tmp___9;
    tmp___10 = strlen((char const   *)fname);
    fname_len = (uint )tmp___10;
    save = fname;
    goto phar_spl_fileinfo;
    }
  } else {

  }
  default: 
  zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                          0L,
                          (char *)"Iterator %v returned an invalid value (must return a string)",
                          ce->name);
  return (1 << 1);
  }
  fname = (*value)->value.str.val;
  fname_len = (uint )(*value)->value.str.len;
  phar_spl_fileinfo: 
  if (base_len) {
    tmp___13 = expand_filepath((char const   *)base, (char *)((void *)0));
    temp = (char *)tmp___13;
    base = temp;
    tmp___14 = strlen((char const   *)base);
    base_len = (uint )tmp___14;
    tmp___15 = strstr((char const   *)fname, (char const   *)base);
    if (tmp___15) {
      str_key_len = fname_len - base_len;
      if (str_key_len <= 0U) {
        if (save) {
          _efree((void *)save);
          _efree((void *)temp);
        } else {

        }
        return (0);
      } else {

      }
      str_key = fname + base_len;
      if ((int )*str_key == 47) {
        str_key ++;
        str_key_len --;
      } else
      if ((int )*str_key == 92) {
        str_key ++;
        str_key_len --;
      } else {

      }
    } else {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"Iterator %v returned a path \"%s\" that is not in the base directory \"%s\"",
                              ce->name, fname, base);
      if (save) {
        _efree((void *)save);
        _efree((void *)temp);
      } else {

      }
      return (1 << 1);
    }
  } else
  if ((iter->funcs)->get_current_key) {
    tmp___16 = (*((iter->funcs)->get_current_key))(iter, & key, & str_key_len,
                                                   & int_key);
    key_type = (zend_uchar )tmp___16;
    if (executor_globals.exception) {
      return (1 << 1);
    } else {

    }
    if ((int )key_type == 2) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"Iterator %v returned an invalid key (must return a string)",
                              ce->name);
      return (1 << 1);
    } else {

    }
    if ((int )key_type > 9) {
      spprintf(& str_key, (size_t )0, "%s", key);
    } else {
      str_key = key;
    }
    save = str_key;
    if ((int )*(str_key + (str_key_len - 1U)) == 0) {
      str_key_len --;
    } else {

    }
  } else {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                            0L,
                            (char *)"Iterator %v returned an invalid key (must return a string)",
                            ce->name);
    return (1 << 1);
  }
  tmp___17 = php_check_open_basedir((char const   *)fname);
  if (tmp___17) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                            0L,
                            (char *)"Iterator %v returned a path \"%s\" that open_basedir prevents opening",
                            ce->name, fname);
    if (save) {
      _efree((void *)save);
    } else {

    }
    if (temp) {
      _efree((void *)temp);
    } else {

    }
    return (1 << 1);
  } else {

  }
  tmp___18 = _php_stream_open_wrapper_ex(fname, (char *)"rb", 16, & opened,
                                         (php_stream_context *)((void *)0));
  fp = (php_stream *)tmp___18;
  if (! fp) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                            0L,
                            (char *)"Iterator %v returned a file that could not be opened \"%s\"",
                            ce->name, fname);
    if (save) {
      _efree((void *)save);
    } else {

    }
    if (temp) {
      _efree((void *)temp);
    } else {

    }
    return (1 << 1);
  } else {

  }
  after_open_fp: 
  if ((unsigned long )str_key_len >= sizeof(".phar") - 1UL) {
    tmp___19 = memcmp((void const   *)str_key, (void const   *)".phar",
                      sizeof(".phar") - 1UL);
    if (! tmp___19) {
      if (save) {
        _efree((void *)save);
      } else {

      }
      if (temp) {
        _efree((void *)temp);
      } else {

      }
      if (opened) {
        _efree((void *)opened);
      } else {

      }
      if (close_fp) {
        _php_stream_free(fp, 3);
      } else {

      }
      return (0);
    } else {

    }
  } else {

  }
  data = phar_get_or_create_entry_data((phar_obj->arc.archive)->fname,
                                       (phar_obj->arc.archive)->fname_len,
                                       str_key, (int )str_key_len,
                                       (char *)"w+b", (char)0, & error, 1);
  if (data) {
    if (error) {
      _efree((void *)error);
    } else {

    }
    if ((unsigned int )(data->internal_file)->fp_type == 2U) {
      _php_stream_free((data->internal_file)->fp, 3);
    } else {

    }
    (data->internal_file)->fp = (php_stream *)((void *)0);
    (data->internal_file)->fp_type = (enum phar_fp_type )1;
    tmp___21 = _php_stream_tell(p_obj->fp);
    tmp___20 = (long )tmp___21;
    (data->internal_file)->offset = tmp___20;
    (data->internal_file)->offset_abs = tmp___20;
    data->fp = (php_stream *)((void *)0);
    _php_stream_copy_to_stream_ex(fp, p_obj->fp, (size_t )-1, & contents_len);
    tmp___23 = _php_stream_tell(p_obj->fp);
    tmp___22 = (php_uint32 )(tmp___23 - (off_t __attribute__((__visibility__("default")))  )(data->internal_file)->offset);
    (data->internal_file)->compressed_filesize = tmp___22;
    (data->internal_file)->uncompressed_filesize = tmp___22;
  } else {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L, (char *)"Entry %s cannot be created: %s",
                            str_key, error);
    _efree((void *)error);
    if (save) {
      _efree((void *)save);
    } else {

    }
    if (opened) {
      _efree((void *)opened);
    } else {

    }
    if (temp) {
      _efree((void *)temp);
    } else {

    }
    if (close_fp) {
      _php_stream_free(fp, 3);
    } else {

    }
    return (1 << 1);
  }
  if (close_fp) {
    _php_stream_free(fp, 3);
  } else {

  }
  tmp___24 = strlen((char const   *)str_key);
  add_assoc_string_ex(p_obj->ret, (char const   *)str_key,
                      (uint )(tmp___24 + 1UL), opened, 0);
  if (save) {
    _efree((void *)save);
  } else {

  }
  if (temp) {
    _efree((void *)temp);
  } else {

  }
  tmp___25 = (php_uint32 )contents_len;
  (data->internal_file)->uncompressed_filesize = tmp___25;
  (data->internal_file)->compressed_filesize = tmp___25;
  phar_entry_delref(data);
  return (0);
}
}
void zim_Phar_buildFromDirectory(int ht , zval *return_value ,
                                 zval **return_value_ptr , zval *this_ptr ,
                                 int return_value_used ) 
{ 
  char *dir ;
  char *error ;
  char *regex ;
  int dir_len ;
  int regex_len ;
  zend_bool apply_reg ;
  zval arg ;
  zval arg2 ;
  zval *iter ;
  zval *iteriter ;
  zval *regexiter ;
  struct _phar_t pass ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval *__z ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  zval *__z___0 ;
  int __attribute__((__visibility__("default")))  tmp___2 ;
  char const   *__s ;
  int __l ;
  zval *__z___1 ;
  zval *__z___2 ;
  zval *__z___3 ;
  void __attribute__((__visibility__("default")))  *tmp___4 ;
  zval *__z___4 ;
  int __attribute__((__visibility__("default")))  tmp___5 ;
  zval *__z___5 ;
  void __attribute__((__visibility__("default")))  *tmp___6 ;
  zval *__z___6 ;
  int __attribute__((__visibility__("default")))  tmp___7 ;
  char const   *__s___0 ;
  int __l___0 ;
  zval *__z___7 ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp___9 ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp___10 ;
  php_stream __attribute__((__visibility__("default")))  *tmp___11 ;
  int tmp___12 ;
  zval *tmp___13 ;
  int __attribute__((__visibility__("default")))  tmp___14 ;

  {
  regex = (char *)((void *)0);
  regex_len = 0;
  apply_reg = (zend_bool )0;
  regexiter = (zval *)((void *)0);
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  if (phar_globals.readonly) {
    if (! (phar_obj->arc.archive)->is_data) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"Cannot write to archive - write operations restricted by INI setting");
      return;
    } else {

    }
  } else {

  }
  tmp___0 = zend_parse_parameters(ht, "s|s", & dir, & dir_len, & regex,
                                  & regex_len);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  while (1) {
    tmp___1 = _emalloc(sizeof(zval_gc_info ));
    iter = (zval *)tmp___1;
    ((zval_gc_info *)iter)->u.buffered = (gc_root_buffer *)((void *)0);
    break;
  }
  iter->refcount__gc = (zend_uint )1;
  iter->is_ref__gc = (zend_uchar )0;
  tmp___2 = _object_init_ex(iter,
                            (zend_class_entry *)spl_ce_RecursiveDirectoryIterator);
  if (0 != (int )tmp___2) {
    _zval_ptr_dtor(& iter);
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Unable to instantiate directory iterator for %s",
                            (phar_obj->arc.archive)->fname);
    while (1) {
      __z___0 = return_value;
      __z___0->value.lval = 0L;
      __z___0->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  arg.refcount__gc = (zend_uint )1;
  arg.is_ref__gc = (zend_uchar )0;
  while (1) {
    __s = (char const   *)dir;
    __l = dir_len;
    __z___1 = & arg;
    __z___1->value.str.len = __l;
    __z___1->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z___1->type = (zend_uchar )6;
    break;
  }
  arg2.refcount__gc = (zend_uint )1;
  arg2.is_ref__gc = (zend_uchar )0;
  __z___2 = & arg2;
  __z___2->value.lval = 12288L;
  __z___2->type = (zend_uchar )1;
  zend_call_method(& iter,
                   (zend_class_entry *)spl_ce_RecursiveDirectoryIterator,
                   & spl_ce_RecursiveDirectoryIterator->constructor,
                   (char *)"__construct", (int )(sizeof("__construct") - 1UL),
                   (zval **)((void *)0), 2, & arg, & arg2);
  if (executor_globals.exception) {
    _zval_ptr_dtor(& iter);
    while (1) {
      __z___3 = return_value;
      __z___3->value.lval = 0L;
      __z___3->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  while (1) {
    tmp___4 = _emalloc(sizeof(zval_gc_info ));
    iteriter = (zval *)tmp___4;
    ((zval_gc_info *)iteriter)->u.buffered = (gc_root_buffer *)((void *)0);
    break;
  }
  iteriter->refcount__gc = (zend_uint )1;
  iteriter->is_ref__gc = (zend_uchar )0;
  tmp___5 = _object_init_ex(iteriter,
                            (zend_class_entry *)spl_ce_RecursiveIteratorIterator);
  if (0 != (int )tmp___5) {
    _zval_ptr_dtor(& iter);
    _zval_ptr_dtor(& iteriter);
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Unable to instantiate directory iterator for %s",
                            (phar_obj->arc.archive)->fname);
    while (1) {
      __z___4 = return_value;
      __z___4->value.lval = 0L;
      __z___4->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  zend_call_method(& iteriter,
                   (zend_class_entry *)spl_ce_RecursiveIteratorIterator,
                   & spl_ce_RecursiveIteratorIterator->constructor,
                   (char *)"__construct", (int )(sizeof("__construct") - 1UL),
                   (zval **)((void *)0), 1, iter, (zval *)((void *)0));
  if (executor_globals.exception) {
    _zval_ptr_dtor(& iter);
    _zval_ptr_dtor(& iteriter);
    while (1) {
      __z___5 = return_value;
      __z___5->value.lval = 0L;
      __z___5->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  _zval_ptr_dtor(& iter);
  if (regex_len > 0) {
    apply_reg = (zend_bool )1;
    while (1) {
      tmp___6 = _emalloc(sizeof(zval_gc_info ));
      regexiter = (zval *)tmp___6;
      ((zval_gc_info *)regexiter)->u.buffered = (gc_root_buffer *)((void *)0);
      break;
    }
    regexiter->refcount__gc = (zend_uint )1;
    regexiter->is_ref__gc = (zend_uchar )0;
    tmp___7 = _object_init_ex(regexiter,
                              (zend_class_entry *)spl_ce_RegexIterator);
    if (0 != (int )tmp___7) {
      _zval_ptr_dtor(& iteriter);
      _zval_dtor(regexiter);
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Unable to instantiate regex iterator for %s",
                              (phar_obj->arc.archive)->fname);
      while (1) {
        __z___6 = return_value;
        __z___6->value.lval = 0L;
        __z___6->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    arg2.refcount__gc = (zend_uint )1;
    arg2.is_ref__gc = (zend_uchar )0;
    while (1) {
      __s___0 = (char const   *)regex;
      __l___0 = regex_len;
      __z___7 = & arg2;
      __z___7->value.str.len = __l___0;
      __z___7->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s___0));
      __z___7->type = (zend_uchar )6;
      break;
    }
    zend_call_method(& regexiter, (zend_class_entry *)spl_ce_RegexIterator,
                     & spl_ce_RegexIterator->constructor, (char *)"__construct",
                     (int )(sizeof("__construct") - 1UL), (zval **)((void *)0),
                     2, iteriter, & arg2);
  } else {

  }
  _array_init(return_value, (uint )0);
  if (apply_reg) {
    tmp___9 = zend_get_class_entry((zval const   *)regexiter);
    pass.c = (zend_class_entry *)tmp___9;
  } else {
    tmp___10 = zend_get_class_entry((zval const   *)iteriter);
    pass.c = (zend_class_entry *)tmp___10;
  }
  pass.p = phar_obj;
  pass.b = dir;
  pass.l = (uint )dir_len;
  pass.count = 0;
  pass.ret = return_value;
  tmp___11 = _php_stream_fopen_tmpfile(0);
  pass.fp = (php_stream *)tmp___11;
  if ((phar_obj->arc.archive)->is_persistent) {
    tmp___12 = phar_copy_on_write(& phar_obj->arc.archive);
    if (-1 == tmp___12) {
      _zval_ptr_dtor(& iteriter);
      if (apply_reg) {
        _zval_ptr_dtor(& regexiter);
      } else {

      }
      _php_stream_free(pass.fp, 3);
      zend_throw_exception_ex(phar_ce_PharException, 0L,
                              (char *)"phar \"%s\" is persistent, unable to copy on write",
                              (phar_obj->arc.archive)->fname);
      return;
    } else {

    }
  } else {

  }
  if (apply_reg) {
    tmp___13 = regexiter;
  } else {
    tmp___13 = iteriter;
  }
  tmp___14 = spl_iterator_apply(tmp___13, & phar_build, (void *)(& pass));
  if (0 == (int )tmp___14) {
    _zval_ptr_dtor(& iteriter);
    if (apply_reg) {
      _zval_ptr_dtor(& regexiter);
    } else {

    }
    (phar_obj->arc.archive)->ufp = pass.fp;
    phar_flush(phar_obj->arc.archive, (char *)0, 0L, 0, & error);
    if (error) {
      zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
      _efree((void *)error);
    } else {

    }
  } else {
    _zval_ptr_dtor(& iteriter);
    if (apply_reg) {
      _zval_ptr_dtor(& regexiter);
    } else {

    }
    _php_stream_free(pass.fp, 3);
  }
  return;
}
}
void zim_Phar_buildFromIterator(int ht , zval *return_value ,
                                zval **return_value_ptr , zval *this_ptr ,
                                int return_value_used ) 
{ 
  zval *obj ;
  char *error ;
  uint base_len ;
  char *base ;
  struct _phar_t pass ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval *__z ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  int tmp___1 ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp___2 ;
  php_stream __attribute__((__visibility__("default")))  *tmp___3 ;
  int __attribute__((__visibility__("default")))  tmp___4 ;

  {
  base_len = (uint )0;
  base = (char *)((void *)0);
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  if (phar_globals.readonly) {
    if (! (phar_obj->arc.archive)->is_data) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"Cannot write out phar archive, phar is read-only");
      return;
    } else {

    }
  } else {

  }
  tmp___0 = zend_parse_parameters(ht, "O|s", & obj, zend_ce_traversable, & base,
                                  & base_len);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  if ((phar_obj->arc.archive)->is_persistent) {
    tmp___1 = phar_copy_on_write(& phar_obj->arc.archive);
    if (-1 == tmp___1) {
      zend_throw_exception_ex(phar_ce_PharException, 0L,
                              (char *)"phar \"%s\" is persistent, unable to copy on write",
                              (phar_obj->arc.archive)->fname);
      return;
    } else {

    }
  } else {

  }
  _array_init(return_value, (uint )0);
  tmp___2 = zend_get_class_entry((zval const   *)obj);
  pass.c = (zend_class_entry *)tmp___2;
  pass.p = phar_obj;
  pass.b = base;
  pass.l = base_len;
  pass.ret = return_value;
  pass.count = 0;
  tmp___3 = _php_stream_fopen_tmpfile(0);
  pass.fp = (php_stream *)tmp___3;
  tmp___4 = spl_iterator_apply(obj, & phar_build, (void *)(& pass));
  if (0 == (int )tmp___4) {
    (phar_obj->arc.archive)->ufp = pass.fp;
    phar_flush(phar_obj->arc.archive, (char *)0, 0L, 0, & error);
    if (error) {
      zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
      _efree((void *)error);
    } else {

    }
  } else {
    _php_stream_free(pass.fp, 3);
  }
  return;
}
}
void zim_Phar_count(int ht , zval *return_value , zval **return_value_ptr ,
                    zval *this_ptr , int return_value_used ) 
{ 
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval *__z ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  __z = return_value;
  tmp___0 = zend_hash_num_elements((HashTable const   *)(& (phar_obj->arc.archive)->manifest));
  __z->value.lval = (long )tmp___0;
  __z->type = (zend_uchar )1;
  return;
}
}
void zim_Phar_isFileFormat(int ht , zval *return_value ,
                           zval **return_value_ptr , zval *this_ptr ,
                           int return_value_used ) 
{ 
  long type ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval *__z ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z___0 ;
  zval *__z___1 ;
  zval *__z___2 ;
  int tmp___1 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  tmp___0 = zend_parse_parameters(ht, "l", & type);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  switch (type) {
  case 2L: 
  while (1) {
    __z___0 = return_value;
    __z___0->value.lval = (long )((phar_obj->arc.archive)->is_tar != 0U);
    __z___0->type = (zend_uchar )3;
    break;
  }
  return;
  case 3L: 
  while (1) {
    __z___1 = return_value;
    __z___1->value.lval = (long )((phar_obj->arc.archive)->is_zip != 0U);
    __z___1->type = (zend_uchar )3;
    break;
  }
  return;
  case 1L: 
  while (1) {
    __z___2 = return_value;
    if (! (phar_obj->arc.archive)->is_tar) {
      if (! (phar_obj->arc.archive)->is_zip) {
        tmp___1 = 1;
      } else {
        tmp___1 = 0;
      }
    } else {
      tmp___1 = 0;
    }
    __z___2->value.lval = (long )(tmp___1 != 0);
    __z___2->type = (zend_uchar )3;
    break;
  }
  return;
  default: 
  zend_throw_exception_ex(phar_ce_PharException, 0L,
                          (char *)"Unknown file format specified");
  }
  return;
}
}
static int phar_copy_file_contents(phar_entry_info *entry , php_stream *fp ) 
{ 
  char *error ;
  off_t offset ;
  phar_entry_info *link___0 ;
  int tmp ;
  off_t __attribute__((__visibility__("default")))  tmp___0 ;
  php_stream *tmp___1 ;
  size_t __attribute__((__visibility__("default")))  tmp___2 ;

  {
  tmp = phar_open_entry_fp(entry, & error, 1);
  if (-1 == tmp) {
    if (error) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"Cannot convert phar archive \"%s\", unable to open entry \"%s\" contents: %s",
                              (entry->phar)->fname, entry->filename, error);
      _efree((void *)error);
    } else {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"Cannot convert phar archive \"%s\", unable to open entry \"%s\" contents",
                              (entry->phar)->fname, entry->filename);
    }
    return (-1);
  } else {

  }
  phar_seek_efp(entry, (off_t )0, 0, (off_t )0, 1);
  tmp___0 = _php_stream_tell(fp);
  offset = (off_t )tmp___0;
  link___0 = phar_get_link_source(entry);
  if (! link___0) {
    link___0 = entry;
  } else {

  }
  tmp___1 = phar_get_efp(link___0, 0);
  tmp___2 = _php_stream_copy_to_stream_ex(tmp___1, fp,
                                          (size_t )link___0->uncompressed_filesize,
                                          (size_t *)((void *)0));
  if ((size_t __attribute__((__visibility__("default")))  )0 != tmp___2) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                            0L,
                            (char *)"Cannot convert phar archive \"%s\", unable to copy entry \"%s\" contents",
                            (entry->phar)->fname, entry->filename);
    return (-1);
  } else {

  }
  if ((unsigned int )entry->fp_type == 2U) {
    entry->cfp = entry->fp;
    entry->fp = (php_stream *)((void *)0);
  } else {

  }
  entry->fp_type = (enum phar_fp_type )0;
  entry->offset = offset;
  return (0);
}
}
static zval *phar_rename_archive(phar_archive_data *phar , char *ext ,
                                 zend_bool compress ) 
{ 
  char const   *oldname ;
  char *oldpath ;
  char *basename ;
  char *basepath ;
  char *newname ;
  char *newpath ;
  zval *ret ;
  zval arg1 ;
  zend_class_entry *ce ;
  char *error ;
  char const   *pcr_error ;
  int ext_len ;
  size_t tmp ;
  size_t tmp___0 ;
  int oldname_len ;
  phar_archive_data **pphar ;
  php_stream_statbuf ssb ;
  phar_path_check_result tmp___1 ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;
  void const   *tmp___3 ;
  size_t tmp___4 ;
  char __attribute__((__visibility__("default")))  *tmp___5 ;
  char *tmp___6 ;
  size_t tmp___7 ;
  char __attribute__((__visibility__("default")))  *tmp___8 ;
  int __attribute__((__visibility__("default")))  tmp___9 ;
  size_t tmp___10 ;
  int __attribute__((__visibility__("default")))  tmp___11 ;
  int __attribute__((__visibility__("default")))  tmp___12 ;
  int tmp___13 ;
  int __attribute__((__visibility__("default")))  tmp___14 ;
  int __attribute__((__visibility__("default")))  tmp___15 ;
  int tmp___16 ;
  size_t tmp___17 ;
  char __attribute__((__visibility__("default")))  *tmp___18 ;
  size_t tmp___19 ;
  int tmp___20 ;
  int __attribute__((__visibility__("default")))  tmp___21 ;
  void __attribute__((__visibility__("default")))  *tmp___22 ;
  int __attribute__((__visibility__("default")))  tmp___23 ;
  char const   *__s ;
  int __l ;
  zval *__z ;

  {
  oldname = (char const   *)((void *)0);
  oldpath = (char *)((void *)0);
  basename = (char *)((void *)0);
  basepath = (char *)((void *)0);
  newname = (char *)((void *)0);
  newpath = (char *)((void *)0);
  if (ext) {
    tmp = strlen((char const   *)ext);
    tmp___0 = tmp;
  } else {
    tmp___0 = (size_t )0;
  }
  ext_len = (int )tmp___0;
  pphar = (phar_archive_data **)((void *)0);
  if (! ext) {
    if (phar->is_zip) {
      if (phar->is_data) {
        ext = (char *)"zip";
      } else {
        ext = (char *)"phar.zip";
      }
    } else
    if (phar->is_tar) {
      switch (phar->flags) {
      case 1048576U: 
      if (phar->is_data) {
        ext = (char *)"tar.gz";
      } else {
        ext = (char *)"phar.tar.gz";
      }
      break;
      case 2097152U: 
      if (phar->is_data) {
        ext = (char *)"tar.bz2";
      } else {
        ext = (char *)"phar.tar.bz2";
      }
      break;
      default: 
      if (phar->is_data) {
        ext = (char *)"tar";
      } else {
        ext = (char *)"phar.tar";
      }
      }
    } else {
      switch (phar->flags) {
      case 1048576U: 
      ext = (char *)"phar.gz";
      break;
      case 2097152U: 
      ext = (char *)"phar.bz2";
      break;
      default: 
      ext = (char *)"phar";
      }
    }
  } else {
    tmp___1 = phar_path_check(& ext, & ext_len, & pcr_error);
    if ((unsigned int )tmp___1 > 1U) {
      if (phar->is_data) {
        zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                                0L,
                                (char *)"data phar converted from \"%s\" has invalid extension %s",
                                phar->fname, ext);
      } else {
        zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                                0L,
                                (char *)"phar converted from \"%s\" has invalid extension %s",
                                phar->fname, ext);
      }
      return ((zval *)((void *)0));
    } else {

    }
  }
  if ((int )*(ext + 0) == 46) {
    ext ++;
  } else {

  }
  tmp___2 = _estrndup((char const   *)phar->fname,
                      (unsigned int )phar->fname_len);
  oldpath = (char *)tmp___2;
  tmp___3 = zend_memrchr((void const   *)phar->fname, '/',
                         (size_t )phar->fname_len);
  oldname = (char const   *)tmp___3;
  oldname ++;
  tmp___4 = strlen(oldname);
  oldname_len = (int )tmp___4;
  tmp___5 = _estrndup(oldname, (unsigned int )oldname_len);
  basename = (char *)tmp___5;
  tmp___6 = strtok((char */* __restrict  */)basename,
                   (char const   */* __restrict  */)".");
  spprintf(& newname, (size_t )0, "%s.%s", tmp___6, ext);
  _efree((void *)basename);
  tmp___7 = strlen((char const   *)oldpath);
  tmp___8 = _estrndup((char const   *)oldpath,
                      (unsigned int )(tmp___7 - (size_t )oldname_len));
  basepath = (char *)tmp___8;
  tmp___9 = spprintf(& newpath, (size_t )0, "%s%s", basepath, newname);
  phar->fname_len = (int )tmp___9;
  phar->fname = newpath;
  tmp___10 = strlen((char const   *)ext);
  phar->ext = ((newpath + phar->fname_len) - tmp___10) - 1;
  _efree((void *)basepath);
  _efree((void *)newname);
  if (phar_globals.manifest_cached) {
    tmp___11 = zend_hash_find((HashTable const   *)(& cached_phars),
                              (char const   *)newpath, (uint )phar->fname_len,
                              (void **)(& pphar));
    if (0 == (int )tmp___11) {
      _efree((void *)oldpath);
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Unable to add newly converted phar \"%s\" to the list of phars, new phar name is in phar.cache_list",
                              phar->fname);
      return ((zval *)((void *)0));
    } else {

    }
  } else {

  }
  tmp___14 = zend_hash_find((HashTable const   *)(& phar_globals.phar_fname_map),
                            (char const   *)newpath, (uint )phar->fname_len,
                            (void **)(& pphar));
  if (0 == (int )tmp___14) {
    if ((*pphar)->fname_len == phar->fname_len) {
      tmp___13 = memcmp((void const   *)(*pphar)->fname,
                        (void const   *)phar->fname, (size_t )phar->fname_len);
      if (! tmp___13) {
        tmp___12 = zend_hash_num_elements((HashTable const   *)(& phar->manifest));
        if (! tmp___12) {
          (*pphar)->is_tar = phar->is_tar;
          (*pphar)->is_zip = phar->is_zip;
          (*pphar)->is_data = phar->is_data;
          (*pphar)->flags = phar->flags;
          (*pphar)->fp = phar->fp;
          phar->fp = (php_stream *)((void *)0);
          phar_destroy_phar_data(phar);
          phar = *pphar;
          (phar->refcount) ++;
          newpath = oldpath;
          goto its_ok;
        } else {

        }
      } else {

      }
    } else {

    }
    _efree((void *)oldpath);
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Unable to add newly converted phar \"%s\" to the list of phars, a phar with that name already exists",
                            phar->fname);
    return ((zval *)((void *)0));
  } else {

  }
  its_ok: 
  tmp___15 = _php_stream_stat_path(newpath, 0, & ssb,
                                   (php_stream_context *)((void *)0));
  if (0 == (int )tmp___15) {
    _efree((void *)oldpath);
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"phar \"%s\" exists and must be unlinked prior to conversion",
                            newpath);
    return ((zval *)((void *)0));
  } else {

  }
  if (! phar->is_data) {
    tmp___16 = phar_detect_phar_fname_ext((char const   *)newpath,
                                          phar->fname_len,
                                          (char const   **)(& phar->ext),
                                          & phar->ext_len, 1, 1, 1);
    if (0 != tmp___16) {
      _efree((void *)oldpath);
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"phar \"%s\" has invalid extension %s",
                              phar->fname, ext);
      return ((zval *)((void *)0));
    } else {

    }
    if (phar->alias) {
      if (phar->is_temporary_alias) {
        phar->alias = (char *)((void *)0);
        phar->alias_len = 0;
      } else {
        tmp___17 = strlen((char const   *)newpath);
        tmp___18 = _estrndup((char const   *)newpath, (unsigned int )tmp___17);
        phar->alias = (char *)tmp___18;
        tmp___19 = strlen((char const   *)newpath);
        phar->alias_len = (int )tmp___19;
        phar->is_temporary_alias = 1U;
        _zend_hash_add_or_update(& phar_globals.phar_alias_map,
                                 (char const   *)newpath,
                                 (uint )phar->fname_len, (void *)(& phar),
                                 (uint )sizeof(phar_archive_data *),
                                 (void **)((void *)0), 1);
      }
    } else {

    }
  } else {
    tmp___20 = phar_detect_phar_fname_ext((char const   *)newpath,
                                          phar->fname_len,
                                          (char const   **)(& phar->ext),
                                          & phar->ext_len, 0, 1, 1);
    if (0 != tmp___20) {
      _efree((void *)oldpath);
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"data phar \"%s\" has invalid extension %s",
                              phar->fname, ext);
      return ((zval *)((void *)0));
    } else {

    }
    phar->alias = (char *)((void *)0);
    phar->alias_len = 0;
  }
  if (! pphar) {
    goto _L;
  } else
  if ((unsigned long )phar == (unsigned long )*pphar) {
    _L: 
    tmp___21 = _zend_hash_add_or_update(& phar_globals.phar_fname_map,
                                        (char const   *)newpath,
                                        (uint )phar->fname_len,
                                        (void *)(& phar),
                                        (uint )sizeof(phar_archive_data *),
                                        (void **)((void *)0), 1);
    if (0 != (int )tmp___21) {
      _efree((void *)oldpath);
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Unable to add newly converted phar \"%s\" to the list of phars",
                              phar->fname);
      return ((zval *)((void *)0));
    } else {

    }
  } else {

  }
  phar_flush(phar, (char *)0, 0L, 1, & error);
  if (error) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L, (char *)"%s", error);
    _efree((void *)error);
    _efree((void *)oldpath);
    return ((zval *)((void *)0));
  } else {

  }
  _efree((void *)oldpath);
  if (phar->is_data) {
    ce = phar_ce_data;
  } else {
    ce = phar_ce_archive;
  }
  while (1) {
    tmp___22 = _emalloc(sizeof(zval_gc_info ));
    ret = (zval *)tmp___22;
    ((zval_gc_info *)ret)->u.buffered = (gc_root_buffer *)((void *)0);
    break;
  }
  ret->refcount__gc = (zend_uint )1;
  ret->is_ref__gc = (zend_uchar )0;
  tmp___23 = _object_init_ex(ret, ce);
  if (0 != (int )tmp___23) {
    _zval_dtor(ret);
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Unable to instantiate phar object when converting archive \"%s\"",
                            phar->fname);
    return ((zval *)((void *)0));
  } else {

  }
  arg1.refcount__gc = (zend_uint )1;
  arg1.is_ref__gc = (zend_uchar )0;
  while (1) {
    __s = (char const   *)phar->fname;
    __l = phar->fname_len;
    __z = & arg1;
    __z->value.str.len = __l;
    __z->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z->type = (zend_uchar )6;
    break;
  }
  zend_call_method(& ret, ce, & ce->constructor, (char *)"__construct",
                   (int )(sizeof("__construct") - 1UL), (zval **)((void *)0), 1,
                   & arg1, (zval *)((void *)0));
  return (ret);
}
}
static zval *phar_convert_to_other(phar_archive_data *source , int convert ,
                                   char *ext , php_uint32 flags ) 
{ 
  phar_archive_data *phar ;
  phar_entry_info *entry ;
  phar_entry_info newentry ;
  zval *ret ;
  void __attribute__((__visibility__("default")))  *tmp ;
  php_stream __attribute__((__visibility__("default")))  *tmp___0 ;
  zval *t ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  int __attribute__((__visibility__("default")))  tmp___2 ;
  char __attribute__((__visibility__("default")))  *tmp___3 ;
  char __attribute__((__visibility__("default")))  *tmp___4 ;
  int tmp___5 ;
  char __attribute__((__visibility__("default")))  *tmp___6 ;
  zval *t___0 ;
  void __attribute__((__visibility__("default")))  *tmp___7 ;
  int tmp___9 ;
  int __attribute__((__visibility__("default")))  tmp___10 ;

  {
  phar_globals.last_phar = (phar_archive_data *)((void *)0);
  phar_globals.last_alias = (char *)((void *)0);
  phar_globals.last_phar_name = phar_globals.last_alias;
  tmp = _ecalloc((size_t )1, sizeof(phar_archive_data ));
  phar = (phar_archive_data *)tmp;
  phar->flags = flags;
  phar->is_data = source->is_data;
  switch (convert) {
  case 2: 
  phar->is_tar = 1U;
  break;
  case 3: 
  phar->is_zip = 1U;
  break;
  default: 
  phar->is_data = 0U;
  break;
  }
  _zend_hash_init(& phar->manifest, (uint )sizeof(phar_entry_info ),
                  (ulong (*)(char const   *arKey , uint nKeyLength ))(& zend_get_hash_value),
                  & destroy_phar_manifest_entry, (zend_bool )0);
  _zend_hash_init(& phar->mounted_dirs, (uint )sizeof(char *),
                  (ulong (*)(char const   *arKey , uint nKeyLength ))(& zend_get_hash_value),
                  (void (*)(void *pDest ))((void *)0), (zend_bool )0);
  _zend_hash_init(& phar->virtual_dirs, (uint )sizeof(char *),
                  (ulong (*)(char const   *arKey , uint nKeyLength ))(& zend_get_hash_value),
                  (void (*)(void *pDest ))((void *)0), (zend_bool )0);
  tmp___0 = _php_stream_fopen_tmpfile(0);
  phar->fp = (php_stream *)tmp___0;
  phar->fname = source->fname;
  phar->fname_len = source->fname_len;
  phar->is_temporary_alias = source->is_temporary_alias;
  phar->alias = source->alias;
  if (source->metadata) {
    t = source->metadata;
    while (1) {
      tmp___1 = _emalloc(sizeof(zval_gc_info ));
      phar->metadata = (zval *)tmp___1;
      ((zval_gc_info *)phar->metadata)->u.buffered = (gc_root_buffer *)((void *)0);
      break;
    }
    *(phar->metadata) = *t;
    _zval_copy_ctor(phar->metadata);
    zval_set_refcount_p(phar->metadata, (zend_uint )1);
    phar->metadata_len = 0;
  } else {

  }
  zend_hash_internal_pointer_reset_ex(& source->manifest,
                                      (HashPosition *)((void *)0));
  while (1) {
    tmp___10 = zend_hash_get_current_key_type_ex(& source->manifest,
                                                 (HashPosition *)((void *)0));
    if (tmp___10 == (int __attribute__((__visibility__("default")))  )3) {
      tmp___9 = -1;
    } else {
      tmp___9 = 0;
    }
    if (! (0 == tmp___9)) {
      break;
    } else {

    }
    tmp___2 = zend_hash_get_current_data_ex(& source->manifest,
                                            (void **)(& entry),
                                            (HashPosition *)((void *)0));
    if (-1 == (int )tmp___2) {
      zend_hash_destroy(& phar->manifest);
      _php_stream_free(phar->fp, 3);
      _efree((void *)phar);
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L, (char *)"Cannot convert phar archive \"%s\"",
                              source->fname);
      return ((zval *)((void *)0));
    } else {

    }
    newentry = *entry;
    if (newentry.link) {
      tmp___3 = _estrdup((char const   *)newentry.link);
      newentry.link = (char *)tmp___3;
      goto no_copy;
    } else {

    }
    if (newentry.tmp) {
      tmp___4 = _estrdup((char const   *)newentry.tmp);
      newentry.tmp = (char *)tmp___4;
      goto no_copy;
    } else {

    }
    newentry.metadata_str.c = (char *)0;
    tmp___5 = phar_copy_file_contents(& newentry, phar->fp);
    if (-1 == tmp___5) {
      zend_hash_destroy(& phar->manifest);
      _php_stream_free(phar->fp, 3);
      _efree((void *)phar);
      return ((zval *)((void *)0));
    } else {

    }
    no_copy: 
    tmp___6 = _estrndup((char const   *)newentry.filename, newentry.filename_len);
    newentry.filename = (char *)tmp___6;
    if (newentry.metadata) {
      t___0 = newentry.metadata;
      while (1) {
        tmp___7 = _emalloc(sizeof(zval_gc_info ));
        newentry.metadata = (zval *)tmp___7;
        ((zval_gc_info *)newentry.metadata)->u.buffered = (gc_root_buffer *)((void *)0);
        break;
      }
      *(newentry.metadata) = *t___0;
      _zval_copy_ctor(newentry.metadata);
      zval_set_refcount_p(newentry.metadata, (zend_uint )1);
      newentry.metadata_str.c = (char *)((void *)0);
      newentry.metadata_str.len = (size_t )0;
    } else {

    }
    newentry.is_zip = phar->is_zip;
    newentry.is_tar = phar->is_tar;
    if (newentry.is_tar) {
      if (entry->is_dir) {
        newentry.tar_type = (char )'5';
      } else {
        newentry.tar_type = (char )'0';
      }
    } else {

    }
    newentry.is_modified = 1U;
    newentry.phar = phar;
    newentry.old_flags = newentry.flags & 4294905855U;
    phar_set_inode(& newentry);
    _zend_hash_add_or_update(& phar->manifest,
                             (char const   *)newentry.filename,
                             newentry.filename_len, (void *)(& newentry),
                             (uint )sizeof(phar_entry_info ),
                             (void **)((void *)0), 1 << 1);
    phar_add_virtual_dirs(phar, newentry.filename, (int )newentry.filename_len);
    zend_hash_move_forward_ex(& source->manifest, (HashPosition *)((void *)0));
  }
  ret = phar_rename_archive(phar, ext, (zend_bool )0);
  if (ret) {
    return (ret);
  } else {
    zend_hash_destroy(& phar->manifest);
    zend_hash_destroy(& phar->mounted_dirs);
    zend_hash_destroy(& phar->virtual_dirs);
    _php_stream_free(phar->fp, 3);
    _efree((void *)phar->fname);
    _efree((void *)phar);
    return ((zval *)((void *)0));
  }
}
}
void zim_Phar_convertToExecutable(int ht , zval *return_value ,
                                  zval **return_value_ptr , zval *this_ptr ,
                                  int return_value_used ) 
{ 
  char *ext ;
  int is_data ;
  int ext_len ;
  php_uint32 flags ;
  zval *ret ;
  long format ;
  long method ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zend_uchar is_ref ;
  zend_bool tmp___1 ;
  zend_uint refcount ;
  zend_uint tmp___2 ;

  {
  ext = (char *)((void *)0);
  ext_len = 0;
  format = 9021976L;
  method = 9021976L;
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  tmp___0 = zend_parse_parameters(ht, "|lls", & format, & method, & ext,
                                  & ext_len);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (phar_globals.readonly) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                            0L,
                            (char *)"Cannot write out executable phar archive, phar is read-only");
    return;
  } else {

  }
  switch (format) {
  case 9021976L: 
  case 0L: 
  if ((phar_obj->arc.archive)->is_tar) {
    format = 2L;
  } else
  if ((phar_obj->arc.archive)->is_zip) {
    format = 3L;
  } else {
    format = 1L;
  }
  break;
  case 1L: 
  case 2L: 
  case 3L: 
  break;
  default: 
  zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException, 0L,
                          (char *)"Unknown file format specified, please pass one of Phar::PHAR, Phar::TAR or Phar::ZIP");
  return;
  }
  switch (method) {
  case 9021976L: 
  flags = (phar_obj->arc.archive)->flags & 15728640U;
  break;
  case 0L: 
  flags = (php_uint32 )0;
  break;
  case 4096L: 
  if (format == 3L) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot compress entire archive with gzip, zip archives do not support whole-archive compression");
    return;
  } else {

  }
  if (! phar_globals.has_zlib) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot compress entire archive with gzip, enable ext/zlib in php.ini");
    return;
  } else {

  }
  flags = (php_uint32 )1048576;
  break;
  case 8192L: 
  if (format == 3L) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot compress entire archive with bz2, zip archives do not support whole-archive compression");
    return;
  } else {

  }
  if (! phar_globals.has_bz2) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot compress entire archive with bz2, enable ext/bz2 in php.ini");
    return;
  } else {

  }
  flags = (php_uint32 )2097152;
  break;
  default: 
  zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException, 0L,
                          (char *)"Unknown compression specified, please pass one of Phar::GZ or Phar::BZ2");
  return;
  }
  is_data = (int )(phar_obj->arc.archive)->is_data;
  (phar_obj->arc.archive)->is_data = 0U;
  ret = phar_convert_to_other(phar_obj->arc.archive, (int )format, ext, flags);
  (phar_obj->arc.archive)->is_data = (unsigned int )is_data;
  if (ret) {
    tmp___1 = zval_isref_p(return_value);
    is_ref = tmp___1;
    tmp___2 = zval_refcount_p(return_value);
    refcount = tmp___2;
    while (1) {
      return_value->value = ret->value;
      return_value->type = ret->type;
      break;
    }
    _zval_copy_ctor(return_value);
    _zval_ptr_dtor(& ret);
    zval_set_isref_to_p(return_value, is_ref);
    zval_set_refcount_p(return_value, refcount);
    return;
  } else {
    return_value->type = (zend_uchar )0;
    return;
  }
}
}
void zim_Phar_convertToData(int ht , zval *return_value ,
                            zval **return_value_ptr , zval *this_ptr ,
                            int return_value_used ) 
{ 
  char *ext ;
  int is_data ;
  int ext_len ;
  php_uint32 flags ;
  zval *ret ;
  long format ;
  long method ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zend_uchar is_ref ;
  zend_bool tmp___1 ;
  zend_uint refcount ;
  zend_uint tmp___2 ;

  {
  ext = (char *)((void *)0);
  ext_len = 0;
  format = 9021976L;
  method = 9021976L;
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  tmp___0 = zend_parse_parameters(ht, "|lls", & format, & method, & ext,
                                  & ext_len);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  switch (format) {
  case 9021976L: 
  case 0L: 
  if ((phar_obj->arc.archive)->is_tar) {
    format = 2L;
  } else
  if ((phar_obj->arc.archive)->is_zip) {
    format = 3L;
  } else {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                            0L,
                            (char *)"Cannot write out data phar archive, use Phar::TAR or Phar::ZIP");
    return;
  }
  break;
  case 1L: 
  zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                          0L,
                          (char *)"Cannot write out data phar archive, use Phar::TAR or Phar::ZIP");
  return;
  case 2L: 
  case 3L: 
  break;
  default: 
  zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException, 0L,
                          (char *)"Unknown file format specified, please pass one of Phar::TAR or Phar::ZIP");
  return;
  }
  switch (method) {
  case 9021976L: 
  flags = (phar_obj->arc.archive)->flags & 15728640U;
  break;
  case 0L: 
  flags = (php_uint32 )0;
  break;
  case 4096L: 
  if (format == 3L) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot compress entire archive with gzip, zip archives do not support whole-archive compression");
    return;
  } else {

  }
  if (! phar_globals.has_zlib) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot compress entire archive with gzip, enable ext/zlib in php.ini");
    return;
  } else {

  }
  flags = (php_uint32 )1048576;
  break;
  case 8192L: 
  if (format == 3L) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot compress entire archive with bz2, zip archives do not support whole-archive compression");
    return;
  } else {

  }
  if (! phar_globals.has_bz2) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot compress entire archive with bz2, enable ext/bz2 in php.ini");
    return;
  } else {

  }
  flags = (php_uint32 )2097152;
  break;
  default: 
  zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException, 0L,
                          (char *)"Unknown compression specified, please pass one of Phar::GZ or Phar::BZ2");
  return;
  }
  is_data = (int )(phar_obj->arc.archive)->is_data;
  (phar_obj->arc.archive)->is_data = 1U;
  ret = phar_convert_to_other(phar_obj->arc.archive, (int )format, ext, flags);
  (phar_obj->arc.archive)->is_data = (unsigned int )is_data;
  if (ret) {
    tmp___1 = zval_isref_p(return_value);
    is_ref = tmp___1;
    tmp___2 = zval_refcount_p(return_value);
    refcount = tmp___2;
    while (1) {
      return_value->value = ret->value;
      return_value->type = ret->type;
      break;
    }
    _zval_copy_ctor(return_value);
    _zval_ptr_dtor(& ret);
    zval_set_isref_to_p(return_value, is_ref);
    zval_set_refcount_p(return_value, refcount);
    return;
  } else {
    return_value->type = (zend_uchar )0;
    return;
  }
}
}
void zim_Phar_isCompressed(int ht , zval *return_value ,
                           zval **return_value_ptr , zval *this_ptr ,
                           int return_value_used ) 
{ 
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval *__z ;
  zval *__z___0 ;
  zval *__z___1 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  if ((phar_obj->arc.archive)->flags & 1048576U) {
    __z = return_value;
    __z->value.lval = 4096L;
    __z->type = (zend_uchar )1;
    return;
  } else {

  }
  if ((phar_obj->arc.archive)->flags & 2097152U) {
    __z___0 = return_value;
    __z___0->value.lval = 8192L;
    __z___0->type = (zend_uchar )1;
    return;
  } else {

  }
  while (1) {
    __z___1 = return_value;
    __z___1->value.lval = 0L;
    __z___1->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zim_Phar_isWritable(int ht , zval *return_value , zval **return_value_ptr ,
                         zval *this_ptr , int return_value_used ) 
{ 
  php_stream_statbuf ssb ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval *__z ;
  zval *__z___0 ;
  zval *__z___1 ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z___2 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  if (! (phar_obj->arc.archive)->is_writeable) {
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  tmp___0 = _php_stream_stat_path((phar_obj->arc.archive)->fname, 0, & ssb,
                                  (php_stream_context *)((void *)0));
  if (0 != (int )tmp___0) {
    if ((phar_obj->arc.archive)->is_brandnew) {
      while (1) {
        __z___0 = return_value;
        __z___0->value.lval = 1L;
        __z___0->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    while (1) {
      __z___1 = return_value;
      __z___1->value.lval = 0L;
      __z___1->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  while (1) {
    __z___2 = return_value;
    __z___2->value.lval = (long )(((ssb.sb.st_mode & (unsigned int )((((128 >> 3) >> 3) | (128 >> 3)) | 128)) != 0U) != 0);
    __z___2->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zim_Phar_delete(int ht , zval *return_value , zval **return_value_ptr ,
                     zval *this_ptr , int return_value_used ) 
{ 
  char *fname ;
  int fname_len ;
  char *error ;
  phar_entry_info *entry ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval *__z ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  int tmp___1 ;
  zval *__z___0 ;
  int __attribute__((__visibility__("default")))  tmp___2 ;
  zval *__z___1 ;
  int __attribute__((__visibility__("default")))  tmp___3 ;
  zval *__z___2 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  if (phar_globals.readonly) {
    if (! (phar_obj->arc.archive)->is_data) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"Cannot write out phar archive, phar is read-only");
      return;
    } else {

    }
  } else {

  }
  tmp___0 = zend_parse_parameters(ht, "s", & fname, & fname_len);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  if ((phar_obj->arc.archive)->is_persistent) {
    tmp___1 = phar_copy_on_write(& phar_obj->arc.archive);
    if (-1 == tmp___1) {
      zend_throw_exception_ex(phar_ce_PharException, 0L,
                              (char *)"phar \"%s\" is persistent, unable to copy on write",
                              (phar_obj->arc.archive)->fname);
      return;
    } else {

    }
  } else {

  }
  tmp___3 = zend_hash_exists((HashTable const   *)(& (phar_obj->arc.archive)->manifest),
                             (char const   *)fname, (uint )fname_len);
  if (tmp___3) {
    tmp___2 = zend_hash_find((HashTable const   *)(& (phar_obj->arc.archive)->manifest),
                             (char const   *)fname, (uint )fname_len,
                             (void **)(& entry));
    if (0 == (int )tmp___2) {
      if (entry->is_deleted) {
        while (1) {
          __z___0 = return_value;
          __z___0->value.lval = 1L;
          __z___0->type = (zend_uchar )3;
          break;
        }
        return;
      } else {
        entry->is_deleted = 1U;
        entry->is_modified = 1U;
        (phar_obj->arc.archive)->is_modified = 1U;
      }
    } else {

    }
  } else {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Entry %s does not exist and cannot be deleted",
                            fname);
    while (1) {
      __z___1 = return_value;
      __z___1->value.lval = 0L;
      __z___1->type = (zend_uchar )3;
      break;
    }
    return;
  }
  phar_flush(phar_obj->arc.archive, (char *)((void *)0), 0L, 0, & error);
  if (error) {
    zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
    _efree((void *)error);
  } else {

  }
  while (1) {
    __z___2 = return_value;
    __z___2->value.lval = 1L;
    __z___2->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zim_Phar_getAlias(int ht , zval *return_value , zval **return_value_ptr ,
                       zval *this_ptr , int return_value_used ) 
{ 
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  if ((phar_obj->arc.archive)->alias) {
    if ((unsigned long )(phar_obj->arc.archive)->alias != (unsigned long )(phar_obj->arc.archive)->fname) {
      while (1) {
        __s = (char const   *)(phar_obj->arc.archive)->alias;
        __l = (phar_obj->arc.archive)->alias_len;
        __z = return_value;
        __z->value.str.len = __l;
        tmp___0 = _estrndup(__s, (unsigned int )__l);
        __z->value.str.val = (char *)tmp___0;
        __z->type = (zend_uchar )6;
        break;
      }
      return;
    } else {

    }
  } else {

  }
  return;
}
}
void zim_Phar_getPath(int ht , zval *return_value , zval **return_value_ptr ,
                      zval *this_ptr , int return_value_used ) 
{ 
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  while (1) {
    __s = (char const   *)(phar_obj->arc.archive)->fname;
    __l = (phar_obj->arc.archive)->fname_len;
    __z = return_value;
    __z->value.str.len = __l;
    tmp___0 = _estrndup(__s, (unsigned int )__l);
    __z->value.str.val = (char *)tmp___0;
    __z->type = (zend_uchar )6;
    break;
  }
  return;
}
}
void zim_Phar_setAlias(int ht , zval *return_value , zval **return_value_ptr ,
                       zval *this_ptr , int return_value_used ) 
{ 
  char *alias ;
  char *error ;
  char *oldalias ;
  phar_archive_data **fd_ptr ;
  int alias_len ;
  int oldalias_len ;
  int old_temp ;
  int readd ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval *__z ;
  zval *__z___0 ;
  zval *__z___1 ;
  int tmp___0 ;
  int tmp___1 ;
  zval *__z___2 ;
  int __attribute__((__visibility__("default")))  tmp___2 ;
  zval *__z___3 ;
  int tmp___3 ;
  int tmp___4 ;
  int __attribute__((__visibility__("default")))  tmp___5 ;
  char __attribute__((__visibility__("default")))  *tmp___6 ;
  zval *__z___4 ;
  zval *__z___5 ;
  int __attribute__((__visibility__("default")))  tmp___7 ;
  zval *__z___6 ;

  {
  readd = 0;
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  if (phar_globals.readonly) {
    if (! (phar_obj->arc.archive)->is_data) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"Cannot write out phar archive, phar is read-only");
      while (1) {
        __z = return_value;
        __z->value.lval = 0L;
        __z->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
  } else {

  }
  phar_globals.last_phar = (phar_archive_data *)((void *)0);
  phar_globals.last_alias = (char *)((void *)0);
  phar_globals.last_phar_name = phar_globals.last_alias;
  if ((phar_obj->arc.archive)->is_data) {
    if ((phar_obj->arc.archive)->is_tar) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"A Phar alias cannot be set in a plain tar archive");
    } else {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"A Phar alias cannot be set in a plain zip archive");
    }
    while (1) {
      __z___0 = return_value;
      __z___0->value.lval = 0L;
      __z___0->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  tmp___7 = zend_parse_parameters(ht, "s", & alias, & alias_len);
  if (tmp___7 == (int __attribute__((__visibility__("default")))  )0) {
    if (alias_len == (phar_obj->arc.archive)->alias_len) {
      tmp___0 = memcmp((void const   *)(phar_obj->arc.archive)->alias,
                       (void const   *)alias, (size_t )alias_len);
      if (tmp___0 == 0) {
        while (1) {
          __z___1 = return_value;
          __z___1->value.lval = 1L;
          __z___1->type = (zend_uchar )3;
          break;
        }
        return;
      } else {

      }
    } else {

    }
    if (alias_len) {
      tmp___2 = zend_hash_find((HashTable const   *)(& phar_globals.phar_alias_map),
                               (char const   *)alias, (uint )alias_len,
                               (void **)(& fd_ptr));
      if (0 == (int )tmp___2) {
        spprintf(& error, (size_t )0,
                 "alias \"%s\" is already used for archive \"%s\" and cannot be used for other archives",
                 alias, (*fd_ptr)->fname);
        tmp___1 = phar_free_alias(*fd_ptr, alias, alias_len);
        if (0 == tmp___1) {
          _efree((void *)error);
          goto valid_alias;
        } else {

        }
        zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
        _efree((void *)error);
        while (1) {
          __z___2 = return_value;
          __z___2->value.lval = 0L;
          __z___2->type = (zend_uchar )3;
          break;
        }
        return;
      } else {

      }
    } else {

    }
    tmp___3 = phar_validate_alias((char const   *)alias, alias_len);
    if (! tmp___3) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"Invalid alias \"%s\" specified for phar \"%s\"",
                              alias, (phar_obj->arc.archive)->fname);
      while (1) {
        __z___3 = return_value;
        __z___3->value.lval = 0L;
        __z___3->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    valid_alias: 
    if ((phar_obj->arc.archive)->is_persistent) {
      tmp___4 = phar_copy_on_write(& phar_obj->arc.archive);
      if (-1 == tmp___4) {
        zend_throw_exception_ex(phar_ce_PharException, 0L,
                                (char *)"phar \"%s\" is persistent, unable to copy on write",
                                (phar_obj->arc.archive)->fname);
        return;
      } else {

      }
    } else {

    }
    if ((phar_obj->arc.archive)->alias_len) {
      tmp___5 = zend_hash_find((HashTable const   *)(& phar_globals.phar_alias_map),
                               (char const   *)(phar_obj->arc.archive)->alias,
                               (uint )(phar_obj->arc.archive)->alias_len,
                               (void **)(& fd_ptr));
      if (0 == (int )tmp___5) {
        zend_hash_del_key_or_index(& phar_globals.phar_alias_map,
                                   (char const   *)(phar_obj->arc.archive)->alias,
                                   (uint )(phar_obj->arc.archive)->alias_len,
                                   (ulong )0, 0);
        readd = 1;
      } else {

      }
    } else {

    }
    oldalias = (phar_obj->arc.archive)->alias;
    oldalias_len = (phar_obj->arc.archive)->alias_len;
    old_temp = (int )(phar_obj->arc.archive)->is_temporary_alias;
    if (alias_len) {
      tmp___6 = _estrndup((char const   *)alias, (unsigned int )alias_len);
      (phar_obj->arc.archive)->alias = (char *)tmp___6;
    } else {
      (phar_obj->arc.archive)->alias = (char *)((void *)0);
    }
    (phar_obj->arc.archive)->alias_len = alias_len;
    (phar_obj->arc.archive)->is_temporary_alias = 0U;
    phar_flush(phar_obj->arc.archive, (char *)((void *)0), 0L, 0, & error);
    if (error) {
      (phar_obj->arc.archive)->alias = oldalias;
      (phar_obj->arc.archive)->alias_len = oldalias_len;
      (phar_obj->arc.archive)->is_temporary_alias = (unsigned int )old_temp;
      zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
      if (readd) {
        _zend_hash_add_or_update(& phar_globals.phar_alias_map,
                                 (char const   *)oldalias, (uint )oldalias_len,
                                 (void *)(& phar_obj->arc.archive),
                                 (uint )sizeof(phar_archive_data *),
                                 (void **)((void *)0), 1 << 1);
      } else {

      }
      _efree((void *)error);
      while (1) {
        __z___4 = return_value;
        __z___4->value.lval = 0L;
        __z___4->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    _zend_hash_add_or_update(& phar_globals.phar_alias_map,
                             (char const   *)alias, (uint )alias_len,
                             (void *)(& phar_obj->arc.archive),
                             (uint )sizeof(phar_archive_data *),
                             (void **)((void *)0), 1 << 1);
    if (oldalias) {
      _efree((void *)oldalias);
    } else {

    }
    while (1) {
      __z___5 = return_value;
      __z___5->value.lval = 1L;
      __z___5->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  while (1) {
    __z___6 = return_value;
    __z___6->value.lval = 0L;
    __z___6->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zim_Phar_getVersion(int ht , zval *return_value , zval **return_value_ptr ,
                         zval *this_ptr , int return_value_used ) 
{ 
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  char const   *__s ;
  zval *__z ;
  size_t tmp___0 ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  while (1) {
    __s = (char const   *)((phar_obj->arc.archive)->version);
    __z = return_value;
    tmp___0 = strlen(__s);
    __z->value.str.len = (int )tmp___0;
    tmp___1 = _estrndup(__s, (unsigned int )__z->value.str.len);
    __z->value.str.val = (char *)tmp___1;
    __z->type = (zend_uchar )6;
    break;
  }
  return;
}
}
void zim_Phar_startBuffering(int ht , zval *return_value ,
                             zval **return_value_ptr , zval *this_ptr ,
                             int return_value_used ) 
{ 
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  (phar_obj->arc.archive)->donotflush = 1U;
  return;
}
}
void zim_Phar_isBuffering(int ht , zval *return_value ,
                          zval **return_value_ptr , zval *this_ptr ,
                          int return_value_used ) 
{ 
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval *__z ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  while (1) {
    __z = return_value;
    __z->value.lval = (long )((phar_obj->arc.archive)->donotflush != 0U);
    __z->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zim_Phar_stopBuffering(int ht , zval *return_value ,
                            zval **return_value_ptr , zval *this_ptr ,
                            int return_value_used ) 
{ 
  char *error ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  if (phar_globals.readonly) {
    if (! (phar_obj->arc.archive)->is_data) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"Cannot write out phar archive, phar is read-only");
      return;
    } else {

    }
  } else {

  }
  (phar_obj->arc.archive)->donotflush = 0U;
  phar_flush(phar_obj->arc.archive, (char *)0, 0L, 0, & error);
  if (error) {
    zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
    _efree((void *)error);
  } else {

  }
  return;
}
}
void zim_Phar_setStub(int ht , zval *return_value , zval **return_value_ptr ,
                      zval *this_ptr , int return_value_used ) 
{ 
  zval *zstub ;
  char *stub ;
  char *error ;
  int stub_len ;
  long len ;
  php_stream *stream ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int tmp___0 ;
  zval *__z ;
  int __attribute__((__visibility__("default")))  tmp___1 ;
  int __attribute__((__visibility__("default")))  tmp___2 ;
  void __attribute__((__visibility__("default")))  *tmp___3 ;
  int tmp___4 ;
  zval *__z___0 ;
  int __attribute__((__visibility__("default")))  tmp___5 ;
  int __attribute__((__visibility__("default")))  tmp___6 ;
  zval *__z___1 ;

  {
  len = -1L;
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  if (phar_globals.readonly) {
    if (! (phar_obj->arc.archive)->is_data) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"Cannot change stub, phar is read-only");
      return;
    } else {

    }
  } else {

  }
  if ((phar_obj->arc.archive)->is_data) {
    if ((phar_obj->arc.archive)->is_tar) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"A Phar stub cannot be set in a plain tar archive");
    } else {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"A Phar stub cannot be set in a plain zip archive");
    }
    return;
  } else {

  }
  tmp___6 = zend_parse_parameters_ex(1 << 1, ht, "r|l", & zstub, & len);
  if (tmp___6 == (int __attribute__((__visibility__("default")))  )0) {
    tmp___1 = php_file_le_pstream();
    tmp___2 = php_file_le_stream();
    tmp___3 = zend_fetch_resource(& zstub, -1, "stream", (int *)((void *)0), 2,
                                  tmp___2, tmp___1);
    stream = (php_stream *)tmp___3;
    if ((unsigned long )stream != (unsigned long )((void *)0)) {
      if (len > 0L) {
        len = - len;
      } else {
        len = -1L;
      }
      if ((phar_obj->arc.archive)->is_persistent) {
        tmp___0 = phar_copy_on_write(& phar_obj->arc.archive);
        if (-1 == tmp___0) {
          zend_throw_exception_ex(phar_ce_PharException, 0L,
                                  (char *)"phar \"%s\" is persistent, unable to copy on write",
                                  (phar_obj->arc.archive)->fname);
          return;
        } else {

        }
      } else {

      }
      phar_flush(phar_obj->arc.archive, (char *)(& zstub), len, 0, & error);
      if (error) {
        zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
        _efree((void *)error);
      } else {

      }
      while (1) {
        __z = return_value;
        __z->value.lval = 1L;
        __z->type = (zend_uchar )3;
        break;
      }
      return;
    } else {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"Cannot change stub, unable to read from input stream");
    }
  } else {
    tmp___5 = zend_parse_parameters(ht, "s", & stub, & stub_len);
    if (tmp___5 == (int __attribute__((__visibility__("default")))  )0) {
      if ((phar_obj->arc.archive)->is_persistent) {
        tmp___4 = phar_copy_on_write(& phar_obj->arc.archive);
        if (-1 == tmp___4) {
          zend_throw_exception_ex(phar_ce_PharException, 0L,
                                  (char *)"phar \"%s\" is persistent, unable to copy on write",
                                  (phar_obj->arc.archive)->fname);
          return;
        } else {

        }
      } else {

      }
      phar_flush(phar_obj->arc.archive, stub, (long )stub_len, 0, & error);
      if (error) {
        zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
        _efree((void *)error);
      } else {

      }
      while (1) {
        __z___0 = return_value;
        __z___0->value.lval = 1L;
        __z___0->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
  }
  while (1) {
    __z___1 = return_value;
    __z___1->value.lval = 0L;
    __z___1->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zim_Phar_setDefaultStub(int ht , zval *return_value ,
                             zval **return_value_ptr , zval *this_ptr ,
                             int return_value_used ) 
{ 
  char *index___0 ;
  char *webindex ;
  char *error ;
  char *stub ;
  int index_len ;
  int webindex_len ;
  int created_stub ;
  size_t stub_len ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval *__z ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z___0 ;
  zval *__z___1 ;
  zval *__z___2 ;
  int tmp___1 ;
  zval *__z___3 ;
  zval *__z___4 ;

  {
  index___0 = (char *)((void *)0);
  webindex = (char *)((void *)0);
  error = (char *)((void *)0);
  stub = (char *)((void *)0);
  index_len = 0;
  webindex_len = 0;
  created_stub = 0;
  stub_len = (size_t )0;
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  if ((phar_obj->arc.archive)->is_data) {
    if ((phar_obj->arc.archive)->is_tar) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"A Phar stub cannot be set in a plain tar archive");
    } else {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"A Phar stub cannot be set in a plain zip archive");
    }
    return;
  } else {

  }
  tmp___0 = zend_parse_parameters(ht, "|s!s", & index___0, & index_len,
                                  & webindex, & webindex_len);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  if (ht > 0) {
    if ((phar_obj->arc.archive)->is_tar) {
      goto _L;
    } else
    if ((phar_obj->arc.archive)->is_zip) {
      _L: 
      php_error_docref0((char const   *)((void *)0), 1 << 1L,
                        "method accepts no arguments for a tar- or zip-based phar stub, %d given",
                        ht);
      while (1) {
        __z___0 = return_value;
        __z___0->value.lval = 0L;
        __z___0->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
  } else {

  }
  if (phar_globals.readonly) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                            0L, (char *)"Cannot change stub: phar.readonly=1");
    while (1) {
      __z___1 = return_value;
      __z___1->value.lval = 0L;
      __z___1->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  if (! (phar_obj->arc.archive)->is_tar) {
    if (! (phar_obj->arc.archive)->is_zip) {
      stub = phar_create_default_stub((char const   *)index___0,
                                      (char const   *)webindex, & stub_len,
                                      & error);
      if (error) {
        zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                                0L, (char *)"%s", error);
        _efree((void *)error);
        if (stub) {
          _efree((void *)stub);
        } else {

        }
        while (1) {
          __z___2 = return_value;
          __z___2->value.lval = 0L;
          __z___2->type = (zend_uchar )3;
          break;
        }
        return;
      } else {

      }
      created_stub = 1;
    } else {

    }
  } else {

  }
  if ((phar_obj->arc.archive)->is_persistent) {
    tmp___1 = phar_copy_on_write(& phar_obj->arc.archive);
    if (-1 == tmp___1) {
      zend_throw_exception_ex(phar_ce_PharException, 0L,
                              (char *)"phar \"%s\" is persistent, unable to copy on write",
                              (phar_obj->arc.archive)->fname);
      return;
    } else {

    }
  } else {

  }
  phar_flush(phar_obj->arc.archive, stub, (long )stub_len, 1, & error);
  if (created_stub) {
    _efree((void *)stub);
  } else {

  }
  if (error) {
    zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
    _efree((void *)error);
    while (1) {
      __z___3 = return_value;
      __z___3->value.lval = 0L;
      __z___3->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  while (1) {
    __z___4 = return_value;
    __z___4->value.lval = 1L;
    __z___4->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zim_Phar_setSignatureAlgorithm(int ht , zval *return_value ,
                                    zval **return_value_ptr , zval *this_ptr ,
                                    int return_value_used ) 
{ 
  long algo ;
  char *error ;
  char *key ;
  int key_len ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  int tmp___1 ;

  {
  key = (char *)((void *)0);
  key_len = 0;
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  if (phar_globals.readonly) {
    if (! (phar_obj->arc.archive)->is_data) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"Cannot set signature algorithm, phar is read-only");
      return;
    } else {

    }
  } else {

  }
  tmp___0 = zend_parse_parameters_ex(1 << 1, ht, "l|s", & algo, & key, & key_len);
  if (tmp___0 != (int __attribute__((__visibility__("default")))  )0) {
    return;
  } else {

  }
  switch (algo) {
  case 3L: 
  case 4L: 
  case 1L: 
  case 2L: 
  case 16L: 
  if ((phar_obj->arc.archive)->is_persistent) {
    tmp___1 = phar_copy_on_write(& phar_obj->arc.archive);
    if (-1 == tmp___1) {
      zend_throw_exception_ex(phar_ce_PharException, 0L,
                              (char *)"phar \"%s\" is persistent, unable to copy on write",
                              (phar_obj->arc.archive)->fname);
      return;
    } else {

    }
  } else {

  }
  (phar_obj->arc.archive)->sig_flags = (php_uint32 )algo;
  (phar_obj->arc.archive)->is_modified = 1U;
  phar_globals.openssl_privatekey = key;
  phar_globals.openssl_privatekey_len = key_len;
  phar_flush(phar_obj->arc.archive, (char *)0, 0L, 0, & error);
  if (error) {
    zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
    _efree((void *)error);
  } else {

  }
  break;
  default: 
  zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                          0L, (char *)"Unknown signature algorithm specified");
  }
  return;
}
}
void zim_Phar_getSignature(int ht , zval *return_value ,
                           zval **return_value_ptr , zval *this_ptr ,
                           int return_value_used ) 
{ 
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  char *unknown ;
  int unknown_len ;
  size_t tmp___0 ;
  size_t tmp___1 ;
  size_t tmp___2 ;
  size_t tmp___3 ;
  size_t tmp___4 ;
  size_t tmp___5 ;
  int __attribute__((__visibility__("default")))  tmp___6 ;
  size_t tmp___7 ;
  zval *__z ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  if ((phar_obj->arc.archive)->signature) {
    _array_init(return_value, (uint )0);
    tmp___0 = strlen("hash");
    add_assoc_stringl_ex(return_value, "hash", (uint )(tmp___0 + 1UL),
                         (phar_obj->arc.archive)->signature,
                         (uint )(phar_obj->arc.archive)->sig_len, 1);
    switch ((phar_obj->arc.archive)->sig_flags) {
    case 1U: 
    tmp___1 = strlen("hash_type");
    add_assoc_stringl_ex(return_value, "hash_type", (uint )(tmp___1 + 1UL),
                         (char *)"MD5", (uint )3, 1);
    break;
    case 2U: 
    tmp___2 = strlen("hash_type");
    add_assoc_stringl_ex(return_value, "hash_type", (uint )(tmp___2 + 1UL),
                         (char *)"SHA-1", (uint )5, 1);
    break;
    case 3U: 
    tmp___3 = strlen("hash_type");
    add_assoc_stringl_ex(return_value, "hash_type", (uint )(tmp___3 + 1UL),
                         (char *)"SHA-256", (uint )7, 1);
    break;
    case 4U: 
    tmp___4 = strlen("hash_type");
    add_assoc_stringl_ex(return_value, "hash_type", (uint )(tmp___4 + 1UL),
                         (char *)"SHA-512", (uint )7, 1);
    break;
    case 16U: 
    tmp___5 = strlen("hash_type");
    add_assoc_stringl_ex(return_value, "hash_type", (uint )(tmp___5 + 1UL),
                         (char *)"OpenSSL", (uint )7, 1);
    break;
    default: 
    tmp___6 = spprintf(& unknown, (size_t )0, "Unknown (%u)",
                       (phar_obj->arc.archive)->sig_flags);
    unknown_len = (int )tmp___6;
    tmp___7 = strlen("hash_type");
    add_assoc_stringl_ex(return_value, "hash_type", (uint )(tmp___7 + 1UL),
                         unknown, (uint )unknown_len, 0);
    break;
    }
  } else {
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  }
  return;
}
}
void zim_Phar_getModified(int ht , zval *return_value ,
                          zval **return_value_ptr , zval *this_ptr ,
                          int return_value_used ) 
{ 
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval *__z ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  while (1) {
    __z = return_value;
    __z->value.lval = (long )((phar_obj->arc.archive)->is_modified != 0U);
    __z->type = (zend_uchar )3;
    break;
  }
  return;
}
}
static int phar_set_compression(void *pDest , void *argument ) 
{ 
  phar_entry_info *entry ;
  php_uint32 compress ;

  {
  entry = (phar_entry_info *)pDest;
  compress = *((php_uint32 *)argument);
  if (entry->is_deleted) {
    return (0);
  } else {

  }
  entry->old_flags = entry->flags;
  entry->flags &= 4294905855U;
  entry->flags |= compress;
  entry->is_modified = 1U;
  return (0);
}
}
static int phar_test_compression(void *pDest , void *argument ) 
{ 
  phar_entry_info *entry ;

  {
  entry = (phar_entry_info *)pDest;
  if (entry->is_deleted) {
    return (0);
  } else {

  }
  if (! phar_globals.has_bz2) {
    if (entry->flags & 8192U) {
      *((int *)argument) = 0;
    } else {

    }
  } else {

  }
  if (! phar_globals.has_zlib) {
    if (entry->flags & 4096U) {
      *((int *)argument) = 0;
    } else {

    }
  } else {

  }
  return (0);
}
}
static void pharobj_set_compression(HashTable *manifest , php_uint32 compress ) 
{ 


  {
  zend_hash_apply_with_argument(manifest, & phar_set_compression,
                                (void *)(& compress));
  return;
}
}
static int pharobj_cancompress(HashTable *manifest ) 
{ 
  int test ;

  {
  test = 1;
  zend_hash_apply_with_argument(manifest, & phar_test_compression,
                                (void *)(& test));
  return (test);
}
}
void zim_Phar_compress(int ht , zval *return_value , zval **return_value_ptr ,
                       zval *this_ptr , int return_value_used ) 
{ 
  long method ;
  char *ext ;
  int ext_len ;
  php_uint32 flags ;
  zval *ret ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zend_uchar is_ref ;
  zend_bool tmp___1 ;
  zend_uint refcount ;
  zend_uint tmp___2 ;

  {
  ext = (char *)((void *)0);
  ext_len = 0;
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  tmp___0 = zend_parse_parameters(ht, "l|s", & method, & ext, & ext_len);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (phar_globals.readonly) {
    if (! (phar_obj->arc.archive)->is_data) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"Cannot compress phar archive, phar is read-only");
      return;
    } else {

    }
  } else {

  }
  if ((phar_obj->arc.archive)->is_zip) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                            0L,
                            (char *)"Cannot compress zip-based archives with whole-archive compression");
    return;
  } else {

  }
  switch (method) {
  case 0L: 
  flags = (php_uint32 )0;
  break;
  case 4096L: 
  if (! phar_globals.has_zlib) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot compress entire archive with gzip, enable ext/zlib in php.ini");
    return;
  } else {

  }
  flags = (php_uint32 )1048576;
  break;
  case 8192L: 
  if (! phar_globals.has_bz2) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot compress entire archive with bz2, enable ext/bz2 in php.ini");
    return;
  } else {

  }
  flags = (php_uint32 )2097152;
  break;
  default: 
  zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException, 0L,
                          (char *)"Unknown compression specified, please pass one of Phar::GZ or Phar::BZ2");
  return;
  }
  if ((phar_obj->arc.archive)->is_tar) {
    ret = phar_convert_to_other(phar_obj->arc.archive, 2, ext, flags);
  } else {
    ret = phar_convert_to_other(phar_obj->arc.archive, 1, ext, flags);
  }
  if (ret) {
    tmp___1 = zval_isref_p(return_value);
    is_ref = tmp___1;
    tmp___2 = zval_refcount_p(return_value);
    refcount = tmp___2;
    while (1) {
      return_value->value = ret->value;
      return_value->type = ret->type;
      break;
    }
    _zval_copy_ctor(return_value);
    _zval_ptr_dtor(& ret);
    zval_set_isref_to_p(return_value, is_ref);
    zval_set_refcount_p(return_value, refcount);
    return;
  } else {
    return_value->type = (zend_uchar )0;
    return;
  }
}
}
void zim_Phar_decompress(int ht , zval *return_value , zval **return_value_ptr ,
                         zval *this_ptr , int return_value_used ) 
{ 
  char *ext ;
  int ext_len ;
  zval *ret ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zend_uchar is_ref ;
  zend_bool tmp___1 ;
  zend_uint refcount ;
  zend_uint tmp___2 ;

  {
  ext = (char *)((void *)0);
  ext_len = 0;
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  tmp___0 = zend_parse_parameters(ht, "|s", & ext, & ext_len);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (phar_globals.readonly) {
    if (! (phar_obj->arc.archive)->is_data) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"Cannot decompress phar archive, phar is read-only");
      return;
    } else {

    }
  } else {

  }
  if ((phar_obj->arc.archive)->is_zip) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                            0L,
                            (char *)"Cannot decompress zip-based archives with whole-archive compression");
    return;
  } else {

  }
  if ((phar_obj->arc.archive)->is_tar) {
    ret = phar_convert_to_other(phar_obj->arc.archive, 2, ext, (php_uint32 )0);
  } else {
    ret = phar_convert_to_other(phar_obj->arc.archive, 1, ext, (php_uint32 )0);
  }
  if (ret) {
    tmp___1 = zval_isref_p(return_value);
    is_ref = tmp___1;
    tmp___2 = zval_refcount_p(return_value);
    refcount = tmp___2;
    while (1) {
      return_value->value = ret->value;
      return_value->type = ret->type;
      break;
    }
    _zval_copy_ctor(return_value);
    _zval_ptr_dtor(& ret);
    zval_set_isref_to_p(return_value, is_ref);
    zval_set_refcount_p(return_value, refcount);
    return;
  } else {
    return_value->type = (zend_uchar )0;
    return;
  }
}
}
void zim_Phar_compressFiles(int ht , zval *return_value ,
                            zval **return_value_ptr , zval *this_ptr ,
                            int return_value_used ) 
{ 
  char *error ;
  php_uint32 flags ;
  long method ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  tmp___0 = zend_parse_parameters(ht, "l", & method);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (phar_globals.readonly) {
    if (! (phar_obj->arc.archive)->is_data) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Phar is readonly, cannot change compression");
      return;
    } else {

    }
  } else {

  }
  switch (method) {
  case 4096L: 
  if (! phar_globals.has_zlib) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot compress files within archive with gzip, enable ext/zlib in php.ini");
    return;
  } else {

  }
  flags = (php_uint32 )4096;
  break;
  case 8192L: 
  if (! phar_globals.has_bz2) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot compress files within archive with bz2, enable ext/bz2 in php.ini");
    return;
  } else {

  }
  flags = (php_uint32 )8192;
  break;
  default: 
  zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException, 0L,
                          (char *)"Unknown compression specified, please pass one of Phar::GZ or Phar::BZ2");
  return;
  }
  if ((phar_obj->arc.archive)->is_tar) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot compress with Gzip compression, tar archives cannot compress individual files, use compress() to compress the whole archive");
    return;
  } else {

  }
  tmp___1 = pharobj_cancompress(& (phar_obj->arc.archive)->manifest);
  if (! tmp___1) {
    if (flags == 1048576U) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Cannot compress all files as Gzip, some are compressed as bzip2 and cannot be decompressed");
    } else {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Cannot compress all files as Bzip2, some are compressed as gzip and cannot be decompressed");
    }
    return;
  } else {

  }
  if ((phar_obj->arc.archive)->is_persistent) {
    tmp___2 = phar_copy_on_write(& phar_obj->arc.archive);
    if (-1 == tmp___2) {
      zend_throw_exception_ex(phar_ce_PharException, 0L,
                              (char *)"phar \"%s\" is persistent, unable to copy on write",
                              (phar_obj->arc.archive)->fname);
      return;
    } else {

    }
  } else {

  }
  pharobj_set_compression(& (phar_obj->arc.archive)->manifest, flags);
  (phar_obj->arc.archive)->is_modified = 1U;
  phar_flush(phar_obj->arc.archive, (char *)0, 0L, 0, & error);
  if (error) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L, (char *)"%s", error);
    _efree((void *)error);
  } else {

  }
  return;
}
}
void zim_Phar_decompressFiles(int ht , zval *return_value ,
                              zval **return_value_ptr , zval *this_ptr ,
                              int return_value_used ) 
{ 
  char *error ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int tmp___0 ;
  zval *__z ;
  int tmp___1 ;
  zval *__z___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  if (phar_globals.readonly) {
    if (! (phar_obj->arc.archive)->is_data) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Phar is readonly, cannot change compression");
      return;
    } else {

    }
  } else {

  }
  tmp___0 = pharobj_cancompress(& (phar_obj->arc.archive)->manifest);
  if (! tmp___0) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot decompress all files, some are compressed as bzip2 or gzip and cannot be decompressed");
    return;
  } else {

  }
  if ((phar_obj->arc.archive)->is_tar) {
    while (1) {
      __z = return_value;
      __z->value.lval = 1L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {
    if ((phar_obj->arc.archive)->is_persistent) {
      tmp___1 = phar_copy_on_write(& phar_obj->arc.archive);
      if (-1 == tmp___1) {
        zend_throw_exception_ex(phar_ce_PharException, 0L,
                                (char *)"phar \"%s\" is persistent, unable to copy on write",
                                (phar_obj->arc.archive)->fname);
        return;
      } else {

      }
    } else {

    }
    pharobj_set_compression(& (phar_obj->arc.archive)->manifest, (php_uint32 )0);
  }
  (phar_obj->arc.archive)->is_modified = 1U;
  phar_flush(phar_obj->arc.archive, (char *)0, 0L, 0, & error);
  if (error) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L, (char *)"%s", error);
    _efree((void *)error);
  } else {

  }
  while (1) {
    __z___0 = return_value;
    __z___0->value.lval = 1L;
    __z___0->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zim_Phar_copy(int ht , zval *return_value , zval **return_value_ptr ,
                   zval *this_ptr , int return_value_used ) 
{ 
  char *oldfile ;
  char *newfile ;
  char *error ;
  char const   *pcr_error ;
  int oldfile_len ;
  int newfile_len ;
  phar_entry_info *oldentry ;
  phar_entry_info newentry ;
  phar_entry_info *temp ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z ;
  zval *__z___0 ;
  int tmp___1 ;
  zval *__z___1 ;
  int tmp___2 ;
  zval *__z___2 ;
  int __attribute__((__visibility__("default")))  tmp___3 ;
  int __attribute__((__visibility__("default")))  tmp___4 ;
  zval *__z___3 ;
  int __attribute__((__visibility__("default")))  tmp___5 ;
  int __attribute__((__visibility__("default")))  tmp___6 ;
  zval *__z___4 ;
  phar_path_check_result tmp___7 ;
  int tmp___8 ;
  zval *t ;
  void __attribute__((__visibility__("default")))  *tmp___9 ;
  char __attribute__((__visibility__("default")))  *tmp___10 ;
  int tmp___11 ;
  zval *__z___5 ;

  {
  newentry.uncompressed_filesize = (php_uint32 )0;
  newentry.timestamp = 0U;
  newentry.compressed_filesize = 0U;
  newentry.crc32 = 0U;
  newentry.flags = 0U;
  newentry.old_flags = 0U;
  newentry.metadata = (zval *)0;
  newentry.metadata_len = 0;
  newentry.filename_len = 0U;
  newentry.filename = (char *)0;
  newentry.fp_type = (enum phar_fp_type )0U;
  newentry.offset_abs = 0L;
  newentry.offset = 0L;
  newentry.header_offset = 0L;
  newentry.fp = (php_stream *)0;
  newentry.cfp = (php_stream *)0;
  newentry.fp_refcount = 0;
  newentry.tmp = (char *)0;
  newentry.phar = (phar_archive_data *)0;
  newentry.metadata_str.c = (char *)0;
  newentry.metadata_str.len = 0UL;
  newentry.metadata_str.a = 0UL;
  newentry.link = (char *)0;
  newentry.tar_type = (char)0;
  newentry.manifest_pos = 0U;
  newentry.inode = (unsigned short)0;
  newentry.is_crc_checked = 0U;
  newentry.is_modified = 0U;
  newentry.is_deleted = 0U;
  newentry.is_dir = 0U;
  newentry.is_mounted = 0U;
  newentry.is_temp_dir = 0U;
  newentry.is_tar = 0U;
  newentry.is_zip = 0U;
  newentry.is_persistent = 0U;
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  tmp___0 = zend_parse_parameters(ht, "ss", & oldfile, & oldfile_len, & newfile,
                                  & newfile_len);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (phar_globals.readonly) {
    if (! (phar_obj->arc.archive)->is_data) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"Cannot copy \"%s\" to \"%s\", phar is read-only",
                              oldfile, newfile);
      while (1) {
        __z = return_value;
        __z->value.lval = 0L;
        __z->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
  } else {

  }
  if ((unsigned long )oldfile_len >= sizeof(".phar") - 1UL) {
    tmp___1 = memcmp((void const   *)oldfile, (void const   *)".phar",
                     sizeof(".phar") - 1UL);
    if (! tmp___1) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"file \"%s\" cannot be copied to file \"%s\", cannot copy Phar meta-file in %s",
                              oldfile, newfile, (phar_obj->arc.archive)->fname);
      while (1) {
        __z___0 = return_value;
        __z___0->value.lval = 0L;
        __z___0->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
  } else {

  }
  if ((unsigned long )newfile_len >= sizeof(".phar") - 1UL) {
    tmp___2 = memcmp((void const   *)newfile, (void const   *)".phar",
                     sizeof(".phar") - 1UL);
    if (! tmp___2) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"file \"%s\" cannot be copied to file \"%s\", cannot copy to Phar meta-file in %s",
                              oldfile, newfile, (phar_obj->arc.archive)->fname);
      while (1) {
        __z___1 = return_value;
        __z___1->value.lval = 0L;
        __z___1->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
  } else {

  }
  tmp___3 = zend_hash_exists((HashTable const   *)(& (phar_obj->arc.archive)->manifest),
                             (char const   *)oldfile, (uint )oldfile_len);
  if (tmp___3) {
    tmp___4 = zend_hash_find((HashTable const   *)(& (phar_obj->arc.archive)->manifest),
                             (char const   *)oldfile, (uint )oldfile_len,
                             (void **)(& oldentry));
    if (0 != (int )tmp___4) {
      goto _L;
    } else
    if (oldentry->is_deleted) {
      _L: 
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"file \"%s\" cannot be copied to file \"%s\", file does not exist in %s",
                              oldfile, newfile, (phar_obj->arc.archive)->fname);
      while (1) {
        __z___2 = return_value;
        __z___2->value.lval = 0L;
        __z___2->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
  } else {
    goto _L;
  }
  tmp___6 = zend_hash_exists((HashTable const   *)(& (phar_obj->arc.archive)->manifest),
                             (char const   *)newfile, (uint )newfile_len);
  if (tmp___6) {
    tmp___5 = zend_hash_find((HashTable const   *)(& (phar_obj->arc.archive)->manifest),
                             (char const   *)newfile, (uint )newfile_len,
                             (void **)(& temp));
    if (0 == (int )tmp___5) {
      goto _L___0;
    } else
    if (! temp->is_deleted) {
      _L___0: 
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L,
                              (char *)"file \"%s\" cannot be copied to file \"%s\", file must not already exist in phar %s",
                              oldfile, newfile, (phar_obj->arc.archive)->fname);
      while (1) {
        __z___3 = return_value;
        __z___3->value.lval = 0L;
        __z___3->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
  } else {

  }
  tmp___7 = phar_path_check(& newfile, & newfile_len, & pcr_error);
  if ((unsigned int )tmp___7 > 1U) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                            0L,
                            (char *)"file \"%s\" contains invalid characters %s, cannot be copied from \"%s\" in phar %s",
                            newfile, pcr_error, oldfile,
                            (phar_obj->arc.archive)->fname);
    while (1) {
      __z___4 = return_value;
      __z___4->value.lval = 0L;
      __z___4->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  if ((phar_obj->arc.archive)->is_persistent) {
    tmp___8 = phar_copy_on_write(& phar_obj->arc.archive);
    if (-1 == tmp___8) {
      zend_throw_exception_ex(phar_ce_PharException, 0L,
                              (char *)"phar \"%s\" is persistent, unable to copy on write",
                              (phar_obj->arc.archive)->fname);
      return;
    } else {

    }
    zend_hash_find((HashTable const   *)(& (phar_obj->arc.archive)->manifest),
                   (char const   *)oldfile, (uint )oldfile_len,
                   (void **)(& oldentry));
  } else {

  }
  memcpy((void */* __restrict  */)((void *)(& newentry)),
         (void const   */* __restrict  */)oldentry, sizeof(phar_entry_info ));
  if (newentry.metadata) {
    t = newentry.metadata;
    while (1) {
      tmp___9 = _emalloc(sizeof(zval_gc_info ));
      newentry.metadata = (zval *)tmp___9;
      ((zval_gc_info *)newentry.metadata)->u.buffered = (gc_root_buffer *)((void *)0);
      break;
    }
    *(newentry.metadata) = *t;
    _zval_copy_ctor(newentry.metadata);
    zval_set_refcount_p(newentry.metadata, (zend_uint )1);
    newentry.metadata_str.c = (char *)((void *)0);
    newentry.metadata_str.len = (size_t )0;
  } else {

  }
  tmp___10 = _estrndup((char const   *)newfile, (unsigned int )newfile_len);
  newentry.filename = (char *)tmp___10;
  newentry.filename_len = (php_uint32 )newfile_len;
  newentry.fp_refcount = 0;
  if ((unsigned int )oldentry->fp_type != 0U) {
    tmp___11 = phar_copy_entry_fp(oldentry, & newentry, & error);
    if (-1 == tmp___11) {
      _efree((void *)newentry.filename);
      _php_stream_free(newentry.fp, 3);
      zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
      _efree((void *)error);
      return;
    } else {

    }
  } else {

  }
  _zend_hash_add_or_update(& (oldentry->phar)->manifest,
                           (char const   *)newfile, (uint )newfile_len,
                           (void *)(& newentry),
                           (uint )sizeof(phar_entry_info ),
                           (void **)((void *)0), 1 << 1);
  (phar_obj->arc.archive)->is_modified = 1U;
  phar_flush(phar_obj->arc.archive, (char *)0, 0L, 0, & error);
  if (error) {
    zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
    _efree((void *)error);
  } else {

  }
  while (1) {
    __z___5 = return_value;
    __z___5->value.lval = 1L;
    __z___5->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zim_Phar_offsetExists(int ht , zval *return_value ,
                           zval **return_value_ptr , zval *this_ptr ,
                           int return_value_used ) 
{ 
  char *fname ;
  int fname_len ;
  phar_entry_info *entry ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z ;
  int __attribute__((__visibility__("default")))  tmp___1 ;
  zval *__z___0 ;
  int tmp___2 ;
  zval *__z___1 ;
  zval *__z___2 ;
  int __attribute__((__visibility__("default")))  tmp___3 ;
  zval *__z___3 ;
  int __attribute__((__visibility__("default")))  tmp___4 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  tmp___0 = zend_parse_parameters(ht, "s", & fname, & fname_len);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  tmp___4 = zend_hash_exists((HashTable const   *)(& (phar_obj->arc.archive)->manifest),
                             (char const   *)fname, (uint )fname_len);
  if (tmp___4) {
    tmp___1 = zend_hash_find((HashTable const   *)(& (phar_obj->arc.archive)->manifest),
                             (char const   *)fname, (uint )fname_len,
                             (void **)(& entry));
    if (0 == (int )tmp___1) {
      if (entry->is_deleted) {
        while (1) {
          __z = return_value;
          __z->value.lval = 0L;
          __z->type = (zend_uchar )3;
          break;
        }
        return;
      } else {

      }
    } else {

    }
    if ((unsigned long )fname_len >= sizeof(".phar") - 1UL) {
      tmp___2 = memcmp((void const   *)fname, (void const   *)".phar",
                       sizeof(".phar") - 1UL);
      if (! tmp___2) {
        while (1) {
          __z___0 = return_value;
          __z___0->value.lval = 0L;
          __z___0->type = (zend_uchar )3;
          break;
        }
        return;
      } else {

      }
    } else {

    }
    while (1) {
      __z___1 = return_value;
      __z___1->value.lval = 1L;
      __z___1->type = (zend_uchar )3;
      break;
    }
    return;
  } else {
    tmp___3 = zend_hash_exists((HashTable const   *)(& (phar_obj->arc.archive)->virtual_dirs),
                               (char const   *)fname, (uint )fname_len);
    if (tmp___3) {
      while (1) {
        __z___2 = return_value;
        __z___2->value.lval = 1L;
        __z___2->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    while (1) {
      __z___3 = return_value;
      __z___3->value.lval = 0L;
      __z___3->type = (zend_uchar )3;
      break;
    }
    return;
  }
}
}
void zim_Phar_offsetGet(int ht , zval *return_value , zval **return_value_ptr ,
                        zval *this_ptr , int return_value_used ) 
{ 
  char *fname ;
  char *error ;
  int fname_len ;
  zval *zfname ;
  phar_entry_info *entry ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  char const   *tmp___1 ;
  char const   *tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  int __attribute__((__visibility__("default")))  tmp___6 ;
  void __attribute__((__visibility__("default")))  *tmp___7 ;
  char const   *__s ;
  int __l ;
  zval *__z ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  tmp___0 = zend_parse_parameters(ht, "s", & fname, & fname_len);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  entry = phar_get_entry_info_dir(phar_obj->arc.archive, fname, fname_len,
                                  (char)1, & error, 0);
  if (entry) {
    if ((unsigned long )fname_len == sizeof(".phar/stub.php") - 1UL) {
      tmp___3 = memcmp((void const   *)fname, (void const   *)".phar/stub.php",
                       sizeof(".phar/stub.php") - 1UL);
      if (! tmp___3) {
        zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                                0L,
                                (char *)"Cannot get stub \".phar/stub.php\" directly in phar \"%s\", use getStub",
                                (phar_obj->arc.archive)->fname);
        return;
      } else {

      }
    } else {

    }
    if ((unsigned long )fname_len == sizeof(".phar/alias.txt") - 1UL) {
      tmp___4 = memcmp((void const   *)fname, (void const   *)".phar/alias.txt",
                       sizeof(".phar/alias.txt") - 1UL);
      if (! tmp___4) {
        zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                                0L,
                                (char *)"Cannot get alias \".phar/alias.txt\" directly in phar \"%s\", use getAlias",
                                (phar_obj->arc.archive)->fname);
        return;
      } else {

      }
    } else {

    }
    if ((unsigned long )fname_len >= sizeof(".phar") - 1UL) {
      tmp___5 = memcmp((void const   *)fname, (void const   *)".phar",
                       sizeof(".phar") - 1UL);
      if (! tmp___5) {
        zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                                0L,
                                (char *)"Cannot directly get any files or directories in magic \".phar\" directory",
                                (phar_obj->arc.archive)->fname);
        return;
      } else {

      }
    } else {

    }
    if (entry->is_temp_dir) {
      _efree((void *)entry->filename);
      _efree((void *)entry);
    } else {

    }
    tmp___6 = spprintf(& fname, (size_t )0, "phar://%s/%s",
                       (phar_obj->arc.archive)->fname, fname);
    fname_len = (int )tmp___6;
    while (1) {
      tmp___7 = _emalloc(sizeof(zval_gc_info ));
      zfname = (zval *)tmp___7;
      ((zval_gc_info *)zfname)->u.buffered = (gc_root_buffer *)((void *)0);
      break;
    }
    zfname->refcount__gc = (zend_uint )1;
    zfname->is_ref__gc = (zend_uchar )0;
    while (1) {
      __s = (char const   *)fname;
      __l = fname_len;
      __z = zfname;
      __z->value.str.len = __l;
      __z->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
      __z->type = (zend_uchar )6;
      break;
    }
    spl_instantiate_arg_ex1(phar_obj->spl.info_class, & return_value, 0, zfname);
    _zval_ptr_dtor(& zfname);
  } else {
    if (error) {
      tmp___1 = (char const   *)error;
    } else {
      tmp___1 = "";
    }
    if (error) {
      tmp___2 = ", ";
    } else {
      tmp___2 = "";
    }
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L, (char *)"Entry %s does not exist%s%s", fname,
                            tmp___2, tmp___1);
  }
  return;
}
}
static void phar_add_file(phar_archive_data **pphar , char *filename ,
                          int filename_len , char *cont_str , int cont_len ,
                          zval *zresource ) 
{ 
  char *error ;
  size_t contents_len ;
  phar_entry_data *data ;
  php_stream *contents_file ;
  int tmp ;
  size_t __attribute__((__visibility__("default")))  tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;
  int __attribute__((__visibility__("default")))  tmp___2 ;
  void __attribute__((__visibility__("default")))  *tmp___3 ;
  php_uint32 tmp___4 ;

  {
  if ((unsigned long )filename_len >= sizeof(".phar") - 1UL) {
    tmp = memcmp((void const   *)filename, (void const   *)".phar",
                 sizeof(".phar") - 1UL);
    if (! tmp) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Cannot create any files in magic \".phar\" directory",
                              (*pphar)->fname);
      return;
    } else {

    }
  } else {

  }
  data = phar_get_or_create_entry_data((*pphar)->fname, (*pphar)->fname_len,
                                       filename, filename_len, (char *)"w+b",
                                       (char)0, & error, 1);
  if (data) {
    if (error) {
      _efree((void *)error);
    } else {

    }
    if (! (data->internal_file)->is_dir) {
      if (cont_str) {
        tmp___0 = _php_stream_write(data->fp, (char const   *)cont_str,
                                    (size_t )cont_len);
        contents_len = (size_t )tmp___0;
        if (contents_len != (size_t )cont_len) {
          zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                                  0L,
                                  (char *)"Entry %s could not be written to",
                                  filename);
          return;
        } else {

        }
      } else {
        tmp___1 = php_file_le_pstream();
        tmp___2 = php_file_le_stream();
        tmp___3 = zend_fetch_resource(& zresource, -1, "stream",
                                      (int *)((void *)0), 2, tmp___2, tmp___1);
        contents_file = (php_stream *)tmp___3;
        if (! contents_file) {
          zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                                  0L,
                                  (char *)"Entry %s could not be written to",
                                  filename);
          return;
        } else {

        }
        _php_stream_copy_to_stream_ex(contents_file, data->fp, (size_t )-1,
                                      & contents_len);
      }
      tmp___4 = (php_uint32 )contents_len;
      (data->internal_file)->uncompressed_filesize = tmp___4;
      (data->internal_file)->compressed_filesize = tmp___4;
    } else {

    }
    if ((unsigned long )*(pphar + 0) != (unsigned long )data->phar) {
      *pphar = data->phar;
    } else {

    }
    phar_entry_delref(data);
    phar_flush(*pphar, (char *)0, 0L, 0, & error);
    if (error) {
      zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
      _efree((void *)error);
    } else {

    }
  } else {
    if (error) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Entry %s does not exist and cannot be created: %s",
                              filename, error);
      _efree((void *)error);
    } else {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Entry %s does not exist and cannot be created",
                              filename);
    }
    return;
  }
  return;
}
}
static void phar_mkdir(phar_archive_data **pphar , char *dirname ,
                       int dirname_len ) 
{ 
  char *error ;
  phar_entry_data *data ;

  {
  data = phar_get_or_create_entry_data((*pphar)->fname, (*pphar)->fname_len,
                                       dirname, dirname_len, (char *)"w+b",
                                       (char)2, & error, 1);
  if (data) {
    if (error) {
      _efree((void *)error);
    } else {

    }
    if ((unsigned long )data->phar != (unsigned long )*pphar) {
      *pphar = data->phar;
    } else {

    }
    phar_entry_delref(data);
    phar_flush(*pphar, (char *)0, 0L, 0, & error);
    if (error) {
      zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
      _efree((void *)error);
    } else {

    }
  } else {
    if (error) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Directory %s does not exist and cannot be created: %s",
                              dirname, error);
      _efree((void *)error);
    } else {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Directory %s does not exist and cannot be created",
                              dirname);
    }
    return;
  }
  return;
}
}
void zim_Phar_offsetSet(int ht , zval *return_value , zval **return_value_ptr ,
                        zval *this_ptr , int return_value_used ) 
{ 
  char *fname ;
  char *cont_str ;
  int fname_len ;
  int cont_len ;
  zval *zresource ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;

  {
  cont_str = (char *)((void *)0);
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  if (phar_globals.readonly) {
    if (! (phar_obj->arc.archive)->is_data) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Write operations disabled by the php.ini setting phar.readonly");
      return;
    } else {

    }
  } else {

  }
  tmp___0 = zend_parse_parameters_ex(1 << 1, ht, "sr", & fname, & fname_len,
                                     & zresource);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    tmp___1 = zend_parse_parameters(ht, "ss", & fname, & fname_len, & cont_str,
                                    & cont_len);
    if (tmp___1 == (int __attribute__((__visibility__("default")))  )-1) {
      return;
    } else {

    }
  } else {

  }
  if ((unsigned long )fname_len == sizeof(".phar/stub.php") - 1UL) {
    tmp___2 = memcmp((void const   *)fname, (void const   *)".phar/stub.php",
                     sizeof(".phar/stub.php") - 1UL);
    if (! tmp___2) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Cannot set stub \".phar/stub.php\" directly in phar \"%s\", use setStub",
                              (phar_obj->arc.archive)->fname);
      return;
    } else {

    }
  } else {

  }
  if ((unsigned long )fname_len == sizeof(".phar/alias.txt") - 1UL) {
    tmp___3 = memcmp((void const   *)fname, (void const   *)".phar/alias.txt",
                     sizeof(".phar/alias.txt") - 1UL);
    if (! tmp___3) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Cannot set alias \".phar/alias.txt\" directly in phar \"%s\", use setAlias",
                              (phar_obj->arc.archive)->fname);
      return;
    } else {

    }
  } else {

  }
  if ((unsigned long )fname_len >= sizeof(".phar") - 1UL) {
    tmp___4 = memcmp((void const   *)fname, (void const   *)".phar",
                     sizeof(".phar") - 1UL);
    if (! tmp___4) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Cannot set any files or directories in magic \".phar\" directory",
                              (phar_obj->arc.archive)->fname);
      return;
    } else {

    }
  } else {

  }
  phar_add_file(& phar_obj->arc.archive, fname, fname_len, cont_str, cont_len,
                zresource);
  return;
}
}
void zim_Phar_offsetUnset(int ht , zval *return_value ,
                          zval **return_value_ptr , zval *this_ptr ,
                          int return_value_used ) 
{ 
  char *fname ;
  char *error ;
  int fname_len ;
  phar_entry_info *entry ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  int tmp___1 ;
  zval *__z ;
  int __attribute__((__visibility__("default")))  tmp___2 ;
  zval *__z___0 ;
  int __attribute__((__visibility__("default")))  tmp___3 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  if (phar_globals.readonly) {
    if (! (phar_obj->arc.archive)->is_data) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Write operations disabled by the php.ini setting phar.readonly");
      return;
    } else {

    }
  } else {

  }
  tmp___0 = zend_parse_parameters(ht, "s", & fname, & fname_len);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  tmp___3 = zend_hash_exists((HashTable const   *)(& (phar_obj->arc.archive)->manifest),
                             (char const   *)fname, (uint )fname_len);
  if (tmp___3) {
    tmp___2 = zend_hash_find((HashTable const   *)(& (phar_obj->arc.archive)->manifest),
                             (char const   *)fname, (uint )fname_len,
                             (void **)(& entry));
    if (0 == (int )tmp___2) {
      if (entry->is_deleted) {
        return;
      } else {

      }
      if ((phar_obj->arc.archive)->is_persistent) {
        tmp___1 = phar_copy_on_write(& phar_obj->arc.archive);
        if (-1 == tmp___1) {
          zend_throw_exception_ex(phar_ce_PharException, 0L,
                                  (char *)"phar \"%s\" is persistent, unable to copy on write",
                                  (phar_obj->arc.archive)->fname);
          return;
        } else {

        }
        zend_hash_find((HashTable const   *)(& (phar_obj->arc.archive)->manifest),
                       (char const   *)fname, (uint )fname_len,
                       (void **)(& entry));
      } else {

      }
      entry->is_modified = 0U;
      entry->is_deleted = 1U;
      phar_flush(phar_obj->arc.archive, (char *)0, 0L, 0, & error);
      if (error) {
        zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
        _efree((void *)error);
      } else {

      }
      while (1) {
        __z = return_value;
        __z->value.lval = 1L;
        __z->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
  } else {
    while (1) {
      __z___0 = return_value;
      __z___0->value.lval = 0L;
      __z___0->type = (zend_uchar )3;
      break;
    }
    return;
  }
  return;
}
}
void zim_Phar_addEmptyDir(int ht , zval *return_value ,
                          zval **return_value_ptr , zval *this_ptr ,
                          int return_value_used ) 
{ 
  char *dirname ;
  int dirname_len ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  int tmp___1 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  tmp___0 = zend_parse_parameters(ht, "s", & dirname, & dirname_len);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if ((unsigned long )dirname_len >= sizeof(".phar") - 1UL) {
    tmp___1 = memcmp((void const   *)dirname, (void const   *)".phar",
                     sizeof(".phar") - 1UL);
    if (! tmp___1) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Cannot create a directory in magic \".phar\" directory");
      return;
    } else {

    }
  } else {

  }
  phar_mkdir(& phar_obj->arc.archive, dirname, dirname_len);
  return;
}
}
void zim_Phar_addFile(int ht , zval *return_value , zval **return_value_ptr ,
                      zval *this_ptr , int return_value_used ) 
{ 
  char *fname ;
  char *localname ;
  int fname_len ;
  int localname_len ;
  php_stream *resource ;
  zval *zresource ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  char *tmp___1 ;
  int __attribute__((__visibility__("default")))  tmp___2 ;
  php_stream __attribute__((__visibility__("default")))  *tmp___3 ;
  void __attribute__((__visibility__("default")))  *tmp___4 ;
  zval *__z ;

  {
  localname = (char *)((void *)0);
  localname_len = 0;
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  tmp___0 = zend_parse_parameters(ht, "s|s", & fname, & fname_len, & localname,
                                  & localname_len);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  tmp___1 = strstr((char const   *)fname, "://");
  if (! tmp___1) {
    tmp___2 = php_check_open_basedir((char const   *)fname);
    if (tmp___2) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_RuntimeException, 0L,
                              (char *)"phar error: unable to open file \"%s\" to add to phar archive, open_basedir restrictions prevent this",
                              fname);
      return;
    } else {

    }
  } else {

  }
  tmp___3 = _php_stream_open_wrapper_ex(fname, (char *)"rb", 0,
                                        (char **)((void *)0),
                                        (php_stream_context *)((void *)0));
  resource = (php_stream *)tmp___3;
  if (! resource) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_RuntimeException, 0L,
                            (char *)"phar error: unable to open file \"%s\" to add to phar archive",
                            fname);
    return;
  } else {

  }
  if (localname) {
    fname = localname;
    fname_len = localname_len;
  } else {

  }
  while (1) {
    tmp___4 = _emalloc(sizeof(zval_gc_info ));
    zresource = (zval *)tmp___4;
    ((zval_gc_info *)zresource)->u.buffered = (gc_root_buffer *)((void *)0);
    break;
  }
  zresource->refcount__gc = (zend_uint )1;
  zresource->is_ref__gc = (zend_uchar )0;
  while (1) {
    __z = zresource;
    __z->value.lval = (long )resource->rsrc_id;
    __z->type = (zend_uchar )7;
    break;
  }
  phar_add_file(& phar_obj->arc.archive, fname, fname_len, (char *)((void *)0),
                0, zresource);
  _efree((void *)zresource);
  _php_stream_free(resource, 3);
  return;
}
}
void zim_Phar_addFromString(int ht , zval *return_value ,
                            zval **return_value_ptr , zval *this_ptr ,
                            int return_value_used ) 
{ 
  char *localname ;
  char *cont_str ;
  int localname_len ;
  int cont_len ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  tmp___0 = zend_parse_parameters(ht, "ss", & localname, & localname_len,
                                  & cont_str, & cont_len);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  phar_add_file(& phar_obj->arc.archive, localname, localname_len, cont_str,
                cont_len, (zval *)((void *)0));
  return;
}
}
void zim_Phar_getStub(int ht , zval *return_value , zval **return_value_ptr ,
                      zval *this_ptr , int return_value_used ) 
{ 
  size_t len ;
  char *buf ;
  php_stream *fp ;
  php_stream_filter *filter ;
  phar_entry_info *stub ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  php_stream __attribute__((__visibility__("default")))  *tmp___0 ;
  char *filter_name ;
  php_stream_filter __attribute__((__visibility__("default")))  *tmp___1 ;
  char *tmp___2 ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___3 ;
  int __attribute__((__visibility__("default")))  tmp___4 ;
  php_stream __attribute__((__visibility__("default")))  *tmp___5 ;
  void __attribute__((__visibility__("default")))  *tmp___6 ;
  size_t __attribute__((__visibility__("default")))  tmp___7 ;
  char const   *__s___0 ;
  int __l___0 ;
  zval *__z___0 ;

  {
  filter = (php_stream_filter *)((void *)0);
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  if ((phar_obj->arc.archive)->is_tar) {
    goto _L___1;
  } else
  if ((phar_obj->arc.archive)->is_zip) {
    _L___1: 
    tmp___4 = zend_hash_find((HashTable const   *)(& (phar_obj->arc.archive)->manifest),
                             ".phar/stub.php",
                             (uint )(sizeof(".phar/stub.php") - 1UL),
                             (void **)(& stub));
    if (0 == (int )tmp___4) {
      if ((phar_obj->arc.archive)->fp) {
        if (! (phar_obj->arc.archive)->is_brandnew) {
          if (! (stub->flags & 61440U)) {
            fp = (phar_obj->arc.archive)->fp;
          } else {
            goto _L___0;
          }
        } else {
          goto _L___0;
        }
      } else {
        _L___0: 
        tmp___0 = _php_stream_open_wrapper_ex((phar_obj->arc.archive)->fname,
                                              (char *)"rb", 0,
                                              (char **)((void *)0),
                                              (php_stream_context *)((void *)0));
        fp = (php_stream *)tmp___0;
        if (stub->flags & 61440U) {
          filter_name = phar_decompress_filter(stub, 0);
          if ((unsigned long )filter_name != (unsigned long )((void *)0)) {
            tmp___1 = php_stream_filter_create((char const   *)filter_name,
                                               (zval *)((void *)0),
                                               fp->is_persistent);
            filter = (php_stream_filter *)tmp___1;
          } else {
            filter = (php_stream_filter *)((void *)0);
          }
          if (! filter) {
            tmp___2 = phar_decompress_filter(stub, 1);
            zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                                    0L,
                                    (char *)"phar error: unable to read stub of phar \"%s\" (cannot create %s filter)",
                                    (phar_obj->arc.archive)->fname, tmp___2);
            return;
          } else {

          }
          _php_stream_filter_append(& fp->readfilters, filter);
        } else {

        }
      }
      if (! fp) {
        zend_throw_exception_ex((zend_class_entry *)spl_ce_RuntimeException, 0L,
                                (char *)"Unable to read stub");
        return;
      } else {

      }
      _php_stream_seek(fp, stub->offset_abs, 0);
      len = (size_t )stub->uncompressed_filesize;
      goto carry_on;
    } else {
      while (1) {
        __s = "";
        __l = 0;
        __z = return_value;
        __z->value.str.len = __l;
        tmp___3 = _estrndup(__s, (unsigned int )__l);
        __z->value.str.val = (char *)tmp___3;
        __z->type = (zend_uchar )6;
        break;
      }
      return;
    }
  } else {

  }
  len = (phar_obj->arc.archive)->halt_offset;
  if ((phar_obj->arc.archive)->fp) {
    if (! (phar_obj->arc.archive)->is_brandnew) {
      fp = (phar_obj->arc.archive)->fp;
    } else {
      tmp___5 = _php_stream_open_wrapper_ex((phar_obj->arc.archive)->fname,
                                            (char *)"rb", 0,
                                            (char **)((void *)0),
                                            (php_stream_context *)((void *)0));
      fp = (php_stream *)tmp___5;
    }
  } else {
    tmp___5 = _php_stream_open_wrapper_ex((phar_obj->arc.archive)->fname,
                                          (char *)"rb", 0, (char **)((void *)0),
                                          (php_stream_context *)((void *)0));
    fp = (php_stream *)tmp___5;
  }
  if (! fp) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_RuntimeException, 0L,
                            (char *)"Unable to read stub");
    return;
  } else {

  }
  _php_stream_seek(fp, 0L, 0);
  carry_on: 
  tmp___6 = _safe_emalloc(len, (size_t )1, (size_t )1);
  buf = (char *)tmp___6;
  tmp___7 = _php_stream_read(fp, buf, len);
  if (len != (size_t )tmp___7) {
    if ((unsigned long )fp != (unsigned long )(phar_obj->arc.archive)->fp) {
      _php_stream_free(fp, 3);
    } else {

    }
    zend_throw_exception_ex((zend_class_entry *)spl_ce_RuntimeException, 0L,
                            (char *)"Unable to read stub");
    _efree((void *)buf);
    return;
  } else {

  }
  if (filter) {
    _php_stream_filter_flush(filter, 1);
    php_stream_filter_remove(filter, 1);
  } else {

  }
  if ((unsigned long )fp != (unsigned long )(phar_obj->arc.archive)->fp) {
    _php_stream_free(fp, 3);
  } else {

  }
  *(buf + len) = (char )'\000';
  while (1) {
    __s___0 = (char const   *)buf;
    __l___0 = (int )len;
    __z___0 = return_value;
    __z___0->value.str.len = __l___0;
    __z___0->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s___0));
    __z___0->type = (zend_uchar )6;
    break;
  }
  return;
}
}
void zim_Phar_hasMetadata(int ht , zval *return_value ,
                          zval **return_value_ptr , zval *this_ptr ,
                          int return_value_used ) 
{ 
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval *__z ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  while (1) {
    __z = return_value;
    __z->value.lval = (long )(((unsigned long )(phar_obj->arc.archive)->metadata != (unsigned long )((void *)0)) != 0);
    __z->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zim_Phar_getMetadata(int ht , zval *return_value ,
                          zval **return_value_ptr , zval *this_ptr ,
                          int return_value_used ) 
{ 
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval *ret ;
  char *buf ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  zend_uchar is_ref ;
  zend_bool tmp___1 ;
  zend_uint refcount ;
  zend_uint tmp___2 ;
  zend_uchar is_ref___0 ;
  zend_bool tmp___3 ;
  zend_uint refcount___0 ;
  zend_uint tmp___4 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  if ((phar_obj->arc.archive)->metadata) {
    if ((phar_obj->arc.archive)->is_persistent) {
      tmp___0 = _estrndup((char const   *)((char *)(phar_obj->arc.archive)->metadata),
                          (unsigned int )(phar_obj->arc.archive)->metadata_len);
      buf = (char *)tmp___0;
      phar_parse_metadata(& buf, & ret, (phar_obj->arc.archive)->metadata_len);
      _efree((void *)buf);
      tmp___1 = zval_isref_p(return_value);
      is_ref = tmp___1;
      tmp___2 = zval_refcount_p(return_value);
      refcount = tmp___2;
      while (1) {
        return_value->value = ret->value;
        return_value->type = ret->type;
        break;
      }
      ret->type = (zend_uchar )0;
      _zval_ptr_dtor(& ret);
      zval_set_isref_to_p(return_value, is_ref);
      zval_set_refcount_p(return_value, refcount);
      return;
    } else {

    }
    tmp___3 = zval_isref_p(return_value);
    is_ref___0 = tmp___3;
    tmp___4 = zval_refcount_p(return_value);
    refcount___0 = tmp___4;
    while (1) {
      return_value->value = ((phar_obj->arc.archive)->metadata)->value;
      return_value->type = ((phar_obj->arc.archive)->metadata)->type;
      break;
    }
    _zval_copy_ctor(return_value);
    zval_set_isref_to_p(return_value, is_ref___0);
    zval_set_refcount_p(return_value, refcount___0);
    return;
  } else {

  }
  return;
}
}
void zim_Phar_setMetadata(int ht , zval *return_value ,
                          zval **return_value_ptr , zval *this_ptr ,
                          int return_value_used ) 
{ 
  char *error ;
  zval *metadata ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  int tmp___1 ;
  void __attribute__((__visibility__("default")))  *tmp___2 ;
  zend_uchar is_ref ;
  zend_bool tmp___3 ;
  zend_uint refcount ;
  zend_uint tmp___4 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  if (phar_globals.readonly) {
    if (! (phar_obj->arc.archive)->is_data) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Write operations disabled by the php.ini setting phar.readonly");
      return;
    } else {

    }
  } else {

  }
  tmp___0 = zend_parse_parameters(ht, "z", & metadata);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if ((phar_obj->arc.archive)->is_persistent) {
    tmp___1 = phar_copy_on_write(& phar_obj->arc.archive);
    if (-1 == tmp___1) {
      zend_throw_exception_ex(phar_ce_PharException, 0L,
                              (char *)"phar \"%s\" is persistent, unable to copy on write",
                              (phar_obj->arc.archive)->fname);
      return;
    } else {

    }
  } else {

  }
  if ((phar_obj->arc.archive)->metadata) {
    _zval_ptr_dtor(& (phar_obj->arc.archive)->metadata);
    (phar_obj->arc.archive)->metadata = (zval *)((void *)0);
  } else {

  }
  while (1) {
    tmp___2 = _emalloc(sizeof(zval_gc_info ));
    (phar_obj->arc.archive)->metadata = (zval *)tmp___2;
    ((zval_gc_info *)(phar_obj->arc.archive)->metadata)->u.buffered = (gc_root_buffer *)((void *)0);
    break;
  }
  ((phar_obj->arc.archive)->metadata)->refcount__gc = (zend_uint )1;
  ((phar_obj->arc.archive)->metadata)->is_ref__gc = (zend_uchar )0;
  tmp___3 = zval_isref_p((phar_obj->arc.archive)->metadata);
  is_ref = tmp___3;
  tmp___4 = zval_refcount_p((phar_obj->arc.archive)->metadata);
  refcount = tmp___4;
  while (1) {
    ((phar_obj->arc.archive)->metadata)->value = metadata->value;
    ((phar_obj->arc.archive)->metadata)->type = metadata->type;
    break;
  }
  _zval_copy_ctor((phar_obj->arc.archive)->metadata);
  zval_set_isref_to_p((phar_obj->arc.archive)->metadata, is_ref);
  zval_set_refcount_p((phar_obj->arc.archive)->metadata, refcount);
  (phar_obj->arc.archive)->is_modified = 1U;
  phar_flush(phar_obj->arc.archive, (char *)0, 0L, 0, & error);
  if (error) {
    zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
    _efree((void *)error);
  } else {

  }
  return;
}
}
void zim_Phar_delMetadata(int ht , zval *return_value ,
                          zval **return_value_ptr , zval *this_ptr ,
                          int return_value_used ) 
{ 
  char *error ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval *__z ;
  zval *__z___0 ;
  zval *__z___1 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  if (phar_globals.readonly) {
    if (! (phar_obj->arc.archive)->is_data) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Write operations disabled by the php.ini setting phar.readonly");
      return;
    } else {

    }
  } else {

  }
  if ((phar_obj->arc.archive)->metadata) {
    _zval_ptr_dtor(& (phar_obj->arc.archive)->metadata);
    (phar_obj->arc.archive)->metadata = (zval *)((void *)0);
    (phar_obj->arc.archive)->is_modified = 1U;
    phar_flush(phar_obj->arc.archive, (char *)0, 0L, 0, & error);
    if (error) {
      zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
      _efree((void *)error);
      while (1) {
        __z = return_value;
        __z->value.lval = 0L;
        __z->type = (zend_uchar )3;
        break;
      }
      return;
    } else {
      while (1) {
        __z___0 = return_value;
        __z___0->value.lval = 1L;
        __z___0->type = (zend_uchar )3;
        break;
      }
      return;
    }
  } else {
    while (1) {
      __z___1 = return_value;
      __z___1->value.lval = 1L;
      __z___1->type = (zend_uchar )3;
      break;
    }
    return;
  }
}
}
static int phar_extract_file(zend_bool overwrite , phar_entry_info *entry ,
                             char *dest , int dest_len , char **error ) 
{ 
  php_stream_statbuf ssb ;
  int len ;
  php_stream *fp ;
  char *fullpath ;
  char const   *slash ;
  mode_t mode ;
  int tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  char *tmp___1 ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;
  int __attribute__((__visibility__("default")))  tmp___3 ;
  int __attribute__((__visibility__("default")))  tmp___4 ;
  void const   *tmp___5 ;
  int __attribute__((__visibility__("default")))  tmp___6 ;
  int __attribute__((__visibility__("default")))  tmp___7 ;
  int __attribute__((__visibility__("default")))  tmp___8 ;
  php_stream __attribute__((__visibility__("default")))  *tmp___9 ;
  int tmp___10 ;
  php_stream *tmp___11 ;
  int tmp___12 ;
  php_stream *tmp___13 ;
  size_t __attribute__((__visibility__("default")))  tmp___14 ;
  int tmp___15 ;

  {
  if (entry->is_mounted) {
    return (0);
  } else {

  }
  if ((unsigned long )entry->filename_len >= sizeof(".phar") - 1UL) {
    tmp = memcmp((void const   *)entry->filename, (void const   *)".phar",
                 sizeof(".phar") - 1UL);
    if (! tmp) {
      return (0);
    } else {

    }
  } else {

  }
  tmp___0 = spprintf(& fullpath, (size_t )0, "%s/%s", dest, entry->filename);
  len = (int )tmp___0;
  if (len >= 4096) {
    *(fullpath + 50) = (char )'\000';
    if (entry->filename_len > 50U) {
      tmp___2 = _estrndup((char const   *)entry->filename, 50U);
      tmp___1 = (char *)tmp___2;
      spprintf(error, (size_t )4096,
               "Cannot extract \"%s...\" to \"%s...\", extracted filename is too long for filesystem",
               tmp___1, fullpath);
      _efree((void *)tmp___1);
    } else {
      spprintf(error, (size_t )4096,
               "Cannot extract \"%s\" to \"%s...\", extracted filename is too long for filesystem",
               entry->filename, fullpath);
    }
    _efree((void *)fullpath);
    return (-1);
  } else {

  }
  if (! len) {
    spprintf(error, (size_t )4096, "Cannot extract \"%s\", internal error",
             entry->filename);
    _efree((void *)fullpath);
    return (-1);
  } else {

  }
  tmp___3 = php_check_open_basedir((char const   *)fullpath);
  if (tmp___3) {
    spprintf(error, (size_t )4096,
             "Cannot extract \"%s\" to \"%s\", openbasedir/safe mode restrictions in effect",
             entry->filename, fullpath);
    _efree((void *)fullpath);
    return (-1);
  } else {

  }
  if (! overwrite) {
    tmp___4 = _php_stream_stat_path(fullpath, 0, & ssb,
                                    (php_stream_context *)((void *)0));
    if (0 == (int )tmp___4) {
      spprintf(error, (size_t )4096,
               "Cannot extract \"%s\" to \"%s\", path already exists",
               entry->filename, fullpath);
      _efree((void *)fullpath);
      return (-1);
    } else {

    }
  } else {

  }
  tmp___5 = zend_memrchr((void const   *)entry->filename, '/',
                         (size_t )entry->filename_len);
  slash = (char const   *)tmp___5;
  if (slash) {
    *(fullpath + (((long )dest_len + (slash - (char const   *)entry->filename)) + 1L)) = (char )'\000';
  } else {
    *(fullpath + dest_len) = (char )'\000';
  }
  tmp___8 = _php_stream_stat_path(fullpath, 0, & ssb,
                                  (php_stream_context *)((void *)0));
  if (-1 == (int )tmp___8) {
    if (entry->is_dir) {
      tmp___6 = _php_stream_mkdir(fullpath, (int )(entry->flags & 511U), 1,
                                  (php_stream_context *)((void *)0));
      if (! tmp___6) {
        spprintf(error, (size_t )4096,
                 "Cannot extract \"%s\", could not create directory \"%s\"",
                 entry->filename, fullpath);
        _efree((void *)fullpath);
        return (-1);
      } else {

      }
    } else {
      tmp___7 = _php_stream_mkdir(fullpath, 511, 1,
                                  (php_stream_context *)((void *)0));
      if (! tmp___7) {
        spprintf(error, (size_t )4096,
                 "Cannot extract \"%s\", could not create directory \"%s\"",
                 entry->filename, fullpath);
        _efree((void *)fullpath);
        return (-1);
      } else {

      }
    }
  } else {

  }
  if (slash) {
    *(fullpath + (((long )dest_len + (slash - (char const   *)entry->filename)) + 1L)) = (char )'/';
  } else {
    *(fullpath + dest_len) = (char )'/';
  }
  if (entry->is_dir) {
    _efree((void *)fullpath);
    return (0);
  } else {

  }
  tmp___9 = _php_stream_open_wrapper_ex(fullpath, (char *)"w+b", 8,
                                        (char **)((void *)0),
                                        (php_stream_context *)((void *)0));
  fp = (php_stream *)tmp___9;
  if (! fp) {
    spprintf(error, (size_t )4096,
             "Cannot extract \"%s\", could not open for writing \"%s\"",
             entry->filename, fullpath);
    _efree((void *)fullpath);
    return (-1);
  } else {

  }
  tmp___11 = phar_get_efp(entry, 0);
  if (! tmp___11) {
    tmp___10 = phar_open_entry_fp(entry, error, 1);
    if (-1 == tmp___10) {
      if (error) {
        spprintf(error, (size_t )4096,
                 "Cannot extract \"%s\" to \"%s\", unable to open internal file pointer: %s",
                 entry->filename, fullpath, *error);
      } else {
        spprintf(error, (size_t )4096,
                 "Cannot extract \"%s\" to \"%s\", unable to open internal file pointer",
                 entry->filename, fullpath);
      }
      _efree((void *)fullpath);
      _php_stream_free(fp, 3);
      return (-1);
    } else {

    }
  } else {

  }
  tmp___12 = phar_seek_efp(entry, (off_t )0, 0, (off_t )0, 0);
  if (-1 == tmp___12) {
    spprintf(error, (size_t )4096,
             "Cannot extract \"%s\" to \"%s\", unable to seek internal file pointer",
             entry->filename, fullpath);
    _efree((void *)fullpath);
    _php_stream_free(fp, 3);
    return (-1);
  } else {

  }
  tmp___13 = phar_get_efp(entry, 0);
  tmp___14 = _php_stream_copy_to_stream_ex(tmp___13, fp,
                                           (size_t )entry->uncompressed_filesize,
                                           (size_t *)((void *)0));
  if ((size_t __attribute__((__visibility__("default")))  )0 != tmp___14) {
    spprintf(error, (size_t )4096,
             "Cannot extract \"%s\" to \"%s\", copying contents failed",
             entry->filename, fullpath);
    _efree((void *)fullpath);
    _php_stream_free(fp, 3);
    return (-1);
  } else {

  }
  _php_stream_free(fp, 3);
  mode = entry->flags & 511U;
  tmp___15 = chmod((char const   *)fullpath, mode);
  if (-1 == tmp___15) {
    spprintf(error, (size_t )4096,
             "Cannot extract \"%s\" to \"%s\", setting file permissions failed",
             entry->filename, fullpath);
    _efree((void *)fullpath);
    return (-1);
  } else {

  }
  _efree((void *)fullpath);
  return (0);
}
}
void zim_Phar_extractTo(int ht , zval *return_value , zval **return_value_ptr ,
                        zval *this_ptr , int return_value_used ) 
{ 
  char *error ;
  php_stream *fp ;
  php_stream_statbuf ssb ;
  phar_entry_info *entry ;
  char *pathto ;
  char *filename ;
  char *actual ;
  int pathto_len ;
  int filename_len ;
  int ret ;
  int i ;
  int nelems ;
  zval *zval_files ;
  zend_bool overwrite ;
  phar_archive_object *phar_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  php_stream __attribute__((__visibility__("default")))  *tmp___1 ;
  char *tmp___2 ;
  char __attribute__((__visibility__("default")))  *tmp___3 ;
  int __attribute__((__visibility__("default")))  tmp___4 ;
  int __attribute__((__visibility__("default")))  tmp___5 ;
  int __attribute__((__visibility__("default")))  tmp___6 ;
  zval *__z ;
  zval **zval_file ;
  int __attribute__((__visibility__("default")))  tmp___7 ;
  int tmp___8 ;
  int __attribute__((__visibility__("default")))  tmp___9 ;
  zval *__z___0 ;
  int __attribute__((__visibility__("default")))  tmp___10 ;
  int tmp___11 ;
  phar_archive_data *phar ;
  zval *__z___1 ;
  int __attribute__((__visibility__("default")))  tmp___12 ;
  int __attribute__((__visibility__("default")))  tmp___13 ;
  int tmp___14 ;
  int tmp___16 ;
  int __attribute__((__visibility__("default")))  tmp___17 ;
  zval *__z___2 ;

  {
  error = (char *)((void *)0);
  zval_files = (zval *)((void *)0);
  overwrite = (zend_bool )0;
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  phar_obj = (phar_archive_object *)tmp;
  if (! phar_obj->arc.archive) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized Phar object");
    return;
  } else {

  }
  tmp___0 = zend_parse_parameters(ht, "s|z!b", & pathto, & pathto_len,
                                  & zval_files, & overwrite);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  tmp___1 = _php_stream_open_wrapper_ex((phar_obj->arc.archive)->fname,
                                        (char *)"rb", 18, & actual,
                                        (php_stream_context *)((void *)0));
  fp = (php_stream *)tmp___1;
  if (! fp) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_InvalidArgumentException,
                            0L, (char *)"Invalid argument, %s cannot be found",
                            (phar_obj->arc.archive)->fname);
    return;
  } else {

  }
  _efree((void *)actual);
  _php_stream_free(fp, 3);
  if (pathto_len < 1) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_InvalidArgumentException,
                            0L,
                            (char *)"Invalid argument, extraction path must be non-zero length");
    return;
  } else {

  }
  if (pathto_len >= 4096) {
    tmp___3 = _estrndup((char const   *)pathto, 50U);
    tmp___2 = (char *)tmp___3;
    zend_throw_exception_ex((zend_class_entry *)spl_ce_InvalidArgumentException,
                            0L,
                            (char *)"Cannot extract to \"%s...\", destination directory is too long for filesystem",
                            tmp___2);
    _efree((void *)tmp___2);
    return;
  } else {

  }
  tmp___5 = _php_stream_stat_path(pathto, 0, & ssb,
                                  (php_stream_context *)((void *)0));
  if (tmp___5 < (int __attribute__((__visibility__("default")))  )0) {
    tmp___4 = _php_stream_mkdir(pathto, 511, 1,
                                (php_stream_context *)((void *)0));
    ret = (int )tmp___4;
    if (! ret) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_RuntimeException, 0L,
                              (char *)"Unable to create path \"%s\" for extraction",
                              pathto);
      return;
    } else {

    }
  } else
  if (! (ssb.sb.st_mode & 16384U)) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_RuntimeException, 0L,
                            (char *)"Unable to use path \"%s\" for extraction, it is a file, must be a directory",
                            pathto);
    return;
  } else {

  }
  if (zval_files) {
    switch ((int )zval_files->type) {
    case 0: 
    goto all_files;
    case 6: 
    filename = zval_files->value.str.val;
    filename_len = zval_files->value.str.len;
    break;
    case 4: 
    tmp___6 = zend_hash_num_elements((HashTable const   *)zval_files->value.ht);
    nelems = (int )tmp___6;
    if (nelems == 0) {
      while (1) {
        __z = return_value;
        __z->value.lval = 0L;
        __z->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    i = 0;
    while (i < nelems) {
      tmp___9 = zend_hash_index_find((HashTable const   *)zval_files->value.ht,
                                     (ulong )i, (void **)(& zval_file));
      if (tmp___9 == (int __attribute__((__visibility__("default")))  )0) {
        switch ((int )(*zval_file)->type) {
        case 6: 
        break;
        default: 
        zend_throw_exception_ex((zend_class_entry *)spl_ce_InvalidArgumentException,
                                0L,
                                (char *)"Invalid argument, array of filenames to extract contains non-string value");
        return;
        }
        tmp___7 = zend_hash_find((HashTable const   *)(& (phar_obj->arc.archive)->manifest),
                                 (char const   *)(*zval_file)->value.str.val,
                                 (uint )(*zval_file)->value.str.len,
                                 (void **)(& entry));
        if (-1 == (int )tmp___7) {
          zend_throw_exception_ex(phar_ce_PharException, 0L,
                                  (char *)"Phar Error: attempted to extract non-existent file \"%s\" from phar \"%s\"",
                                  (*zval_file)->value.str.val,
                                  (phar_obj->arc.archive)->fname);
        } else {

        }
        tmp___8 = phar_extract_file(overwrite, entry, pathto, pathto_len,
                                    & error);
        if (-1 == tmp___8) {
          zend_throw_exception_ex(phar_ce_PharException, 0L,
                                  (char *)"Extraction from phar \"%s\" failed: %s",
                                  (phar_obj->arc.archive)->fname, error);
          _efree((void *)error);
          return;
        } else {

        }
      } else {

      }
      i ++;
    }
    while (1) {
      __z___0 = return_value;
      __z___0->value.lval = 1L;
      __z___0->type = (zend_uchar )3;
      break;
    }
    return;
    default: 
    zend_throw_exception_ex((zend_class_entry *)spl_ce_InvalidArgumentException,
                            0L,
                            (char *)"Invalid argument, expected a filename (string) or array of filenames");
    return;
    }
    tmp___10 = zend_hash_find((HashTable const   *)(& (phar_obj->arc.archive)->manifest),
                              (char const   *)filename, (uint )filename_len,
                              (void **)(& entry));
    if (-1 == (int )tmp___10) {
      zend_throw_exception_ex(phar_ce_PharException, 0L,
                              (char *)"Phar Error: attempted to extract non-existent file \"%s\" from phar \"%s\"",
                              filename, (phar_obj->arc.archive)->fname);
      return;
    } else {

    }
    tmp___11 = phar_extract_file(overwrite, entry, pathto, pathto_len, & error);
    if (-1 == tmp___11) {
      zend_throw_exception_ex(phar_ce_PharException, 0L,
                              (char *)"Extraction from phar \"%s\" failed: %s",
                              (phar_obj->arc.archive)->fname, error);
      _efree((void *)error);
      return;
    } else {

    }
  } else {
    all_files: 
    phar = phar_obj->arc.archive;
    tmp___12 = zend_hash_num_elements((HashTable const   *)(& phar->manifest));
    if (! tmp___12) {
      while (1) {
        __z___1 = return_value;
        __z___1->value.lval = 1L;
        __z___1->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    zend_hash_internal_pointer_reset_ex(& phar->manifest,
                                        (HashPosition *)((void *)0));
    while (1) {
      tmp___17 = zend_hash_get_current_key_type_ex(& phar->manifest,
                                                   (HashPosition *)((void *)0));
      if (tmp___17 == (int __attribute__((__visibility__("default")))  )3) {
        tmp___16 = -1;
      } else {
        tmp___16 = 0;
      }
      if (! (tmp___16 == 0)) {
        break;
      } else {

      }
      tmp___13 = zend_hash_get_current_data_ex(& phar->manifest,
                                               (void **)(& entry),
                                               (HashPosition *)((void *)0));
      if (tmp___13 == (int __attribute__((__visibility__("default")))  )-1) {
        goto __Cont;
      } else {

      }
      tmp___14 = phar_extract_file(overwrite, entry, pathto, pathto_len, & error);
      if (-1 == tmp___14) {
        zend_throw_exception_ex(phar_ce_PharException, 0L,
                                (char *)"Extraction from phar \"%s\" failed: %s",
                                phar->fname, error);
        _efree((void *)error);
        return;
      } else {

      }
      __Cont: 
      zend_hash_move_forward_ex(& phar->manifest, (HashPosition *)((void *)0));
    }
  }
  while (1) {
    __z___2 = return_value;
    __z___2->value.lval = 1L;
    __z___2->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zim_PharFileInfo___construct(int ht , zval *return_value ,
                                  zval **return_value_ptr , zval *this_ptr ,
                                  int return_value_used ) 
{ 
  char *fname ;
  char *arch ;
  char *entry ;
  char *error ;
  int fname_len ;
  int arch_len ;
  int entry_len ;
  phar_entry_object *entry_obj ;
  phar_entry_info *entry_info ;
  phar_archive_data *phar_data ;
  zval *zobj ;
  zval arg1 ;
  int __attribute__((__visibility__("default")))  tmp ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  char const   *tmp___4 ;
  char const   *tmp___5 ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp___7 ;

  {
  zobj = this_ptr;
  tmp = zend_parse_parameters(ht, "s", & fname, & fname_len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  tmp___0 = zend_object_store_get_object((zval const   *)this_ptr);
  entry_obj = (phar_entry_object *)tmp___0;
  if (entry_obj->ent.entry) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L, (char *)"Cannot call constructor twice");
    return;
  } else {

  }
  if (fname_len < 7) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_RuntimeException, 0L,
                            (char *)"\'%s\' is not a valid phar archive URL (must have at least phar://filename.phar)",
                            fname);
    return;
  } else {
    tmp___1 = memcmp((void const   *)fname, (void const   *)"phar://",
                     (size_t )7);
    if (tmp___1) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_RuntimeException, 0L,
                              (char *)"\'%s\' is not a valid phar archive URL (must have at least phar://filename.phar)",
                              fname);
      return;
    } else {
      tmp___2 = phar_split_fname(fname, fname_len, & arch, & arch_len, & entry,
                                 & entry_len, 2, 0);
      if (tmp___2 == -1) {
        zend_throw_exception_ex((zend_class_entry *)spl_ce_RuntimeException, 0L,
                                (char *)"\'%s\' is not a valid phar archive URL (must have at least phar://filename.phar)",
                                fname);
        return;
      } else {

      }
    }
  }
  tmp___3 = phar_open_from_filename(arch, arch_len, (char *)((void *)0), 0, 8,
                                    & phar_data, & error);
  if (tmp___3 == -1) {
    _efree((void *)arch);
    _efree((void *)entry);
    if (error) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_RuntimeException, 0L,
                              (char *)"Cannot open phar file \'%s\': %s", fname,
                              error);
      _efree((void *)error);
    } else {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_RuntimeException, 0L,
                              (char *)"Cannot open phar file \'%s\'", fname);
    }
    return;
  } else {

  }
  entry_info = phar_get_entry_info_dir(phar_data, entry, entry_len, (char)1,
                                       & error, 1);
  if ((unsigned long )entry_info == (unsigned long )((void *)0)) {
    if (error) {
      tmp___4 = (char const   *)error;
    } else {
      tmp___4 = "";
    }
    if (error) {
      tmp___5 = ", ";
    } else {
      tmp___5 = "";
    }
    zend_throw_exception_ex((zend_class_entry *)spl_ce_RuntimeException, 0L,
                            (char *)"Cannot access phar file entry \'%s\' in archive \'%s\'%s%s",
                            entry, arch, tmp___5, tmp___4);
    _efree((void *)arch);
    _efree((void *)entry);
    return;
  } else {

  }
  _efree((void *)arch);
  _efree((void *)entry);
  entry_obj->ent.entry = entry_info;
  arg1.refcount__gc = (zend_uint )1;
  arg1.is_ref__gc = (zend_uchar )0;
  while (1) {
    __s = (char const   *)fname;
    __l = fname_len;
    __z = & arg1;
    __z->value.str.len = __l;
    __z->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z->type = (zend_uchar )6;
    break;
  }
  tmp___7 = zend_get_class_entry((zval const   *)zobj);
  zend_call_method(& zobj, (zend_class_entry *)tmp___7,
                   & spl_ce_SplFileInfo->constructor, (char *)"__construct",
                   (int )(sizeof("__construct") - 1UL), (zval **)((void *)0), 1,
                   & arg1, (zval *)((void *)0));
  return;
}
}
void zim_PharFileInfo___destruct(int ht , zval *return_value ,
                                 zval **return_value_ptr , zval *this_ptr ,
                                 int return_value_used ) 
{ 
  phar_entry_object *entry_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  entry_obj = (phar_entry_object *)tmp;
  if (entry_obj->ent.entry) {
    if ((entry_obj->ent.entry)->is_temp_dir) {
      if ((entry_obj->ent.entry)->filename) {
        _efree((void *)(entry_obj->ent.entry)->filename);
        (entry_obj->ent.entry)->filename = (char *)((void *)0);
      } else {

      }
      _efree((void *)entry_obj->ent.entry);
      entry_obj->ent.entry = (phar_entry_info *)((void *)0);
    } else {

    }
  } else {

  }
  return;
}
}
void zim_PharFileInfo_getCompressedSize(int ht , zval *return_value ,
                                        zval **return_value_ptr ,
                                        zval *this_ptr , int return_value_used ) 
{ 
  phar_entry_object *entry_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval *__z ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  entry_obj = (phar_entry_object *)tmp;
  if (! entry_obj->ent.entry) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized PharFileInfo object");
    return;
  } else {

  }
  __z = return_value;
  __z->value.lval = (long )(entry_obj->ent.entry)->compressed_filesize;
  __z->type = (zend_uchar )1;
  return;
}
}
void zim_PharFileInfo_isCompressed(int ht , zval *return_value ,
                                   zval **return_value_ptr , zval *this_ptr ,
                                   int return_value_used ) 
{ 
  long method ;
  phar_entry_object *entry_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z ;
  zval *__z___0 ;
  zval *__z___1 ;

  {
  method = 9021976L;
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  entry_obj = (phar_entry_object *)tmp;
  if (! entry_obj->ent.entry) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized PharFileInfo object");
    return;
  } else {

  }
  tmp___0 = zend_parse_parameters(ht, "|l", & method);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  switch (method) {
  case 9021976L: 
  while (1) {
    __z = return_value;
    __z->value.lval = (long )(((entry_obj->ent.entry)->flags & 61440U) != 0U);
    __z->type = (zend_uchar )3;
    break;
  }
  return;
  case 4096L: 
  while (1) {
    __z___0 = return_value;
    __z___0->value.lval = (long )(((entry_obj->ent.entry)->flags & 4096U) != 0U);
    __z___0->type = (zend_uchar )3;
    break;
  }
  return;
  case 8192L: 
  while (1) {
    __z___1 = return_value;
    __z___1->value.lval = (long )(((entry_obj->ent.entry)->flags & 8192U) != 0U);
    __z___1->type = (zend_uchar )3;
    break;
  }
  return;
  default: 
  zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException, 0L,
                          (char *)"Unknown compression type specified");
  }
  return;
}
}
void zim_PharFileInfo_getCRC32(int ht , zval *return_value ,
                               zval **return_value_ptr , zval *this_ptr ,
                               int return_value_used ) 
{ 
  phar_entry_object *entry_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval *__z ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  entry_obj = (phar_entry_object *)tmp;
  if (! entry_obj->ent.entry) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized PharFileInfo object");
    return;
  } else {

  }
  if ((entry_obj->ent.entry)->is_dir) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Phar entry is a directory, does not have a CRC");
    return;
  } else {

  }
  if ((entry_obj->ent.entry)->is_crc_checked) {
    __z = return_value;
    __z->value.lval = (long )(entry_obj->ent.entry)->crc32;
    __z->type = (zend_uchar )1;
    return;
  } else {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L, (char *)"Phar entry was not CRC checked");
  }
  return;
}
}
void zim_PharFileInfo_isCRCChecked(int ht , zval *return_value ,
                                   zval **return_value_ptr , zval *this_ptr ,
                                   int return_value_used ) 
{ 
  phar_entry_object *entry_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval *__z ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  entry_obj = (phar_entry_object *)tmp;
  if (! entry_obj->ent.entry) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized PharFileInfo object");
    return;
  } else {

  }
  while (1) {
    __z = return_value;
    __z->value.lval = (long )((entry_obj->ent.entry)->is_crc_checked != 0U);
    __z->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zim_PharFileInfo_getPharFlags(int ht , zval *return_value ,
                                   zval **return_value_ptr , zval *this_ptr ,
                                   int return_value_used ) 
{ 
  phar_entry_object *entry_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval *__z ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  entry_obj = (phar_entry_object *)tmp;
  if (! entry_obj->ent.entry) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized PharFileInfo object");
    return;
  } else {

  }
  __z = return_value;
  __z->value.lval = (long )((entry_obj->ent.entry)->flags & 4294905344U);
  __z->type = (zend_uchar )1;
  return;
}
}
void zim_PharFileInfo_chmod(int ht , zval *return_value ,
                            zval **return_value_ptr , zval *this_ptr ,
                            int return_value_used ) 
{ 
  char *error ;
  long perms ;
  phar_entry_object *entry_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  phar_archive_data *phar ;
  int tmp___1 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  entry_obj = (phar_entry_object *)tmp;
  if (! entry_obj->ent.entry) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized PharFileInfo object");
    return;
  } else {

  }
  if ((entry_obj->ent.entry)->is_temp_dir) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Phar entry \"%s\" is a temporary directory (not an actual entry in the archive), cannot chmod",
                            (entry_obj->ent.entry)->filename);
    return;
  } else {

  }
  if (phar_globals.readonly) {
    if (! ((entry_obj->ent.entry)->phar)->is_data) {
      zend_throw_exception_ex(phar_ce_PharException, 0L,
                              (char *)"Cannot modify permissions for file \"%s\" in phar \"%s\", write operations are prohibited",
                              (entry_obj->ent.entry)->filename,
                              ((entry_obj->ent.entry)->phar)->fname);
      return;
    } else {

    }
  } else {

  }
  tmp___0 = zend_parse_parameters(ht, "l", & perms);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if ((entry_obj->ent.entry)->is_persistent) {
    phar = (entry_obj->ent.entry)->phar;
    tmp___1 = phar_copy_on_write(& phar);
    if (-1 == tmp___1) {
      zend_throw_exception_ex(phar_ce_PharException, 0L,
                              (char *)"phar \"%s\" is persistent, unable to copy on write",
                              phar->fname);
      return;
    } else {

    }
    zend_hash_find((HashTable const   *)(& phar->manifest),
                   (char const   *)(entry_obj->ent.entry)->filename,
                   (entry_obj->ent.entry)->filename_len,
                   (void **)(& entry_obj->ent.entry));
  } else {

  }
  (entry_obj->ent.entry)->flags &= 4294966784U;
  perms &= 511L;
  (entry_obj->ent.entry)->flags = (php_uint32 )((long )(entry_obj->ent.entry)->flags | perms);
  (entry_obj->ent.entry)->old_flags = (entry_obj->ent.entry)->flags;
  ((entry_obj->ent.entry)->phar)->is_modified = 1U;
  (entry_obj->ent.entry)->is_modified = 1U;
  if (basic_globals.CurrentLStatFile) {
    _efree((void *)basic_globals.CurrentLStatFile);
  } else {

  }
  if (basic_globals.CurrentStatFile) {
    _efree((void *)basic_globals.CurrentStatFile);
  } else {

  }
  basic_globals.CurrentLStatFile = (char *)((void *)0);
  basic_globals.CurrentStatFile = (char *)((void *)0);
  phar_flush((entry_obj->ent.entry)->phar, (char *)0, 0L, 0, & error);
  if (error) {
    zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
    _efree((void *)error);
  } else {

  }
  return;
}
}
void zim_PharFileInfo_hasMetadata(int ht , zval *return_value ,
                                  zval **return_value_ptr , zval *this_ptr ,
                                  int return_value_used ) 
{ 
  phar_entry_object *entry_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval *__z ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  entry_obj = (phar_entry_object *)tmp;
  if (! entry_obj->ent.entry) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized PharFileInfo object");
    return;
  } else {

  }
  while (1) {
    __z = return_value;
    __z->value.lval = (long )(((unsigned long )(entry_obj->ent.entry)->metadata != (unsigned long )((void *)0)) != 0);
    __z->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zim_PharFileInfo_getMetadata(int ht , zval *return_value ,
                                  zval **return_value_ptr , zval *this_ptr ,
                                  int return_value_used ) 
{ 
  phar_entry_object *entry_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval *ret ;
  char *buf ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  zend_uchar is_ref ;
  zend_bool tmp___1 ;
  zend_uint refcount ;
  zend_uint tmp___2 ;
  zend_uchar is_ref___0 ;
  zend_bool tmp___3 ;
  zend_uint refcount___0 ;
  zend_uint tmp___4 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  entry_obj = (phar_entry_object *)tmp;
  if (! entry_obj->ent.entry) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized PharFileInfo object");
    return;
  } else {

  }
  if ((entry_obj->ent.entry)->metadata) {
    if ((entry_obj->ent.entry)->is_persistent) {
      tmp___0 = _estrndup((char const   *)((char *)(entry_obj->ent.entry)->metadata),
                          (unsigned int )(entry_obj->ent.entry)->metadata_len);
      buf = (char *)tmp___0;
      phar_parse_metadata(& buf, & ret, (entry_obj->ent.entry)->metadata_len);
      _efree((void *)buf);
      tmp___1 = zval_isref_p(return_value);
      is_ref = tmp___1;
      tmp___2 = zval_refcount_p(return_value);
      refcount = tmp___2;
      while (1) {
        return_value->value = ret->value;
        return_value->type = ret->type;
        break;
      }
      ret->type = (zend_uchar )0;
      _zval_ptr_dtor(& ret);
      zval_set_isref_to_p(return_value, is_ref);
      zval_set_refcount_p(return_value, refcount);
      return;
    } else {

    }
    tmp___3 = zval_isref_p(return_value);
    is_ref___0 = tmp___3;
    tmp___4 = zval_refcount_p(return_value);
    refcount___0 = tmp___4;
    while (1) {
      return_value->value = ((entry_obj->ent.entry)->metadata)->value;
      return_value->type = ((entry_obj->ent.entry)->metadata)->type;
      break;
    }
    _zval_copy_ctor(return_value);
    zval_set_isref_to_p(return_value, is_ref___0);
    zval_set_refcount_p(return_value, refcount___0);
    return;
  } else {

  }
  return;
}
}
void zim_PharFileInfo_setMetadata(int ht , zval *return_value ,
                                  zval **return_value_ptr , zval *this_ptr ,
                                  int return_value_used ) 
{ 
  char *error ;
  zval *metadata ;
  phar_entry_object *entry_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  phar_archive_data *phar ;
  int tmp___1 ;
  void __attribute__((__visibility__("default")))  *tmp___2 ;
  zend_uchar is_ref ;
  zend_bool tmp___3 ;
  zend_uint refcount ;
  zend_uint tmp___4 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  entry_obj = (phar_entry_object *)tmp;
  if (! entry_obj->ent.entry) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized PharFileInfo object");
    return;
  } else {

  }
  if (phar_globals.readonly) {
    if (! ((entry_obj->ent.entry)->phar)->is_data) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Write operations disabled by the php.ini setting phar.readonly");
      return;
    } else {

    }
  } else {

  }
  if ((entry_obj->ent.entry)->is_temp_dir) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Phar entry is a temporary directory (not an actual entry in the archive), cannot set metadata");
    return;
  } else {

  }
  tmp___0 = zend_parse_parameters(ht, "z", & metadata);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if ((entry_obj->ent.entry)->is_persistent) {
    phar = (entry_obj->ent.entry)->phar;
    tmp___1 = phar_copy_on_write(& phar);
    if (-1 == tmp___1) {
      zend_throw_exception_ex(phar_ce_PharException, 0L,
                              (char *)"phar \"%s\" is persistent, unable to copy on write",
                              phar->fname);
      return;
    } else {

    }
    zend_hash_find((HashTable const   *)(& phar->manifest),
                   (char const   *)(entry_obj->ent.entry)->filename,
                   (entry_obj->ent.entry)->filename_len,
                   (void **)(& entry_obj->ent.entry));
  } else {

  }
  if ((entry_obj->ent.entry)->metadata) {
    _zval_ptr_dtor(& (entry_obj->ent.entry)->metadata);
    (entry_obj->ent.entry)->metadata = (zval *)((void *)0);
  } else {

  }
  while (1) {
    tmp___2 = _emalloc(sizeof(zval_gc_info ));
    (entry_obj->ent.entry)->metadata = (zval *)tmp___2;
    ((zval_gc_info *)(entry_obj->ent.entry)->metadata)->u.buffered = (gc_root_buffer *)((void *)0);
    break;
  }
  ((entry_obj->ent.entry)->metadata)->refcount__gc = (zend_uint )1;
  ((entry_obj->ent.entry)->metadata)->is_ref__gc = (zend_uchar )0;
  tmp___3 = zval_isref_p((entry_obj->ent.entry)->metadata);
  is_ref = tmp___3;
  tmp___4 = zval_refcount_p((entry_obj->ent.entry)->metadata);
  refcount = tmp___4;
  while (1) {
    ((entry_obj->ent.entry)->metadata)->value = metadata->value;
    ((entry_obj->ent.entry)->metadata)->type = metadata->type;
    break;
  }
  _zval_copy_ctor((entry_obj->ent.entry)->metadata);
  zval_set_isref_to_p((entry_obj->ent.entry)->metadata, is_ref);
  zval_set_refcount_p((entry_obj->ent.entry)->metadata, refcount);
  (entry_obj->ent.entry)->is_modified = 1U;
  ((entry_obj->ent.entry)->phar)->is_modified = 1U;
  phar_flush((entry_obj->ent.entry)->phar, (char *)0, 0L, 0, & error);
  if (error) {
    zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
    _efree((void *)error);
  } else {

  }
  return;
}
}
void zim_PharFileInfo_delMetadata(int ht , zval *return_value ,
                                  zval **return_value_ptr , zval *this_ptr ,
                                  int return_value_used ) 
{ 
  char *error ;
  phar_entry_object *entry_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  phar_archive_data *phar ;
  int tmp___0 ;
  zval *__z ;
  zval *__z___0 ;
  zval *__z___1 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  entry_obj = (phar_entry_object *)tmp;
  if (! entry_obj->ent.entry) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized PharFileInfo object");
    return;
  } else {

  }
  if (phar_globals.readonly) {
    if (! ((entry_obj->ent.entry)->phar)->is_data) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Write operations disabled by the php.ini setting phar.readonly");
      return;
    } else {

    }
  } else {

  }
  if ((entry_obj->ent.entry)->is_temp_dir) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Phar entry is a temporary directory (not an actual entry in the archive), cannot delete metadata");
    return;
  } else {

  }
  if ((entry_obj->ent.entry)->metadata) {
    if ((entry_obj->ent.entry)->is_persistent) {
      phar = (entry_obj->ent.entry)->phar;
      tmp___0 = phar_copy_on_write(& phar);
      if (-1 == tmp___0) {
        zend_throw_exception_ex(phar_ce_PharException, 0L,
                                (char *)"phar \"%s\" is persistent, unable to copy on write",
                                phar->fname);
        return;
      } else {

      }
      zend_hash_find((HashTable const   *)(& phar->manifest),
                     (char const   *)(entry_obj->ent.entry)->filename,
                     (entry_obj->ent.entry)->filename_len,
                     (void **)(& entry_obj->ent.entry));
    } else {

    }
    _zval_ptr_dtor(& (entry_obj->ent.entry)->metadata);
    (entry_obj->ent.entry)->metadata = (zval *)((void *)0);
    (entry_obj->ent.entry)->is_modified = 1U;
    ((entry_obj->ent.entry)->phar)->is_modified = 1U;
    phar_flush((entry_obj->ent.entry)->phar, (char *)0, 0L, 0, & error);
    if (error) {
      zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
      _efree((void *)error);
      while (1) {
        __z = return_value;
        __z->value.lval = 0L;
        __z->type = (zend_uchar )3;
        break;
      }
      return;
    } else {
      while (1) {
        __z___0 = return_value;
        __z___0->value.lval = 1L;
        __z___0->type = (zend_uchar )3;
        break;
      }
      return;
    }
  } else {
    while (1) {
      __z___1 = return_value;
      __z___1->value.lval = 1L;
      __z___1->type = (zend_uchar )3;
      break;
    }
    return;
  }
}
}
void zim_PharFileInfo_getContent(int ht , zval *return_value ,
                                 zval **return_value_ptr , zval *this_ptr ,
                                 int return_value_used ) 
{ 
  char *error ;
  php_stream *fp ;
  phar_entry_info *link___0 ;
  phar_entry_object *entry_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int tmp___0 ;
  size_t __attribute__((__visibility__("default")))  tmp___1 ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  entry_obj = (phar_entry_object *)tmp;
  if (! entry_obj->ent.entry) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized PharFileInfo object");
    return;
  } else {

  }
  if ((entry_obj->ent.entry)->is_dir) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Phar error: Cannot retrieve contents, \"%s\" in phar \"%s\" is a directory",
                            (entry_obj->ent.entry)->filename,
                            ((entry_obj->ent.entry)->phar)->fname);
    return;
  } else {

  }
  link___0 = phar_get_link_source(entry_obj->ent.entry);
  if (! link___0) {
    link___0 = entry_obj->ent.entry;
  } else {

  }
  tmp___0 = phar_open_entry_fp(link___0, & error, 0);
  if (0 != tmp___0) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Phar error: Cannot retrieve contents, \"%s\" in phar \"%s\": %s",
                            (entry_obj->ent.entry)->filename,
                            ((entry_obj->ent.entry)->phar)->fname, error);
    _efree((void *)error);
    return;
  } else {

  }
  fp = phar_get_efp(link___0, 0);
  if (! fp) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Phar error: Cannot retrieve contents of \"%s\" in phar \"%s\"",
                            (entry_obj->ent.entry)->filename,
                            ((entry_obj->ent.entry)->phar)->fname);
    return;
  } else {

  }
  phar_seek_efp(link___0, (off_t )0, 0, (off_t )0, 0);
  return_value->type = (zend_uchar )6;
  tmp___1 = _php_stream_copy_to_mem(fp, & return_value->value.str.val,
                                    (size_t )link___0->uncompressed_filesize, 0);
  return_value->value.str.len = (int )tmp___1;
  if (! return_value->value.str.val) {
    tmp___2 = _estrndup("", 0U);
    return_value->value.str.val = (char *)tmp___2;
  } else {

  }
  return;
}
}
void zim_PharFileInfo_compress(int ht , zval *return_value ,
                               zval **return_value_ptr , zval *this_ptr ,
                               int return_value_used ) 
{ 
  long method ;
  char *error ;
  phar_entry_object *entry_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  phar_archive_data *phar ;
  int tmp___1 ;
  zval *__z ;
  int tmp___2 ;
  zval *__z___0 ;
  int tmp___3 ;
  zval *__z___1 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  entry_obj = (phar_entry_object *)tmp;
  if (! entry_obj->ent.entry) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized PharFileInfo object");
    return;
  } else {

  }
  tmp___0 = zend_parse_parameters(ht, "l", & method);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if ((entry_obj->ent.entry)->is_tar) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot compress with Gzip compression, not possible with tar-based phar archives");
    return;
  } else {

  }
  if ((entry_obj->ent.entry)->is_dir) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Phar entry is a directory, cannot set compression");
    return;
  } else {

  }
  if (phar_globals.readonly) {
    if (! ((entry_obj->ent.entry)->phar)->is_data) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Phar is readonly, cannot change compression");
      return;
    } else {

    }
  } else {

  }
  if ((entry_obj->ent.entry)->is_deleted) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L, (char *)"Cannot compress deleted file");
    return;
  } else {

  }
  if ((entry_obj->ent.entry)->is_persistent) {
    phar = (entry_obj->ent.entry)->phar;
    tmp___1 = phar_copy_on_write(& phar);
    if (-1 == tmp___1) {
      zend_throw_exception_ex(phar_ce_PharException, 0L,
                              (char *)"phar \"%s\" is persistent, unable to copy on write",
                              phar->fname);
      return;
    } else {

    }
    zend_hash_find((HashTable const   *)(& phar->manifest),
                   (char const   *)(entry_obj->ent.entry)->filename,
                   (entry_obj->ent.entry)->filename_len,
                   (void **)(& entry_obj->ent.entry));
  } else {

  }
  switch (method) {
  case 4096L: 
  if ((entry_obj->ent.entry)->flags & 4096U) {
    while (1) {
      __z = return_value;
      __z->value.lval = 1L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  if (((entry_obj->ent.entry)->flags & 8192U) != 0U) {
    if (! phar_globals.has_bz2) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Cannot compress with gzip compression, file is already compressed with bzip2 compression and bz2 extension is not enabled, cannot decompress");
      return;
    } else {

    }
    tmp___2 = phar_open_entry_fp(entry_obj->ent.entry, & error, 1);
    if (0 != tmp___2) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Phar error: Cannot decompress bzip2-compressed file \"%s\" in phar \"%s\" in order to compress with gzip: %s",
                              (entry_obj->ent.entry)->filename,
                              ((entry_obj->ent.entry)->phar)->fname, error);
      _efree((void *)error);
      return;
    } else {

    }
  } else {

  }
  if (! phar_globals.has_zlib) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot compress with gzip compression, zlib extension is not enabled");
    return;
  } else {

  }
  (entry_obj->ent.entry)->old_flags = (entry_obj->ent.entry)->flags;
  (entry_obj->ent.entry)->flags &= 4294905855U;
  (entry_obj->ent.entry)->flags |= 4096U;
  break;
  case 8192L: 
  if ((entry_obj->ent.entry)->flags & 8192U) {
    while (1) {
      __z___0 = return_value;
      __z___0->value.lval = 1L;
      __z___0->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  if (((entry_obj->ent.entry)->flags & 4096U) != 0U) {
    if (! phar_globals.has_zlib) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Cannot compress with bzip2 compression, file is already compressed with gzip compression and zlib extension is not enabled, cannot decompress");
      return;
    } else {

    }
    tmp___3 = phar_open_entry_fp(entry_obj->ent.entry, & error, 1);
    if (0 != tmp___3) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Phar error: Cannot decompress gzip-compressed file \"%s\" in phar \"%s\" in order to compress with bzip2: %s",
                              (entry_obj->ent.entry)->filename,
                              ((entry_obj->ent.entry)->phar)->fname, error);
      _efree((void *)error);
      return;
    } else {

    }
  } else {

  }
  if (! phar_globals.has_bz2) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot compress with bzip2 compression, bz2 extension is not enabled");
    return;
  } else {

  }
  (entry_obj->ent.entry)->old_flags = (entry_obj->ent.entry)->flags;
  (entry_obj->ent.entry)->flags &= 4294905855U;
  (entry_obj->ent.entry)->flags |= 8192U;
  break;
  default: 
  zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException, 0L,
                          (char *)"Unknown compression type specified");
  }
  ((entry_obj->ent.entry)->phar)->is_modified = 1U;
  (entry_obj->ent.entry)->is_modified = 1U;
  phar_flush((entry_obj->ent.entry)->phar, (char *)0, 0L, 0, & error);
  if (error) {
    zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
    _efree((void *)error);
  } else {

  }
  while (1) {
    __z___1 = return_value;
    __z___1->value.lval = 1L;
    __z___1->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zim_PharFileInfo_decompress(int ht , zval *return_value ,
                                 zval **return_value_ptr , zval *this_ptr ,
                                 int return_value_used ) 
{ 
  char *error ;
  phar_entry_object *entry_obj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval *__z ;
  phar_archive_data *phar ;
  int tmp___0 ;
  int tmp___1 ;
  zval *__z___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  entry_obj = (phar_entry_object *)tmp;
  if (! entry_obj->ent.entry) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Cannot call method on an uninitialized PharFileInfo object");
    return;
  } else {

  }
  if ((entry_obj->ent.entry)->is_dir) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L,
                            (char *)"Phar entry is a directory, cannot set compression");
    return;
  } else {

  }
  if (((entry_obj->ent.entry)->flags & 61440U) == 0U) {
    while (1) {
      __z = return_value;
      __z->value.lval = 1L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  if (phar_globals.readonly) {
    if (! ((entry_obj->ent.entry)->phar)->is_data) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L, (char *)"Phar is readonly, cannot decompress");
      return;
    } else {

    }
  } else {

  }
  if ((entry_obj->ent.entry)->is_deleted) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                            0L, (char *)"Cannot compress deleted file");
    return;
  } else {

  }
  if (((entry_obj->ent.entry)->flags & 4096U) != 0U) {
    if (! phar_globals.has_zlib) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Cannot decompress Gzip-compressed file, zlib extension is not enabled");
      return;
    } else {

    }
  } else {

  }
  if (((entry_obj->ent.entry)->flags & 8192U) != 0U) {
    if (! phar_globals.has_bz2) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Cannot decompress Bzip2-compressed file, bz2 extension is not enabled");
      return;
    } else {

    }
  } else {

  }
  if ((entry_obj->ent.entry)->is_persistent) {
    phar = (entry_obj->ent.entry)->phar;
    tmp___0 = phar_copy_on_write(& phar);
    if (-1 == tmp___0) {
      zend_throw_exception_ex(phar_ce_PharException, 0L,
                              (char *)"phar \"%s\" is persistent, unable to copy on write",
                              phar->fname);
      return;
    } else {

    }
    zend_hash_find((HashTable const   *)(& phar->manifest),
                   (char const   *)(entry_obj->ent.entry)->filename,
                   (entry_obj->ent.entry)->filename_len,
                   (void **)(& entry_obj->ent.entry));
  } else {

  }
  if (! (entry_obj->ent.entry)->fp) {
    tmp___1 = phar_open_archive_fp((entry_obj->ent.entry)->phar);
    if (-1 == tmp___1) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_BadMethodCallException,
                              0L,
                              (char *)"Cannot decompress entry \"%s\", phar error: Cannot open phar archive \"%s\" for reading",
                              (entry_obj->ent.entry)->filename,
                              ((entry_obj->ent.entry)->phar)->fname);
      return;
    } else {

    }
    (entry_obj->ent.entry)->fp_type = (enum phar_fp_type )0;
  } else {

  }
  (entry_obj->ent.entry)->old_flags = (entry_obj->ent.entry)->flags;
  (entry_obj->ent.entry)->flags &= 4294905855U;
  ((entry_obj->ent.entry)->phar)->is_modified = 1U;
  (entry_obj->ent.entry)->is_modified = 1U;
  phar_flush((entry_obj->ent.entry)->phar, (char *)0, 0L, 0, & error);
  if (error) {
    zend_throw_exception_ex(phar_ce_PharException, 0L, (char *)"%s", error);
    _efree((void *)error);
  } else {

  }
  while (1) {
    __z___0 = return_value;
    __z___0->value.lval = 1L;
    __z___0->type = (zend_uchar )3;
    break;
  }
  return;
}
}
static zend_arg_info const   arginfo_phar___construct[5]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"filename", (zend_uint )(sizeof("filename") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}, 
        {"flags", (zend_uint )(sizeof("flags") - 1UL), (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"alias", (zend_uint )(sizeof("alias") - 1UL), (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"fileformat", (zend_uint )(sizeof("fileformat") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_phar_createDS[3]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"index", (zend_uint )(sizeof("index") - 1UL), (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"webindex", (zend_uint )(sizeof("webindex") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_phar_loadPhar[3]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"filename", (zend_uint )(sizeof("filename") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}, 
        {"alias", (zend_uint )(sizeof("alias") - 1UL), (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}};
static zend_arg_info const   arginfo_phar_mapPhar[3]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"alias", (zend_uint )(sizeof("alias") - 1UL), (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"offset", (zend_uint )(sizeof("offset") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_phar_mount[3]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )2, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"inphar", (zend_uint )(sizeof("inphar") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}, 
        {"externalfile", (zend_uint )(sizeof("externalfile") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_phar_mungServer[2]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"munglist", (zend_uint )(sizeof("munglist") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_phar_webPhar[6]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"alias", (zend_uint )(sizeof("alias") - 1UL), (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"index", (zend_uint )(sizeof("index") - 1UL), (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"f404", (zend_uint )(sizeof("f404") - 1UL), (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"mimetypes", (zend_uint )(sizeof("mimetypes") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}, 
        {"rewrites", (zend_uint )(sizeof("rewrites") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_phar_running[2]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"retphar", (zend_uint )(sizeof("retphar") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_phar_ua[2]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"archive", (zend_uint )(sizeof("archive") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_phar_build[3]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"iterator", (zend_uint )(sizeof("iterator") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}, 
        {"base_directory", (zend_uint )(sizeof("base_directory") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_phar_conv[4]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"format", (zend_uint )(sizeof("format") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}, 
        {"compression_type", (zend_uint )(sizeof("compression_type") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}, 
        {"file_ext", (zend_uint )(sizeof("file_ext") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_phar_comps[3]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"compression_type", (zend_uint )(sizeof("compression_type") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}, 
        {"file_ext", (zend_uint )(sizeof("file_ext") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_phar_decomp[2]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"file_ext", (zend_uint )(sizeof("file_ext") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_phar_comp[2]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"compression_type", (zend_uint )(sizeof("compression_type") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_phar_compo[2]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"compression_type", (zend_uint )(sizeof("compression_type") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_phar_copy[3]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )2, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"newfile", (zend_uint )(sizeof("newfile") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}, 
        {"oldfile", (zend_uint )(sizeof("oldfile") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_phar_delete[2]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"entry", (zend_uint )(sizeof("entry") - 1UL), (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}};
static zend_arg_info const   arginfo_phar_fromdir[3]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"base_dir", (zend_uint )(sizeof("base_dir") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}, 
        {"regex", (zend_uint )(sizeof("regex") - 1UL), (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}};
static zend_arg_info const   arginfo_phar_offsetExists[2]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"entry", (zend_uint )(sizeof("entry") - 1UL), (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}};
static zend_arg_info const   arginfo_phar_offsetSet[3]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )2, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"entry", (zend_uint )(sizeof("entry") - 1UL), (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"value", (zend_uint )(sizeof("value") - 1UL), (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}};
static zend_arg_info const   arginfo_phar_setAlias[2]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"alias", (zend_uint )(sizeof("alias") - 1UL), (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}};
static zend_arg_info const   arginfo_phar_setMetadata[2]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"metadata", (zend_uint )(sizeof("metadata") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_phar_setSigAlgo[3]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"algorithm", (zend_uint )(sizeof("algorithm") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}, 
        {"privatekey", (zend_uint )(sizeof("privatekey") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_phar_setStub[3]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"newstub", (zend_uint )(sizeof("newstub") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}, 
        {"maxlen", (zend_uint )(sizeof("maxlen") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_phar_emptydir[2]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"dirname", (zend_uint )(sizeof("dirname") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_phar_extract[4]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"pathto", (zend_uint )(sizeof("pathto") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}, 
        {"files", (zend_uint )(sizeof("files") - 1UL), (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"overwrite", (zend_uint )(sizeof("overwrite") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_phar_addfile[3]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"filename", (zend_uint )(sizeof("filename") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}, 
        {"localname", (zend_uint )(sizeof("localname") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_phar_fromstring[3]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"localname", (zend_uint )(sizeof("localname") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}, 
        {"contents", (zend_uint )(sizeof("contents") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_phar_isff[2]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"fileformat", (zend_uint )(sizeof("fileformat") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
zend_function_entry php_archive_methods[57]  = 
  {      {"__construct", & zim_Phar___construct, arginfo_phar___construct,
      (zend_uint )(sizeof(arginfo_phar___construct) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"__destruct", & zim_Phar___destruct,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"addEmptyDir", & zim_Phar_addEmptyDir, arginfo_phar_emptydir,
      (zend_uint )(sizeof(arginfo_phar_emptydir) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"addFile", & zim_Phar_addFile, arginfo_phar_addfile,
      (zend_uint )(sizeof(arginfo_phar_addfile) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"addFromString", & zim_Phar_addFromString, arginfo_phar_fromstring,
      (zend_uint )(sizeof(arginfo_phar_fromstring) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"buildFromDirectory", & zim_Phar_buildFromDirectory, arginfo_phar_fromdir,
      (zend_uint )(sizeof(arginfo_phar_fromdir) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"buildFromIterator", & zim_Phar_buildFromIterator, arginfo_phar_build,
      (zend_uint )(sizeof(arginfo_phar_build) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"compressFiles", & zim_Phar_compressFiles, arginfo_phar_comp,
      (zend_uint )(sizeof(arginfo_phar_comp) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"decompressFiles", & zim_Phar_decompressFiles,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"compress", & zim_Phar_compress, arginfo_phar_comps,
      (zend_uint )(sizeof(arginfo_phar_comps) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"decompress", & zim_Phar_decompress, arginfo_phar_decomp,
      (zend_uint )(sizeof(arginfo_phar_decomp) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"convertToExecutable", & zim_Phar_convertToExecutable, arginfo_phar_conv,
      (zend_uint )(sizeof(arginfo_phar_conv) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"convertToData", & zim_Phar_convertToData, arginfo_phar_conv,
      (zend_uint )(sizeof(arginfo_phar_conv) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"copy", & zim_Phar_copy, arginfo_phar_copy,
      (zend_uint )(sizeof(arginfo_phar_copy) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"count", & zim_Phar_count, (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"delete", & zim_Phar_delete, arginfo_phar_delete,
      (zend_uint )(sizeof(arginfo_phar_delete) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"delMetadata", & zim_Phar_delMetadata,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"extractTo", & zim_Phar_extractTo, arginfo_phar_extract,
      (zend_uint )(sizeof(arginfo_phar_extract) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getAlias", & zim_Phar_getAlias,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getPath", & zim_Phar_getPath,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getMetadata", & zim_Phar_getMetadata,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getModified", & zim_Phar_getModified,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getSignature", & zim_Phar_getSignature,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getStub", & zim_Phar_getStub,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getVersion", & zim_Phar_getVersion,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"hasMetadata", & zim_Phar_hasMetadata,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"isBuffering", & zim_Phar_isBuffering,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"isCompressed", & zim_Phar_isCompressed,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"isFileFormat", & zim_Phar_isFileFormat, arginfo_phar_isff,
      (zend_uint )(sizeof(arginfo_phar_isff) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"isWritable", & zim_Phar_isWritable,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"offsetExists", & zim_Phar_offsetExists, arginfo_phar_offsetExists,
      (zend_uint )(sizeof(arginfo_phar_offsetExists) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"offsetGet", & zim_Phar_offsetGet, arginfo_phar_offsetExists,
      (zend_uint )(sizeof(arginfo_phar_offsetExists) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"offsetSet", & zim_Phar_offsetSet, arginfo_phar_offsetSet,
      (zend_uint )(sizeof(arginfo_phar_offsetSet) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"offsetUnset", & zim_Phar_offsetUnset, arginfo_phar_offsetExists,
      (zend_uint )(sizeof(arginfo_phar_offsetExists) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"setAlias", & zim_Phar_setAlias, arginfo_phar_setAlias,
      (zend_uint )(sizeof(arginfo_phar_setAlias) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"setDefaultStub", & zim_Phar_setDefaultStub, arginfo_phar_createDS,
      (zend_uint )(sizeof(arginfo_phar_createDS) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"setMetadata", & zim_Phar_setMetadata, arginfo_phar_setMetadata,
      (zend_uint )(sizeof(arginfo_phar_setMetadata) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"setSignatureAlgorithm", & zim_Phar_setSignatureAlgorithm,
      arginfo_phar_setSigAlgo,
      (zend_uint )(sizeof(arginfo_phar_setSigAlgo) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"setStub", & zim_Phar_setStub, arginfo_phar_setStub,
      (zend_uint )(sizeof(arginfo_phar_setStub) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"startBuffering", & zim_Phar_startBuffering,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"stopBuffering", & zim_Phar_stopBuffering,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"apiVersion", & zim_Phar_apiVersion,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )261}, 
        {"canCompress", & zim_Phar_canCompress,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )261}, 
        {"canWrite", & zim_Phar_canWrite,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )261}, 
        {"createDefaultStub", & zim_Phar_createDefaultStub, arginfo_phar_createDS,
      (zend_uint )(sizeof(arginfo_phar_createDS) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )261}, 
        {"getSupportedCompression", & zim_Phar_getSupportedCompression,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )261}, 
        {"getSupportedSignatures", & zim_Phar_getSupportedSignatures,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )261}, 
        {"interceptFileFuncs", & zim_Phar_interceptFileFuncs,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )261}, 
        {"isValidPharFilename", & zim_Phar_isValidPharFilename,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )261}, 
        {"loadPhar", & zim_Phar_loadPhar, arginfo_phar_loadPhar,
      (zend_uint )(sizeof(arginfo_phar_loadPhar) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )261}, 
        {"mapPhar", & zim_Phar_mapPhar, arginfo_phar_mapPhar,
      (zend_uint )(sizeof(arginfo_phar_mapPhar) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )261}, 
        {"running", & zim_Phar_running, arginfo_phar_running,
      (zend_uint )(sizeof(arginfo_phar_running) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )261}, 
        {"mount", & zim_Phar_mount, arginfo_phar_mount,
      (zend_uint )(sizeof(arginfo_phar_mount) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )261}, 
        {"mungServer", & zim_Phar_mungServer, arginfo_phar_mungServer,
      (zend_uint )(sizeof(arginfo_phar_mungServer) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )261}, 
        {"unlinkArchive", & zim_Phar_unlinkArchive, arginfo_phar_ua,
      (zend_uint )(sizeof(arginfo_phar_ua) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )261}, 
        {"webPhar", & zim_Phar_webPhar, arginfo_phar_webPhar,
      (zend_uint )(sizeof(arginfo_phar_webPhar) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )261}, 
        {(char const   *)((void *)0),
      (void (*)(int ht , zval *return_value ,
                zval **return_value_ptr , zval *this_ptr ,
                int return_value_used ))((void *)0),
      (struct _zend_arg_info  const  *)((void *)0), 0U, 0U}};
static zend_arg_info const   arginfo_entry___construct[2]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"filename", (zend_uint )(sizeof("filename") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_entry_chmod[2]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"perms", (zend_uint )(sizeof("perms") - 1UL), (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}};
zend_function_entry php_entry_methods[16]  = 
  {      {"__construct", & zim_PharFileInfo___construct, arginfo_entry___construct,
      (zend_uint )(sizeof(arginfo_entry___construct) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"__destruct", & zim_PharFileInfo___destruct,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"chmod", & zim_PharFileInfo_chmod, arginfo_entry_chmod,
      (zend_uint )(sizeof(arginfo_entry_chmod) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"compress", & zim_PharFileInfo_compress, arginfo_phar_comp,
      (zend_uint )(sizeof(arginfo_phar_comp) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"decompress", & zim_PharFileInfo_decompress,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"delMetadata", & zim_PharFileInfo_delMetadata,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getCompressedSize", & zim_PharFileInfo_getCompressedSize,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getCRC32", & zim_PharFileInfo_getCRC32,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getContent", & zim_PharFileInfo_getContent,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getMetadata", & zim_PharFileInfo_getMetadata,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getPharFlags", & zim_PharFileInfo_getPharFlags,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"hasMetadata", & zim_PharFileInfo_hasMetadata,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"isCompressed", & zim_PharFileInfo_isCompressed, arginfo_phar_compo,
      (zend_uint )(sizeof(arginfo_phar_compo) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"isCRCChecked", & zim_PharFileInfo_isCRCChecked,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"setMetadata", & zim_PharFileInfo_setMetadata, arginfo_phar_setMetadata,
      (zend_uint )(sizeof(arginfo_phar_setMetadata) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {(char const   *)((void *)0),
      (void (*)(int ht , zval *return_value ,
                zval **return_value_ptr , zval *this_ptr ,
                int return_value_used ))((void *)0),
      (struct _zend_arg_info  const  *)((void *)0), 0U, 0U}};
zend_function_entry phar_exception_methods[1]  = {      {(char const   *)((void *)0),
      (void (*)(int ht , zval *return_value ,
                zval **return_value_ptr , zval *this_ptr ,
                int return_value_used ))((void *)0),
      (struct _zend_arg_info  const  *)((void *)0), 0U, 0U}};
void phar_object_init(void) 
{ 
  zend_class_entry ce ;
  char const   *cl_name ;
  int _len ;
  char const __attribute__((__visibility__("default")))  *tmp ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp___1 ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp___2 ;
  char const   *cl_name___0 ;
  int _len___0 ;
  char const __attribute__((__visibility__("default")))  *tmp___3 ;
  char __attribute__((__visibility__("default")))  *tmp___4 ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp___5 ;
  char const   *cl_name___1 ;
  int _len___1 ;
  char const __attribute__((__visibility__("default")))  *tmp___6 ;
  char __attribute__((__visibility__("default")))  *tmp___7 ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp___8 ;
  char const   *cl_name___2 ;
  int _len___2 ;
  char const __attribute__((__visibility__("default")))  *tmp___9 ;
  char __attribute__((__visibility__("default")))  *tmp___10 ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp___11 ;

  {
  cl_name = "PharException";
  _len = (int )(sizeof("PharException") - 1UL);
  tmp = (*zend_new_interned_string)(cl_name, _len + 1, 0);
  ce.name = (char const   *)tmp;
  if ((unsigned long )ce.name == (unsigned long )cl_name) {
    tmp___0 = zend_strndup(cl_name, (unsigned int )_len);
    ce.name = (char const   *)tmp___0;
  } else {

  }
  ce.name_length = (zend_uint )_len;
  ce.constructor = (union _zend_function *)((void *)0);
  ce.destructor = (union _zend_function *)((void *)0);
  ce.clone = (union _zend_function *)((void *)0);
  ce.serialize = (int (*)(zval *object , unsigned char **buffer ,
                          zend_uint *buf_len , zend_serialize_data *data ))((void *)0);
  ce.unserialize = (int (*)(zval **object , zend_class_entry *ce ,
                            unsigned char const   *buf , zend_uint buf_len ,
                            zend_unserialize_data *data ))((void *)0);
  ce.create_object = (zend_object_value (*)(zend_class_entry *class_type ))((void *)0);
  ce.interface_gets_implemented = (int (*)(zend_class_entry *iface ,
                                           zend_class_entry *class_type ))((void *)0);
  ce.get_static_method = (union _zend_function *(*)(zend_class_entry *ce ,
                                                    char *method ,
                                                    int method_len ))((void *)0);
  ce.__call = (union _zend_function *)((void *)0);
  ce.__callstatic = (union _zend_function *)((void *)0);
  ce.__tostring = (union _zend_function *)((void *)0);
  ce.__get = (union _zend_function *)((void *)0);
  ce.__set = (union _zend_function *)((void *)0);
  ce.__unset = (union _zend_function *)((void *)0);
  ce.__isset = (union _zend_function *)((void *)0);
  ce.serialize_func = (union _zend_function *)((void *)0);
  ce.unserialize_func = (union _zend_function *)((void *)0);
  ce.serialize = (int (*)(zval *object , unsigned char **buffer ,
                          zend_uint *buf_len , zend_serialize_data *data ))((void *)0);
  ce.unserialize = (int (*)(zval **object , zend_class_entry *ce ,
                            unsigned char const   *buf , zend_uint buf_len ,
                            zend_unserialize_data *data ))((void *)0);
  ce.parent = (struct _zend_class_entry *)((void *)0);
  ce.num_interfaces = (zend_uint )0;
  ce.traits = (zend_class_entry **)((void *)0);
  ce.num_traits = (zend_uint )0;
  ce.trait_aliases = (zend_trait_alias **)((void *)0);
  ce.trait_precedences = (zend_trait_precedence **)((void *)0);
  ce.interfaces = (zend_class_entry **)((void *)0);
  ce.get_iterator = (zend_object_iterator *(*)(zend_class_entry *ce ,
                                               zval *object , int by_ref ))((void *)0);
  ce.iterator_funcs.funcs = (zend_object_iterator_funcs *)((void *)0);
  ce.info.internal.module = (struct _zend_module_entry *)((void *)0);
  ce.info.internal.builtin_functions = (struct _zend_function_entry  const  *)(phar_exception_methods);
  tmp___1 = zend_exception_get_default();
  tmp___2 = zend_register_internal_class_ex(& ce, (zend_class_entry *)tmp___1,
                                            (char *)((void *)0));
  phar_ce_PharException = (zend_class_entry *)tmp___2;
  cl_name___0 = "Phar";
  _len___0 = (int )(sizeof("Phar") - 1UL);
  tmp___3 = (*zend_new_interned_string)(cl_name___0, _len___0 + 1, 0);
  ce.name = (char const   *)tmp___3;
  if ((unsigned long )ce.name == (unsigned long )cl_name___0) {
    tmp___4 = zend_strndup(cl_name___0, (unsigned int )_len___0);
    ce.name = (char const   *)tmp___4;
  } else {

  }
  ce.name_length = (zend_uint )_len___0;
  ce.constructor = (union _zend_function *)((void *)0);
  ce.destructor = (union _zend_function *)((void *)0);
  ce.clone = (union _zend_function *)((void *)0);
  ce.serialize = (int (*)(zval *object , unsigned char **buffer ,
                          zend_uint *buf_len , zend_serialize_data *data ))((void *)0);
  ce.unserialize = (int (*)(zval **object , zend_class_entry *ce ,
                            unsigned char const   *buf , zend_uint buf_len ,
                            zend_unserialize_data *data ))((void *)0);
  ce.create_object = (zend_object_value (*)(zend_class_entry *class_type ))((void *)0);
  ce.interface_gets_implemented = (int (*)(zend_class_entry *iface ,
                                           zend_class_entry *class_type ))((void *)0);
  ce.get_static_method = (union _zend_function *(*)(zend_class_entry *ce ,
                                                    char *method ,
                                                    int method_len ))((void *)0);
  ce.__call = (union _zend_function *)((void *)0);
  ce.__callstatic = (union _zend_function *)((void *)0);
  ce.__tostring = (union _zend_function *)((void *)0);
  ce.__get = (union _zend_function *)((void *)0);
  ce.__set = (union _zend_function *)((void *)0);
  ce.__unset = (union _zend_function *)((void *)0);
  ce.__isset = (union _zend_function *)((void *)0);
  ce.serialize_func = (union _zend_function *)((void *)0);
  ce.unserialize_func = (union _zend_function *)((void *)0);
  ce.serialize = (int (*)(zval *object , unsigned char **buffer ,
                          zend_uint *buf_len , zend_serialize_data *data ))((void *)0);
  ce.unserialize = (int (*)(zval **object , zend_class_entry *ce ,
                            unsigned char const   *buf , zend_uint buf_len ,
                            zend_unserialize_data *data ))((void *)0);
  ce.parent = (struct _zend_class_entry *)((void *)0);
  ce.num_interfaces = (zend_uint )0;
  ce.traits = (zend_class_entry **)((void *)0);
  ce.num_traits = (zend_uint )0;
  ce.trait_aliases = (zend_trait_alias **)((void *)0);
  ce.trait_precedences = (zend_trait_precedence **)((void *)0);
  ce.interfaces = (zend_class_entry **)((void *)0);
  ce.get_iterator = (zend_object_iterator *(*)(zend_class_entry *ce ,
                                               zval *object , int by_ref ))((void *)0);
  ce.iterator_funcs.funcs = (zend_object_iterator_funcs *)((void *)0);
  ce.info.internal.module = (struct _zend_module_entry *)((void *)0);
  ce.info.internal.builtin_functions = (struct _zend_function_entry  const  *)(php_archive_methods);
  tmp___5 = zend_register_internal_class_ex(& ce,
                                            (zend_class_entry *)spl_ce_RecursiveDirectoryIterator,
                                            (char *)((void *)0));
  phar_ce_archive = (zend_class_entry *)tmp___5;
  zend_class_implements(phar_ce_archive, 2, spl_ce_Countable,
                        zend_ce_arrayaccess);
  cl_name___1 = "PharData";
  _len___1 = (int )(sizeof("PharData") - 1UL);
  tmp___6 = (*zend_new_interned_string)(cl_name___1, _len___1 + 1, 0);
  ce.name = (char const   *)tmp___6;
  if ((unsigned long )ce.name == (unsigned long )cl_name___1) {
    tmp___7 = zend_strndup(cl_name___1, (unsigned int )_len___1);
    ce.name = (char const   *)tmp___7;
  } else {

  }
  ce.name_length = (zend_uint )_len___1;
  ce.constructor = (union _zend_function *)((void *)0);
  ce.destructor = (union _zend_function *)((void *)0);
  ce.clone = (union _zend_function *)((void *)0);
  ce.serialize = (int (*)(zval *object , unsigned char **buffer ,
                          zend_uint *buf_len , zend_serialize_data *data ))((void *)0);
  ce.unserialize = (int (*)(zval **object , zend_class_entry *ce ,
                            unsigned char const   *buf , zend_uint buf_len ,
                            zend_unserialize_data *data ))((void *)0);
  ce.create_object = (zend_object_value (*)(zend_class_entry *class_type ))((void *)0);
  ce.interface_gets_implemented = (int (*)(zend_class_entry *iface ,
                                           zend_class_entry *class_type ))((void *)0);
  ce.get_static_method = (union _zend_function *(*)(zend_class_entry *ce ,
                                                    char *method ,
                                                    int method_len ))((void *)0);
  ce.__call = (union _zend_function *)((void *)0);
  ce.__callstatic = (union _zend_function *)((void *)0);
  ce.__tostring = (union _zend_function *)((void *)0);
  ce.__get = (union _zend_function *)((void *)0);
  ce.__set = (union _zend_function *)((void *)0);
  ce.__unset = (union _zend_function *)((void *)0);
  ce.__isset = (union _zend_function *)((void *)0);
  ce.serialize_func = (union _zend_function *)((void *)0);
  ce.unserialize_func = (union _zend_function *)((void *)0);
  ce.serialize = (int (*)(zval *object , unsigned char **buffer ,
                          zend_uint *buf_len , zend_serialize_data *data ))((void *)0);
  ce.unserialize = (int (*)(zval **object , zend_class_entry *ce ,
                            unsigned char const   *buf , zend_uint buf_len ,
                            zend_unserialize_data *data ))((void *)0);
  ce.parent = (struct _zend_class_entry *)((void *)0);
  ce.num_interfaces = (zend_uint )0;
  ce.traits = (zend_class_entry **)((void *)0);
  ce.num_traits = (zend_uint )0;
  ce.trait_aliases = (zend_trait_alias **)((void *)0);
  ce.trait_precedences = (zend_trait_precedence **)((void *)0);
  ce.interfaces = (zend_class_entry **)((void *)0);
  ce.get_iterator = (zend_object_iterator *(*)(zend_class_entry *ce ,
                                               zval *object , int by_ref ))((void *)0);
  ce.iterator_funcs.funcs = (zend_object_iterator_funcs *)((void *)0);
  ce.info.internal.module = (struct _zend_module_entry *)((void *)0);
  ce.info.internal.builtin_functions = (struct _zend_function_entry  const  *)(php_archive_methods);
  tmp___8 = zend_register_internal_class_ex(& ce,
                                            (zend_class_entry *)spl_ce_RecursiveDirectoryIterator,
                                            (char *)((void *)0));
  phar_ce_data = (zend_class_entry *)tmp___8;
  zend_class_implements(phar_ce_data, 2, spl_ce_Countable, zend_ce_arrayaccess);
  cl_name___2 = "PharFileInfo";
  _len___2 = (int )(sizeof("PharFileInfo") - 1UL);
  tmp___9 = (*zend_new_interned_string)(cl_name___2, _len___2 + 1, 0);
  ce.name = (char const   *)tmp___9;
  if ((unsigned long )ce.name == (unsigned long )cl_name___2) {
    tmp___10 = zend_strndup(cl_name___2, (unsigned int )_len___2);
    ce.name = (char const   *)tmp___10;
  } else {

  }
  ce.name_length = (zend_uint )_len___2;
  ce.constructor = (union _zend_function *)((void *)0);
  ce.destructor = (union _zend_function *)((void *)0);
  ce.clone = (union _zend_function *)((void *)0);
  ce.serialize = (int (*)(zval *object , unsigned char **buffer ,
                          zend_uint *buf_len , zend_serialize_data *data ))((void *)0);
  ce.unserialize = (int (*)(zval **object , zend_class_entry *ce ,
                            unsigned char const   *buf , zend_uint buf_len ,
                            zend_unserialize_data *data ))((void *)0);
  ce.create_object = (zend_object_value (*)(zend_class_entry *class_type ))((void *)0);
  ce.interface_gets_implemented = (int (*)(zend_class_entry *iface ,
                                           zend_class_entry *class_type ))((void *)0);
  ce.get_static_method = (union _zend_function *(*)(zend_class_entry *ce ,
                                                    char *method ,
                                                    int method_len ))((void *)0);
  ce.__call = (union _zend_function *)((void *)0);
  ce.__callstatic = (union _zend_function *)((void *)0);
  ce.__tostring = (union _zend_function *)((void *)0);
  ce.__get = (union _zend_function *)((void *)0);
  ce.__set = (union _zend_function *)((void *)0);
  ce.__unset = (union _zend_function *)((void *)0);
  ce.__isset = (union _zend_function *)((void *)0);
  ce.serialize_func = (union _zend_function *)((void *)0);
  ce.unserialize_func = (union _zend_function *)((void *)0);
  ce.serialize = (int (*)(zval *object , unsigned char **buffer ,
                          zend_uint *buf_len , zend_serialize_data *data ))((void *)0);
  ce.unserialize = (int (*)(zval **object , zend_class_entry *ce ,
                            unsigned char const   *buf , zend_uint buf_len ,
                            zend_unserialize_data *data ))((void *)0);
  ce.parent = (struct _zend_class_entry *)((void *)0);
  ce.num_interfaces = (zend_uint )0;
  ce.traits = (zend_class_entry **)((void *)0);
  ce.num_traits = (zend_uint )0;
  ce.trait_aliases = (zend_trait_alias **)((void *)0);
  ce.trait_precedences = (zend_trait_precedence **)((void *)0);
  ce.interfaces = (zend_class_entry **)((void *)0);
  ce.get_iterator = (zend_object_iterator *(*)(zend_class_entry *ce ,
                                               zval *object , int by_ref ))((void *)0);
  ce.iterator_funcs.funcs = (zend_object_iterator_funcs *)((void *)0);
  ce.info.internal.module = (struct _zend_module_entry *)((void *)0);
  ce.info.internal.builtin_functions = (struct _zend_function_entry  const  *)(php_entry_methods);
  tmp___11 = zend_register_internal_class_ex(& ce,
                                             (zend_class_entry *)spl_ce_SplFileInfo,
                                             (char *)((void *)0));
  phar_ce_entry = (zend_class_entry *)tmp___11;
  zend_declare_class_constant_long(phar_ce_archive, "BZ2", sizeof("BZ2") - 1UL,
                                   8192L);
  zend_declare_class_constant_long(phar_ce_archive, "GZ", sizeof("GZ") - 1UL,
                                   4096L);
  zend_declare_class_constant_long(phar_ce_archive, "NONE",
                                   sizeof("NONE") - 1UL, 0L);
  zend_declare_class_constant_long(phar_ce_archive, "PHAR",
                                   sizeof("PHAR") - 1UL, 1L);
  zend_declare_class_constant_long(phar_ce_archive, "TAR", sizeof("TAR") - 1UL,
                                   2L);
  zend_declare_class_constant_long(phar_ce_archive, "ZIP", sizeof("ZIP") - 1UL,
                                   3L);
  zend_declare_class_constant_long(phar_ce_archive, "COMPRESSED",
                                   sizeof("COMPRESSED") - 1UL, 61440L);
  zend_declare_class_constant_long(phar_ce_archive, "PHP", sizeof("PHP") - 1UL,
                                   (long )'\000');
  zend_declare_class_constant_long(phar_ce_archive, "PHPS",
                                   sizeof("PHPS") - 1UL, (long )'\001');
  zend_declare_class_constant_long(phar_ce_archive, "MD5", sizeof("MD5") - 1UL,
                                   1L);
  zend_declare_class_constant_long(phar_ce_archive, "OPENSSL",
                                   sizeof("OPENSSL") - 1UL, 16L);
  zend_declare_class_constant_long(phar_ce_archive, "SHA1",
                                   sizeof("SHA1") - 1UL, 2L);
  zend_declare_class_constant_long(phar_ce_archive, "SHA256",
                                   sizeof("SHA256") - 1UL, 3L);
  zend_declare_class_constant_long(phar_ce_archive, "SHA512",
                                   sizeof("SHA512") - 1UL, 4L);
  return;
}
}
