typedef unsigned long size_t;
typedef int wchar_t;
typedef int __int32_t;
typedef unsigned long __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long __ino_t;
typedef unsigned long __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long __nlink_t;
typedef long __off_t;
typedef long __off64_t;
typedef long __time_t;
typedef long __blksize_t;
typedef long __blkcnt_t;
typedef long __blkcnt64_t;
typedef long __ssize_t;
typedef long __syscall_slong_t;
typedef unsigned int __socklen_t;
typedef __off_t off_t;
typedef __ssize_t ssize_t;
typedef unsigned long ulong;
typedef unsigned int uint;
struct __anonstruct___sigset_t_9 {
   unsigned long __val[1024UL / (8UL * sizeof(unsigned long ))] ;
};
typedef struct __anonstruct___sigset_t_9 __sigset_t;
struct timespec {
   __time_t tv_sec ;
   __syscall_slong_t tv_nsec ;
};
union __anonunion___u_23 {
   long double __l ;
   int __i[3] ;
};
struct _IO_FILE;
struct _IO_FILE;
struct _IO_FILE;
typedef struct _IO_FILE FILE;
typedef struct _IO_FILE __FILE;
union __anonunion___value_25 {
   unsigned int __wch ;
   char __wchb[4] ;
};
struct __anonstruct___mbstate_t_24 {
   int __count ;
   union __anonunion___value_25 __value ;
};
typedef struct __anonstruct___mbstate_t_24 __mbstate_t;
typedef __builtin_va_list __gnuc_va_list;
struct _IO_FILE;
typedef void _IO_lock_t;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
struct _IO_FILE {
   int _flags ;
   char *_IO_read_ptr ;
   char *_IO_read_end ;
   char *_IO_read_base ;
   char *_IO_write_base ;
   char *_IO_write_ptr ;
   char *_IO_write_end ;
   char *_IO_buf_base ;
   char *_IO_buf_end ;
   char *_IO_save_base ;
   char *_IO_backup_base ;
   char *_IO_save_end ;
   struct _IO_marker *_markers ;
   struct _IO_FILE *_chain ;
   int _fileno ;
   int _flags2 ;
   __off_t _old_offset ;
   unsigned short _cur_column ;
   signed char _vtable_offset ;
   char _shortbuf[1] ;
   _IO_lock_t *_lock ;
   __off64_t _offset ;
   void *__pad1 ;
   void *__pad2 ;
   void *__pad3 ;
   void *__pad4 ;
   size_t __pad5 ;
   int _mode ;
   char _unused2[(15UL * sizeof(int ) - 4UL * sizeof(void *)) - sizeof(size_t )] ;
};
typedef struct _IO_FILE _IO_FILE;
struct obstack;
struct obstack;
struct obstack;
typedef unsigned char zend_bool;
typedef unsigned char zend_uchar;
typedef unsigned int zend_uint;
typedef unsigned long zend_ulong;
typedef unsigned int zend_object_handle;
struct _zend_object_handlers;
struct _zend_object_handlers;
typedef struct _zend_object_handlers zend_object_handlers;
struct _zend_object_value {
   zend_object_handle handle ;
   zend_object_handlers const   *handlers ;
};
typedef struct _zend_object_value zend_object_value;
struct _hashtable;
struct _hashtable;
struct _hashtable;
struct bucket {
   ulong h ;
   uint nKeyLength ;
   void *pData ;
   void *pDataPtr ;
   struct bucket *pListNext ;
   struct bucket *pListLast ;
   struct bucket *pNext ;
   struct bucket *pLast ;
   char const   *arKey ;
};
typedef struct bucket Bucket;
struct _hashtable {
   uint nTableSize ;
   uint nTableMask ;
   uint nNumOfElements ;
   ulong nNextFreeElement ;
   Bucket *pInternalPointer ;
   Bucket *pListHead ;
   Bucket *pListTail ;
   Bucket **arBuckets ;
   void (*pDestructor)(void *pDest ) ;
   zend_bool persistent ;
   unsigned char nApplyCount ;
   zend_bool bApplyProtection ;
};
typedef struct _hashtable HashTable;
typedef Bucket *HashPosition;
struct _HashPointer {
   HashPosition pos ;
   ulong h ;
};
typedef struct _HashPointer HashPointer;
struct _zval_struct;
struct _zval_struct;
typedef struct _zval_struct zval;
struct _zend_class_entry;
struct _zend_class_entry;
typedef struct _zend_class_entry zend_class_entry;
struct _zend_object {
   zend_class_entry *ce ;
   HashTable *properties ;
   zval **properties_table ;
   HashTable *guards ;
};
typedef struct _zend_object zend_object;
union _zend_function;
union _zend_function;
union _zend_function;
struct _zend_property_info;
struct _zend_property_info;
struct _zend_property_info;
struct _zend_literal;
struct _zend_literal;
struct _zend_literal;
struct _zend_object_handlers {
   void (*add_ref)(zval *object ) ;
   void (*del_ref)(zval *object ) ;
   zend_object_value (*clone_obj)(zval *object ) ;
   zval *(*read_property)(zval *object , zval *member , int type ,
                          struct _zend_literal  const  *key ) ;
   void (*write_property)(zval *object , zval *member , zval *value ,
                          struct _zend_literal  const  *key ) ;
   zval *(*read_dimension)(zval *object , zval *offset , int type ) ;
   void (*write_dimension)(zval *object , zval *offset , zval *value ) ;
   zval **(*get_property_ptr_ptr)(zval *object , zval *member ,
                                  struct _zend_literal  const  *key ) ;
   zval *(*get)(zval *object ) ;
   void (*set)(zval **object , zval *value ) ;
   int (*has_property)(zval *object , zval *member , int has_set_exists ,
                       struct _zend_literal  const  *key ) ;
   void (*unset_property)(zval *object , zval *member ,
                          struct _zend_literal  const  *key ) ;
   int (*has_dimension)(zval *object , zval *member , int check_empty ) ;
   void (*unset_dimension)(zval *object , zval *offset ) ;
   HashTable *(*get_properties)(zval *object ) ;
   union _zend_function *(*get_method)(zval **object_ptr , char *method ,
                                       int method_len ,
                                       struct _zend_literal  const  *key ) ;
   int (*call_method)(char const   *method , int ht , zval *return_value ,
                      zval **return_value_ptr , zval *this_ptr ,
                      int return_value_used ) ;
   union _zend_function *(*get_constructor)(zval *object ) ;
   zend_class_entry *(*get_class_entry)(zval const   *object ) ;
   int (*get_class_name)(zval const   *object , char const   **class_name ,
                         zend_uint *class_name_len , int parent ) ;
   int (*compare_objects)(zval *object1 , zval *object2 ) ;
   int (*cast_object)(zval *readobj , zval *retval , int type ) ;
   int (*count_elements)(zval *object , long *count ) ;
   HashTable *(*get_debug_info)(zval *object , int *is_temp ) ;
   int (*get_closure)(zval *obj , zend_class_entry **ce_ptr ,
                      union _zend_function **fptr_ptr , zval **zobj_ptr ) ;
   HashTable *(*get_gc)(zval *object , zval ***table , int *n ) ;
};
struct __anonstruct_str_34 {
   char *val ;
   int len ;
};
union _zvalue_value {
   long lval ;
   double dval ;
   struct __anonstruct_str_34 str ;
   HashTable *ht ;
   zend_object_value obj ;
};
typedef union _zvalue_value zvalue_value;
struct _zval_struct {
   zvalue_value value ;
   zend_uint refcount__gc ;
   zend_uchar type ;
   zend_uchar is_ref__gc ;
};
union _zend_function;
struct _zend_object_iterator;
struct _zend_object_iterator;
typedef struct _zend_object_iterator zend_object_iterator;
struct _zend_object_iterator_funcs {
   void (*dtor)(zend_object_iterator *iter ) ;
   int (*valid)(zend_object_iterator *iter ) ;
   void (*get_current_data)(zend_object_iterator *iter , zval ***data ) ;
   int (*get_current_key)(zend_object_iterator *iter , char **str_key ,
                          uint *str_key_len , ulong *int_key ) ;
   void (*move_forward)(zend_object_iterator *iter ) ;
   void (*rewind)(zend_object_iterator *iter ) ;
   void (*invalidate_current)(zend_object_iterator *iter ) ;
};
typedef struct _zend_object_iterator_funcs zend_object_iterator_funcs;
struct _zend_object_iterator {
   void *data ;
   zend_object_iterator_funcs *funcs ;
   ulong index ;
};
struct _zend_class_iterator_funcs {
   zend_object_iterator_funcs *funcs ;
   union _zend_function *zf_new_iterator ;
   union _zend_function *zf_valid ;
   union _zend_function *zf_current ;
   union _zend_function *zf_key ;
   union _zend_function *zf_next ;
   union _zend_function *zf_rewind ;
};
typedef struct _zend_class_iterator_funcs zend_class_iterator_funcs;
struct _zend_serialize_data;
struct _zend_serialize_data;
struct _zend_serialize_data;
struct _zend_unserialize_data;
struct _zend_unserialize_data;
struct _zend_unserialize_data;
typedef struct _zend_serialize_data zend_serialize_data;
typedef struct _zend_unserialize_data zend_unserialize_data;
struct _zend_trait_method_reference {
   char const   *method_name ;
   unsigned int mname_len ;
   zend_class_entry *ce ;
   char const   *class_name ;
   unsigned int cname_len ;
};
typedef struct _zend_trait_method_reference zend_trait_method_reference;
struct _zend_trait_precedence {
   zend_trait_method_reference *trait_method ;
   zend_class_entry **exclude_from_classes ;
   union _zend_function *function ;
};
typedef struct _zend_trait_precedence zend_trait_precedence;
struct _zend_trait_alias {
   zend_trait_method_reference *trait_method ;
   char const   *alias ;
   unsigned int alias_len ;
   zend_uint modifiers ;
   union _zend_function *function ;
};
typedef struct _zend_trait_alias zend_trait_alias;
struct __anonstruct_user_36 {
   char const   *filename ;
   zend_uint line_start ;
   zend_uint line_end ;
   char const   *doc_comment ;
   zend_uint doc_comment_len ;
};
struct _zend_function_entry;
struct _zend_function_entry;
struct _zend_module_entry;
struct _zend_module_entry;
struct __anonstruct_internal_37 {
   struct _zend_function_entry  const  *builtin_functions ;
   struct _zend_module_entry *module ;
};
union __anonunion_info_35 {
   struct __anonstruct_user_36 user ;
   struct __anonstruct_internal_37 internal ;
};
struct _zend_class_entry {
   char type ;
   char const   *name ;
   zend_uint name_length ;
   struct _zend_class_entry *parent ;
   int refcount ;
   zend_uint ce_flags ;
   HashTable function_table ;
   HashTable properties_info ;
   zval **default_properties_table ;
   zval **default_static_members_table ;
   zval **static_members_table ;
   HashTable constants_table ;
   int default_properties_count ;
   int default_static_members_count ;
   union _zend_function *constructor ;
   union _zend_function *destructor ;
   union _zend_function *clone ;
   union _zend_function *__get ;
   union _zend_function *__set ;
   union _zend_function *__unset ;
   union _zend_function *__isset ;
   union _zend_function *__call ;
   union _zend_function *__callstatic ;
   union _zend_function *__tostring ;
   union _zend_function *serialize_func ;
   union _zend_function *unserialize_func ;
   zend_class_iterator_funcs iterator_funcs ;
   zend_object_value (*create_object)(zend_class_entry *class_type ) ;
   zend_object_iterator *(*get_iterator)(zend_class_entry *ce , zval *object ,
                                         int by_ref ) ;
   int (*interface_gets_implemented)(zend_class_entry *iface ,
                                     zend_class_entry *class_type ) ;
   union _zend_function *(*get_static_method)(zend_class_entry *ce ,
                                              char *method , int method_len ) ;
   int (*serialize)(zval *object , unsigned char **buffer , zend_uint *buf_len ,
                    zend_serialize_data *data ) ;
   int (*unserialize)(zval **object , zend_class_entry *ce ,
                      unsigned char const   *buf , zend_uint buf_len ,
                      zend_unserialize_data *data ) ;
   zend_class_entry **interfaces ;
   zend_uint num_interfaces ;
   zend_class_entry **traits ;
   zend_uint num_traits ;
   zend_trait_alias **trait_aliases ;
   zend_trait_precedence **trait_precedences ;
   union __anonunion_info_35 info ;
};
union __anonunion_u_66 {
   zval *pz ;
   zend_object_handlers const   *handlers ;
};
struct _gc_root_buffer {
   struct _gc_root_buffer *prev ;
   struct _gc_root_buffer *next ;
   zend_object_handle handle ;
   union __anonunion_u_66 u ;
};
typedef struct _gc_root_buffer gc_root_buffer;
struct _zval_gc_info;
union __anonunion_u_67 {
   gc_root_buffer *buffered ;
   struct _zval_gc_info *next ;
};
struct _zval_gc_info {
   zval z ;
   union __anonunion_u_67 u ;
};
typedef struct _zval_gc_info zval_gc_info;
enum __anonenum_zend_error_handling_t_68 {
    EH_NORMAL = 0,
    EH_SUPPRESS = 1,
    EH_THROW = 2
} ;
typedef enum __anonenum_zend_error_handling_t_68 zend_error_handling_t;
struct __anonstruct_zend_error_handling_69 {
   zend_error_handling_t handling ;
   zend_class_entry *exception ;
   zval *user_handler ;
};
typedef struct __anonstruct_zend_error_handling_69 zend_error_handling;
struct _zend_op_array;
struct _zend_op_array;
typedef struct _zend_op_array zend_op_array;
struct _zend_op;
struct _zend_op;
typedef struct _zend_op zend_op;
struct _zend_literal {
   zval constant ;
   zend_ulong hash_value ;
   zend_uint cache_slot ;
};
typedef struct _zend_literal zend_literal;
union _znode_op {
   zend_uint constant ;
   zend_uint var ;
   zend_uint num ;
   zend_ulong hash ;
   zend_uint opline_num ;
   zend_op *jmp_addr ;
   zval *zv ;
   zend_literal *literal ;
   void *ptr ;
};
typedef union _znode_op znode_op;
struct _zend_execute_data;
struct _zend_execute_data;
typedef struct _zend_execute_data zend_execute_data;
struct _zend_op {
   int (*handler)(zend_execute_data *execute_data ) ;
   znode_op op1 ;
   znode_op op2 ;
   znode_op result ;
   ulong extended_value ;
   uint lineno ;
   zend_uchar opcode ;
   zend_uchar op1_type ;
   zend_uchar op2_type ;
   zend_uchar result_type ;
};
struct _zend_brk_cont_element {
   int start ;
   int cont ;
   int brk ;
   int parent ;
};
typedef struct _zend_brk_cont_element zend_brk_cont_element;
struct _zend_try_catch_element {
   zend_uint try_op ;
   zend_uint catch_op ;
};
typedef struct _zend_try_catch_element zend_try_catch_element;
struct _zend_property_info {
   zend_uint flags ;
   char const   *name ;
   int name_length ;
   ulong h ;
   int offset ;
   char const   *doc_comment ;
   int doc_comment_len ;
   zend_class_entry *ce ;
};
typedef struct _zend_property_info zend_property_info;
struct _zend_arg_info {
   char const   *name ;
   zend_uint name_len ;
   char const   *class_name ;
   zend_uint class_name_len ;
   zend_uchar type_hint ;
   zend_bool allow_null ;
   zend_bool pass_by_reference ;
};
typedef struct _zend_arg_info zend_arg_info;
struct _zend_compiled_variable {
   char const   *name ;
   int name_len ;
   ulong hash_value ;
};
typedef struct _zend_compiled_variable zend_compiled_variable;
struct _zend_op_array {
   zend_uchar type ;
   char const   *function_name ;
   zend_class_entry *scope ;
   zend_uint fn_flags ;
   union _zend_function *prototype ;
   zend_uint num_args ;
   zend_uint required_num_args ;
   zend_arg_info *arg_info ;
   zend_uint *refcount ;
   zend_op *opcodes ;
   zend_uint last ;
   zend_compiled_variable *vars ;
   int last_var ;
   zend_uint T ;
   zend_brk_cont_element *brk_cont_array ;
   int last_brk_cont ;
   zend_try_catch_element *try_catch_array ;
   int last_try_catch ;
   HashTable *static_variables ;
   zend_uint this_var ;
   char const   *filename ;
   zend_uint line_start ;
   zend_uint line_end ;
   char const   *doc_comment ;
   zend_uint doc_comment_len ;
   zend_uint early_binding ;
   zend_literal *literals ;
   int last_literal ;
   void **run_time_cache ;
   int last_cache_slot ;
   void *reserved[4] ;
};
struct _zend_internal_function {
   zend_uchar type ;
   char const   *function_name ;
   zend_class_entry *scope ;
   zend_uint fn_flags ;
   union _zend_function *prototype ;
   zend_uint num_args ;
   zend_uint required_num_args ;
   zend_arg_info *arg_info ;
   void (*handler)(int ht , zval *return_value , zval **return_value_ptr ,
                   zval *this_ptr , int return_value_used ) ;
   struct _zend_module_entry *module ;
};
typedef struct _zend_internal_function zend_internal_function;
struct __anonstruct_common_71 {
   zend_uchar type ;
   char const   *function_name ;
   zend_class_entry *scope ;
   zend_uint fn_flags ;
   union _zend_function *prototype ;
   zend_uint num_args ;
   zend_uint required_num_args ;
   zend_arg_info *arg_info ;
};
union _zend_function {
   zend_uchar type ;
   struct __anonstruct_common_71 common ;
   zend_op_array op_array ;
   zend_internal_function internal_function ;
};
typedef union _zend_function zend_function;
struct _zend_function_state {
   zend_function *function ;
   void **arguments ;
};
typedef struct _zend_function_state zend_function_state;
union _temp_variable;
union _temp_variable;
union _temp_variable;
struct _zend_execute_data {
   struct _zend_op *opline ;
   zend_function_state function_state ;
   zend_function *fbc ;
   zend_class_entry *called_scope ;
   zend_op_array *op_array ;
   zval *object ;
   union _temp_variable *Ts ;
   zval ***CVs ;
   HashTable *symbol_table ;
   struct _zend_execute_data *prev_execute_data ;
   zval *old_error_reporting ;
   zend_bool nested ;
   zval **original_return_value ;
   zend_class_entry *current_scope ;
   zend_class_entry *current_called_scope ;
   zval *current_this ;
   zval *current_object ;
};
typedef long __jmp_buf[8];
struct __jmp_buf_tag {
   __jmp_buf __jmpbuf ;
   int __mask_was_saved ;
   __sigset_t __saved_mask ;
};
typedef struct __jmp_buf_tag jmp_buf[1];
struct _zend_executor_globals;
struct _zend_executor_globals;
typedef struct _zend_executor_globals zend_executor_globals;
struct _zend_stack {
   int top ;
   int max ;
   void **elements ;
};
typedef struct _zend_stack zend_stack;
struct _zend_ptr_stack {
   int top ;
   int max ;
   void **elements ;
   void **top_element ;
   zend_bool persistent ;
};
typedef struct _zend_ptr_stack zend_ptr_stack;
struct _store_object {
   void *object ;
   void (*dtor)(void *object , zend_object_handle handle ) ;
   void (*free_storage)(void *object ) ;
   void (*clone)(void *object , void **object_clone ) ;
   zend_object_handlers const   *handlers ;
   zend_uint refcount ;
   gc_root_buffer *buffered ;
};
struct __anonstruct_free_list_72 {
   int next ;
};
union _store_bucket {
   struct _store_object obj ;
   struct __anonstruct_free_list_72 free_list ;
};
struct _zend_object_store_bucket {
   zend_bool destructor_called ;
   zend_bool valid ;
   union _store_bucket bucket ;
};
typedef struct _zend_object_store_bucket zend_object_store_bucket;
struct _zend_objects_store {
   zend_object_store_bucket *object_buckets ;
   zend_uint top ;
   zend_uint size ;
   int free_list_head ;
};
typedef struct _zend_objects_store zend_objects_store;
typedef unsigned short fpu_control_t;
struct _zend_vm_stack;
struct _zend_vm_stack;
typedef struct _zend_vm_stack *zend_vm_stack;
struct _zend_ini_entry;
struct _zend_ini_entry;
typedef struct _zend_ini_entry zend_ini_entry;
struct _zend_executor_globals {
   zval **return_value_ptr_ptr ;
   zval uninitialized_zval ;
   zval *uninitialized_zval_ptr ;
   zval error_zval ;
   zval *error_zval_ptr ;
   zend_ptr_stack arg_types_stack ;
   HashTable *symtable_cache[32] ;
   HashTable **symtable_cache_limit ;
   HashTable **symtable_cache_ptr ;
   zend_op **opline_ptr ;
   HashTable *active_symbol_table ;
   HashTable symbol_table ;
   HashTable included_files ;
   jmp_buf *bailout ;
   int error_reporting ;
   int orig_error_reporting ;
   int exit_status ;
   zend_op_array *active_op_array ;
   HashTable *function_table ;
   HashTable *class_table ;
   HashTable *zend_constants ;
   zend_class_entry *scope ;
   zend_class_entry *called_scope ;
   zval *This ;
   long precision ;
   int ticks_count ;
   zend_bool in_execution ;
   HashTable *in_autoload ;
   zend_function *autoload_func ;
   zend_bool full_tables_cleanup ;
   zend_bool no_extensions ;
   HashTable regular_list ;
   HashTable persistent_list ;
   zend_vm_stack argument_stack ;
   int user_error_handler_error_reporting ;
   zval *user_error_handler ;
   zval *user_exception_handler ;
   zend_stack user_error_handlers_error_reporting ;
   zend_ptr_stack user_error_handlers ;
   zend_ptr_stack user_exception_handlers ;
   zend_error_handling_t error_handling ;
   zend_class_entry *exception_class ;
   int timeout_seconds ;
   int lambda_count ;
   HashTable *ini_directives ;
   HashTable *modified_ini_directives ;
   zend_ini_entry *error_reporting_ini_entry ;
   zend_objects_store objects_store ;
   zval *exception ;
   zval *prev_exception ;
   zend_op *opline_before_exception ;
   zend_op exception_op[3] ;
   struct _zend_execute_data *current_execute_data ;
   struct _zend_module_entry *current_module ;
   zend_property_info std_property_info ;
   zend_bool active ;
   zend_op *start_op ;
   void *saved_fpu_cw_ptr ;
   fpu_control_t saved_fpu_cw ;
   void *reserved[4] ;
};
struct _zend_ini_entry;
typedef struct _zend_module_entry zend_module_entry;
struct _zend_module_dep;
struct _zend_module_dep;
struct _zend_module_entry {
   unsigned short size ;
   unsigned int zend_api ;
   unsigned char zend_debug ;
   unsigned char zts ;
   struct _zend_ini_entry  const  *ini_entry ;
   struct _zend_module_dep  const  *deps ;
   char const   *name ;
   struct _zend_function_entry  const  *functions ;
   int (*module_startup_func)(int type , int module_number ) ;
   int (*module_shutdown_func)(int type , int module_number ) ;
   int (*request_startup_func)(int type , int module_number ) ;
   int (*request_shutdown_func)(int type , int module_number ) ;
   void (*info_func)(zend_module_entry *zend_module ) ;
   char const   *version ;
   size_t globals_size ;
   void *globals_ptr ;
   void (*globals_ctor)(void *global ) ;
   void (*globals_dtor)(void *global ) ;
   int (*post_deactivate_func)(void) ;
   int module_started ;
   unsigned char type ;
   void *handle ;
   int module_number ;
   char const   *build_id ;
};
struct _zend_module_dep {
   char const   *name ;
   char const   *rel ;
   char const   *version ;
   unsigned char type ;
};
struct __anonstruct_var_73 {
   zval **ptr_ptr ;
   zval *ptr ;
   zend_bool fcall_returned_reference ;
};
struct __anonstruct_str_offset_74 {
   zval **ptr_ptr ;
   zval *str ;
   zend_uint offset ;
};
struct __anonstruct_fe_75 {
   zval **ptr_ptr ;
   zval *ptr ;
   HashPointer fe_pos ;
};
union _temp_variable {
   zval tmp_var ;
   struct __anonstruct_var_73 var ;
   struct __anonstruct_str_offset_74 str_offset ;
   struct __anonstruct_fe_75 fe ;
   zend_class_entry *class_entry ;
};
struct _zend_vm_stack {
   void **top ;
   void **end ;
   zend_vm_stack prev ;
};
struct _zend_function_entry {
   char const   *fname ;
   void (*handler)(int ht , zval *return_value , zval **return_value_ptr ,
                   zval *this_ptr , int return_value_used ) ;
   struct _zend_arg_info  const  *arg_info ;
   zend_uint num_args ;
   zend_uint flags ;
};
typedef struct _zend_function_entry zend_function_entry;
struct _zend_fcall_info {
   size_t size ;
   HashTable *function_table ;
   zval *function_name ;
   HashTable *symbol_table ;
   zval **retval_ptr_ptr ;
   zend_uint param_count ;
   zval ***params ;
   zval *object_ptr ;
   zend_bool no_separation ;
};
typedef struct _zend_fcall_info zend_fcall_info;
struct _zend_fcall_info_cache {
   zend_bool initialized ;
   zend_function *function_handler ;
   zend_class_entry *calling_scope ;
   zend_class_entry *called_scope ;
   zval *object_ptr ;
};
typedef struct _zend_fcall_info_cache zend_fcall_info_cache;
typedef __socklen_t socklen_t;
struct stat {
   __dev_t st_dev ;
   __ino_t st_ino ;
   __nlink_t st_nlink ;
   __mode_t st_mode ;
   __uid_t st_uid ;
   __gid_t st_gid ;
   int __pad0 ;
   __dev_t st_rdev ;
   __off_t st_size ;
   __blksize_t st_blksize ;
   __blkcnt_t st_blocks ;
   struct timespec st_atim ;
   struct timespec st_mtim ;
   struct timespec st_ctim ;
   __syscall_slong_t __glibc_reserved[3] ;
};
struct stat64 {
   __dev_t st_dev ;
   __ino64_t st_ino ;
   __nlink_t st_nlink ;
   __mode_t st_mode ;
   __uid_t st_uid ;
   __gid_t st_gid ;
   int __pad0 ;
   __dev_t st_rdev ;
   __off_t st_size ;
   __blksize_t st_blksize ;
   __blkcnt64_t st_blocks ;
   struct timespec st_atim ;
   struct timespec st_mtim ;
   struct timespec st_ctim ;
   __syscall_slong_t __glibc_reserved[3] ;
};
struct _php_stream;
struct _php_stream;
typedef struct _php_stream php_stream;
struct _php_stream_wrapper;
struct _php_stream_wrapper;
typedef struct _php_stream_wrapper php_stream_wrapper;
struct _php_stream_context;
struct _php_stream_context;
typedef struct _php_stream_context php_stream_context;
struct _php_stream_filter;
struct _php_stream_filter;
typedef struct _php_stream_filter php_stream_filter;
struct _php_stream_notifier;
struct _php_stream_notifier;
typedef struct _php_stream_notifier php_stream_notifier;
struct _php_stream_notifier {
   void (*func)(php_stream_context *context , int notifycode , int severity ,
                char *xmsg , int xcode , size_t bytes_sofar , size_t bytes_max ,
                void *ptr ) ;
   void (*dtor)(php_stream_notifier *notifier ) ;
   void *ptr ;
   int mask ;
   size_t progress ;
   size_t progress_max ;
};
struct _php_stream_context {
   php_stream_notifier *notifier ;
   zval *options ;
   zval *links ;
   int rsrc_id ;
};
struct _php_stream_bucket;
struct _php_stream_bucket;
typedef struct _php_stream_bucket php_stream_bucket;
struct _php_stream_bucket_brigade;
struct _php_stream_bucket_brigade;
typedef struct _php_stream_bucket_brigade php_stream_bucket_brigade;
struct _php_stream_bucket {
   php_stream_bucket *next ;
   php_stream_bucket *prev ;
   php_stream_bucket_brigade *brigade ;
   char *buf ;
   size_t buflen ;
   int own_buf ;
   int is_persistent ;
   int refcount ;
};
struct _php_stream_bucket_brigade {
   php_stream_bucket *head ;
   php_stream_bucket *tail ;
};
enum __anonenum_php_stream_filter_status_t_83 {
    PSFS_ERR_FATAL = 0,
    PSFS_FEED_ME = 1,
    PSFS_PASS_ON = 2
} ;
typedef enum __anonenum_php_stream_filter_status_t_83 php_stream_filter_status_t;
struct _php_stream_filter_ops {
   php_stream_filter_status_t (*filter)(php_stream *stream ,
                                        php_stream_filter *thisfilter ,
                                        php_stream_bucket_brigade *buckets_in ,
                                        php_stream_bucket_brigade *buckets_out ,
                                        size_t *bytes_consumed , int flags ) ;
   void (*dtor)(php_stream_filter *thisfilter ) ;
   char const   *label ;
};
typedef struct _php_stream_filter_ops php_stream_filter_ops;
struct _php_stream_filter_chain {
   php_stream_filter *head ;
   php_stream_filter *tail ;
   php_stream *stream ;
};
typedef struct _php_stream_filter_chain php_stream_filter_chain;
struct _php_stream_filter {
   php_stream_filter_ops *fops ;
   void *abstract ;
   php_stream_filter *next ;
   php_stream_filter *prev ;
   int is_persistent ;
   php_stream_filter_chain *chain ;
   php_stream_bucket_brigade buffer ;
   int rsrc_id ;
};
struct _php_stream_statbuf {
   struct stat sb ;
};
typedef struct _php_stream_statbuf php_stream_statbuf;
struct _php_stream_dirent {
   char d_name[4096] ;
};
typedef struct _php_stream_dirent php_stream_dirent;
struct _php_stream_ops {
   size_t (*write)(php_stream *stream , char const   *buf , size_t count ) ;
   size_t (*read)(php_stream *stream , char *buf , size_t count ) ;
   int (*close)(php_stream *stream , int close_handle ) ;
   int (*flush)(php_stream *stream ) ;
   char const   *label ;
   int (*seek)(php_stream *stream , off_t offset , int whence ,
               off_t *newoffset ) ;
   int (*cast)(php_stream *stream , int castas , void **ret ) ;
   int (*stat)(php_stream *stream , php_stream_statbuf *ssb ) ;
   int (*set_option)(php_stream *stream , int option , int value ,
                     void *ptrparam ) ;
};
typedef struct _php_stream_ops php_stream_ops;
struct _php_stream_wrapper_ops {
   php_stream *(*stream_opener)(php_stream_wrapper *wrapper , char *filename ,
                                char *mode , int options , char **opened_path ,
                                php_stream_context *context ) ;
   int (*stream_closer)(php_stream_wrapper *wrapper , php_stream *stream ) ;
   int (*stream_stat)(php_stream_wrapper *wrapper , php_stream *stream ,
                      php_stream_statbuf *ssb ) ;
   int (*url_stat)(php_stream_wrapper *wrapper , char *url , int flags ,
                   php_stream_statbuf *ssb , php_stream_context *context ) ;
   php_stream *(*dir_opener)(php_stream_wrapper *wrapper , char *filename ,
                             char *mode , int options , char **opened_path ,
                             php_stream_context *context ) ;
   char const   *label ;
   int (*unlink)(php_stream_wrapper *wrapper , char *url , int options ,
                 php_stream_context *context ) ;
   int (*rename)(php_stream_wrapper *wrapper , char *url_from , char *url_to ,
                 int options , php_stream_context *context ) ;
   int (*stream_mkdir)(php_stream_wrapper *wrapper , char *url , int mode ,
                       int options , php_stream_context *context ) ;
   int (*stream_rmdir)(php_stream_wrapper *wrapper , char *url , int options ,
                       php_stream_context *context ) ;
   int (*stream_metadata)(php_stream_wrapper *wrapper , char *url ,
                          int options , void *value ,
                          php_stream_context *context ) ;
};
typedef struct _php_stream_wrapper_ops php_stream_wrapper_ops;
struct _php_stream_wrapper {
   php_stream_wrapper_ops *wops ;
   void *abstract ;
   int is_url ;
   int err_count ;
   char **err_stack ;
};
struct _php_stream {
   php_stream_ops *ops ;
   void *abstract ;
   php_stream_filter_chain readfilters ;
   php_stream_filter_chain writefilters ;
   php_stream_wrapper *wrapper ;
   void *wrapperthis ;
   zval *wrapperdata ;
   int fgetss_state ;
   int is_persistent ;
   char mode[16] ;
   int rsrc_id ;
   int in_free ;
   int fclose_stdiocast ;
   FILE *stdiocast ;
   char *orig_path ;
   php_stream_context *context ;
   int flags ;
   off_t position ;
   unsigned char *readbuf ;
   size_t readbuflen ;
   off_t readpos ;
   off_t writepos ;
   size_t chunk_size ;
   int eof ;
   struct _php_stream *enclosing_stream ;
};
struct iovec {
   void *iov_base ;
   size_t iov_len ;
};
typedef unsigned short sa_family_t;
struct sockaddr {
   sa_family_t sa_family ;
   char sa_data[14] ;
};
struct msghdr {
   void *msg_name ;
   socklen_t msg_namelen ;
   struct iovec *msg_iov ;
   size_t msg_iovlen ;
   void *msg_control ;
   size_t msg_controllen ;
   int msg_flags ;
};
struct cmsghdr {
   size_t cmsg_len ;
   int cmsg_level ;
   int cmsg_type ;
   unsigned char __cmsg_data[] ;
};
struct sockaddr_at;
struct sockaddr_at;
struct sockaddr_ax25;
struct sockaddr_ax25;
struct sockaddr_dl;
struct sockaddr_dl;
struct sockaddr_eon;
struct sockaddr_eon;
struct sockaddr_in;
struct sockaddr_in;
struct sockaddr_in6;
struct sockaddr_in6;
struct sockaddr_inarp;
struct sockaddr_inarp;
struct sockaddr_ipx;
struct sockaddr_ipx;
struct sockaddr_iso;
struct sockaddr_iso;
struct sockaddr_ns;
struct sockaddr_ns;
struct sockaddr_un;
struct sockaddr_un;
struct sockaddr_x25;
struct sockaddr_x25;
union __anonunion___SOCKADDR_ARG_87 {
   struct sockaddr * __restrict  __sockaddr__ ;
   struct sockaddr_at * __restrict  __sockaddr_at__ ;
   struct sockaddr_ax25 * __restrict  __sockaddr_ax25__ ;
   struct sockaddr_dl * __restrict  __sockaddr_dl__ ;
   struct sockaddr_eon * __restrict  __sockaddr_eon__ ;
   struct sockaddr_in * __restrict  __sockaddr_in__ ;
   struct sockaddr_in6 * __restrict  __sockaddr_in6__ ;
   struct sockaddr_inarp * __restrict  __sockaddr_inarp__ ;
   struct sockaddr_ipx * __restrict  __sockaddr_ipx__ ;
   struct sockaddr_iso * __restrict  __sockaddr_iso__ ;
   struct sockaddr_ns * __restrict  __sockaddr_ns__ ;
   struct sockaddr_un * __restrict  __sockaddr_un__ ;
   struct sockaddr_x25 * __restrict  __sockaddr_x25__ ;
};
typedef union __anonunion___SOCKADDR_ARG_87  __attribute__((__transparent_union__)) __SOCKADDR_ARG;
struct _zend_ini_entry {
   int module_number ;
   int modifiable ;
   char *name ;
   uint name_length ;
   int (*on_modify)(zend_ini_entry *entry , char *new_value ,
                    uint new_value_length , void *mh_arg1 , void *mh_arg2 ,
                    void *mh_arg3 , int stage ) ;
   void *mh_arg1 ;
   void *mh_arg2 ;
   void *mh_arg3 ;
   char *value ;
   uint value_length ;
   char *orig_value ;
   uint orig_value_length ;
   int orig_modifiable ;
   int modified ;
   void (*displayer)(zend_ini_entry *ini_entry , int type ) ;
};
struct __anonstruct_php_file_globals_101 {
   int pclose_ret ;
   size_t def_chunk_size ;
   long auto_detect_line_endings ;
   long default_socket_timeout ;
   char *user_agent ;
   char *from_address ;
   char *user_stream_current_filename ;
   php_stream_context *default_context ;
   HashTable *stream_wrappers ;
   HashTable *stream_filters ;
};
typedef struct __anonstruct_php_file_globals_101 php_file_globals;
enum __anonenum_SPL_FS_OBJ_TYPE_115 {
    SPL_FS_INFO = 0,
    SPL_FS_DIR = 1,
    SPL_FS_FILE = 2
} ;
typedef enum __anonenum_SPL_FS_OBJ_TYPE_115 SPL_FS_OBJ_TYPE;
struct _spl_filesystem_object;
struct _spl_filesystem_object;
typedef struct _spl_filesystem_object spl_filesystem_object;
struct _spl_other_handler {
   void (*dtor)(spl_filesystem_object *object ) ;
   void (*clone)(spl_filesystem_object *src , spl_filesystem_object *dst ) ;
};
typedef struct _spl_other_handler spl_other_handler;
struct __anonstruct_spl_filesystem_iterator_116 {
   zend_object_iterator intern ;
   zval *current ;
   spl_filesystem_object *object ;
};
typedef struct __anonstruct_spl_filesystem_iterator_116 spl_filesystem_iterator;
struct __anonstruct_dir_118 {
   php_stream *dirp ;
   php_stream_dirent entry ;
   char *sub_path ;
   int sub_path_len ;
   int index ;
   int is_recursive ;
   zend_function *func_rewind ;
   zend_function *func_next ;
   zend_function *func_valid ;
};
struct __anonstruct_file_119 {
   php_stream *stream ;
   php_stream_context *context ;
   zval *zcontext ;
   char *open_mode ;
   int open_mode_len ;
   zval *current_zval ;
   char *current_line ;
   size_t current_line_len ;
   size_t max_line_len ;
   long current_line_num ;
   zval zresource ;
   zend_function *func_getCurr ;
   char delimiter ;
   char enclosure ;
   char escape ;
};
union __anonunion_u_117 {
   struct __anonstruct_dir_118 dir ;
   struct __anonstruct_file_119 file ;
};
struct _spl_filesystem_object {
   zend_object std ;
   void *oth ;
   spl_other_handler *oth_handler ;
   char *_path ;
   int _path_len ;
   char *orig_path ;
   char *file_name ;
   int file_name_len ;
   SPL_FS_OBJ_TYPE type ;
   long flags ;
   zend_class_entry *file_class ;
   zend_class_entry *info_class ;
   union __anonunion_u_117 u ;
   spl_filesystem_iterator it ;
};
typedef unsigned int wint_t;
typedef __mbstate_t mbstate_t;
typedef int php_stat_len;
__inline extern  __attribute__((__nothrow__)) double __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atof)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atoi)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atol)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) long long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atoll)(char const   *__nptr )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) double ( __attribute__((__nonnull__(1),
__leaf__)) strtod)(char const   * __restrict  __nptr ,
                   char ** __restrict  __endptr ) ;
extern  __attribute__((__nothrow__)) long ( __attribute__((__nonnull__(1),
__leaf__)) strtol)(char const   * __restrict  __nptr ,
                   char ** __restrict  __endptr , int __base ) ;
extern  __attribute__((__nothrow__)) long long ( __attribute__((__nonnull__(1),
__leaf__)) strtoll)(char const   * __restrict  __nptr ,
                    char ** __restrict  __endptr , int __base ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atoi)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) atoi)(char const   *__nptr ) 
{ 
  long tmp ;

  {
  tmp = strtol((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)), 10);
  return ((int __attribute__((__gnu_inline__))  )((int )tmp));
}
}
__inline extern  __attribute__((__nothrow__)) long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atol)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) atol)(char const   *__nptr ) 
{ 
  long tmp ;

  {
  tmp = strtol((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)), 10);
  return ((long __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) long long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atoll)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern long long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) atoll)(char const   *__nptr ) 
{ 
  long long tmp ;

  {
  tmp = strtoll((char const   */* __restrict  */)__nptr,
                (char **/* __restrict  */)((char **)((void *)0)), 10);
  return ((long long __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_major)(unsigned long long __dev )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_minor)(unsigned long long __dev )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) unsigned long long __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_makedev)(unsigned int __major ,
                                                                                                                                               unsigned int __minor )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_major)(unsigned long long __dev )  __attribute__((__const__)) ;
__inline extern unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_major)(unsigned long long __dev ) 
{ 


  {
  return ((unsigned int __attribute__((__gnu_inline__))  )(((__dev >> 8) & 4095ULL) | (unsigned long long )((unsigned int )(__dev >> 32) & 4294963200U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_minor)(unsigned long long __dev )  __attribute__((__const__)) ;
__inline extern unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_minor)(unsigned long long __dev ) 
{ 


  {
  return ((unsigned int __attribute__((__gnu_inline__))  )((__dev & 255ULL) | (unsigned long long )((unsigned int )(__dev >> 12) & 4294967040U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned long long __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_makedev)(unsigned int __major ,
                                                                                                                                               unsigned int __minor )  __attribute__((__const__)) ;
__inline extern unsigned long long __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_makedev)(unsigned int __major ,
                                                                                                                 unsigned int __minor ) 
{ 


  {
  return ((unsigned long long __attribute__((__gnu_inline__))  )(((unsigned long long )((__minor & 255U) | ((__major & 4095U) << 8)) | ((unsigned long long )(__minor & 4294967040U) << 12)) | ((unsigned long long )(__major & 4294963200U) << 32)));
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) realpath)(char const   * __restrict  __name ,
                              char * __restrict  __resolved ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__nonnull__(1,2,5))) bsearch)(void const   *__key , void const   *__base ,
                              size_t __nmemb , size_t __size ,
                              int (*__compar)(void const   * , void const   * ) ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__nonnull__(1,2,5))) bsearch)(void const   *__key , void const   *__base ,
                              size_t __nmemb , size_t __size ,
                              int (*__compar)(void const   * , void const   * ) ) 
{ 
  size_t __l ;
  size_t __u ;
  size_t __idx ;
  void const   *__p ;
  int __comparison ;

  {
  __l = (size_t )0;
  __u = __nmemb;
  while (__l < __u) {
    __idx = (__l + __u) / 2UL;
    __p = (void const   *)((void *)((char const   *)__base + __idx * __size));
    __comparison = (*__compar)(__key, __p);
    if (__comparison < 0) {
      __u = __idx;
    } else
    if (__comparison > 0) {
      __l = __idx + 1UL;
    } else {
      return ((void __attribute__((__gnu_inline__))  *)((void *)__p));
    }
  }
  return ((void __attribute__((__gnu_inline__))  *)((void *)0));
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) wctomb)(char *__s , wchar_t __wchar ) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) mbstowcs)(wchar_t * __restrict  __dst ,
                                              char const   * __restrict  __src ,
                                              size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcstombs)(char * __restrict  __dst ,
                              wchar_t const   * __restrict  __src ,
                              size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__, __artificial__,
__always_inline__)) ptsname_r)(int __fd , char *__buf , size_t __buflen ) ;
__inline extern  __attribute__((__nothrow__)) double __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atof)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern double __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) atof)(char const   *__nptr ) 
{ 
  double tmp ;

  {
  tmp = strtod((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)));
  return ((double __attribute__((__gnu_inline__))  )tmp);
}
}
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__leaf__)) __realpath_chk)(char const   * __restrict  __name ,
                           char * __restrict  __resolved , size_t __resolvedlen ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__leaf__)) __realpath_alias)(char const   * __restrict  __name ,
                             char * __restrict  __resolved )  __asm__("realpath")  ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) realpath)(char const   * __restrict  __name ,
                              char * __restrict  __resolved ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) realpath)(char const   * __restrict  __name ,
                              char * __restrict  __resolved ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__resolved, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__resolved, 1);
    tmp___0 = __realpath_chk(__name, __resolved, tmp);
    return ((char __attribute__((__gnu_inline__))  *)tmp___0);
  } else {

  }
  tmp___2 = __realpath_alias(__name, __resolved);
  return ((char __attribute__((__gnu_inline__))  *)tmp___2);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ptsname_r_chk)(int __fd , char *__buf , size_t __buflen ,
                            size_t __nreal ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ptsname_r_alias)(int __fd , char *__buf , size_t __buflen )  __asm__("ptsname_r")  ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ptsname_r_chk_warn)(int __fd , char *__buf , size_t __buflen ,
                                 size_t __nreal )  __asm__("__ptsname_r_chk") __attribute__((__warning__("ptsname_r called with buflen bigger than size of buf"))) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__, __artificial__,
__always_inline__)) ptsname_r)(int __fd , char *__buf , size_t __buflen ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__, __artificial__,
__always_inline__)) ptsname_r)(int __fd , char *__buf , size_t __buflen ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __ptsname_r_chk(__fd, __buf, __buflen, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__buflen > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __ptsname_r_chk_warn(__fd, __buf, __buflen, tmp___1);
      return ((int __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __ptsname_r_alias(__fd, __buf, __buflen);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __wctomb_chk)(char *__s , wchar_t __wchar , size_t __buflen ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __wctomb_alias)(char *__s , wchar_t __wchar )  __asm__("wctomb")  ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) wctomb)(char *__s , wchar_t __wchar ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) wctomb)(char *__s , wchar_t __wchar ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  unsigned long tmp___2 ;
  int tmp___3 ;

  {
  tmp___1 = __builtin_object_size((void *)__s, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp___2 = __builtin_object_size((void *)__s, 1);
    if (16UL > tmp___2) {
      tmp = __builtin_object_size((void *)__s, 1);
      tmp___0 = __wctomb_chk(__s, __wchar, tmp);
      return ((int __attribute__((__gnu_inline__))  )tmp___0);
    } else {

    }
  } else {

  }
  tmp___3 = __wctomb_alias(__s, __wchar);
  return ((int __attribute__((__gnu_inline__))  )tmp___3);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbstowcs_chk)(wchar_t * __restrict  __dst ,
                                                                                        char const   * __restrict  __src ,
                                                                                        size_t __len ,
                                                                                        size_t __dstlen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbstowcs_alias)(wchar_t * __restrict  __dst ,
                                                                                          char const   * __restrict  __src ,
                                                                                          size_t __len )  __asm__("mbstowcs")  ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbstowcs_chk_warn)(wchar_t * __restrict  __dst ,
                                                                                             char const   * __restrict  __src ,
                                                                                             size_t __len ,
                                                                                             size_t __dstlen )  __asm__("__mbstowcs_chk") __attribute__((__warning__("mbstowcs called with dst buffer smaller than len * sizeof (wchar_t)"))) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) mbstowcs)(wchar_t * __restrict  __dst ,
                                              char const   * __restrict  __src ,
                                              size_t __len ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) mbstowcs)(wchar_t * __restrict  __dst ,
                                              char const   * __restrict  __src ,
                                              size_t __len ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__dst, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dst, 1);
    tmp___0 = __mbstowcs_chk(__dst, __src, __len, tmp / sizeof(wchar_t ));
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__dst, 1);
    if (__len > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__dst, 1);
      tmp___2 = __mbstowcs_chk_warn(__dst, __src, __len,
                                    tmp___1 / sizeof(wchar_t ));
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __mbstowcs_alias(__dst, __src, __len);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcstombs_chk)(char * __restrict  __dst ,
                                                                                        wchar_t const   * __restrict  __src ,
                                                                                        size_t __len ,
                                                                                        size_t __dstlen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcstombs_alias)(char * __restrict  __dst ,
                                                                                          wchar_t const   * __restrict  __src ,
                                                                                          size_t __len )  __asm__("wcstombs")  ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcstombs_chk_warn)(char * __restrict  __dst ,
                                                                                             wchar_t const   * __restrict  __src ,
                                                                                             size_t __len ,
                                                                                             size_t __dstlen )  __asm__("__wcstombs_chk") __attribute__((__warning__("wcstombs called with dst buffer smaller than len"))) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcstombs)(char * __restrict  __dst ,
                              wchar_t const   * __restrict  __src ,
                              size_t __len ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcstombs)(char * __restrict  __dst ,
                              wchar_t const   * __restrict  __src ,
                              size_t __len ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__dst, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dst, 1);
    tmp___0 = __wcstombs_chk(__dst, __src, __len, tmp);
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__dst, 1);
    if (__len > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__dst, 1);
      tmp___2 = __wcstombs_chk_warn(__dst, __src, __len, tmp___1);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wcstombs_alias(__dst, __src, __len);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memcpy)(void * __restrict  __dest ,
                            void const   * __restrict  __src , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memmove)(void *__dest , void const   *__src , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1),
__leaf__, __artificial__, __always_inline__)) memset)(void *__dest , int __ch ,
                                                      size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcat)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncat)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1),
__leaf__)) strrchr)(char const   *__s , int __c )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1,2),
__leaf__)) strstr)(char const   *__haystack , char const   *__needle )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) mempcpy)(void * __restrict  __dest ,
                             void const   * __restrict  __src , size_t __len ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__nonnull__(1),
__leaf__)) strlen)(char const   *__s )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__leaf__)) strerror)(int __errnum ) ;
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) bcopy)(void const   *__src , void *__dest , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) bzero)(void *__dest , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __n ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c1(char const   *__s ,
                                                                     int __reject ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c1(char const   *__s ,
                                                                     int __reject ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if ((int const   )*(__s + __result) != 0) {
      if (! ((int const   )*(__s + __result) != (int const   )__reject)) {
        break;
      } else {

      }
    } else {
      break;
    }
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c2(char const   *__s ,
                                                                     int __reject1 ,
                                                                     int __reject2 ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c2(char const   *__s ,
                                                                     int __reject1 ,
                                                                     int __reject2 ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if ((int const   )*(__s + __result) != 0) {
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        if (! ((int const   )*(__s + __result) != (int const   )__reject2)) {
          break;
        } else {

        }
      } else {
        break;
      }
    } else {
      break;
    }
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c3(char const   *__s ,
                                                                     int __reject1 ,
                                                                     int __reject2 ,
                                                                     int __reject3 ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c3(char const   *__s ,
                                                                     int __reject1 ,
                                                                     int __reject2 ,
                                                                     int __reject3 ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if ((int const   )*(__s + __result) != 0) {
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          if (! ((int const   )*(__s + __result) != (int const   )__reject3)) {
            break;
          } else {

          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c1(char const   *__s ,
                                                                    int __accept ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c1(char const   *__s ,
                                                                    int __accept ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while ((int const   )*(__s + __result) == (int const   )__accept) {
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c2(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c2(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if (! ((int const   )*(__s + __result) == (int const   )__accept1)) {
      if (! ((int const   )*(__s + __result) == (int const   )__accept2)) {
        break;
      } else {

      }
    } else {

    }
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c3(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ,
                                                                    int __accept3 ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c3(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ,
                                                                    int __accept3 ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if (! ((int const   )*(__s + __result) == (int const   )__accept1)) {
      if (! ((int const   )*(__s + __result) == (int const   )__accept2)) {
        if (! ((int const   )*(__s + __result) == (int const   )__accept3)) {
          break;
        } else {

        }
      } else {

      }
    } else {

    }
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strpbrk_c2(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strpbrk_c2(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ) 
{ 
  char *tmp ;

  {
  while (1) {
    if ((int const   )*__s != 0) {
      if ((int const   )*__s != (int const   )__accept1) {
        if (! ((int const   )*__s != (int const   )__accept2)) {
          break;
        } else {

        }
      } else {
        break;
      }
    } else {
      break;
    }
    __s ++;
  }
  if ((int const   )*__s == 0) {
    tmp = (char *)((void *)0);
  } else {
    tmp = (char *)((size_t )__s);
  }
  return ((char __attribute__((__gnu_inline__))  *)tmp);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strpbrk_c3(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ,
                                                                    int __accept3 ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strpbrk_c3(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ,
                                                                    int __accept3 ) 
{ 
  char *tmp ;

  {
  while (1) {
    if ((int const   )*__s != 0) {
      if ((int const   )*__s != (int const   )__accept1) {
        if ((int const   )*__s != (int const   )__accept2) {
          if (! ((int const   )*__s != (int const   )__accept3)) {
            break;
          } else {

          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    __s ++;
  }
  if ((int const   )*__s == 0) {
    tmp = (char *)((void *)0);
  } else {
    tmp = (char *)((size_t )__s);
  }
  return ((char __attribute__((__gnu_inline__))  *)tmp);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strtok_r_1c(char *__s ,
                                                                     char __sep ,
                                                                     char **__nextp ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strtok_r_1c(char *__s ,
                                                                     char __sep ,
                                                                     char **__nextp ) 
{ 
  char *__result ;
  char *tmp ;
  char *tmp___0 ;

  {
  if ((unsigned long )__s == (unsigned long )((void *)0)) {
    __s = *__nextp;
  } else {

  }
  while ((int )*__s == (int )__sep) {
    __s ++;
  }
  __result = (char *)((void *)0);
  if ((int )*__s != 0) {
    tmp = __s;
    __s ++;
    __result = tmp;
    while ((int )*__s != 0) {
      tmp___0 = __s;
      __s ++;
      if ((int )*tmp___0 == (int )__sep) {
        *(__s + -1) = (char )'\000';
        break;
      } else {

      }
    }
  } else {

  }
  *__nextp = __s;
  return ((char __attribute__((__gnu_inline__))  *)__result);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strsep_1c(char **__s ,
                                                                   char __reject ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strsep_1c(char **__s ,
                                                                   char __reject ) 
{ 
  char *__retval ;
  char *tmp ;
  char *tmp___0 ;
  char *tmp___2 ;

  {
  __retval = *__s;
  if ((unsigned long )__retval != (unsigned long )((void *)0)) {
    tmp___2 = __builtin_strchr(__retval, (int )__reject);
    tmp___0 = tmp___2;
    *__s = tmp___0;
    if ((unsigned long )tmp___0 != (unsigned long )((void *)0)) {
      tmp = *__s;
      (*__s) ++;
      *tmp = (char )'\000';
    } else {

    }
  } else {

  }
  return ((char __attribute__((__gnu_inline__))  *)__retval);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strsep_2c(char **__s ,
                                                                   char __reject1 ,
                                                                   char __reject2 ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strsep_2c(char **__s ,
                                                                   char __reject1 ,
                                                                   char __reject2 ) 
{ 
  char *__retval ;
  char *__cp ;
  char *tmp ;

  {
  __retval = *__s;
  if ((unsigned long )__retval != (unsigned long )((void *)0)) {
    __cp = __retval;
    while (1) {
      if ((int )*__cp == 0) {
        __cp = (char *)((void *)0);
        break;
      } else {

      }
      if ((int )*__cp == (int )__reject1) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else
      if ((int )*__cp == (int )__reject2) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else {

      }
      __cp ++;
    }
    *__s = __cp;
  } else {

  }
  return ((char __attribute__((__gnu_inline__))  *)__retval);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strsep_3c(char **__s ,
                                                                   char __reject1 ,
                                                                   char __reject2 ,
                                                                   char __reject3 ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strsep_3c(char **__s ,
                                                                   char __reject1 ,
                                                                   char __reject2 ,
                                                                   char __reject3 ) 
{ 
  char *__retval ;
  char *__cp ;
  char *tmp ;

  {
  __retval = *__s;
  if ((unsigned long )__retval != (unsigned long )((void *)0)) {
    __cp = __retval;
    while (1) {
      if ((int )*__cp == 0) {
        __cp = (char *)((void *)0);
        break;
      } else {

      }
      if ((int )*__cp == (int )__reject1) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else
      if ((int )*__cp == (int )__reject2) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else
      if ((int )*__cp == (int )__reject3) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else {

      }
      __cp ++;
    }
    *__s = __cp;
  } else {

  }
  return ((char __attribute__((__gnu_inline__))  *)__retval);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memcpy)(void * __restrict  __dest ,
                            void const   * __restrict  __src , size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memcpy)(void * __restrict  __dest ,
                            void const   * __restrict  __src , size_t __len ) 
{ 
  unsigned long tmp ;
  void *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 0);
  tmp___0 = __builtin___memcpy_chk((void *)__dest, (void const   *)__src, __len,
                                   tmp);
  return ((void __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memmove)(void *__dest , void const   *__src , size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memmove)(void *__dest , void const   *__src , size_t __len ) 
{ 
  unsigned long tmp ;
  void *tmp___0 ;

  {
  tmp = __builtin_object_size(__dest, 0);
  tmp___0 = __builtin___memmove_chk(__dest, __src, __len, tmp);
  return ((void __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) mempcpy)(void * __restrict  __dest ,
                             void const   * __restrict  __src , size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) mempcpy)(void * __restrict  __dest ,
                             void const   * __restrict  __src , size_t __len ) 
{ 
  unsigned long tmp ;
  void *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 0);
  tmp___0 = __builtin___mempcpy_chk((void *)__dest, (void const   *)__src,
                                    __len, tmp);
  return ((void __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1),
__leaf__, __artificial__, __always_inline__)) memset)(void *__dest , int __ch ,
                                                      size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1),
__leaf__, __artificial__, __always_inline__)) memset)(void *__dest , int __ch ,
                                                      size_t __len ) 
{ 
  unsigned long tmp ;
  void *tmp___0 ;

  {
  tmp = __builtin_object_size(__dest, 0);
  tmp___0 = __builtin___memset_chk(__dest, __ch, __len, tmp);
  return ((void __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) bcopy)(void const   *__src , void *__dest , size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) bcopy)(void const   *__src , void *__dest , size_t __len ) 
{ 
  unsigned long tmp ;

  {
  tmp = __builtin_object_size(__dest, 0);
  __builtin___memmove_chk(__dest, __src, __len, tmp);
  return;
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) bzero)(void *__dest , size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) bzero)(void *__dest , size_t __len ) 
{ 
  unsigned long tmp ;

  {
  tmp = __builtin_object_size(__dest, 0);
  __builtin___memset_chk(__dest, '\000', __len, tmp);
  return;
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 1);
  tmp___0 = __builtin___strcpy_chk((char *)__dest, (char const   *)__src, tmp);
  return ((char __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 1);
  tmp___0 = __builtin___stpcpy_chk((char *)__dest, (char const   *)__src, tmp);
  return ((char __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 1);
  tmp___0 = __builtin___strncpy_chk((char *)__dest, (char const   *)__src,
                                    __len, tmp);
  return ((char __attribute__((__gnu_inline__))  *)tmp___0);
}
}
extern  __attribute__((__nothrow__)) char *( __attribute__((__leaf__)) __stpncpy_chk)(char *__dest ,
                                                                                      char const   *__src ,
                                                                                      size_t __n ,
                                                                                      size_t __destlen ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__leaf__)) __stpncpy_alias)(char *__dest ,
                                                                                        char const   *__src ,
                                                                                        size_t __n )  __asm__("stpncpy")  ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __n ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __n ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___3 ;

  {
  tmp___1 = __builtin_object_size((void *)__dest, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dest, 1);
    tmp___0 = __stpncpy_chk((char *)__dest, (char const   *)__src, __n, tmp);
    return ((char __attribute__((__gnu_inline__))  *)tmp___0);
  } else {

  }
  tmp___3 = __stpncpy_alias((char *)__dest, (char const   *)__src, __n);
  return ((char __attribute__((__gnu_inline__))  *)tmp___3);
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcat)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcat)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 1);
  tmp___0 = __builtin___strcat_chk((char *)__dest, (char const   *)__src, tmp);
  return ((char __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncat)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncat)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 1);
  tmp___0 = __builtin___strncat_chk((char *)__dest, (char const   *)__src,
                                    __len, tmp);
  return ((char __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbit)(double __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitf)(float __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitl)(long double __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitf)(float __x )  __attribute__((__const__)) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitf)(float __x ) 
{ 
  int __m ;

  {
  __asm__  ("pmovmskb %1, %0": "=r" (__m): "x" (__x));
  return ((int __attribute__((__gnu_inline__))  )((__m & 8) != 0));
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbit)(double __x )  __attribute__((__const__)) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbit)(double __x ) 
{ 
  int __m ;

  {
  __asm__  ("pmovmskb %1, %0": "=r" (__m): "x" (__x));
  return ((int __attribute__((__gnu_inline__))  )((__m & 128) != 0));
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitl)(long double __x )  __attribute__((__const__)) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitl)(long double __x ) 
{ 
  union __anonunion___u_23 __u ;

  {
  __u.__l = __x;
  return ((int __attribute__((__gnu_inline__))  )((__u.__i[2] & 32768) != 0));
}
}
extern int __uflow(_IO_FILE * ) ;
extern int __overflow(_IO_FILE * , int  ) ;
extern int _IO_getc(_IO_FILE *__fp ) ;
extern int _IO_putc(int __c , _IO_FILE *__fp ) ;
extern struct _IO_FILE *stdin ;
extern struct _IO_FILE *stdout ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) fprintf)(FILE * __restrict  __stream ,
                             char const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) printf)(char const   * __restrict  __fmt  , ...) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) sprintf)(char * __restrict  __s ,
                                             char const   * __restrict  __fmt 
                                             , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vfprintf)(FILE * __restrict  __stream ,
                              char const   * __restrict  __fmt ,
                              __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vprintf)(char const   * __restrict  __fmt ,
                             __gnuc_va_list __ap ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) vsprintf)(char * __restrict  __s ,
                                              char const   * __restrict  __fmt ,
                                              __gnuc_va_list __ap ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) snprintf)(char * __restrict  __s ,
                              size_t __n , char const   * __restrict  __fmt 
                              , ...) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) vsnprintf)(char * __restrict  __s ,
                               size_t __n , char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) vasprintf)(char ** __restrict  __ptr ,
                               char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) __asprintf)(char ** __restrict  __ptr ,
                                char const   * __restrict  __fmt  , ...) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) asprintf)(char ** __restrict  __ptr ,
                              char const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vdprintf)(int __fd , char const   * __restrict  __fmt ,
                              __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) dprintf)(int __fd , char const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  getchar(void) ;
__inline extern int __attribute__((__gnu_inline__))  getc_unlocked(FILE *__fp ) ;
__inline extern int __attribute__((__gnu_inline__))  getchar_unlocked(void) ;
__inline extern int __attribute__((__gnu_inline__))  fgetc_unlocked(FILE *__fp ) ;
__inline extern int __attribute__((__gnu_inline__))  putchar(int __c ) ;
__inline extern int __attribute__((__gnu_inline__))  fputc_unlocked(int __c ,
                                                                    FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  putc_unlocked(int __c ,
                                                                   FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  putchar_unlocked(int __c ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) fgets)(char * __restrict  __s , int __n ,
                                           FILE * __restrict  __stream ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fgets_unlocked)(char * __restrict  __s ,
                                    int __n , FILE * __restrict  __stream ) ;
extern __ssize_t ( __attribute__((__warn_unused_result__)) __getdelim)(char ** __restrict  __lineptr ,
                                                                       size_t * __restrict  __n ,
                                                                       int __delimiter ,
                                                                       FILE * __restrict  __stream ) ;
__inline extern __ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__)) getline)(char ** __restrict  __lineptr ,
                                                                                                              size_t * __restrict  __n ,
                                                                                                              FILE * __restrict  __stream ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) fread)(void * __restrict  __ptr ,
                                           size_t __size , size_t __n ,
                                           FILE * __restrict  __stream ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fread_unlocked)(void * __restrict  __ptr ,
                                    size_t __size , size_t __n ,
                                    FILE * __restrict  __stream ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) feof_unlocked)(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) ferror_unlocked)(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) obstack_printf)(struct obstack * __restrict  __obstack ,
                                    char const   * __restrict  __fmt  , ...) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) obstack_vprintf)(struct obstack * __restrict  __obstack ,
                                     char const   * __restrict  __fmt ,
                                     __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  getchar(void) 
{ 
  int tmp ;

  {
  tmp = _IO_getc(stdin);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  fgetc_unlocked(FILE *__fp ) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  tmp___3 = __builtin_expect((long )((unsigned long )__fp->_IO_read_ptr >= (unsigned long )__fp->_IO_read_end),
                             0L);
  if (tmp___3) {
    tmp___0 = __uflow(__fp);
    tmp___2 = tmp___0;
  } else {
    tmp___1 = __fp->_IO_read_ptr;
    (__fp->_IO_read_ptr) ++;
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
__inline extern int __attribute__((__gnu_inline__))  getc_unlocked(FILE *__fp ) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  tmp___3 = __builtin_expect((long )((unsigned long )__fp->_IO_read_ptr >= (unsigned long )__fp->_IO_read_end),
                             0L);
  if (tmp___3) {
    tmp___0 = __uflow(__fp);
    tmp___2 = tmp___0;
  } else {
    tmp___1 = __fp->_IO_read_ptr;
    (__fp->_IO_read_ptr) ++;
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
__inline extern int __attribute__((__gnu_inline__))  getchar_unlocked(void) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  tmp___3 = __builtin_expect((long )((unsigned long )stdin->_IO_read_ptr >= (unsigned long )stdin->_IO_read_end),
                             0L);
  if (tmp___3) {
    tmp___0 = __uflow(stdin);
    tmp___2 = tmp___0;
  } else {
    tmp___1 = stdin->_IO_read_ptr;
    (stdin->_IO_read_ptr) ++;
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
__inline extern int __attribute__((__gnu_inline__))  putchar(int __c ) 
{ 
  int tmp ;

  {
  tmp = _IO_putc(__c, stdout);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  fputc_unlocked(int __c ,
                                                                    FILE *__stream ) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  tmp___4 = __builtin_expect((long )((unsigned long )__stream->_IO_write_ptr >= (unsigned long )__stream->_IO_write_end),
                             0L);
  if (tmp___4) {
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    tmp___3 = tmp___0;
  } else {
    tmp___1 = __stream->_IO_write_ptr;
    (__stream->_IO_write_ptr) ++;
    tmp___2 = (char )__c;
    *tmp___1 = tmp___2;
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___3);
}
}
__inline extern int __attribute__((__gnu_inline__))  putc_unlocked(int __c ,
                                                                   FILE *__stream ) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  tmp___4 = __builtin_expect((long )((unsigned long )__stream->_IO_write_ptr >= (unsigned long )__stream->_IO_write_end),
                             0L);
  if (tmp___4) {
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    tmp___3 = tmp___0;
  } else {
    tmp___1 = __stream->_IO_write_ptr;
    (__stream->_IO_write_ptr) ++;
    tmp___2 = (char )__c;
    *tmp___1 = tmp___2;
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___3);
}
}
__inline extern int __attribute__((__gnu_inline__))  putchar_unlocked(int __c ) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  tmp___4 = __builtin_expect((long )((unsigned long )stdout->_IO_write_ptr >= (unsigned long )stdout->_IO_write_end),
                             0L);
  if (tmp___4) {
    tmp___0 = __overflow(stdout, (int )((unsigned char )__c));
    tmp___3 = tmp___0;
  } else {
    tmp___1 = stdout->_IO_write_ptr;
    (stdout->_IO_write_ptr) ++;
    tmp___2 = (char )__c;
    *tmp___1 = tmp___2;
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___3);
}
}
__inline extern __ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__)) getline)(char ** __restrict  __lineptr ,
                                                                                                              size_t * __restrict  __n ,
                                                                                                              FILE * __restrict  __stream ) 
{ 
  __ssize_t tmp ;

  {
  tmp = __getdelim(__lineptr, __n, '\n', __stream);
  return ((__ssize_t __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) feof_unlocked)(FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) feof_unlocked)(FILE *__stream ) 
{ 


  {
  return ((int __attribute__((__gnu_inline__))  )((__stream->_flags & 16) != 0));
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) ferror_unlocked)(FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) ferror_unlocked)(FILE *__stream ) 
{ 


  {
  return ((int __attribute__((__gnu_inline__))  )((__stream->_flags & 32) != 0));
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) sprintf)(char * __restrict  __s ,
                                             char const   * __restrict  __fmt 
                                             , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) sprintf)(char * __restrict  __s ,
                                             char const   * __restrict  __fmt 
                                             , ...) 
{ 
  unsigned long tmp ;
  int tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__s, 1);
  tmp___0 = __builtin___sprintf_chk((char *)__s, 1, tmp, (char const   *)__fmt,
                                    __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) vsprintf)(char * __restrict  __s ,
                                              char const   * __restrict  __fmt ,
                                              __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) vsprintf)(char * __restrict  __s ,
                                              char const   * __restrict  __fmt ,
                                              __gnuc_va_list __ap ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__s, 1);
  tmp___0 = __builtin___vsprintf_chk((char *)__s, 1, tmp, (char const   *)__fmt,
                                     __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) snprintf)(char * __restrict  __s ,
                              size_t __n , char const   * __restrict  __fmt 
                              , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) snprintf)(char * __restrict  __s ,
                              size_t __n , char const   * __restrict  __fmt 
                              , ...) 
{ 
  unsigned long tmp ;
  int tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__s, 1);
  tmp___0 = __builtin___snprintf_chk((char *)__s, __n, 1, tmp,
                                     (char const   *)__fmt,
                                     __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) vsnprintf)(char * __restrict  __s ,
                               size_t __n , char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) vsnprintf)(char * __restrict  __s ,
                               size_t __n , char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__s, 1);
  tmp___0 = __builtin___vsnprintf_chk((char *)__s, __n, 1, tmp,
                                      (char const   *)__fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
extern int __fprintf_chk(FILE * __restrict  __stream , int __flag ,
                         char const   * __restrict  __format  , ...) ;
extern int __printf_chk(int __flag , char const   * __restrict  __format  , ...) ;
extern int __vfprintf_chk(FILE * __restrict  __stream , int __flag ,
                          char const   * __restrict  __format ,
                          __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) fprintf)(FILE * __restrict  __stream ,
                             char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __fprintf_chk(__stream, 1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) printf)(char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __printf_chk(1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vprintf)(char const   * __restrict  __fmt ,
                             __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __vfprintf_chk((FILE */* __restrict  */)stdout, 1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vfprintf)(FILE * __restrict  __stream ,
                              char const   * __restrict  __fmt ,
                              __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __vfprintf_chk(__stream, 1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
extern int __dprintf_chk(int __fd , int __flag ,
                         char const   * __restrict  __fmt  , ...) ;
extern int __vdprintf_chk(int __fd , int __flag ,
                          char const   * __restrict  __fmt ,
                          __gnuc_va_list __arg ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) dprintf)(int __fd , char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __dprintf_chk(__fd, 1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vdprintf)(int __fd , char const   * __restrict  __fmt ,
                              __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __vdprintf_chk(__fd, 1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __asprintf_chk)(char ** __restrict  __ptr , int __flag ,
                           char const   * __restrict  __fmt  , ...) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __vasprintf_chk)(char ** __restrict  __ptr , int __flag ,
                            char const   * __restrict  __fmt ,
                            __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__leaf__)) __obstack_printf_chk)(struct obstack * __restrict  __obstack ,
                                                                                           int __flag ,
                                                                                           char const   * __restrict  __format 
                                                                                           , ...) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__leaf__)) __obstack_vprintf_chk)(struct obstack * __restrict  __obstack ,
                                                                                            int __flag ,
                                                                                            char const   * __restrict  __format ,
                                                                                            __gnuc_va_list __args ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) asprintf)(char ** __restrict  __ptr ,
                              char const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) asprintf)(char ** __restrict  __ptr ,
                              char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __asprintf_chk(__ptr, 1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) __asprintf)(char ** __restrict  __ptr ,
                                char const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) __asprintf)(char ** __restrict  __ptr ,
                                char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __asprintf_chk(__ptr, 1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) obstack_printf)(struct obstack * __restrict  __obstack ,
                                    char const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) obstack_printf)(struct obstack * __restrict  __obstack ,
                                    char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __obstack_printf_chk(__obstack, 1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) vasprintf)(char ** __restrict  __ptr ,
                               char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) vasprintf)(char ** __restrict  __ptr ,
                               char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __vasprintf_chk(__ptr, 1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) obstack_vprintf)(struct obstack * __restrict  __obstack ,
                                     char const   * __restrict  __fmt ,
                                     __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) obstack_vprintf)(struct obstack * __restrict  __obstack ,
                                     char const   * __restrict  __fmt ,
                                     __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __obstack_vprintf_chk(__obstack, 1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
extern char *( __attribute__((__warn_unused_result__)) __fgets_chk)(char * __restrict  __s ,
                                                                    size_t __size ,
                                                                    int __n ,
                                                                    FILE * __restrict  __stream ) ;
extern char *( __attribute__((__warn_unused_result__)) __fgets_alias)(char * __restrict  __s ,
                                                                      int __n ,
                                                                      FILE * __restrict  __stream )  __asm__("fgets")  ;
extern char *( __attribute__((__warn_unused_result__)) __fgets_chk_warn)(char * __restrict  __s ,
                                                                         size_t __size ,
                                                                         int __n ,
                                                                         FILE * __restrict  __stream )  __asm__("__fgets_chk") __attribute__((__warning__("fgets called with bigger size than length of destination buffer"))) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) fgets)(char * __restrict  __s , int __n ,
                                           FILE * __restrict  __stream ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  char *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__s, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s, 1);
    tmp___0 = __fgets_chk(__s, tmp, __n, __stream);
    return ((char __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__s, 1);
    if ((size_t )__n > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__s, 1);
      tmp___2 = __fgets_chk_warn(__s, tmp___1, __n, __stream);
      return ((char __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __fgets_alias(__s, __n, __stream);
  return ((char __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern size_t ( __attribute__((__warn_unused_result__)) __fread_chk)(void * __restrict  __ptr ,
                                                                     size_t __ptrlen ,
                                                                     size_t __size ,
                                                                     size_t __n ,
                                                                     FILE * __restrict  __stream ) ;
extern size_t ( __attribute__((__warn_unused_result__)) __fread_alias)(void * __restrict  __ptr ,
                                                                       size_t __size ,
                                                                       size_t __n ,
                                                                       FILE * __restrict  __stream )  __asm__("fread")  ;
extern size_t ( __attribute__((__warn_unused_result__)) __fread_chk_warn)(void * __restrict  __ptr ,
                                                                          size_t __ptrlen ,
                                                                          size_t __size ,
                                                                          size_t __n ,
                                                                          FILE * __restrict  __stream )  __asm__("__fread_chk") __attribute__((__warning__("fread called with bigger size * nmemb than length of destination buffer"))) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) fread)(void * __restrict  __ptr ,
                                           size_t __size , size_t __n ,
                                           FILE * __restrict  __stream ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__ptr, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__ptr, 0);
    tmp___0 = __fread_chk(__ptr, tmp, __size, __n, __stream);
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__ptr, 0);
    if (__size * __n > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__ptr, 0);
      tmp___2 = __fread_chk_warn(__ptr, tmp___1, __size, __n, __stream);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __fread_alias(__ptr, __size, __n, __stream);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern char *( __attribute__((__warn_unused_result__)) __fgets_unlocked_chk)(char * __restrict  __s ,
                                                                             size_t __size ,
                                                                             int __n ,
                                                                             FILE * __restrict  __stream ) ;
extern char *( __attribute__((__warn_unused_result__)) __fgets_unlocked_alias)(char * __restrict  __s ,
                                                                               int __n ,
                                                                               FILE * __restrict  __stream )  __asm__("fgets_unlocked")  ;
extern char *( __attribute__((__warn_unused_result__)) __fgets_unlocked_chk_warn)(char * __restrict  __s ,
                                                                                  size_t __size ,
                                                                                  int __n ,
                                                                                  FILE * __restrict  __stream )  __asm__("__fgets_unlocked_chk") __attribute__((__warning__("fgets_unlocked called with bigger size than length of destination buffer"))) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fgets_unlocked)(char * __restrict  __s ,
                                    int __n , FILE * __restrict  __stream ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  char *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__s, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s, 1);
    tmp___0 = __fgets_unlocked_chk(__s, tmp, __n, __stream);
    return ((char __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__s, 1);
    if ((size_t )__n > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__s, 1);
      tmp___2 = __fgets_unlocked_chk_warn(__s, tmp___1, __n, __stream);
      return ((char __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __fgets_unlocked_alias(__s, __n, __stream);
  return ((char __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern size_t ( __attribute__((__warn_unused_result__)) __fread_unlocked_chk)(void * __restrict  __ptr ,
                                                                              size_t __ptrlen ,
                                                                              size_t __size ,
                                                                              size_t __n ,
                                                                              FILE * __restrict  __stream ) ;
extern size_t ( __attribute__((__warn_unused_result__)) __fread_unlocked_alias)(void * __restrict  __ptr ,
                                                                                size_t __size ,
                                                                                size_t __n ,
                                                                                FILE * __restrict  __stream )  __asm__("fread_unlocked")  ;
extern size_t ( __attribute__((__warn_unused_result__)) __fread_unlocked_chk_warn)(void * __restrict  __ptr ,
                                                                                   size_t __ptrlen ,
                                                                                   size_t __size ,
                                                                                   size_t __n ,
                                                                                   FILE * __restrict  __stream )  __asm__("__fread_unlocked_chk") __attribute__((__warning__("fread_unlocked called with bigger size * nmemb than length of destination buffer"))) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fread_unlocked)(void * __restrict  __ptr ,
                                    size_t __size , size_t __n ,
                                    FILE * __restrict  __stream ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___11 ;

  {
  tmp___4 = __builtin_object_size((void *)__ptr, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__ptr, 0);
    tmp___0 = __fread_unlocked_chk(__ptr, tmp, __size, __n, __stream);
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__ptr, 0);
    if (__size * __n > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__ptr, 0);
      tmp___2 = __fread_unlocked_chk_warn(__ptr, tmp___1, __size, __n, __stream);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___11 = __fread_unlocked_alias(__ptr, __size, __n, __stream);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___11);
}
}
extern void __attribute__((__visibility__("default")))  *_emalloc(size_t size )  __attribute__((__malloc__)) ;
extern void __attribute__((__visibility__("default")))  *_safe_emalloc(size_t nmemb ,
                                                                       size_t size ,
                                                                       size_t offset )  __attribute__((__malloc__)) ;
extern void __attribute__((__visibility__("default")))  _efree(void *ptr ) ;
extern char __attribute__((__visibility__("default")))  *_estrdup(char const   *s )  __attribute__((__malloc__)) ;
extern char __attribute__((__visibility__("default")))  *_estrndup(char const   *s ,
                                                                   unsigned int length )  __attribute__((__malloc__)) ;
extern int __attribute__((__visibility__("default")))  _zend_hash_init(HashTable *ht ,
                                                                       uint nSize ,
                                                                       ulong (*pHashFunction)(char const   *arKey ,
                                                                                              uint nKeyLength ) ,
                                                                       void (*pDestructor)(void *pDest ) ,
                                                                       zend_bool persistent ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_find(HashTable const   *ht ,
                                                                      char const   *arKey ,
                                                                      uint nKeyLength ,
                                                                      void **pData ) ;
extern void __attribute__((__visibility__("default")))  zend_hash_copy(HashTable *target ,
                                                                       HashTable *source ,
                                                                       void (*pCopyConstructor)(void *pElement ) ,
                                                                       void *tmp ,
                                                                       uint size ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_num_elements(HashTable const   *ht ) ;
extern void __attribute__((__visibility__("default")))  rebuild_object_properties(zend_object *zobj ) ;
__inline static zend_uint ( __attribute__((__always_inline__)) zval_refcount_p)(zval *pz ) 
{ 


  {
  return (pz->refcount__gc);
}
}
__inline static zend_uint ( __attribute__((__always_inline__)) zval_set_refcount_p)(zval *pz ,
                                                                                    zend_uint rc ) 
{ 
  zend_uint tmp ;

  {
  tmp = rc;
  pz->refcount__gc = tmp;
  return (tmp);
}
}
__inline static zend_bool ( __attribute__((__always_inline__)) zval_isref_p)(zval *pz ) 
{ 


  {
  return (pz->is_ref__gc);
}
}
__inline static zend_bool ( __attribute__((__always_inline__)) zval_set_isref_to_p)(zval *pz ,
                                                                                    zend_bool isref ) 
{ 
  zend_uchar tmp ;

  {
  tmp = isref;
  pz->is_ref__gc = tmp;
  return (tmp);
}
}
extern void __attribute__((__visibility__("default")))  zend_error(int type ,
                                                                   char const   *format 
                                                                   , ...) ;
extern zval __attribute__((__visibility__("default")))  zval_used_for_init ;
__inline extern int __attribute__((__gnu_inline__))  __sigismember(__sigset_t const   *__set ,
                                                                   int __sig ) ;
__inline extern int __attribute__((__gnu_inline__))  __sigaddset(__sigset_t *__set ,
                                                                 int __sig ) ;
__inline extern int __attribute__((__gnu_inline__))  __sigdelset(__sigset_t *__set ,
                                                                 int __sig ) ;
__inline extern int __attribute__((__gnu_inline__))  __sigismember(__sigset_t const   *__set ,
                                                                   int __sig ) 
{ 
  unsigned long __mask ;
  unsigned long __word ;
  int tmp ;

  {
  __mask = 1UL << (unsigned long )(__sig - 1) % (8UL * sizeof(unsigned long ));
  __word = (unsigned long )(__sig - 1) / (8UL * sizeof(unsigned long ));
  if (__set->__val[__word] & __mask) {
    tmp = 1;
  } else {
    tmp = 0;
  }
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  __sigaddset(__sigset_t *__set ,
                                                                 int __sig ) 
{ 
  unsigned long __mask ;
  unsigned long __word ;

  {
  __mask = 1UL << (unsigned long )(__sig - 1) % (8UL * sizeof(unsigned long ));
  __word = (unsigned long )(__sig - 1) / (8UL * sizeof(unsigned long ));
  __set->__val[__word] |= __mask;
  return ((int __attribute__((__gnu_inline__))  )0);
}
}
__inline extern int __attribute__((__gnu_inline__))  __sigdelset(__sigset_t *__set ,
                                                                 int __sig ) 
{ 
  unsigned long __mask ;
  unsigned long __word ;

  {
  __mask = 1UL << (unsigned long )(__sig - 1) % (8UL * sizeof(unsigned long ));
  __word = (unsigned long )(__sig - 1) / (8UL * sizeof(unsigned long ));
  __set->__val[__word] &= ~ __mask;
  return ((int __attribute__((__gnu_inline__))  )0);
}
}
extern  __attribute__((__nothrow__)) int *( __attribute__((__leaf__)) __errno_location)(void)  __attribute__((__const__)) ;
extern zend_bool __attribute__((__visibility__("default")))  instanceof_function(zend_class_entry const   *instance_ce ,
                                                                                 zend_class_entry const   *ce ) ;
__inline static void const   *zend_memrchr(void const   *s , int c , size_t n ) 
{ 
  register unsigned char const   *e ;

  {
  if (n <= 0UL) {
    return ((void const   *)((void *)0));
  } else {

  }
  e = ((unsigned char const   *)s + n) - 1;
  while ((unsigned long )e >= (unsigned long )((unsigned char const   *)s)) {
    if ((int const   )*e == (int const   )((unsigned char const   )c)) {
      return ((void const   *)e);
    } else {

    }
    e --;
  }
  return ((void const   *)((void *)0));
}
}
extern void __attribute__((__visibility__("default")))  _zval_dtor_func(zval *zvalue ) ;
__inline static void ( __attribute__((__always_inline__)) _zval_dtor)(zval *zvalue ) 
{ 


  {
  if ((int )zvalue->type <= 3) {
    return;
  } else {

  }
  _zval_dtor_func(zvalue);
  return;
}
}
extern void __attribute__((__visibility__("default")))  _zval_copy_ctor_func(zval *zvalue ) ;
__inline static void ( __attribute__((__always_inline__)) _zval_copy_ctor)(zval *zvalue ) 
{ 


  {
  if ((int )zvalue->type <= 3) {
    return;
  } else {

  }
  _zval_copy_ctor_func(zvalue);
  return;
}
}
extern void __attribute__((__visibility__("default")))  _zval_ptr_dtor(zval **zval_ptr ) ;
extern void __attribute__((__visibility__("default")))  zval_add_ref(zval **p ) ;
extern void __attribute__((__visibility__("default")))  zend_replace_error_handling(zend_error_handling_t error_handling ,
                                                                                    zend_class_entry *exception_class ,
                                                                                    zend_error_handling *current ) ;
extern void __attribute__((__visibility__("default")))  zend_restore_error_handling(zend_error_handling *saved ) ;
extern zend_executor_globals __attribute__((__visibility__("default")))  executor_globals ;
extern void __attribute__((__visibility__("default")))  zend_object_std_init(zend_object *object ,
                                                                             zend_class_entry *ce ) ;
extern void __attribute__((__visibility__("default")))  zend_object_std_dtor(zend_object *object ) ;
extern void __attribute__((__visibility__("default")))  zend_objects_destroy_object(zend_object *object ,
                                                                                    zend_object_handle handle ) ;
extern zend_object __attribute__((__visibility__("default")))  *zend_objects_get_address(zval const   *object ) ;
extern void __attribute__((__visibility__("default")))  zend_objects_clone_members(zend_object *new_object ,
                                                                                   zend_object_value new_obj_val ,
                                                                                   zend_object *old_object ,
                                                                                   zend_object_handle handle ) ;
extern zend_object_handle __attribute__((__visibility__("default")))  zend_objects_store_put(void *object ,
                                                                                             void (*dtor)(void *object ,
                                                                                                          zend_object_handle handle ) ,
                                                                                             void (*storage)(void *object ) ,
                                                                                             void (*clone)(void *object ,
                                                                                                           void **object_clone ) ) ;
extern void __attribute__((__visibility__("default")))  *zend_object_store_get_object(zval const   *object ) ;
extern zend_object_handlers __attribute__((__visibility__("default")))  *zend_get_std_object_handlers(void) ;
extern int __attribute__((__visibility__("default")))  _zend_list_addref(int id ) ;
extern void __attribute__((__visibility__("default")))  *zend_fetch_resource(zval **passed_id ,
                                                                             int default_id ,
                                                                             char const   *resource_type_name ,
                                                                             int *found_resource_type ,
                                                                             int num_resource_types 
                                                                             , ...) ;
extern int __attribute__((__visibility__("default")))  zend_is_true(zval *op ) ;
extern int __attribute__((__visibility__("default")))  _zend_get_parameters_array_ex(int param_count ,
                                                                                     zval ***argument_array ) ;
extern int __attribute__((__visibility__("default")))  zend_parse_parameters(int num_args ,
                                                                             char const   *type_spec 
                                                                             , ...) ;
extern void __attribute__((__visibility__("default")))  zend_class_implements(zend_class_entry *class_entry ,
                                                                              int num_interfaces 
                                                                              , ...) ;
extern int __attribute__((__visibility__("default")))  zend_declare_class_constant_long(zend_class_entry *ce ,
                                                                                        char const   *name ,
                                                                                        size_t name_length ,
                                                                                        long value ) ;
extern void __attribute__((__visibility__("default")))  zend_update_class_constants(zend_class_entry *class_type ) ;
extern zend_class_entry __attribute__((__visibility__("default")))  *zend_get_class_entry(zval const   *zobject ) ;
extern int __attribute__((__visibility__("default")))  _array_init(zval *arg ,
                                                                   uint size ) ;
extern void __attribute__((__visibility__("default")))  object_properties_init(zend_object *object ,
                                                                               zend_class_entry *class_type ) ;
extern int __attribute__((__visibility__("default")))  add_assoc_bool_ex(zval *arg ,
                                                                         char const   *key ,
                                                                         uint key_len ,
                                                                         int b ) ;
extern int __attribute__((__visibility__("default")))  add_assoc_stringl_ex(zval *arg ,
                                                                            char const   *key ,
                                                                            uint key_len ,
                                                                            char *str ,
                                                                            uint length ,
                                                                            int duplicate ) ;
extern int __attribute__((__visibility__("default")))  add_next_index_string(zval *arg ,
                                                                             char const   *str ,
                                                                             int duplicate ) ;
extern int __attribute__((__visibility__("default")))  zend_call_function(zend_fcall_info *fci ,
                                                                          zend_fcall_info_cache *fci_cache ) ;
extern  __attribute__((__nothrow__)) __int32_t const   **( __attribute__((__leaf__)) __ctype_tolower_loc)(void)  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) __int32_t const   **( __attribute__((__leaf__)) __ctype_toupper_loc)(void)  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) tolower)(int __c ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) toupper)(int __c ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) tolower)(int __c ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) tolower)(int __c ) 
{ 
  __int32_t const   **tmp ;
  __int32_t tmp___0 ;

  {
  if (__c >= -128) {
    if (__c < 256) {
      tmp = __ctype_tolower_loc();
      tmp___0 = (__int32_t )*(*tmp + __c);
    } else {
      tmp___0 = (__int32_t )((__int32_t const   )__c);
    }
  } else {
    tmp___0 = (__int32_t )((__int32_t const   )__c);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) toupper)(int __c ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) toupper)(int __c ) 
{ 
  __int32_t const   **tmp ;
  __int32_t tmp___0 ;

  {
  if (__c >= -128) {
    if (__c < 256) {
      tmp = __ctype_toupper_loc();
      tmp___0 = (__int32_t )*(*tmp + __c);
    } else {
      tmp___0 = (__int32_t )((__int32_t const   )__c);
    }
  } else {
    tmp___0 = (__int32_t )((__int32_t const   )__c);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) read)(int __fd , void *__buf ,
                                          size_t __nbytes ) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) pread)(int __fd , void *__buf ,
                           size_t __nbytes , __off_t __offset ) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) pread64)(int __fd , void *__buf ,
                                             size_t __nbytes ,
                                             __off64_t __offset ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) getcwd)(char *__buf , size_t __size ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__,
__deprecated__))  *( __attribute__((__warn_unused_result__, __nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) getwd)(char *__buf )  __attribute__((__deprecated__)) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) confstr)(int __name , char *__buf ,
                                             size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) getgroups)(int __size , __gid_t *__list ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(2), __leaf__, __artificial__,
__always_inline__)) ttyname_r)(int __fd , char *__buf , size_t __buflen ) ;
__inline extern  __attribute__((__nothrow__)) ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1,2), __leaf__, __artificial__,
__always_inline__)) readlink)(char const   * __restrict  __path ,
                              char * __restrict  __buf , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(2,3), __leaf__, __artificial__,
__always_inline__)) readlinkat)(int __fd , char const   * __restrict  __path ,
                                char * __restrict  __buf , size_t __len ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__artificial__,
__always_inline__)) getlogin_r)(char *__buf , size_t __buflen ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) gethostname)(char *__buf , size_t __buflen ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__, __artificial__,
__always_inline__)) getdomainname)(char *__buf , size_t __buflen ) ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __read_chk)(int __fd ,
                                                                     void *__buf ,
                                                                     size_t __nbytes ,
                                                                     size_t __buflen ) ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __read_alias)(int __fd ,
                                                                       void *__buf ,
                                                                       size_t __nbytes )  __asm__("read")  ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __read_chk_warn)(int __fd ,
                                                                          void *__buf ,
                                                                          size_t __nbytes ,
                                                                          size_t __buflen )  __asm__("__read_chk") __attribute__((__warning__("read called with bigger length than size of the destination buffer"))) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) read)(int __fd , void *__buf ,
                                          size_t __nbytes ) 
{ 
  unsigned long tmp ;
  ssize_t tmp___0 ;
  unsigned long tmp___1 ;
  ssize_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  ssize_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size(__buf, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size(__buf, 0);
    tmp___0 = __read_chk(__fd, __buf, __nbytes, tmp);
    return ((ssize_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size(__buf, 0);
    if (__nbytes > tmp___3) {
      tmp___1 = __builtin_object_size(__buf, 0);
      tmp___2 = __read_chk_warn(__fd, __buf, __nbytes, tmp___1);
      return ((ssize_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __read_alias(__fd, __buf, __nbytes);
  return ((ssize_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern ssize_t ( __attribute__((__warn_unused_result__)) __pread_chk)(int __fd ,
                                                                      void *__buf ,
                                                                      size_t __nbytes ,
                                                                      __off_t __offset ,
                                                                      size_t __bufsize ) ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __pread64_chk)(int __fd ,
                                                                        void *__buf ,
                                                                        size_t __nbytes ,
                                                                        __off64_t __offset ,
                                                                        size_t __bufsize ) ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __pread_alias)(int __fd ,
                                                                        void *__buf ,
                                                                        size_t __nbytes ,
                                                                        __off_t __offset )  __asm__("pread")  ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __pread64_alias)(int __fd ,
                                                                          void *__buf ,
                                                                          size_t __nbytes ,
                                                                          __off64_t __offset )  __asm__("pread64")  ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __pread_chk_warn)(int __fd ,
                                                                           void *__buf ,
                                                                           size_t __nbytes ,
                                                                           __off_t __offset ,
                                                                           size_t __bufsize )  __asm__("__pread_chk") __attribute__((__warning__("pread called with bigger length than size of the destination buffer"))) ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __pread64_chk_warn)(int __fd ,
                                                                             void *__buf ,
                                                                             size_t __nbytes ,
                                                                             __off64_t __offset ,
                                                                             size_t __bufsize )  __asm__("__pread64_chk") __attribute__((__warning__("pread64 called with bigger length than size of the destination buffer"))) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) pread)(int __fd , void *__buf ,
                                           size_t __nbytes , __off_t __offset ) 
{ 
  unsigned long tmp ;
  ssize_t tmp___0 ;
  unsigned long tmp___1 ;
  ssize_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  ssize_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size(__buf, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size(__buf, 0);
    tmp___0 = __pread_chk(__fd, __buf, __nbytes, __offset, tmp);
    return ((ssize_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size(__buf, 0);
    if (__nbytes > tmp___3) {
      tmp___1 = __builtin_object_size(__buf, 0);
      tmp___2 = __pread_chk_warn(__fd, __buf, __nbytes, __offset, tmp___1);
      return ((ssize_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __pread_alias(__fd, __buf, __nbytes, __offset);
  return ((ssize_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) pread64)(int __fd , void *__buf ,
                                             size_t __nbytes ,
                                             __off64_t __offset ) 
{ 
  unsigned long tmp ;
  ssize_t tmp___0 ;
  unsigned long tmp___1 ;
  ssize_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  ssize_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size(__buf, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size(__buf, 0);
    tmp___0 = __pread64_chk(__fd, __buf, __nbytes, __offset, tmp);
    return ((ssize_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size(__buf, 0);
    if (__nbytes > tmp___3) {
      tmp___1 = __builtin_object_size(__buf, 0);
      tmp___2 = __pread64_chk_warn(__fd, __buf, __nbytes, __offset, tmp___1);
      return ((ssize_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __pread64_alias(__fd, __buf, __nbytes, __offset);
  return ((ssize_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__warn_unused_result__,
__nonnull__(1,2), __leaf__)) __readlink_chk)(char const   * __restrict  __path ,
                                             char * __restrict  __buf ,
                                             size_t __len , size_t __buflen ) ;
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__warn_unused_result__,
__nonnull__(1,2),
__leaf__)) __readlink_alias)(char const   * __restrict  __path ,
                             char * __restrict  __buf , size_t __len )  __asm__("readlink")  ;
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__warn_unused_result__,
__nonnull__(1,2),
__leaf__)) __readlink_chk_warn)(char const   * __restrict  __path ,
                                char * __restrict  __buf , size_t __len ,
                                size_t __buflen )  __asm__("__readlink_chk") __attribute__((__warning__("readlink called with bigger length than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1,2), __leaf__, __artificial__,
__always_inline__)) readlink)(char const   * __restrict  __path ,
                              char * __restrict  __buf , size_t __len ) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1,2), __leaf__, __artificial__,
__always_inline__)) readlink)(char const   * __restrict  __path ,
                              char * __restrict  __buf , size_t __len ) 
{ 
  unsigned long tmp ;
  ssize_t tmp___0 ;
  unsigned long tmp___1 ;
  ssize_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  ssize_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __readlink_chk(__path, __buf, __len, tmp);
    return ((ssize_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__len > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __readlink_chk_warn(__path, __buf, __len, tmp___1);
      return ((ssize_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __readlink_alias(__path, __buf, __len);
  return ((ssize_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__warn_unused_result__,
__nonnull__(2,3),
__leaf__)) __readlinkat_chk)(int __fd , char const   * __restrict  __path ,
                             char * __restrict  __buf , size_t __len ,
                             size_t __buflen ) ;
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__warn_unused_result__,
__nonnull__(2,3),
__leaf__)) __readlinkat_alias)(int __fd , char const   * __restrict  __path ,
                               char * __restrict  __buf , size_t __len )  __asm__("readlinkat")  ;
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__warn_unused_result__,
__nonnull__(2,3),
__leaf__)) __readlinkat_chk_warn)(int __fd , char const   * __restrict  __path ,
                                  char * __restrict  __buf , size_t __len ,
                                  size_t __buflen )  __asm__("__readlinkat_chk") __attribute__((__warning__("readlinkat called with bigger length than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(2,3), __leaf__, __artificial__,
__always_inline__)) readlinkat)(int __fd , char const   * __restrict  __path ,
                                char * __restrict  __buf , size_t __len ) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(2,3), __leaf__, __artificial__,
__always_inline__)) readlinkat)(int __fd , char const   * __restrict  __path ,
                                char * __restrict  __buf , size_t __len ) 
{ 
  unsigned long tmp ;
  ssize_t tmp___0 ;
  unsigned long tmp___1 ;
  ssize_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  ssize_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __readlinkat_chk(__fd, __path, __buf, __len, tmp);
    return ((ssize_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__len > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __readlinkat_chk_warn(__fd, __path, __buf, __len, tmp___1);
      return ((ssize_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __readlinkat_alias(__fd, __path, __buf, __len);
  return ((ssize_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__leaf__)) __getcwd_chk)(char *__buf , size_t __size , size_t __buflen ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__leaf__)) __getcwd_alias)(char *__buf , size_t __size )  __asm__("getcwd")  ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__leaf__)) __getcwd_chk_warn)(char *__buf , size_t __size , size_t __buflen )  __asm__("__getcwd_chk") __attribute__((__warning__("getcwd caller with bigger length than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) getcwd)(char *__buf , size_t __size ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) getcwd)(char *__buf , size_t __size ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  char *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __getcwd_chk(__buf, __size, tmp);
    return ((char __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__size > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __getcwd_chk_warn(__buf, __size, tmp___1);
      return ((char __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __getcwd_alias(__buf, __size);
  return ((char __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) __getwd_chk)(char *__buf , size_t buflen ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) __getwd_warn)(char *__buf )  __asm__("getwd") __attribute__((__warning__("please use getcwd instead, as getwd doesn\'t specify buffer size"))) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__,
__deprecated__))  *( __attribute__((__warn_unused_result__, __nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) getwd)(char *__buf )  __attribute__((__deprecated__)) ;
__inline extern char __attribute__((__gnu_inline__,
__deprecated__))  *( __attribute__((__warn_unused_result__, __nonnull__(1),
__leaf__, __artificial__, __always_inline__)) getwd)(char *__buf ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__buf, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __getwd_chk(__buf, tmp);
    return ((char __attribute__((__gnu_inline__, __deprecated__))  *)tmp___0);
  } else {

  }
  tmp___2 = __getwd_warn(__buf);
  return ((char __attribute__((__gnu_inline__, __deprecated__))  *)tmp___2);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __confstr_chk)(int __name ,
                                                                                       char *__buf ,
                                                                                       size_t __len ,
                                                                                       size_t __buflen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __confstr_alias)(int __name ,
                                                                                         char *__buf ,
                                                                                         size_t __len )  __asm__("confstr")  ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __confstr_chk_warn)(int __name ,
                                                                                            char *__buf ,
                                                                                            size_t __len ,
                                                                                            size_t __buflen )  __asm__("__confstr_chk") __attribute__((__warning__("confstr called with bigger length than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) confstr)(int __name , char *__buf ,
                                             size_t __len ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) confstr)(int __name , char *__buf ,
                                             size_t __len ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __confstr_chk(__name, __buf, __len, tmp);
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (tmp___3 < __len) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __confstr_chk_warn(__name, __buf, __len, tmp___1);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __confstr_alias(__name, __buf, __len);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __getgroups_chk)(int __size , __gid_t *__list , size_t __listlen ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __getgroups_alias)(int __size , __gid_t *__list )  __asm__("getgroups")  ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __getgroups_chk_warn)(int __size , __gid_t *__list ,
                                 size_t __listlen )  __asm__("__getgroups_chk") __attribute__((__warning__("getgroups called with bigger group count than what can fit into destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) getgroups)(int __size , __gid_t *__list ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) getgroups)(int __size , __gid_t *__list ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__list, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__list, 1);
    tmp___0 = __getgroups_chk(__size, __list, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__list, 1);
    if ((unsigned long )__size * sizeof(__gid_t ) > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__list, 1);
      tmp___2 = __getgroups_chk_warn(__size, __list, tmp___1);
      return ((int __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __getgroups_alias(__size, __list);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ttyname_r_chk)(int __fd , char *__buf , size_t __buflen ,
                            size_t __nreal ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ttyname_r_alias)(int __fd , char *__buf , size_t __buflen )  __asm__("ttyname_r")  ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ttyname_r_chk_warn)(int __fd , char *__buf , size_t __buflen ,
                                 size_t __nreal )  __asm__("__ttyname_r_chk") __attribute__((__warning__("ttyname_r called with bigger buflen than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(2), __leaf__, __artificial__,
__always_inline__)) ttyname_r)(int __fd , char *__buf , size_t __buflen ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(2), __leaf__, __artificial__,
__always_inline__)) ttyname_r)(int __fd , char *__buf , size_t __buflen ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __ttyname_r_chk(__fd, __buf, __buflen, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__buflen > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __ttyname_r_chk_warn(__fd, __buf, __buflen, tmp___1);
      return ((int __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __ttyname_r_alias(__fd, __buf, __buflen);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern int ( __attribute__((__nonnull__(1))) __getlogin_r_chk)(char *__buf ,
                                                               size_t __buflen ,
                                                               size_t __nreal ) ;
extern int ( __attribute__((__nonnull__(1))) __getlogin_r_alias)(char *__buf ,
                                                                 size_t __buflen )  __asm__("getlogin_r")  ;
extern int ( __attribute__((__nonnull__(1))) __getlogin_r_chk_warn)(char *__buf ,
                                                                    size_t __buflen ,
                                                                    size_t __nreal )  __asm__("__getlogin_r_chk") __attribute__((__warning__("getlogin_r called with bigger buflen than size of destination buffer"))) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__artificial__, __always_inline__)) getlogin_r)(char *__buf , size_t __buflen ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __getlogin_r_chk(__buf, __buflen, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__buflen > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __getlogin_r_chk_warn(__buf, __buflen, tmp___1);
      return ((int __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __getlogin_r_alias(__buf, __buflen);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1),
__leaf__)) __gethostname_chk)(char *__buf , size_t __buflen , size_t __nreal ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1),
__leaf__)) __gethostname_alias)(char *__buf , size_t __buflen )  __asm__("gethostname")  ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1),
__leaf__)) __gethostname_chk_warn)(char *__buf , size_t __buflen ,
                                   size_t __nreal )  __asm__("__gethostname_chk") __attribute__((__warning__("gethostname called with bigger buflen than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) gethostname)(char *__buf , size_t __buflen ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) gethostname)(char *__buf , size_t __buflen ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __gethostname_chk(__buf, __buflen, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__buflen > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __gethostname_chk_warn(__buf, __buflen, tmp___1);
      return ((int __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __gethostname_alias(__buf, __buflen);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) __getdomainname_chk)(char *__buf , size_t __buflen ,
                                                size_t __nreal ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) __getdomainname_alias)(char *__buf , size_t __buflen )  __asm__("getdomainname")  ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) __getdomainname_chk_warn)(char *__buf , size_t __buflen ,
                                     size_t __nreal )  __asm__("__getdomainname_chk") __attribute__((__warning__("getdomainname called with bigger buflen than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__, __artificial__,
__always_inline__)) getdomainname)(char *__buf , size_t __buflen ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__, __artificial__,
__always_inline__)) getdomainname)(char *__buf , size_t __buflen ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __getdomainname_chk(__buf, __buflen, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__buflen > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __getdomainname_chk_warn(__buf, __buflen, tmp___1);
      return ((int __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __getdomainname_alias(__buf, __buflen);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern int __attribute__((__visibility__("default")))  ap_php_slprintf(char *buf ,
                                                                       size_t len ,
                                                                       char const   *format 
                                                                       , ...) ;
extern int __attribute__((__visibility__("default")))  spprintf(char **pbuf ,
                                                                size_t max_len ,
                                                                char const   *format 
                                                                , ...) ;
extern void __attribute__((__visibility__("default")))  php_error_docref0(char const   *docref ,
                                                                          int type ,
                                                                          char const   *format 
                                                                          , ...) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) stat)(char const   * __restrict  __path ,
                 struct stat * __restrict  __statbuf ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) fstat)(int __fd , struct stat *__statbuf ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) stat64)(char const   * __restrict  __path ,
                   struct stat64 * __restrict  __statbuf ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) fstat64)(int __fd , struct stat64 *__statbuf ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2,3),
__leaf__)) fstatat)(int __fd , char const   * __restrict  __filename ,
                    struct stat * __restrict  __statbuf , int __flag ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2,3),
__leaf__)) fstatat64)(int __fd , char const   * __restrict  __filename ,
                      struct stat64 * __restrict  __statbuf , int __flag ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) lstat)(char const   * __restrict  __path ,
                  struct stat * __restrict  __statbuf ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) lstat64)(char const   * __restrict  __path ,
                    struct stat64 * __restrict  __statbuf ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__)) mknod)(char const   *__path , __mode_t __mode , __dev_t __dev ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) mknodat)(int __fd , char const   *__path , __mode_t __mode ,
                    __dev_t __dev ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3),
__leaf__)) __fxstat)(int __ver , int __fildes , struct stat *__stat_buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,3),
__leaf__)) __xstat)(int __ver , char const   *__filename ,
                    struct stat *__stat_buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,3),
__leaf__)) __lxstat)(int __ver , char const   *__filename ,
                     struct stat *__stat_buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3,4),
__leaf__)) __fxstatat)(int __ver , int __fildes , char const   *__filename ,
                       struct stat *__stat_buf , int __flag ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3),
__leaf__)) __fxstat64)(int __ver , int __fildes , struct stat64 *__stat_buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,3),
__leaf__)) __xstat64)(int __ver , char const   *__filename ,
                      struct stat64 *__stat_buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,3),
__leaf__)) __lxstat64)(int __ver , char const   *__filename ,
                       struct stat64 *__stat_buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3,4),
__leaf__)) __fxstatat64)(int __ver , int __fildes , char const   *__filename ,
                         struct stat64 *__stat_buf , int __flag ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,4),
__leaf__)) __xmknod)(int __ver , char const   *__path , __mode_t __mode ,
                     __dev_t *__dev ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3,5),
__leaf__)) __xmknodat)(int __ver , int __fd , char const   *__path ,
                       __mode_t __mode , __dev_t *__dev ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) stat)(char const   * __restrict  __path ,
                 struct stat * __restrict  __statbuf ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) stat)(char const   * __restrict  __path ,
                 struct stat * __restrict  __statbuf ) 
{ 
  int tmp ;

  {
  tmp = __xstat(1, (char const   *)__path, (struct stat *)__statbuf);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) lstat)(char const   * __restrict  __path ,
                  struct stat * __restrict  __statbuf ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) lstat)(char const   * __restrict  __path ,
                  struct stat * __restrict  __statbuf ) 
{ 
  int tmp ;

  {
  tmp = __lxstat(1, (char const   *)__path, (struct stat *)__statbuf);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) fstat)(int __fd , struct stat *__statbuf ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) fstat)(int __fd , struct stat *__statbuf ) 
{ 
  int tmp ;

  {
  tmp = __fxstat(1, __fd, __statbuf);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2,3),
__leaf__)) fstatat)(int __fd , char const   * __restrict  __filename ,
                    struct stat * __restrict  __statbuf , int __flag ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2,3),
__leaf__)) fstatat)(int __fd , char const   * __restrict  __filename ,
                    struct stat * __restrict  __statbuf , int __flag ) 
{ 
  int tmp ;

  {
  tmp = __fxstatat(1, __fd, (char const   *)__filename,
                   (struct stat *)__statbuf, __flag);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__)) mknod)(char const   *__path , __mode_t __mode , __dev_t __dev ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__)) mknod)(char const   *__path , __mode_t __mode , __dev_t __dev ) 
{ 
  int tmp ;

  {
  tmp = __xmknod(0, __path, __mode, & __dev);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) mknodat)(int __fd , char const   *__path , __mode_t __mode ,
                    __dev_t __dev ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) mknodat)(int __fd , char const   *__path , __mode_t __mode ,
                    __dev_t __dev ) 
{ 
  int tmp ;

  {
  tmp = __xmknodat(0, __fd, __path, __mode, & __dev);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) stat64)(char const   * __restrict  __path ,
                   struct stat64 * __restrict  __statbuf ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) stat64)(char const   * __restrict  __path ,
                   struct stat64 * __restrict  __statbuf ) 
{ 
  int tmp ;

  {
  tmp = __xstat64(1, (char const   *)__path, (struct stat64 *)__statbuf);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) lstat64)(char const   * __restrict  __path ,
                    struct stat64 * __restrict  __statbuf ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) lstat64)(char const   * __restrict  __path ,
                    struct stat64 * __restrict  __statbuf ) 
{ 
  int tmp ;

  {
  tmp = __lxstat64(1, (char const   *)__path, (struct stat64 *)__statbuf);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) fstat64)(int __fd , struct stat64 *__statbuf ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) fstat64)(int __fd , struct stat64 *__statbuf ) 
{ 
  int tmp ;

  {
  tmp = __fxstat64(1, __fd, __statbuf);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2,3),
__leaf__)) fstatat64)(int __fd , char const   * __restrict  __filename ,
                      struct stat64 * __restrict  __statbuf , int __flag ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2,3),
__leaf__)) fstatat64)(int __fd , char const   * __restrict  __filename ,
                      struct stat64 * __restrict  __statbuf , int __flag ) 
{ 
  int tmp ;

  {
  tmp = __fxstatat64(1, __fd, (char const   *)__filename,
                     (struct stat64 *)__statbuf, __flag);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
extern php_stream_context __attribute__((__visibility__("default")))  *php_stream_context_alloc(void) ;
extern int __attribute__((__visibility__("default")))  _php_stream_free(php_stream *stream ,
                                                                        int close_options ) ;
extern int __attribute__((__visibility__("default")))  _php_stream_seek(php_stream *stream ,
                                                                        off_t offset ,
                                                                        int whence ) ;
extern off_t __attribute__((__visibility__("default")))  _php_stream_tell(php_stream *stream ) ;
extern size_t __attribute__((__visibility__("default")))  _php_stream_write(php_stream *stream ,
                                                                            char const   *buf ,
                                                                            size_t count ) ;
extern int __attribute__((__visibility__("default")))  _php_stream_eof(php_stream *stream ) ;
extern int __attribute__((__visibility__("default")))  _php_stream_getc(php_stream *stream ) ;
extern int __attribute__((__visibility__("default")))  _php_stream_flush(php_stream *stream ,
                                                                         int closing ) ;
extern char __attribute__((__visibility__("default")))  *_php_stream_get_line(php_stream *stream ,
                                                                              char *buf ,
                                                                              size_t maxlen ,
                                                                              size_t *returned_len ) ;
extern php_stream __attribute__((__visibility__("default")))  *_php_stream_opendir(char *path ,
                                                                                   int options ,
                                                                                   php_stream_context *context ) ;
extern php_stream_dirent __attribute__((__visibility__("default")))  *_php_stream_readdir(php_stream *dirstream ,
                                                                                          php_stream_dirent *ent ) ;
extern int __attribute__((__visibility__("default")))  _php_stream_set_option(php_stream *stream ,
                                                                              int option ,
                                                                              int value ,
                                                                              void *ptrparam ) ;
extern int __attribute__((__visibility__("default")))  _php_stream_truncate_set_size(php_stream *stream ,
                                                                                     size_t newsize ) ;
extern size_t __attribute__((__visibility__("default")))  _php_stream_passthru(php_stream *src ) ;
__inline extern  __attribute__((__nothrow__)) struct cmsghdr  __attribute__((__gnu_inline__)) *( __attribute__((__leaf__)) __cmsg_nxthdr)(struct msghdr *__mhdr ,
                                                                                                                                          struct cmsghdr *__cmsg ) ;
__inline extern  __attribute__((__nothrow__)) struct cmsghdr  __attribute__((__gnu_inline__)) *( __attribute__((__leaf__)) __cmsg_nxthdr)(struct msghdr *__mhdr ,
                                                                                                                                          struct cmsghdr *__cmsg ) ;
__inline extern struct cmsghdr  __attribute__((__gnu_inline__)) *( __attribute__((__leaf__)) __cmsg_nxthdr)(struct msghdr *__mhdr ,
                                                                                                            struct cmsghdr *__cmsg ) 
{ 


  {
  if (__cmsg->cmsg_len < sizeof(struct cmsghdr )) {
    return ((struct cmsghdr  __attribute__((__gnu_inline__)) *)((struct cmsghdr *)0));
  } else {

  }
  __cmsg = (struct cmsghdr *)((unsigned char *)__cmsg + (((__cmsg->cmsg_len + sizeof(size_t )) - 1UL) & ~ (sizeof(size_t ) - 1UL)));
  if ((unsigned long )((unsigned char *)(__cmsg + 1)) > (unsigned long )((unsigned char *)__mhdr->msg_control + __mhdr->msg_controllen)) {
    return ((struct cmsghdr  __attribute__((__gnu_inline__)) *)((struct cmsghdr *)0));
  } else
  if ((unsigned long )((unsigned char *)__cmsg + (((__cmsg->cmsg_len + sizeof(size_t )) - 1UL) & ~ (sizeof(size_t ) - 1UL))) > (unsigned long )((unsigned char *)__mhdr->msg_control + __mhdr->msg_controllen)) {
    return ((struct cmsghdr  __attribute__((__gnu_inline__)) *)((struct cmsghdr *)0));
  } else {

  }
  return ((struct cmsghdr  __attribute__((__gnu_inline__)) *)__cmsg);
}
}
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) recv)(int __fd , void *__buf , size_t __n , int __flags ) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) recvfrom)(int __fd , void * __restrict  __buf , size_t __n ,
                              int __flags ,
                              struct sockaddr * __restrict  __cil_tmp14 ,
                              socklen_t * __restrict  __addr_len ) ;
extern ssize_t __recv_chk(int __fd , void *__buf , size_t __n ,
                          size_t __buflen , int __flags ) ;
extern ssize_t __recv_alias(int __fd , void *__buf , size_t __n , int __flags )  __asm__("recv")  ;
extern ssize_t __recv_chk_warn(int __fd , void *__buf , size_t __n ,
                               size_t __buflen , int __flags )  __asm__("__recv_chk") __attribute__((__warning__("recv called with bigger length than size of destination buffer"))) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) recv)(int __fd , void *__buf , size_t __n , int __flags ) 
{ 
  unsigned long tmp ;
  ssize_t tmp___0 ;
  unsigned long tmp___1 ;
  ssize_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  ssize_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size(__buf, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size(__buf, 0);
    tmp___0 = __recv_chk(__fd, __buf, __n, tmp, __flags);
    return ((ssize_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size(__buf, 0);
    if (__n > tmp___3) {
      tmp___1 = __builtin_object_size(__buf, 0);
      tmp___2 = __recv_chk_warn(__fd, __buf, __n, tmp___1, __flags);
      return ((ssize_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __recv_alias(__fd, __buf, __n, __flags);
  return ((ssize_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern ssize_t __recvfrom_chk(int __fd , void * __restrict  __buf , size_t __n ,
                              size_t __buflen , int __flags ,
                              struct sockaddr * __restrict  __addr ,
                              socklen_t * __restrict  __addr_len ) ;
extern ssize_t __recvfrom_alias(int __fd , void * __restrict  __buf ,
                                size_t __n , int __flags ,
                                struct sockaddr * __restrict  __addr ,
                                socklen_t * __restrict  __addr_len )  __asm__("recvfrom")  ;
extern ssize_t __recvfrom_chk_warn(int __fd , void * __restrict  __buf ,
                                   size_t __n , size_t __buflen , int __flags ,
                                   struct sockaddr * __restrict  __addr ,
                                   socklen_t * __restrict  __addr_len )  __asm__("__recvfrom_chk") __attribute__((__warning__("recvfrom called with bigger length than size of destination buffer"))) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) recvfrom)(int __fd , void * __restrict  __buf , size_t __n ,
                              int __flags ,
                              struct sockaddr * __restrict  __cil_tmp14 ,
                              socklen_t * __restrict  __addr_len ) 
{ 
  __SOCKADDR_ARG __addr ;
  unsigned long tmp ;
  ssize_t tmp___0 ;
  unsigned long tmp___1 ;
  ssize_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  ssize_t tmp___5 ;

  {
  __addr.__sockaddr__ = __cil_tmp14;
  tmp___4 = __builtin_object_size((void *)__buf, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 0);
    tmp___0 = __recvfrom_chk(__fd, __buf, __n, tmp, __flags,
                             __addr.__sockaddr__, __addr_len);
    return ((ssize_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 0);
    if (__n > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 0);
      tmp___2 = __recvfrom_chk_warn(__fd, __buf, __n, tmp___1, __flags,
                                    __addr.__sockaddr__, __addr_len);
      return ((ssize_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __recvfrom_alias(__fd, __buf, __n, __flags, __addr.__sockaddr__,
                             __addr_len);
  return ((ssize_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern php_stream_ops __attribute__((__visibility__("default")))  php_glob_stream_ops ;
extern char __attribute__((__visibility__("default")))  *_php_glob_stream_get_path(php_stream *stream ,
                                                                                   int copy ,
                                                                                   int *plen ) ;
extern int __attribute__((__visibility__("default")))  _php_glob_stream_get_count(php_stream *stream ,
                                                                                  int *pflags ) ;
extern php_stream __attribute__((__visibility__("default")))  *_php_stream_open_wrapper_ex(char *path ,
                                                                                           char *mode ,
                                                                                           int options ,
                                                                                           char **opened_path ,
                                                                                           php_stream_context *context ) ;
extern char __attribute__((__visibility__("default")))  *expand_filepath_with_mode(char const   *filepath ,
                                                                                   char *real_path ,
                                                                                   char const   *relative_to ,
                                                                                   size_t relative_to_len ,
                                                                                   int realpath_mode ) ;
extern char __attribute__((__visibility__("default")))  *tsrm_realpath(char const   *path ,
                                                                       char *real_path ) ;
extern int __attribute__((__visibility__("default")))  php_le_stream_context(void) ;
extern void __attribute__((__visibility__("default")))  php_fgetcsv(php_stream *stream ,
                                                                    char delimiter ,
                                                                    char enclosure ,
                                                                    char escape_char ,
                                                                    size_t buf_len ,
                                                                    char *buf ,
                                                                    zval *return_value ) ;
extern int __attribute__((__visibility__("default")))  php_fputcsv(php_stream *stream ,
                                                                   zval *fields ,
                                                                   char delimiter ,
                                                                   char enclosure ,
                                                                   char escape_char ) ;
extern php_file_globals __attribute__((__visibility__("default")))  file_globals ;
extern void __attribute__((__visibility__("default")))  php_basename(char const   *s ,
                                                                     size_t len ,
                                                                     char *suffix ,
                                                                     size_t sufflen ,
                                                                     char **p_ret ,
                                                                     size_t *p_len ) ;
extern size_t __attribute__((__visibility__("default")))  php_dirname(char *str ,
                                                                      size_t len ) ;
extern zval __attribute__((__visibility__("default")))  *zend_throw_exception_ex(zend_class_entry *exception_ce ,
                                                                                 long code ,
                                                                                 char *format 
                                                                                 , ...) ;
extern zend_class_entry __attribute__((__visibility__("default")))  *zend_ce_iterator ;
extern zval __attribute__((__visibility__("default")))  *zend_call_method(zval **object_pp ,
                                                                          zend_class_entry *obj_ce ,
                                                                          zend_function **fn_proxy ,
                                                                          char const   *function_name ,
                                                                          int function_name_len ,
                                                                          zval **retval_ptr_ptr ,
                                                                          int param_count ,
                                                                          zval *arg1 ,
                                                                          zval *arg2 ) ;
extern int __attribute__((__visibility__("default")))  zend_class_serialize_deny(zval *object ,
                                                                                 unsigned char **buffer ,
                                                                                 zend_uint *buf_len ,
                                                                                 zend_serialize_data *data ) ;
extern int __attribute__((__visibility__("default")))  zend_class_unserialize_deny(zval **object ,
                                                                                   zend_class_entry *ce ,
                                                                                   unsigned char const   *buf ,
                                                                                   zend_uint buf_len ,
                                                                                   zend_unserialize_data *data ) ;
extern void spl_register_std_class(zend_class_entry **ppce , char *class_name ,
                                   zend_object_value (*ctor)(zend_class_entry *class_type ) ,
                                   zend_function_entry const   *function_list ) ;
extern void spl_register_sub_class(zend_class_entry **ppce ,
                                   zend_class_entry *parent_ce ,
                                   char *class_name ,
                                   zend_object_value (*ctor)(zend_class_entry *class_type ) ,
                                   zend_function_entry const   *function_list ) ;
extern char *spl_gen_private_prop_name(zend_class_entry *ce , char *prop_name ,
                                       int prop_len , int *name_len ) ;
extern void __attribute__((__visibility__("default")))  spl_instantiate(zend_class_entry *pce ,
                                                                        zval **object ,
                                                                        int alloc ) ;
__inline static int spl_instantiate_arg_ex2(zend_class_entry *pce ,
                                            zval **retval , int alloc ,
                                            zval *arg1 , zval *arg2 ) 
{ 
  size_t tmp ;

  {
  spl_instantiate(pce, retval, alloc);
  tmp = strlen((pce->constructor)->common.function_name);
  zend_call_method(retval, pce, & pce->constructor,
                   (pce->constructor)->common.function_name, (int )tmp,
                   (zval **)((void *)0), 2, arg1, arg2);
  return (0);
}
}
extern zend_class_entry __attribute__((__visibility__("default")))  *spl_ce_RecursiveIterator ;
extern zend_class_entry __attribute__((__visibility__("default")))  *spl_ce_SeekableIterator ;
extern zend_class_entry __attribute__((__visibility__("default")))  *spl_ce_Countable ;
zend_class_entry __attribute__((__visibility__("default")))  *spl_ce_SplFileInfo  ;
zend_class_entry __attribute__((__visibility__("default")))  *spl_ce_DirectoryIterator  ;
zend_class_entry __attribute__((__visibility__("default")))  *spl_ce_FilesystemIterator  ;
zend_class_entry __attribute__((__visibility__("default")))  *spl_ce_RecursiveDirectoryIterator  ;
zend_class_entry __attribute__((__visibility__("default")))  *spl_ce_GlobIterator  ;
zend_class_entry __attribute__((__visibility__("default")))  *spl_ce_SplFileObject  ;
zend_class_entry __attribute__((__visibility__("default")))  *spl_ce_SplTempFileObject  ;
int zm_startup_spl_directory(int type , int module_number ) ;
char __attribute__((__visibility__("default")))  *spl_filesystem_object_get_path(spl_filesystem_object *intern ,
                                                                                 int *len ) ;
__inline static spl_filesystem_iterator *spl_filesystem_object_to_iterator(spl_filesystem_object *obj ) 
{ 


  {
  return (& obj->it);
}
}
__inline static spl_filesystem_object *spl_filesystem_iterator_to_object(spl_filesystem_iterator *it ) 
{ 


  {
  return ((spl_filesystem_object *)((char *)it - ((char *)(& ((spl_filesystem_object *)((void *)0))->it) - (char *)((void *)0))));
}
}
extern zend_class_entry __attribute__((__visibility__("default")))  *spl_ce_LogicException ;
extern zend_class_entry __attribute__((__visibility__("default")))  *spl_ce_DomainException ;
extern zend_class_entry __attribute__((__visibility__("default")))  *spl_ce_RuntimeException ;
extern zend_class_entry __attribute__((__visibility__("default")))  *spl_ce_UnexpectedValueException ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcscpy)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcsncpy)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcscat)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcsncat)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wmemcpy)(wchar_t * __restrict  __s1 ,
                             wchar_t const   * __restrict  __s2 , size_t __n ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__, __always_inline__)) wmemmove)(wchar_t *__s1 ,
                                              wchar_t const   *__s2 ,
                                              size_t __n ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__, __always_inline__)) wmemset)(wchar_t *__s , wchar_t __c ,
                                             size_t __n ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wmempcpy)(wchar_t * __restrict  __s1 ,
                              wchar_t const   * __restrict  __s2 , size_t __n ) ;
__inline extern  __attribute__((__nothrow__)) wint_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) btowc)(int __c ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) wctob)(wint_t __wc ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) mbrtowc)(wchar_t * __restrict  __pwc ,
                                                                                 char const   * __restrict  __s ,
                                                                                 size_t __n ,
                                                                                 mbstate_t * __restrict  __p ) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) wcrtomb)(char * __restrict  __s , wchar_t __wchar ,
                             mbstate_t * __restrict  __ps ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbrlen)(char const   * __restrict  __s ,
                                                                                  size_t __n ,
                                                                                  mbstate_t * __restrict  __ps ) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) mbrlen)(char const   * __restrict  __s ,
                                                                                                                          size_t __n ,
                                                                                                                          mbstate_t * __restrict  __ps ) ;
extern wint_t __btowc_alias(int __c )  __asm__("btowc")  ;
__inline extern  __attribute__((__nothrow__)) wint_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) btowc)(int __c ) ;
__inline extern wint_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) btowc)(int __c ) 
{ 
  wint_t tmp ;

  {
  tmp = __btowc_alias(__c);
  return ((wint_t __attribute__((__gnu_inline__))  )tmp);
}
}
extern int __wctob_alias(wint_t __c )  __asm__("wctob")  ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) wctob)(wint_t __wc ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) wctob)(wint_t __wc ) 
{ 
  int tmp ;

  {
  tmp = __wctob_alias(__wc);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) mbrlen)(char const   * __restrict  __s ,
                                                                                                                          size_t __n ,
                                                                                                                          mbstate_t * __restrict  __ps ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) mbrlen)(char const   * __restrict  __s ,
                                                                                            size_t __n ,
                                                                                            mbstate_t * __restrict  __ps ) 
{ 
  size_t tmp ;
  size_t tmp___0 ;
  size_t tmp___1 ;

  {
  if ((unsigned long )__ps != (unsigned long )((void *)0)) {
    tmp = mbrtowc((wchar_t */* __restrict  */)((void *)0), __s, __n, __ps);
    tmp___1 = tmp;
  } else {
    tmp___0 = __mbrlen(__s, __n, (mbstate_t */* __restrict  */)((void *)0));
    tmp___1 = tmp___0;
  }
  return ((size_t __attribute__((__gnu_inline__))  )tmp___1);
}
}
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) mbsrtowcs)(wchar_t * __restrict  __dst ,
                               char const   ** __restrict  __src ,
                               size_t __len , mbstate_t * __restrict  __ps ) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcsrtombs)(char * __restrict  __dst ,
                               wchar_t const   ** __restrict  __src ,
                               size_t __len , mbstate_t * __restrict  __ps ) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) mbsnrtowcs)(wchar_t * __restrict  __dst ,
                                char const   ** __restrict  __src ,
                                size_t __nmc , size_t __len ,
                                mbstate_t * __restrict  __ps ) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcsnrtombs)(char * __restrict  __dst ,
                                wchar_t const   ** __restrict  __src ,
                                size_t __nwc , size_t __len ,
                                mbstate_t * __restrict  __ps ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcpcpy)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcpncpy)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) fwprintf)(__FILE * __restrict  __stream ,
                              wchar_t const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) wprintf)(wchar_t const   * __restrict  __fmt  , ...) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) swprintf)(wchar_t * __restrict  __s ,
                              size_t __n , wchar_t const   * __restrict  __fmt 
                              , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vfwprintf)(__FILE * __restrict  __stream ,
                               wchar_t const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vwprintf)(wchar_t const   * __restrict  __fmt ,
                              __gnuc_va_list __ap ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) vswprintf)(wchar_t * __restrict  __s ,
                               size_t __n ,
                               wchar_t const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fgetws)(wchar_t * __restrict  __s ,
                            int __n , __FILE * __restrict  __stream ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fgetws_unlocked)(wchar_t * __restrict  __s ,
                                     int __n , __FILE * __restrict  __stream ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemcpy_chk)(wchar_t * __restrict  __s1 ,
                                                                                         wchar_t const   * __restrict  __s2 ,
                                                                                         size_t __n ,
                                                                                         size_t __ns1 ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemcpy_alias)(wchar_t * __restrict  __s1 ,
                                                                                           wchar_t const   * __restrict  __s2 ,
                                                                                           size_t __n )  __asm__("wmemcpy")  ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemcpy_chk_warn)(wchar_t * __restrict  __s1 ,
                                                                                              wchar_t const   * __restrict  __s2 ,
                                                                                              size_t __n ,
                                                                                              size_t __ns1 )  __asm__("__wmemcpy_chk") __attribute__((__warning__("wmemcpy called with length bigger than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wmemcpy)(wchar_t * __restrict  __s1 ,
                             wchar_t const   * __restrict  __s2 , size_t __n ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wmemcpy)(wchar_t * __restrict  __s1 ,
                             wchar_t const   * __restrict  __s2 , size_t __n ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  wchar_t *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__s1, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s1, 0);
    tmp___0 = __wmemcpy_chk(__s1, __s2, __n, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__s1, 0);
    if (__n > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__s1, 0);
      tmp___2 = __wmemcpy_chk_warn(__s1, __s2, __n, tmp___1 / sizeof(wchar_t ));
      return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wmemcpy_alias(__s1, __s2, __n);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemmove_chk)(wchar_t *__s1 ,
                                                                                          wchar_t const   *__s2 ,
                                                                                          size_t __n ,
                                                                                          size_t __ns1 ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemmove_alias)(wchar_t *__s1 ,
                                                                                            wchar_t const   *__s2 ,
                                                                                            size_t __n )  __asm__("wmemmove")  ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemmove_chk_warn)(wchar_t *__s1 ,
                                                                                               wchar_t const   *__s2 ,
                                                                                               size_t __n ,
                                                                                               size_t __ns1 )  __asm__("__wmemmove_chk") __attribute__((__warning__("wmemmove called with length bigger than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__, __always_inline__)) wmemmove)(wchar_t *__s1 ,
                                              wchar_t const   *__s2 ,
                                              size_t __n ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__, __always_inline__)) wmemmove)(wchar_t *__s1 ,
                                              wchar_t const   *__s2 ,
                                              size_t __n ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  wchar_t *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__s1, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s1, 0);
    tmp___0 = __wmemmove_chk(__s1, __s2, __n, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__s1, 0);
    if (__n > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__s1, 0);
      tmp___2 = __wmemmove_chk_warn(__s1, __s2, __n, tmp___1 / sizeof(wchar_t ));
      return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wmemmove_alias(__s1, __s2, __n);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmempcpy_chk)(wchar_t * __restrict  __s1 ,
                                                                                          wchar_t const   * __restrict  __s2 ,
                                                                                          size_t __n ,
                                                                                          size_t __ns1 ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmempcpy_alias)(wchar_t * __restrict  __s1 ,
                                                                                            wchar_t const   * __restrict  __s2 ,
                                                                                            size_t __n )  __asm__("wmempcpy")  ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmempcpy_chk_warn)(wchar_t * __restrict  __s1 ,
                                                                                               wchar_t const   * __restrict  __s2 ,
                                                                                               size_t __n ,
                                                                                               size_t __ns1 )  __asm__("__wmempcpy_chk") __attribute__((__warning__("wmempcpy called with length bigger than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wmempcpy)(wchar_t * __restrict  __s1 ,
                              wchar_t const   * __restrict  __s2 , size_t __n ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wmempcpy)(wchar_t * __restrict  __s1 ,
                              wchar_t const   * __restrict  __s2 , size_t __n ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  wchar_t *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__s1, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s1, 0);
    tmp___0 = __wmempcpy_chk(__s1, __s2, __n, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__s1, 0);
    if (__n > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__s1, 0);
      tmp___2 = __wmempcpy_chk_warn(__s1, __s2, __n, tmp___1 / sizeof(wchar_t ));
      return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wmempcpy_alias(__s1, __s2, __n);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemset_chk)(wchar_t *__s ,
                                                                                         wchar_t __c ,
                                                                                         size_t __n ,
                                                                                         size_t __ns ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemset_alias)(wchar_t *__s ,
                                                                                           wchar_t __c ,
                                                                                           size_t __n )  __asm__("wmemset")  ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemset_chk_warn)(wchar_t *__s ,
                                                                                              wchar_t __c ,
                                                                                              size_t __n ,
                                                                                              size_t __ns )  __asm__("__wmemset_chk") __attribute__((__warning__("wmemset called with length bigger than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__, __always_inline__)) wmemset)(wchar_t *__s , wchar_t __c ,
                                             size_t __n ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__, __always_inline__)) wmemset)(wchar_t *__s , wchar_t __c ,
                                             size_t __n ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  wchar_t *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__s, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s, 0);
    tmp___0 = __wmemset_chk(__s, __c, __n, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__s, 0);
    if (__n > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__s, 0);
      tmp___2 = __wmemset_chk_warn(__s, __c, __n, tmp___1 / sizeof(wchar_t ));
      return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wmemset_alias(__s, __c, __n);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcscpy_chk)(wchar_t * __restrict  __dest ,
                                                                                        wchar_t const   * __restrict  __src ,
                                                                                        size_t __n ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcscpy_alias)(wchar_t * __restrict  __dest ,
                                                                                          wchar_t const   * __restrict  __src )  __asm__("wcscpy")  ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcscpy)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcscpy)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__dest, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dest, 1);
    tmp___0 = __wcscpy_chk(__dest, __src, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
  } else {

  }
  tmp___2 = __wcscpy_alias(__dest, __src);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
}
}
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcpcpy_chk)(wchar_t * __restrict  __dest ,
                                                                                        wchar_t const   * __restrict  __src ,
                                                                                        size_t __destlen ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcpcpy_alias)(wchar_t * __restrict  __dest ,
                                                                                          wchar_t const   * __restrict  __src )  __asm__("wcpcpy")  ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcpcpy)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcpcpy)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__dest, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dest, 1);
    tmp___0 = __wcpcpy_chk(__dest, __src, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
  } else {

  }
  tmp___2 = __wcpcpy_alias(__dest, __src);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
}
}
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcsncpy_chk)(wchar_t * __restrict  __dest ,
                                                                                         wchar_t const   * __restrict  __src ,
                                                                                         size_t __n ,
                                                                                         size_t __destlen ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcsncpy_alias)(wchar_t * __restrict  __dest ,
                                                                                           wchar_t const   * __restrict  __src ,
                                                                                           size_t __n )  __asm__("wcsncpy")  ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcsncpy_chk_warn)(wchar_t * __restrict  __dest ,
                                                                                              wchar_t const   * __restrict  __src ,
                                                                                              size_t __n ,
                                                                                              size_t __destlen )  __asm__("__wcsncpy_chk") __attribute__((__warning__("wcsncpy called with length bigger than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcsncpy)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcsncpy)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  wchar_t *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__dest, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dest, 1);
    tmp___0 = __wcsncpy_chk(__dest, __src, __n, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__dest, 1);
    if (__n > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__dest, 1);
      tmp___2 = __wcsncpy_chk_warn(__dest, __src, __n,
                                   tmp___1 / sizeof(wchar_t ));
      return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wcsncpy_alias(__dest, __src, __n);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcpncpy_chk)(wchar_t * __restrict  __dest ,
                                                                                         wchar_t const   * __restrict  __src ,
                                                                                         size_t __n ,
                                                                                         size_t __destlen ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcpncpy_alias)(wchar_t * __restrict  __dest ,
                                                                                           wchar_t const   * __restrict  __src ,
                                                                                           size_t __n )  __asm__("wcpncpy")  ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcpncpy_chk_warn)(wchar_t * __restrict  __dest ,
                                                                                              wchar_t const   * __restrict  __src ,
                                                                                              size_t __n ,
                                                                                              size_t __destlen )  __asm__("__wcpncpy_chk") __attribute__((__warning__("wcpncpy called with length bigger than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcpncpy)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcpncpy)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  wchar_t *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__dest, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dest, 1);
    tmp___0 = __wcpncpy_chk(__dest, __src, __n, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__dest, 1);
    if (__n > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__dest, 1);
      tmp___2 = __wcpncpy_chk_warn(__dest, __src, __n,
                                   tmp___1 / sizeof(wchar_t ));
      return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wcpncpy_alias(__dest, __src, __n);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcscat_chk)(wchar_t * __restrict  __dest ,
                                                                                        wchar_t const   * __restrict  __src ,
                                                                                        size_t __destlen ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcscat_alias)(wchar_t * __restrict  __dest ,
                                                                                          wchar_t const   * __restrict  __src )  __asm__("wcscat")  ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcscat)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcscat)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__dest, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dest, 1);
    tmp___0 = __wcscat_chk(__dest, __src, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
  } else {

  }
  tmp___2 = __wcscat_alias(__dest, __src);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
}
}
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcsncat_chk)(wchar_t * __restrict  __dest ,
                                                                                         wchar_t const   * __restrict  __src ,
                                                                                         size_t __n ,
                                                                                         size_t __destlen ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcsncat_alias)(wchar_t * __restrict  __dest ,
                                                                                           wchar_t const   * __restrict  __src ,
                                                                                           size_t __n )  __asm__("wcsncat")  ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcsncat)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcsncat)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__dest, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dest, 1);
    tmp___0 = __wcsncat_chk(__dest, __src, __n, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
  } else {

  }
  tmp___2 = __wcsncat_alias(__dest, __src, __n);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__leaf__)) __swprintf_chk)(wchar_t * __restrict  __s ,
                                                                                     size_t __n ,
                                                                                     int __flag ,
                                                                                     size_t __s_len ,
                                                                                     wchar_t const   * __restrict  __format 
                                                                                     , ...) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__leaf__)) __swprintf_alias)(wchar_t * __restrict  __s ,
                                                                                       size_t __n ,
                                                                                       wchar_t const   * __restrict  __fmt 
                                                                                       , ...)  __asm__("swprintf")  ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) swprintf)(wchar_t * __restrict  __s ,
                              size_t __n , wchar_t const   * __restrict  __fmt 
                              , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) swprintf)(wchar_t * __restrict  __s ,
                              size_t __n , wchar_t const   * __restrict  __fmt 
                              , ...) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__s, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s, 1);
    tmp___0 = __swprintf_chk(__s, __n, 1, tmp / sizeof(wchar_t ), __fmt,
                             __builtin_va_arg_pack());
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
  } else {
    tmp = __builtin_object_size((void *)__s, 1);
    tmp___0 = __swprintf_chk(__s, __n, 1, tmp / sizeof(wchar_t ), __fmt,
                             __builtin_va_arg_pack());
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
  }
  tmp___2 = __swprintf_alias(__s, __n, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__leaf__)) __vswprintf_chk)(wchar_t * __restrict  __s ,
                                                                                      size_t __n ,
                                                                                      int __flag ,
                                                                                      size_t __s_len ,
                                                                                      wchar_t const   * __restrict  __format ,
                                                                                      __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__leaf__)) __vswprintf_alias)(wchar_t * __restrict  __s ,
                                                                                        size_t __n ,
                                                                                        wchar_t const   * __restrict  __fmt ,
                                                                                        __gnuc_va_list __ap )  __asm__("vswprintf")  ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) vswprintf)(wchar_t * __restrict  __s ,
                               size_t __n ,
                               wchar_t const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) vswprintf)(wchar_t * __restrict  __s ,
                               size_t __n ,
                               wchar_t const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__s, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s, 1);
    tmp___0 = __vswprintf_chk(__s, __n, 1, tmp / sizeof(wchar_t ), __fmt, __ap);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
  } else {
    tmp = __builtin_object_size((void *)__s, 1);
    tmp___0 = __vswprintf_chk(__s, __n, 1, tmp / sizeof(wchar_t ), __fmt, __ap);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
  }
  tmp___2 = __vswprintf_alias(__s, __n, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
extern int __fwprintf_chk(__FILE * __restrict  __stream , int __flag ,
                          wchar_t const   * __restrict  __format  , ...) ;
extern int __wprintf_chk(int __flag , wchar_t const   * __restrict  __format 
                         , ...) ;
extern int __vfwprintf_chk(__FILE * __restrict  __stream , int __flag ,
                           wchar_t const   * __restrict  __format ,
                           __gnuc_va_list __ap ) ;
extern int __vwprintf_chk(int __flag , wchar_t const   * __restrict  __format ,
                          __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) wprintf)(wchar_t const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __wprintf_chk(1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) fwprintf)(__FILE * __restrict  __stream ,
                              wchar_t const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __fwprintf_chk(__stream, 1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vwprintf)(wchar_t const   * __restrict  __fmt ,
                              __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __vwprintf_chk(1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vfwprintf)(__FILE * __restrict  __stream ,
                               wchar_t const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __vfwprintf_chk(__stream, 1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
extern wchar_t *( __attribute__((__warn_unused_result__)) __fgetws_chk)(wchar_t * __restrict  __s ,
                                                                        size_t __size ,
                                                                        int __n ,
                                                                        __FILE * __restrict  __stream ) ;
extern wchar_t *( __attribute__((__warn_unused_result__)) __fgetws_alias)(wchar_t * __restrict  __s ,
                                                                          int __n ,
                                                                          __FILE * __restrict  __stream )  __asm__("fgetws")  ;
extern wchar_t *( __attribute__((__warn_unused_result__)) __fgetws_chk_warn)(wchar_t * __restrict  __s ,
                                                                             size_t __size ,
                                                                             int __n ,
                                                                             __FILE * __restrict  __stream )  __asm__("__fgetws_chk") __attribute__((__warning__("fgetws called with bigger size than length of destination buffer"))) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fgetws)(wchar_t * __restrict  __s ,
                            int __n , __FILE * __restrict  __stream ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  wchar_t *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__s, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s, 1);
    tmp___0 = __fgetws_chk(__s, tmp / sizeof(wchar_t ), __n, __stream);
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__s, 1);
    if ((size_t )__n > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__s, 1);
      tmp___2 = __fgetws_chk_warn(__s, tmp___1 / sizeof(wchar_t ), __n, __stream);
      return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __fgetws_alias(__s, __n, __stream);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern wchar_t *( __attribute__((__warn_unused_result__)) __fgetws_unlocked_chk)(wchar_t * __restrict  __s ,
                                                                                 size_t __size ,
                                                                                 int __n ,
                                                                                 __FILE * __restrict  __stream ) ;
extern wchar_t *( __attribute__((__warn_unused_result__)) __fgetws_unlocked_alias)(wchar_t * __restrict  __s ,
                                                                                   int __n ,
                                                                                   __FILE * __restrict  __stream )  __asm__("fgetws_unlocked")  ;
extern wchar_t *( __attribute__((__warn_unused_result__)) __fgetws_unlocked_chk_warn)(wchar_t * __restrict  __s ,
                                                                                      size_t __size ,
                                                                                      int __n ,
                                                                                      __FILE * __restrict  __stream )  __asm__("__fgetws_unlocked_chk") __attribute__((__warning__("fgetws_unlocked called with bigger size than length of destination buffer"))) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fgetws_unlocked)(wchar_t * __restrict  __s ,
                                     int __n , __FILE * __restrict  __stream ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  wchar_t *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__s, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s, 1);
    tmp___0 = __fgetws_unlocked_chk(__s, tmp / sizeof(wchar_t ), __n, __stream);
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__s, 1);
    if ((size_t )__n > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__s, 1);
      tmp___2 = __fgetws_unlocked_chk_warn(__s, tmp___1 / sizeof(wchar_t ), __n,
                                           __stream);
      return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __fgetws_unlocked_alias(__s, __n, __stream);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__warn_unused_result__,
__leaf__)) __wcrtomb_chk)(char * __restrict  __s , wchar_t __wchar ,
                          mbstate_t * __restrict  __p , size_t __buflen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__warn_unused_result__,
__leaf__)) __wcrtomb_alias)(char * __restrict  __s , wchar_t __wchar ,
                            mbstate_t * __restrict  __ps )  __asm__("wcrtomb")  ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) wcrtomb)(char * __restrict  __s , wchar_t __wchar ,
                             mbstate_t * __restrict  __ps ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) wcrtomb)(char * __restrict  __s , wchar_t __wchar ,
                             mbstate_t * __restrict  __ps ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  unsigned long tmp___2 ;
  size_t tmp___3 ;

  {
  tmp___1 = __builtin_object_size((void *)__s, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp___2 = __builtin_object_size((void *)__s, 1);
    if (16UL > tmp___2) {
      tmp = __builtin_object_size((void *)__s, 1);
      tmp___0 = __wcrtomb_chk(__s, __wchar, __ps, tmp);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    } else {

    }
  } else {

  }
  tmp___3 = __wcrtomb_alias(__s, __wchar, __ps);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___3);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbsrtowcs_chk)(wchar_t * __restrict  __dst ,
                                                                                         char const   ** __restrict  __src ,
                                                                                         size_t __len ,
                                                                                         mbstate_t * __restrict  __ps ,
                                                                                         size_t __dstlen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbsrtowcs_alias)(wchar_t * __restrict  __dst ,
                                                                                           char const   ** __restrict  __src ,
                                                                                           size_t __len ,
                                                                                           mbstate_t * __restrict  __ps )  __asm__("mbsrtowcs")  ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbsrtowcs_chk_warn)(wchar_t * __restrict  __dst ,
                                                                                              char const   ** __restrict  __src ,
                                                                                              size_t __len ,
                                                                                              mbstate_t * __restrict  __ps ,
                                                                                              size_t __dstlen )  __asm__("__mbsrtowcs_chk") __attribute__((__warning__("mbsrtowcs called with dst buffer smaller than len * sizeof (wchar_t)"))) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) mbsrtowcs)(wchar_t * __restrict  __dst ,
                               char const   ** __restrict  __src ,
                               size_t __len , mbstate_t * __restrict  __ps ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) mbsrtowcs)(wchar_t * __restrict  __dst ,
                               char const   ** __restrict  __src ,
                               size_t __len , mbstate_t * __restrict  __ps ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__dst, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dst, 1);
    tmp___0 = __mbsrtowcs_chk(__dst, __src, __len, __ps, tmp / sizeof(wchar_t ));
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__dst, 1);
    if (__len > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__dst, 1);
      tmp___2 = __mbsrtowcs_chk_warn(__dst, __src, __len, __ps,
                                     tmp___1 / sizeof(wchar_t ));
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __mbsrtowcs_alias(__dst, __src, __len, __ps);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcsrtombs_chk)(char * __restrict  __dst ,
                                                                                         wchar_t const   ** __restrict  __src ,
                                                                                         size_t __len ,
                                                                                         mbstate_t * __restrict  __ps ,
                                                                                         size_t __dstlen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcsrtombs_alias)(char * __restrict  __dst ,
                                                                                           wchar_t const   ** __restrict  __src ,
                                                                                           size_t __len ,
                                                                                           mbstate_t * __restrict  __ps )  __asm__("wcsrtombs")  ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcsrtombs_chk_warn)(char * __restrict  __dst ,
                                                                                              wchar_t const   ** __restrict  __src ,
                                                                                              size_t __len ,
                                                                                              mbstate_t * __restrict  __ps ,
                                                                                              size_t __dstlen )  __asm__("__wcsrtombs_chk") __attribute__((__warning__("wcsrtombs called with dst buffer smaller than len"))) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcsrtombs)(char * __restrict  __dst ,
                               wchar_t const   ** __restrict  __src ,
                               size_t __len , mbstate_t * __restrict  __ps ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcsrtombs)(char * __restrict  __dst ,
                               wchar_t const   ** __restrict  __src ,
                               size_t __len , mbstate_t * __restrict  __ps ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__dst, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dst, 1);
    tmp___0 = __wcsrtombs_chk(__dst, __src, __len, __ps, tmp);
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__dst, 1);
    if (__len > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__dst, 1);
      tmp___2 = __wcsrtombs_chk_warn(__dst, __src, __len, __ps, tmp___1);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wcsrtombs_alias(__dst, __src, __len, __ps);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbsnrtowcs_chk)(wchar_t * __restrict  __dst ,
                                                                                          char const   ** __restrict  __src ,
                                                                                          size_t __nmc ,
                                                                                          size_t __len ,
                                                                                          mbstate_t * __restrict  __ps ,
                                                                                          size_t __dstlen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbsnrtowcs_alias)(wchar_t * __restrict  __dst ,
                                                                                            char const   ** __restrict  __src ,
                                                                                            size_t __nmc ,
                                                                                            size_t __len ,
                                                                                            mbstate_t * __restrict  __ps )  __asm__("mbsnrtowcs")  ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbsnrtowcs_chk_warn)(wchar_t * __restrict  __dst ,
                                                                                               char const   ** __restrict  __src ,
                                                                                               size_t __nmc ,
                                                                                               size_t __len ,
                                                                                               mbstate_t * __restrict  __ps ,
                                                                                               size_t __dstlen )  __asm__("__mbsnrtowcs_chk") __attribute__((__warning__("mbsnrtowcs called with dst buffer smaller than len * sizeof (wchar_t)"))) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) mbsnrtowcs)(wchar_t * __restrict  __dst ,
                                char const   ** __restrict  __src ,
                                size_t __nmc , size_t __len ,
                                mbstate_t * __restrict  __ps ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) mbsnrtowcs)(wchar_t * __restrict  __dst ,
                                char const   ** __restrict  __src ,
                                size_t __nmc , size_t __len ,
                                mbstate_t * __restrict  __ps ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__dst, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dst, 1);
    tmp___0 = __mbsnrtowcs_chk(__dst, __src, __nmc, __len, __ps,
                               tmp / sizeof(wchar_t ));
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__dst, 1);
    if (__len > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__dst, 1);
      tmp___2 = __mbsnrtowcs_chk_warn(__dst, __src, __nmc, __len, __ps,
                                      tmp___1 / sizeof(wchar_t ));
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __mbsnrtowcs_alias(__dst, __src, __nmc, __len, __ps);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcsnrtombs_chk)(char * __restrict  __dst ,
                                                                                          wchar_t const   ** __restrict  __src ,
                                                                                          size_t __nwc ,
                                                                                          size_t __len ,
                                                                                          mbstate_t * __restrict  __ps ,
                                                                                          size_t __dstlen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcsnrtombs_alias)(char * __restrict  __dst ,
                                                                                            wchar_t const   ** __restrict  __src ,
                                                                                            size_t __nwc ,
                                                                                            size_t __len ,
                                                                                            mbstate_t * __restrict  __ps )  __asm__("wcsnrtombs")  ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcsnrtombs_chk_warn)(char * __restrict  __dst ,
                                                                                               wchar_t const   ** __restrict  __src ,
                                                                                               size_t __nwc ,
                                                                                               size_t __len ,
                                                                                               mbstate_t * __restrict  __ps ,
                                                                                               size_t __dstlen )  __asm__("__wcsnrtombs_chk") __attribute__((__warning__("wcsnrtombs called with dst buffer smaller than len"))) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcsnrtombs)(char * __restrict  __dst ,
                                wchar_t const   ** __restrict  __src ,
                                size_t __nwc , size_t __len ,
                                mbstate_t * __restrict  __ps ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcsnrtombs)(char * __restrict  __dst ,
                                wchar_t const   ** __restrict  __src ,
                                size_t __nwc , size_t __len ,
                                mbstate_t * __restrict  __ps ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__dst, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dst, 1);
    tmp___0 = __wcsnrtombs_chk(__dst, __src, __nwc, __len, __ps, tmp);
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__dst, 1);
    if (__len > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__dst, 1);
      tmp___2 = __wcsnrtombs_chk_warn(__dst, __src, __nwc, __len, __ps, tmp___1);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wcsnrtombs_alias(__dst, __src, __nwc, __len, __ps);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern void __attribute__((__visibility__("default")))  php_stat(char const   *filename ,
                                                                 php_stat_len filename_length ,
                                                                 int type ,
                                                                 zval *return_value ) ;
static zend_object_handlers spl_filesystem_object_handlers  ;
static zend_object_handlers spl_filesystem_object_check_handlers  ;
static void spl_filesystem_file_free_line(spl_filesystem_object *intern ) 
{ 


  {
  if (intern->u.file.current_line) {
    _efree((void *)intern->u.file.current_line);
    intern->u.file.current_line = (char *)((void *)0);
  } else {

  }
  if (intern->u.file.current_zval) {
    _zval_ptr_dtor(& intern->u.file.current_zval);
    intern->u.file.current_zval = (zval *)((void *)0);
  } else {

  }
  return;
}
}
static void spl_filesystem_object_free_storage(void *object ) 
{ 
  spl_filesystem_object *intern ;

  {
  intern = (spl_filesystem_object *)object;
  if (intern->oth_handler) {
    if ((intern->oth_handler)->dtor) {
      (*((intern->oth_handler)->dtor))(intern);
    } else {

    }
  } else {

  }
  zend_object_std_dtor(& intern->std);
  if (intern->_path) {
    _efree((void *)intern->_path);
  } else {

  }
  if (intern->file_name) {
    _efree((void *)intern->file_name);
  } else {

  }
  switch ((unsigned int )intern->type) {
  case 0U: 
  break;
  case 1U: 
  if (intern->u.dir.dirp) {
    _php_stream_free(intern->u.dir.dirp, 3);
    intern->u.dir.dirp = (php_stream *)((void *)0);
  } else {

  }
  if (intern->u.dir.sub_path) {
    _efree((void *)intern->u.dir.sub_path);
  } else {

  }
  break;
  case 2U: 
  if (intern->u.file.stream) {
    if (! (intern->u.file.stream)->is_persistent) {
      _php_stream_free(intern->u.file.stream, 3);
    } else {
      _php_stream_free(intern->u.file.stream, 19);
    }
    if (intern->u.file.open_mode) {
      _efree((void *)intern->u.file.open_mode);
    } else {

    }
    if (intern->orig_path) {
      _efree((void *)intern->orig_path);
    } else {

    }
  } else {

  }
  spl_filesystem_file_free_line(intern);
  break;
  }
  _efree(object);
  return;
}
}
static zend_object_value spl_filesystem_object_new_ex(zend_class_entry *class_type ,
                                                      spl_filesystem_object **obj ) 
{ 
  zend_object_value retval ;
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_object_handle __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = _emalloc(sizeof(spl_filesystem_object ));
  intern = (spl_filesystem_object *)tmp;
  memset((void *)intern, 0, sizeof(spl_filesystem_object ));
  intern->file_class = (zend_class_entry *)spl_ce_SplFileObject;
  intern->info_class = (zend_class_entry *)spl_ce_SplFileInfo;
  if (obj) {
    *obj = intern;
  } else {

  }
  zend_object_std_init(& intern->std, class_type);
  object_properties_init(& intern->std, class_type);
  tmp___0 = zend_objects_store_put((void *)intern,
                                   (void (*)(void *object ,
                                             zend_object_handle handle ))(& zend_objects_destroy_object),
                                   & spl_filesystem_object_free_storage,
                                   (void (*)(void *object , void **object_clone ))((void *)0));
  retval.handle = (zend_object_handle )tmp___0;
  retval.handlers = (zend_object_handlers const   *)(& spl_filesystem_object_handlers);
  return (retval);
}
}
static zend_object_value spl_filesystem_object_new(zend_class_entry *class_type ) 
{ 
  zend_object_value tmp ;

  {
  tmp = spl_filesystem_object_new_ex(class_type,
                                     (spl_filesystem_object **)((void *)0));
  return (tmp);
}
}
static zend_object_value spl_filesystem_object_new_check(zend_class_entry *class_type ) 
{ 
  zend_object_value ret ;
  zend_object_value tmp ;

  {
  tmp = spl_filesystem_object_new_ex(class_type,
                                     (spl_filesystem_object **)((void *)0));
  ret = tmp;
  ret.handlers = (zend_object_handlers const   *)(& spl_filesystem_object_check_handlers);
  return (ret);
}
}
char __attribute__((__visibility__("default")))  *spl_filesystem_object_get_path(spl_filesystem_object *intern ,
                                                                                 int *len ) 
{ 
  char __attribute__((__visibility__("default")))  *tmp ;

  {
  if ((unsigned int )intern->type == 1U) {
    if ((unsigned long )(intern->u.dir.dirp)->ops == (unsigned long )(& php_glob_stream_ops)) {
      tmp = _php_glob_stream_get_path(intern->u.dir.dirp, 0, len);
      return (tmp);
    } else {

    }
  } else {

  }
  if (len) {
    *len = intern->_path_len;
  } else {

  }
  return ((char __attribute__((__visibility__("default")))  *)intern->_path);
}
}
__inline static void spl_filesystem_object_get_file_name(spl_filesystem_object *intern ) 
{ 
  char slash ;
  int tmp___0 ;
  int tmp___1 ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;
  int __attribute__((__visibility__("default")))  tmp___3 ;

  {
  if (intern->flags & 8192L) {
    tmp___1 = 1;
  } else {
    tmp___1 = 0;
  }
  if (tmp___1) {
    tmp___0 = '/';
  } else {
    tmp___0 = '/';
  }
  slash = (char )tmp___0;
  if (! intern->file_name) {
    switch ((unsigned int )intern->type) {
    case 0U: 
    case 2U: 
    php_error_docref0((char const   *)((void *)0), 1, "Object not initialized");
    break;
    case 1U: 
    tmp___2 = spl_filesystem_object_get_path(intern, (int *)((void *)0));
    tmp___3 = spprintf(& intern->file_name, (size_t )0, "%s%c%s", tmp___2,
                       (int )slash, intern->u.dir.entry.d_name);
    intern->file_name_len = (int )tmp___3;
    break;
    }
  } else {

  }
  return;
}
}
static int spl_filesystem_dir_read(spl_filesystem_object *intern ) 
{ 
  php_stream_dirent __attribute__((__visibility__("default")))  *tmp ;

  {
  if (! intern->u.dir.dirp) {
    intern->u.dir.entry.d_name[0] = (char )'\000';
    return (0);
  } else {
    tmp = _php_stream_readdir(intern->u.dir.dirp, & intern->u.dir.entry);
    if (tmp) {
      return (1);
    } else {
      intern->u.dir.entry.d_name[0] = (char )'\000';
      return (0);
    }
  }
}
}
__inline static int spl_filesystem_is_dot(char const   *d_name ) 
{ 
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp___0 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  size_t __s1_len___0 ;
  size_t __s2_len___0 ;
  int tmp___7 ;
  int tmp___10 ;
  int tmp___11 ;
  int tmp___12 ;
  int tmp___13 ;

  {
  if (0) {
    __s1_len = __builtin_strlen(d_name);
    __s2_len = __builtin_strlen(".");
    if (! ((size_t )((void const   *)(d_name + 1)) - (size_t )((void const   *)d_name) == 1UL)) {
      goto _L___0;
    } else
    if (__s1_len >= 4UL) {
      _L___0: 
      if (! ((size_t )((void const   *)("." + 1)) - (size_t )((void const   *)".") == 1UL)) {
        tmp___5 = 1;
      } else
      if (__s2_len >= 4UL) {
        tmp___5 = 1;
      } else {
        tmp___5 = 0;
      }
    } else {
      tmp___5 = 0;
    }
    if (tmp___5) {
      tmp___0 = __builtin_strcmp(d_name, ".");
      tmp___4 = tmp___0;
    } else {
      tmp___3 = __builtin_strcmp(d_name, ".");
      tmp___4 = tmp___3;
    }
  } else {
    tmp___3 = __builtin_strcmp(d_name, ".");
    tmp___4 = tmp___3;
  }
  if (tmp___4) {
    if (0) {
      __s1_len___0 = __builtin_strlen(d_name);
      __s2_len___0 = __builtin_strlen("..");
      if (! ((size_t )((void const   *)(d_name + 1)) - (size_t )((void const   *)d_name) == 1UL)) {
        goto _L___2;
      } else
      if (__s1_len___0 >= 4UL) {
        _L___2: 
        if (! ((size_t )((void const   *)(".." + 1)) - (size_t )((void const   *)"..") == 1UL)) {
          tmp___12 = 1;
        } else
        if (__s2_len___0 >= 4UL) {
          tmp___12 = 1;
        } else {
          tmp___12 = 0;
        }
      } else {
        tmp___12 = 0;
      }
      if (tmp___12) {
        tmp___7 = __builtin_strcmp(d_name, "..");
        tmp___11 = tmp___7;
      } else {
        tmp___10 = __builtin_strcmp(d_name, "..");
        tmp___11 = tmp___10;
      }
    } else {
      tmp___10 = __builtin_strcmp(d_name, "..");
      tmp___11 = tmp___10;
    }
    if (tmp___11) {
      tmp___13 = 0;
    } else {
      tmp___13 = 1;
    }
  } else {
    tmp___13 = 1;
  }
  return (tmp___13);
}
}
static void spl_filesystem_dir_open(spl_filesystem_object *intern , char *path ) 
{ 
  int skip_dots ;
  int tmp ;
  size_t tmp___0 ;
  php_stream __attribute__((__visibility__("default")))  *tmp___1 ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;
  char __attribute__((__visibility__("default")))  *tmp___3 ;
  int tmp___4 ;

  {
  if (intern->flags & 4096L) {
    tmp = 1;
  } else {
    tmp = 0;
  }
  skip_dots = tmp;
  intern->type = (SPL_FS_OBJ_TYPE )1;
  tmp___0 = strlen((char const   *)path);
  intern->_path_len = (int )tmp___0;
  tmp___1 = _php_stream_opendir(path, 8, file_globals.default_context);
  intern->u.dir.dirp = (php_stream *)tmp___1;
  if (intern->_path_len > 1) {
    if ((int )*(path + (intern->_path_len - 1)) == 47) {
      (intern->_path_len) --;
      tmp___2 = _estrndup((char const   *)path, (unsigned int )intern->_path_len);
      intern->_path = (char *)tmp___2;
    } else {
      tmp___3 = _estrndup((char const   *)path, (unsigned int )intern->_path_len);
      intern->_path = (char *)tmp___3;
    }
  } else {
    tmp___3 = _estrndup((char const   *)path, (unsigned int )intern->_path_len);
    intern->_path = (char *)tmp___3;
  }
  intern->u.dir.index = 0;
  if (executor_globals.exception) {
    goto _L;
  } else
  if ((unsigned long )intern->u.dir.dirp == (unsigned long )((void *)0)) {
    _L: 
    intern->u.dir.entry.d_name[0] = (char )'\000';
    if (! executor_globals.exception) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_UnexpectedValueException,
                              0L, (char *)"Failed to open directory \"%s\"",
                              path);
    } else {

    }
  } else {
    while (1) {
      spl_filesystem_dir_read(intern);
      if (skip_dots) {
        tmp___4 = spl_filesystem_is_dot((char const   *)(intern->u.dir.entry.d_name));
        if (! tmp___4) {
          break;
        } else {

        }
      } else {
        break;
      }
    }
  }
  return;
}
}
static int spl_filesystem_file_open(spl_filesystem_object *intern ,
                                    int use_include_path , int silent ) 
{ 
  zval tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  php_stream_context __attribute__((__visibility__("default")))  *tmp___2 ;
  php_stream_context *tmp___3 ;
  int tmp___4 ;
  php_stream __attribute__((__visibility__("default")))  *tmp___5 ;
  char const   *tmp___6 ;
  size_t tmp___7 ;
  char __attribute__((__visibility__("default")))  *tmp___8 ;
  char __attribute__((__visibility__("default")))  *tmp___9 ;
  char __attribute__((__visibility__("default")))  *tmp___10 ;
  zval *__z ;

  {
  intern->type = (SPL_FS_OBJ_TYPE )2;
  php_stat((char const   *)intern->file_name, intern->file_name_len, 13, & tmp);
  if (tmp.value.lval) {
    intern->u.file.open_mode = (char *)((void *)0);
    intern->file_name = (char *)((void *)0);
    zend_throw_exception_ex((zend_class_entry *)spl_ce_LogicException, 0L,
                            (char *)"Cannot use SplFileObject with directories");
    return (-1);
  } else {

  }
  if (intern->u.file.zcontext) {
    tmp___0 = php_le_stream_context();
    tmp___1 = zend_fetch_resource(& intern->u.file.zcontext, -1,
                                  "Stream-Context", (int *)((void *)0), 1,
                                  tmp___0);
    intern->u.file.context = (php_stream_context *)tmp___1;
  } else {
    if (file_globals.default_context) {
      tmp___3 = file_globals.default_context;
    } else {
      tmp___2 = php_stream_context_alloc();
      file_globals.default_context = (php_stream_context *)tmp___2;
      tmp___3 = file_globals.default_context;
    }
    intern->u.file.context = tmp___3;
  }
  if (use_include_path) {
    tmp___4 = 1;
  } else {
    tmp___4 = 0;
  }
  tmp___5 = _php_stream_open_wrapper_ex(intern->file_name,
                                        intern->u.file.open_mode, tmp___4 | 8,
                                        (char **)((void *)0),
                                        intern->u.file.context);
  intern->u.file.stream = (php_stream *)tmp___5;
  if (! intern->file_name_len) {
    goto _L;
  } else
  if (! intern->u.file.stream) {
    _L: 
    if (! executor_globals.exception) {
      if (intern->file_name_len) {
        tmp___6 = (char const   *)intern->file_name;
      } else {
        tmp___6 = "";
      }
      zend_throw_exception_ex((zend_class_entry *)spl_ce_RuntimeException, 0L,
                              (char *)"Cannot open file \'%s\'", tmp___6);
    } else {

    }
    intern->file_name = (char *)((void *)0);
    intern->u.file.open_mode = (char *)((void *)0);
    return (-1);
  } else {

  }
  if (intern->u.file.zcontext) {
    _zend_list_addref((int )(intern->u.file.zcontext)->value.lval);
  } else {

  }
  if (intern->file_name_len > 1) {
    if ((int )*(intern->file_name + (intern->file_name_len - 1)) == 47) {
      (intern->file_name_len) --;
    } else {

    }
  } else {

  }
  tmp___7 = strlen((char const   *)(intern->u.file.stream)->orig_path);
  tmp___8 = _estrndup((char const   *)(intern->u.file.stream)->orig_path,
                      (unsigned int )tmp___7);
  intern->orig_path = (char *)tmp___8;
  tmp___9 = _estrndup((char const   *)intern->file_name,
                      (unsigned int )intern->file_name_len);
  intern->file_name = (char *)tmp___9;
  tmp___10 = _estrndup((char const   *)intern->u.file.open_mode,
                       (unsigned int )intern->u.file.open_mode_len);
  intern->u.file.open_mode = (char *)tmp___10;
  while (1) {
    __z = & intern->u.file.zresource;
    __z->value.lval = (long )(intern->u.file.stream)->rsrc_id;
    __z->type = (zend_uchar )7;
    break;
  }
  zval_set_refcount_p(& intern->u.file.zresource, (zend_uint )1);
  intern->u.file.delimiter = (char )',';
  intern->u.file.enclosure = (char )'\"';
  intern->u.file.escape = (char )'\\';
  zend_hash_find((HashTable const   *)(& (intern->std.ce)->function_table),
                 "getcurrentline", (uint )sizeof("getcurrentline"),
                 (void **)(& intern->u.file.func_getCurr));
  return (0);
}
}
static zend_object_value spl_filesystem_object_clone(zval *zobject ) 
{ 
  zend_object_value new_obj_val ;
  zend_object *old_object ;
  zend_object *new_object ;
  zend_object_handle handle ;
  spl_filesystem_object *intern ;
  spl_filesystem_object *source ;
  int index___0 ;
  int skip_dots ;
  zend_object __attribute__((__visibility__("default")))  *tmp ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  int tmp___2 ;

  {
  handle = zobject->value.obj.handle;
  tmp = zend_objects_get_address((zval const   *)zobject);
  old_object = (zend_object *)tmp;
  source = (spl_filesystem_object *)old_object;
  new_obj_val = spl_filesystem_object_new_ex(old_object->ce, & intern);
  new_object = & intern->std;
  intern->flags = source->flags;
  switch ((unsigned int )source->type) {
  case 0U: 
  intern->_path_len = source->_path_len;
  tmp___0 = _estrndup((char const   *)source->_path,
                      (unsigned int )source->_path_len);
  intern->_path = (char *)tmp___0;
  intern->file_name_len = source->file_name_len;
  tmp___1 = _estrndup((char const   *)source->file_name,
                      (unsigned int )intern->file_name_len);
  intern->file_name = (char *)tmp___1;
  break;
  case 1U: 
  spl_filesystem_dir_open(intern, source->_path);
  if (source->flags & 4096L) {
    skip_dots = 1;
  } else {
    skip_dots = 0;
  }
  index___0 = 0;
  while (index___0 < source->u.dir.index) {
    while (1) {
      spl_filesystem_dir_read(intern);
      if (skip_dots) {
        tmp___2 = spl_filesystem_is_dot((char const   *)(intern->u.dir.entry.d_name));
        if (! tmp___2) {
          break;
        } else {

        }
      } else {
        break;
      }
    }
    index___0 ++;
  }
  intern->u.dir.index = index___0;
  break;
  case 2U: 
  php_error_docref0((char const   *)((void *)0), 1,
                    "An object of class %s cannot be cloned",
                    (old_object->ce)->name);
  break;
  }
  intern->file_class = source->file_class;
  intern->info_class = source->info_class;
  intern->oth = source->oth;
  intern->oth_handler = source->oth_handler;
  zend_objects_clone_members(new_object, new_obj_val, old_object, handle);
  if (intern->oth_handler) {
    if ((intern->oth_handler)->clone) {
      (*((intern->oth_handler)->clone))(source, intern);
    } else {

    }
  } else {

  }
  return (new_obj_val);
}
}
void spl_filesystem_info_set_filename(spl_filesystem_object *intern ,
                                      char *path , int len , int use_copy ) 
{ 
  char *p1 ;
  char *p2 ;
  char __attribute__((__visibility__("default")))  *tmp ;
  char *tmp___0 ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;

  {
  if (use_copy) {
    tmp = _estrndup((char const   *)path, (unsigned int )len);
    intern->file_name = (char *)tmp;
  } else {
    intern->file_name = path;
  }
  intern->file_name_len = len;
  while (1) {
    if ((int )*(intern->file_name + (intern->file_name_len - 1)) == 47) {
      if (! (intern->file_name_len > 1)) {
        break;
      } else {

      }
    } else {
      break;
    }
    *(intern->file_name + (intern->file_name_len - 1)) = (char)0;
    (intern->file_name_len) --;
  }
  p1 = strrchr((char const   *)intern->file_name, '/');
  p2 = (char *)0;
  if (p1) {
    goto _L;
  } else
  if (p2) {
    _L: 
    if ((unsigned long )p1 > (unsigned long )p2) {
      tmp___0 = p1;
    } else {
      tmp___0 = p2;
    }
    intern->_path_len = (int )(tmp___0 - intern->file_name);
  } else {
    intern->_path_len = 0;
  }
  tmp___1 = _estrndup((char const   *)path, (unsigned int )intern->_path_len);
  intern->_path = (char *)tmp___1;
  return;
}
}
static spl_filesystem_object *spl_filesystem_object_create_info(spl_filesystem_object *source ,
                                                                char *file_path ,
                                                                int file_path_len ,
                                                                int use_copy ,
                                                                zend_class_entry *ce ,
                                                                zval *return_value ) 
{ 
  spl_filesystem_object *intern ;
  zval *arg1 ;
  zend_error_handling error_handling ;
  void __attribute__((__visibility__("default")))  *tmp ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;

  {
  if (! file_path) {
    goto _L;
  } else
  if (! file_path_len) {
    _L: 
    if (file_path) {
      if (! use_copy) {
        _efree((void *)file_path);
      } else {

      }
    } else {

    }
    use_copy = 1;
    file_path_len = 1;
    file_path = (char *)"/";
    return ((spl_filesystem_object *)((void *)0));
  } else {

  }
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_RuntimeException,
                              & error_handling);
  if (ce) {
    ce = ce;
  } else {
    ce = source->info_class;
  }
  zend_update_class_constants(ce);
  return_value->value.obj = spl_filesystem_object_new_ex(ce, & intern);
  return_value->type = (zend_uchar )5;
  if ((unsigned long )(ce->constructor)->common.scope != (unsigned long )spl_ce_SplFileInfo) {
    while (1) {
      tmp = _emalloc(sizeof(zval_gc_info ));
      arg1 = (zval *)tmp;
      ((zval_gc_info *)arg1)->u.buffered = (gc_root_buffer *)((void *)0);
      break;
    }
    arg1->refcount__gc = (zend_uint )1;
    arg1->is_ref__gc = (zend_uchar )0;
    while (1) {
      __s = (char const   *)file_path;
      __l = file_path_len;
      __z = arg1;
      __z->value.str.len = __l;
      if (use_copy) {
        tmp___0 = _estrndup(__s, (unsigned int )__l);
        __z->value.str.val = (char *)tmp___0;
      } else {
        __z->value.str.val = (char *)__s;
      }
      __z->type = (zend_uchar )6;
      break;
    }
    zend_call_method(& return_value, ce, & ce->constructor, "__construct",
                     (int )(sizeof("__construct") - 1UL), (zval **)((void *)0),
                     1, arg1, (zval *)((void *)0));
    _zval_ptr_dtor(& arg1);
  } else {
    spl_filesystem_info_set_filename(intern, file_path, file_path_len, use_copy);
  }
  zend_restore_error_handling(& error_handling);
  return (intern);
}
}
static spl_filesystem_object *spl_filesystem_object_create_type(int ht ,
                                                                spl_filesystem_object *source ,
                                                                int type ,
                                                                zend_class_entry *ce ,
                                                                zval *return_value ) 
{ 
  spl_filesystem_object *intern ;
  zend_bool use_include_path ;
  zval *arg1 ;
  zval *arg2 ;
  zend_error_handling error_handling ;
  void __attribute__((__visibility__("default")))  *tmp ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;
  char __attribute__((__visibility__("default")))  *tmp___3 ;
  void __attribute__((__visibility__("default")))  *tmp___4 ;
  void __attribute__((__visibility__("default")))  *tmp___5 ;
  char const   *__s___0 ;
  int __l___0 ;
  zval *__z___0 ;
  char __attribute__((__visibility__("default")))  *tmp___6 ;
  char const   *__s___1 ;
  int __l___1 ;
  zval *__z___1 ;
  char __attribute__((__visibility__("default")))  *tmp___7 ;
  char __attribute__((__visibility__("default")))  *tmp___8 ;
  char __attribute__((__visibility__("default")))  *tmp___9 ;
  int __attribute__((__visibility__("default")))  tmp___10 ;
  int tmp___11 ;

  {
  use_include_path = (zend_bool )0;
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_RuntimeException,
                              & error_handling);
  switch ((unsigned int )source->type) {
  case 0U: 
  case 2U: 
  break;
  case 1U: 
  if (! source->u.dir.entry.d_name[0]) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_RuntimeException, 0L,
                            (char *)"Could not open file");
    zend_restore_error_handling(& error_handling);
    return ((spl_filesystem_object *)((void *)0));
  } else {

  }
  }
  switch (type) {
  case 0: 
  if (ce) {
    ce = ce;
  } else {
    ce = source->info_class;
  }
  zend_update_class_constants(ce);
  return_value->value.obj = spl_filesystem_object_new_ex(ce, & intern);
  return_value->type = (zend_uchar )5;
  spl_filesystem_object_get_file_name(source);
  if ((unsigned long )(ce->constructor)->common.scope != (unsigned long )spl_ce_SplFileInfo) {
    while (1) {
      tmp = _emalloc(sizeof(zval_gc_info ));
      arg1 = (zval *)tmp;
      ((zval_gc_info *)arg1)->u.buffered = (gc_root_buffer *)((void *)0);
      break;
    }
    arg1->refcount__gc = (zend_uint )1;
    arg1->is_ref__gc = (zend_uchar )0;
    while (1) {
      __s = (char const   *)source->file_name;
      __l = source->file_name_len;
      __z = arg1;
      __z->value.str.len = __l;
      tmp___0 = _estrndup(__s, (unsigned int )__l);
      __z->value.str.val = (char *)tmp___0;
      __z->type = (zend_uchar )6;
      break;
    }
    zend_call_method(& return_value, ce, & ce->constructor, "__construct",
                     (int )(sizeof("__construct") - 1UL), (zval **)((void *)0),
                     1, arg1, (zval *)((void *)0));
    _zval_ptr_dtor(& arg1);
  } else {
    tmp___1 = _estrndup((char const   *)source->file_name,
                        (unsigned int )source->file_name_len);
    intern->file_name = (char *)tmp___1;
    intern->file_name_len = source->file_name_len;
    tmp___2 = spl_filesystem_object_get_path(source, & intern->_path_len);
    intern->_path = (char *)tmp___2;
    tmp___3 = _estrndup((char const   *)intern->_path,
                        (unsigned int )intern->_path_len);
    intern->_path = (char *)tmp___3;
  }
  break;
  case 2: 
  if (ce) {
    ce = ce;
  } else {
    ce = source->file_class;
  }
  zend_update_class_constants(ce);
  return_value->value.obj = spl_filesystem_object_new_ex(ce, & intern);
  return_value->type = (zend_uchar )5;
  spl_filesystem_object_get_file_name(source);
  if ((unsigned long )(ce->constructor)->common.scope != (unsigned long )spl_ce_SplFileObject) {
    while (1) {
      tmp___4 = _emalloc(sizeof(zval_gc_info ));
      arg1 = (zval *)tmp___4;
      ((zval_gc_info *)arg1)->u.buffered = (gc_root_buffer *)((void *)0);
      break;
    }
    arg1->refcount__gc = (zend_uint )1;
    arg1->is_ref__gc = (zend_uchar )0;
    while (1) {
      tmp___5 = _emalloc(sizeof(zval_gc_info ));
      arg2 = (zval *)tmp___5;
      ((zval_gc_info *)arg2)->u.buffered = (gc_root_buffer *)((void *)0);
      break;
    }
    arg2->refcount__gc = (zend_uint )1;
    arg2->is_ref__gc = (zend_uchar )0;
    while (1) {
      __s___0 = (char const   *)source->file_name;
      __l___0 = source->file_name_len;
      __z___0 = arg1;
      __z___0->value.str.len = __l___0;
      tmp___6 = _estrndup(__s___0, (unsigned int )__l___0);
      __z___0->value.str.val = (char *)tmp___6;
      __z___0->type = (zend_uchar )6;
      break;
    }
    while (1) {
      __s___1 = "r";
      __l___1 = 1;
      __z___1 = arg2;
      __z___1->value.str.len = __l___1;
      tmp___7 = _estrndup(__s___1, (unsigned int )__l___1);
      __z___1->value.str.val = (char *)tmp___7;
      __z___1->type = (zend_uchar )6;
      break;
    }
    zend_call_method(& return_value, ce, & ce->constructor, "__construct",
                     (int )(sizeof("__construct") - 1UL), (zval **)((void *)0),
                     2, arg1, arg2);
    _zval_ptr_dtor(& arg1);
    _zval_ptr_dtor(& arg2);
  } else {
    intern->file_name = source->file_name;
    intern->file_name_len = source->file_name_len;
    tmp___8 = spl_filesystem_object_get_path(source, & intern->_path_len);
    intern->_path = (char *)tmp___8;
    tmp___9 = _estrndup((char const   *)intern->_path,
                        (unsigned int )intern->_path_len);
    intern->_path = (char *)tmp___9;
    intern->u.file.open_mode = (char *)"r";
    intern->u.file.open_mode_len = 1;
    if (ht) {
      tmp___10 = zend_parse_parameters(ht, "|sbr", & intern->u.file.open_mode,
                                       & intern->u.file.open_mode_len,
                                       & use_include_path,
                                       & intern->u.file.zcontext);
      if (tmp___10 == (int __attribute__((__visibility__("default")))  )-1) {
        zend_restore_error_handling(& error_handling);
        intern->u.file.open_mode = (char *)((void *)0);
        intern->file_name = (char *)((void *)0);
        _zval_dtor(return_value);
        return_value->type = (zend_uchar )0;
        return ((spl_filesystem_object *)((void *)0));
      } else {

      }
    } else {

    }
    tmp___11 = spl_filesystem_file_open(intern, (int )use_include_path, 0);
    if (tmp___11 == -1) {
      zend_restore_error_handling(& error_handling);
      _zval_dtor(return_value);
      return_value->type = (zend_uchar )0;
      return ((spl_filesystem_object *)((void *)0));
    } else {

    }
  }
  break;
  case 1: 
  zend_restore_error_handling(& error_handling);
  zend_throw_exception_ex((zend_class_entry *)spl_ce_RuntimeException, 0L,
                          (char *)"Operation not supported");
  return ((spl_filesystem_object *)((void *)0));
  }
  zend_restore_error_handling(& error_handling);
  return ((spl_filesystem_object *)((void *)0));
}
}
static int spl_filesystem_is_invalid_or_dot(char const   *d_name ) 
{ 
  int tmp ;
  int tmp___0 ;

  {
  if ((int const   )*(d_name + 0) == 0) {
    tmp___0 = 1;
  } else {
    tmp = spl_filesystem_is_dot(d_name);
    if (tmp) {
      tmp___0 = 1;
    } else {
      tmp___0 = 0;
    }
  }
  return (tmp___0);
}
}
static char *spl_filesystem_object_get_pathname(spl_filesystem_object *intern ,
                                                int *len ) 
{ 


  {
  switch ((unsigned int )intern->type) {
  case 0U: 
  case 2U: 
  *len = intern->file_name_len;
  return (intern->file_name);
  case 1U: 
  if (intern->u.dir.entry.d_name[0]) {
    spl_filesystem_object_get_file_name(intern);
    *len = intern->file_name_len;
    return (intern->file_name);
  } else {

  }
  }
  *len = 0;
  return ((char *)((void *)0));
}
}
static HashTable *spl_filesystem_object_get_debug_info(zval *obj , int *is_temp ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  HashTable *rv ;
  zval *tmp___0 ;
  zval zrv ;
  char *pnstr ;
  char *path ;
  int pnlen ;
  int path_len ;
  char stmp[2] ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  int __attribute__((__visibility__("default")))  tmp___2 ;

  {
  tmp = zend_object_store_get_object((zval const   *)obj);
  intern = (spl_filesystem_object *)tmp;
  *is_temp = 1;
  if (! intern->std.properties) {
    rebuild_object_properties(& intern->std);
  } else {

  }
  tmp___1 = _emalloc(sizeof(HashTable ));
  rv = (HashTable *)tmp___1;
  tmp___2 = zend_hash_num_elements((HashTable const   *)intern->std.properties);
  _zend_hash_init(rv,
                  (uint )(tmp___2 + (int __attribute__((__visibility__("default")))  )3),
                  (ulong (*)(char const   *arKey , uint nKeyLength ))((void *)0),
                  (void (*)(void * ))(& _zval_ptr_dtor), (zend_bool )0);
  zrv.refcount__gc = (zend_uint )1;
  zrv.is_ref__gc = (zend_uchar )0;
  zrv.value.ht = rv;
  zend_hash_copy(rv, intern->std.properties,
                 (void (*)(void *pElement ))(& zval_add_ref),
                 (void *)(& tmp___0), (uint )sizeof(zval *));
  pnstr = spl_gen_private_prop_name((zend_class_entry *)spl_ce_SplFileInfo,
                                    (char *)"pathName",
                                    (int )(sizeof("pathName") - 1UL), & pnlen);
  path = spl_filesystem_object_get_pathname(intern, & path_len);
  add_assoc_stringl_ex(& zrv, (char const   *)pnstr, (uint )(pnlen + 1), path,
                       (uint )path_len, 1);
  _efree((void *)pnstr);
  if (intern->file_name) {
    pnstr = spl_gen_private_prop_name((zend_class_entry *)spl_ce_SplFileInfo,
                                      (char *)"fileName",
                                      (int )(sizeof("fileName") - 1UL), & pnlen);
    spl_filesystem_object_get_path(intern, & path_len);
    if (path_len) {
      if (path_len < intern->file_name_len) {
        add_assoc_stringl_ex(& zrv, (char const   *)pnstr, (uint )(pnlen + 1),
                             (intern->file_name + path_len) + 1,
                             (uint )(intern->file_name_len - (path_len + 1)), 1);
      } else {
        add_assoc_stringl_ex(& zrv, (char const   *)pnstr, (uint )(pnlen + 1),
                             intern->file_name, (uint )intern->file_name_len, 1);
      }
    } else {
      add_assoc_stringl_ex(& zrv, (char const   *)pnstr, (uint )(pnlen + 1),
                           intern->file_name, (uint )intern->file_name_len, 1);
    }
    _efree((void *)pnstr);
  } else {

  }
  if ((unsigned int )intern->type == 1U) {
    pnstr = spl_gen_private_prop_name((zend_class_entry *)spl_ce_DirectoryIterator,
                                      (char *)"glob",
                                      (int )(sizeof("glob") - 1UL), & pnlen);
    if ((unsigned long )(intern->u.dir.dirp)->ops == (unsigned long )(& php_glob_stream_ops)) {
      add_assoc_stringl_ex(& zrv, (char const   *)pnstr, (uint )(pnlen + 1),
                           intern->_path, (uint )intern->_path_len, 1);
    } else {
      add_assoc_bool_ex(& zrv, (char const   *)pnstr, (uint )(pnlen + 1), 0);
    }
    _efree((void *)pnstr);
    pnstr = spl_gen_private_prop_name((zend_class_entry *)spl_ce_RecursiveDirectoryIterator,
                                      (char *)"subPathName",
                                      (int )(sizeof("subPathName") - 1UL),
                                      & pnlen);
    if (intern->u.dir.sub_path) {
      add_assoc_stringl_ex(& zrv, (char const   *)pnstr, (uint )(pnlen + 1),
                           intern->u.dir.sub_path,
                           (uint )intern->u.dir.sub_path_len, 1);
    } else {
      add_assoc_stringl_ex(& zrv, (char const   *)pnstr, (uint )(pnlen + 1),
                           (char *)"", (uint )0, 1);
    }
    _efree((void *)pnstr);
  } else {

  }
  if ((unsigned int )intern->type == 2U) {
    pnstr = spl_gen_private_prop_name((zend_class_entry *)spl_ce_SplFileObject,
                                      (char *)"openMode",
                                      (int )(sizeof("openMode") - 1UL), & pnlen);
    add_assoc_stringl_ex(& zrv, (char const   *)pnstr, (uint )(pnlen + 1),
                         intern->u.file.open_mode,
                         (uint )intern->u.file.open_mode_len, 1);
    _efree((void *)pnstr);
    stmp[1] = (char )'\000';
    stmp[0] = intern->u.file.delimiter;
    pnstr = spl_gen_private_prop_name((zend_class_entry *)spl_ce_SplFileObject,
                                      (char *)"delimiter",
                                      (int )(sizeof("delimiter") - 1UL), & pnlen);
    add_assoc_stringl_ex(& zrv, (char const   *)pnstr, (uint )(pnlen + 1), stmp,
                         (uint )1, 1);
    _efree((void *)pnstr);
    stmp[0] = intern->u.file.enclosure;
    pnstr = spl_gen_private_prop_name((zend_class_entry *)spl_ce_SplFileObject,
                                      (char *)"enclosure",
                                      (int )(sizeof("enclosure") - 1UL), & pnlen);
    add_assoc_stringl_ex(& zrv, (char const   *)pnstr, (uint )(pnlen + 1), stmp,
                         (uint )1, 1);
    _efree((void *)pnstr);
  } else {

  }
  return (rv);
}
}
zend_function *spl_filesystem_object_get_method_check(zval **object_ptr ,
                                                      char *method ,
                                                      int method_len ,
                                                      struct _zend_literal  const  *key ) 
{ 
  spl_filesystem_object *fsobj ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_object_handlers __attribute__((__visibility__("default")))  *tmp___0 ;
  union _zend_function *tmp___1 ;

  {
  tmp = zend_object_store_get_object((zval const   *)*object_ptr);
  fsobj = (spl_filesystem_object *)tmp;
  if ((int )fsobj->u.dir.entry.d_name[0] == 0) {
    if ((unsigned long )fsobj->orig_path == (unsigned long )((void *)0)) {
      method = (char *)"_bad_state_ex";
      method_len = (int )(sizeof("_bad_state_ex") - 1UL);
      key = (struct _zend_literal  const  *)((void *)0);
    } else {

    }
  } else {

  }
  tmp___0 = zend_get_std_object_handlers();
  tmp___1 = (*(tmp___0->get_method))(object_ptr, method, method_len, key);
  return (tmp___1);
}
}
void spl_filesystem_object_construct(int ht , zval *return_value ,
                                     zval **return_value_ptr , zval *this_ptr ,
                                     int return_value_used , long ctor_flags ) 
{ 
  spl_filesystem_object *intern ;
  char *path ;
  int parsed ;
  int len ;
  long flags ;
  zend_error_handling error_handling ;
  int __attribute__((__visibility__("default")))  tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  void __attribute__((__visibility__("default")))  *tmp___4 ;
  int tmp___5 ;
  char *tmp___6 ;
  zend_bool __attribute__((__visibility__("default")))  tmp___8 ;

  {
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_UnexpectedValueException,
                              & error_handling);
  if (ctor_flags & 1L) {
    tmp___1 = 1;
  } else {
    tmp___1 = 0;
  }
  if (tmp___1) {
    flags = 0L;
    tmp = zend_parse_parameters(ht, "s|l", & path, & len, & flags);
    parsed = (int )tmp;
  } else {
    flags = 16L;
    tmp___0 = zend_parse_parameters(ht, "s", & path, & len);
    parsed = (int )tmp___0;
  }
  if (ctor_flags & 4096L) {
    tmp___2 = 1;
  } else {
    tmp___2 = 0;
  }
  if (tmp___2) {
    flags |= 4096L;
  } else {

  }
  if (ctor_flags & 8192L) {
    tmp___3 = 1;
  } else {
    tmp___3 = 0;
  }
  if (tmp___3) {
    flags |= 8192L;
  } else {

  }
  if (parsed == -1) {
    zend_restore_error_handling(& error_handling);
    return;
  } else {

  }
  if (! len) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_RuntimeException, 0L,
                            (char *)"Directory name must not be empty.");
    zend_restore_error_handling(& error_handling);
    return;
  } else {

  }
  tmp___4 = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp___4;
  intern->flags = flags;
  if (ctor_flags & 2L) {
    tmp___5 = 1;
  } else {
    tmp___5 = 0;
  }
  if (tmp___5) {
    tmp___6 = strstr((char const   *)path, "glob://");
    if ((unsigned long )tmp___6 != (unsigned long )path) {
      spprintf(& path, (size_t )0, "glob://%s", path);
      spl_filesystem_dir_open(intern, path);
      _efree((void *)path);
    } else {
      spl_filesystem_dir_open(intern, path);
    }
  } else {
    spl_filesystem_dir_open(intern, path);
  }
  tmp___8 = instanceof_function((zend_class_entry const   *)intern->std.ce,
                                (zend_class_entry const   *)spl_ce_RecursiveDirectoryIterator);
  if (tmp___8) {
    intern->u.dir.is_recursive = 1;
  } else {
    intern->u.dir.is_recursive = 0;
  }
  zend_restore_error_handling(& error_handling);
  return;
}
}
void zim_spl_DirectoryIterator___construct(int ht , zval *return_value ,
                                           zval **return_value_ptr ,
                                           zval *this_ptr ,
                                           int return_value_used ) 
{ 


  {
  spl_filesystem_object_construct(ht, return_value, return_value_ptr, this_ptr,
                                  return_value_used, 0L);
  return;
}
}
void zim_spl_DirectoryIterator_rewind(int ht , zval *return_value ,
                                      zval **return_value_ptr , zval *this_ptr ,
                                      int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  intern->u.dir.index = 0;
  if (intern->u.dir.dirp) {
    _php_stream_seek(intern->u.dir.dirp, 0L, 0);
  } else {

  }
  spl_filesystem_dir_read(intern);
  return;
}
}
void zim_spl_DirectoryIterator_key(int ht , zval *return_value ,
                                   zval **return_value_ptr , zval *this_ptr ,
                                   int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z ;
  zval *__z___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (intern->u.dir.dirp) {
    __z = return_value;
    __z->value.lval = (long )intern->u.dir.index;
    __z->type = (zend_uchar )1;
    return;
  } else {
    while (1) {
      __z___0 = return_value;
      __z___0->value.lval = 0L;
      __z___0->type = (zend_uchar )3;
      break;
    }
    return;
  }
}
}
void zim_spl_DirectoryIterator_current(int ht , zval *return_value ,
                                       zval **return_value_ptr ,
                                       zval *this_ptr , int return_value_used ) 
{ 
  int __attribute__((__visibility__("default")))  tmp ;
  zend_uchar is_ref ;
  zend_bool tmp___0 ;
  zend_uint refcount ;
  zend_uint tmp___1 ;

  {
  tmp = zend_parse_parameters(ht, "");
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  tmp___0 = zval_isref_p(return_value);
  is_ref = tmp___0;
  tmp___1 = zval_refcount_p(return_value);
  refcount = tmp___1;
  while (1) {
    return_value->value = this_ptr->value;
    return_value->type = this_ptr->type;
    break;
  }
  _zval_copy_ctor(return_value);
  zval_set_isref_to_p(return_value, is_ref);
  zval_set_refcount_p(return_value, refcount);
  return;
}
}
void zim_spl_DirectoryIterator_next(int ht , zval *return_value ,
                                    zval **return_value_ptr , zval *this_ptr ,
                                    int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int skip_dots ;
  int tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;
  int tmp___2 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  if (intern->flags & 4096L) {
    tmp___0 = 1;
  } else {
    tmp___0 = 0;
  }
  skip_dots = tmp___0;
  tmp___1 = zend_parse_parameters(ht, "");
  if (tmp___1 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  (intern->u.dir.index) ++;
  while (1) {
    spl_filesystem_dir_read(intern);
    if (skip_dots) {
      tmp___2 = spl_filesystem_is_dot((char const   *)(intern->u.dir.entry.d_name));
      if (! tmp___2) {
        break;
      } else {

      }
    } else {
      break;
    }
  }
  if (intern->file_name) {
    _efree((void *)intern->file_name);
    intern->file_name = (char *)((void *)0);
  } else {

  }
  return;
}
}
void zim_spl_DirectoryIterator_seek(int ht , zval *return_value ,
                                    zval **return_value_ptr , zval *this_ptr ,
                                    int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval *retval ;
  long pos ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp___1 ;
  int valid ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp___2 ;
  int __attribute__((__visibility__("default")))  tmp___3 ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp___4 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  retval = (zval *)((void *)0);
  tmp___0 = zend_parse_parameters(ht, "l", & pos);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if ((long )intern->u.dir.index > pos) {
    tmp___1 = zend_get_class_entry((zval const   *)this_ptr);
    zend_call_method(& this_ptr, (zend_class_entry *)tmp___1,
                     & intern->u.dir.func_rewind, "rewind",
                     (int )(sizeof("rewind") - 1UL), & retval, 0,
                     (zval *)((void *)0), (zval *)((void *)0));
    if (retval) {
      _zval_ptr_dtor(& retval);
    } else {

    }
  } else {

  }
  while ((long )intern->u.dir.index < pos) {
    valid = 0;
    tmp___2 = zend_get_class_entry((zval const   *)this_ptr);
    zend_call_method(& this_ptr, (zend_class_entry *)tmp___2,
                     & intern->u.dir.func_valid, "valid",
                     (int )(sizeof("valid") - 1UL), & retval, 0,
                     (zval *)((void *)0), (zval *)((void *)0));
    if (retval) {
      tmp___3 = zend_is_true(retval);
      valid = (int )tmp___3;
      _zval_ptr_dtor(& retval);
    } else {

    }
    if (! valid) {
      break;
    } else {

    }
    tmp___4 = zend_get_class_entry((zval const   *)this_ptr);
    zend_call_method(& this_ptr, (zend_class_entry *)tmp___4,
                     & intern->u.dir.func_next, "next",
                     (int )(sizeof("next") - 1UL), & retval, 0,
                     (zval *)((void *)0), (zval *)((void *)0));
    if (retval) {
      _zval_ptr_dtor(& retval);
    } else {

    }
  }
  return;
}
}
void zim_spl_DirectoryIterator_valid(int ht , zval *return_value ,
                                     zval **return_value_ptr , zval *this_ptr ,
                                     int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  while (1) {
    __z = return_value;
    __z->value.lval = (long )(((int )intern->u.dir.entry.d_name[0] != 0) != 0);
    __z->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zim_spl_SplFileInfo_getPath(int ht , zval *return_value ,
                                 zval **return_value_ptr , zval *this_ptr ,
                                 int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  char *path ;
  int path_len ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  tmp___1 = spl_filesystem_object_get_path(intern, & path_len);
  path = (char *)tmp___1;
  while (1) {
    __s = (char const   *)path;
    __l = path_len;
    __z = return_value;
    __z->value.str.len = __l;
    tmp___2 = _estrndup(__s, (unsigned int )__l);
    __z->value.str.val = (char *)tmp___2;
    __z->type = (zend_uchar )6;
    break;
  }
  return;
}
}
void zim_spl_SplFileInfo_getFilename(int ht , zval *return_value ,
                                     zval **return_value_ptr , zval *this_ptr ,
                                     int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int path_len ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  char const   *__s___0 ;
  int __l___0 ;
  zval *__z___0 ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  spl_filesystem_object_get_path(intern, & path_len);
  if (path_len) {
    if (path_len < intern->file_name_len) {
      while (1) {
        __s = (char const   *)((intern->file_name + path_len) + 1);
        __l = intern->file_name_len - (path_len + 1);
        __z = return_value;
        __z->value.str.len = __l;
        tmp___1 = _estrndup(__s, (unsigned int )__l);
        __z->value.str.val = (char *)tmp___1;
        __z->type = (zend_uchar )6;
        break;
      }
      return;
    } else {
      goto _L;
    }
  } else {
    _L: 
    while (1) {
      __s___0 = (char const   *)intern->file_name;
      __l___0 = intern->file_name_len;
      __z___0 = return_value;
      __z___0->value.str.len = __l___0;
      tmp___2 = _estrndup(__s___0, (unsigned int )__l___0);
      __z___0->value.str.val = (char *)tmp___2;
      __z___0->type = (zend_uchar )6;
      break;
    }
    return;
  }
}
}
void zim_spl_DirectoryIterator_getFilename(int ht , zval *return_value ,
                                           zval **return_value_ptr ,
                                           zval *this_ptr ,
                                           int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  char const   *__s ;
  zval *__z ;
  size_t tmp___1 ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  while (1) {
    __s = (char const   *)(intern->u.dir.entry.d_name);
    __z = return_value;
    tmp___1 = strlen(__s);
    __z->value.str.len = (int )tmp___1;
    tmp___2 = _estrndup(__s, (unsigned int )__z->value.str.len);
    __z->value.str.val = (char *)tmp___2;
    __z->type = (zend_uchar )6;
    break;
  }
  return;
}
}
void zim_spl_SplFileInfo_getExtension(int ht , zval *return_value ,
                                      zval **return_value_ptr , zval *this_ptr ,
                                      int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  char *fname ;
  char const   *p ;
  size_t flen ;
  int path_len ;
  int idx ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  void const   *tmp___1 ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;
  zval *__z___0 ;
  char __attribute__((__visibility__("default")))  *tmp___3 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  fname = (char *)((void *)0);
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  spl_filesystem_object_get_path(intern, & path_len);
  if (path_len) {
    if (path_len < intern->file_name_len) {
      fname = (intern->file_name + path_len) + 1;
      flen = (size_t )(intern->file_name_len - (path_len + 1));
    } else {
      fname = intern->file_name;
      flen = (size_t )intern->file_name_len;
    }
  } else {
    fname = intern->file_name;
    flen = (size_t )intern->file_name_len;
  }
  php_basename((char const   *)fname, flen, (char *)((void *)0), (size_t )0,
               & fname, & flen);
  tmp___1 = zend_memrchr((void const   *)fname, '.', flen);
  p = (char const   *)tmp___1;
  if (p) {
    idx = (int )(p - (char const   *)fname);
    while (1) {
      __s = (char const   *)((fname + idx) + 1);
      __l = (int )((flen - (size_t )idx) - 1UL);
      __z = return_value;
      __z->value.str.len = __l;
      tmp___2 = _estrndup(__s, (unsigned int )__l);
      __z->value.str.val = (char *)tmp___2;
      __z->type = (zend_uchar )6;
      break;
    }
    _efree((void *)fname);
    return;
  } else {
    if (fname) {
      _efree((void *)fname);
    } else {

    }
    while (1) {
      __z___0 = return_value;
      __z___0->value.str.len = 0;
      tmp___3 = _estrndup("", (unsigned int )(sizeof("") - 1UL));
      __z___0->value.str.val = (char *)tmp___3;
      __z___0->type = (zend_uchar )6;
      break;
    }
    return;
  }
}
}
void zim_spl_DirectoryIterator_getExtension(int ht , zval *return_value ,
                                            zval **return_value_ptr ,
                                            zval *this_ptr ,
                                            int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  char *fname ;
  char const   *p ;
  size_t flen ;
  int idx ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  size_t tmp___1 ;
  void const   *tmp___2 ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___3 ;
  zval *__z___0 ;
  char __attribute__((__visibility__("default")))  *tmp___4 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  fname = (char *)((void *)0);
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  tmp___1 = strlen((char const   *)(intern->u.dir.entry.d_name));
  php_basename((char const   *)(intern->u.dir.entry.d_name), tmp___1,
               (char *)((void *)0), (size_t )0, & fname, & flen);
  tmp___2 = zend_memrchr((void const   *)fname, '.', flen);
  p = (char const   *)tmp___2;
  if (p) {
    idx = (int )(p - (char const   *)fname);
    while (1) {
      __s = (char const   *)((fname + idx) + 1);
      __l = (int )((flen - (size_t )idx) - 1UL);
      __z = return_value;
      __z->value.str.len = __l;
      tmp___3 = _estrndup(__s, (unsigned int )__l);
      __z->value.str.val = (char *)tmp___3;
      __z->type = (zend_uchar )6;
      break;
    }
    _efree((void *)fname);
    return;
  } else {
    if (fname) {
      _efree((void *)fname);
    } else {

    }
    while (1) {
      __z___0 = return_value;
      __z___0->value.str.len = 0;
      tmp___4 = _estrndup("", (unsigned int )(sizeof("") - 1UL));
      __z___0->value.str.val = (char *)tmp___4;
      __z___0->type = (zend_uchar )6;
      break;
    }
    return;
  }
}
}
void zim_spl_SplFileInfo_getBasename(int ht , zval *return_value ,
                                     zval **return_value_ptr , zval *this_ptr ,
                                     int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  char *fname ;
  char *suffix ;
  size_t flen ;
  int slen ;
  int path_len ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  char const   *__s ;
  int __l ;
  zval *__z ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  suffix = (char *)0;
  slen = 0;
  tmp___0 = zend_parse_parameters(ht, "|s", & suffix, & slen);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  spl_filesystem_object_get_path(intern, & path_len);
  if (path_len) {
    if (path_len < intern->file_name_len) {
      fname = (intern->file_name + path_len) + 1;
      flen = (size_t )(intern->file_name_len - (path_len + 1));
    } else {
      fname = intern->file_name;
      flen = (size_t )intern->file_name_len;
    }
  } else {
    fname = intern->file_name;
    flen = (size_t )intern->file_name_len;
  }
  php_basename((char const   *)fname, flen, suffix, (size_t )slen, & fname,
               & flen);
  while (1) {
    __s = (char const   *)fname;
    __l = (int )flen;
    __z = return_value;
    __z->value.str.len = __l;
    __z->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z->type = (zend_uchar )6;
    break;
  }
  return;
}
}
void zim_spl_DirectoryIterator_getBasename(int ht , zval *return_value ,
                                           zval **return_value_ptr ,
                                           zval *this_ptr ,
                                           int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  char *suffix ;
  char *fname ;
  int slen ;
  size_t flen ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  size_t tmp___1 ;
  char const   *__s ;
  int __l ;
  zval *__z ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  suffix = (char *)0;
  slen = 0;
  tmp___0 = zend_parse_parameters(ht, "|s", & suffix, & slen);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  tmp___1 = strlen((char const   *)(intern->u.dir.entry.d_name));
  php_basename((char const   *)(intern->u.dir.entry.d_name), tmp___1, suffix,
               (size_t )slen, & fname, & flen);
  while (1) {
    __s = (char const   *)fname;
    __l = (int )flen;
    __z = return_value;
    __z->value.str.len = __l;
    __z->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z->type = (zend_uchar )6;
    break;
  }
  return;
}
}
void zim_spl_SplFileInfo_getPathname(int ht , zval *return_value ,
                                     zval **return_value_ptr , zval *this_ptr ,
                                     int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  char *path ;
  int path_len ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  zval *__z___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  path = spl_filesystem_object_get_pathname(intern, & path_len);
  if ((unsigned long )path != (unsigned long )((void *)0)) {
    while (1) {
      __s = (char const   *)path;
      __l = path_len;
      __z = return_value;
      __z->value.str.len = __l;
      tmp___1 = _estrndup(__s, (unsigned int )__l);
      __z->value.str.val = (char *)tmp___1;
      __z->type = (zend_uchar )6;
      break;
    }
    return;
  } else {
    while (1) {
      __z___0 = return_value;
      __z___0->value.lval = 0L;
      __z___0->type = (zend_uchar )3;
      break;
    }
    return;
  }
}
}
void zim_spl_FilesystemIterator_key(int ht , zval *return_value ,
                                    zval **return_value_ptr , zval *this_ptr ,
                                    int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  char const   *__s ;
  zval *__z ;
  size_t tmp___1 ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;
  char const   *__s___0 ;
  int __l ;
  zval *__z___0 ;
  char __attribute__((__visibility__("default")))  *tmp___3 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if ((intern->flags & 3840L) == 256L) {
    while (1) {
      __s = (char const   *)(intern->u.dir.entry.d_name);
      __z = return_value;
      tmp___1 = strlen(__s);
      __z->value.str.len = (int )tmp___1;
      tmp___2 = _estrndup(__s, (unsigned int )__z->value.str.len);
      __z->value.str.val = (char *)tmp___2;
      __z->type = (zend_uchar )6;
      break;
    }
    return;
  } else {
    spl_filesystem_object_get_file_name(intern);
    while (1) {
      __s___0 = (char const   *)intern->file_name;
      __l = intern->file_name_len;
      __z___0 = return_value;
      __z___0->value.str.len = __l;
      tmp___3 = _estrndup(__s___0, (unsigned int )__l);
      __z___0->value.str.val = (char *)tmp___3;
      __z___0->type = (zend_uchar )6;
      break;
    }
    return;
  }
}
}
void zim_spl_FilesystemIterator_current(int ht , zval *return_value ,
                                        zval **return_value_ptr ,
                                        zval *this_ptr , int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  zend_uchar is_ref ;
  zend_bool tmp___2 ;
  zend_uint refcount ;
  zend_uint tmp___3 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if ((intern->flags & 240L) == 32L) {
    spl_filesystem_object_get_file_name(intern);
    while (1) {
      __s = (char const   *)intern->file_name;
      __l = intern->file_name_len;
      __z = return_value;
      __z->value.str.len = __l;
      tmp___1 = _estrndup(__s, (unsigned int )__l);
      __z->value.str.val = (char *)tmp___1;
      __z->type = (zend_uchar )6;
      break;
    }
    return;
  } else
  if ((intern->flags & 240L) == 0L) {
    spl_filesystem_object_get_file_name(intern);
    spl_filesystem_object_create_type(0, intern, 0,
                                      (zend_class_entry *)((void *)0),
                                      return_value);
  } else {
    tmp___2 = zval_isref_p(return_value);
    is_ref = tmp___2;
    tmp___3 = zval_refcount_p(return_value);
    refcount = tmp___3;
    while (1) {
      return_value->value = this_ptr->value;
      return_value->type = this_ptr->type;
      break;
    }
    _zval_copy_ctor(return_value);
    zval_set_isref_to_p(return_value, is_ref);
    zval_set_refcount_p(return_value, refcount);
    return;
  }
  return;
}
}
void zim_spl_DirectoryIterator_isDot(int ht , zval *return_value ,
                                     zval **return_value_ptr , zval *this_ptr ,
                                     int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z ;
  int tmp___1 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  while (1) {
    __z = return_value;
    tmp___1 = spl_filesystem_is_dot((char const   *)(intern->u.dir.entry.d_name));
    __z->value.lval = (long )(tmp___1 != 0);
    __z->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zim_spl_SplFileInfo___construct(int ht , zval *return_value ,
                                     zval **return_value_ptr , zval *this_ptr ,
                                     int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  char *path ;
  int len ;
  zend_error_handling error_handling ;
  int __attribute__((__visibility__("default")))  tmp ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;

  {
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_RuntimeException,
                              & error_handling);
  tmp = zend_parse_parameters(ht, "s", & path, & len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    zend_restore_error_handling(& error_handling);
    return;
  } else {

  }
  tmp___0 = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp___0;
  spl_filesystem_info_set_filename(intern, path, len, 1);
  zend_restore_error_handling(& error_handling);
  return;
}
}
void zim_spl_SplFileInfo_getPerms(int ht , zval *return_value ,
                                  zval **return_value_ptr , zval *this_ptr ,
                                  int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_error_handling error_handling ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_RuntimeException,
                              & error_handling);
  spl_filesystem_object_get_file_name(intern);
  php_stat((char const   *)intern->file_name, intern->file_name_len, 0,
           return_value);
  zend_restore_error_handling(& error_handling);
  return;
}
}
void zim_spl_SplFileInfo_getInode(int ht , zval *return_value ,
                                  zval **return_value_ptr , zval *this_ptr ,
                                  int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_error_handling error_handling ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_RuntimeException,
                              & error_handling);
  spl_filesystem_object_get_file_name(intern);
  php_stat((char const   *)intern->file_name, intern->file_name_len, 1,
           return_value);
  zend_restore_error_handling(& error_handling);
  return;
}
}
void zim_spl_SplFileInfo_getSize(int ht , zval *return_value ,
                                 zval **return_value_ptr , zval *this_ptr ,
                                 int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_error_handling error_handling ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_RuntimeException,
                              & error_handling);
  spl_filesystem_object_get_file_name(intern);
  php_stat((char const   *)intern->file_name, intern->file_name_len, 2,
           return_value);
  zend_restore_error_handling(& error_handling);
  return;
}
}
void zim_spl_SplFileInfo_getOwner(int ht , zval *return_value ,
                                  zval **return_value_ptr , zval *this_ptr ,
                                  int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_error_handling error_handling ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_RuntimeException,
                              & error_handling);
  spl_filesystem_object_get_file_name(intern);
  php_stat((char const   *)intern->file_name, intern->file_name_len, 3,
           return_value);
  zend_restore_error_handling(& error_handling);
  return;
}
}
void zim_spl_SplFileInfo_getGroup(int ht , zval *return_value ,
                                  zval **return_value_ptr , zval *this_ptr ,
                                  int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_error_handling error_handling ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_RuntimeException,
                              & error_handling);
  spl_filesystem_object_get_file_name(intern);
  php_stat((char const   *)intern->file_name, intern->file_name_len, 4,
           return_value);
  zend_restore_error_handling(& error_handling);
  return;
}
}
void zim_spl_SplFileInfo_getATime(int ht , zval *return_value ,
                                  zval **return_value_ptr , zval *this_ptr ,
                                  int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_error_handling error_handling ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_RuntimeException,
                              & error_handling);
  spl_filesystem_object_get_file_name(intern);
  php_stat((char const   *)intern->file_name, intern->file_name_len, 5,
           return_value);
  zend_restore_error_handling(& error_handling);
  return;
}
}
void zim_spl_SplFileInfo_getMTime(int ht , zval *return_value ,
                                  zval **return_value_ptr , zval *this_ptr ,
                                  int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_error_handling error_handling ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_RuntimeException,
                              & error_handling);
  spl_filesystem_object_get_file_name(intern);
  php_stat((char const   *)intern->file_name, intern->file_name_len, 6,
           return_value);
  zend_restore_error_handling(& error_handling);
  return;
}
}
void zim_spl_SplFileInfo_getCTime(int ht , zval *return_value ,
                                  zval **return_value_ptr , zval *this_ptr ,
                                  int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_error_handling error_handling ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_RuntimeException,
                              & error_handling);
  spl_filesystem_object_get_file_name(intern);
  php_stat((char const   *)intern->file_name, intern->file_name_len, 7,
           return_value);
  zend_restore_error_handling(& error_handling);
  return;
}
}
void zim_spl_SplFileInfo_getType(int ht , zval *return_value ,
                                 zval **return_value_ptr , zval *this_ptr ,
                                 int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_error_handling error_handling ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_RuntimeException,
                              & error_handling);
  spl_filesystem_object_get_file_name(intern);
  php_stat((char const   *)intern->file_name, intern->file_name_len, 8,
           return_value);
  zend_restore_error_handling(& error_handling);
  return;
}
}
void zim_spl_SplFileInfo_isWritable(int ht , zval *return_value ,
                                    zval **return_value_ptr , zval *this_ptr ,
                                    int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_error_handling error_handling ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_RuntimeException,
                              & error_handling);
  spl_filesystem_object_get_file_name(intern);
  php_stat((char const   *)intern->file_name, intern->file_name_len, 9,
           return_value);
  zend_restore_error_handling(& error_handling);
  return;
}
}
void zim_spl_SplFileInfo_isReadable(int ht , zval *return_value ,
                                    zval **return_value_ptr , zval *this_ptr ,
                                    int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_error_handling error_handling ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_RuntimeException,
                              & error_handling);
  spl_filesystem_object_get_file_name(intern);
  php_stat((char const   *)intern->file_name, intern->file_name_len, 10,
           return_value);
  zend_restore_error_handling(& error_handling);
  return;
}
}
void zim_spl_SplFileInfo_isExecutable(int ht , zval *return_value ,
                                      zval **return_value_ptr , zval *this_ptr ,
                                      int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_error_handling error_handling ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_RuntimeException,
                              & error_handling);
  spl_filesystem_object_get_file_name(intern);
  php_stat((char const   *)intern->file_name, intern->file_name_len, 11,
           return_value);
  zend_restore_error_handling(& error_handling);
  return;
}
}
void zim_spl_SplFileInfo_isFile(int ht , zval *return_value ,
                                zval **return_value_ptr , zval *this_ptr ,
                                int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_error_handling error_handling ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_RuntimeException,
                              & error_handling);
  spl_filesystem_object_get_file_name(intern);
  php_stat((char const   *)intern->file_name, intern->file_name_len, 12,
           return_value);
  zend_restore_error_handling(& error_handling);
  return;
}
}
void zim_spl_SplFileInfo_isDir(int ht , zval *return_value ,
                               zval **return_value_ptr , zval *this_ptr ,
                               int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_error_handling error_handling ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_RuntimeException,
                              & error_handling);
  spl_filesystem_object_get_file_name(intern);
  php_stat((char const   *)intern->file_name, intern->file_name_len, 13,
           return_value);
  zend_restore_error_handling(& error_handling);
  return;
}
}
void zim_spl_SplFileInfo_isLink(int ht , zval *return_value ,
                                zval **return_value_ptr , zval *this_ptr ,
                                int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_error_handling error_handling ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_RuntimeException,
                              & error_handling);
  spl_filesystem_object_get_file_name(intern);
  php_stat((char const   *)intern->file_name, intern->file_name_len, 14,
           return_value);
  zend_restore_error_handling(& error_handling);
  return;
}
}
void zim_spl_SplFileInfo_getLinkTarget(int ht , zval *return_value ,
                                       zval **return_value_ptr ,
                                       zval *this_ptr , int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int ret ;
  char buff[4096] ;
  zend_error_handling error_handling ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  char expanded_path[4096] ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  ssize_t __attribute__((__gnu_inline__))  tmp___2 ;
  ssize_t __attribute__((__gnu_inline__))  tmp___3 ;
  int *tmp___4 ;
  char *tmp___5 ;
  zval *__z___0 ;
  char const   *__s ;
  int __l ;
  zval *__z___1 ;
  char __attribute__((__visibility__("default")))  *tmp___6 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_RuntimeException,
                              & error_handling);
  __repair_del_2217__0: /* CIL Label */ ;
  if (ret == -1) {
    tmp___4 = __errno_location();
    tmp___5 = strerror(*tmp___4);
    zend_throw_exception_ex((zend_class_entry *)spl_ce_RuntimeException, 0L,
                            (char *)"Unable to read link %s, error: %s",
                            intern->file_name, tmp___5);
    while (1) {
      __z___0 = return_value;
      __z___0->value.lval = 0L;
      __z___0->type = (zend_uchar )3;
      break;
    }
  } else {
    buff[ret] = (char )'\000';
    while (1) {
      __s = (char const   *)(buff);
      __l = ret;
      __z___1 = return_value;
      __z___1->value.str.len = __l;
      tmp___6 = _estrndup(__s, (unsigned int )__l);
      __z___1->value.str.val = (char *)tmp___6;
      __z___1->type = (zend_uchar )6;
      break;
    }
  }
  zend_restore_error_handling(& error_handling);
  return;
}
}
void zim_spl_SplFileInfo_getRealPath(int ht , zval *return_value ,
                                     zval **return_value_ptr , zval *this_ptr ,
                                     int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  char buff[4096] ;
  char *filename ;
  zend_error_handling error_handling ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  char const   *__s ;
  zval *__z ;
  size_t tmp___1 ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;
  zval *__z___0 ;
  char __attribute__((__visibility__("default")))  *tmp___3 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_RuntimeException,
                              & error_handling);
  if ((unsigned int )intern->type == 1U) {
    if (! intern->file_name) {
      if (intern->u.dir.entry.d_name[0]) {
        spl_filesystem_object_get_file_name(intern);
      } else {

      }
    } else {

    }
  } else {

  }
  if (intern->orig_path) {
    filename = intern->orig_path;
  } else {
    filename = intern->file_name;
  }
  if (filename) {
    tmp___3 = tsrm_realpath((char const   *)filename, buff);
    if (tmp___3) {
      while (1) {
        __s = (char const   *)(buff);
        __z = return_value;
        tmp___1 = strlen(__s);
        __z->value.str.len = (int )tmp___1;
        tmp___2 = _estrndup(__s, (unsigned int )__z->value.str.len);
        __z->value.str.val = (char *)tmp___2;
        __z->type = (zend_uchar )6;
        break;
      }
    } else {
      goto _L;
    }
  } else {
    _L: 
    while (1) {
      __z___0 = return_value;
      __z___0->value.lval = 0L;
      __z___0->type = (zend_uchar )3;
      break;
    }
  }
  zend_restore_error_handling(& error_handling);
  return;
}
}
void zim_spl_SplFileInfo_openFile(int ht , zval *return_value ,
                                  zval **return_value_ptr , zval *this_ptr ,
                                  int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  spl_filesystem_object_create_type(ht, intern, 2,
                                    (zend_class_entry *)((void *)0),
                                    return_value);
  return;
}
}
void zim_spl_SplFileInfo_setFileClass(int ht , zval *return_value ,
                                      zval **return_value_ptr , zval *this_ptr ,
                                      int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_class_entry *ce ;
  zend_error_handling error_handling ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  ce = (zend_class_entry *)spl_ce_SplFileObject;
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_UnexpectedValueException,
                              & error_handling);
  tmp___0 = zend_parse_parameters(ht, "|C", & ce);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )0) {
    intern->file_class = ce;
  } else {

  }
  zend_restore_error_handling(& error_handling);
  return;
}
}
void zim_spl_SplFileInfo_setInfoClass(int ht , zval *return_value ,
                                      zval **return_value_ptr , zval *this_ptr ,
                                      int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_class_entry *ce ;
  zend_error_handling error_handling ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  ce = (zend_class_entry *)spl_ce_SplFileInfo;
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_UnexpectedValueException,
                              & error_handling);
  tmp___0 = zend_parse_parameters(ht, "|C", & ce);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )0) {
    intern->info_class = ce;
  } else {

  }
  zend_restore_error_handling(& error_handling);
  return;
}
}
void zim_spl_SplFileInfo_getFileInfo(int ht , zval *return_value ,
                                     zval **return_value_ptr , zval *this_ptr ,
                                     int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_class_entry *ce ;
  zend_error_handling error_handling ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  ce = intern->info_class;
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_UnexpectedValueException,
                              & error_handling);
  tmp___0 = zend_parse_parameters(ht, "|C", & ce);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )0) {
    spl_filesystem_object_create_type(ht, intern, 0, ce, return_value);
  } else {

  }
  zend_restore_error_handling(& error_handling);
  return;
}
}
void zim_spl_SplFileInfo_getPathInfo(int ht , zval *return_value ,
                                     zval **return_value_ptr , zval *this_ptr ,
                                     int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_class_entry *ce ;
  zend_error_handling error_handling ;
  int path_len ;
  char *path ;
  char *tmp___0 ;
  char *dpath ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  size_t __attribute__((__visibility__("default")))  tmp___2 ;
  int __attribute__((__visibility__("default")))  tmp___3 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  ce = intern->info_class;
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_UnexpectedValueException,
                              & error_handling);
  tmp___3 = zend_parse_parameters(ht, "|C", & ce);
  if (tmp___3 == (int __attribute__((__visibility__("default")))  )0) {
    tmp___0 = spl_filesystem_object_get_pathname(intern, & path_len);
    path = tmp___0;
    if (path) {
      tmp___1 = _estrndup((char const   *)path, (unsigned int )path_len);
      dpath = (char *)tmp___1;
      tmp___2 = php_dirname(dpath, (size_t )path_len);
      path_len = (int )tmp___2;
      spl_filesystem_object_create_info(intern, dpath, path_len, 1, ce,
                                        return_value);
      _efree((void *)dpath);
    } else {

    }
  } else {

  }
  zend_restore_error_handling(& error_handling);
  return;
}
}
void zim_spl_SplFileInfo__bad_state_ex(int ht , zval *return_value ,
                                       zval **return_value_ptr ,
                                       zval *this_ptr , int return_value_used ) 
{ 


  {
  zend_throw_exception_ex((zend_class_entry *)spl_ce_LogicException, 0L,
                          (char *)"The parent constructor was not called: the object is in an invalid state ");
  return;
}
}
void zim_spl_FilesystemIterator___construct(int ht , zval *return_value ,
                                            zval **return_value_ptr ,
                                            zval *this_ptr ,
                                            int return_value_used ) 
{ 


  {
  spl_filesystem_object_construct(ht, return_value, return_value_ptr, this_ptr,
                                  return_value_used, 4097L);
  return;
}
}
void zim_spl_FilesystemIterator_rewind(int ht , zval *return_value ,
                                       zval **return_value_ptr ,
                                       zval *this_ptr , int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  int tmp___1 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  intern->u.dir.index = 0;
  if (intern->u.dir.dirp) {
    _php_stream_seek(intern->u.dir.dirp, 0L, 0);
  } else {

  }
  while (1) {
    spl_filesystem_dir_read(intern);
    tmp___1 = spl_filesystem_is_dot((char const   *)(intern->u.dir.entry.d_name));
    if (! tmp___1) {
      break;
    } else {

    }
  }
  return;
}
}
void zim_spl_FilesystemIterator_getFlags(int ht , zval *return_value ,
                                         zval **return_value_ptr ,
                                         zval *this_ptr , int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  __z = return_value;
  __z->value.lval = intern->flags & 16368L;
  __z->type = (zend_uchar )1;
  return;
}
}
void zim_spl_FilesystemIterator_setFlags(int ht , zval *return_value ,
                                         zval **return_value_ptr ,
                                         zval *this_ptr , int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  long flags ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "l", & flags);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  intern->flags &= -16369L;
  intern->flags |= 16368L & flags;
  return;
}
}
void zim_spl_RecursiveDirectoryIterator_hasChildren(int ht ,
                                                    zval *return_value ,
                                                    zval **return_value_ptr ,
                                                    zval *this_ptr ,
                                                    int return_value_used ) 
{ 
  zend_bool allow_links ;
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z ;
  zval *__z___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;
  int tmp___2 ;

  {
  allow_links = (zend_bool )0;
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "|b", & allow_links);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  tmp___2 = spl_filesystem_is_invalid_or_dot((char const   *)(intern->u.dir.entry.d_name));
  if (tmp___2) {
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {
    spl_filesystem_object_get_file_name(intern);
    if (! allow_links) {
      if (! (intern->flags & 512L)) {
        php_stat((char const   *)intern->file_name, intern->file_name_len, 14,
                 return_value);
        tmp___1 = zend_is_true(return_value);
        if (tmp___1) {
          while (1) {
            __z___0 = return_value;
            __z___0->value.lval = 0L;
            __z___0->type = (zend_uchar )3;
            break;
          }
          return;
        } else {

        }
      } else {

      }
    } else {

    }
    php_stat((char const   *)intern->file_name, intern->file_name_len, 13,
             return_value);
  }
  return;
}
}
void zim_spl_RecursiveDirectoryIterator_getChildren(int ht ,
                                                    zval *return_value ,
                                                    zval **return_value_ptr ,
                                                    zval *this_ptr ,
                                                    int return_value_used ) 
{ 
  zval zpath ;
  zval zflags ;
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  spl_filesystem_object *subdir ;
  char slash ;
  int tmp___1 ;
  int tmp___2 ;
  int __attribute__((__visibility__("default")))  tmp___3 ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___4 ;
  zval *__z___0 ;
  char const   *__s___0 ;
  int __l___0 ;
  zval *__z___1 ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp___6 ;
  void __attribute__((__visibility__("default")))  *tmp___7 ;
  int __attribute__((__visibility__("default")))  tmp___8 ;
  size_t tmp___9 ;
  char __attribute__((__visibility__("default")))  *tmp___10 ;
  int tmp___11 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  if (intern->flags & 8192L) {
    tmp___2 = 1;
  } else {
    tmp___2 = 0;
  }
  if (tmp___2) {
    tmp___1 = '/';
  } else {
    tmp___1 = '/';
  }
  slash = (char )tmp___1;
  tmp___3 = zend_parse_parameters(ht, "");
  if (tmp___3 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  spl_filesystem_object_get_file_name(intern);
  if (intern->flags & 32L) {
    tmp___11 = 1;
  } else {
    tmp___11 = 0;
  }
  if (tmp___11) {
    while (1) {
      __s = (char const   *)intern->file_name;
      __l = intern->file_name_len;
      __z = return_value;
      __z->value.str.len = __l;
      tmp___4 = _estrndup(__s, (unsigned int )__l);
      __z->value.str.val = (char *)tmp___4;
      __z->type = (zend_uchar )6;
      break;
    }
    return;
  } else {
    zflags.refcount__gc = (zend_uint )1;
    zflags.is_ref__gc = (zend_uchar )0;
    zpath.refcount__gc = (zend_uint )1;
    zpath.is_ref__gc = (zend_uchar )0;
    __z___0 = & zflags;
    __z___0->value.lval = intern->flags;
    __z___0->type = (zend_uchar )1;
    while (1) {
      __s___0 = (char const   *)intern->file_name;
      __l___0 = intern->file_name_len;
      __z___1 = & zpath;
      __z___1->value.str.len = __l___0;
      __z___1->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s___0));
      __z___1->type = (zend_uchar )6;
      break;
    }
    tmp___6 = zend_get_class_entry((zval const   *)this_ptr);
    spl_instantiate_arg_ex2((zend_class_entry *)tmp___6, & return_value, 0,
                            & zpath, & zflags);
    tmp___7 = zend_object_store_get_object((zval const   *)return_value);
    subdir = (spl_filesystem_object *)tmp___7;
    if (subdir) {
      if (intern->u.dir.sub_path) {
        if (*(intern->u.dir.sub_path + 0)) {
          tmp___8 = spprintf(& subdir->u.dir.sub_path, (size_t )0, "%s%c%s",
                             intern->u.dir.sub_path, (int )slash,
                             intern->u.dir.entry.d_name);
          subdir->u.dir.sub_path_len = (int )tmp___8;
        } else {
          tmp___9 = strlen((char const   *)(intern->u.dir.entry.d_name));
          subdir->u.dir.sub_path_len = (int )tmp___9;
          tmp___10 = _estrndup((char const   *)(intern->u.dir.entry.d_name),
                               (unsigned int )subdir->u.dir.sub_path_len);
          subdir->u.dir.sub_path = (char *)tmp___10;
        }
      } else {
        tmp___9 = strlen((char const   *)(intern->u.dir.entry.d_name));
        subdir->u.dir.sub_path_len = (int )tmp___9;
        tmp___10 = _estrndup((char const   *)(intern->u.dir.entry.d_name),
                             (unsigned int )subdir->u.dir.sub_path_len);
        subdir->u.dir.sub_path = (char *)tmp___10;
      }
      subdir->info_class = intern->info_class;
      subdir->file_class = intern->file_class;
      subdir->oth = intern->oth;
    } else {

    }
  }
  return;
}
}
void zim_spl_RecursiveDirectoryIterator_getSubPath(int ht , zval *return_value ,
                                                   zval **return_value_ptr ,
                                                   zval *this_ptr ,
                                                   int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  char const   *__s___0 ;
  int __l___0 ;
  zval *__z___0 ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (intern->u.dir.sub_path) {
    while (1) {
      __s = (char const   *)intern->u.dir.sub_path;
      __l = intern->u.dir.sub_path_len;
      __z = return_value;
      __z->value.str.len = __l;
      tmp___1 = _estrndup(__s, (unsigned int )__l);
      __z->value.str.val = (char *)tmp___1;
      __z->type = (zend_uchar )6;
      break;
    }
    return;
  } else {
    while (1) {
      __s___0 = "";
      __l___0 = 0;
      __z___0 = return_value;
      __z___0->value.str.len = __l___0;
      tmp___2 = _estrndup(__s___0, (unsigned int )__l___0);
      __z___0->value.str.val = (char *)tmp___2;
      __z___0->type = (zend_uchar )6;
      break;
    }
    return;
  }
}
}
void zim_spl_RecursiveDirectoryIterator_getSubPathname(int ht ,
                                                       zval *return_value ,
                                                       zval **return_value_ptr ,
                                                       zval *this_ptr ,
                                                       int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  char *sub_name ;
  int len ;
  char slash ;
  int tmp___1 ;
  int tmp___2 ;
  int __attribute__((__visibility__("default")))  tmp___3 ;
  int __attribute__((__visibility__("default")))  tmp___4 ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char const   *__s___0 ;
  zval *__z___0 ;
  size_t tmp___6 ;
  char __attribute__((__visibility__("default")))  *tmp___7 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  if (intern->flags & 8192L) {
    tmp___2 = 1;
  } else {
    tmp___2 = 0;
  }
  if (tmp___2) {
    tmp___1 = '/';
  } else {
    tmp___1 = '/';
  }
  slash = (char )tmp___1;
  tmp___3 = zend_parse_parameters(ht, "");
  if (tmp___3 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (intern->u.dir.sub_path) {
    tmp___4 = spprintf(& sub_name, (size_t )0, "%s%c%s", intern->u.dir.sub_path,
                       (int )slash, intern->u.dir.entry.d_name);
    len = (int )tmp___4;
    while (1) {
      __s = (char const   *)sub_name;
      __l = len;
      __z = return_value;
      __z->value.str.len = __l;
      __z->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
      __z->type = (zend_uchar )6;
      break;
    }
    return;
  } else {
    while (1) {
      __s___0 = (char const   *)(intern->u.dir.entry.d_name);
      __z___0 = return_value;
      tmp___6 = strlen(__s___0);
      __z___0->value.str.len = (int )tmp___6;
      tmp___7 = _estrndup(__s___0, (unsigned int )__z___0->value.str.len);
      __z___0->value.str.val = (char *)tmp___7;
      __z___0->type = (zend_uchar )6;
      break;
    }
    return;
  }
}
}
void zim_spl_RecursiveDirectoryIterator___construct(int ht ,
                                                    zval *return_value ,
                                                    zval **return_value_ptr ,
                                                    zval *this_ptr ,
                                                    int return_value_used ) 
{ 


  {
  spl_filesystem_object_construct(ht, return_value, return_value_ptr, this_ptr,
                                  return_value_used, 1L);
  return;
}
}
void zim_spl_GlobIterator___construct(int ht , zval *return_value ,
                                      zval **return_value_ptr , zval *this_ptr ,
                                      int return_value_used ) 
{ 


  {
  spl_filesystem_object_construct(ht, return_value, return_value_ptr, this_ptr,
                                  return_value_used, 3L);
  return;
}
}
void zim_spl_GlobIterator_count(int ht , zval *return_value ,
                                zval **return_value_ptr , zval *this_ptr ,
                                int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z ;
  int __attribute__((__visibility__("default")))  tmp___1 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if ((unsigned long )(intern->u.dir.dirp)->ops == (unsigned long )(& php_glob_stream_ops)) {
    __z = return_value;
    tmp___1 = _php_glob_stream_get_count(intern->u.dir.dirp, (int *)((void *)0));
    __z->value.lval = (long )tmp___1;
    __z->type = (zend_uchar )1;
    return;
  } else {
    php_error_docref0((char const   *)((void *)0), 1,
                      "GlobIterator lost glob state");
  }
  return;
}
}
static void spl_filesystem_dir_it_dtor(zend_object_iterator *iter ) ;
static int spl_filesystem_dir_it_valid(zend_object_iterator *iter ) ;
static void spl_filesystem_dir_it_current_data(zend_object_iterator *iter ,
                                               zval ***data ) ;
static int spl_filesystem_dir_it_current_key(zend_object_iterator *iter ,
                                             char **str_key ,
                                             uint *str_key_len , ulong *int_key ) ;
static void spl_filesystem_dir_it_move_forward(zend_object_iterator *iter ) ;
static void spl_filesystem_dir_it_rewind(zend_object_iterator *iter ) ;
zend_object_iterator_funcs spl_filesystem_dir_it_funcs  =    {& spl_filesystem_dir_it_dtor, & spl_filesystem_dir_it_valid,
    & spl_filesystem_dir_it_current_data, & spl_filesystem_dir_it_current_key,
    & spl_filesystem_dir_it_move_forward, & spl_filesystem_dir_it_rewind,
    (void (*)(zend_object_iterator *iter ))0};
zend_object_iterator *spl_filesystem_dir_get_iterator(zend_class_entry *ce ,
                                                      zval *object , int by_ref ) 
{ 
  spl_filesystem_iterator *iterator ;
  spl_filesystem_object *dir_object ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_uint tmp___0 ;

  {
  if (by_ref) {
    zend_error(1, "An iterator cannot be used with foreach by reference");
  } else {

  }
  tmp = zend_object_store_get_object((zval const   *)object);
  dir_object = (spl_filesystem_object *)tmp;
  iterator = spl_filesystem_object_to_iterator(dir_object);
  tmp___0 = zval_refcount_p(object);
  zval_set_refcount_p(object, tmp___0 + 2U);
  iterator->intern.data = (void *)object;
  iterator->intern.funcs = & spl_filesystem_dir_it_funcs;
  iterator->current = object;
  return ((zend_object_iterator *)iterator);
}
}
static void spl_filesystem_dir_it_dtor(zend_object_iterator *iter ) 
{ 
  spl_filesystem_iterator *iterator ;
  zval *zfree ;

  {
  iterator = (spl_filesystem_iterator *)iter;
  zfree = (zval *)iterator->intern.data;
  iterator->intern.data = (void *)0;
  _zval_ptr_dtor(& iterator->current);
  if (zfree) {
    _zval_ptr_dtor(& zfree);
  } else {

  }
  return;
}
}
static int spl_filesystem_dir_it_valid(zend_object_iterator *iter ) 
{ 
  spl_filesystem_object *object ;
  spl_filesystem_object *tmp ;
  int tmp___0 ;

  {
  tmp = spl_filesystem_iterator_to_object((spl_filesystem_iterator *)iter);
  object = tmp;
  if ((int )object->u.dir.entry.d_name[0] != 0) {
    tmp___0 = 0;
  } else {
    tmp___0 = -1;
  }
  return (tmp___0);
}
}
static void spl_filesystem_dir_it_current_data(zend_object_iterator *iter ,
                                               zval ***data ) 
{ 
  spl_filesystem_iterator *iterator ;

  {
  iterator = (spl_filesystem_iterator *)iter;
  *data = & iterator->current;
  return;
}
}
static int spl_filesystem_dir_it_current_key(zend_object_iterator *iter ,
                                             char **str_key ,
                                             uint *str_key_len , ulong *int_key ) 
{ 
  spl_filesystem_object *object ;
  spl_filesystem_object *tmp ;

  {
  tmp = spl_filesystem_iterator_to_object((spl_filesystem_iterator *)iter);
  object = tmp;
  *int_key = (ulong )object->u.dir.index;
  return (2);
}
}
static void spl_filesystem_dir_it_move_forward(zend_object_iterator *iter ) 
{ 
  spl_filesystem_object *object ;
  spl_filesystem_object *tmp ;

  {
  tmp = spl_filesystem_iterator_to_object((spl_filesystem_iterator *)iter);
  object = tmp;
  (object->u.dir.index) ++;
  spl_filesystem_dir_read(object);
  if (object->file_name) {
    _efree((void *)object->file_name);
    object->file_name = (char *)((void *)0);
  } else {

  }
  return;
}
}
static void spl_filesystem_dir_it_rewind(zend_object_iterator *iter ) 
{ 
  spl_filesystem_object *object ;
  spl_filesystem_object *tmp ;

  {
  tmp = spl_filesystem_iterator_to_object((spl_filesystem_iterator *)iter);
  object = tmp;
  object->u.dir.index = 0;
  if (object->u.dir.dirp) {
    _php_stream_seek(object->u.dir.dirp, 0L, 0);
  } else {

  }
  spl_filesystem_dir_read(object);
  return;
}
}
static void spl_filesystem_tree_it_dtor(zend_object_iterator *iter ) 
{ 
  spl_filesystem_iterator *iterator ;
  zval *zfree ;

  {
  iterator = (spl_filesystem_iterator *)iter;
  zfree = (zval *)iterator->intern.data;
  if (iterator->current) {
    _zval_ptr_dtor(& iterator->current);
  } else {

  }
  iterator->intern.data = (void *)0;
  _zval_ptr_dtor(& zfree);
  _zval_ptr_dtor(& zfree);
  return;
}
}
static void spl_filesystem_tree_it_current_data(zend_object_iterator *iter ,
                                                zval ***data ) 
{ 
  spl_filesystem_iterator *iterator ;
  spl_filesystem_object *object ;
  spl_filesystem_object *tmp ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  void __attribute__((__visibility__("default")))  *tmp___2 ;

  {
  iterator = (spl_filesystem_iterator *)iter;
  tmp = spl_filesystem_iterator_to_object(iterator);
  object = tmp;
  if ((object->flags & 240L) == 32L) {
    if (! iterator->current) {
      while (1) {
        tmp___0 = _emalloc(sizeof(zval_gc_info ));
        iterator->current = (zval *)tmp___0;
        ((zval_gc_info *)iterator->current)->u.buffered = (gc_root_buffer *)((void *)0);
        break;
      }
      *(iterator->current) = (zval )zval_used_for_init;
      spl_filesystem_object_get_file_name(object);
      while (1) {
        __s = (char const   *)object->file_name;
        __l = object->file_name_len;
        __z = iterator->current;
        __z->value.str.len = __l;
        tmp___1 = _estrndup(__s, (unsigned int )__l);
        __z->value.str.val = (char *)tmp___1;
        __z->type = (zend_uchar )6;
        break;
      }
    } else {

    }
    *data = & iterator->current;
  } else
  if ((object->flags & 240L) == 0L) {
    if (! iterator->current) {
      while (1) {
        tmp___2 = _emalloc(sizeof(zval_gc_info ));
        iterator->current = (zval *)tmp___2;
        ((zval_gc_info *)iterator->current)->u.buffered = (gc_root_buffer *)((void *)0);
        break;
      }
      *(iterator->current) = (zval )zval_used_for_init;
      spl_filesystem_object_get_file_name(object);
      spl_filesystem_object_create_type(0, object, 0,
                                        (zend_class_entry *)((void *)0),
                                        iterator->current);
    } else {

    }
    *data = & iterator->current;
  } else {
    *data = (zval **)(& iterator->intern.data);
  }
  return;
}
}
static int spl_filesystem_tree_it_current_key(zend_object_iterator *iter ,
                                              char **str_key ,
                                              uint *str_key_len ,
                                              ulong *int_key ) 
{ 
  spl_filesystem_object *object ;
  spl_filesystem_object *tmp ;
  size_t tmp___0 ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;

  {
  tmp = spl_filesystem_iterator_to_object((spl_filesystem_iterator *)iter);
  object = tmp;
  if ((object->flags & 3840L) == 256L) {
    tmp___0 = strlen((char const   *)(object->u.dir.entry.d_name));
    *str_key_len = (uint )(tmp___0 + 1UL);
    tmp___1 = _estrndup((char const   *)(object->u.dir.entry.d_name),
                        *str_key_len - 1U);
    *str_key = (char *)tmp___1;
  } else {
    spl_filesystem_object_get_file_name(object);
    *str_key_len = (uint )(object->file_name_len + 1);
    tmp___2 = _estrndup((char const   *)object->file_name,
                        (unsigned int )object->file_name_len);
    *str_key = (char *)tmp___2;
  }
  return (1);
}
}
static void spl_filesystem_tree_it_move_forward(zend_object_iterator *iter ) 
{ 
  spl_filesystem_iterator *iterator ;
  spl_filesystem_object *object ;
  spl_filesystem_object *tmp ;
  int tmp___0 ;

  {
  iterator = (spl_filesystem_iterator *)iter;
  tmp = spl_filesystem_iterator_to_object(iterator);
  object = tmp;
  (object->u.dir.index) ++;
  while (1) {
    spl_filesystem_dir_read(object);
    tmp___0 = spl_filesystem_is_dot((char const   *)(object->u.dir.entry.d_name));
    if (! tmp___0) {
      break;
    } else {

    }
  }
  if (object->file_name) {
    _efree((void *)object->file_name);
    object->file_name = (char *)((void *)0);
  } else {

  }
  if (iterator->current) {
    _zval_ptr_dtor(& iterator->current);
    iterator->current = (zval *)((void *)0);
  } else {

  }
  return;
}
}
static void spl_filesystem_tree_it_rewind(zend_object_iterator *iter ) 
{ 
  spl_filesystem_iterator *iterator ;
  spl_filesystem_object *object ;
  spl_filesystem_object *tmp ;
  int tmp___0 ;

  {
  iterator = (spl_filesystem_iterator *)iter;
  tmp = spl_filesystem_iterator_to_object(iterator);
  object = tmp;
  object->u.dir.index = 0;
  if (object->u.dir.dirp) {
    _php_stream_seek(object->u.dir.dirp, 0L, 0);
  } else {

  }
  while (1) {
    spl_filesystem_dir_read(object);
    tmp___0 = spl_filesystem_is_dot((char const   *)(object->u.dir.entry.d_name));
    if (! tmp___0) {
      break;
    } else {

    }
  }
  if (iterator->current) {
    _zval_ptr_dtor(& iterator->current);
    iterator->current = (zval *)((void *)0);
  } else {

  }
  return;
}
}
zend_object_iterator_funcs spl_filesystem_tree_it_funcs  =    {& spl_filesystem_tree_it_dtor, & spl_filesystem_dir_it_valid,
    & spl_filesystem_tree_it_current_data, & spl_filesystem_tree_it_current_key,
    & spl_filesystem_tree_it_move_forward, & spl_filesystem_tree_it_rewind,
    (void (*)(zend_object_iterator *iter ))0};
zend_object_iterator *spl_filesystem_tree_get_iterator(zend_class_entry *ce ,
                                                       zval *object ,
                                                       int by_ref ) 
{ 
  spl_filesystem_iterator *iterator ;
  spl_filesystem_object *dir_object ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_uint tmp___0 ;

  {
  if (by_ref) {
    zend_error(1, "An iterator cannot be used with foreach by reference");
  } else {

  }
  tmp = zend_object_store_get_object((zval const   *)object);
  dir_object = (spl_filesystem_object *)tmp;
  iterator = spl_filesystem_object_to_iterator(dir_object);
  tmp___0 = zval_refcount_p(object);
  zval_set_refcount_p(object, tmp___0 + 2U);
  iterator->intern.data = (void *)object;
  iterator->intern.funcs = & spl_filesystem_tree_it_funcs;
  iterator->current = (zval *)((void *)0);
  return ((zend_object_iterator *)iterator);
}
}
static int spl_filesystem_object_cast(zval *readobj , zval *writeobj , int type ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval retval ;
  zval *retval_ptr ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  zend_uchar is_ref ;
  zend_bool tmp___1 ;
  zend_uint refcount ;
  zend_uint tmp___2 ;
  char const   *__s___0 ;
  int __l___0 ;
  zval *__z___0 ;
  char __attribute__((__visibility__("default")))  *tmp___3 ;
  zval retval___0 ;
  zval *retval_ptr___0 ;
  char const   *__s___1 ;
  zval *__z___1 ;
  size_t tmp___4 ;
  char __attribute__((__visibility__("default")))  *tmp___5 ;
  zend_uchar is_ref___0 ;
  zend_bool tmp___6 ;
  zend_uint refcount___0 ;
  zend_uint tmp___7 ;
  char const   *__s___2 ;
  zval *__z___2 ;
  size_t tmp___8 ;
  char __attribute__((__visibility__("default")))  *tmp___9 ;

  {
  tmp = zend_object_store_get_object((zval const   *)readobj);
  intern = (spl_filesystem_object *)tmp;
  if (type == 6) {
    switch ((unsigned int )intern->type) {
    case 0U: 
    case 2U: 
    if ((unsigned long )readobj == (unsigned long )writeobj) {
      retval_ptr = & retval;
      while (1) {
        __s = (char const   *)intern->file_name;
        __l = intern->file_name_len;
        __z = retval_ptr;
        __z->value.str.len = __l;
        tmp___0 = _estrndup(__s, (unsigned int )__l);
        __z->value.str.val = (char *)tmp___0;
        __z->type = (zend_uchar )6;
        break;
      }
      _zval_dtor(readobj);
      tmp___1 = zval_isref_p(writeobj);
      is_ref = tmp___1;
      tmp___2 = zval_refcount_p(writeobj);
      refcount = tmp___2;
      while (1) {
        writeobj->value = retval_ptr->value;
        writeobj->type = retval_ptr->type;
        break;
      }
      zval_set_isref_to_p(writeobj, is_ref);
      zval_set_refcount_p(writeobj, refcount);
    } else {
      while (1) {
        __s___0 = (char const   *)intern->file_name;
        __l___0 = intern->file_name_len;
        __z___0 = writeobj;
        __z___0->value.str.len = __l___0;
        tmp___3 = _estrndup(__s___0, (unsigned int )__l___0);
        __z___0->value.str.val = (char *)tmp___3;
        __z___0->type = (zend_uchar )6;
        break;
      }
    }
    return (0);
    case 1U: 
    if ((unsigned long )readobj == (unsigned long )writeobj) {
      retval_ptr___0 = & retval___0;
      while (1) {
        __s___1 = (char const   *)(intern->u.dir.entry.d_name);
        __z___1 = retval_ptr___0;
        tmp___4 = strlen(__s___1);
        __z___1->value.str.len = (int )tmp___4;
        tmp___5 = _estrndup(__s___1, (unsigned int )__z___1->value.str.len);
        __z___1->value.str.val = (char *)tmp___5;
        __z___1->type = (zend_uchar )6;
        break;
      }
      _zval_dtor(readobj);
      tmp___6 = zval_isref_p(writeobj);
      is_ref___0 = tmp___6;
      tmp___7 = zval_refcount_p(writeobj);
      refcount___0 = tmp___7;
      while (1) {
        writeobj->value = retval_ptr___0->value;
        writeobj->type = retval_ptr___0->type;
        break;
      }
      zval_set_isref_to_p(writeobj, is_ref___0);
      zval_set_refcount_p(writeobj, refcount___0);
    } else {
      while (1) {
        __s___2 = (char const   *)(intern->u.dir.entry.d_name);
        __z___2 = writeobj;
        tmp___8 = strlen(__s___2);
        __z___2->value.str.len = (int )tmp___8;
        tmp___9 = _estrndup(__s___2, (unsigned int )__z___2->value.str.len);
        __z___2->value.str.val = (char *)tmp___9;
        __z___2->type = (zend_uchar )6;
        break;
      }
    }
    return (0);
    }
  } else {

  }
  if ((unsigned long )readobj == (unsigned long )writeobj) {
    _zval_dtor(readobj);
  } else {

  }
  writeobj->type = (zend_uchar )0;
  return (-1);
}
}
static zend_arg_info const   arginfo_info___construct[2]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )-1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"file_name", (zend_uint )(sizeof("file_name") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_info_openFile[4]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"open_mode", (zend_uint )(sizeof("open_mode") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}, 
        {"use_include_path", (zend_uint )(sizeof("use_include_path") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}, 
        {"context", (zend_uint )(sizeof("context") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_info_optinalFileClass[2]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"class_name", (zend_uint )(sizeof("class_name") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_optinalSuffix[2]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"suffix", (zend_uint )(sizeof("suffix") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_splfileinfo_void[1]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )-1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}};
static zend_function_entry const   spl_SplFileInfo_functions[31]  = 
  {      {"__construct", & zim_spl_SplFileInfo___construct,
      arginfo_info___construct,
      (zend_uint )(sizeof(arginfo_info___construct) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getPath", & zim_spl_SplFileInfo_getPath, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getFilename", & zim_spl_SplFileInfo_getFilename,
      arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getExtension", & zim_spl_SplFileInfo_getExtension,
      arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getBasename", & zim_spl_SplFileInfo_getBasename, arginfo_optinalSuffix,
      (zend_uint )(sizeof(arginfo_optinalSuffix) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getPathname", & zim_spl_SplFileInfo_getPathname,
      arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getPerms", & zim_spl_SplFileInfo_getPerms, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getInode", & zim_spl_SplFileInfo_getInode, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getSize", & zim_spl_SplFileInfo_getSize, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getOwner", & zim_spl_SplFileInfo_getOwner, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getGroup", & zim_spl_SplFileInfo_getGroup, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getATime", & zim_spl_SplFileInfo_getATime, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getMTime", & zim_spl_SplFileInfo_getMTime, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getCTime", & zim_spl_SplFileInfo_getCTime, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getType", & zim_spl_SplFileInfo_getType, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"isWritable", & zim_spl_SplFileInfo_isWritable, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"isReadable", & zim_spl_SplFileInfo_isReadable, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"isExecutable", & zim_spl_SplFileInfo_isExecutable,
      arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"isFile", & zim_spl_SplFileInfo_isFile, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"isDir", & zim_spl_SplFileInfo_isDir, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"isLink", & zim_spl_SplFileInfo_isLink, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getLinkTarget", & zim_spl_SplFileInfo_getLinkTarget,
      arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getRealPath", & zim_spl_SplFileInfo_getRealPath,
      arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getFileInfo", & zim_spl_SplFileInfo_getFileInfo,
      arginfo_info_optinalFileClass,
      (zend_uint )(sizeof(arginfo_info_optinalFileClass) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getPathInfo", & zim_spl_SplFileInfo_getPathInfo,
      arginfo_info_optinalFileClass,
      (zend_uint )(sizeof(arginfo_info_optinalFileClass) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"openFile", & zim_spl_SplFileInfo_openFile, arginfo_info_openFile,
      (zend_uint )(sizeof(arginfo_info_openFile) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"setFileClass", & zim_spl_SplFileInfo_setFileClass,
      arginfo_info_optinalFileClass,
      (zend_uint )(sizeof(arginfo_info_optinalFileClass) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"setInfoClass", & zim_spl_SplFileInfo_setInfoClass,
      arginfo_info_optinalFileClass,
      (zend_uint )(sizeof(arginfo_info_optinalFileClass) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"_bad_state_ex", & zim_spl_SplFileInfo__bad_state_ex,
      (struct _zend_arg_info  const  *)((void *)0),
      (zend_uint )(sizeof((void *)0) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )260}, 
        {"__toString", & zim_spl_SplFileInfo_getPathname, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {(char const   *)((void *)0),
      (void (*)(int ht , zval *return_value ,
                zval **return_value_ptr , zval *this_ptr ,
                int return_value_used ))((void *)0),
      (struct _zend_arg_info  const  *)((void *)0), (zend_uint )0, (zend_uint )0}};
static zend_arg_info const   arginfo_dir___construct[2]  = {      {(char const   *)((void *)0),
      (zend_uint )0, (char const   *)((void *)0), (zend_uint )-1,
      (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"path", (zend_uint )(sizeof("path") - 1UL), (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}};
static zend_arg_info const   arginfo_dir_it_seek[2]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )-1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"position", (zend_uint )(sizeof("position") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_function_entry const   spl_DirectoryIterator_functions[13]  = 
  {      {"__construct", & zim_spl_DirectoryIterator___construct,
      arginfo_dir___construct,
      (zend_uint )(sizeof(arginfo_dir___construct) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getFilename", & zim_spl_DirectoryIterator_getFilename,
      arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getExtension", & zim_spl_DirectoryIterator_getExtension,
      arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getBasename", & zim_spl_DirectoryIterator_getBasename,
      arginfo_optinalSuffix,
      (zend_uint )(sizeof(arginfo_optinalSuffix) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"isDot", & zim_spl_DirectoryIterator_isDot, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"rewind", & zim_spl_DirectoryIterator_rewind, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"valid", & zim_spl_DirectoryIterator_valid, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"key", & zim_spl_DirectoryIterator_key, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"current", & zim_spl_DirectoryIterator_current, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"next", & zim_spl_DirectoryIterator_next, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"seek", & zim_spl_DirectoryIterator_seek, arginfo_dir_it_seek,
      (zend_uint )(sizeof(arginfo_dir_it_seek) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"__toString", & zim_spl_DirectoryIterator_getFilename,
      arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {(char const   *)((void *)0),
      (void (*)(int ht , zval *return_value ,
                zval **return_value_ptr , zval *this_ptr ,
                int return_value_used ))((void *)0),
      (struct _zend_arg_info  const  *)((void *)0), (zend_uint )0, (zend_uint )0}};
static zend_arg_info const   arginfo_r_dir___construct[3]  = {      {(char const   *)((void *)0),
      (zend_uint )0, (char const   *)((void *)0), (zend_uint )1, (zend_uchar )0,
      (zend_bool )0, (zend_bool )0}, 
        {"path", (zend_uint )(sizeof("path") - 1UL), (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"flags", (zend_uint )(sizeof("flags") - 1UL), (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}};
static zend_arg_info const   arginfo_r_dir_hasChildren[2]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"allow_links", (zend_uint )(sizeof("allow_links") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_r_dir_setFlags[2]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"flags", (zend_uint )(sizeof("flags") - 1UL), (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}};
static zend_function_entry const   spl_FilesystemIterator_functions[8]  = 
  {      {"__construct", & zim_spl_FilesystemIterator___construct,
      arginfo_r_dir___construct,
      (zend_uint )(sizeof(arginfo_r_dir___construct) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"rewind", & zim_spl_FilesystemIterator_rewind, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"next", & zim_spl_DirectoryIterator_next, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"key", & zim_spl_FilesystemIterator_key, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"current", & zim_spl_FilesystemIterator_current, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getFlags", & zim_spl_FilesystemIterator_getFlags,
      arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"setFlags", & zim_spl_FilesystemIterator_setFlags, arginfo_r_dir_setFlags,
      (zend_uint )(sizeof(arginfo_r_dir_setFlags) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {(char const   *)((void *)0),
      (void (*)(int ht , zval *return_value ,
                zval **return_value_ptr , zval *this_ptr ,
                int return_value_used ))((void *)0),
      (struct _zend_arg_info  const  *)((void *)0), (zend_uint )0, (zend_uint )0}};
static zend_function_entry const   spl_RecursiveDirectoryIterator_functions[6]  = {      {"__construct",
      & zim_spl_RecursiveDirectoryIterator___construct,
      arginfo_r_dir___construct,
      (zend_uint )(sizeof(arginfo_r_dir___construct) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"hasChildren", & zim_spl_RecursiveDirectoryIterator_hasChildren,
      arginfo_r_dir_hasChildren,
      (zend_uint )(sizeof(arginfo_r_dir_hasChildren) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getChildren", & zim_spl_RecursiveDirectoryIterator_getChildren,
      arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getSubPath", & zim_spl_RecursiveDirectoryIterator_getSubPath,
      arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getSubPathname", & zim_spl_RecursiveDirectoryIterator_getSubPathname,
      arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {(char const   *)((void *)0),
      (void (*)(int ht , zval *return_value ,
                zval **return_value_ptr , zval *this_ptr ,
                int return_value_used ))((void *)0),
      (struct _zend_arg_info  const  *)((void *)0), (zend_uint )0, (zend_uint )0}};
static zend_function_entry const   spl_GlobIterator_functions[3]  = {      {"__construct",
      & zim_spl_GlobIterator___construct, arginfo_r_dir___construct,
      (zend_uint )(sizeof(arginfo_r_dir___construct) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"count", & zim_spl_GlobIterator_count, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {(char const   *)((void *)0),
      (void (*)(int ht , zval *return_value ,
                zval **return_value_ptr , zval *this_ptr ,
                int return_value_used ))((void *)0),
      (struct _zend_arg_info  const  *)((void *)0), (zend_uint )0, (zend_uint )0}};
static int spl_filesystem_file_read(spl_filesystem_object *intern ,
                                    int silent ) 
{ 
  char *buf ;
  size_t line_len ;
  long line_add ;
  int tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;
  char __attribute__((__visibility__("default")))  *tmp___3 ;
  char __attribute__((__visibility__("default")))  *tmp___4 ;
  unsigned long tmp___15 ;
  int tmp___16 ;

  {
  line_len = (size_t )0;
  if (intern->u.file.current_line) {
    tmp = 1;
  } else
  if (intern->u.file.current_zval) {
    tmp = 1;
  } else {
    tmp = 0;
  }
  line_add = (long )tmp;
  spl_filesystem_file_free_line(intern);
  tmp___0 = _php_stream_eof(intern->u.file.stream);
  if (tmp___0) {
    if (! silent) {
      zend_throw_exception_ex((zend_class_entry *)spl_ce_RuntimeException, 0L,
                              (char *)"Cannot read from file %s",
                              intern->file_name);
    } else {

    }
    return (-1);
  } else {

  }
  if (intern->u.file.max_line_len > 0UL) {
    tmp___1 = _safe_emalloc(intern->u.file.max_line_len + 1UL, sizeof(char ),
                            (size_t )0);
    buf = (char *)tmp___1;
    tmp___2 = _php_stream_get_line(intern->u.file.stream, buf,
                                   intern->u.file.max_line_len, & line_len);
    if ((unsigned long )tmp___2 == (unsigned long )((void *)0)) {
      _efree((void *)buf);
      buf = (char *)((void *)0);
    } else {
      *(buf + line_len) = (char )'\000';
    }
  } else {
    tmp___3 = _php_stream_get_line(intern->u.file.stream, (char *)((void *)0),
                                   (size_t )0, & line_len);
    buf = (char *)tmp___3;
  }
  if (! buf) {
    tmp___4 = _estrdup("");
    intern->u.file.current_line = (char *)tmp___4;
    intern->u.file.current_line_len = (size_t )0;
  } else {
    if (intern->flags & 1L) {
      tmp___16 = 1;
    } else {
      tmp___16 = 0;
    }
    if (tmp___16) {
      tmp___15 = __builtin_strcspn((char const   *)buf, "\r\n");
      line_len = tmp___15;
      *(buf + line_len) = (char )'\000';
    } else {

    }
    intern->u.file.current_line = buf;
    intern->u.file.current_line_len = line_len;
  }
  intern->u.file.current_line_num += line_add;
  return (0);
}
}
static int spl_filesystem_file_call(spl_filesystem_object *intern ,
                                    zend_function *func_ptr ,
                                    int pass_num_args , zval *return_value ,
                                    zval *arg2 ) 
{ 
  zend_fcall_info fci ;
  zend_fcall_info_cache fcic ;
  zval z_fname ;
  zval *zresource_ptr ;
  zval *retval ;
  int result ;
  int num_args ;
  int tmp ;
  zval ***params ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  int tmp___1 ;
  char const   *__s ;
  zval *__z ;
  size_t tmp___2 ;
  int __attribute__((__visibility__("default")))  tmp___4 ;
  zval *__z___0 ;
  zend_uchar is_ref ;
  zend_bool tmp___5 ;
  zend_uint refcount ;
  zend_uint tmp___6 ;

  {
  zresource_ptr = & intern->u.file.zresource;
  if (arg2) {
    tmp = 2;
  } else {
    tmp = 1;
  }
  num_args = pass_num_args + tmp;
  tmp___0 = _safe_emalloc((size_t )num_args, sizeof(zval **), (size_t )0);
  params = (zval ***)tmp___0;
  *(params + 0) = & zresource_ptr;
  if (arg2) {
    *(params + 1) = & arg2;
  } else {

  }
  if (arg2) {
    tmp___1 = 2;
  } else {
    tmp___1 = 1;
  }
  _zend_get_parameters_array_ex(pass_num_args, params + tmp___1);
  while (1) {
    __s = func_ptr->common.function_name;
    __z = & z_fname;
    tmp___2 = strlen(__s);
    __z->value.str.len = (int )tmp___2;
    __z->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z->type = (zend_uchar )6;
    break;
  }
  fci.size = sizeof(fci);
  fci.function_table = executor_globals.function_table;
  fci.object_ptr = (zval *)((void *)0);
  fci.function_name = & z_fname;
  fci.retval_ptr_ptr = & retval;
  fci.param_count = (zend_uint )num_args;
  fci.params = params;
  fci.no_separation = (zend_bool )1;
  fci.symbol_table = (HashTable *)((void *)0);
  fcic.initialized = (zend_bool )1;
  fcic.function_handler = func_ptr;
  fcic.calling_scope = (zend_class_entry *)((void *)0);
  fcic.called_scope = (zend_class_entry *)((void *)0);
  fcic.object_ptr = (zval *)((void *)0);
  tmp___4 = zend_call_function(& fci, & fcic);
  result = (int )tmp___4;
  if (result == -1) {
    while (1) {
      __z___0 = return_value;
      __z___0->value.lval = 0L;
      __z___0->type = (zend_uchar )3;
      break;
    }
  } else {
    tmp___5 = zval_isref_p(return_value);
    is_ref = tmp___5;
    tmp___6 = zval_refcount_p(return_value);
    refcount = tmp___6;
    while (1) {
      return_value->value = retval->value;
      return_value->type = retval->type;
      break;
    }
    _zval_copy_ctor(return_value);
    _zval_ptr_dtor(& retval);
    zval_set_isref_to_p(return_value, is_ref);
    zval_set_refcount_p(return_value, refcount);
  }
  _efree((void *)params);
  return (result);
}
}
static int spl_filesystem_file_read_csv(spl_filesystem_object *intern ,
                                        char delimiter , char enclosure ,
                                        char escape , zval *return_value ) 
{ 
  int ret ;
  int tmp ;
  size_t buf_len ;
  char *buf ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  zend_uchar is_ref ;
  zend_bool tmp___2 ;
  zend_uint refcount ;
  zend_uint tmp___3 ;

  {
  ret = 0;
  while (1) {
    ret = spl_filesystem_file_read(intern, 1);
    if (ret == 0) {
      if (! intern->u.file.current_line_len) {
        if (intern->flags & 4L) {
          tmp = 1;
        } else {
          tmp = 0;
        }
        if (! tmp) {
          break;
        } else {

        }
      } else {
        break;
      }
    } else {
      break;
    }
  }
  if (ret == 0) {
    buf_len = intern->u.file.current_line_len;
    tmp___0 = _estrndup((char const   *)intern->u.file.current_line,
                        (unsigned int )buf_len);
    buf = (char *)tmp___0;
    if (intern->u.file.current_zval) {
      _zval_ptr_dtor(& intern->u.file.current_zval);
    } else {

    }
    while (1) {
      tmp___1 = _emalloc(sizeof(zval_gc_info ));
      intern->u.file.current_zval = (zval *)tmp___1;
      ((zval_gc_info *)intern->u.file.current_zval)->u.buffered = (gc_root_buffer *)((void *)0);
      break;
    }
    *(intern->u.file.current_zval) = (zval )zval_used_for_init;
    php_fgetcsv(intern->u.file.stream, delimiter, enclosure, escape, buf_len,
                buf, intern->u.file.current_zval);
    if (return_value) {
      if ((int )return_value->type != 0) {
        _zval_dtor(return_value);
        return_value->type = (zend_uchar )0;
      } else {

      }
      tmp___2 = zval_isref_p(return_value);
      is_ref = tmp___2;
      tmp___3 = zval_refcount_p(return_value);
      refcount = tmp___3;
      while (1) {
        return_value->value = (intern->u.file.current_zval)->value;
        return_value->type = (intern->u.file.current_zval)->type;
        break;
      }
      _zval_copy_ctor(return_value);
      zval_set_isref_to_p(return_value, is_ref);
      zval_set_refcount_p(return_value, refcount);
    } else {

    }
  } else {

  }
  return (ret);
}
}
static int spl_filesystem_file_read_line_ex(zval *this_ptr ,
                                            spl_filesystem_object *intern ,
                                            int silent ) 
{ 
  zval *retval ;
  int __attribute__((__visibility__("default")))  tmp ;
  int tmp___0 ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp___1 ;
  int tmp___2 ;
  char __attribute__((__visibility__("default")))  *tmp___3 ;
  void __attribute__((__visibility__("default")))  *tmp___4 ;
  zend_uchar is_ref ;
  zend_bool tmp___5 ;
  zend_uint refcount ;
  zend_uint tmp___6 ;
  int tmp___7 ;
  int tmp___8 ;

  {
  retval = (zval *)((void *)0);
  if (intern->flags & 8L) {
    tmp___8 = 1;
  } else {
    tmp___8 = 0;
  }
  if (tmp___8) {
    goto _L;
  } else
  if ((unsigned long )(intern->u.file.func_getCurr)->common.scope != (unsigned long )spl_ce_SplFileObject) {
    _L: 
    tmp = _php_stream_eof(intern->u.file.stream);
    if (tmp) {
      if (! silent) {
        zend_throw_exception_ex((zend_class_entry *)spl_ce_RuntimeException, 0L,
                                (char *)"Cannot read from file %s",
                                intern->file_name);
      } else {

      }
      return (-1);
    } else {

    }
    if (intern->flags & 8L) {
      tmp___2 = 1;
    } else {
      tmp___2 = 0;
    }
    if (tmp___2) {
      tmp___0 = spl_filesystem_file_read_csv(intern, intern->u.file.delimiter,
                                             intern->u.file.enclosure,
                                             intern->u.file.escape,
                                             (zval *)((void *)0));
      return (tmp___0);
    } else {
      tmp___1 = zend_get_class_entry((zval const   *)this_ptr);
      zend_call_method(& this_ptr, (zend_class_entry *)tmp___1,
                       & intern->u.file.func_getCurr, "getCurrentLine",
                       (int )(sizeof("getCurrentLine") - 1UL), & retval, 0,
                       (zval *)((void *)0), (zval *)((void *)0));
    }
    if (retval) {
      if (intern->u.file.current_line) {
        (intern->u.file.current_line_num) ++;
      } else
      if (intern->u.file.current_zval) {
        (intern->u.file.current_line_num) ++;
      } else {

      }
      spl_filesystem_file_free_line(intern);
      if ((int )retval->type == 6) {
        tmp___3 = _estrndup((char const   *)retval->value.str.val,
                            (unsigned int )retval->value.str.len);
        intern->u.file.current_line = (char *)tmp___3;
        intern->u.file.current_line_len = (size_t )retval->value.str.len;
      } else {
        while (1) {
          tmp___4 = _emalloc(sizeof(zval_gc_info ));
          intern->u.file.current_zval = (zval *)tmp___4;
          ((zval_gc_info *)intern->u.file.current_zval)->u.buffered = (gc_root_buffer *)((void *)0);
          break;
        }
        (intern->u.file.current_zval)->refcount__gc = (zend_uint )1;
        (intern->u.file.current_zval)->is_ref__gc = (zend_uchar )0;
        tmp___5 = zval_isref_p(intern->u.file.current_zval);
        is_ref = tmp___5;
        tmp___6 = zval_refcount_p(intern->u.file.current_zval);
        refcount = tmp___6;
        while (1) {
          (intern->u.file.current_zval)->value = retval->value;
          (intern->u.file.current_zval)->type = retval->type;
          break;
        }
        _zval_copy_ctor(intern->u.file.current_zval);
        zval_set_isref_to_p(intern->u.file.current_zval, is_ref);
        zval_set_refcount_p(intern->u.file.current_zval, refcount);
      }
      _zval_ptr_dtor(& retval);
      return (0);
    } else {
      return (-1);
    }
  } else {
    tmp___7 = spl_filesystem_file_read(intern, silent);
    return (tmp___7);
  }
}
}
static int spl_filesystem_file_is_empty_line(spl_filesystem_object *intern ) 
{ 
  zval **first ;
  int tmp ;
  int tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;
  int __attribute__((__visibility__("default")))  tmp___2 ;

  {
  if (intern->u.file.current_line) {
    return (intern->u.file.current_line_len == 0UL);
  } else
  if (intern->u.file.current_zval) {
    switch ((int )(intern->u.file.current_zval)->type) {
    case 6: 
    return ((intern->u.file.current_zval)->value.str.len == 0);
    case 4: 
    if (intern->flags & 8L) {
      tmp___0 = 1;
    } else {
      tmp___0 = 0;
    }
    if (tmp___0) {
      tmp___1 = zend_hash_num_elements((HashTable const   *)(intern->u.file.current_zval)->value.ht);
      if (tmp___1 == (int __attribute__((__visibility__("default")))  )1) {
        first = (zval **)(((intern->u.file.current_zval)->value.ht)->pListHead)->pData;
        if ((int )(*first)->type == 6) {
          if ((*first)->value.str.len == 0) {
            tmp = 1;
          } else {
            tmp = 0;
          }
        } else {
          tmp = 0;
        }
        return (tmp);
      } else {

      }
    } else {

    }
    tmp___2 = zend_hash_num_elements((HashTable const   *)(intern->u.file.current_zval)->value.ht);
    return (tmp___2 == (int __attribute__((__visibility__("default")))  )0);
    case 0: 
    return (1);
    default: 
    return (0);
    }
  } else {
    return (1);
  }
}
}
static int spl_filesystem_file_read_line(zval *this_ptr ,
                                         spl_filesystem_object *intern ,
                                         int silent ) 
{ 
  int ret ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;

  {
  tmp = spl_filesystem_file_read_line_ex(this_ptr, intern, silent);
  ret = tmp;
  while (1) {
    if (intern->flags & 4L) {
      tmp___0 = 1;
    } else {
      tmp___0 = 0;
    }
    if (tmp___0) {
      if (ret == 0) {
        tmp___1 = spl_filesystem_file_is_empty_line(intern);
        if (! tmp___1) {
          break;
        } else {

        }
      } else {
        break;
      }
    } else {
      break;
    }
    spl_filesystem_file_free_line(intern);
    ret = spl_filesystem_file_read_line_ex(this_ptr, intern, silent);
  }
  return (ret);
}
}
static void spl_filesystem_file_rewind(zval *this_ptr ,
                                       spl_filesystem_object *intern ) 
{ 
  int __attribute__((__visibility__("default")))  tmp ;
  int tmp___0 ;

  {
  tmp = _php_stream_seek(intern->u.file.stream, 0L, 0);
  if (-1 == (int )tmp) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_RuntimeException, 0L,
                            (char *)"Cannot rewind file %s", intern->file_name);
  } else {
    spl_filesystem_file_free_line(intern);
    intern->u.file.current_line_num = 0L;
  }
  if (intern->flags & 2L) {
    tmp___0 = 1;
  } else {
    tmp___0 = 0;
  }
  if (tmp___0) {
    spl_filesystem_file_read_line(this_ptr, intern, 1);
  } else {

  }
  return;
}
}
void zim_spl_SplFileObject___construct(int ht , zval *return_value ,
                                       zval **return_value_ptr ,
                                       zval *this_ptr , int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_bool use_include_path ;
  char *p1 ;
  char *p2 ;
  char *tmp_path ;
  int tmp_path_len ;
  zend_error_handling error_handling ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  size_t tmp___1 ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;
  char *tmp___3 ;
  char __attribute__((__visibility__("default")))  *tmp___4 ;
  int tmp___5 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  use_include_path = (zend_bool )0;
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_RuntimeException,
                              & error_handling);
  intern->u.file.open_mode = (char *)((void *)0);
  intern->u.file.open_mode_len = 0;
  tmp___0 = zend_parse_parameters(ht, "p|sbr", & intern->file_name,
                                  & intern->file_name_len,
                                  & intern->u.file.open_mode,
                                  & intern->u.file.open_mode_len,
                                  & use_include_path, & intern->u.file.zcontext);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    intern->u.file.open_mode = (char *)((void *)0);
    intern->file_name = (char *)((void *)0);
    zend_restore_error_handling(& error_handling);
    return;
  } else {

  }
  if ((unsigned long )intern->u.file.open_mode == (unsigned long )((void *)0)) {
    intern->u.file.open_mode = (char *)"r";
    intern->u.file.open_mode_len = 1;
  } else {

  }
  tmp___5 = spl_filesystem_file_open(intern, (int )use_include_path, 0);
  if (tmp___5 == 0) {
    tmp___1 = strlen((char const   *)(intern->u.file.stream)->orig_path);
    tmp_path_len = (int )tmp___1;
    if (tmp_path_len > 1) {
      if ((int )*((intern->u.file.stream)->orig_path + (tmp_path_len - 1)) == 47) {
        tmp_path_len --;
      } else {

      }
    } else {

    }
    tmp___2 = _estrndup((char const   *)(intern->u.file.stream)->orig_path,
                        (unsigned int )tmp_path_len);
    tmp_path = (char *)tmp___2;
    p1 = strrchr((char const   *)tmp_path, '/');
    p2 = (char *)0;
    if (p1) {
      goto _L;
    } else
    if (p2) {
      _L: 
      if ((unsigned long )p1 > (unsigned long )p2) {
        tmp___3 = p1;
      } else {
        tmp___3 = p2;
      }
      intern->_path_len = (int )(tmp___3 - tmp_path);
    } else {
      intern->_path_len = 0;
    }
    _efree((void *)tmp_path);
    tmp___4 = _estrndup((char const   *)(intern->u.file.stream)->orig_path,
                        (unsigned int )intern->_path_len);
    intern->_path = (char *)tmp___4;
  } else {

  }
  zend_restore_error_handling(& error_handling);
  return;
}
}
void zim_spl_SplTempFileObject___construct(int ht , zval *return_value ,
                                           zval **return_value_ptr ,
                                           zval *this_ptr ,
                                           int return_value_used ) 
{ 
  long max_memory ;
  char tmp_fname[48] ;
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_error_handling error_handling ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;
  int tmp___3 ;

  {
  max_memory = 2097152L;
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  zend_replace_error_handling((zend_error_handling_t )2,
                              (zend_class_entry *)spl_ce_RuntimeException,
                              & error_handling);
  tmp___0 = zend_parse_parameters(ht, "|l", & max_memory);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    zend_restore_error_handling(& error_handling);
    return;
  } else {

  }
  if (max_memory < 0L) {
    intern->file_name = (char *)"php://memory";
    intern->file_name_len = 12;
  } else
  if (ht) {
    tmp___1 = ap_php_slprintf(tmp_fname, sizeof(tmp_fname),
                              "php://temp/maxmemory:%ld", max_memory);
    intern->file_name_len = (int )tmp___1;
    intern->file_name = tmp_fname;
  } else {
    intern->file_name = (char *)"php://temp";
    intern->file_name_len = 10;
  }
  intern->u.file.open_mode = (char *)"wb";
  intern->u.file.open_mode_len = 1;
  intern->u.file.zcontext = (zval *)((void *)0);
  tmp___3 = spl_filesystem_file_open(intern, 0, 0);
  if (tmp___3 == 0) {
    intern->_path_len = 0;
    tmp___2 = _estrndup("", 0U);
    intern->_path = (char *)tmp___2;
  } else {

  }
  zend_restore_error_handling(& error_handling);
  return;
}
}
void zim_spl_SplFileObject_rewind(int ht , zval *return_value ,
                                  zval **return_value_ptr , zval *this_ptr ,
                                  int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  spl_filesystem_file_rewind(this_ptr, intern);
  return;
}
}
void zim_spl_SplFileObject_eof(int ht , zval *return_value ,
                               zval **return_value_ptr , zval *this_ptr ,
                               int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z ;
  int __attribute__((__visibility__("default")))  tmp___1 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  while (1) {
    __z = return_value;
    tmp___1 = _php_stream_eof(intern->u.file.stream);
    __z->value.lval = (long )(tmp___1 != (int __attribute__((__visibility__("default")))  )0);
    __z->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zim_spl_SplFileObject_valid(int ht , zval *return_value ,
                                 zval **return_value_ptr , zval *this_ptr ,
                                 int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z ;
  int tmp___1 ;
  zval *__z___0 ;
  int __attribute__((__visibility__("default")))  tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (intern->flags & 2L) {
    tmp___4 = 1;
  } else {
    tmp___4 = 0;
  }
  if (tmp___4) {
    while (1) {
      __z = return_value;
      if (intern->u.file.current_line) {
        tmp___1 = 1;
      } else
      if (intern->u.file.current_zval) {
        tmp___1 = 1;
      } else {
        tmp___1 = 0;
      }
      __z->value.lval = (long )(tmp___1 != 0);
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {
    while (1) {
      __z___0 = return_value;
      tmp___2 = _php_stream_eof(intern->u.file.stream);
      if (tmp___2) {
        tmp___3 = 0;
      } else {
        tmp___3 = 1;
      }
      __z___0->value.lval = (long )(tmp___3 != 0);
      __z___0->type = (zend_uchar )3;
      break;
    }
  }
  return;
}
}
void zim_spl_SplFileObject_fgets(int ht , zval *return_value ,
                                 zval **return_value_ptr , zval *this_ptr ,
                                 int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z ;
  int tmp___1 ;
  char const   *__s ;
  int __l ;
  zval *__z___0 ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  tmp___1 = spl_filesystem_file_read(intern, 0);
  if (tmp___1 == -1) {
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  while (1) {
    __s = (char const   *)intern->u.file.current_line;
    __l = (int )intern->u.file.current_line_len;
    __z___0 = return_value;
    __z___0->value.str.len = __l;
    tmp___2 = _estrndup(__s, (unsigned int )__l);
    __z___0->value.str.val = (char *)tmp___2;
    __z___0->type = (zend_uchar )6;
    break;
  }
  return;
}
}
void zim_spl_SplFileObject_current(int ht , zval *return_value ,
                                   zval **return_value_ptr , zval *this_ptr ,
                                   int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  zend_uchar is_ref ;
  zend_bool tmp___2 ;
  zend_uint refcount ;
  zend_uint tmp___3 ;
  int tmp___4 ;
  zval *__z___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (! intern->u.file.current_line) {
    if (! intern->u.file.current_zval) {
      spl_filesystem_file_read_line(this_ptr, intern, 1);
    } else {

    }
  } else {

  }
  if (intern->u.file.current_line) {
    if (intern->flags & 8L) {
      tmp___4 = 1;
    } else {
      tmp___4 = 0;
    }
    if (tmp___4) {
      if (! intern->u.file.current_zval) {
        _L___0: 
        while (1) {
          __s = (char const   *)intern->u.file.current_line;
          __l = (int )intern->u.file.current_line_len;
          __z = return_value;
          __z->value.str.len = __l;
          tmp___1 = _estrndup(__s, (unsigned int )__l);
          __z->value.str.val = (char *)tmp___1;
          __z->type = (zend_uchar )6;
          break;
        }
        return;
      } else {
        goto _L;
      }
    } else {
      goto _L___0;
    }
  } else
  _L: 
  if (intern->u.file.current_zval) {
    tmp___2 = zval_isref_p(return_value);
    is_ref = tmp___2;
    tmp___3 = zval_refcount_p(return_value);
    refcount = tmp___3;
    while (1) {
      return_value->value = (intern->u.file.current_zval)->value;
      return_value->type = (intern->u.file.current_zval)->type;
      break;
    }
    _zval_copy_ctor(return_value);
    zval_set_isref_to_p(return_value, is_ref);
    zval_set_refcount_p(return_value, refcount);
    return;
  } else {

  }
  while (1) {
    __z___0 = return_value;
    __z___0->value.lval = 0L;
    __z___0->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zim_spl_SplFileObject_key(int ht , zval *return_value ,
                               zval **return_value_ptr , zval *this_ptr ,
                               int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  __z = return_value;
  __z->value.lval = intern->u.file.current_line_num;
  __z->type = (zend_uchar )1;
  return;
}
}
void zim_spl_SplFileObject_next(int ht , zval *return_value ,
                                zval **return_value_ptr , zval *this_ptr ,
                                int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  int tmp___1 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  spl_filesystem_file_free_line(intern);
  if (intern->flags & 2L) {
    tmp___1 = 1;
  } else {
    tmp___1 = 0;
  }
  if (tmp___1) {
    spl_filesystem_file_read_line(this_ptr, intern, 1);
  } else {

  }
  (intern->u.file.current_line_num) ++;
  return;
}
}
void zim_spl_SplFileObject_setFlags(int ht , zval *return_value ,
                                    zval **return_value_ptr , zval *this_ptr ,
                                    int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "l", & intern->flags);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  return;
}
}
void zim_spl_SplFileObject_getFlags(int ht , zval *return_value ,
                                    zval **return_value_ptr , zval *this_ptr ,
                                    int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  __z = return_value;
  __z->value.lval = intern->flags & 15L;
  __z->type = (zend_uchar )1;
  return;
}
}
void zim_spl_SplFileObject_setMaxLineLen(int ht , zval *return_value ,
                                         zval **return_value_ptr ,
                                         zval *this_ptr , int return_value_used ) 
{ 
  long max_len ;
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "l", & max_len);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (max_len < 0L) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_DomainException, 0L,
                            (char *)"Maximum line length must be greater than or equal zero");
    return;
  } else {

  }
  intern->u.file.max_line_len = (size_t )max_len;
  return;
}
}
void zim_spl_SplFileObject_getMaxLineLen(int ht , zval *return_value ,
                                         zval **return_value_ptr ,
                                         zval *this_ptr , int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "");
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  __z = return_value;
  __z->value.lval = (long )intern->u.file.max_line_len;
  __z->type = (zend_uchar )1;
  return;
}
}
void zim_spl_SplFileObject_hasChildren(int ht , zval *return_value ,
                                       zval **return_value_ptr ,
                                       zval *this_ptr , int return_value_used ) 
{ 
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;

  {
  tmp = zend_parse_parameters(ht, "");
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  while (1) {
    __z = return_value;
    __z->value.lval = 0L;
    __z->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zim_spl_SplFileObject_getChildren(int ht , zval *return_value ,
                                       zval **return_value_ptr ,
                                       zval *this_ptr , int return_value_used ) 
{ 
  int __attribute__((__visibility__("default")))  tmp ;

  {
  tmp = zend_parse_parameters(ht, "");
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  return;
}
}
void zim_spl_SplFileObject_fgetcsv(int ht , zval *return_value ,
                                   zval **return_value_ptr , zval *this_ptr ,
                                   int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  char delimiter ;
  char enclosure ;
  char escape ;
  char *delim ;
  char *enclo ;
  char *esc ;
  int d_len ;
  int e_len ;
  int esc_len ;
  zval *__z ;
  zval *__z___0 ;
  zval *__z___1 ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  delimiter = intern->u.file.delimiter;
  enclosure = intern->u.file.enclosure;
  escape = intern->u.file.escape;
  delim = (char *)((void *)0);
  enclo = (char *)((void *)0);
  esc = (char *)((void *)0);
  d_len = 0;
  e_len = 0;
  esc_len = 0;
  tmp___0 = zend_parse_parameters(ht, "|sss", & delim, & d_len, & enclo,
                                  & e_len, & esc, & esc_len);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )0) {
    switch (ht) {
    case 3: 
    if (esc_len != 1) {
      php_error_docref0((char const   *)((void *)0), 1 << 1L,
                        "escape must be a character");
      while (1) {
        __z = return_value;
        __z->value.lval = 0L;
        __z->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    escape = *(esc + 0);
    case 2: 
    if (e_len != 1) {
      php_error_docref0((char const   *)((void *)0), 1 << 1L,
                        "enclosure must be a character");
      while (1) {
        __z___0 = return_value;
        __z___0->value.lval = 0L;
        __z___0->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    enclosure = *(enclo + 0);
    case 1: 
    if (d_len != 1) {
      php_error_docref0((char const   *)((void *)0), 1 << 1L,
                        "delimiter must be a character");
      while (1) {
        __z___1 = return_value;
        __z___1->value.lval = 0L;
        __z___1->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    delimiter = *(delim + 0);
    case 0: 
    break;
    }
    spl_filesystem_file_read_csv(intern, delimiter, enclosure, escape,
                                 return_value);
  } else {

  }
  return;
}
}
void zim_spl_SplFileObject_fputcsv(int ht , zval *return_value ,
                                   zval **return_value_ptr , zval *this_ptr ,
                                   int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  char delimiter ;
  char enclosure ;
  char escape ;
  char *delim ;
  char *enclo ;
  int d_len ;
  int e_len ;
  int ret ;
  zval *fields ;
  zval *__z ;
  zval *__z___0 ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z___1 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  delimiter = intern->u.file.delimiter;
  enclosure = intern->u.file.enclosure;
  escape = intern->u.file.escape;
  delim = (char *)((void *)0);
  enclo = (char *)((void *)0);
  d_len = 0;
  e_len = 0;
  fields = (zval *)((void *)0);
  tmp___1 = zend_parse_parameters(ht, "a|ss", & fields, & delim, & d_len,
                                  & enclo, & e_len);
  if (tmp___1 == (int __attribute__((__visibility__("default")))  )0) {
    switch (ht) {
    case 3: 
    if (e_len != 1) {
      php_error_docref0((char const   *)((void *)0), 1 << 1L,
                        "enclosure must be a character");
      while (1) {
        __z = return_value;
        __z->value.lval = 0L;
        __z->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    enclosure = *(enclo + 0);
    case 2: 
    if (d_len != 1) {
      php_error_docref0((char const   *)((void *)0), 1 << 1L,
                        "delimiter must be a character");
      while (1) {
        __z___0 = return_value;
        __z___0->value.lval = 0L;
        __z___0->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    delimiter = *(delim + 0);
    case 1: 
    case 0: 
    break;
    }
    tmp___0 = php_fputcsv(intern->u.file.stream, fields, delimiter, enclosure,
                          escape);
    ret = (int )tmp___0;
    __z___1 = return_value;
    __z___1->value.lval = (long )ret;
    __z___1->type = (zend_uchar )1;
    return;
  } else {

  }
  return;
}
}
void zim_spl_SplFileObject_setCsvControl(int ht , zval *return_value ,
                                         zval **return_value_ptr ,
                                         zval *this_ptr , int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  char delimiter ;
  char enclosure ;
  char escape ;
  char *delim ;
  char *enclo ;
  char *esc ;
  int d_len ;
  int e_len ;
  int esc_len ;
  zval *__z ;
  zval *__z___0 ;
  zval *__z___1 ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  delimiter = (char )',';
  enclosure = (char )'\"';
  escape = (char )'\\';
  delim = (char *)((void *)0);
  enclo = (char *)((void *)0);
  esc = (char *)((void *)0);
  d_len = 0;
  e_len = 0;
  esc_len = 0;
  tmp___0 = zend_parse_parameters(ht, "|sss", & delim, & d_len, & enclo,
                                  & e_len, & esc, & esc_len);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )0) {
    switch (ht) {
    case 3: 
    if (esc_len != 1) {
      php_error_docref0((char const   *)((void *)0), 1 << 1L,
                        "escape must be a character");
      while (1) {
        __z = return_value;
        __z->value.lval = 0L;
        __z->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    escape = *(esc + 0);
    case 2: 
    if (e_len != 1) {
      php_error_docref0((char const   *)((void *)0), 1 << 1L,
                        "enclosure must be a character");
      while (1) {
        __z___0 = return_value;
        __z___0->value.lval = 0L;
        __z___0->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    enclosure = *(enclo + 0);
    case 1: 
    if (d_len != 1) {
      php_error_docref0((char const   *)((void *)0), 1 << 1L,
                        "delimiter must be a character");
      while (1) {
        __z___1 = return_value;
        __z___1->value.lval = 0L;
        __z___1->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    delimiter = *(delim + 0);
    case 0: 
    break;
    }
    intern->u.file.delimiter = delimiter;
    intern->u.file.enclosure = enclosure;
    intern->u.file.escape = escape;
  } else {

  }
  return;
}
}
void zim_spl_SplFileObject_getCsvControl(int ht , zval *return_value ,
                                         zval **return_value_ptr ,
                                         zval *this_ptr , int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  char delimiter[2] ;
  char enclosure[2] ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  _array_init(return_value, (uint )0);
  delimiter[0] = intern->u.file.delimiter;
  delimiter[1] = (char )'\000';
  enclosure[0] = intern->u.file.enclosure;
  enclosure[1] = (char )'\000';
  add_next_index_string(return_value, (char const   *)(delimiter), 1);
  add_next_index_string(return_value, (char const   *)(enclosure), 1);
  return;
}
}
void zim_spl_SplFileObject_flock(int ht , zval *return_value ,
                                 zval **return_value_ptr , zval *this_ptr ,
                                 int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_function *func_ptr ;
  int ret ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_hash_find((HashTable const   *)executor_globals.function_table,
                           "flock", (uint )sizeof("flock"),
                           (void **)(& func_ptr));
  ret = (int )tmp___0;
  if (ret != 0) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_RuntimeException, 0L,
                            (char *)"Internal error, function \'%s\' not found. Please report",
                            "flock");
    return;
  } else {

  }
  spl_filesystem_file_call(intern, func_ptr, ht, return_value,
                           (zval *)((void *)0));
  return;
}
}
void zim_spl_SplFileObject_fflush(int ht , zval *return_value ,
                                  zval **return_value_ptr , zval *this_ptr ,
                                  int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval *__z ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  int tmp___1 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  while (1) {
    __z = return_value;
    tmp___0 = _php_stream_flush(intern->u.file.stream, 0);
    if (tmp___0) {
      tmp___1 = 0;
    } else {
      tmp___1 = 1;
    }
    __z->value.lval = (long )(tmp___1 != 0);
    __z->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zim_spl_SplFileObject_ftell(int ht , zval *return_value ,
                                 zval **return_value_ptr , zval *this_ptr ,
                                 int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  long ret ;
  off_t __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z ;
  zval *__z___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = _php_stream_tell(intern->u.file.stream);
  ret = (long )tmp___0;
  if (ret == -1L) {
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {
    __z___0 = return_value;
    __z___0->value.lval = ret;
    __z___0->type = (zend_uchar )1;
    return;
  }
}
}
void zim_spl_SplFileObject_fseek(int ht , zval *return_value ,
                                 zval **return_value_ptr , zval *this_ptr ,
                                 int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  long pos ;
  long whence ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z ;
  int __attribute__((__visibility__("default")))  tmp___1 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  whence = 0L;
  tmp___0 = zend_parse_parameters(ht, "l|l", & pos, & whence);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  spl_filesystem_file_free_line(intern);
  __z = return_value;
  tmp___1 = _php_stream_seek(intern->u.file.stream, pos, (int )whence);
  __z->value.lval = (long )tmp___1;
  __z->type = (zend_uchar )1;
  return;
}
}
void zim_spl_SplFileObject_fgetc(int ht , zval *return_value ,
                                 zval **return_value_ptr , zval *this_ptr ,
                                 int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  char buf[2] ;
  int result ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z ;
  char const   *__s ;
  int __l ;
  zval *__z___0 ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  spl_filesystem_file_free_line(intern);
  tmp___0 = _php_stream_getc(intern->u.file.stream);
  result = (int )tmp___0;
  if (result == -1) {
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
  } else {
    if (result == 10) {
      (intern->u.file.current_line_num) ++;
    } else {

    }
    buf[0] = (char )result;
    buf[1] = (char )'\000';
    while (1) {
      __s = (char const   *)(buf);
      __l = 1;
      __z___0 = return_value;
      __z___0->value.str.len = __l;
      tmp___1 = _estrndup(__s, (unsigned int )__l);
      __z___0->value.str.val = (char *)tmp___1;
      __z___0->type = (zend_uchar )6;
      break;
    }
    return;
  }
  return;
}
}
void zim_spl_SplFileObject_fgetss(int ht , zval *return_value ,
                                  zval **return_value_ptr , zval *this_ptr ,
                                  int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval *arg2 ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  zval *__z ;
  zval *__z___0 ;
  zend_function *func_ptr ;
  int ret ;
  int __attribute__((__visibility__("default")))  tmp___1 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  arg2 = (zval *)((void *)0);
  while (1) {
    tmp___0 = _emalloc(sizeof(zval_gc_info ));
    arg2 = (zval *)tmp___0;
    ((zval_gc_info *)arg2)->u.buffered = (gc_root_buffer *)((void *)0);
    break;
  }
  arg2->refcount__gc = (zend_uint )1;
  arg2->is_ref__gc = (zend_uchar )0;
  if (intern->u.file.max_line_len > 0UL) {
    __z = arg2;
    __z->value.lval = (long )intern->u.file.max_line_len;
    __z->type = (zend_uchar )1;
  } else {
    __z___0 = arg2;
    __z___0->value.lval = 1024L;
    __z___0->type = (zend_uchar )1;
  }
  spl_filesystem_file_free_line(intern);
  (intern->u.file.current_line_num) ++;
  tmp___1 = zend_hash_find((HashTable const   *)executor_globals.function_table,
                           "fgetss", (uint )sizeof("fgetss"),
                           (void **)(& func_ptr));
  ret = (int )tmp___1;
  if (ret != 0) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_RuntimeException, 0L,
                            (char *)"Internal error, function \'%s\' not found. Please report",
                            "fgetss");
    return;
  } else {

  }
  spl_filesystem_file_call(intern, func_ptr, ht, return_value, arg2);
  _zval_ptr_dtor(& arg2);
  return;
}
}
void zim_spl_SplFileObject_fpassthru(int ht , zval *return_value ,
                                     zval **return_value_ptr , zval *this_ptr ,
                                     int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval *__z ;
  size_t __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  __z = return_value;
  tmp___0 = _php_stream_passthru(intern->u.file.stream);
  __z->value.lval = (long )tmp___0;
  __z->type = (zend_uchar )1;
  return;
}
}
void zim_spl_SplFileObject_fscanf(int ht , zval *return_value ,
                                  zval **return_value_ptr , zval *this_ptr ,
                                  int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_function *func_ptr ;
  int ret ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  spl_filesystem_file_free_line(intern);
  (intern->u.file.current_line_num) ++;
  tmp___0 = zend_hash_find((HashTable const   *)executor_globals.function_table,
                           "fscanf", (uint )sizeof("fscanf"),
                           (void **)(& func_ptr));
  ret = (int )tmp___0;
  if (ret != 0) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_RuntimeException, 0L,
                            (char *)"Internal error, function \'%s\' not found. Please report",
                            "fscanf");
    return;
  } else {

  }
  spl_filesystem_file_call(intern, func_ptr, ht, return_value,
                           (zval *)((void *)0));
  return;
}
}
void zim_spl_SplFileObject_fwrite(int ht , zval *return_value ,
                                  zval **return_value_ptr , zval *this_ptr ,
                                  int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  char *str ;
  int str_len ;
  long length ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  long tmp___2 ;
  long tmp___3 ;
  zval *__z ;
  zval *__z___0 ;
  size_t __attribute__((__visibility__("default")))  tmp___4 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  length = 0L;
  tmp___0 = zend_parse_parameters(ht, "s|l", & str, & str_len, & length);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (ht > 1) {
    if (length < (long )str_len) {
      tmp___3 = length;
    } else {
      tmp___3 = (long )str_len;
    }
    if (0L > tmp___3) {
      str_len = 0;
    } else {
      if (length < (long )str_len) {
        tmp___2 = length;
      } else {
        tmp___2 = (long )str_len;
      }
      str_len = (int )tmp___2;
    }
  } else {

  }
  if (! str_len) {
    __z = return_value;
    __z->value.lval = 0L;
    __z->type = (zend_uchar )1;
    return;
  } else {

  }
  __z___0 = return_value;
  tmp___4 = _php_stream_write(intern->u.file.stream, (char const   *)str,
                              (size_t )str_len);
  __z___0->value.lval = (long )tmp___4;
  __z___0->type = (zend_uchar )1;
  return;
}
}
void zim_spl_SplFileObject_fstat(int ht , zval *return_value ,
                                 zval **return_value_ptr , zval *this_ptr ,
                                 int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_function *func_ptr ;
  int ret ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_hash_find((HashTable const   *)executor_globals.function_table,
                           "fstat", (uint )sizeof("fstat"),
                           (void **)(& func_ptr));
  ret = (int )tmp___0;
  if (ret != 0) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_RuntimeException, 0L,
                            (char *)"Internal error, function \'%s\' not found. Please report",
                            "fstat");
    return;
  } else {

  }
  spl_filesystem_file_call(intern, func_ptr, ht, return_value,
                           (zval *)((void *)0));
  return;
}
}
void zim_spl_SplFileObject_ftruncate(int ht , zval *return_value ,
                                     zval **return_value_ptr , zval *this_ptr ,
                                     int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  long size ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z ;
  int tmp___2 ;
  int __attribute__((__visibility__("default")))  tmp___3 ;
  zval *__z___0 ;
  int __attribute__((__visibility__("default")))  tmp___4 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "l", & size);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  tmp___3 = _php_stream_set_option(intern->u.file.stream, 10, 0, (void *)0);
  if (tmp___3 == (int __attribute__((__visibility__("default")))  )0) {
    tmp___2 = 1;
  } else {
    tmp___2 = 0;
  }
  if (! tmp___2) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_LogicException, 0L,
                            (char *)"Can\'t truncate file %s", intern->file_name);
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  while (1) {
    __z___0 = return_value;
    tmp___4 = _php_stream_truncate_set_size(intern->u.file.stream, (size_t )size);
    __z___0->value.lval = (long )((0 == (int )tmp___4) != 0);
    __z___0->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zim_spl_SplFileObject_seek(int ht , zval *return_value ,
                                zval **return_value_ptr , zval *this_ptr ,
                                int return_value_used ) 
{ 
  spl_filesystem_object *intern ;
  void __attribute__((__visibility__("default")))  *tmp ;
  long line_pos ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z ;
  int tmp___1 ;

  {
  tmp = zend_object_store_get_object((zval const   *)this_ptr);
  intern = (spl_filesystem_object *)tmp;
  tmp___0 = zend_parse_parameters(ht, "l", & line_pos);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (line_pos < 0L) {
    zend_throw_exception_ex((zend_class_entry *)spl_ce_LogicException, 0L,
                            (char *)"Can\'t seek file %s to negative line %ld",
                            intern->file_name, line_pos);
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  spl_filesystem_file_rewind(this_ptr, intern);
  while (intern->u.file.current_line_num < line_pos) {
    tmp___1 = spl_filesystem_file_read_line(this_ptr, intern, 1);
    if (tmp___1 == -1) {
      break;
    } else {

    }
  }
  return;
}
}
static zend_arg_info const   arginfo_file_object___construct[5]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"file_name", (zend_uint )(sizeof("file_name") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}, 
        {"open_mode", (zend_uint )(sizeof("open_mode") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}, 
        {"use_include_path", (zend_uint )(sizeof("use_include_path") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}, 
        {"context", (zend_uint )(sizeof("context") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_file_object_setFlags[2]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )-1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"flags", (zend_uint )(sizeof("flags") - 1UL), (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}};
static zend_arg_info const   arginfo_file_object_setMaxLineLen[2]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )-1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"max_len", (zend_uint )(sizeof("max_len") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_file_object_fgetcsv[4]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"delimiter", (zend_uint )(sizeof("delimiter") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}, 
        {"enclosure", (zend_uint )(sizeof("enclosure") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}, 
        {"escape", (zend_uint )(sizeof("escape") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_file_object_fputcsv[4]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"fields", (zend_uint )(sizeof("fields") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}, 
        {"delimiter", (zend_uint )(sizeof("delimiter") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}, 
        {"enclosure", (zend_uint )(sizeof("enclosure") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_file_object_flock[3]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"operation", (zend_uint )(sizeof("operation") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}, 
        {"wouldblock", (zend_uint )(sizeof("wouldblock") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )1}};
static zend_arg_info const   arginfo_file_object_fseek[3]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"pos", (zend_uint )(sizeof("pos") - 1UL), (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"whence", (zend_uint )(sizeof("whence") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_file_object_fgetss[2]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"allowable_tags", (zend_uint )(sizeof("allowable_tags") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_file_object_fscanf[2]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )1}, 
        {"format", (zend_uint )(sizeof("format") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_file_object_fwrite[3]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"str", (zend_uint )(sizeof("str") - 1UL), (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"length", (zend_uint )(sizeof("length") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_arg_info const   arginfo_file_object_ftruncate[2]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"size", (zend_uint )(sizeof("size") - 1UL), (char const   *)((void *)0),
      (zend_uint )0, (zend_uchar )0, (zend_bool )0, (zend_bool )0}};
static zend_arg_info const   arginfo_file_object_seek[2]  = {      {(char const   *)((void *)0), (zend_uint )0, (char const   *)((void *)0),
      (zend_uint )1, (zend_uchar )0, (zend_bool )0, (zend_bool )0}, 
        {"line_pos", (zend_uint )(sizeof("line_pos") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_function_entry const   spl_SplFileObject_functions[33]  = 
  {      {"__construct", & zim_spl_SplFileObject___construct,
      arginfo_file_object___construct,
      (zend_uint )(sizeof(arginfo_file_object___construct) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"rewind", & zim_spl_SplFileObject_rewind, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"eof", & zim_spl_SplFileObject_eof, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"valid", & zim_spl_SplFileObject_valid, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"fgets", & zim_spl_SplFileObject_fgets, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"fgetcsv", & zim_spl_SplFileObject_fgetcsv, arginfo_file_object_fgetcsv,
      (zend_uint )(sizeof(arginfo_file_object_fgetcsv) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"fputcsv", & zim_spl_SplFileObject_fputcsv, arginfo_file_object_fputcsv,
      (zend_uint )(sizeof(arginfo_file_object_fputcsv) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"setCsvControl", & zim_spl_SplFileObject_setCsvControl,
      arginfo_file_object_fgetcsv,
      (zend_uint )(sizeof(arginfo_file_object_fgetcsv) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getCsvControl", & zim_spl_SplFileObject_getCsvControl,
      arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"flock", & zim_spl_SplFileObject_flock, arginfo_file_object_flock,
      (zend_uint )(sizeof(arginfo_file_object_flock) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"fflush", & zim_spl_SplFileObject_fflush, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"ftell", & zim_spl_SplFileObject_ftell, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"fseek", & zim_spl_SplFileObject_fseek, arginfo_file_object_fseek,
      (zend_uint )(sizeof(arginfo_file_object_fseek) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"fgetc", & zim_spl_SplFileObject_fgetc, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"fpassthru", & zim_spl_SplFileObject_fpassthru, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"fgetss", & zim_spl_SplFileObject_fgetss, arginfo_file_object_fgetss,
      (zend_uint )(sizeof(arginfo_file_object_fgetss) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"fscanf", & zim_spl_SplFileObject_fscanf, arginfo_file_object_fscanf,
      (zend_uint )(sizeof(arginfo_file_object_fscanf) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"fwrite", & zim_spl_SplFileObject_fwrite, arginfo_file_object_fwrite,
      (zend_uint )(sizeof(arginfo_file_object_fwrite) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"fstat", & zim_spl_SplFileObject_fstat, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"ftruncate", & zim_spl_SplFileObject_ftruncate,
      arginfo_file_object_ftruncate,
      (zend_uint )(sizeof(arginfo_file_object_ftruncate) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"current", & zim_spl_SplFileObject_current, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"key", & zim_spl_SplFileObject_key, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"next", & zim_spl_SplFileObject_next, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"setFlags", & zim_spl_SplFileObject_setFlags,
      arginfo_file_object_setFlags,
      (zend_uint )(sizeof(arginfo_file_object_setFlags) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getFlags", & zim_spl_SplFileObject_getFlags, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"setMaxLineLen", & zim_spl_SplFileObject_setMaxLineLen,
      arginfo_file_object_setMaxLineLen,
      (zend_uint )(sizeof(arginfo_file_object_setMaxLineLen) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getMaxLineLen", & zim_spl_SplFileObject_getMaxLineLen,
      arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"hasChildren", & zim_spl_SplFileObject_hasChildren,
      arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getChildren", & zim_spl_SplFileObject_getChildren,
      arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"seek", & zim_spl_SplFileObject_seek, arginfo_file_object_seek,
      (zend_uint )(sizeof(arginfo_file_object_seek) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"getCurrentLine", & zim_spl_SplFileObject_fgets, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {"__toString", & zim_spl_SplFileObject_current, arginfo_splfileinfo_void,
      (zend_uint )(sizeof(arginfo_splfileinfo_void) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {(char const   *)((void *)0),
      (void (*)(int ht , zval *return_value ,
                zval **return_value_ptr , zval *this_ptr ,
                int return_value_used ))((void *)0),
      (struct _zend_arg_info  const  *)((void *)0), (zend_uint )0, (zend_uint )0}};
static zend_arg_info const   arginfo_temp_file_object___construct[2]  = {      {(char const   *)((void *)0),
      (zend_uint )0, (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0,
      (zend_bool )0, (zend_bool )0}, 
        {"max_memory", (zend_uint )(sizeof("max_memory") - 1UL),
      (char const   *)((void *)0), (zend_uint )0, (zend_uchar )0, (zend_bool )0,
      (zend_bool )0}};
static zend_function_entry const   spl_SplTempFileObject_functions[2]  = {      {"__construct", & zim_spl_SplTempFileObject___construct,
      arginfo_temp_file_object___construct,
      (zend_uint )(sizeof(arginfo_temp_file_object___construct) / sizeof(struct _zend_arg_info ) - 1UL),
      (zend_uint )256}, 
        {(char const   *)((void *)0),
      (void (*)(int ht , zval *return_value ,
                zval **return_value_ptr , zval *this_ptr ,
                int return_value_used ))((void *)0),
      (struct _zend_arg_info  const  *)((void *)0), (zend_uint )0, (zend_uint )0}};
int zm_startup_spl_directory(int type ,
                             int module_number ) 
{ 
  zend_object_handlers __attribute__((__visibility__("default")))  *tmp ;

  {
  spl_register_std_class((zend_class_entry **)(& spl_ce_SplFileInfo),
                         (char *)"SplFileInfo", & spl_filesystem_object_new,
                         spl_SplFileInfo_functions);
  tmp = zend_get_std_object_handlers();
  memcpy((void */* __restrict  */)(& spl_filesystem_object_handlers),
         (void const   */* __restrict  */)tmp, sizeof(zend_object_handlers ));
  spl_filesystem_object_handlers.clone_obj = & spl_filesystem_object_clone;
  spl_filesystem_object_handlers.cast_object = & spl_filesystem_object_cast;
  spl_filesystem_object_handlers.get_debug_info = & spl_filesystem_object_get_debug_info;
  spl_ce_SplFileInfo->serialize = (int (*)(zval *object ,
                                           unsigned char **buffer ,
                                           zend_uint *buf_len ,
                                           zend_serialize_data *data ))(& zend_class_serialize_deny);
  spl_ce_SplFileInfo->unserialize = (int (*)(zval **object ,
                                             zend_class_entry *ce ,
                                             unsigned char const   *buf ,
                                             zend_uint buf_len ,
                                             zend_unserialize_data *data ))(& zend_class_unserialize_deny);
  spl_register_sub_class((zend_class_entry **)(& spl_ce_DirectoryIterator),
                         (zend_class_entry *)spl_ce_SplFileInfo,
                         (char *)"DirectoryIterator",
                         & spl_filesystem_object_new,
                         spl_DirectoryIterator_functions);
  zend_class_implements((zend_class_entry *)spl_ce_DirectoryIterator, 1,
                        zend_ce_iterator);
  zend_class_implements((zend_class_entry *)spl_ce_DirectoryIterator, 1,
                        spl_ce_SeekableIterator);
  spl_ce_DirectoryIterator->get_iterator = & spl_filesystem_dir_get_iterator;
  spl_register_sub_class((zend_class_entry **)(& spl_ce_FilesystemIterator),
                         (zend_class_entry *)spl_ce_DirectoryIterator,
                         (char *)"FilesystemIterator",
                         & spl_filesystem_object_new,
                         spl_FilesystemIterator_functions);
  zend_declare_class_constant_long((zend_class_entry *)spl_ce_FilesystemIterator,
                                   "CURRENT_MODE_MASK",
                                   sizeof("CURRENT_MODE_MASK") - 1UL, 240L);
  zend_declare_class_constant_long((zend_class_entry *)spl_ce_FilesystemIterator,
                                   "CURRENT_AS_PATHNAME",
                                   sizeof("CURRENT_AS_PATHNAME") - 1UL, 32L);
  zend_declare_class_constant_long((zend_class_entry *)spl_ce_FilesystemIterator,
                                   "CURRENT_AS_FILEINFO",
                                   sizeof("CURRENT_AS_FILEINFO") - 1UL, 0L);
  zend_declare_class_constant_long((zend_class_entry *)spl_ce_FilesystemIterator,
                                   "CURRENT_AS_SELF",
                                   sizeof("CURRENT_AS_SELF") - 1UL, 16L);
  zend_declare_class_constant_long((zend_class_entry *)spl_ce_FilesystemIterator,
                                   "KEY_MODE_MASK",
                                   sizeof("KEY_MODE_MASK") - 1UL, 3840L);
  zend_declare_class_constant_long((zend_class_entry *)spl_ce_FilesystemIterator,
                                   "KEY_AS_PATHNAME",
                                   sizeof("KEY_AS_PATHNAME") - 1UL, 0L);
  zend_declare_class_constant_long((zend_class_entry *)spl_ce_FilesystemIterator,
                                   "FOLLOW_SYMLINKS",
                                   sizeof("FOLLOW_SYMLINKS") - 1UL, 512L);
  zend_declare_class_constant_long((zend_class_entry *)spl_ce_FilesystemIterator,
                                   "KEY_AS_FILENAME",
                                   sizeof("KEY_AS_FILENAME") - 1UL, 256L);
  zend_declare_class_constant_long((zend_class_entry *)spl_ce_FilesystemIterator,
                                   "NEW_CURRENT_AND_KEY",
                                   sizeof("NEW_CURRENT_AND_KEY") - 1UL, 256L);
  zend_declare_class_constant_long((zend_class_entry *)spl_ce_FilesystemIterator,
                                   "SKIP_DOTS", sizeof("SKIP_DOTS") - 1UL, 4096L);
  zend_declare_class_constant_long((zend_class_entry *)spl_ce_FilesystemIterator,
                                   "UNIX_PATHS", sizeof("UNIX_PATHS") - 1UL,
                                   8192L);
  spl_ce_FilesystemIterator->get_iterator = & spl_filesystem_tree_get_iterator;
  spl_register_sub_class((zend_class_entry **)(& spl_ce_RecursiveDirectoryIterator),
                         (zend_class_entry *)spl_ce_FilesystemIterator,
                         (char *)"RecursiveDirectoryIterator",
                         & spl_filesystem_object_new,
                         spl_RecursiveDirectoryIterator_functions);
  zend_class_implements((zend_class_entry *)spl_ce_RecursiveDirectoryIterator,
                        1, spl_ce_RecursiveIterator);
  memcpy((void */* __restrict  */)(& spl_filesystem_object_check_handlers),
         (void const   */* __restrict  */)(& spl_filesystem_object_handlers),
         sizeof(zend_object_handlers ));
  spl_filesystem_object_check_handlers.get_method = & spl_filesystem_object_get_method_check;
  spl_register_sub_class((zend_class_entry **)(& spl_ce_GlobIterator),
                         (zend_class_entry *)spl_ce_FilesystemIterator,
                         (char *)"GlobIterator",
                         & spl_filesystem_object_new_check,
                         spl_GlobIterator_functions);
  zend_class_implements((zend_class_entry *)spl_ce_GlobIterator, 1,
                        spl_ce_Countable);
  spl_register_sub_class((zend_class_entry **)(& spl_ce_SplFileObject),
                         (zend_class_entry *)spl_ce_SplFileInfo,
                         (char *)"SplFileObject",
                         & spl_filesystem_object_new_check,
                         spl_SplFileObject_functions);
  zend_class_implements((zend_class_entry *)spl_ce_SplFileObject, 1,
                        spl_ce_RecursiveIterator);
  zend_class_implements((zend_class_entry *)spl_ce_SplFileObject, 1,
                        spl_ce_SeekableIterator);
  zend_declare_class_constant_long((zend_class_entry *)spl_ce_SplFileObject,
                                   "DROP_NEW_LINE",
                                   sizeof("DROP_NEW_LINE") - 1UL, 1L);
  zend_declare_class_constant_long((zend_class_entry *)spl_ce_SplFileObject,
                                   "READ_AHEAD", sizeof("READ_AHEAD") - 1UL, 2L);
  zend_declare_class_constant_long((zend_class_entry *)spl_ce_SplFileObject,
                                   "SKIP_EMPTY", sizeof("SKIP_EMPTY") - 1UL, 4L);
  zend_declare_class_constant_long((zend_class_entry *)spl_ce_SplFileObject,
                                   "READ_CSV", sizeof("READ_CSV") - 1UL, 8L);
  spl_register_sub_class((zend_class_entry **)(& spl_ce_SplTempFileObject),
                         (zend_class_entry *)spl_ce_SplFileObject,
                         (char *)"SplTempFileObject",
                         & spl_filesystem_object_new_check,
                         spl_SplTempFileObject_functions);
  return (0);
}
}
