typedef long __off_t;
typedef long __off64_t;
typedef unsigned long size_t;
typedef signed char int8;
typedef unsigned char uint8;
typedef short int16;
typedef unsigned short uint16;
typedef int int32;
typedef unsigned int uint32;
struct __anonstruct_TIFFHeader_4 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
   uint32 tiff_diroff ;
};
typedef struct __anonstruct_TIFFHeader_4 TIFFHeader;
struct __anonstruct_TIFFDirEntry_5 {
   uint16 tdir_tag ;
   uint16 tdir_type ;
   uint32 tdir_count ;
   uint32 tdir_offset ;
};
typedef struct __anonstruct_TIFFDirEntry_5 TIFFDirEntry;
enum __anonenum_TIFFDataType_6 {
    TIFF_NOTYPE = 0,
    TIFF_BYTE = 1,
    TIFF_ASCII = 2,
    TIFF_SHORT = 3,
    TIFF_LONG = 4,
    TIFF_RATIONAL = 5,
    TIFF_SBYTE = 6,
    TIFF_UNDEFINED = 7,
    TIFF_SSHORT = 8,
    TIFF_SLONG = 9,
    TIFF_SRATIONAL = 10,
    TIFF_FLOAT = 11,
    TIFF_DOUBLE = 12,
    TIFF_IFD = 13
} ;
typedef enum __anonenum_TIFFDataType_6 TIFFDataType;
struct tiff;
struct tiff;
typedef struct tiff TIFF;
typedef uint32 ttag_t;
typedef uint16 tdir_t;
typedef uint16 tsample_t;
typedef uint32 tstrip_t;
typedef uint32 ttile_t;
typedef int32 tsize_t;
typedef void *tdata_t;
typedef uint32 toff_t;
typedef void *thandle_t;
struct _IO_FILE;
struct _IO_FILE;
struct _IO_FILE;
typedef struct _IO_FILE FILE;
typedef __builtin_va_list __gnuc_va_list;
struct _IO_FILE;
typedef void _IO_lock_t;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
struct _IO_FILE {
   int _flags ;
   char *_IO_read_ptr ;
   char *_IO_read_end ;
   char *_IO_read_base ;
   char *_IO_write_base ;
   char *_IO_write_ptr ;
   char *_IO_write_end ;
   char *_IO_buf_base ;
   char *_IO_buf_end ;
   char *_IO_save_base ;
   char *_IO_backup_base ;
   char *_IO_save_end ;
   struct _IO_marker *_markers ;
   struct _IO_FILE *_chain ;
   int _fileno ;
   int _flags2 ;
   __off_t _old_offset ;
   unsigned short _cur_column ;
   signed char _vtable_offset ;
   char _shortbuf[1] ;
   _IO_lock_t *_lock ;
   __off64_t _offset ;
   void *__pad1 ;
   void *__pad2 ;
   void *__pad3 ;
   void *__pad4 ;
   size_t __pad5 ;
   int _mode ;
   char _unused2[(15UL * sizeof(int ) - 4UL * sizeof(void *)) - sizeof(size_t )] ;
};
typedef __gnuc_va_list va_list;
struct __anonstruct_TIFFFieldInfo_16 {
   ttag_t field_tag ;
   short field_readcount ;
   short field_writecount ;
   TIFFDataType field_type ;
   unsigned short field_bit ;
   unsigned char field_oktochange ;
   unsigned char field_passcount ;
   char *field_name ;
};
typedef struct __anonstruct_TIFFFieldInfo_16 TIFFFieldInfo;
struct _TIFFTagValue {
   TIFFFieldInfo const   *info ;
   int count ;
   void *value ;
};
typedef struct _TIFFTagValue TIFFTagValue;
struct __anonstruct_TIFFTagMethods_17 {
   int (*vsetfield)(TIFF * , ttag_t  , va_list  ) ;
   int (*vgetfield)(TIFF * , ttag_t  , va_list  ) ;
   void (*printdir)(TIFF * , FILE * , long  ) ;
};
typedef struct __anonstruct_TIFFTagMethods_17 TIFFTagMethods;
struct __anonstruct_TIFFDirectory_18 {
   unsigned long td_fieldsset[4] ;
   uint32 td_imagewidth ;
   uint32 td_imagelength ;
   uint32 td_imagedepth ;
   uint32 td_tilewidth ;
   uint32 td_tilelength ;
   uint32 td_tiledepth ;
   uint32 td_subfiletype ;
   uint16 td_bitspersample ;
   uint16 td_sampleformat ;
   uint16 td_compression ;
   uint16 td_photometric ;
   uint16 td_threshholding ;
   uint16 td_fillorder ;
   uint16 td_orientation ;
   uint16 td_samplesperpixel ;
   uint32 td_rowsperstrip ;
   uint16 td_minsamplevalue ;
   uint16 td_maxsamplevalue ;
   double td_sminsamplevalue ;
   double td_smaxsamplevalue ;
   float td_xresolution ;
   float td_yresolution ;
   uint16 td_resolutionunit ;
   uint16 td_planarconfig ;
   float td_xposition ;
   float td_yposition ;
   uint16 td_pagenumber[2] ;
   uint16 *td_colormap[3] ;
   uint16 td_halftonehints[2] ;
   uint16 td_extrasamples ;
   uint16 *td_sampleinfo ;
   double td_stonits ;
   tstrip_t td_stripsperimage ;
   tstrip_t td_nstrips ;
   uint32 *td_stripoffset ;
   uint32 *td_stripbytecount ;
   int td_stripbytecountsorted ;
   uint16 td_nsubifd ;
   uint32 *td_subifd ;
   uint16 td_ycbcrsubsampling[2] ;
   uint16 td_ycbcrpositioning ;
   float *td_whitepoint ;
   uint16 *td_transferfunction[3] ;
   uint16 td_inkset ;
   uint16 td_ninks ;
   uint16 td_dotrange[2] ;
   int td_inknameslen ;
   char *td_inknames ;
   int td_customValueCount ;
   TIFFTagValue *td_customValues ;
};
typedef struct __anonstruct_TIFFDirectory_18 TIFFDirectory;
struct client_info {
   struct client_info *next ;
   void *data ;
   char *name ;
};
typedef struct client_info TIFFClientInfoLink;
typedef unsigned char tidataval_t;
typedef tidataval_t *tidata_t;
struct tiff {
   char *tif_name ;
   int tif_fd ;
   int tif_mode ;
   uint32 tif_flags ;
   toff_t tif_diroff ;
   toff_t tif_nextdiroff ;
   toff_t *tif_dirlist ;
   uint16 tif_dirnumber ;
   TIFFDirectory tif_dir ;
   TIFFHeader tif_header ;
   int const   *tif_typeshift ;
   long const   *tif_typemask ;
   uint32 tif_row ;
   tdir_t tif_curdir ;
   tstrip_t tif_curstrip ;
   toff_t tif_curoff ;
   toff_t tif_dataoff ;
   uint16 tif_nsubifd ;
   toff_t tif_subifdoff ;
   uint32 tif_col ;
   ttile_t tif_curtile ;
   tsize_t tif_tilesize ;
   int tif_decodestatus ;
   int (*tif_setupdecode)(TIFF * ) ;
   int (*tif_predecode)(TIFF * , tsample_t  ) ;
   int (*tif_setupencode)(TIFF * ) ;
   int tif_encodestatus ;
   int (*tif_preencode)(TIFF * , tsample_t  ) ;
   int (*tif_postencode)(TIFF * ) ;
   int (*tif_decoderow)(TIFF * , tidata_t  , tsize_t  , tsample_t  ) ;
   int (*tif_encoderow)(TIFF * , tidata_t  , tsize_t  , tsample_t  ) ;
   int (*tif_decodestrip)(TIFF * , tidata_t  , tsize_t  , tsample_t  ) ;
   int (*tif_encodestrip)(TIFF * , tidata_t  , tsize_t  , tsample_t  ) ;
   int (*tif_decodetile)(TIFF * , tidata_t  , tsize_t  , tsample_t  ) ;
   int (*tif_encodetile)(TIFF * , tidata_t  , tsize_t  , tsample_t  ) ;
   void (*tif_close)(TIFF * ) ;
   int (*tif_seek)(TIFF * , uint32  ) ;
   void (*tif_cleanup)(TIFF * ) ;
   uint32 (*tif_defstripsize)(TIFF * , uint32  ) ;
   void (*tif_deftilesize)(TIFF * , uint32 * , uint32 * ) ;
   tidata_t tif_data ;
   tsize_t tif_scanlinesize ;
   tsize_t tif_scanlineskew ;
   tidata_t tif_rawdata ;
   tsize_t tif_rawdatasize ;
   tidata_t tif_rawcp ;
   tsize_t tif_rawcc ;
   tidata_t tif_base ;
   toff_t tif_size ;
   int (*tif_mapproc)(thandle_t  , tdata_t * , toff_t * ) ;
   void (*tif_unmapproc)(thandle_t  , tdata_t  , toff_t  ) ;
   thandle_t tif_clientdata ;
   tsize_t (*tif_readproc)(thandle_t  , tdata_t  , tsize_t  ) ;
   tsize_t (*tif_writeproc)(thandle_t  , tdata_t  , tsize_t  ) ;
   toff_t (*tif_seekproc)(thandle_t  , toff_t  , int  ) ;
   int (*tif_closeproc)(thandle_t  ) ;
   toff_t (*tif_sizeproc)(thandle_t  ) ;
   void (*tif_postdecode)(TIFF * , tidata_t  , tsize_t  ) ;
   TIFFFieldInfo **tif_fieldinfo ;
   size_t tif_nfields ;
   TIFFFieldInfo const   *tif_foundfield ;
   TIFFTagMethods tif_tagmethods ;
   TIFFClientInfoLink *tif_clientinfo ;
};
extern tdata_t _TIFFrealloc(tdata_t  , tsize_t  ) ;
extern void _TIFFmemset(tdata_t  , int  , tsize_t  ) ;
extern void _TIFFmemcpy(tdata_t  , tdata_t const    , tsize_t  ) ;
extern void _TIFFfree(tdata_t  ) ;
extern void TIFFMergeFieldInfo(TIFF * , TIFFFieldInfo const   * , int  ) ;
extern TIFFFieldInfo const   *TIFFFieldWithTag(TIFF * , ttag_t  ) ;
int TIFFReadDirectory(TIFF *tif ) ;
int TIFFReadCustomDirectory(TIFF *tif , toff_t diroff ,
                            TIFFFieldInfo const   *info , size_t n ) ;
int TIFFReadEXIFDirectory(TIFF *tif , toff_t diroff ) ;
extern tsize_t TIFFScanlineSize(TIFF * ) ;
extern tsize_t TIFFStripSize(TIFF * ) ;
extern tsize_t TIFFTileSize(TIFF * ) ;
extern tsize_t TIFFVTileSize(TIFF * , uint32  ) ;
extern void TIFFFreeDirectory(TIFF * ) ;
extern int TIFFSetField(TIFF * , ttag_t   , ...) ;
extern void TIFFErrorExt(thandle_t  , char const   * , char const   *  , ...) ;
extern void TIFFWarning(char const   * , char const   *  , ...) ;
extern ttile_t TIFFNumberOfTiles(TIFF * ) ;
extern tstrip_t TIFFNumberOfStrips(TIFF * ) ;
extern int TIFFDataWidth(TIFFDataType  ) ;
extern void TIFFSwabShort(uint16 * ) ;
extern void TIFFSwabLong(uint32 * ) ;
extern void TIFFSwabArrayOfShort(uint16 * , unsigned long  ) ;
extern void TIFFSwabArrayOfLong(uint32 * , unsigned long  ) ;
extern void TIFFSwabArrayOfDouble(double * , unsigned long  ) ;
static TIFFFieldInfo const   exifFieldInfo[33]  = 
  {      {(ttag_t )33434, (short)1, (short)1, (TIFFDataType )5, (unsigned short)65,
      (unsigned char)1, (unsigned char)0, (char *)"ExposureTime"}, 
        {(ttag_t )33437, (short)1, (short)1, (TIFFDataType )5, (unsigned short)65,
      (unsigned char)1, (unsigned char)0, (char *)"FNumber"}, 
        {(ttag_t )34850, (short)1, (short)1, (TIFFDataType )3, (unsigned short)65,
      (unsigned char)1, (unsigned char)0, (char *)"ExposureProgram"}, 
        {(ttag_t )34852, (short)-1, (short)-1, (TIFFDataType )2,
      (unsigned short)65, (unsigned char)1, (unsigned char)0,
      (char *)"SpectralSensitivity"}, 
        {(ttag_t )34855, (short)-1, (short)-1, (TIFFDataType )3,
      (unsigned short)65, (unsigned char)1, (unsigned char)1,
      (char *)"ISOSpeedRatings"}, 
        {(ttag_t )34856, (short)-1, (short)-1, (TIFFDataType )7,
      (unsigned short)65, (unsigned char)1, (unsigned char)1,
      (char *)"OptoelectricConversionFactor"}, 
        {(ttag_t )36864, (short)4, (short)4, (TIFFDataType )7, (unsigned short)65,
      (unsigned char)1, (unsigned char)0, (char *)"ExifVersion"}, 
        {(ttag_t )37121, (short)4, (short)4, (TIFFDataType )7, (unsigned short)65,
      (unsigned char)1, (unsigned char)0, (char *)"ComponentsConfiguration"}, 
        {(ttag_t )37122, (short)1, (short)1, (TIFFDataType )5, (unsigned short)65,
      (unsigned char)1, (unsigned char)0, (char *)"CompressedBitsPerPixel"}, 
        {(ttag_t )37377, (short)1, (short)1, (TIFFDataType )10, (unsigned short)65,
      (unsigned char)1, (unsigned char)0, (char *)"ShutterSpeedValue"}, 
        {(ttag_t )37378, (short)1, (short)1, (TIFFDataType )5, (unsigned short)65,
      (unsigned char)1, (unsigned char)0, (char *)"ApertureValue"}, 
        {(ttag_t )37379, (short)1, (short)1, (TIFFDataType )10, (unsigned short)65,
      (unsigned char)1, (unsigned char)0, (char *)"BrightnessValue"}, 
        {(ttag_t )37380, (short)1, (short)1, (TIFFDataType )10, (unsigned short)65,
      (unsigned char)1, (unsigned char)0, (char *)"ExposureBiasValue"}, 
        {(ttag_t )37381, (short)1, (short)1, (TIFFDataType )5, (unsigned short)65,
      (unsigned char)1, (unsigned char)0, (char *)"MaxApertureValue"}, 
        {(ttag_t )37382, (short)1, (short)1, (TIFFDataType )5, (unsigned short)65,
      (unsigned char)1, (unsigned char)0, (char *)"SubjectDistance"}, 
        {(ttag_t )37383, (short)1, (short)1, (TIFFDataType )3, (unsigned short)65,
      (unsigned char)1, (unsigned char)0, (char *)"MeteringMode"}, 
        {(ttag_t )37384, (short)1, (short)1, (TIFFDataType )3, (unsigned short)65,
      (unsigned char)1, (unsigned char)0, (char *)"LightSource"}, 
        {(ttag_t )37385, (short)1, (short)1, (TIFFDataType )3, (unsigned short)65,
      (unsigned char)1, (unsigned char)0, (char *)"Flash"}, 
        {(ttag_t )37386, (short)1, (short)1, (TIFFDataType )5, (unsigned short)65,
      (unsigned char)1, (unsigned char)0, (char *)"FocalLength"}, 
        {(ttag_t )37500, (short)-1, (short)-1, (TIFFDataType )7,
      (unsigned short)65, (unsigned char)1, (unsigned char)1,
      (char *)"MakerNote"}, 
        {(ttag_t )37510, (short)-1, (short)-1, (TIFFDataType )7,
      (unsigned short)65, (unsigned char)1, (unsigned char)1,
      (char *)"UserComment"}, 
        {(ttag_t )36867, (short)20, (short)20, (TIFFDataType )2,
      (unsigned short)65, (unsigned char)1, (unsigned char)0,
      (char *)"DateTimeOriginal"}, 
        {(ttag_t )36868, (short)20, (short)20, (TIFFDataType )2,
      (unsigned short)65, (unsigned char)1, (unsigned char)0,
      (char *)"DateTimeDigitized"}, 
        {(ttag_t )37520, (short)-1, (short)-1, (TIFFDataType )2,
      (unsigned short)65, (unsigned char)1, (unsigned char)0,
      (char *)"SubSecTime"}, 
        {(ttag_t )37521, (short)-1, (short)-1, (TIFFDataType )2,
      (unsigned short)65, (unsigned char)1, (unsigned char)0,
      (char *)"SubSecTimeOriginal"}, 
        {(ttag_t )37522, (short)-1, (short)-1, (TIFFDataType )2,
      (unsigned short)65, (unsigned char)1, (unsigned char)0,
      (char *)"SubSecTimeDigitized"}, 
        {(ttag_t )40960, (short)4, (short)4, (TIFFDataType )7, (unsigned short)65,
      (unsigned char)1, (unsigned char)0, (char *)"FlashpixVersion"}, 
        {(ttag_t )40962, (short)1, (short)1, (TIFFDataType )4, (unsigned short)65,
      (unsigned char)1, (unsigned char)0, (char *)"PixelXDimension"}, 
        {(ttag_t )40962, (short)1, (short)1, (TIFFDataType )3, (unsigned short)65,
      (unsigned char)1, (unsigned char)0, (char *)"PixelXDimension"}, 
        {(ttag_t )40963, (short)1, (short)1, (TIFFDataType )4, (unsigned short)65,
      (unsigned char)1, (unsigned char)0, (char *)"PixelYDimension"}, 
        {(ttag_t )40963, (short)1, (short)1, (TIFFDataType )3, (unsigned short)65,
      (unsigned char)1, (unsigned char)0, (char *)"PixelYDimension"}, 
        {(ttag_t )40964, (short)13, (short)13, (TIFFDataType )2,
      (unsigned short)65, (unsigned char)1, (unsigned char)0,
      (char *)"RelatedSoundFile"}, 
        {(ttag_t )42016, (short)33, (short)33, (TIFFDataType )2,
      (unsigned short)65, (unsigned char)1, (unsigned char)0,
      (char *)"ImageUniqueID"}};
extern void _TIFFSetupFieldInfo(TIFF * , TIFFFieldInfo const   * , int  ) ;
extern TIFFFieldInfo *_TIFFCreateAnonFieldInfo(TIFF *tif , ttag_t tag ,
                                               TIFFDataType dt ) ;
extern int TIFFDefaultDirectory(TIFF * ) ;
extern tdata_t _TIFFCheckMalloc(TIFF * , size_t  , size_t  , char const   * ) ;
static int EstimateStripByteCounts(TIFF *tif , TIFFDirEntry *dir ,
                                   uint16 dircount ) ;
static void MissingRequired(TIFF *tif , char const   *tagname ) ;
static int CheckDirCount(TIFF *tif , TIFFDirEntry *dir , uint32 count ) ;
static tsize_t TIFFFetchData(TIFF *tif , TIFFDirEntry *dir , char *cp ) ;
static tsize_t TIFFFetchString(TIFF *tif , TIFFDirEntry *dir , char *cp ) ;
static float TIFFFetchRational(TIFF *tif , TIFFDirEntry *dir ) ;
static int TIFFFetchNormalTag(TIFF *tif , TIFFDirEntry *dp ) ;
static int TIFFFetchPerSampleShorts(TIFF *tif , TIFFDirEntry *dir , uint16 *pl ) ;
static int TIFFFetchPerSampleLongs(TIFF *tif , TIFFDirEntry *dir , uint32 *pl ) ;
static int TIFFFetchPerSampleAnys(TIFF *tif , TIFFDirEntry *dir , double *pl ) ;
static int TIFFFetchShortArray(TIFF *tif , TIFFDirEntry *dir , uint16 *v ) ;
static int TIFFFetchStripThing(TIFF *tif , TIFFDirEntry *dir , long nstrips ,
                               uint32 **lpp ) ;
static int TIFFFetchRefBlackWhite(TIFF *tif , TIFFDirEntry *dir ) ;
static float TIFFFetchFloat(TIFF *tif , TIFFDirEntry *dir ) ;
static int TIFFFetchFloatArray(TIFF *tif , TIFFDirEntry *dir , float *v ) ;
static int TIFFFetchDoubleArray(TIFF *tif , TIFFDirEntry *dir , double *v ) ;
static int TIFFFetchAnyArray(TIFF *tif , TIFFDirEntry *dir , double *v ) ;
static int TIFFFetchShortPair(TIFF *tif , TIFFDirEntry *dir ) ;
static void ChopUpSingleUncompressedStrip(TIFF *tif ) ;
static char const   module[18]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'R',      (char const   )'e',      (char const   )'a',      (char const   )'d', 
        (char const   )'D',      (char const   )'i',      (char const   )'r',      (char const   )'e', 
        (char const   )'c',      (char const   )'t',      (char const   )'o',      (char const   )'r', 
        (char const   )'y',      (char const   )'\000'};
int TIFFReadDirectory(TIFF *tif ) 
{ 
  int n ;
  TIFFDirectory *td ;
  TIFFDirEntry *dp ;
  TIFFDirEntry *dir ;
  uint16 iv ;
  uint32 v ;
  TIFFFieldInfo const   *fip ;
  size_t fix ;
  uint16 dircount ;
  toff_t nextdiroff ;
  char *cp ;
  int diroutoforderwarning ;
  toff_t *new_dirlist ;
  tdata_t tmp ;
  toff_t tmp___0 ;
  tsize_t tmp___1 ;
  tdata_t tmp___2 ;
  tsize_t tmp___3 ;
  tsize_t tmp___4 ;
  toff_t off ;
  tdata_t tmp___5 ;
  int tmp___6 ;
  TIFFFieldInfo *tmp___7 ;
  uint32 expected ;
  uint32 tmp___8 ;
  int tmp___9 ;
  long tmp___10 ;
  int tmp___11 ;
  int tmp___12 ;
  int tmp___13 ;
  int tmp___14 ;
  int tmp___15 ;
  int tmp___16 ;
  char const   *tmp___17 ;
  char const   *tmp___18 ;
  long tmp___19 ;
  int tmp___20 ;
  int tmp___21 ;
  int tmp___22 ;
  int tmp___23 ;
  int tmp___24 ;
  double dv ;
  int tmp___25 ;
  int tmp___26 ;
  int tmp___27 ;
  int tmp___28 ;
  int tmp___29 ;
  tdata_t tmp___30 ;
  uint32 c ;
  tsize_t tmp___31 ;
  long tmp___32 ;
  TIFFFieldInfo const   *tmp___33 ;
  int tmp___34 ;
  TIFFFieldInfo const   *tmp___35 ;
  int tmp___36 ;
  TIFFFieldInfo const   *tmp___37 ;
  int tmp___38 ;
  toff_t tmp___39 ;
  tsize_t tmp___40 ;
  tstrip_t strip ;
  tsize_t tmp___41 ;

  {
  dir = (TIFFDirEntry *)((void *)0);
  diroutoforderwarning = 0;
  tif->tif_diroff = tif->tif_nextdiroff;
  if (tif->tif_diroff == 0U) {
    return (0);
  } else {

  }
  n = 0;
  while (n < (int )tif->tif_dirnumber) {
    if (*(tif->tif_dirlist + n) == tif->tif_diroff) {
      return (0);
    } else {

    }
    n ++;
  }
  tif->tif_dirnumber = (uint16 )((int )tif->tif_dirnumber + 1);
  tmp = _TIFFrealloc((tdata_t )tif->tif_dirlist,
                     (tsize_t )((unsigned long )tif->tif_dirnumber * sizeof(toff_t )));
  new_dirlist = (toff_t *)tmp;
  if (! new_dirlist) {
    TIFFErrorExt(tif->tif_clientdata, module,
                 "%s: Failed to allocate space for IFD list", tif->tif_name);
    return (0);
  } else {

  }
  tif->tif_dirlist = new_dirlist;
  *(tif->tif_dirlist + ((int )tif->tif_dirnumber - 1)) = tif->tif_diroff;
  (*(tif->tif_cleanup))(tif);
  tif->tif_curdir = (tdir_t )((int )tif->tif_curdir + 1);
  nextdiroff = (toff_t )0;
  if (! ((tif->tif_flags & 2048U) != 0U)) {
    tmp___0 = (*(tif->tif_seekproc))(tif->tif_clientdata, tif->tif_diroff, 0);
    if (! (tmp___0 == tif->tif_diroff)) {
      TIFFErrorExt(tif->tif_clientdata, module,
                   "%s: Seek error accessing TIFF directory", tif->tif_name);
      return (0);
    } else {

    }
    tmp___1 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                     (tdata_t )(& dircount),
                                     (tsize_t )sizeof(uint16 ));
    if (! (tmp___1 == (tsize_t )sizeof(uint16 ))) {
      TIFFErrorExt(tif->tif_clientdata, module,
                   "%s: Can not read TIFF directory count", tif->tif_name);
      return (0);
    } else {

    }
    if (tif->tif_flags & 128U) {
      TIFFSwabShort(& dircount);
    } else {

    }
    tmp___2 = _TIFFCheckMalloc(tif, (size_t )dircount, sizeof(TIFFDirEntry ),
                               "to read TIFF directory");
    dir = (TIFFDirEntry *)tmp___2;
    if ((unsigned long )dir == (unsigned long )((void *)0)) {
      return (0);
    } else {

    }
    tmp___3 = (*(tif->tif_readproc))(tif->tif_clientdata, (tdata_t )dir,
                                     (tsize_t )((unsigned long )dircount * sizeof(TIFFDirEntry )));
    if (! (tmp___3 == (tsize_t )((unsigned long )dircount * sizeof(TIFFDirEntry )))) {
      TIFFErrorExt(tif->tif_clientdata, module,
                   "%.100s: Can not read TIFF directory", tif->tif_name);
      goto bad;
    } else {

    }
    tmp___4 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                     (tdata_t )(& nextdiroff),
                                     (tsize_t )sizeof(uint32 ));
  } else {
    off = tif->tif_diroff;
    if ((unsigned long )off + sizeof(uint16 ) > (unsigned long )tif->tif_size) {
      TIFFErrorExt(tif->tif_clientdata, module,
                   "%s: Can not read TIFF directory count", tif->tif_name);
      return (0);
    } else {
      _TIFFmemcpy((tdata_t )(& dircount),
                  (tdata_t const   )(tif->tif_base + off),
                  (tsize_t )sizeof(uint16 ));
    }
    off = (toff_t )((unsigned long )off + sizeof(uint16 ));
    if (tif->tif_flags & 128U) {
      TIFFSwabShort(& dircount);
    } else {

    }
    tmp___5 = _TIFFCheckMalloc(tif, (size_t )dircount, sizeof(TIFFDirEntry ),
                               "to read TIFF directory");
    dir = (TIFFDirEntry *)tmp___5;
    if ((unsigned long )dir == (unsigned long )((void *)0)) {
      return (0);
    } else {

    }
    if ((unsigned long )off + (unsigned long )dircount * sizeof(TIFFDirEntry ) > (unsigned long )tif->tif_size) {
      TIFFErrorExt(tif->tif_clientdata, module,
                   "%s: Can not read TIFF directory", tif->tif_name);
      goto bad;
    } else {
      _TIFFmemcpy((tdata_t )dir, (tdata_t const   )(tif->tif_base + off),
                  (tsize_t )((unsigned long )dircount * sizeof(TIFFDirEntry )));
    }
    off = (toff_t )((unsigned long )off + (unsigned long )dircount * sizeof(TIFFDirEntry ));
    if ((unsigned long )off + sizeof(uint32 ) <= (unsigned long )tif->tif_size) {
      _TIFFmemcpy((tdata_t )(& nextdiroff),
                  (tdata_t const   )(tif->tif_base + off),
                  (tsize_t )sizeof(uint32 ));
    } else {

    }
  }
  if (tif->tif_flags & 128U) {
    TIFFSwabLong(& nextdiroff);
  } else {

  }
  tif->tif_nextdiroff = nextdiroff;
  tif->tif_flags &= 4294967231U;
  td = & tif->tif_dir;
  TIFFFreeDirectory(tif);
  TIFFDefaultDirectory(tif);
  TIFFSetField(tif, (ttag_t )284, 1);
  dp = dir;
  n = (int )dircount;
  while (n > 0) {
    if (tif->tif_flags & 128U) {
      TIFFSwabArrayOfShort(& dp->tdir_tag, 2UL);
      TIFFSwabArrayOfLong(& dp->tdir_count, 2UL);
    } else {

    }
    if ((int )dp->tdir_tag == 277) {
      tmp___6 = TIFFFetchNormalTag(tif, dp);
      if (! tmp___6) {
        goto bad;
      } else {

      }
      dp->tdir_tag = (uint16 )0;
    } else {

    }
    n --;
    dp ++;
  }
  fix = (size_t )0;
  dp = dir;
  n = (int )dircount;
  while (n > 0) {
    if (fix >= tif->tif_nfields) {
      goto __Cont;
    } else
    if ((int )dp->tdir_tag == 0) {
      goto __Cont;
    } else {

    }
    if ((ttag_t )dp->tdir_tag < (*(tif->tif_fieldinfo + fix))->field_tag) {
      if (! diroutoforderwarning) {
        TIFFWarning(module,
                    "%s: invalid TIFF directory; tags are not sorted in ascending order",
                    tif->tif_name);
        diroutoforderwarning = 1;
      } else {

      }
      fix = (size_t )0;
    } else {

    }
    while (1) {
      if (fix < tif->tif_nfields) {
        if (! ((*(tif->tif_fieldinfo + fix))->field_tag < (ttag_t )dp->tdir_tag)) {
          break;
        } else {

        }
      } else {
        break;
      }
      fix ++;
    }
    if (fix >= tif->tif_nfields) {
      goto _L;
    } else
    if ((*(tif->tif_fieldinfo + fix))->field_tag != (ttag_t )dp->tdir_tag) {
      _L: 
      TIFFWarning(module, "%s: unknown field with tag %d (0x%x) encountered",
                  tif->tif_name, (int )dp->tdir_tag, (int )dp->tdir_tag,
                  (int )dp->tdir_type);
      tmp___7 = _TIFFCreateAnonFieldInfo(tif, (ttag_t )dp->tdir_tag,
                                         (TIFFDataType )dp->tdir_type);
      TIFFMergeFieldInfo(tif, (TIFFFieldInfo const   *)tmp___7, 1);
      fix = (size_t )0;
      while (1) {
        if (fix < tif->tif_nfields) {
          if (! ((*(tif->tif_fieldinfo + fix))->field_tag < (ttag_t )dp->tdir_tag)) {
            break;
          } else {

          }
        } else {
          break;
        }
        fix ++;
      }
    } else {

    }
    if ((int )(*(tif->tif_fieldinfo + fix))->field_bit == 0) {
      ignore: 
      dp->tdir_tag = (uint16 )0;
      goto __Cont;
    } else {

    }
    fip = (TIFFFieldInfo const   *)*(tif->tif_fieldinfo + fix);
    while (1) {
      if ((int )dp->tdir_type != (int )((unsigned short )fip->field_type)) {
        if (! (fix < tif->tif_nfields)) {
          break;
        } else {

        }
      } else {
        break;
      }
      if ((unsigned int const   )fip->field_type == 0U) {
        break;
      } else {

      }
      fix ++;
      fip = (TIFFFieldInfo const   *)*(tif->tif_fieldinfo + fix);
      if (fix >= tif->tif_nfields) {
        TIFFWarning(module, "%s: wrong data type %d for \"%s\"; tag ignored",
                    tif->tif_name, (int )dp->tdir_type,
                    (*(tif->tif_fieldinfo + (fix - 1UL)))->field_name);
        goto ignore;
      } else
      if (fip->field_tag != (ttag_t const   )dp->tdir_tag) {
        TIFFWarning(module, "%s: wrong data type %d for \"%s\"; tag ignored",
                    tif->tif_name, (int )dp->tdir_type,
                    (*(tif->tif_fieldinfo + (fix - 1UL)))->field_name);
        goto ignore;
      } else {

      }
    }
    if ((int const   )fip->field_readcount != -1) {
      if ((int const   )fip->field_readcount != -3) {
        if ((int const   )fip->field_readcount == -2) {
          tmp___8 = (uint32 )td->td_samplesperpixel;
        } else {
          tmp___8 = (uint32 )fip->field_readcount;
        }
        expected = tmp___8;
        tmp___9 = CheckDirCount(tif, dp, expected);
        if (! tmp___9) {
          goto ignore;
        } else {

        }
      } else {

      }
    } else {

    }
    switch ((int )dp->tdir_tag) {
    case 259: 
    if (dp->tdir_count == 1U) {
      if ((int )tif->tif_header.tiff_magic == 19789) {
        tmp___10 = (long )((long const   )(dp->tdir_offset >> *(tif->tif_typeshift + (int )dp->tdir_type)) & *(tif->tif_typemask + (int )dp->tdir_type));
      } else {
        tmp___10 = (long )((long const   )dp->tdir_offset & *(tif->tif_typemask + (int )dp->tdir_type));
      }
      v = (uint32 )tmp___10;
      tmp___11 = TIFFSetField(tif, (ttag_t )dp->tdir_tag, (int )((uint16 )v));
      if (! tmp___11) {
        goto bad;
      } else {

      }
      break;
    } else
    if ((int )dp->tdir_type == 4) {
      tmp___12 = TIFFFetchPerSampleLongs(tif, dp, & v);
      if (tmp___12) {
        tmp___13 = TIFFSetField(tif, (ttag_t )dp->tdir_tag, (int )((uint16 )v));
        if (! tmp___13) {
          goto bad;
        } else {

        }
      } else {
        goto bad;
      }
    } else {
      tmp___14 = TIFFFetchPerSampleShorts(tif, dp, & iv);
      if (tmp___14) {
        tmp___15 = TIFFSetField(tif, (ttag_t )dp->tdir_tag, (int )iv);
        if (! tmp___15) {
          goto bad;
        } else {

        }
      } else {
        goto bad;
      }
    }
    dp->tdir_tag = (uint16 )0;
    break;
    case 273: 
    case 279: 
    case 324: 
    case 325: 
    tif->tif_dir.td_fieldsset[(int const   )fip->field_bit / 32] |= 1UL << ((int const   )fip->field_bit & 31);
    break;
    case 256: 
    case 257: 
    case 32997: 
    case 323: 
    case 322: 
    case 32998: 
    case 284: 
    case 278: 
    case 338: 
    tmp___16 = TIFFFetchNormalTag(tif, dp);
    if (! tmp___16) {
      goto bad;
    } else {

    }
    dp->tdir_tag = (uint16 )0;
    break;
    }
    __Cont: 
    n --;
    dp ++;
  }
  if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 1))) {
    MissingRequired(tif, "ImageLength");
    goto bad;
  } else {

  }
  if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 20))) {
    MissingRequired(tif, "PlanarConfiguration");
    goto bad;
  } else {

  }
  if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 2))) {
    td->td_nstrips = TIFFNumberOfStrips(tif);
    td->td_tilewidth = td->td_imagewidth;
    td->td_tilelength = td->td_rowsperstrip;
    td->td_tiledepth = td->td_imagedepth;
    tif->tif_flags &= 4294966271U;
  } else {
    td->td_nstrips = TIFFNumberOfTiles(tif);
    tif->tif_flags |= 1024U;
  }
  if (! td->td_nstrips) {
    if ((tif->tif_flags & 1024U) != 0U) {
      tmp___17 = "tiles";
    } else {
      tmp___17 = "strips";
    }
    TIFFErrorExt(tif->tif_clientdata, module,
                 "%s: cannot handle zero number of %s", tif->tif_name, tmp___17);
    goto bad;
  } else {

  }
  td->td_stripsperimage = td->td_nstrips;
  if ((int )td->td_planarconfig == 2) {
    td->td_stripsperimage /= (tstrip_t )td->td_samplesperpixel;
  } else {

  }
  if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 25))) {
    if ((tif->tif_flags & 1024U) != 0U) {
      tmp___18 = "TileOffsets";
    } else {
      tmp___18 = "StripOffsets";
    }
    MissingRequired(tif, tmp___18);
    goto bad;
  } else {

  }
  dp = dir;
  n = (int )dircount;
  while (n > 0) {
    if ((int )dp->tdir_tag == 0) {
      goto __Cont___0;
    } else {

    }
    switch ((int )dp->tdir_tag) {
    case 280: 
    case 281: 
    case 258: 
    case 32996: 
    case 339: 
    if (dp->tdir_count == 1U) {
      if ((int )tif->tif_header.tiff_magic == 19789) {
        tmp___19 = (long )((long const   )(dp->tdir_offset >> *(tif->tif_typeshift + (int )dp->tdir_type)) & *(tif->tif_typemask + (int )dp->tdir_type));
      } else {
        tmp___19 = (long )((long const   )dp->tdir_offset & *(tif->tif_typemask + (int )dp->tdir_type));
      }
      v = (uint32 )tmp___19;
      tmp___20 = TIFFSetField(tif, (ttag_t )dp->tdir_tag, (int )((uint16 )v));
      if (! tmp___20) {
        goto bad;
      } else {

      }
    } else
    if ((int )dp->tdir_tag == 258) {
      if ((int )dp->tdir_type == 4) {
        tmp___21 = TIFFFetchPerSampleLongs(tif, dp, & v);
        if (tmp___21) {
          tmp___22 = TIFFSetField(tif, (ttag_t )dp->tdir_tag, (int )((uint16 )v));
          if (! tmp___22) {
            goto bad;
          } else {

          }
        } else {
          goto bad;
        }
      } else {
        goto _L___0;
      }
    } else {
      _L___0: 
      tmp___23 = TIFFFetchPerSampleShorts(tif, dp, & iv);
      if (tmp___23) {
        tmp___24 = TIFFSetField(tif, (ttag_t )dp->tdir_tag, (int )iv);
        if (! tmp___24) {
          goto bad;
        } else {

        }
      } else {
        goto bad;
      }
    }
    break;
    case 340: 
    case 341: 
    dv = 0.0;
    tmp___25 = TIFFFetchPerSampleAnys(tif, dp, & dv);
    if (tmp___25) {
      tmp___26 = TIFFSetField(tif, (ttag_t )dp->tdir_tag, dv);
      if (! tmp___26) {
        goto bad;
      } else {

      }
    } else {
      goto bad;
    }
    break;
    case 273: 
    case 324: 
    tmp___27 = TIFFFetchStripThing(tif, dp, (long )td->td_nstrips,
                                   & td->td_stripoffset);
    if (! tmp___27) {
      goto bad;
    } else {

    }
    break;
    case 279: 
    case 325: 
    tmp___28 = TIFFFetchStripThing(tif, dp, (long )td->td_nstrips,
                                   & td->td_stripbytecount);
    if (! tmp___28) {
      goto bad;
    } else {

    }
    break;
    case 320: 
    case 301: 
    v = (uint32 )(1L << (int )td->td_bitspersample);
    if ((int )dp->tdir_tag == 320) {
      goto _L___1;
    } else
    if (dp->tdir_count != v) {
      _L___1: 
      tmp___29 = CheckDirCount(tif, dp, 3U * v);
      if (! tmp___29) {
        break;
      } else {

      }
    } else {

    }
    v = (uint32 )((unsigned long )v * sizeof(uint16 ));
    tmp___30 = _TIFFCheckMalloc(tif, (size_t )dp->tdir_count, sizeof(uint16 ),
                                "to read \"TransferFunction\" tag");
    cp = (char *)tmp___30;
    if ((unsigned long )cp != (unsigned long )((void *)0)) {
      tmp___31 = TIFFFetchData(tif, dp, cp);
      if (tmp___31) {
        c = (uint32 )(1L << (int )td->td_bitspersample);
        if (dp->tdir_count == c) {
          v = (uint32 )0L;
        } else {

        }
        TIFFSetField(tif, (ttag_t )dp->tdir_tag, cp, cp + v, cp + 2U * v);
      } else {

      }
      _TIFFfree((tdata_t )cp);
    } else {

    }
    break;
    case 297: 
    case 321: 
    case 530: 
    case 336: 
    TIFFFetchShortPair(tif, dp);
    break;
    case 532: 
    TIFFFetchRefBlackWhite(tif, dp);
    break;
    case 255: 
    v = (uint32 )0L;
    if ((int )tif->tif_header.tiff_magic == 19789) {
      tmp___32 = (long )((long const   )(dp->tdir_offset >> *(tif->tif_typeshift + (int )dp->tdir_type)) & *(tif->tif_typemask + (int )dp->tdir_type));
    } else {
      tmp___32 = (long )((long const   )dp->tdir_offset & *(tif->tif_typemask + (int )dp->tdir_type));
    }
    switch ((uint32 )tmp___32) {
    case 2U: 
    v = (uint32 )1;
    break;
    case 3U: 
    v = (uint32 )2;
    break;
    }
    if (v) {
      TIFFSetField(tif, (ttag_t )254, v);
    } else {

    }
    break;
    default: 
    TIFFFetchNormalTag(tif, dp);
    break;
    }
    __Cont___0: 
    n --;
    dp ++;
  }
  if ((int )td->td_photometric == 3) {
    if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 26))) {
      MissingRequired(tif, "Colormap");
      goto bad;
    } else {

    }
  } else {

  }
  if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 24))) {
    if ((int )td->td_planarconfig == 1) {
      if (td->td_nstrips > 1U) {
        MissingRequired(tif, "StripByteCounts");
        goto bad;
      } else {
        goto _L___2;
      }
    } else
    _L___2: 
    if ((int )td->td_planarconfig == 2) {
      if (td->td_nstrips != (tstrip_t )td->td_samplesperpixel) {
        MissingRequired(tif, "StripByteCounts");
        goto bad;
      } else {

      }
    } else {

    }
    tmp___33 = TIFFFieldWithTag(tif, (ttag_t )279);
    TIFFWarning(module,
                "%s: TIFF directory is missing required \"%s\" field, calculating from imagelength",
                tif->tif_name, tmp___33->field_name);
    tmp___34 = EstimateStripByteCounts(tif, dir, dircount);
    if (tmp___34 < 0) {
      goto bad;
    } else {

    }
  } else
  if (td->td_nstrips == 1U) {
    if (*(td->td_stripoffset + 0) != 0U) {
      if (*(td->td_stripbytecount + 0) == 0U) {
        if (*(td->td_stripoffset + 0) != 0U) {
          goto _L___4;
        } else {
          goto _L___6;
        }
      } else
      _L___6: 
      if ((int )td->td_compression == 1) {
        tmp___39 = (*(tif->tif_sizeproc))(tif->tif_clientdata);
        if (*(td->td_stripbytecount + 0) > tmp___39 - *(td->td_stripoffset + 0)) {
          goto _L___4;
        } else {
          goto _L___5;
        }
      } else
      _L___5: 
      if (tif->tif_mode == 0) {
        if ((int )td->td_compression == 1) {
          tmp___40 = TIFFScanlineSize(tif);
          if (*(td->td_stripbytecount + 0) < (uint32 )tmp___40 * td->td_imagelength) {
            _L___4: 
            tmp___35 = TIFFFieldWithTag(tif, (ttag_t )279);
            TIFFWarning(module,
                        "%s: Bogus \"%s\" field, ignoring and calculating from imagelength",
                        tif->tif_name, tmp___35->field_name);
            tmp___36 = EstimateStripByteCounts(tif, dir, dircount);
            if (tmp___36 < 0) {
              goto bad;
            } else {

            }
          } else {
            goto _L___7;
          }
        } else {
          goto _L___7;
        }
      } else {
        goto _L___7;
      }
    } else {
      goto _L___7;
    }
  } else {
    __repair_del_401__0: /* CIL Label */ 
    _L___7: ;
  }
  if (dir) {
    _TIFFfree((tdata_t )((char *)dir));
    dir = (TIFFDirEntry *)((void *)0);
  } else {

  }
  if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 19))) {
    td->td_maxsamplevalue = (uint16 )((1L << (int )td->td_bitspersample) - 1L);
  } else {

  }
  if (td->td_nstrips > 1U) {
    td->td_stripbytecountsorted = 1;
    strip = (tstrip_t )1;
    while (strip < td->td_nstrips) {
      if (*(td->td_stripoffset + (strip - 1U)) > *(td->td_stripoffset + strip)) {
        td->td_stripbytecountsorted = 0;
        break;
      } else {

      }
      strip ++;
    }
  } else {

  }
  if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 7))) {
    TIFFSetField(tif, (ttag_t )259, 1);
  } else {

  }
  if (td->td_nstrips == 1U) {
    if ((int )td->td_compression == 1) {
      if ((tif->tif_flags & 33792U) == 32768U) {
        ChopUpSingleUncompressedStrip(tif);
      } else {

      }
    } else {

    }
  } else {

  }
  tif->tif_row = (uint32 )-1;
  tif->tif_curstrip = (tstrip_t )-1;
  tif->tif_col = (uint32 )-1;
  tif->tif_curtile = (ttile_t )-1;
  tif->tif_tilesize = -1;
  tif->tif_scanlinesize = TIFFScanlineSize(tif);
  if (! tif->tif_scanlinesize) {
    TIFFErrorExt(tif->tif_clientdata, module,
                 "%s: cannot handle zero scanline size", tif->tif_name);
    return (0);
  } else {

  }
  if ((tif->tif_flags & 1024U) != 0U) {
    tif->tif_tilesize = TIFFTileSize(tif);
    if (! tif->tif_tilesize) {
      TIFFErrorExt(tif->tif_clientdata, module,
                   "%s: cannot handle zero tile size", tif->tif_name);
      return (0);
    } else {

    }
  } else {
    tmp___41 = TIFFStripSize(tif);
    if (! tmp___41) {
      TIFFErrorExt(tif->tif_clientdata, module,
                   "%s: cannot handle zero strip size", tif->tif_name);
      return (0);
    } else {

    }
  }
  return (1);
  bad: 
  if (dir) {
    _TIFFfree((tdata_t )dir);
  } else {

  }
  return (0);
}
}
static char const   module___0[24]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'R',      (char const   )'e',      (char const   )'a',      (char const   )'d', 
        (char const   )'C',      (char const   )'u',      (char const   )'s',      (char const   )'t', 
        (char const   )'o',      (char const   )'m',      (char const   )'D',      (char const   )'i', 
        (char const   )'r',      (char const   )'e',      (char const   )'c',      (char const   )'t', 
        (char const   )'o',      (char const   )'r',      (char const   )'y',      (char const   )'\000'};
int TIFFReadCustomDirectory(TIFF *tif , toff_t diroff ,
                            TIFFFieldInfo const   *info , size_t n ) 
{ 
  TIFFDirectory *td ;
  TIFFDirEntry *dp ;
  TIFFDirEntry *dir ;
  TIFFFieldInfo const   *fip ;
  size_t fix ;
  uint16 i ;
  uint16 dircount ;
  toff_t tmp ;
  tsize_t tmp___0 ;
  tdata_t tmp___1 ;
  tsize_t tmp___2 ;
  toff_t off ;
  tdata_t tmp___3 ;
  TIFFFieldInfo *tmp___4 ;
  uint32 expected ;
  uint32 tmp___5 ;
  int tmp___6 ;

  {
  td = & tif->tif_dir;
  dir = (TIFFDirEntry *)((void *)0);
  _TIFFSetupFieldInfo(tif, info, (int )n);
  tif->tif_diroff = diroff;
  if (! ((tif->tif_flags & 2048U) != 0U)) {
    tmp = (*(tif->tif_seekproc))(tif->tif_clientdata, diroff, 0);
    if (! (tmp == diroff)) {
      TIFFErrorExt(tif->tif_clientdata, module___0,
                   "%s: Seek error accessing TIFF directory", tif->tif_name);
      return (0);
    } else {

    }
    tmp___0 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                     (tdata_t )(& dircount),
                                     (tsize_t )sizeof(uint16 ));
    if (! (tmp___0 == (tsize_t )sizeof(uint16 ))) {
      TIFFErrorExt(tif->tif_clientdata, module___0,
                   "%s: Can not read TIFF directory count", tif->tif_name);
      return (0);
    } else {

    }
    if (tif->tif_flags & 128U) {
      TIFFSwabShort(& dircount);
    } else {

    }
    tmp___1 = _TIFFCheckMalloc(tif, (size_t )dircount, sizeof(TIFFDirEntry ),
                               "to read TIFF directory");
    dir = (TIFFDirEntry *)tmp___1;
    if ((unsigned long )dir == (unsigned long )((void *)0)) {
      return (0);
    } else {

    }
    tmp___2 = (*(tif->tif_readproc))(tif->tif_clientdata, (tdata_t )dir,
                                     (tsize_t )((unsigned long )dircount * sizeof(TIFFDirEntry )));
    if (! (tmp___2 == (tsize_t )((unsigned long )dircount * sizeof(TIFFDirEntry )))) {
      TIFFErrorExt(tif->tif_clientdata, module___0,
                   "%.100s: Can not read TIFF directory", tif->tif_name);
      goto bad;
    } else {

    }
  } else {
    off = diroff;
    if ((unsigned long )off + sizeof(uint16 ) > (unsigned long )tif->tif_size) {
      TIFFErrorExt(tif->tif_clientdata, module___0,
                   "%s: Can not read TIFF directory count", tif->tif_name);
      return (0);
    } else {
      _TIFFmemcpy((tdata_t )(& dircount),
                  (tdata_t const   )(tif->tif_base + off),
                  (tsize_t )sizeof(uint16 ));
    }
    off = (toff_t )((unsigned long )off + sizeof(uint16 ));
    if (tif->tif_flags & 128U) {
      TIFFSwabShort(& dircount);
    } else {

    }
    tmp___3 = _TIFFCheckMalloc(tif, (size_t )dircount, sizeof(TIFFDirEntry ),
                               "to read TIFF directory");
    dir = (TIFFDirEntry *)tmp___3;
    if ((unsigned long )dir == (unsigned long )((void *)0)) {
      return (0);
    } else {

    }
    if ((unsigned long )off + (unsigned long )dircount * sizeof(TIFFDirEntry ) > (unsigned long )tif->tif_size) {
      TIFFErrorExt(tif->tif_clientdata, module___0,
                   "%s: Can not read TIFF directory", tif->tif_name);
      goto bad;
    } else {
      _TIFFmemcpy((tdata_t )dir, (tdata_t const   )(tif->tif_base + off),
                  (tsize_t )((unsigned long )dircount * sizeof(TIFFDirEntry )));
    }
  }
  TIFFFreeDirectory(tif);
  fix = (size_t )0;
  dp = dir;
  i = dircount;
  while ((int )i > 0) {
    if (tif->tif_flags & 128U) {
      TIFFSwabArrayOfShort(& dp->tdir_tag, 2UL);
      TIFFSwabArrayOfLong(& dp->tdir_count, 2UL);
    } else {

    }
    if (fix >= tif->tif_nfields) {
      goto __Cont;
    } else
    if ((int )dp->tdir_tag == 0) {
      goto __Cont;
    } else {

    }
    while (1) {
      if (fix < tif->tif_nfields) {
        if (! ((*(tif->tif_fieldinfo + fix))->field_tag < (ttag_t )dp->tdir_tag)) {
          break;
        } else {

        }
      } else {
        break;
      }
      fix ++;
    }
    if (fix >= tif->tif_nfields) {
      goto _L;
    } else
    if ((*(tif->tif_fieldinfo + fix))->field_tag != (ttag_t )dp->tdir_tag) {
      _L: 
      TIFFWarning(module___0,
                  "%s: unknown field with tag %d (0x%x) encountered",
                  tif->tif_name, (int )dp->tdir_tag, (int )dp->tdir_tag,
                  (int )dp->tdir_type);
      tmp___4 = _TIFFCreateAnonFieldInfo(tif, (ttag_t )dp->tdir_tag,
                                         (TIFFDataType )dp->tdir_type);
      TIFFMergeFieldInfo(tif, (TIFFFieldInfo const   *)tmp___4, 1);
      fix = (size_t )0;
      while (1) {
        if (fix < tif->tif_nfields) {
          if (! ((*(tif->tif_fieldinfo + fix))->field_tag < (ttag_t )dp->tdir_tag)) {
            break;
          } else {

          }
        } else {
          break;
        }
        fix ++;
      }
    } else {

    }
    if ((int )(*(tif->tif_fieldinfo + fix))->field_bit == 0) {
      ignore: 
      dp->tdir_tag = (uint16 )0;
      goto __Cont;
    } else {

    }
    fip = (TIFFFieldInfo const   *)*(tif->tif_fieldinfo + fix);
    while (1) {
      if ((int )dp->tdir_type != (int )((unsigned short )fip->field_type)) {
        if (! (fix < tif->tif_nfields)) {
          break;
        } else {

        }
      } else {
        break;
      }
      if ((unsigned int const   )fip->field_type == 0U) {
        break;
      } else {

      }
      fix ++;
      fip = (TIFFFieldInfo const   *)*(tif->tif_fieldinfo + fix);
      if (fix >= tif->tif_nfields) {
        TIFFWarning(module___0,
                    "%s: wrong data type %d for \"%s\"; tag ignored",
                    tif->tif_name, (int )dp->tdir_type,
                    (*(tif->tif_fieldinfo + (fix - 1UL)))->field_name);
        goto ignore;
      } else
      if (fip->field_tag != (ttag_t const   )dp->tdir_tag) {
        TIFFWarning(module___0,
                    "%s: wrong data type %d for \"%s\"; tag ignored",
                    tif->tif_name, (int )dp->tdir_type,
                    (*(tif->tif_fieldinfo + (fix - 1UL)))->field_name);
        goto ignore;
      } else {

      }
    }
    if ((int const   )fip->field_readcount != -1) {
      if ((int const   )fip->field_readcount != -3) {
        if ((int const   )fip->field_readcount == -2) {
          tmp___5 = (uint32 )td->td_samplesperpixel;
        } else {
          tmp___5 = (uint32 )fip->field_readcount;
        }
        expected = tmp___5;
        tmp___6 = CheckDirCount(tif, dp, expected);
        if (! tmp___6) {
          goto ignore;
        } else {

        }
      } else {

      }
    } else {

    }
    TIFFFetchNormalTag(tif, dp);
    __Cont: 
    i = (uint16 )((int )i - 1);
    dp ++;
  }
  if (dir) {
    _TIFFfree((tdata_t )dir);
  } else {

  }
  return (1);
  bad: 
  if (dir) {
    _TIFFfree((tdata_t )dir);
  } else {

  }
  return (0);
}
}
int TIFFReadEXIFDirectory(TIFF *tif , toff_t diroff ) 
{ 
  int tmp ;

  {
  tmp = TIFFReadCustomDirectory(tif, diroff, exifFieldInfo,
                                sizeof(exifFieldInfo) / sizeof(exifFieldInfo[0]));
  return (tmp);
}
}
static char const   module___1[24]  = 
  {      (char const   )'E',      (char const   )'s',      (char const   )'t',      (char const   )'i', 
        (char const   )'m',      (char const   )'a',      (char const   )'t',      (char const   )'e', 
        (char const   )'S',      (char const   )'t',      (char const   )'r',      (char const   )'i', 
        (char const   )'p',      (char const   )'B',      (char const   )'y',      (char const   )'t', 
        (char const   )'e',      (char const   )'C',      (char const   )'o',      (char const   )'u', 
        (char const   )'n',      (char const   )'t',      (char const   )'s',      (char const   )'\000'};
static int EstimateStripByteCounts(TIFF *tif , TIFFDirEntry *dir ,
                                   uint16 dircount ) 
{ 
  register TIFFDirEntry *dp ;
  register TIFFDirectory *td ;
  uint16 i ;
  tdata_t tmp ;
  uint32 space ;
  toff_t filesize ;
  toff_t tmp___0 ;
  uint16 n ;
  uint32 cc ;
  int tmp___1 ;
  uint32 rowbytes ;
  tsize_t tmp___2 ;
  uint32 rowsperstrip ;

  {
  td = & tif->tif_dir;
  if (td->td_stripbytecount) {
    _TIFFfree((tdata_t )td->td_stripbytecount);
  } else {

  }
  tmp = _TIFFCheckMalloc(tif, (size_t )td->td_nstrips, sizeof(uint32 ),
                         "for \"StripByteCounts\" array");
  td->td_stripbytecount = (uint32 *)tmp;
  if ((int )td->td_compression != 1) {
    space = (uint32 )(((sizeof(TIFFHeader ) + sizeof(uint16 )) + (unsigned long )dircount * sizeof(TIFFDirEntry )) + sizeof(uint32 ));
    tmp___0 = (*(tif->tif_sizeproc))(tif->tif_clientdata);
    filesize = tmp___0;
    dp = dir;
    n = dircount;
    while ((int )n > 0) {
      tmp___1 = TIFFDataWidth((TIFFDataType )dp->tdir_type);
      cc = (uint32 )tmp___1;
      if (cc == 0U) {
        TIFFErrorExt(tif->tif_clientdata, module___1,
                     "%s: Cannot determine size of unknown tag type %d",
                     tif->tif_name, (int )dp->tdir_type);
        return (-1);
      } else {

      }
      cc *= dp->tdir_count;
      if ((unsigned long )cc > sizeof(uint32 )) {
        space += cc;
      } else {

      }
      n = (uint16 )((int )n - 1);
      dp ++;
    }
    space = filesize - space;
    if ((int )td->td_planarconfig == 2) {
      space /= (uint32 )td->td_samplesperpixel;
    } else {

    }
    i = (uint16 )0;
    while ((tstrip_t )i < td->td_nstrips) {
      *(td->td_stripbytecount + (int )i) = space;
      i = (uint16 )((int )i + 1);
    }
    i = (uint16 )((int )i - 1);
    if (*(td->td_stripoffset + (int )i) + *(td->td_stripbytecount + (int )i) > filesize) {
      *(td->td_stripbytecount + (int )i) = filesize - *(td->td_stripoffset + (int )i);
    } else {

    }
  } else {
    tmp___2 = TIFFScanlineSize(tif);
    rowbytes = (uint32 )tmp___2;
    rowsperstrip = td->td_imagelength / td->td_stripsperimage;
    i = (uint16 )0;
    while ((tstrip_t )i < td->td_nstrips) {
      *(td->td_stripbytecount + (int )i) = rowbytes * rowsperstrip;
      i = (uint16 )((int )i + 1);
    }
  }
  tif->tif_dir.td_fieldsset[0] |= 1UL << 24;
  if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 17))) {
    td->td_rowsperstrip = td->td_imagelength;
  } else {

  }
  return (1);
}
}
static char const   module___2[16]  = 
  {      (char const   )'M',      (char const   )'i',      (char const   )'s',      (char const   )'s', 
        (char const   )'i',      (char const   )'n',      (char const   )'g',      (char const   )'R', 
        (char const   )'e',      (char const   )'q',      (char const   )'u',      (char const   )'i', 
        (char const   )'r',      (char const   )'e',      (char const   )'d',      (char const   )'\000'};
static void MissingRequired(TIFF *tif , char const   *tagname ) 
{ 


  {
  TIFFErrorExt(tif->tif_clientdata, module___2,
               "%s: TIFF directory is missing required \"%s\" field",
               tif->tif_name, tagname);
  return;
}
}
static int CheckDirCount(TIFF *tif , TIFFDirEntry *dir , uint32 count ) 
{ 
  TIFFFieldInfo const   *tmp ;
  TIFFFieldInfo const   *tmp___0 ;

  {
  if (count > dir->tdir_count) {
    tmp = TIFFFieldWithTag(tif, (ttag_t )dir->tdir_tag);
    TIFFWarning((char const   *)tif->tif_name,
                "incorrect count for field \"%s\" (%lu, expecting %lu); tag ignored",
                tmp->field_name, dir->tdir_count, count);
    return (0);
  } else
  if (count < dir->tdir_count) {
    tmp___0 = TIFFFieldWithTag(tif, (ttag_t )dir->tdir_tag);
    TIFFWarning((char const   *)tif->tif_name,
                "incorrect count for field \"%s\" (%lu, expecting %lu); tag trimmed",
                tmp___0->field_name, dir->tdir_count, count);
    return (1);
  } else {

  }
  return (1);
}
}
static tsize_t TIFFFetchData(TIFF *tif , TIFFDirEntry *dir , char *cp ) 
{ 
  int w ;
  int tmp ;
  tsize_t cc ;
  toff_t tmp___0 ;
  tsize_t tmp___1 ;
  TIFFFieldInfo const   *tmp___2 ;

  {
  tmp = TIFFDataWidth((TIFFDataType )dir->tdir_type);
  w = tmp;
  cc = (tsize_t )(dir->tdir_count * (uint32 )w);
  if (! ((tif->tif_flags & 2048U) != 0U)) {
    tmp___0 = (*(tif->tif_seekproc))(tif->tif_clientdata, dir->tdir_offset, 0);
    if (! (tmp___0 == dir->tdir_offset)) {
      goto bad;
    } else {

    }
    tmp___1 = (*(tif->tif_readproc))(tif->tif_clientdata, (tdata_t )cp, cc);
    if (! (tmp___1 == cc)) {
      goto bad;
    } else {

    }
  } else {
    if (dir->tdir_offset + (uint32 )cc > tif->tif_size) {
      goto bad;
    } else {

    }
    _TIFFmemcpy((tdata_t )cp,
                (tdata_t const   )(tif->tif_base + dir->tdir_offset), cc);
  }
  if (tif->tif_flags & 128U) {
    switch ((int )dir->tdir_type) {
    case 3: 
    case 8: 
    TIFFSwabArrayOfShort((uint16 *)cp, (unsigned long )dir->tdir_count);
    break;
    case 4: 
    case 9: 
    case 11: 
    TIFFSwabArrayOfLong((uint32 *)cp, (unsigned long )dir->tdir_count);
    break;
    case 5: 
    case 10: 
    TIFFSwabArrayOfLong((uint32 *)cp, (unsigned long )(2U * dir->tdir_count));
    break;
    case 12: 
    TIFFSwabArrayOfDouble((double *)cp, (unsigned long )dir->tdir_count);
    break;
    }
  } else {

  }
  return (cc);
  bad: 
  tmp___2 = TIFFFieldWithTag(tif, (ttag_t )dir->tdir_tag);
  TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
               "Error fetching data for field \"%s\"", tmp___2->field_name);
  return (0);
}
}
static tsize_t TIFFFetchString(TIFF *tif , TIFFDirEntry *dir , char *cp ) 
{ 
  uint32 l ;
  tsize_t tmp ;

  {
  if (dir->tdir_count <= 4U) {
    l = dir->tdir_offset;
    if (tif->tif_flags & 128U) {
      TIFFSwabLong(& l);
    } else {

    }
    _TIFFmemcpy((tdata_t )cp, (tdata_t const   )(& l), (tsize_t )dir->tdir_count);
    return (1);
  } else {

  }
  tmp = TIFFFetchData(tif, dir, cp);
  return (tmp);
}
}
static int cvtRational(TIFF *tif , TIFFDirEntry *dir , uint32 num ,
                       uint32 denom , float *rv ) 
{ 
  TIFFFieldInfo const   *tmp ;

  {
  if (denom == 0U) {
    tmp = TIFFFieldWithTag(tif, (ttag_t )dir->tdir_tag);
    TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                 "%s: Rational with zero denominator (num = %lu)",
                 tmp->field_name, num);
    return (0);
  } else {
    if ((int )dir->tdir_type == 5) {
      *rv = (float )num / (float )denom;
    } else {
      *rv = (float )((int32 )num) / (float )((int32 )denom);
    }
    return (1);
  }
}
}
static float TIFFFetchRational(TIFF *tif , TIFFDirEntry *dir ) 
{ 
  uint32 l[2] ;
  float v ;
  float tmp___1 ;
  tsize_t tmp___2 ;
  int tmp___3 ;

  {
  tmp___2 = TIFFFetchData(tif, dir, (char *)(l));
  if (tmp___2) {
    tmp___3 = cvtRational(tif, dir, l[0], l[1], & v);
    if (tmp___3) {
      tmp___1 = v;
    } else {
      tmp___1 = 1.0f;
    }
  } else {
    tmp___1 = 1.0f;
  }
  return (tmp___1);
}
}
static float TIFFFetchFloat(TIFF *tif , TIFFDirEntry *dir ) 
{ 
  float v ;
  int32 l ;
  long tmp ;

  {
  if ((int )tif->tif_header.tiff_magic == 19789) {
    tmp = (long )((long const   )(dir->tdir_offset >> *(tif->tif_typeshift + (int )dir->tdir_type)) & *(tif->tif_typemask + (int )dir->tdir_type));
  } else {
    tmp = (long )((long const   )dir->tdir_offset & *(tif->tif_typemask + (int )dir->tdir_type));
  }
  l = (int32 )((uint32 )tmp);
  _TIFFmemcpy((tdata_t )(& v), (tdata_t const   )(& l), (tsize_t )sizeof(float ));
  return (v);
}
}
static int TIFFFetchByteArray(TIFF *tif , TIFFDirEntry *dir , uint8 *v ) 
{ 
  tsize_t tmp ;

  {
  if (dir->tdir_count <= 4U) {
    if ((int )tif->tif_header.tiff_magic == 19789) {
      if ((int )dir->tdir_type == 6) {
        switch (dir->tdir_count) {
        case 4U: 
        *(v + 3) = (uint8 )(dir->tdir_offset & 255U);
        case 3U: 
        *(v + 2) = (uint8 )((dir->tdir_offset >> 8) & 255U);
        case 2U: 
        *(v + 1) = (uint8 )((dir->tdir_offset >> 16) & 255U);
        case 1U: 
        *(v + 0) = (uint8 )(dir->tdir_offset >> 24);
        }
      } else {
        switch (dir->tdir_count) {
        case 4U: 
        *(v + 3) = (uint8 )(dir->tdir_offset & 255U);
        case 3U: 
        *(v + 2) = (uint8 )((dir->tdir_offset >> 8) & 255U);
        case 2U: 
        *(v + 1) = (uint8 )((dir->tdir_offset >> 16) & 255U);
        case 1U: 
        *(v + 0) = (uint8 )(dir->tdir_offset >> 24);
        }
      }
    } else
    if ((int )dir->tdir_type == 6) {
      switch (dir->tdir_count) {
      case 4U: 
      *(v + 3) = (uint8 )(dir->tdir_offset >> 24);
      case 3U: 
      *(v + 2) = (uint8 )((dir->tdir_offset >> 16) & 255U);
      case 2U: 
      *(v + 1) = (uint8 )((dir->tdir_offset >> 8) & 255U);
      case 1U: 
      *(v + 0) = (uint8 )(dir->tdir_offset & 255U);
      }
    } else {
      switch (dir->tdir_count) {
      case 4U: 
      *(v + 3) = (uint8 )(dir->tdir_offset >> 24);
      case 3U: 
      *(v + 2) = (uint8 )((dir->tdir_offset >> 16) & 255U);
      case 2U: 
      *(v + 1) = (uint8 )((dir->tdir_offset >> 8) & 255U);
      case 1U: 
      *(v + 0) = (uint8 )(dir->tdir_offset & 255U);
      }
    }
    return (1);
  } else {
    tmp = TIFFFetchData(tif, dir, (char *)v);
    return (tmp != 0);
  }
}
}
static int TIFFFetchShortArray(TIFF *tif , TIFFDirEntry *dir , uint16 *v ) 
{ 
  tsize_t tmp ;

  {
  if (dir->tdir_count <= 2U) {
    if ((int )tif->tif_header.tiff_magic == 19789) {
      switch (dir->tdir_count) {
      case 2U: 
      *(v + 1) = (uint16 )(dir->tdir_offset & 65535U);
      case 1U: 
      *(v + 0) = (uint16 )(dir->tdir_offset >> 16);
      }
    } else {
      switch (dir->tdir_count) {
      case 2U: 
      *(v + 1) = (uint16 )(dir->tdir_offset >> 16);
      case 1U: 
      *(v + 0) = (uint16 )(dir->tdir_offset & 65535U);
      }
    }
    return (1);
  } else {
    tmp = TIFFFetchData(tif, dir, (char *)v);
    return (tmp != 0);
  }
}
}
static int TIFFFetchShortPair(TIFF *tif , TIFFDirEntry *dir ) 
{ 
  uint8 v[4] ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  uint16 v___0[4] ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;

  {
  switch ((int )dir->tdir_type) {
  case 1: 
  case 6: 
  tmp = TIFFFetchByteArray(tif, dir, v);
  if (tmp) {
    tmp___0 = TIFFSetField(tif, (ttag_t )dir->tdir_tag, (int )v[0], (int )v[1]);
    if (tmp___0) {
      tmp___1 = 1;
    } else {
      tmp___1 = 0;
    }
  } else {
    tmp___1 = 0;
  }
  return (tmp___1);
  case 3: 
  case 8: 
  tmp___2 = TIFFFetchShortArray(tif, dir, v___0);
  if (tmp___2) {
    tmp___3 = TIFFSetField(tif, (ttag_t )dir->tdir_tag, (int )v___0[0],
                           (int )v___0[1]);
    if (tmp___3) {
      tmp___4 = 1;
    } else {
      tmp___4 = 0;
    }
  } else {
    tmp___4 = 0;
  }
  return (tmp___4);
  default: 
  return (0);
  }
}
}
static int TIFFFetchLongArray(TIFF *tif , TIFFDirEntry *dir , uint32 *v ) 
{ 
  tsize_t tmp ;

  {
  if (dir->tdir_count == 1U) {
    *(v + 0) = dir->tdir_offset;
    return (1);
  } else {
    tmp = TIFFFetchData(tif, dir, (char *)v);
    return (tmp != 0);
  }
}
}
static int TIFFFetchRationalArray(TIFF *tif , TIFFDirEntry *dir , float *v ) 
{ 
  int ok ;
  uint32 *l ;
  int tmp ;
  tdata_t tmp___0 ;
  uint32 i ;
  tsize_t tmp___1 ;

  {
  ok = 0;
  tmp = TIFFDataWidth((TIFFDataType )dir->tdir_type);
  tmp___0 = _TIFFCheckMalloc(tif, (size_t )dir->tdir_count, (size_t )tmp,
                             "to fetch array of rationals");
  l = (uint32 *)tmp___0;
  if (l) {
    tmp___1 = TIFFFetchData(tif, dir, (char *)l);
    if (tmp___1) {
      i = (uint32 )0;
      while (i < dir->tdir_count) {
        ok = cvtRational(tif, dir, *(l + 2U * i), *(l + (2U * i + 1U)), v + i);
        if (! ok) {
          break;
        } else {

        }
        i ++;
      }
    } else {

    }
    _TIFFfree((tdata_t )((char *)l));
  } else {

  }
  return (ok);
}
}
static int TIFFFetchFloatArray(TIFF *tif , TIFFDirEntry *dir , float *v ) 
{ 
  tsize_t tmp ;

  {
  if (dir->tdir_count == 1U) {
    *(v + 0) = *((float *)(& dir->tdir_offset));
    return (1);
  } else {
    tmp = TIFFFetchData(tif, dir, (char *)v);
    if (tmp) {
      return (1);
    } else {
      return (0);
    }
  }
}
}
static int TIFFFetchDoubleArray(TIFF *tif , TIFFDirEntry *dir , double *v ) 
{ 
  tsize_t tmp ;

  {
  tmp = TIFFFetchData(tif, dir, (char *)v);
  if (tmp) {
    return (1);
  } else {
    return (0);
  }
}
}
static int TIFFFetchAnyArray(TIFF *tif , TIFFDirEntry *dir , double *v ) 
{ 
  int i ;
  int tmp ;
  uint8 *vp ;
  int8 *vp___0 ;
  int tmp___0 ;
  uint16 *vp___1 ;
  int16 *vp___2 ;
  int tmp___1 ;
  uint32 *vp___3 ;
  int32 *vp___4 ;
  int tmp___2 ;
  float *vp___5 ;
  int tmp___3 ;
  float *vp___6 ;
  int tmp___4 ;
  TIFFFieldInfo const   *tmp___5 ;

  {
  switch ((int )dir->tdir_type) {
  case 1: 
  case 6: 
  tmp = TIFFFetchByteArray(tif, dir, (uint8 *)v);
  if (! tmp) {
    return (0);
  } else {

  }
  if ((int )dir->tdir_type == 1) {
    vp = (uint8 *)v;
    i = (int )(dir->tdir_count - 1U);
    while (i >= 0) {
      *(v + i) = (double )*(vp + i);
      i --;
    }
  } else {
    vp___0 = (int8 *)v;
    i = (int )(dir->tdir_count - 1U);
    while (i >= 0) {
      *(v + i) = (double )*(vp___0 + i);
      i --;
    }
  }
  break;
  case 3: 
  case 8: 
  tmp___0 = TIFFFetchShortArray(tif, dir, (uint16 *)v);
  if (! tmp___0) {
    return (0);
  } else {

  }
  if ((int )dir->tdir_type == 3) {
    vp___1 = (uint16 *)v;
    i = (int )(dir->tdir_count - 1U);
    while (i >= 0) {
      *(v + i) = (double )*(vp___1 + i);
      i --;
    }
  } else {
    vp___2 = (int16 *)v;
    i = (int )(dir->tdir_count - 1U);
    while (i >= 0) {
      *(v + i) = (double )*(vp___2 + i);
      i --;
    }
  }
  break;
  case 4: 
  case 9: 
  tmp___1 = TIFFFetchLongArray(tif, dir, (uint32 *)v);
  if (! tmp___1) {
    return (0);
  } else {

  }
  if ((int )dir->tdir_type == 4) {
    vp___3 = (uint32 *)v;
    i = (int )(dir->tdir_count - 1U);
    while (i >= 0) {
      *(v + i) = (double )*(vp___3 + i);
      i --;
    }
  } else {
    vp___4 = (int32 *)v;
    i = (int )(dir->tdir_count - 1U);
    while (i >= 0) {
      *(v + i) = (double )*(vp___4 + i);
      i --;
    }
  }
  break;
  case 5: 
  case 10: 
  tmp___2 = TIFFFetchRationalArray(tif, dir, (float *)v);
  if (! tmp___2) {
    return (0);
  } else {

  }
  vp___5 = (float *)v;
  i = (int )(dir->tdir_count - 1U);
  while (i >= 0) {
    *(v + i) = (double )*(vp___5 + i);
    i --;
  }
  break;
  case 11: 
  tmp___3 = TIFFFetchFloatArray(tif, dir, (float *)v);
  if (! tmp___3) {
    return (0);
  } else {

  }
  vp___6 = (float *)v;
  i = (int )(dir->tdir_count - 1U);
  while (i >= 0) {
    *(v + i) = (double )*(vp___6 + i);
    i --;
  }
  break;
  case 12: 
  tmp___4 = TIFFFetchDoubleArray(tif, dir, v);
  return (tmp___4);
  default: 
  tmp___5 = TIFFFieldWithTag(tif, (ttag_t )dir->tdir_tag);
  TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
               "cannot read TIFF_ANY type %d for field \"%s\"",
               tmp___5->field_name);
  return (0);
  }
  return (1);
}
}
static char const   mesg[19]  = 
  {      (char const   )'t',      (char const   )'o',      (char const   )' ',      (char const   )'f', 
        (char const   )'e',      (char const   )'t',      (char const   )'c',      (char const   )'h', 
        (char const   )' ',      (char const   )'t',      (char const   )'a',      (char const   )'g', 
        (char const   )' ',      (char const   )'v',      (char const   )'a',      (char const   )'l', 
        (char const   )'u',      (char const   )'e',      (char const   )'\000'};
static int TIFFFetchNormalTag(TIFF *tif , TIFFDirEntry *dp ) 
{ 
  int ok ;
  TIFFFieldInfo const   *fip ;
  TIFFFieldInfo const   *tmp ;
  char *cp ;
  tdata_t tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  tdata_t tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  tdata_t tmp___6 ;
  int tmp___7 ;
  int tmp___8 ;
  tdata_t tmp___9 ;
  int tmp___10 ;
  int tmp___11 ;
  tdata_t tmp___12 ;
  int tmp___13 ;
  int tmp___14 ;
  tdata_t tmp___15 ;
  int tmp___16 ;
  int tmp___17 ;
  tdata_t tmp___18 ;
  tsize_t tmp___19 ;
  int tmp___20 ;
  int tmp___21 ;
  int tmp___22 ;
  TIFFDataType type ;
  uint16 v ;
  long tmp___23 ;
  int tmp___24 ;
  int tmp___25 ;
  uint32 v32 ;
  long tmp___26 ;
  int tmp___27 ;
  int tmp___28 ;
  float v___0 ;
  float tmp___29 ;
  float tmp___30 ;
  float tmp___31 ;
  int tmp___32 ;
  int tmp___33 ;
  double v___1 ;
  int tmp___34 ;
  int tmp___35 ;
  int tmp___36 ;
  int tmp___37 ;
  int tmp___38 ;
  char c[2] ;
  int tmp___39 ;
  int tmp___40 ;
  tsize_t tmp___41 ;
  int tmp___42 ;

  {
  ok = 0;
  tmp = TIFFFieldWithTag(tif, (ttag_t )dp->tdir_tag);
  fip = tmp;
  if (dp->tdir_count > 1U) {
    cp = (char *)((void *)0);
    switch ((int )dp->tdir_type) {
    case 1: 
    case 6: 
    tmp___0 = _TIFFCheckMalloc(tif, (size_t )dp->tdir_count, sizeof(uint8 ),
                               mesg);
    cp = (char *)tmp___0;
    if (cp) {
      tmp___1 = TIFFFetchByteArray(tif, dp, (uint8 *)cp);
      if (tmp___1) {
        tmp___2 = 1;
      } else {
        tmp___2 = 0;
      }
    } else {
      tmp___2 = 0;
    }
    ok = tmp___2;
    break;
    case 3: 
    case 8: 
    tmp___3 = _TIFFCheckMalloc(tif, (size_t )dp->tdir_count, sizeof(uint16 ),
                               mesg);
    cp = (char *)tmp___3;
    if (cp) {
      tmp___4 = TIFFFetchShortArray(tif, dp, (uint16 *)cp);
      if (tmp___4) {
        tmp___5 = 1;
      } else {
        tmp___5 = 0;
      }
    } else {
      tmp___5 = 0;
    }
    ok = tmp___5;
    break;
    case 4: 
    case 9: 
    tmp___6 = _TIFFCheckMalloc(tif, (size_t )dp->tdir_count, sizeof(uint32 ),
                               mesg);
    cp = (char *)tmp___6;
    if (cp) {
      tmp___7 = TIFFFetchLongArray(tif, dp, (uint32 *)cp);
      if (tmp___7) {
        tmp___8 = 1;
      } else {
        tmp___8 = 0;
      }
    } else {
      tmp___8 = 0;
    }
    ok = tmp___8;
    break;
    case 5: 
    case 10: 
    tmp___9 = _TIFFCheckMalloc(tif, (size_t )dp->tdir_count, sizeof(float ),
                               mesg);
    cp = (char *)tmp___9;
    if (cp) {
      tmp___10 = TIFFFetchRationalArray(tif, dp, (float *)cp);
      if (tmp___10) {
        tmp___11 = 1;
      } else {
        tmp___11 = 0;
      }
    } else {
      tmp___11 = 0;
    }
    ok = tmp___11;
    break;
    case 11: 
    tmp___12 = _TIFFCheckMalloc(tif, (size_t )dp->tdir_count, sizeof(float ),
                                mesg);
    cp = (char *)tmp___12;
    if (cp) {
      tmp___13 = TIFFFetchFloatArray(tif, dp, (float *)cp);
      if (tmp___13) {
        tmp___14 = 1;
      } else {
        tmp___14 = 0;
      }
    } else {
      tmp___14 = 0;
    }
    ok = tmp___14;
    break;
    case 12: 
    tmp___15 = _TIFFCheckMalloc(tif, (size_t )dp->tdir_count, sizeof(double ),
                                mesg);
    cp = (char *)tmp___15;
    if (cp) {
      tmp___16 = TIFFFetchDoubleArray(tif, dp, (double *)cp);
      if (tmp___16) {
        tmp___17 = 1;
      } else {
        tmp___17 = 0;
      }
    } else {
      tmp___17 = 0;
    }
    ok = tmp___17;
    break;
    case 2: 
    case 7: 
    tmp___18 = _TIFFCheckMalloc(tif, (size_t )(dp->tdir_count + 1U), (size_t )1,
                                mesg);
    cp = (char *)tmp___18;
    if (cp) {
      tmp___19 = TIFFFetchString(tif, dp, cp);
      if (tmp___19) {
        tmp___20 = 1;
      } else {
        tmp___20 = 0;
      }
    } else {
      tmp___20 = 0;
    }
    ok = tmp___20;
    if (ok != 0) {
      *(cp + dp->tdir_count) = (char )'\000';
    } else {

    }
    break;
    }
    if (ok) {
      if (fip->field_passcount) {
        tmp___21 = TIFFSetField(tif, (ttag_t )dp->tdir_tag, dp->tdir_count, cp);
        ok = tmp___21;
      } else {
        tmp___22 = TIFFSetField(tif, (ttag_t )dp->tdir_tag, cp);
        ok = tmp___22;
      }
    } else {

    }
    if ((unsigned long )cp != (unsigned long )((void *)0)) {
      _TIFFfree((tdata_t )cp);
    } else {

    }
  } else {
    tmp___42 = CheckDirCount(tif, dp, (uint32 )1);
    if (tmp___42) {
      switch ((int )dp->tdir_type) {
      case 1: 
      case 6: 
      case 3: 
      case 8: 
      type = (TIFFDataType )fip->field_type;
      if ((unsigned int )type != 4U) {
        if ((unsigned int )type != 9U) {
          if ((int )tif->tif_header.tiff_magic == 19789) {
            tmp___23 = (long )((long const   )(dp->tdir_offset >> *(tif->tif_typeshift + (int )dp->tdir_type)) & *(tif->tif_typemask + (int )dp->tdir_type));
          } else {
            tmp___23 = (long )((long const   )dp->tdir_offset & *(tif->tif_typemask + (int )dp->tdir_type));
          }
          v = (uint16 )((uint32 )tmp___23);
          if (fip->field_passcount) {
            tmp___24 = TIFFSetField(tif, (ttag_t )dp->tdir_tag, 1, & v);
            ok = tmp___24;
          } else {
            tmp___25 = TIFFSetField(tif, (ttag_t )dp->tdir_tag, (int )v);
            ok = tmp___25;
          }
          break;
        } else {

        }
      } else {

      }
      case 4: 
      case 9: 
      if ((int )tif->tif_header.tiff_magic == 19789) {
        tmp___26 = (long )((long const   )(dp->tdir_offset >> *(tif->tif_typeshift + (int )dp->tdir_type)) & *(tif->tif_typemask + (int )dp->tdir_type));
      } else {
        tmp___26 = (long )((long const   )dp->tdir_offset & *(tif->tif_typemask + (int )dp->tdir_type));
      }
      v32 = (uint32 )tmp___26;
      if (fip->field_passcount) {
        tmp___27 = TIFFSetField(tif, (ttag_t )dp->tdir_tag, 1, & v32);
        ok = tmp___27;
      } else {
        tmp___28 = TIFFSetField(tif, (ttag_t )dp->tdir_tag, v32);
        ok = tmp___28;
      }
      break;
      case 5: 
      case 10: 
      case 11: 
      if ((int )dp->tdir_type == 11) {
        tmp___29 = TIFFFetchFloat(tif, dp);
        tmp___31 = tmp___29;
      } else {
        tmp___30 = TIFFFetchRational(tif, dp);
        tmp___31 = tmp___30;
      }
      v___0 = tmp___31;
      if (fip->field_passcount) {
        tmp___32 = TIFFSetField(tif, (ttag_t )dp->tdir_tag, 1, & v___0);
        ok = tmp___32;
      } else {
        tmp___33 = TIFFSetField(tif, (ttag_t )dp->tdir_tag, (double )v___0);
        ok = tmp___33;
      }
      break;
      case 12: 
      tmp___34 = TIFFFetchDoubleArray(tif, dp, & v___1);
      if (tmp___34) {
        if (fip->field_passcount) {
          tmp___35 = TIFFSetField(tif, (ttag_t )dp->tdir_tag, 1, & v___1);
          tmp___37 = tmp___35;
        } else {
          tmp___36 = TIFFSetField(tif, (ttag_t )dp->tdir_tag, v___1);
          tmp___37 = tmp___36;
        }
        if (tmp___37) {
          tmp___38 = 1;
        } else {
          tmp___38 = 0;
        }
      } else {
        tmp___38 = 0;
      }
      ok = tmp___38;
      break;
      case 2: 
      case 7: 
      tmp___41 = TIFFFetchString(tif, dp, c);
      ok = tmp___41 != 0;
      if (ok != 0) {
        c[1] = (char )'\000';
        if (fip->field_passcount) {
          tmp___39 = TIFFSetField(tif, (ttag_t )dp->tdir_tag, 1, c);
          ok = tmp___39;
        } else {
          tmp___40 = TIFFSetField(tif, (ttag_t )dp->tdir_tag, c);
          ok = tmp___40;
        }
      } else {

      }
      break;
      }
    } else {

    }
  }
  return (ok);
}
}
static int TIFFFetchPerSampleShorts(TIFF *tif , TIFFDirEntry *dir , uint16 *pl ) 
{ 
  uint16 samples ;
  int status ;
  uint16 buf[10] ;
  uint16 *v ;
  tdata_t tmp ;
  uint16 i ;
  int check_count ;
  TIFFFieldInfo const   *tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;

  {
  samples = tif->tif_dir.td_samplesperpixel;
  status = 0;
  tmp___2 = CheckDirCount(tif, dir, (uint32 )samples);
  if (tmp___2) {
    v = buf;
    if ((unsigned long )dir->tdir_count > sizeof(buf) / sizeof(buf[0])) {
      tmp = _TIFFCheckMalloc(tif, (size_t )dir->tdir_count, sizeof(uint16 ),
                             "to fetch per-sample values");
      v = (uint16 *)tmp;
    } else {

    }
    if (v) {
      tmp___1 = TIFFFetchShortArray(tif, dir, v);
      if (tmp___1) {
        check_count = (int )dir->tdir_count;
        if ((int )samples < check_count) {
          check_count = (int )samples;
        } else {

        }
        i = (uint16 )1;
        while ((int )i < check_count) {
          if ((int )*(v + (int )i) != (int )*(v + 0)) {
            tmp___0 = TIFFFieldWithTag(tif, (ttag_t )dir->tdir_tag);
            TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                         "Cannot handle different per-sample values for field \"%s\"",
                         tmp___0->field_name);
            goto bad;
          } else {

          }
          i = (uint16 )((int )i + 1);
        }
        *pl = *(v + 0);
        status = 1;
      } else {

      }
    } else {

    }
    bad: 
    if (v) {
      if ((unsigned long )v != (unsigned long )(buf)) {
        _TIFFfree((tdata_t )v);
      } else {

      }
    } else {

    }
  } else {

  }
  return (status);
}
}
static int TIFFFetchPerSampleLongs(TIFF *tif , TIFFDirEntry *dir , uint32 *pl ) 
{ 
  uint16 samples ;
  int status ;
  uint32 buf[10] ;
  uint32 *v ;
  tdata_t tmp ;
  uint16 i ;
  int check_count ;
  TIFFFieldInfo const   *tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;

  {
  samples = tif->tif_dir.td_samplesperpixel;
  status = 0;
  tmp___2 = CheckDirCount(tif, dir, (uint32 )samples);
  if (tmp___2) {
    v = buf;
    if ((unsigned long )dir->tdir_count > sizeof(buf) / sizeof(buf[0])) {
      tmp = _TIFFCheckMalloc(tif, (size_t )dir->tdir_count, sizeof(uint32 ),
                             "to fetch per-sample values");
      v = (uint32 *)tmp;
    } else {

    }
    if (v) {
      tmp___1 = TIFFFetchLongArray(tif, dir, v);
      if (tmp___1) {
        check_count = (int )dir->tdir_count;
        if ((int )samples < check_count) {
          check_count = (int )samples;
        } else {

        }
        i = (uint16 )1;
        while ((int )i < check_count) {
          if (*(v + (int )i) != *(v + 0)) {
            tmp___0 = TIFFFieldWithTag(tif, (ttag_t )dir->tdir_tag);
            TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                         "Cannot handle different per-sample values for field \"%s\"",
                         tmp___0->field_name);
            goto bad;
          } else {

          }
          i = (uint16 )((int )i + 1);
        }
        *pl = *(v + 0);
        status = 1;
      } else {

      }
    } else {

    }
    bad: 
    if (v) {
      if ((unsigned long )v != (unsigned long )(buf)) {
        _TIFFfree((tdata_t )v);
      } else {

      }
    } else {

    }
  } else {

  }
  return (status);
}
}
static int TIFFFetchPerSampleAnys(TIFF *tif , TIFFDirEntry *dir , double *pl ) 
{ 
  uint16 samples ;
  int status ;
  double buf[10] ;
  double *v ;
  tdata_t tmp ;
  uint16 i ;
  int check_count ;
  TIFFFieldInfo const   *tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;

  {
  samples = tif->tif_dir.td_samplesperpixel;
  status = 0;
  tmp___2 = CheckDirCount(tif, dir, (uint32 )samples);
  if (tmp___2) {
    v = buf;
    if ((unsigned long )dir->tdir_count > sizeof(buf) / sizeof(buf[0])) {
      tmp = _TIFFCheckMalloc(tif, (size_t )dir->tdir_count, sizeof(double ),
                             "to fetch per-sample values");
      v = (double *)tmp;
    } else {

    }
    if (v) {
      tmp___1 = TIFFFetchAnyArray(tif, dir, v);
      if (tmp___1) {
        check_count = (int )dir->tdir_count;
        if ((int )samples < check_count) {
          check_count = (int )samples;
        } else {

        }
        i = (uint16 )1;
        while ((int )i < check_count) {
          if (*(v + (int )i) != *(v + 0)) {
            tmp___0 = TIFFFieldWithTag(tif, (ttag_t )dir->tdir_tag);
            TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                         "Cannot handle different per-sample values for field \"%s\"",
                         tmp___0->field_name);
            goto bad;
          } else {

          }
          i = (uint16 )((int )i + 1);
        }
        *pl = *(v + 0);
        status = 1;
      } else {

      }
    } else {

    }
    bad: 
    if (v) {
      if ((unsigned long )v != (unsigned long )(buf)) {
        _TIFFfree((tdata_t )v);
      } else {

      }
    } else {

    }
  } else {

  }
  return (status);
}
}
static int TIFFFetchStripThing(TIFF *tif , TIFFDirEntry *dir , long nstrips ,
                               uint32 **lpp ) 
{ 
  register uint32 *lp ;
  int status ;
  uint32 *tmp ;
  tdata_t tmp___0 ;
  uint16 *dp ;
  tdata_t tmp___1 ;
  int i ;
  uint32 *dp___0 ;
  tdata_t tmp___2 ;
  int i___0 ;

  {
  CheckDirCount(tif, dir, (uint32 )nstrips);
  if ((unsigned long )*lpp == (unsigned long )((void *)0)) {
    tmp___0 = _TIFFCheckMalloc(tif, (size_t )nstrips, sizeof(uint32 ),
                               "for strip array");
    tmp = (uint32 *)tmp___0;
    *lpp = tmp;
    if ((unsigned long )tmp == (unsigned long )((void *)0)) {
      return (0);
    } else {

    }
  } else {

  }
  lp = *lpp;
  _TIFFmemset((tdata_t )lp, 0,
              (tsize_t )(sizeof(uint32 ) * (unsigned long )nstrips));
  if ((int )dir->tdir_type == 3) {
    tmp___1 = _TIFFCheckMalloc(tif, (size_t )dir->tdir_count, sizeof(uint16 ),
                               "to fetch strip tag");
    dp = (uint16 *)tmp___1;
    if ((unsigned long )dp == (unsigned long )((void *)0)) {
      return (0);
    } else {

    }
    status = TIFFFetchShortArray(tif, dir, dp);
    if (status != 0) {
      i = 0;
      while (1) {
        if ((long )i < nstrips) {
          if (! (i < (int )dir->tdir_count)) {
            break;
          } else {

          }
        } else {
          break;
        }
        *(lp + i) = (uint32 )*(dp + i);
        i ++;
      }
    } else {

    }
    _TIFFfree((tdata_t )((char *)dp));
  } else
  if (nstrips != (long )((int )dir->tdir_count)) {
    tmp___2 = _TIFFCheckMalloc(tif, (size_t )dir->tdir_count, sizeof(uint32 ),
                               "to fetch strip tag");
    dp___0 = (uint32 *)tmp___2;
    if ((unsigned long )dp___0 == (unsigned long )((void *)0)) {
      return (0);
    } else {

    }
    status = TIFFFetchLongArray(tif, dir, dp___0);
    if (status != 0) {
      i___0 = 0;
      while (1) {
        if ((long )i___0 < nstrips) {
          if (! (i___0 < (int )dir->tdir_count)) {
            break;
          } else {

          }
        } else {
          break;
        }
        *(lp + i___0) = *(dp___0 + i___0);
        i___0 ++;
      }
    } else {

    }
    _TIFFfree((tdata_t )((char *)dp___0));
  } else {
    status = TIFFFetchLongArray(tif, dir, lp);
  }
  return (status);
}
}
static char const   mesg___0[32]  = 
  {      (char const   )'f',      (char const   )'o',      (char const   )'r',      (char const   )' ', 
        (char const   )'\"',      (char const   )'R',      (char const   )'e',      (char const   )'f', 
        (char const   )'e',      (char const   )'r',      (char const   )'e',      (char const   )'n', 
        (char const   )'c',      (char const   )'e',      (char const   )'B',      (char const   )'l', 
        (char const   )'a',      (char const   )'c',      (char const   )'k',      (char const   )'W', 
        (char const   )'h',      (char const   )'i',      (char const   )'t',      (char const   )'e', 
        (char const   )'\"',      (char const   )' ',      (char const   )'a',      (char const   )'r', 
        (char const   )'r',      (char const   )'a',      (char const   )'y',      (char const   )'\000'};
static int TIFFFetchRefBlackWhite(TIFF *tif , TIFFDirEntry *dir ) 
{ 
  char *cp ;
  int ok ;
  int tmp ;
  tdata_t tmp___0 ;
  float *fp ;
  tdata_t tmp___1 ;
  uint32 i ;
  int tmp___2 ;
  int tmp___3 ;

  {
  if ((int )dir->tdir_type == 5) {
    tmp = TIFFFetchNormalTag(tif, dir);
    return (tmp);
  } else {

  }
  tmp___0 = _TIFFCheckMalloc(tif, (size_t )dir->tdir_count, sizeof(uint32 ),
                             mesg___0);
  cp = (char *)tmp___0;
  if (cp) {
    tmp___2 = TIFFFetchLongArray(tif, dir, (uint32 *)cp);
    if (tmp___2) {
      tmp___3 = 1;
    } else {
      tmp___3 = 0;
    }
  } else {
    tmp___3 = 0;
  }
  ok = tmp___3;
  if (ok != 0) {
    tmp___1 = _TIFFCheckMalloc(tif, (size_t )dir->tdir_count, sizeof(float ),
                               mesg___0);
    fp = (float *)tmp___1;
    ok = (unsigned long )fp != (unsigned long )((void *)0);
    if (ok != 0) {
      i = (uint32 )0;
      while (i < dir->tdir_count) {
        *(fp + i) = (float )*((uint32 *)cp + i);
        i ++;
      }
      ok = TIFFSetField(tif, (ttag_t )dir->tdir_tag, fp);
      _TIFFfree((tdata_t )((char *)fp));
    } else {

    }
  } else {

  }
  if (cp) {
    _TIFFfree((tdata_t )cp);
  } else {

  }
  return (ok);
}
}
static void ChopUpSingleUncompressedStrip(TIFF *tif ) 
{ 
  register TIFFDirectory *td ;
  uint32 bytecount ;
  uint32 offset ;
  tsize_t rowbytes ;
  tsize_t tmp ;
  tsize_t stripbytes ;
  tstrip_t strip ;
  tstrip_t nstrips ;
  tstrip_t rowsperstrip ;
  uint32 *newcounts ;
  uint32 *newoffsets ;
  tdata_t tmp___0 ;
  tdata_t tmp___1 ;
  tstrip_t tmp___2 ;

  {
  td = & tif->tif_dir;
  bytecount = *(td->td_stripbytecount + 0);
  offset = *(td->td_stripoffset + 0);
  tmp = TIFFVTileSize(tif, (uint32 )1);
  rowbytes = tmp;
  if (rowbytes > 8192) {
    stripbytes = rowbytes;
    rowsperstrip = (tstrip_t )1;
  } else
  if (rowbytes > 0) {
    rowsperstrip = (tstrip_t )(8192 / rowbytes);
    stripbytes = (tsize_t )((tstrip_t )rowbytes * rowsperstrip);
  } else {
    return;
  }
  if (rowsperstrip >= td->td_rowsperstrip) {
    return;
  } else {

  }
  nstrips = (bytecount + ((uint32 )stripbytes - 1U)) / (uint32 )stripbytes;
  if (nstrips == 0U) {
    return;
  } else {

  }
  tmp___0 = _TIFFCheckMalloc(tif, (size_t )nstrips, sizeof(uint32 ),
                             "for chopped \"StripByteCounts\" array");
  newcounts = (uint32 *)tmp___0;
  tmp___1 = _TIFFCheckMalloc(tif, (size_t )nstrips, sizeof(uint32 ),
                             "for chopped \"StripOffsets\" array");
  newoffsets = (uint32 *)tmp___1;
  if ((unsigned long )newcounts == (unsigned long )((void *)0)) {
    goto _L;
  } else
  if ((unsigned long )newoffsets == (unsigned long )((void *)0)) {
    _L: 
    if ((unsigned long )newcounts != (unsigned long )((void *)0)) {
      _TIFFfree((tdata_t )newcounts);
    } else {

    }
    if ((unsigned long )newoffsets != (unsigned long )((void *)0)) {
      _TIFFfree((tdata_t )newoffsets);
    } else {

    }
    return;
  } else {

  }
  strip = (tstrip_t )0;
  while (strip < nstrips) {
    if (stripbytes > (tsize_t )bytecount) {
      stripbytes = (tsize_t )bytecount;
    } else {

    }
    *(newcounts + strip) = (uint32 )stripbytes;
    *(newoffsets + strip) = offset;
    offset += (uint32 )stripbytes;
    bytecount -= (uint32 )stripbytes;
    strip ++;
  }
  tmp___2 = nstrips;
  td->td_nstrips = tmp___2;
  td->td_stripsperimage = tmp___2;
  TIFFSetField(tif, (ttag_t )278, rowsperstrip);
  _TIFFfree((tdata_t )td->td_stripbytecount);
  _TIFFfree((tdata_t )td->td_stripoffset);
  td->td_stripbytecount = newcounts;
  td->td_stripoffset = newoffsets;
  td->td_stripbytecountsorted = 1;
  return;
}
}
