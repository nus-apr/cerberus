typedef unsigned long size_t;
typedef int wchar_t;
typedef long __off_t;
typedef long __off64_t;
typedef long __ssize_t;
typedef unsigned long ulong;
typedef unsigned int uint;
struct __anonstruct___sigset_t_9 {
   unsigned long __val[1024UL / (8UL * sizeof(unsigned long ))] ;
};
typedef struct __anonstruct___sigset_t_9 __sigset_t;
union __anonunion___u_23 {
   long double __l ;
   int __i[3] ;
};
struct _IO_FILE;
struct _IO_FILE;
struct _IO_FILE;
typedef struct _IO_FILE FILE;
typedef __builtin_va_list __gnuc_va_list;
struct _IO_FILE;
typedef void _IO_lock_t;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
struct _IO_FILE {
   int _flags ;
   char *_IO_read_ptr ;
   char *_IO_read_end ;
   char *_IO_read_base ;
   char *_IO_write_base ;
   char *_IO_write_ptr ;
   char *_IO_write_end ;
   char *_IO_buf_base ;
   char *_IO_buf_end ;
   char *_IO_save_base ;
   char *_IO_backup_base ;
   char *_IO_save_end ;
   struct _IO_marker *_markers ;
   struct _IO_FILE *_chain ;
   int _fileno ;
   int _flags2 ;
   __off_t _old_offset ;
   unsigned short _cur_column ;
   signed char _vtable_offset ;
   char _shortbuf[1] ;
   _IO_lock_t *_lock ;
   __off64_t _offset ;
   void *__pad1 ;
   void *__pad2 ;
   void *__pad3 ;
   void *__pad4 ;
   size_t __pad5 ;
   int _mode ;
   char _unused2[(15UL * sizeof(int ) - 4UL * sizeof(void *)) - sizeof(size_t )] ;
};
typedef struct _IO_FILE _IO_FILE;
struct obstack;
struct obstack;
struct obstack;
typedef unsigned char zend_bool;
typedef unsigned char zend_uchar;
typedef unsigned int zend_uint;
typedef unsigned long zend_ulong;
typedef unsigned int zend_object_handle;
struct _zend_object_handlers;
struct _zend_object_handlers;
typedef struct _zend_object_handlers zend_object_handlers;
struct _zend_object_value {
   zend_object_handle handle ;
   zend_object_handlers *handlers ;
};
typedef struct _zend_object_value zend_object_value;
struct _hashtable;
struct _hashtable;
struct _hashtable;
struct bucket {
   ulong h ;
   uint nKeyLength ;
   void *pData ;
   void *pDataPtr ;
   struct bucket *pListNext ;
   struct bucket *pListLast ;
   struct bucket *pNext ;
   struct bucket *pLast ;
   char *arKey ;
};
typedef struct bucket Bucket;
struct _hashtable {
   uint nTableSize ;
   uint nTableMask ;
   uint nNumOfElements ;
   ulong nNextFreeElement ;
   Bucket *pInternalPointer ;
   Bucket *pListHead ;
   Bucket *pListTail ;
   Bucket **arBuckets ;
   void (*pDestructor)(void *pDest ) ;
   zend_bool persistent ;
   unsigned char nApplyCount ;
   zend_bool bApplyProtection ;
};
typedef struct _hashtable HashTable;
typedef Bucket *HashPosition;
struct _HashPointer {
   HashPosition pos ;
   ulong h ;
};
typedef struct _HashPointer HashPointer;
struct _zval_struct;
struct _zval_struct;
typedef struct _zval_struct zval;
struct _zend_class_entry;
struct _zend_class_entry;
typedef struct _zend_class_entry zend_class_entry;
struct _zend_guard {
   zend_bool in_get ;
   zend_bool in_set ;
   zend_bool in_unset ;
   zend_bool in_isset ;
   zend_bool dummy ;
};
typedef struct _zend_guard zend_guard;
struct _zend_object {
   zend_class_entry *ce ;
   HashTable *properties ;
   zval **properties_table ;
   HashTable *guards ;
};
typedef struct _zend_object zend_object;
union _zend_function;
union _zend_function;
union _zend_function;
struct _zend_property_info;
struct _zend_property_info;
struct _zend_property_info;
struct _zend_literal;
struct _zend_literal;
struct _zend_literal;
struct _zend_object_handlers {
   void (*add_ref)(zval *object ) ;
   void (*del_ref)(zval *object ) ;
   zend_object_value (*clone_obj)(zval *object ) ;
   zval *(*read_property)(zval *object , zval *member , int type ,
                          struct _zend_literal  const  *key ) ;
   void (*write_property)(zval *object , zval *member , zval *value ,
                          struct _zend_literal  const  *key ) ;
   zval *(*read_dimension)(zval *object , zval *offset , int type ) ;
   void (*write_dimension)(zval *object , zval *offset , zval *value ) ;
   zval **(*get_property_ptr_ptr)(zval *object , zval *member ,
                                  struct _zend_literal  const  *key ) ;
   zval *(*get)(zval *object ) ;
   void (*set)(zval **object , zval *value ) ;
   int (*has_property)(zval *object , zval *member , int has_set_exists ,
                       struct _zend_literal  const  *key ) ;
   void (*unset_property)(zval *object , zval *member ,
                          struct _zend_literal  const  *key ) ;
   int (*has_dimension)(zval *object , zval *member , int check_empty ) ;
   void (*unset_dimension)(zval *object , zval *offset ) ;
   HashTable *(*get_properties)(zval *object ) ;
   union _zend_function *(*get_method)(zval **object_ptr , char *method ,
                                       int method_len ,
                                       struct _zend_literal  const  *key ) ;
   int (*call_method)(char *method , int ht , zval *return_value ,
                      zval **return_value_ptr , zval *this_ptr ,
                      int return_value_used ) ;
   union _zend_function *(*get_constructor)(zval *object ) ;
   zend_class_entry *(*get_class_entry)(zval const   *object ) ;
   int (*get_class_name)(zval const   *object , char **class_name ,
                         zend_uint *class_name_len , int parent ) ;
   int (*compare_objects)(zval *object1 , zval *object2 ) ;
   int (*cast_object)(zval *readobj , zval *retval , int type ) ;
   int (*count_elements)(zval *object , long *count ) ;
   HashTable *(*get_debug_info)(zval *object , int *is_temp ) ;
   int (*get_closure)(zval *obj , zend_class_entry **ce_ptr ,
                      union _zend_function **fptr_ptr , zval **zobj_ptr ) ;
};
struct __anonstruct_str_34 {
   char *val ;
   int len ;
};
union _zvalue_value {
   long lval ;
   double dval ;
   struct __anonstruct_str_34 str ;
   HashTable *ht ;
   zend_object_value obj ;
};
typedef union _zvalue_value zvalue_value;
struct _zval_struct {
   zvalue_value value ;
   zend_uint refcount__gc ;
   zend_uchar type ;
   zend_uchar is_ref__gc ;
};
union _zend_function;
struct _zend_object_iterator;
struct _zend_object_iterator;
typedef struct _zend_object_iterator zend_object_iterator;
struct _zend_object_iterator_funcs {
   void (*dtor)(zend_object_iterator *iter ) ;
   int (*valid)(zend_object_iterator *iter ) ;
   void (*get_current_data)(zend_object_iterator *iter , zval ***data ) ;
   int (*get_current_key)(zend_object_iterator *iter , char **str_key ,
                          uint *str_key_len , ulong *int_key ) ;
   void (*move_forward)(zend_object_iterator *iter ) ;
   void (*rewind)(zend_object_iterator *iter ) ;
   void (*invalidate_current)(zend_object_iterator *iter ) ;
};
typedef struct _zend_object_iterator_funcs zend_object_iterator_funcs;
struct _zend_object_iterator {
   void *data ;
   zend_object_iterator_funcs *funcs ;
   ulong index ;
};
struct _zend_class_iterator_funcs {
   zend_object_iterator_funcs *funcs ;
   union _zend_function *zf_new_iterator ;
   union _zend_function *zf_valid ;
   union _zend_function *zf_current ;
   union _zend_function *zf_key ;
   union _zend_function *zf_next ;
   union _zend_function *zf_rewind ;
};
typedef struct _zend_class_iterator_funcs zend_class_iterator_funcs;
struct _zend_serialize_data;
struct _zend_serialize_data;
struct _zend_serialize_data;
struct _zend_unserialize_data;
struct _zend_unserialize_data;
struct _zend_unserialize_data;
typedef struct _zend_serialize_data zend_serialize_data;
typedef struct _zend_unserialize_data zend_unserialize_data;
struct _zend_trait_method_reference {
   char *method_name ;
   unsigned int mname_len ;
   zend_class_entry *ce ;
   char *class_name ;
   unsigned int cname_len ;
};
typedef struct _zend_trait_method_reference zend_trait_method_reference;
struct _zend_trait_precedence {
   zend_trait_method_reference *trait_method ;
   zend_class_entry **exclude_from_classes ;
   union _zend_function *function ;
};
typedef struct _zend_trait_precedence zend_trait_precedence;
struct _zend_trait_alias {
   zend_trait_method_reference *trait_method ;
   char *alias ;
   unsigned int alias_len ;
   zend_uint modifiers ;
   union _zend_function *function ;
};
typedef struct _zend_trait_alias zend_trait_alias;
struct __anonstruct_user_36 {
   char *filename ;
   zend_uint line_start ;
   zend_uint line_end ;
   char *doc_comment ;
   zend_uint doc_comment_len ;
};
struct _zend_function_entry;
struct _zend_function_entry;
struct _zend_module_entry;
struct _zend_module_entry;
struct __anonstruct_internal_37 {
   struct _zend_function_entry  const  *builtin_functions ;
   struct _zend_module_entry *module ;
};
union __anonunion_info_35 {
   struct __anonstruct_user_36 user ;
   struct __anonstruct_internal_37 internal ;
};
struct _zend_class_entry {
   char type ;
   char const   *name ;
   zend_uint name_length ;
   struct _zend_class_entry *parent ;
   int refcount ;
   zend_uint ce_flags ;
   HashTable function_table ;
   HashTable properties_info ;
   zval **default_properties_table ;
   zval **default_static_members_table ;
   zval **static_members_table ;
   HashTable constants_table ;
   int default_properties_count ;
   int default_static_members_count ;
   union _zend_function *constructor ;
   union _zend_function *destructor ;
   union _zend_function *clone ;
   union _zend_function *__get ;
   union _zend_function *__set ;
   union _zend_function *__unset ;
   union _zend_function *__isset ;
   union _zend_function *__call ;
   union _zend_function *__callstatic ;
   union _zend_function *__tostring ;
   union _zend_function *serialize_func ;
   union _zend_function *unserialize_func ;
   zend_class_iterator_funcs iterator_funcs ;
   zend_object_value (*create_object)(zend_class_entry *class_type ) ;
   zend_object_iterator *(*get_iterator)(zend_class_entry *ce , zval *object ,
                                         int by_ref ) ;
   int (*interface_gets_implemented)(zend_class_entry *iface ,
                                     zend_class_entry *class_type ) ;
   union _zend_function *(*get_static_method)(zend_class_entry *ce ,
                                              char *method , int method_len ) ;
   int (*serialize)(zval *object , unsigned char **buffer , zend_uint *buf_len ,
                    zend_serialize_data *data ) ;
   int (*unserialize)(zval **object , zend_class_entry *ce ,
                      unsigned char const   *buf , zend_uint buf_len ,
                      zend_unserialize_data *data ) ;
   zend_class_entry **interfaces ;
   zend_uint num_interfaces ;
   zend_class_entry **traits ;
   zend_uint num_traits ;
   zend_trait_alias **trait_aliases ;
   zend_trait_precedence **trait_precedences ;
   union __anonunion_info_35 info ;
};
union __anonunion_u_40 {
   zval *pz ;
   zend_object_handlers *handlers ;
};
struct _gc_root_buffer {
   struct _gc_root_buffer *prev ;
   struct _gc_root_buffer *next ;
   zend_object_handle handle ;
   union __anonunion_u_40 u ;
};
typedef struct _gc_root_buffer gc_root_buffer;
struct _zval_gc_info;
union __anonunion_u_41 {
   gc_root_buffer *buffered ;
   struct _zval_gc_info *next ;
};
struct _zval_gc_info {
   zval z ;
   union __anonunion_u_41 u ;
};
typedef struct _zval_gc_info zval_gc_info;
enum __anonenum_zend_error_handling_t_42 {
    EH_NORMAL = 0,
    EH_SUPPRESS = 1,
    EH_THROW = 2
} ;
typedef enum __anonenum_zend_error_handling_t_42 zend_error_handling_t;
typedef long __jmp_buf[8];
struct __jmp_buf_tag {
   __jmp_buf __jmpbuf ;
   int __mask_was_saved ;
   __sigset_t __saved_mask ;
};
typedef struct __jmp_buf_tag jmp_buf[1];
struct _zend_executor_globals;
struct _zend_executor_globals;
typedef struct _zend_executor_globals zend_executor_globals;
struct _zend_stack {
   int top ;
   int max ;
   void **elements ;
};
typedef struct _zend_stack zend_stack;
struct _zend_ptr_stack {
   int top ;
   int max ;
   void **elements ;
   void **top_element ;
   zend_bool persistent ;
};
typedef struct _zend_ptr_stack zend_ptr_stack;
struct _store_object {
   void *object ;
   void (*dtor)(void *object , zend_object_handle handle ) ;
   void (*free_storage)(void *object ) ;
   void (*clone)(void *object , void **object_clone ) ;
   zend_object_handlers const   *handlers ;
   zend_uint refcount ;
   gc_root_buffer *buffered ;
};
struct __anonstruct_free_list_44 {
   int next ;
};
union _store_bucket {
   struct _store_object obj ;
   struct __anonstruct_free_list_44 free_list ;
};
struct _zend_object_store_bucket {
   zend_bool destructor_called ;
   zend_bool valid ;
   union _store_bucket bucket ;
};
typedef struct _zend_object_store_bucket zend_object_store_bucket;
struct _zend_objects_store {
   zend_object_store_bucket *object_buckets ;
   zend_uint top ;
   zend_uint size ;
   int free_list_head ;
};
typedef struct _zend_objects_store zend_objects_store;
struct _zend_op_array;
struct _zend_op_array;
typedef struct _zend_op_array zend_op_array;
struct _zend_op;
struct _zend_op;
typedef struct _zend_op zend_op;
struct _zend_literal {
   zval constant ;
   zend_ulong hash_value ;
   zend_uint cache_slot ;
};
typedef struct _zend_literal zend_literal;
union _znode_op {
   zend_uint constant ;
   zend_uint var ;
   zend_uint num ;
   zend_ulong hash ;
   zend_uint opline_num ;
   zend_op *jmp_addr ;
   zval *zv ;
   zend_literal *literal ;
   void *ptr ;
};
typedef union _znode_op znode_op;
struct _zend_execute_data;
struct _zend_execute_data;
typedef struct _zend_execute_data zend_execute_data;
struct _zend_op {
   int (*handler)(zend_execute_data *execute_data ) ;
   znode_op op1 ;
   znode_op op2 ;
   znode_op result ;
   ulong extended_value ;
   uint lineno ;
   zend_uchar opcode ;
   zend_uchar op1_type ;
   zend_uchar op2_type ;
   zend_uchar result_type ;
};
struct _zend_brk_cont_element {
   int start ;
   int cont ;
   int brk ;
   int parent ;
};
typedef struct _zend_brk_cont_element zend_brk_cont_element;
struct _zend_try_catch_element {
   zend_uint try_op ;
   zend_uint catch_op ;
};
typedef struct _zend_try_catch_element zend_try_catch_element;
struct _zend_property_info {
   zend_uint flags ;
   char *name ;
   int name_length ;
   ulong h ;
   int offset ;
   char *doc_comment ;
   int doc_comment_len ;
   zend_class_entry *ce ;
};
typedef struct _zend_property_info zend_property_info;
struct _zend_arg_info {
   char const   *name ;
   zend_uint name_len ;
   char const   *class_name ;
   zend_uint class_name_len ;
   zend_uchar type_hint ;
   zend_bool allow_null ;
   zend_bool pass_by_reference ;
};
typedef struct _zend_arg_info zend_arg_info;
struct _zend_compiled_variable {
   char *name ;
   int name_len ;
   ulong hash_value ;
};
typedef struct _zend_compiled_variable zend_compiled_variable;
struct _zend_op_array {
   zend_uchar type ;
   char *function_name ;
   zend_class_entry *scope ;
   zend_uint fn_flags ;
   union _zend_function *prototype ;
   zend_uint num_args ;
   zend_uint required_num_args ;
   zend_arg_info *arg_info ;
   zend_uint *refcount ;
   zend_op *opcodes ;
   zend_uint last ;
   zend_compiled_variable *vars ;
   int last_var ;
   zend_uint T ;
   zend_brk_cont_element *brk_cont_array ;
   int last_brk_cont ;
   zend_try_catch_element *try_catch_array ;
   int last_try_catch ;
   HashTable *static_variables ;
   zend_uint this_var ;
   char *filename ;
   zend_uint line_start ;
   zend_uint line_end ;
   char *doc_comment ;
   zend_uint doc_comment_len ;
   zend_uint early_binding ;
   zend_literal *literals ;
   int last_literal ;
   void **run_time_cache ;
   int last_cache_slot ;
   void *reserved[4] ;
};
struct _zend_internal_function {
   zend_uchar type ;
   char *function_name ;
   zend_class_entry *scope ;
   zend_uint fn_flags ;
   union _zend_function *prototype ;
   zend_uint num_args ;
   zend_uint required_num_args ;
   zend_arg_info *arg_info ;
   void (*handler)(int ht , zval *return_value , zval **return_value_ptr ,
                   zval *this_ptr , int return_value_used ) ;
   struct _zend_module_entry *module ;
};
typedef struct _zend_internal_function zend_internal_function;
struct __anonstruct_common_46 {
   zend_uchar type ;
   char *function_name ;
   zend_class_entry *scope ;
   zend_uint fn_flags ;
   union _zend_function *prototype ;
   zend_uint num_args ;
   zend_uint required_num_args ;
   zend_arg_info *arg_info ;
};
union _zend_function {
   zend_uchar type ;
   struct __anonstruct_common_46 common ;
   zend_op_array op_array ;
   zend_internal_function internal_function ;
};
typedef union _zend_function zend_function;
struct _zend_function_state {
   zend_function *function ;
   void **arguments ;
};
typedef struct _zend_function_state zend_function_state;
union _temp_variable;
union _temp_variable;
union _temp_variable;
struct _zend_execute_data {
   struct _zend_op *opline ;
   zend_function_state function_state ;
   zend_function *fbc ;
   zend_class_entry *called_scope ;
   zend_op_array *op_array ;
   zval *object ;
   union _temp_variable *Ts ;
   zval ***CVs ;
   HashTable *symbol_table ;
   struct _zend_execute_data *prev_execute_data ;
   zval *old_error_reporting ;
   zend_bool nested ;
   zval **original_return_value ;
   zend_class_entry *current_scope ;
   zend_class_entry *current_called_scope ;
   zval *current_this ;
   zval *current_object ;
};
struct _zend_ini_entry;
struct _zend_ini_entry;
struct _zend_ini_entry;
typedef struct _zend_module_entry zend_module_entry;
struct _zend_module_dep;
struct _zend_module_dep;
struct _zend_module_entry {
   unsigned short size ;
   unsigned int zend_api ;
   unsigned char zend_debug ;
   unsigned char zts ;
   struct _zend_ini_entry  const  *ini_entry ;
   struct _zend_module_dep  const  *deps ;
   char const   *name ;
   struct _zend_function_entry  const  *functions ;
   int (*module_startup_func)(int type , int module_number ) ;
   int (*module_shutdown_func)(int type , int module_number ) ;
   int (*request_startup_func)(int type , int module_number ) ;
   int (*request_shutdown_func)(int type , int module_number ) ;
   void (*info_func)(zend_module_entry *zend_module ) ;
   char const   *version ;
   size_t globals_size ;
   void *globals_ptr ;
   void (*globals_ctor)(void *global ) ;
   void (*globals_dtor)(void *global ) ;
   int (*post_deactivate_func)(void) ;
   int module_started ;
   unsigned char type ;
   void *handle ;
   int module_number ;
   char const   *build_id ;
};
struct _zend_module_dep {
   char const   *name ;
   char const   *rel ;
   char const   *version ;
   unsigned char type ;
};
typedef unsigned short fpu_control_t;
struct _zend_vm_stack;
struct _zend_vm_stack;
typedef struct _zend_vm_stack *zend_vm_stack;
typedef struct _zend_ini_entry zend_ini_entry;
struct _zend_executor_globals {
   zval **return_value_ptr_ptr ;
   zval uninitialized_zval ;
   zval *uninitialized_zval_ptr ;
   zval error_zval ;
   zval *error_zval_ptr ;
   zend_ptr_stack arg_types_stack ;
   HashTable *symtable_cache[32] ;
   HashTable **symtable_cache_limit ;
   HashTable **symtable_cache_ptr ;
   zend_op **opline_ptr ;
   HashTable *active_symbol_table ;
   HashTable symbol_table ;
   HashTable included_files ;
   jmp_buf *bailout ;
   int error_reporting ;
   int orig_error_reporting ;
   int exit_status ;
   zend_op_array *active_op_array ;
   HashTable *function_table ;
   HashTable *class_table ;
   HashTable *zend_constants ;
   zend_class_entry *scope ;
   zend_class_entry *called_scope ;
   zval *This ;
   long precision ;
   int ticks_count ;
   zend_bool in_execution ;
   HashTable *in_autoload ;
   zend_function *autoload_func ;
   zend_bool full_tables_cleanup ;
   zend_bool no_extensions ;
   HashTable regular_list ;
   HashTable persistent_list ;
   zend_vm_stack argument_stack ;
   int user_error_handler_error_reporting ;
   zval *user_error_handler ;
   zval *user_exception_handler ;
   zend_stack user_error_handlers_error_reporting ;
   zend_ptr_stack user_error_handlers ;
   zend_ptr_stack user_exception_handlers ;
   zend_error_handling_t error_handling ;
   zend_class_entry *exception_class ;
   int timeout_seconds ;
   int lambda_count ;
   HashTable *ini_directives ;
   HashTable *modified_ini_directives ;
   zend_ini_entry *error_reporting_ini_entry ;
   zend_objects_store objects_store ;
   zval *exception ;
   zval *prev_exception ;
   zend_op *opline_before_exception ;
   zend_op exception_op[3] ;
   struct _zend_execute_data *current_execute_data ;
   struct _zend_module_entry *current_module ;
   zend_property_info std_property_info ;
   zend_bool active ;
   zend_op *start_op ;
   void *saved_fpu_cw_ptr ;
   fpu_control_t saved_fpu_cw ;
   void *reserved[4] ;
};
struct __anonstruct_var_47 {
   zval **ptr_ptr ;
   zval *ptr ;
   zend_bool fcall_returned_reference ;
};
struct __anonstruct_str_offset_48 {
   zval **ptr_ptr ;
   zval *str ;
   zend_uint offset ;
};
struct __anonstruct_fe_49 {
   zval **ptr_ptr ;
   zval *ptr ;
   HashPointer fe_pos ;
};
union _temp_variable {
   zval tmp_var ;
   struct __anonstruct_var_47 var ;
   struct __anonstruct_str_offset_48 str_offset ;
   struct __anonstruct_fe_49 fe ;
   zend_class_entry *class_entry ;
};
struct _zend_vm_stack {
   void **top ;
   void **end ;
   zend_vm_stack prev ;
};
struct _zend_function_entry {
   char const   *fname ;
   void (*handler)(int ht , zval *return_value , zval **return_value_ptr ,
                   zval *this_ptr , int return_value_used ) ;
   struct _zend_arg_info  const  *arg_info ;
   zend_uint num_args ;
   zend_uint flags ;
};
__inline extern  __attribute__((__nothrow__)) double __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atof)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atoi)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atol)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) long long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atoll)(char const   *__nptr )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) double ( __attribute__((__nonnull__(1),
__leaf__)) strtod)(char const   * __restrict  __nptr ,
                   char ** __restrict  __endptr ) ;
extern  __attribute__((__nothrow__)) long ( __attribute__((__nonnull__(1),
__leaf__)) strtol)(char const   * __restrict  __nptr ,
                   char ** __restrict  __endptr , int __base ) ;
extern  __attribute__((__nothrow__)) long long ( __attribute__((__nonnull__(1),
__leaf__)) strtoll)(char const   * __restrict  __nptr ,
                    char ** __restrict  __endptr , int __base ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atoi)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) atoi)(char const   *__nptr ) 
{ 
  long tmp ;

  {
  tmp = strtol((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)), 10);
  return ((int __attribute__((__gnu_inline__))  )((int )tmp));
}
}
__inline extern  __attribute__((__nothrow__)) long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atol)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) atol)(char const   *__nptr ) 
{ 
  long tmp ;

  {
  tmp = strtol((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)), 10);
  return ((long __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) long long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atoll)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern long long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) atoll)(char const   *__nptr ) 
{ 
  long long tmp ;

  {
  tmp = strtoll((char const   */* __restrict  */)__nptr,
                (char **/* __restrict  */)((char **)((void *)0)), 10);
  return ((long long __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_major)(unsigned long long __dev )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_minor)(unsigned long long __dev )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) unsigned long long __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_makedev)(unsigned int __major ,
                                                                                                                                               unsigned int __minor )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_major)(unsigned long long __dev )  __attribute__((__const__)) ;
__inline extern unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_major)(unsigned long long __dev ) 
{ 


  {
  return ((unsigned int __attribute__((__gnu_inline__))  )(((__dev >> 8) & 4095ULL) | (unsigned long long )((unsigned int )(__dev >> 32) & 4294963200U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_minor)(unsigned long long __dev )  __attribute__((__const__)) ;
__inline extern unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_minor)(unsigned long long __dev ) 
{ 


  {
  return ((unsigned int __attribute__((__gnu_inline__))  )((__dev & 255ULL) | (unsigned long long )((unsigned int )(__dev >> 12) & 4294967040U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned long long __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_makedev)(unsigned int __major ,
                                                                                                                                               unsigned int __minor )  __attribute__((__const__)) ;
__inline extern unsigned long long __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_makedev)(unsigned int __major ,
                                                                                                                 unsigned int __minor ) 
{ 


  {
  return ((unsigned long long __attribute__((__gnu_inline__))  )(((unsigned long long )((__minor & 255U) | ((__major & 4095U) << 8)) | ((unsigned long long )(__minor & 4294967040U) << 12)) | ((unsigned long long )(__major & 4294963200U) << 32)));
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) realpath)(char const   * __restrict  __name ,
                              char * __restrict  __resolved ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__nonnull__(1,2,5))) bsearch)(void const   *__key , void const   *__base ,
                              size_t __nmemb , size_t __size ,
                              int (*__compar)(void const   * , void const   * ) ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__nonnull__(1,2,5))) bsearch)(void const   *__key , void const   *__base ,
                              size_t __nmemb , size_t __size ,
                              int (*__compar)(void const   * , void const   * ) ) 
{ 
  size_t __l ;
  size_t __u ;
  size_t __idx ;
  void const   *__p ;
  int __comparison ;

  {
  __l = (size_t )0;
  __u = __nmemb;
  while (__l < __u) {
    __idx = (__l + __u) / 2UL;
    __p = (void const   *)((void *)((char const   *)__base + __idx * __size));
    __comparison = (*__compar)(__key, __p);
    if (__comparison < 0) {
      __u = __idx;
    } else
    if (__comparison > 0) {
      __l = __idx + 1UL;
    } else {
      return ((void __attribute__((__gnu_inline__))  *)((void *)__p));
    }
  }
  return ((void __attribute__((__gnu_inline__))  *)((void *)0));
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) wctomb)(char *__s , wchar_t __wchar ) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) mbstowcs)(wchar_t * __restrict  __dst ,
                                              char const   * __restrict  __src ,
                                              size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcstombs)(char * __restrict  __dst ,
                              wchar_t const   * __restrict  __src ,
                              size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__, __artificial__,
__always_inline__)) ptsname_r)(int __fd , char *__buf , size_t __buflen ) ;
__inline extern  __attribute__((__nothrow__)) double __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atof)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern double __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) atof)(char const   *__nptr ) 
{ 
  double tmp ;

  {
  tmp = strtod((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)));
  return ((double __attribute__((__gnu_inline__))  )tmp);
}
}
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__leaf__)) __realpath_chk)(char const   * __restrict  __name ,
                           char * __restrict  __resolved , size_t __resolvedlen ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__leaf__)) __realpath_alias)(char const   * __restrict  __name ,
                             char * __restrict  __resolved )  __asm__("realpath")  ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) realpath)(char const   * __restrict  __name ,
                              char * __restrict  __resolved ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) realpath)(char const   * __restrict  __name ,
                              char * __restrict  __resolved ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__resolved, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__resolved, 1);
    tmp___0 = __realpath_chk(__name, __resolved, tmp);
    return ((char __attribute__((__gnu_inline__))  *)tmp___0);
  } else {

  }
  tmp___2 = __realpath_alias(__name, __resolved);
  return ((char __attribute__((__gnu_inline__))  *)tmp___2);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ptsname_r_chk)(int __fd , char *__buf , size_t __buflen ,
                            size_t __nreal ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ptsname_r_alias)(int __fd , char *__buf , size_t __buflen )  __asm__("ptsname_r")  ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ptsname_r_chk_warn)(int __fd , char *__buf , size_t __buflen ,
                                 size_t __nreal )  __asm__("__ptsname_r_chk") __attribute__((__warning__("ptsname_r called with buflen bigger than size of buf"))) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__, __artificial__,
__always_inline__)) ptsname_r)(int __fd , char *__buf , size_t __buflen ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__, __artificial__,
__always_inline__)) ptsname_r)(int __fd , char *__buf , size_t __buflen ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __ptsname_r_chk(__fd, __buf, __buflen, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__buflen > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __ptsname_r_chk_warn(__fd, __buf, __buflen, tmp___1);
      return ((int __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __ptsname_r_alias(__fd, __buf, __buflen);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __wctomb_chk)(char *__s , wchar_t __wchar , size_t __buflen ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __wctomb_alias)(char *__s , wchar_t __wchar )  __asm__("wctomb")  ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) wctomb)(char *__s , wchar_t __wchar ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) wctomb)(char *__s , wchar_t __wchar ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  unsigned long tmp___2 ;
  int tmp___3 ;

  {
  tmp___1 = __builtin_object_size((void *)__s, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp___2 = __builtin_object_size((void *)__s, 1);
    if (16UL > tmp___2) {
      tmp = __builtin_object_size((void *)__s, 1);
      tmp___0 = __wctomb_chk(__s, __wchar, tmp);
      return ((int __attribute__((__gnu_inline__))  )tmp___0);
    } else {

    }
  } else {

  }
  tmp___3 = __wctomb_alias(__s, __wchar);
  return ((int __attribute__((__gnu_inline__))  )tmp___3);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbstowcs_chk)(wchar_t * __restrict  __dst ,
                                                                                        char const   * __restrict  __src ,
                                                                                        size_t __len ,
                                                                                        size_t __dstlen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbstowcs_alias)(wchar_t * __restrict  __dst ,
                                                                                          char const   * __restrict  __src ,
                                                                                          size_t __len )  __asm__("mbstowcs")  ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbstowcs_chk_warn)(wchar_t * __restrict  __dst ,
                                                                                             char const   * __restrict  __src ,
                                                                                             size_t __len ,
                                                                                             size_t __dstlen )  __asm__("__mbstowcs_chk") __attribute__((__warning__("mbstowcs called with dst buffer smaller than len * sizeof (wchar_t)"))) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) mbstowcs)(wchar_t * __restrict  __dst ,
                                              char const   * __restrict  __src ,
                                              size_t __len ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) mbstowcs)(wchar_t * __restrict  __dst ,
                                              char const   * __restrict  __src ,
                                              size_t __len ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__dst, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dst, 1);
    tmp___0 = __mbstowcs_chk(__dst, __src, __len, tmp / sizeof(wchar_t ));
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__dst, 1);
    if (__len > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__dst, 1);
      tmp___2 = __mbstowcs_chk_warn(__dst, __src, __len,
                                    tmp___1 / sizeof(wchar_t ));
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __mbstowcs_alias(__dst, __src, __len);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcstombs_chk)(char * __restrict  __dst ,
                                                                                        wchar_t const   * __restrict  __src ,
                                                                                        size_t __len ,
                                                                                        size_t __dstlen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcstombs_alias)(char * __restrict  __dst ,
                                                                                          wchar_t const   * __restrict  __src ,
                                                                                          size_t __len )  __asm__("wcstombs")  ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcstombs_chk_warn)(char * __restrict  __dst ,
                                                                                             wchar_t const   * __restrict  __src ,
                                                                                             size_t __len ,
                                                                                             size_t __dstlen )  __asm__("__wcstombs_chk") __attribute__((__warning__("wcstombs called with dst buffer smaller than len"))) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcstombs)(char * __restrict  __dst ,
                              wchar_t const   * __restrict  __src ,
                              size_t __len ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcstombs)(char * __restrict  __dst ,
                              wchar_t const   * __restrict  __src ,
                              size_t __len ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__dst, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dst, 1);
    tmp___0 = __wcstombs_chk(__dst, __src, __len, tmp);
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__dst, 1);
    if (__len > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__dst, 1);
      tmp___2 = __wcstombs_chk_warn(__dst, __src, __len, tmp___1);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wcstombs_alias(__dst, __src, __len);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memcpy)(void * __restrict  __dest ,
                            void const   * __restrict  __src , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memmove)(void *__dest , void const   *__src , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1),
__leaf__, __artificial__, __always_inline__)) memset)(void *__dest , int __ch ,
                                                      size_t __len ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2),
__leaf__)) memcmp)(void const   *__s1 , void const   *__s2 , size_t __n )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcat)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncat)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) mempcpy)(void * __restrict  __dest ,
                             void const   * __restrict  __src , size_t __len ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__nonnull__(1),
__leaf__)) strlen)(char const   *__s )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) bcopy)(void const   *__src , void *__dest , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) bzero)(void *__dest , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __n ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c1(char const   *__s ,
                                                                     int __reject ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c1(char const   *__s ,
                                                                     int __reject ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if ((int const   )*(__s + __result) != 0) {
      if (! ((int const   )*(__s + __result) != (int const   )__reject)) {
        break;
      } else {

      }
    } else {
      break;
    }
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c2(char const   *__s ,
                                                                     int __reject1 ,
                                                                     int __reject2 ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c2(char const   *__s ,
                                                                     int __reject1 ,
                                                                     int __reject2 ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if ((int const   )*(__s + __result) != 0) {
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        if (! ((int const   )*(__s + __result) != (int const   )__reject2)) {
          break;
        } else {

        }
      } else {
        break;
      }
    } else {
      break;
    }
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c3(char const   *__s ,
                                                                     int __reject1 ,
                                                                     int __reject2 ,
                                                                     int __reject3 ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c3(char const   *__s ,
                                                                     int __reject1 ,
                                                                     int __reject2 ,
                                                                     int __reject3 ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if ((int const   )*(__s + __result) != 0) {
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          if (! ((int const   )*(__s + __result) != (int const   )__reject3)) {
            break;
          } else {

          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c1(char const   *__s ,
                                                                    int __accept ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c1(char const   *__s ,
                                                                    int __accept ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while ((int const   )*(__s + __result) == (int const   )__accept) {
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c2(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c2(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if (! ((int const   )*(__s + __result) == (int const   )__accept1)) {
      if (! ((int const   )*(__s + __result) == (int const   )__accept2)) {
        break;
      } else {

      }
    } else {

    }
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c3(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ,
                                                                    int __accept3 ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c3(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ,
                                                                    int __accept3 ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if (! ((int const   )*(__s + __result) == (int const   )__accept1)) {
      if (! ((int const   )*(__s + __result) == (int const   )__accept2)) {
        if (! ((int const   )*(__s + __result) == (int const   )__accept3)) {
          break;
        } else {

        }
      } else {

      }
    } else {

    }
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strpbrk_c2(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strpbrk_c2(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ) 
{ 
  char *tmp ;

  {
  while (1) {
    if ((int const   )*__s != 0) {
      if ((int const   )*__s != (int const   )__accept1) {
        if (! ((int const   )*__s != (int const   )__accept2)) {
          break;
        } else {

        }
      } else {
        break;
      }
    } else {
      break;
    }
    __s ++;
  }
  if ((int const   )*__s == 0) {
    tmp = (char *)((void *)0);
  } else {
    tmp = (char *)((size_t )__s);
  }
  return ((char __attribute__((__gnu_inline__))  *)tmp);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strpbrk_c3(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ,
                                                                    int __accept3 ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strpbrk_c3(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ,
                                                                    int __accept3 ) 
{ 
  char *tmp ;

  {
  while (1) {
    if ((int const   )*__s != 0) {
      if ((int const   )*__s != (int const   )__accept1) {
        if ((int const   )*__s != (int const   )__accept2) {
          if (! ((int const   )*__s != (int const   )__accept3)) {
            break;
          } else {

          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    __s ++;
  }
  if ((int const   )*__s == 0) {
    tmp = (char *)((void *)0);
  } else {
    tmp = (char *)((size_t )__s);
  }
  return ((char __attribute__((__gnu_inline__))  *)tmp);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strtok_r_1c(char *__s ,
                                                                     char __sep ,
                                                                     char **__nextp ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strtok_r_1c(char *__s ,
                                                                     char __sep ,
                                                                     char **__nextp ) 
{ 
  char *__result ;
  char *tmp ;
  char *tmp___0 ;

  {
  if ((unsigned long )__s == (unsigned long )((void *)0)) {
    __s = *__nextp;
  } else {

  }
  while ((int )*__s == (int )__sep) {
    __s ++;
  }
  __result = (char *)((void *)0);
  if ((int )*__s != 0) {
    tmp = __s;
    __s ++;
    __result = tmp;
    while ((int )*__s != 0) {
      tmp___0 = __s;
      __s ++;
      if ((int )*tmp___0 == (int )__sep) {
        *(__s + -1) = (char )'\000';
        break;
      } else {

      }
    }
  } else {

  }
  *__nextp = __s;
  return ((char __attribute__((__gnu_inline__))  *)__result);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strsep_1c(char **__s ,
                                                                   char __reject ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strsep_1c(char **__s ,
                                                                   char __reject ) 
{ 
  char *__retval ;
  char *tmp ;
  char *tmp___0 ;
  char *tmp___2 ;

  {
  __retval = *__s;
  if ((unsigned long )__retval != (unsigned long )((void *)0)) {
    tmp___2 = __builtin_strchr(__retval, (int )__reject);
    tmp___0 = tmp___2;
    *__s = tmp___0;
    if ((unsigned long )tmp___0 != (unsigned long )((void *)0)) {
      tmp = *__s;
      (*__s) ++;
      *tmp = (char )'\000';
    } else {

    }
  } else {

  }
  return ((char __attribute__((__gnu_inline__))  *)__retval);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strsep_2c(char **__s ,
                                                                   char __reject1 ,
                                                                   char __reject2 ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strsep_2c(char **__s ,
                                                                   char __reject1 ,
                                                                   char __reject2 ) 
{ 
  char *__retval ;
  char *__cp ;
  char *tmp ;

  {
  __retval = *__s;
  if ((unsigned long )__retval != (unsigned long )((void *)0)) {
    __cp = __retval;
    while (1) {
      if ((int )*__cp == 0) {
        __cp = (char *)((void *)0);
        break;
      } else {

      }
      if ((int )*__cp == (int )__reject1) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else
      if ((int )*__cp == (int )__reject2) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else {

      }
      __cp ++;
    }
    *__s = __cp;
  } else {

  }
  return ((char __attribute__((__gnu_inline__))  *)__retval);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strsep_3c(char **__s ,
                                                                   char __reject1 ,
                                                                   char __reject2 ,
                                                                   char __reject3 ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strsep_3c(char **__s ,
                                                                   char __reject1 ,
                                                                   char __reject2 ,
                                                                   char __reject3 ) 
{ 
  char *__retval ;
  char *__cp ;
  char *tmp ;

  {
  __retval = *__s;
  if ((unsigned long )__retval != (unsigned long )((void *)0)) {
    __cp = __retval;
    while (1) {
      if ((int )*__cp == 0) {
        __cp = (char *)((void *)0);
        break;
      } else {

      }
      if ((int )*__cp == (int )__reject1) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else
      if ((int )*__cp == (int )__reject2) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else
      if ((int )*__cp == (int )__reject3) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else {

      }
      __cp ++;
    }
    *__s = __cp;
  } else {

  }
  return ((char __attribute__((__gnu_inline__))  *)__retval);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memcpy)(void * __restrict  __dest ,
                            void const   * __restrict  __src , size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memcpy)(void * __restrict  __dest ,
                            void const   * __restrict  __src , size_t __len ) 
{ 
  unsigned long tmp ;
  void *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 0);
  tmp___0 = __builtin___memcpy_chk((void *)__dest, (void const   *)__src, __len,
                                   tmp);
  return ((void __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memmove)(void *__dest , void const   *__src , size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memmove)(void *__dest , void const   *__src , size_t __len ) 
{ 
  unsigned long tmp ;
  void *tmp___0 ;

  {
  tmp = __builtin_object_size(__dest, 0);
  tmp___0 = __builtin___memmove_chk(__dest, __src, __len, tmp);
  return ((void __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) mempcpy)(void * __restrict  __dest ,
                             void const   * __restrict  __src , size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) mempcpy)(void * __restrict  __dest ,
                             void const   * __restrict  __src , size_t __len ) 
{ 
  unsigned long tmp ;
  void *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 0);
  tmp___0 = __builtin___mempcpy_chk((void *)__dest, (void const   *)__src,
                                    __len, tmp);
  return ((void __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1),
__leaf__, __artificial__, __always_inline__)) memset)(void *__dest , int __ch ,
                                                      size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1),
__leaf__, __artificial__, __always_inline__)) memset)(void *__dest , int __ch ,
                                                      size_t __len ) 
{ 
  unsigned long tmp ;
  void *tmp___0 ;

  {
  tmp = __builtin_object_size(__dest, 0);
  tmp___0 = __builtin___memset_chk(__dest, __ch, __len, tmp);
  return ((void __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) bcopy)(void const   *__src , void *__dest , size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) bcopy)(void const   *__src , void *__dest , size_t __len ) 
{ 
  unsigned long tmp ;

  {
  tmp = __builtin_object_size(__dest, 0);
  __builtin___memmove_chk(__dest, __src, __len, tmp);
  return;
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) bzero)(void *__dest , size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) bzero)(void *__dest , size_t __len ) 
{ 
  unsigned long tmp ;

  {
  tmp = __builtin_object_size(__dest, 0);
  __builtin___memset_chk(__dest, '\000', __len, tmp);
  return;
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 1);
  tmp___0 = __builtin___strcpy_chk((char *)__dest, (char const   *)__src, tmp);
  return ((char __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 1);
  tmp___0 = __builtin___stpcpy_chk((char *)__dest, (char const   *)__src, tmp);
  return ((char __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 1);
  tmp___0 = __builtin___strncpy_chk((char *)__dest, (char const   *)__src,
                                    __len, tmp);
  return ((char __attribute__((__gnu_inline__))  *)tmp___0);
}
}
extern  __attribute__((__nothrow__)) char *( __attribute__((__leaf__)) __stpncpy_chk)(char *__dest ,
                                                                                      char const   *__src ,
                                                                                      size_t __n ,
                                                                                      size_t __destlen ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__leaf__)) __stpncpy_alias)(char *__dest ,
                                                                                        char const   *__src ,
                                                                                        size_t __n )  __asm__("stpncpy")  ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __n ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __n ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___3 ;

  {
  tmp___1 = __builtin_object_size((void *)__dest, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dest, 1);
    tmp___0 = __stpncpy_chk((char *)__dest, (char const   *)__src, __n, tmp);
    return ((char __attribute__((__gnu_inline__))  *)tmp___0);
  } else {

  }
  tmp___3 = __stpncpy_alias((char *)__dest, (char const   *)__src, __n);
  return ((char __attribute__((__gnu_inline__))  *)tmp___3);
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcat)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcat)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 1);
  tmp___0 = __builtin___strcat_chk((char *)__dest, (char const   *)__src, tmp);
  return ((char __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncat)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncat)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 1);
  tmp___0 = __builtin___strncat_chk((char *)__dest, (char const   *)__src,
                                    __len, tmp);
  return ((char __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbit)(double __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitf)(float __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitl)(long double __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitf)(float __x )  __attribute__((__const__)) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitf)(float __x ) 
{ 
  int __m ;

  {
  __asm__  ("pmovmskb %1, %0": "=r" (__m): "x" (__x));
  return ((int __attribute__((__gnu_inline__))  )((__m & 8) != 0));
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbit)(double __x )  __attribute__((__const__)) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbit)(double __x ) 
{ 
  int __m ;

  {
  __asm__  ("pmovmskb %1, %0": "=r" (__m): "x" (__x));
  return ((int __attribute__((__gnu_inline__))  )((__m & 128) != 0));
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitl)(long double __x )  __attribute__((__const__)) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitl)(long double __x ) 
{ 
  union __anonunion___u_23 __u ;

  {
  __u.__l = __x;
  return ((int __attribute__((__gnu_inline__))  )((__u.__i[2] & 32768) != 0));
}
}
extern int __uflow(_IO_FILE * ) ;
extern int __overflow(_IO_FILE * , int  ) ;
extern int _IO_getc(_IO_FILE *__fp ) ;
extern int _IO_putc(int __c , _IO_FILE *__fp ) ;
extern struct _IO_FILE *stdin ;
extern struct _IO_FILE *stdout ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) fprintf)(FILE * __restrict  __stream ,
                             char const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) printf)(char const   * __restrict  __fmt  , ...) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) sprintf)(char * __restrict  __s ,
                                             char const   * __restrict  __fmt 
                                             , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vfprintf)(FILE * __restrict  __stream ,
                              char const   * __restrict  __fmt ,
                              __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vprintf)(char const   * __restrict  __fmt ,
                             __gnuc_va_list __ap ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) vsprintf)(char * __restrict  __s ,
                                              char const   * __restrict  __fmt ,
                                              __gnuc_va_list __ap ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) snprintf)(char * __restrict  __s ,
                              size_t __n , char const   * __restrict  __fmt 
                              , ...) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) vsnprintf)(char * __restrict  __s ,
                               size_t __n , char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) vasprintf)(char ** __restrict  __ptr ,
                               char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) __asprintf)(char ** __restrict  __ptr ,
                                char const   * __restrict  __fmt  , ...) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) asprintf)(char ** __restrict  __ptr ,
                              char const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vdprintf)(int __fd , char const   * __restrict  __fmt ,
                              __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) dprintf)(int __fd , char const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  getchar(void) ;
__inline extern int __attribute__((__gnu_inline__))  getc_unlocked(FILE *__fp ) ;
__inline extern int __attribute__((__gnu_inline__))  getchar_unlocked(void) ;
__inline extern int __attribute__((__gnu_inline__))  fgetc_unlocked(FILE *__fp ) ;
__inline extern int __attribute__((__gnu_inline__))  putchar(int __c ) ;
__inline extern int __attribute__((__gnu_inline__))  fputc_unlocked(int __c ,
                                                                    FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  putc_unlocked(int __c ,
                                                                   FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  putchar_unlocked(int __c ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) fgets)(char * __restrict  __s , int __n ,
                                           FILE * __restrict  __stream ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fgets_unlocked)(char * __restrict  __s ,
                                    int __n , FILE * __restrict  __stream ) ;
extern __ssize_t ( __attribute__((__warn_unused_result__)) __getdelim)(char ** __restrict  __lineptr ,
                                                                       size_t * __restrict  __n ,
                                                                       int __delimiter ,
                                                                       FILE * __restrict  __stream ) ;
__inline extern __ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__)) getline)(char ** __restrict  __lineptr ,
                                                                                                              size_t * __restrict  __n ,
                                                                                                              FILE * __restrict  __stream ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) fread)(void * __restrict  __ptr ,
                                           size_t __size , size_t __n ,
                                           FILE * __restrict  __stream ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fread_unlocked)(void * __restrict  __ptr ,
                                    size_t __size , size_t __n ,
                                    FILE * __restrict  __stream ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) feof_unlocked)(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) ferror_unlocked)(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) obstack_printf)(struct obstack * __restrict  __obstack ,
                                    char const   * __restrict  __fmt  , ...) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) obstack_vprintf)(struct obstack * __restrict  __obstack ,
                                     char const   * __restrict  __fmt ,
                                     __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  getchar(void) 
{ 
  int tmp ;

  {
  tmp = _IO_getc(stdin);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  fgetc_unlocked(FILE *__fp ) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  tmp___3 = __builtin_expect((long )((unsigned long )__fp->_IO_read_ptr >= (unsigned long )__fp->_IO_read_end),
                             0L);
  if (tmp___3) {
    tmp___0 = __uflow(__fp);
    tmp___2 = tmp___0;
  } else {
    tmp___1 = __fp->_IO_read_ptr;
    (__fp->_IO_read_ptr) ++;
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
__inline extern int __attribute__((__gnu_inline__))  getc_unlocked(FILE *__fp ) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  tmp___3 = __builtin_expect((long )((unsigned long )__fp->_IO_read_ptr >= (unsigned long )__fp->_IO_read_end),
                             0L);
  if (tmp___3) {
    tmp___0 = __uflow(__fp);
    tmp___2 = tmp___0;
  } else {
    tmp___1 = __fp->_IO_read_ptr;
    (__fp->_IO_read_ptr) ++;
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
__inline extern int __attribute__((__gnu_inline__))  getchar_unlocked(void) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  tmp___3 = __builtin_expect((long )((unsigned long )stdin->_IO_read_ptr >= (unsigned long )stdin->_IO_read_end),
                             0L);
  if (tmp___3) {
    tmp___0 = __uflow(stdin);
    tmp___2 = tmp___0;
  } else {
    tmp___1 = stdin->_IO_read_ptr;
    (stdin->_IO_read_ptr) ++;
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
__inline extern int __attribute__((__gnu_inline__))  putchar(int __c ) 
{ 
  int tmp ;

  {
  tmp = _IO_putc(__c, stdout);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  fputc_unlocked(int __c ,
                                                                    FILE *__stream ) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  tmp___4 = __builtin_expect((long )((unsigned long )__stream->_IO_write_ptr >= (unsigned long )__stream->_IO_write_end),
                             0L);
  if (tmp___4) {
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    tmp___3 = tmp___0;
  } else {
    tmp___1 = __stream->_IO_write_ptr;
    (__stream->_IO_write_ptr) ++;
    tmp___2 = (char )__c;
    *tmp___1 = tmp___2;
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___3);
}
}
__inline extern int __attribute__((__gnu_inline__))  putc_unlocked(int __c ,
                                                                   FILE *__stream ) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  tmp___4 = __builtin_expect((long )((unsigned long )__stream->_IO_write_ptr >= (unsigned long )__stream->_IO_write_end),
                             0L);
  if (tmp___4) {
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    tmp___3 = tmp___0;
  } else {
    tmp___1 = __stream->_IO_write_ptr;
    (__stream->_IO_write_ptr) ++;
    tmp___2 = (char )__c;
    *tmp___1 = tmp___2;
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___3);
}
}
__inline extern int __attribute__((__gnu_inline__))  putchar_unlocked(int __c ) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  tmp___4 = __builtin_expect((long )((unsigned long )stdout->_IO_write_ptr >= (unsigned long )stdout->_IO_write_end),
                             0L);
  if (tmp___4) {
    tmp___0 = __overflow(stdout, (int )((unsigned char )__c));
    tmp___3 = tmp___0;
  } else {
    tmp___1 = stdout->_IO_write_ptr;
    (stdout->_IO_write_ptr) ++;
    tmp___2 = (char )__c;
    *tmp___1 = tmp___2;
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___3);
}
}
__inline extern __ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__)) getline)(char ** __restrict  __lineptr ,
                                                                                                              size_t * __restrict  __n ,
                                                                                                              FILE * __restrict  __stream ) 
{ 
  __ssize_t tmp ;

  {
  tmp = __getdelim(__lineptr, __n, '\n', __stream);
  return ((__ssize_t __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) feof_unlocked)(FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) feof_unlocked)(FILE *__stream ) 
{ 


  {
  return ((int __attribute__((__gnu_inline__))  )((__stream->_flags & 16) != 0));
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) ferror_unlocked)(FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) ferror_unlocked)(FILE *__stream ) 
{ 


  {
  return ((int __attribute__((__gnu_inline__))  )((__stream->_flags & 32) != 0));
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) sprintf)(char * __restrict  __s ,
                                             char const   * __restrict  __fmt 
                                             , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) sprintf)(char * __restrict  __s ,
                                             char const   * __restrict  __fmt 
                                             , ...) 
{ 
  unsigned long tmp ;
  int tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__s, 1);
  tmp___0 = __builtin___sprintf_chk((char *)__s, 1, tmp, (char const   *)__fmt,
                                    __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) vsprintf)(char * __restrict  __s ,
                                              char const   * __restrict  __fmt ,
                                              __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) vsprintf)(char * __restrict  __s ,
                                              char const   * __restrict  __fmt ,
                                              __gnuc_va_list __ap ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__s, 1);
  tmp___0 = __builtin___vsprintf_chk((char *)__s, 1, tmp, (char const   *)__fmt,
                                     __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) snprintf)(char * __restrict  __s ,
                              size_t __n , char const   * __restrict  __fmt 
                              , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) snprintf)(char * __restrict  __s ,
                              size_t __n , char const   * __restrict  __fmt 
                              , ...) 
{ 
  unsigned long tmp ;
  int tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__s, 1);
  tmp___0 = __builtin___snprintf_chk((char *)__s, __n, 1, tmp,
                                     (char const   *)__fmt,
                                     __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) vsnprintf)(char * __restrict  __s ,
                               size_t __n , char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) vsnprintf)(char * __restrict  __s ,
                               size_t __n , char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__s, 1);
  tmp___0 = __builtin___vsnprintf_chk((char *)__s, __n, 1, tmp,
                                      (char const   *)__fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
extern int __fprintf_chk(FILE * __restrict  __stream , int __flag ,
                         char const   * __restrict  __format  , ...) ;
extern int __printf_chk(int __flag , char const   * __restrict  __format  , ...) ;
extern int __vfprintf_chk(FILE * __restrict  __stream , int __flag ,
                          char const   * __restrict  __format ,
                          __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) fprintf)(FILE * __restrict  __stream ,
                             char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __fprintf_chk(__stream, 1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) printf)(char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __printf_chk(1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vprintf)(char const   * __restrict  __fmt ,
                             __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __vfprintf_chk((FILE */* __restrict  */)stdout, 1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vfprintf)(FILE * __restrict  __stream ,
                              char const   * __restrict  __fmt ,
                              __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __vfprintf_chk(__stream, 1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
extern int __dprintf_chk(int __fd , int __flag ,
                         char const   * __restrict  __fmt  , ...) ;
extern int __vdprintf_chk(int __fd , int __flag ,
                          char const   * __restrict  __fmt ,
                          __gnuc_va_list __arg ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) dprintf)(int __fd , char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __dprintf_chk(__fd, 1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vdprintf)(int __fd , char const   * __restrict  __fmt ,
                              __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __vdprintf_chk(__fd, 1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __asprintf_chk)(char ** __restrict  __ptr , int __flag ,
                           char const   * __restrict  __fmt  , ...) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __vasprintf_chk)(char ** __restrict  __ptr , int __flag ,
                            char const   * __restrict  __fmt ,
                            __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__leaf__)) __obstack_printf_chk)(struct obstack * __restrict  __obstack ,
                                                                                           int __flag ,
                                                                                           char const   * __restrict  __format 
                                                                                           , ...) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__leaf__)) __obstack_vprintf_chk)(struct obstack * __restrict  __obstack ,
                                                                                            int __flag ,
                                                                                            char const   * __restrict  __format ,
                                                                                            __gnuc_va_list __args ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) asprintf)(char ** __restrict  __ptr ,
                              char const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) asprintf)(char ** __restrict  __ptr ,
                              char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __asprintf_chk(__ptr, 1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) __asprintf)(char ** __restrict  __ptr ,
                                char const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) __asprintf)(char ** __restrict  __ptr ,
                                char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __asprintf_chk(__ptr, 1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) obstack_printf)(struct obstack * __restrict  __obstack ,
                                    char const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) obstack_printf)(struct obstack * __restrict  __obstack ,
                                    char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __obstack_printf_chk(__obstack, 1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) vasprintf)(char ** __restrict  __ptr ,
                               char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) vasprintf)(char ** __restrict  __ptr ,
                               char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __vasprintf_chk(__ptr, 1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) obstack_vprintf)(struct obstack * __restrict  __obstack ,
                                     char const   * __restrict  __fmt ,
                                     __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) obstack_vprintf)(struct obstack * __restrict  __obstack ,
                                     char const   * __restrict  __fmt ,
                                     __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __obstack_vprintf_chk(__obstack, 1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
extern char *( __attribute__((__warn_unused_result__)) __fgets_chk)(char * __restrict  __s ,
                                                                    size_t __size ,
                                                                    int __n ,
                                                                    FILE * __restrict  __stream ) ;
extern char *( __attribute__((__warn_unused_result__)) __fgets_alias)(char * __restrict  __s ,
                                                                      int __n ,
                                                                      FILE * __restrict  __stream )  __asm__("fgets")  ;
extern char *( __attribute__((__warn_unused_result__)) __fgets_chk_warn)(char * __restrict  __s ,
                                                                         size_t __size ,
                                                                         int __n ,
                                                                         FILE * __restrict  __stream )  __asm__("__fgets_chk") __attribute__((__warning__("fgets called with bigger size than length of destination buffer"))) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) fgets)(char * __restrict  __s , int __n ,
                                           FILE * __restrict  __stream ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  char *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__s, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s, 1);
    tmp___0 = __fgets_chk(__s, tmp, __n, __stream);
    return ((char __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__s, 1);
    if ((size_t )__n > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__s, 1);
      tmp___2 = __fgets_chk_warn(__s, tmp___1, __n, __stream);
      return ((char __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __fgets_alias(__s, __n, __stream);
  return ((char __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern size_t ( __attribute__((__warn_unused_result__)) __fread_chk)(void * __restrict  __ptr ,
                                                                     size_t __ptrlen ,
                                                                     size_t __size ,
                                                                     size_t __n ,
                                                                     FILE * __restrict  __stream ) ;
extern size_t ( __attribute__((__warn_unused_result__)) __fread_alias)(void * __restrict  __ptr ,
                                                                       size_t __size ,
                                                                       size_t __n ,
                                                                       FILE * __restrict  __stream )  __asm__("fread")  ;
extern size_t ( __attribute__((__warn_unused_result__)) __fread_chk_warn)(void * __restrict  __ptr ,
                                                                          size_t __ptrlen ,
                                                                          size_t __size ,
                                                                          size_t __n ,
                                                                          FILE * __restrict  __stream )  __asm__("__fread_chk") __attribute__((__warning__("fread called with bigger size * nmemb than length of destination buffer"))) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) fread)(void * __restrict  __ptr ,
                                           size_t __size , size_t __n ,
                                           FILE * __restrict  __stream ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__ptr, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__ptr, 0);
    tmp___0 = __fread_chk(__ptr, tmp, __size, __n, __stream);
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__ptr, 0);
    if (__size * __n > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__ptr, 0);
      tmp___2 = __fread_chk_warn(__ptr, tmp___1, __size, __n, __stream);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __fread_alias(__ptr, __size, __n, __stream);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern char *( __attribute__((__warn_unused_result__)) __fgets_unlocked_chk)(char * __restrict  __s ,
                                                                             size_t __size ,
                                                                             int __n ,
                                                                             FILE * __restrict  __stream ) ;
extern char *( __attribute__((__warn_unused_result__)) __fgets_unlocked_alias)(char * __restrict  __s ,
                                                                               int __n ,
                                                                               FILE * __restrict  __stream )  __asm__("fgets_unlocked")  ;
extern char *( __attribute__((__warn_unused_result__)) __fgets_unlocked_chk_warn)(char * __restrict  __s ,
                                                                                  size_t __size ,
                                                                                  int __n ,
                                                                                  FILE * __restrict  __stream )  __asm__("__fgets_unlocked_chk") __attribute__((__warning__("fgets_unlocked called with bigger size than length of destination buffer"))) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fgets_unlocked)(char * __restrict  __s ,
                                    int __n , FILE * __restrict  __stream ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  char *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__s, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s, 1);
    tmp___0 = __fgets_unlocked_chk(__s, tmp, __n, __stream);
    return ((char __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__s, 1);
    if ((size_t )__n > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__s, 1);
      tmp___2 = __fgets_unlocked_chk_warn(__s, tmp___1, __n, __stream);
      return ((char __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __fgets_unlocked_alias(__s, __n, __stream);
  return ((char __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern size_t ( __attribute__((__warn_unused_result__)) __fread_unlocked_chk)(void * __restrict  __ptr ,
                                                                              size_t __ptrlen ,
                                                                              size_t __size ,
                                                                              size_t __n ,
                                                                              FILE * __restrict  __stream ) ;
extern size_t ( __attribute__((__warn_unused_result__)) __fread_unlocked_alias)(void * __restrict  __ptr ,
                                                                                size_t __size ,
                                                                                size_t __n ,
                                                                                FILE * __restrict  __stream )  __asm__("fread_unlocked")  ;
extern size_t ( __attribute__((__warn_unused_result__)) __fread_unlocked_chk_warn)(void * __restrict  __ptr ,
                                                                                   size_t __ptrlen ,
                                                                                   size_t __size ,
                                                                                   size_t __n ,
                                                                                   FILE * __restrict  __stream )  __asm__("__fread_unlocked_chk") __attribute__((__warning__("fread_unlocked called with bigger size * nmemb than length of destination buffer"))) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fread_unlocked)(void * __restrict  __ptr ,
                                    size_t __size , size_t __n ,
                                    FILE * __restrict  __stream ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___11 ;

  {
  tmp___4 = __builtin_object_size((void *)__ptr, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__ptr, 0);
    tmp___0 = __fread_unlocked_chk(__ptr, tmp, __size, __n, __stream);
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__ptr, 0);
    if (__size * __n > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__ptr, 0);
      tmp___2 = __fread_unlocked_chk_warn(__ptr, tmp___1, __size, __n, __stream);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___11 = __fread_unlocked_alias(__ptr, __size, __n, __stream);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___11);
}
}
extern void __attribute__((__visibility__("default")))  *_emalloc(size_t size )  __attribute__((__malloc__)) ;
extern void __attribute__((__visibility__("default")))  _efree(void *ptr ) ;
extern char __attribute__((__visibility__("default")))  *_estrndup(char const   *s ,
                                                                   unsigned int length )  __attribute__((__malloc__)) ;
extern int __attribute__((__visibility__("default")))  _zend_hash_init(HashTable *ht ,
                                                                       uint nSize ,
                                                                       ulong (*pHashFunction)(char const   *arKey ,
                                                                                              uint nKeyLength ) ,
                                                                       void (*pDestructor)(void *pDest ) ,
                                                                       zend_bool persistent ) ;
extern int __attribute__((__visibility__("default")))  _zend_hash_quick_add_or_update(HashTable *ht ,
                                                                                      char const   *arKey ,
                                                                                      uint nKeyLength ,
                                                                                      ulong h ,
                                                                                      void *pData ,
                                                                                      uint nDataSize ,
                                                                                      void **pDest ,
                                                                                      int flag ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_del_key_or_index(HashTable *ht ,
                                                                                  char const   *arKey ,
                                                                                  uint nKeyLength ,
                                                                                  ulong h ,
                                                                                  int flag ) ;
extern ulong __attribute__((__visibility__("default")))  zend_get_hash_value(char const   *arKey ,
                                                                             uint nKeyLength ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_find(HashTable const   *ht ,
                                                                      char const   *arKey ,
                                                                      uint nKeyLength ,
                                                                      void **pData ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_quick_find(HashTable const   *ht ,
                                                                            char const   *arKey ,
                                                                            uint nKeyLength ,
                                                                            ulong h ,
                                                                            void **pData ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_move_forward_ex(HashTable *ht ,
                                                                                 HashPosition *pos ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_get_current_data_ex(HashTable *ht ,
                                                                                     void **pData ,
                                                                                     HashPosition *pos ) ;
extern void __attribute__((__visibility__("default")))  zend_hash_internal_pointer_reset_ex(HashTable *ht ,
                                                                                            HashPosition *pos ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_num_elements(HashTable const   *ht ) ;
extern ulong __attribute__((__visibility__("default")))  zend_hash_func(char const   *arKey ,
                                                                        uint nKeyLength ) ;
extern  __attribute__((__noreturn__)) void zend_error_noreturn(int type ,
                                                               char const   *format 
                                                               , ...) ;
struct _zend_object_handlers  __attribute__((__visibility__("default"))) std_object_handlers ;
union _zend_function  __attribute__((__visibility__("default"))) *zend_std_get_static_method(zend_class_entry *ce ,
                                                                                             char *function_name_strval ,
                                                                                             int function_name_strlen ,
                                                                                             struct _zend_literal  const  *key ) ;
zval __attribute__((__visibility__("default")))  **zend_std_get_static_property(zend_class_entry *ce ,
                                                                                char *property_name ,
                                                                                int property_name_len ,
                                                                                zend_bool silent ,
                                                                                struct _zend_literal  const  *key ) ;
zend_bool __attribute__((__visibility__("default")))  zend_std_unset_static_property(zend_class_entry *ce ,
                                                                                     char *property_name ,
                                                                                     int property_name_len ,
                                                                                     struct _zend_literal  const  *key ) ;
union _zend_function  __attribute__((__visibility__("default"))) *zend_std_get_constructor(zval *object ) ;
struct _zend_property_info  __attribute__((__visibility__("default"))) *zend_get_property_info(zend_class_entry *ce ,
                                                                                               zval *member ,
                                                                                               int silent ) ;
HashTable __attribute__((__visibility__("default")))  *zend_std_get_properties(zval *object ) ;
HashTable __attribute__((__visibility__("default")))  *zend_std_get_debug_info(zval *object ,
                                                                               int *is_temp ) ;
int __attribute__((__visibility__("default")))  zend_std_cast_object_tostring(zval *readobj ,
                                                                              zval *writeobj ,
                                                                              int type ) ;
void __attribute__((__visibility__("default")))  zend_std_write_property(zval *object ,
                                                                         zval *member ,
                                                                         zval *value ,
                                                                         struct _zend_literal  const  *key ) ;
void __attribute__((__visibility__("default")))  rebuild_object_properties(zend_object *zobj ) ;
int __attribute__((__visibility__("default")))  zend_check_private(union _zend_function *fbc ,
                                                                   zend_class_entry *ce ,
                                                                   char *function_name_strval ,
                                                                   int function_name_strlen ) ;
int __attribute__((__visibility__("default")))  zend_check_protected(zend_class_entry *ce ,
                                                                     zend_class_entry *scope ) ;
int __attribute__((__visibility__("default")))  zend_check_property_access(zend_object *zobj ,
                                                                           char *prop_info_name ,
                                                                           int prop_info_name_len ) ;
void __attribute__((__visibility__("default")))  zend_std_call_user_call(int ht ,
                                                                         zval *return_value ,
                                                                         zval **return_value_ptr ,
                                                                         zval *this_ptr ,
                                                                         int return_value_used ) ;
__inline static zend_uint ( __attribute__((__always_inline__)) zval_refcount_p)(zval *pz ) 
{ 


  {
  return (pz->refcount__gc);
}
}
__inline static zend_uint ( __attribute__((__always_inline__)) zval_set_refcount_p)(zval *pz ,
                                                                                    zend_uint rc ) 
{ 
  zend_uint tmp ;

  {
  tmp = rc;
  pz->refcount__gc = tmp;
  return (tmp);
}
}
__inline static zend_uint ( __attribute__((__always_inline__)) zval_addref_p)(zval *pz ) 
{ 


  {
  (pz->refcount__gc) ++;
  return (pz->refcount__gc);
}
}
__inline static zend_uint ( __attribute__((__always_inline__)) zval_delref_p)(zval *pz ) 
{ 


  {
  (pz->refcount__gc) --;
  return (pz->refcount__gc);
}
}
__inline static zend_bool ( __attribute__((__always_inline__)) zval_isref_p)(zval *pz ) 
{ 


  {
  return (pz->is_ref__gc);
}
}
__inline static zend_bool ( __attribute__((__always_inline__)) zval_unset_isref_p)(zval *pz ) 
{ 
  zend_uchar tmp ;

  {
  tmp = (zend_uchar )0;
  pz->is_ref__gc = tmp;
  return (tmp);
}
}
__inline static zend_bool ( __attribute__((__always_inline__)) zval_set_isref_to_p)(zval *pz ,
                                                                                    zend_bool isref ) 
{ 
  zend_uchar tmp ;

  {
  tmp = isref;
  pz->is_ref__gc = tmp;
  return (tmp);
}
}
extern void __attribute__((__visibility__("default")))  zend_error(int type ,
                                                                   char const   *format 
                                                                   , ...) ;
extern zval __attribute__((__visibility__("default")))  zval_used_for_init ;
extern  __attribute__((__nothrow__,
__noreturn__)) void ( __attribute__((__leaf__)) __assert_fail)(char const   *__assertion ,
                                                               char const   *__file ,
                                                               unsigned int __line ,
                                                               char const   *__function ) ;
extern zend_bool __attribute__((__visibility__("default")))  instanceof_function_ex(zend_class_entry const   *instance_ce ,
                                                                                    zend_class_entry const   *ce ,
                                                                                    zend_bool interfaces_only ) ;
extern zend_bool __attribute__((__visibility__("default")))  instanceof_function(zend_class_entry const   *instance_ce ,
                                                                                 zend_class_entry const   *ce ) ;
extern void __attribute__((__visibility__("default")))  _convert_to_string(zval *op ) ;
extern void __attribute__((__visibility__("default")))  convert_to_long(zval *op ) ;
extern void __attribute__((__visibility__("default")))  convert_to_double(zval *op ) ;
extern void __attribute__((__visibility__("default")))  convert_to_null(zval *op ) ;
extern void __attribute__((__visibility__("default")))  convert_to_boolean(zval *op ) ;
extern void __attribute__((__visibility__("default")))  convert_to_array(zval *op ) ;
extern void __attribute__((__visibility__("default")))  convert_to_object(zval *op ) ;
extern int __attribute__((__visibility__("default")))  compare_function(zval *result ,
                                                                        zval *op1 ,
                                                                        zval *op2 ) ;
extern char __attribute__((__visibility__("default")))  *zend_str_tolower_copy(char *dest ,
                                                                               char const   *source ,
                                                                               unsigned int length ) ;
extern char __attribute__((__visibility__("default")))  *zend_str_tolower_dup(char const   *source ,
                                                                              unsigned int length ) ;
extern void __attribute__((__visibility__("default")))  _zval_dtor_func(zval *zvalue ) ;
__inline static void ( __attribute__((__always_inline__)) _zval_dtor)(zval *zvalue ) 
{ 


  {
  if ((int )zvalue->type <= 3) {
    return;
  } else {

  }
  _zval_dtor_func(zvalue);
  return;
}
}
extern void __attribute__((__visibility__("default")))  _zval_copy_ctor_func(zval *zvalue ) ;
__inline static void ( __attribute__((__always_inline__)) _zval_copy_ctor)(zval *zvalue ) 
{ 


  {
  if ((int )zvalue->type <= 3) {
    return;
  } else {

  }
  _zval_copy_ctor_func(zvalue);
  return;
}
}
extern void __attribute__((__visibility__("default")))  _zval_ptr_dtor(zval **zval_ptr ) ;
extern zend_executor_globals __attribute__((__visibility__("default")))  executor_globals ;
extern zend_object_value __attribute__((__visibility__("default")))  zend_objects_clone_obj(zval *object ) ;
extern void __attribute__((__visibility__("default")))  zend_objects_store_add_ref(zval *object ) ;
extern void __attribute__((__visibility__("default")))  zend_objects_store_del_ref(zval *object ) ;
extern char *zend_visibility_string(zend_uint fn_flags ) ;
extern int __attribute__((__visibility__("default")))  zend_unmangle_property_name(char *mangled_property ,
                                                                                   int mangled_property_len ,
                                                                                   char **class_name ,
                                                                                   char **prop_name ) ;
extern int __attribute__((__visibility__("default")))  zend_is_true(zval *op ) ;
__inline static int ( __attribute__((__always_inline__)) i_zend_is_true)(zval *op ) 
{ 
  int result ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval tmp___1 ;
  int tmp___2 ;
  zval *tmp___3 ;
  zval *tmp___4 ;

  {
  switch ((int )op->type) {
  case 0: 
  result = 0;
  break;
  case 1: 
  case 3: 
  case 7: 
  if (op->value.lval) {
    result = 1;
  } else {
    result = 0;
  }
  break;
  case 2: 
  if (op->value.dval) {
    result = 1;
  } else {
    result = 0;
  }
  break;
  case 6: 
  if (op->value.str.len == 0) {
    result = 0;
  } else
  if (op->value.str.len == 1) {
    if ((int )*(op->value.str.val + 0) == 48) {
      result = 0;
    } else {
      result = 1;
    }
  } else {
    result = 1;
  }
  break;
  case 4: 
  tmp___0 = zend_hash_num_elements((HashTable const   *)op->value.ht);
  if (tmp___0) {
    result = 1;
  } else {
    result = 0;
  }
  break;
  case 5: 
  if ((int )op->type == 5) {
    if ((unsigned long )(op->value.obj.handlers)->get_class_entry != (unsigned long )((void *)0)) {
      if ((op->value.obj.handlers)->cast_object) {
        tmp___2 = (*((op->value.obj.handlers)->cast_object))(op, & tmp___1, 3);
        if (tmp___2 == 0) {
          result = (int )tmp___1.value.lval;
          break;
        } else {

        }
      } else
      if ((op->value.obj.handlers)->get) {
        tmp___4 = (*((op->value.obj.handlers)->get))(op);
        tmp___3 = tmp___4;
        if ((int )tmp___3->type != 5) {
          convert_to_boolean(tmp___3);
          result = (int )tmp___3->value.lval;
          _zval_ptr_dtor(& tmp___3);
          break;
        } else {

        }
      } else {

      }
    } else {

    }
  } else {

  }
  result = 1;
  break;
  default: 
  result = 0;
  break;
  }
  return (result);
}
}
extern int __attribute__((__visibility__("default")))  zend_copy_parameters_array(int param_count ,
                                                                                  zval *argument_array ) ;
extern void __attribute__((__visibility__("default")))  zend_update_class_constants(zend_class_entry *class_type ) ;
extern zend_class_entry __attribute__((__visibility__("default")))  *zend_get_class_entry(zval const   *zobject ) ;
extern int __attribute__((__visibility__("default")))  _array_init(zval *arg ,
                                                                   uint size ) ;
extern zend_class_entry __attribute__((__visibility__("default")))  *zend_ce_arrayaccess ;
extern zval __attribute__((__visibility__("default")))  *zend_call_method(zval **object_pp ,
                                                                          zend_class_entry *obj_ce ,
                                                                          zend_function **fn_proxy ,
                                                                          char *function_name ,
                                                                          int function_name_len ,
                                                                          zval **retval_ptr_ptr ,
                                                                          int param_count ,
                                                                          zval *arg1 ,
                                                                          zval *arg2 ) ;
void __attribute__((__visibility__("default")))  rebuild_object_properties(zend_object *zobj ) 
{ 
  HashPosition pos ;
  zend_property_info *prop_info ;
  zend_class_entry *ce ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;

  {
  if (! zobj->properties) {
    ce = zobj->ce;
    tmp = _emalloc(sizeof(HashTable ));
    zobj->properties = (HashTable *)tmp;
    _zend_hash_init(zobj->properties, (uint )0,
                    (ulong (*)(char const   *arKey , uint nKeyLength ))((void *)0),
                    (void (*)(void * ))(& _zval_ptr_dtor), (zend_bool )0);
    if (ce->default_properties_count) {
      zend_hash_internal_pointer_reset_ex(& ce->properties_info, & pos);
      while (1) {
        tmp___0 = zend_hash_get_current_data_ex(& ce->properties_info,
                                                (void **)(& prop_info), & pos);
        if (! (tmp___0 == (int __attribute__((__visibility__("default")))  )0)) {
          break;
        } else {

        }
        if ((prop_info->flags & 1U) == 0U) {
          if (prop_info->offset >= 0) {
            if (*(zobj->properties_table + prop_info->offset)) {
              _zend_hash_quick_add_or_update(zobj->properties,
                                             (char const   *)prop_info->name,
                                             (uint )(prop_info->name_length + 1),
                                             prop_info->h,
                                             (void *)((void **)(zobj->properties_table + prop_info->offset)),
                                             (uint )sizeof(zval *),
                                             (void **)(zobj->properties_table + prop_info->offset),
                                             1 << 1);
            } else {

            }
          } else {

          }
        } else {

        }
        zend_hash_move_forward_ex(& ce->properties_info, & pos);
      }
      while (1) {
        if (ce->parent) {
          if (! (ce->parent)->default_properties_count) {
            break;
          } else {

          }
        } else {
          break;
        }
        ce = ce->parent;
        zend_hash_internal_pointer_reset_ex(& ce->properties_info, & pos);
        while (1) {
          tmp___1 = zend_hash_get_current_data_ex(& ce->properties_info,
                                                  (void **)(& prop_info), & pos);
          if (! (tmp___1 == (int __attribute__((__visibility__("default")))  )0)) {
            break;
          } else {

          }
          if ((unsigned long )prop_info->ce == (unsigned long )ce) {
            if ((prop_info->flags & 1U) == 0U) {
              if ((prop_info->flags & 1024U) != 0U) {
                if (prop_info->offset >= 0) {
                  if (*(zobj->properties_table + prop_info->offset)) {
                    _zend_hash_quick_add_or_update(zobj->properties,
                                                   (char const   *)prop_info->name,
                                                   (uint )(prop_info->name_length + 1),
                                                   prop_info->h,
                                                   (void *)((void **)(zobj->properties_table + prop_info->offset)),
                                                   (uint )sizeof(zval *),
                                                   (void **)(zobj->properties_table + prop_info->offset),
                                                   1 << 1);
                  } else {

                  }
                } else {

                }
              } else {

              }
            } else {

            }
          } else {

          }
          zend_hash_move_forward_ex(& ce->properties_info, & pos);
        }
      }
    } else {

    }
  } else {

  }
  return;
}
}
HashTable __attribute__((__visibility__("default")))  *zend_std_get_properties(zval *object ) 
{ 
  zend_object *zobj ;

  {
  zobj = (zend_object *)(executor_globals.objects_store.object_buckets + object->value.obj.handle)->bucket.obj.object;
  if (! zobj->properties) {
    rebuild_object_properties(zobj);
  } else {

  }
  return ((HashTable __attribute__((__visibility__("default")))  *)zobj->properties);
}
}
HashTable __attribute__((__visibility__("default")))  *zend_std_get_debug_info(zval *object ,
                                                                               int *is_temp ) 
{ 
  HashTable __attribute__((__visibility__("default")))  *tmp ;

  {
  *is_temp = 0;
  tmp = zend_std_get_properties(object);
  return (tmp);
}
}
static zval *zend_std_call_getter(zval *object , zval *member ) 
{ 
  zval *retval ;
  zend_class_entry *ce ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp ;
  zval *original_var ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  zend_bool tmp___1 ;

  {
  retval = (zval *)((void *)0);
  tmp = zend_get_class_entry((zval const   *)object);
  ce = (zend_class_entry *)tmp;
  tmp___1 = zval_isref_p(member);
  if (tmp___1) {
    original_var = member;
    while (1) {
      tmp___0 = _emalloc(sizeof(zval_gc_info ));
      member = (zval *)tmp___0;
      ((zval_gc_info *)member)->u.buffered = (gc_root_buffer *)((void *)0);
      break;
    }
    while (1) {
      while (1) {
        member->value = original_var->value;
        member->type = original_var->type;
        break;
      }
      zval_set_refcount_p(member, (zend_uint )1);
      zval_unset_isref_p(member);
      break;
    }
    _zval_copy_ctor(member);
  } else {
    zval_addref_p(member);
  }
  zend_call_method(& object, ce, & ce->__get, (char *)"__get",
                   (int )(sizeof("__get") - 1UL), & retval, 1, member,
                   (zval *)((void *)0));
  _zval_ptr_dtor(& member);
  if (retval) {
    zval_delref_p(retval);
  } else {

  }
  return (retval);
}
}
static int zend_std_call_setter(zval *object , zval *member , zval *value ) 
{ 
  zval *retval ;
  int result ;
  zend_class_entry *ce ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp ;
  zval *original_var ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  zend_bool tmp___1 ;
  int tmp___3 ;

  {
  retval = (zval *)((void *)0);
  tmp = zend_get_class_entry((zval const   *)object);
  ce = (zend_class_entry *)tmp;
  tmp___1 = zval_isref_p(member);
  if (tmp___1) {
    original_var = member;
    while (1) {
      tmp___0 = _emalloc(sizeof(zval_gc_info ));
      member = (zval *)tmp___0;
      ((zval_gc_info *)member)->u.buffered = (gc_root_buffer *)((void *)0);
      break;
    }
    while (1) {
      while (1) {
        member->value = original_var->value;
        member->type = original_var->type;
        break;
      }
      zval_set_refcount_p(member, (zend_uint )1);
      zval_unset_isref_p(member);
      break;
    }
    _zval_copy_ctor(member);
  } else {
    zval_addref_p(member);
  }
  zval_addref_p(value);
  zend_call_method(& object, ce, & ce->__set, (char *)"__set",
                   (int )(sizeof("__set") - 1UL), & retval, 2, member, value);
  _zval_ptr_dtor(& member);
  _zval_ptr_dtor(& value);
  if (retval) {
    tmp___3 = i_zend_is_true(retval);
    if (tmp___3) {
      result = 0;
    } else {
      result = -1;
    }
    _zval_ptr_dtor(& retval);
    return (result);
  } else {
    return (-1);
  }
}
}
static void zend_std_call_unsetter(zval *object , zval *member ) 
{ 
  zend_class_entry *ce ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp ;
  zval *original_var ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  zend_bool tmp___1 ;

  {
  tmp = zend_get_class_entry((zval const   *)object);
  ce = (zend_class_entry *)tmp;
  tmp___1 = zval_isref_p(member);
  if (tmp___1) {
    original_var = member;
    while (1) {
      tmp___0 = _emalloc(sizeof(zval_gc_info ));
      member = (zval *)tmp___0;
      ((zval_gc_info *)member)->u.buffered = (gc_root_buffer *)((void *)0);
      break;
    }
    while (1) {
      while (1) {
        member->value = original_var->value;
        member->type = original_var->type;
        break;
      }
      zval_set_refcount_p(member, (zend_uint )1);
      zval_unset_isref_p(member);
      break;
    }
    _zval_copy_ctor(member);
  } else {
    zval_addref_p(member);
  }
  zend_call_method(& object, ce, & ce->__unset, (char *)"__unset",
                   (int )(sizeof("__unset") - 1UL), (zval **)((void *)0), 1,
                   member, (zval *)((void *)0));
  _zval_ptr_dtor(& member);
  return;
}
}
static zval *zend_std_call_issetter(zval *object , zval *member ) 
{ 
  zval *retval ;
  zend_class_entry *ce ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp ;
  zval *original_var ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  zend_bool tmp___1 ;

  {
  retval = (zval *)((void *)0);
  tmp = zend_get_class_entry((zval const   *)object);
  ce = (zend_class_entry *)tmp;
  tmp___1 = zval_isref_p(member);
  if (tmp___1) {
    original_var = member;
    while (1) {
      tmp___0 = _emalloc(sizeof(zval_gc_info ));
      member = (zval *)tmp___0;
      ((zval_gc_info *)member)->u.buffered = (gc_root_buffer *)((void *)0);
      break;
    }
    while (1) {
      while (1) {
        member->value = original_var->value;
        member->type = original_var->type;
        break;
      }
      zval_set_refcount_p(member, (zend_uint )1);
      zval_unset_isref_p(member);
      break;
    }
    _zval_copy_ctor(member);
  } else {
    zval_addref_p(member);
  }
  zend_call_method(& object, ce, & ce->__isset, (char *)"__isset",
                   (int )(sizeof("__isset") - 1UL), & retval, 1, member,
                   (zval *)((void *)0));
  _zval_ptr_dtor(& member);
  return (retval);
}
}
__inline static int ( __attribute__((__always_inline__)) zend_verify_property_access)(zend_property_info *property_info ,
                                                                                      zend_class_entry *ce ) 
{ 
  int __attribute__((__visibility__("default")))  tmp ;

  {
  switch (property_info->flags & 1792U) {
  case 256U: 
  return (1);
  case 512U: 
  tmp = zend_check_protected(property_info->ce, executor_globals.scope);
  return ((int )tmp);
  case 1024U: 
  if ((unsigned long )ce == (unsigned long )executor_globals.scope) {
    goto _L;
  } else
  if ((unsigned long )property_info->ce == (unsigned long )executor_globals.scope) {
    _L: 
    if (executor_globals.scope) {
      return (1);
    } else {
      return (0);
    }
  } else {
    return (0);
  }
  break;
  }
  return (0);
}
}
__inline static zend_bool ( __attribute__((__always_inline__)) is_derived_class)(zend_class_entry *child_class ,
                                                                                 zend_class_entry *parent_class ) 
{ 


  {
  child_class = child_class->parent;
  while (child_class) {
    if ((unsigned long )child_class == (unsigned long )parent_class) {
      return ((zend_bool )1);
    } else {

    }
    child_class = child_class->parent;
  }
  return ((zend_bool )0);
}
}
__inline static struct _zend_property_info *( __attribute__((__always_inline__)) zend_get_property_info_quick)(zend_class_entry *ce ,
                                                                                                               zval *member ,
                                                                                                               int silent ,
                                                                                                               zend_literal const   *key ) 
{ 
  zend_property_info *property_info ;
  zend_property_info *scope_property_info ;
  zend_bool denied_access ;
  ulong h ;
  long tmp ;
  ulong __attribute__((__visibility__("default")))  tmp___0 ;
  long tmp___1 ;
  long tmp___2 ;
  long tmp___3 ;
  int tmp___4 ;
  long tmp___5 ;
  long tmp___6 ;
  int __attribute__((__visibility__("default")))  tmp___7 ;
  char *tmp___8 ;
  long tmp___9 ;
  zend_bool tmp___10 ;
  int __attribute__((__visibility__("default")))  tmp___11 ;

  {
  denied_access = (zend_bool )0;
  if (key) {
    if ((unsigned long )*((executor_globals.active_op_array)->run_time_cache + key->cache_slot) == (unsigned long )ce) {
      property_info = (zend_property_info *)*((executor_globals.active_op_array)->run_time_cache + (key->cache_slot + 1U));
    } else {
      property_info = (zend_property_info *)((void *)0);
    }
    if ((unsigned long )property_info != (unsigned long )((void *)0)) {
      return (property_info);
    } else {

    }
  } else {

  }
  tmp = __builtin_expect((long )((int )*(member->value.str.val + 0) == 0), 0L);
  if (tmp) {
    if (! silent) {
      if (member->value.str.len == 0) {
        zend_error_noreturn(1, "Cannot access empty property");
      } else {
        zend_error_noreturn(1, "Cannot access property started with \'\\0\'");
      }
    } else {

    }
    return ((struct _zend_property_info *)((void *)0));
  } else {

  }
  property_info = (zend_property_info *)((void *)0);
  if (key) {
    h = (ulong )key->hash_value;
  } else {
    tmp___0 = zend_get_hash_value((char const   *)member->value.str.val,
                                  (uint )(member->value.str.len + 1));
    h = (ulong )tmp___0;
  }
  tmp___7 = zend_hash_quick_find((HashTable const   *)(& ce->properties_info),
                                 (char const   *)member->value.str.val,
                                 (uint )(member->value.str.len + 1), h,
                                 (void **)(& property_info));
  if (tmp___7 == (int __attribute__((__visibility__("default")))  )0) {
    tmp___6 = __builtin_expect((long )((property_info->flags & 131072U) != 0U),
                               0L);
    if (tmp___6) {
      property_info = (zend_property_info *)((void *)0);
    } else {
      tmp___4 = zend_verify_property_access(property_info, ce);
      tmp___5 = __builtin_expect((long )(tmp___4 != 0), 1L);
      if (tmp___5) {
        tmp___2 = __builtin_expect((long )((property_info->flags & 2048U) != 0U),
                                   1L);
        if (tmp___2) {
          tmp___3 = __builtin_expect((long )(! (property_info->flags & 1024U)),
                                     1L);
          if (! tmp___3) {
            goto _L;
          } else {

          }
        } else {
          _L: 
          tmp___1 = __builtin_expect((long )((property_info->flags & 1U) != 0U),
                                     0L);
          if (tmp___1) {
            if (! silent) {
              zend_error(1 << 11L,
                         "Accessing static property %s::$%s as non static",
                         ce->name, member->value.str.val);
            } else {

            }
          } else {

          }
          if (key) {
            while (1) {
              *((executor_globals.active_op_array)->run_time_cache + key->cache_slot) = (void *)ce;
              *((executor_globals.active_op_array)->run_time_cache + (key->cache_slot + 1U)) = (void *)property_info;
              break;
            }
          } else {

          }
          return (property_info);
        }
      } else {
        denied_access = (zend_bool )1;
      }
    }
  } else {

  }
  if ((unsigned long )executor_globals.scope != (unsigned long )ce) {
    if (executor_globals.scope) {
      tmp___10 = is_derived_class(ce, executor_globals.scope);
      if (tmp___10) {
        tmp___11 = zend_hash_quick_find((HashTable const   *)(& (executor_globals.scope)->properties_info),
                                        (char const   *)member->value.str.val,
                                        (uint )(member->value.str.len + 1), h,
                                        (void **)(& scope_property_info));
        if (tmp___11 == (int __attribute__((__visibility__("default")))  )0) {
          if (scope_property_info->flags & 1024U) {
            if (key) {
              while (1) {
                *((executor_globals.active_op_array)->run_time_cache + key->cache_slot) = (void *)ce;
                *((executor_globals.active_op_array)->run_time_cache + (key->cache_slot + 1U)) = (void *)scope_property_info;
                break;
              }
            } else {

            }
            return (scope_property_info);
          } else {
            goto _L___3;
          }
        } else {
          goto _L___3;
        }
      } else {
        goto _L___3;
      }
    } else {
      goto _L___3;
    }
  } else
  _L___3: 
  if (property_info) {
    tmp___9 = __builtin_expect((long )((int )denied_access != 0), 0L);
    if (tmp___9) {
      if (! silent) {
        tmp___8 = zend_visibility_string(property_info->flags);
        zend_error_noreturn(1, "Cannot access %s property %s::$%s", tmp___8,
                            ce->name, member->value.str.val);
      } else {

      }
      return ((struct _zend_property_info *)((void *)0));
    } else
    if (key) {
      while (1) {
        *((executor_globals.active_op_array)->run_time_cache + key->cache_slot) = (void *)ce;
        *((executor_globals.active_op_array)->run_time_cache + (key->cache_slot + 1U)) = (void *)property_info;
        break;
      }
    } else {

    }
  } else {
    executor_globals.std_property_info.flags = (zend_uint )256;
    executor_globals.std_property_info.name = member->value.str.val;
    executor_globals.std_property_info.name_length = member->value.str.len;
    executor_globals.std_property_info.h = h;
    executor_globals.std_property_info.ce = ce;
    executor_globals.std_property_info.offset = -1;
    property_info = & executor_globals.std_property_info;
  }
  return (property_info);
}
}
struct _zend_property_info  __attribute__((__visibility__("default"))) *zend_get_property_info(zend_class_entry *ce ,
                                                                                               zval *member ,
                                                                                               int silent ) 
{ 
  struct _zend_property_info *tmp ;

  {
  tmp = zend_get_property_info_quick(ce, member, silent,
                                     (zend_literal const   *)((void *)0));
  return ((struct _zend_property_info  __attribute__((__visibility__("default"))) *)tmp);
}
}
int __attribute__((__visibility__("default")))  zend_check_property_access(zend_object *zobj ,
                                                                           char *prop_info_name ,
                                                                           int prop_info_name_len ) 
{ 
  zend_property_info *property_info ;
  char *class_name ;
  char *prop_name ;
  zval member ;
  char const   *__s ;
  zval *__z ;
  size_t tmp ;
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp___2 ;
  int tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;
  int tmp___9 ;
  int tmp___10 ;

  {
  zend_unmangle_property_name(prop_info_name, prop_info_name_len, & class_name,
                              & prop_name);
  while (1) {
    __s = (char const   *)prop_name;
    __z = & member;
    tmp = strlen(__s);
    __z->value.str.len = (int )tmp;
    __z->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z->type = (zend_uchar )6;
    break;
  }
  property_info = zend_get_property_info_quick(zobj->ce, & member, 1,
                                               (zend_literal const   *)((void *)0));
  if (! property_info) {
    return ((int __attribute__((__visibility__("default")))  )-1);
  } else {

  }
  if (class_name) {
    if ((int )*(class_name + 0) != 42) {
      if (! (property_info->flags & 1024U)) {
        return ((int __attribute__((__visibility__("default")))  )-1);
      } else {
        if (0) {
          __s1_len = __builtin_strlen((char const   *)(prop_info_name + 1));
          __s2_len = __builtin_strlen((char const   *)(property_info->name + 1));
          if (! ((size_t )((void const   *)((prop_info_name + 1) + 1)) - (size_t )((void const   *)(prop_info_name + 1)) == 1UL)) {
            goto _L___0;
          } else
          if (__s1_len >= 4UL) {
            _L___0: 
            if (! ((size_t )((void const   *)((property_info->name + 1) + 1)) - (size_t )((void const   *)(property_info->name + 1)) == 1UL)) {
              tmp___7 = 1;
            } else
            if (__s2_len >= 4UL) {
              tmp___7 = 1;
            } else {
              tmp___7 = 0;
            }
          } else {
            tmp___7 = 0;
          }
          if (tmp___7) {
            tmp___2 = __builtin_strcmp((char const   *)(prop_info_name + 1),
                                       (char const   *)(property_info->name + 1));
            tmp___6 = tmp___2;
          } else {
            tmp___5 = __builtin_strcmp((char const   *)(prop_info_name + 1),
                                       (char const   *)(property_info->name + 1));
            tmp___6 = tmp___5;
          }
        } else {
          tmp___5 = __builtin_strcmp((char const   *)(prop_info_name + 1),
                                     (char const   *)(property_info->name + 1));
          tmp___6 = tmp___5;
        }
        if (tmp___6) {
          return ((int __attribute__((__visibility__("default")))  )-1);
        } else {

        }
      }
    } else {

    }
  } else {

  }
  tmp___10 = zend_verify_property_access(property_info, zobj->ce);
  if (tmp___10) {
    tmp___9 = 0;
  } else {
    tmp___9 = -1;
  }
  return ((int __attribute__((__visibility__("default")))  )tmp___9);
}
}
static int zend_get_property_guard(zend_object *zobj ,
                                   zend_property_info *property_info ,
                                   zval *member , zend_guard **pguard ) 
{ 
  zend_property_info info ;
  zend_guard stub ;
  ulong __attribute__((__visibility__("default")))  tmp ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;
  int __attribute__((__visibility__("default")))  tmp___2 ;

  {
  if (! property_info) {
    property_info = & info;
    info.name = member->value.str.val;
    info.name_length = member->value.str.len;
    tmp = zend_get_hash_value((char const   *)member->value.str.val,
                              (uint )(member->value.str.len + 1));
    info.h = (ulong )tmp;
  } else {

  }
  if (! zobj->guards) {
    tmp___0 = _emalloc(sizeof(HashTable ));
    zobj->guards = (HashTable *)tmp___0;
    _zend_hash_init(zobj->guards, (uint )0,
                    (ulong (*)(char const   *arKey , uint nKeyLength ))((void *)0),
                    (void (*)(void *pDest ))((void *)0), (zend_bool )0);
  } else {
    tmp___1 = zend_hash_quick_find((HashTable const   *)zobj->guards,
                                   (char const   *)property_info->name,
                                   (uint )(property_info->name_length + 1),
                                   property_info->h, (void **)pguard);
    if (tmp___1 == (int __attribute__((__visibility__("default")))  )0) {
      return (0);
    } else {

    }
  }
  stub.in_get = (zend_bool )0;
  stub.in_set = (zend_bool )0;
  stub.in_unset = (zend_bool )0;
  stub.in_isset = (zend_bool )0;
  tmp___2 = _zend_hash_quick_add_or_update(zobj->guards,
                                           (char const   *)property_info->name,
                                           (uint )(property_info->name_length + 1),
                                           property_info->h,
                                           (void *)((void **)(& stub)),
                                           (uint )sizeof(stub), (void **)pguard,
                                           1 << 1);
  return ((int )tmp___2);
}
}
zval *zend_std_read_property(zval *object , zval *member , int type ,
                             zend_literal const   *key ) 
{ 
  zend_object *zobj ;
  zval *tmp_member ;
  zval **retval ;
  zval *rv ;
  zend_property_info *property_info ;
  int silent ;
  void __attribute__((__visibility__("default")))  *tmp ;
  long tmp___0 ;
  zend_guard *guard ;
  zval *new_zv ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  zend_uint tmp___2 ;
  zend_bool tmp___3 ;
  zval *tmp___4 ;
  void __attribute__((__visibility__("default")))  *tmp___5 ;
  zend_uint tmp___6 ;
  long tmp___7 ;
  zend_bool tmp___8 ;
  int tmp___9 ;
  long tmp___10 ;
  int tmp___12 ;
  long tmp___13 ;
  int __attribute__((__visibility__("default")))  tmp___14 ;
  long tmp___15 ;
  int tmp___16 ;
  int tmp___17 ;
  long tmp___18 ;
  long tmp___19 ;

  {
  tmp_member = (zval *)((void *)0);
  rv = (zval *)((void *)0);
  silent = type == 3;
  zobj = (zend_object *)(executor_globals.objects_store.object_buckets + object->value.obj.handle)->bucket.obj.object;
  tmp___0 = __builtin_expect((long )((int )member->type != 6), 0L);
  if (tmp___0) {
    while (1) {
      tmp = _emalloc(sizeof(zval_gc_info ));
      tmp_member = (zval *)tmp;
      ((zval_gc_info *)tmp_member)->u.buffered = (gc_root_buffer *)((void *)0);
      break;
    }
    *tmp_member = *member;
    tmp_member->refcount__gc = (zend_uint )1;
    tmp_member->is_ref__gc = (zend_uchar )0;
    _zval_copy_ctor(tmp_member);
    if ((int )tmp_member->type != 6) {
      _convert_to_string(tmp_member);
    } else {

    }
    member = tmp_member;
    key = (zend_literal const   *)((void *)0);
  } else {

  }
  property_info = zend_get_property_info_quick(zobj->ce, member,
                                               (unsigned long )(zobj->ce)->__get != (unsigned long )((void *)0),
                                               key);
  tmp___10 = __builtin_expect((long )(! property_info), 0L);
  if (tmp___10) {
    goto _L___3;
  } else {
    tmp___18 = __builtin_expect((long )((property_info->flags & 1U) == 0U), 1L);
    if (tmp___18) {
      if (property_info->offset >= 0) {
        if (zobj->properties) {
          retval = (zval **)*(zobj->properties_table + property_info->offset);
          tmp___12 = (unsigned long )retval == (unsigned long )((void *)0);
        } else {
          retval = zobj->properties_table + property_info->offset;
          tmp___12 = (unsigned long )*retval == (unsigned long )((void *)0);
        }
        tmp___17 = tmp___12;
      } else {
        goto _L___2;
      }
    } else {
      _L___2: 
      tmp___13 = __builtin_expect((long )(! zobj->properties), 0L);
      if (tmp___13) {
        tmp___16 = 1;
      } else {
        tmp___14 = zend_hash_quick_find((HashTable const   *)zobj->properties,
                                        (char const   *)property_info->name,
                                        (uint )(property_info->name_length + 1),
                                        property_info->h, (void **)(& retval));
        tmp___15 = __builtin_expect((long )(tmp___14 == (int __attribute__((__visibility__("default")))  )-1),
                                    0L);
        if (tmp___15) {
          tmp___16 = 1;
        } else {
          tmp___16 = 0;
        }
      }
      tmp___17 = tmp___16;
    }
    if (tmp___17) {
      _L___3: 
      guard = (zend_guard *)((void *)0);
      if ((zobj->ce)->__get) {
        tmp___9 = zend_get_property_guard(zobj, property_info, member, & guard);
        if (tmp___9 == 0) {
          if (! guard->in_get) {
            zval_addref_p(object);
            tmp___3 = zval_isref_p(object);
            if (tmp___3) {
              while (1) {
                tmp___2 = zval_refcount_p(object);
                if (tmp___2 > 1U) {
                  zval_delref_p(object);
                  while (1) {
                    tmp___1 = _emalloc(sizeof(zval_gc_info ));
                    new_zv = (zval *)tmp___1;
                    ((zval_gc_info *)new_zv)->u.buffered = (gc_root_buffer *)((void *)0);
                    break;
                  }
                  while (1) {
                    while (1) {
                      new_zv->value = object->value;
                      new_zv->type = object->type;
                      break;
                    }
                    zval_set_refcount_p(new_zv, (zend_uint )1);
                    zval_unset_isref_p(new_zv);
                    break;
                  }
                  object = new_zv;
                  _zval_copy_ctor(new_zv);
                } else {

                }
                break;
              }
            } else {

            }
            guard->in_get = (zend_bool )1;
            rv = zend_std_call_getter(object, member);
            guard->in_get = (zend_bool )0;
            if (rv) {
              retval = & rv;
              tmp___8 = zval_isref_p(rv);
              if (! tmp___8) {
                if (type == 1) {
                  goto _L;
                } else
                if (type == 2) {
                  goto _L;
                } else
                if (type == 6) {
                  _L: 
                  tmp___6 = zval_refcount_p(rv);
                  if (tmp___6 > 0U) {
                    tmp___4 = rv;
                    while (1) {
                      tmp___5 = _emalloc(sizeof(zval_gc_info ));
                      rv = (zval *)tmp___5;
                      ((zval_gc_info *)rv)->u.buffered = (gc_root_buffer *)((void *)0);
                      break;
                    }
                    *rv = *tmp___4;
                    _zval_copy_ctor(rv);
                    zval_unset_isref_p(rv);
                    zval_set_refcount_p(rv, (zend_uint )0);
                  } else {

                  }
                  tmp___7 = __builtin_expect((long )((int )rv->type != 5), 0L);
                  if (tmp___7) {
                    zend_error(1 << 3L,
                               "Indirect modification of overloaded property %s::$%s has no effect",
                               (zobj->ce)->name, member->value.str.val);
                  } else {

                  }
                } else {

                }
              } else {

              }
            } else {
              retval = & executor_globals.uninitialized_zval_ptr;
            }
            __repair_del_992__0: /* CIL Label */ ;
          } else {
            goto _L___1;
          }
        } else {
          goto _L___1;
        }
      } else {
        _L___1: 
        if ((zobj->ce)->__get) {
          if (guard) {
            if ((int )guard->in_get == 1) {
              if ((int )*(member->value.str.val + 0) == 0) {
                if (member->value.str.len == 0) {
                  zend_error(1, "Cannot access empty property");
                } else {
                  zend_error(1, "Cannot access property started with \'\\0\'");
                }
              } else {

              }
            } else {

            }
          } else {

          }
        } else {

        }
        if (! silent) {
          zend_error(1 << 3L, "Undefined property: %s::$%s", (zobj->ce)->name,
                     member->value.str.val);
        } else {

        }
        retval = & executor_globals.uninitialized_zval_ptr;
      }
    } else {

    }
  }
  tmp___19 = __builtin_expect((long )((unsigned long )tmp_member != (unsigned long )((void *)0)),
                              0L);
  if (tmp___19) {
    zval_addref_p(*retval);
    _zval_ptr_dtor(& tmp_member);
    zval_delref_p(*retval);
  } else {

  }
  return (*retval);
}
}
void __attribute__((__visibility__("default")))  zend_std_write_property(zval *object ,
                                                                         zval *member ,
                                                                         zval *value ,
                                                                         struct _zend_literal  const  *key ) 
{ 
  zend_object *zobj ;
  zval *tmp_member ;
  zval **variable_ptr ;
  zend_property_info *property_info ;
  void __attribute__((__visibility__("default")))  *tmp ;
  long tmp___0 ;
  zval garbage ;
  zend_uint tmp___1 ;
  zval *garbage___0 ;
  zval *new_zv ;
  void __attribute__((__visibility__("default")))  *tmp___2 ;
  zend_uint tmp___3 ;
  zend_bool tmp___4 ;
  zend_bool tmp___5 ;
  long tmp___6 ;
  zend_guard *guard ;
  zval *new_zv___0 ;
  void __attribute__((__visibility__("default")))  *tmp___7 ;
  zend_uint tmp___8 ;
  zend_bool tmp___9 ;
  int tmp___10 ;
  zval *new_zv___1 ;
  void __attribute__((__visibility__("default")))  *tmp___11 ;
  zend_uint tmp___12 ;
  zend_bool tmp___13 ;
  long tmp___14 ;
  long tmp___15 ;
  int tmp___16 ;
  long tmp___17 ;
  int tmp___19 ;
  long tmp___20 ;
  int __attribute__((__visibility__("default")))  tmp___21 ;
  long tmp___22 ;
  int tmp___23 ;
  int tmp___24 ;
  long tmp___25 ;
  long tmp___26 ;

  {
  tmp_member = (zval *)((void *)0);
  zobj = (zend_object *)(executor_globals.objects_store.object_buckets + object->value.obj.handle)->bucket.obj.object;
  tmp___0 = __builtin_expect((long )((int )member->type != 6), 0L);
  if (tmp___0) {
    while (1) {
      tmp = _emalloc(sizeof(zval_gc_info ));
      tmp_member = (zval *)tmp;
      ((zval_gc_info *)tmp_member)->u.buffered = (gc_root_buffer *)((void *)0);
      break;
    }
    *tmp_member = *member;
    tmp_member->refcount__gc = (zend_uint )1;
    tmp_member->is_ref__gc = (zend_uchar )0;
    _zval_copy_ctor(tmp_member);
    if ((int )tmp_member->type != 6) {
      _convert_to_string(tmp_member);
    } else {

    }
    member = tmp_member;
    key = (struct _zend_literal  const  *)((void *)0);
  } else {

  }
  property_info = zend_get_property_info_quick(zobj->ce, member,
                                               (unsigned long )(zobj->ce)->__set != (unsigned long )((void *)0),
                                               key);
  tmp___17 = __builtin_expect((long )((unsigned long )property_info != (unsigned long )((void *)0)),
                              1L);
  if (tmp___17) {
    tmp___25 = __builtin_expect((long )((property_info->flags & 1U) == 0U), 1L);
    if (tmp___25) {
      if (property_info->offset >= 0) {
        if (zobj->properties) {
          variable_ptr = (zval **)*(zobj->properties_table + property_info->offset);
          tmp___19 = (unsigned long )variable_ptr != (unsigned long )((void *)0);
        } else {
          variable_ptr = zobj->properties_table + property_info->offset;
          tmp___19 = (unsigned long )*variable_ptr != (unsigned long )((void *)0);
        }
        tmp___24 = tmp___19;
      } else {
        goto _L___2;
      }
    } else {
      _L___2: 
      tmp___20 = __builtin_expect((long )((unsigned long )zobj->properties != (unsigned long )((void *)0)),
                                  1L);
      if (tmp___20) {
        tmp___21 = zend_hash_quick_find((HashTable const   *)zobj->properties,
                                        (char const   *)property_info->name,
                                        (uint )(property_info->name_length + 1),
                                        property_info->h,
                                        (void **)(& variable_ptr));
        tmp___22 = __builtin_expect((long )(tmp___21 == (int __attribute__((__visibility__("default")))  )0),
                                    1L);
        if (tmp___22) {
          tmp___23 = 1;
        } else {
          tmp___23 = 0;
        }
      } else {
        tmp___23 = 0;
      }
      tmp___24 = tmp___23;
    }
    if (tmp___24) {
      tmp___6 = __builtin_expect((long )((unsigned long )*variable_ptr != (unsigned long )value),
                                 1L);
      if (tmp___6) {
        tmp___5 = zval_isref_p(*variable_ptr);
        if (tmp___5) {
          garbage = *(*variable_ptr);
          (*variable_ptr)->type = value->type;
          (*variable_ptr)->value = value->value;
          tmp___1 = zval_refcount_p(value);
          if (tmp___1 > 0U) {
            _zval_copy_ctor(*variable_ptr);
          } else {

          }
          _zval_dtor(& garbage);
        } else {
          garbage___0 = *variable_ptr;
          zval_addref_p(value);
          tmp___4 = zval_isref_p(value);
          if (tmp___4) {
            while (1) {
              tmp___3 = zval_refcount_p(value);
              if (tmp___3 > 1U) {
                zval_delref_p(value);
                while (1) {
                  tmp___2 = _emalloc(sizeof(zval_gc_info ));
                  new_zv = (zval *)tmp___2;
                  ((zval_gc_info *)new_zv)->u.buffered = (gc_root_buffer *)((void *)0);
                  break;
                }
                while (1) {
                  while (1) {
                    new_zv->value = value->value;
                    new_zv->type = value->type;
                    break;
                  }
                  zval_set_refcount_p(new_zv, (zend_uint )1);
                  zval_unset_isref_p(new_zv);
                  break;
                }
                value = new_zv;
                _zval_copy_ctor(new_zv);
              } else {

              }
              break;
            }
          } else {

          }
          *variable_ptr = value;
          _zval_ptr_dtor(& garbage___0);
        }
      } else {

      }
    } else {
      goto _L___3;
    }
  } else {
    _L___3: 
    guard = (zend_guard *)((void *)0);
    if ((zobj->ce)->__set) {
      tmp___16 = zend_get_property_guard(zobj, property_info, member, & guard);
      if (tmp___16 == 0) {
        if (! guard->in_set) {
          zval_addref_p(object);
          tmp___9 = zval_isref_p(object);
          if (tmp___9) {
            while (1) {
              tmp___8 = zval_refcount_p(object);
              if (tmp___8 > 1U) {
                zval_delref_p(object);
                while (1) {
                  tmp___7 = _emalloc(sizeof(zval_gc_info ));
                  new_zv___0 = (zval *)tmp___7;
                  ((zval_gc_info *)new_zv___0)->u.buffered = (gc_root_buffer *)((void *)0);
                  break;
                }
                while (1) {
                  while (1) {
                    new_zv___0->value = object->value;
                    new_zv___0->type = object->type;
                    break;
                  }
                  zval_set_refcount_p(new_zv___0, (zend_uint )1);
                  zval_unset_isref_p(new_zv___0);
                  break;
                }
                object = new_zv___0;
                _zval_copy_ctor(new_zv___0);
              } else {

              }
              break;
            }
          } else {

          }
          guard->in_set = (zend_bool )1;
          tmp___10 = zend_std_call_setter(object, member, value);
          guard->in_set = (zend_bool )0;
          _zval_ptr_dtor(& object);
        } else {
          goto _L___1;
        }
      } else {
        goto _L___1;
      }
    } else {
      _L___1: 
      tmp___15 = __builtin_expect((long )((unsigned long )property_info != (unsigned long )((void *)0)),
                                  1L);
      if (tmp___15) {
        zval_addref_p(value);
        tmp___13 = zval_isref_p(value);
        if (tmp___13) {
          while (1) {
            tmp___12 = zval_refcount_p(value);
            if (tmp___12 > 1U) {
              zval_delref_p(value);
              while (1) {
                tmp___11 = _emalloc(sizeof(zval_gc_info ));
                new_zv___1 = (zval *)tmp___11;
                ((zval_gc_info *)new_zv___1)->u.buffered = (gc_root_buffer *)((void *)0);
                break;
              }
              while (1) {
                while (1) {
                  new_zv___1->value = value->value;
                  new_zv___1->type = value->type;
                  break;
                }
                zval_set_refcount_p(new_zv___1, (zend_uint )1);
                zval_unset_isref_p(new_zv___1);
                break;
              }
              value = new_zv___1;
              _zval_copy_ctor(new_zv___1);
            } else {

            }
            break;
          }
        } else {

        }
        tmp___14 = __builtin_expect((long )((property_info->flags & 1U) == 0U),
                                    1L);
        if (tmp___14) {
          if (property_info->offset >= 0) {
            if (! zobj->properties) {
              *(zobj->properties_table + property_info->offset) = value;
            } else
            if (*(zobj->properties_table + property_info->offset)) {
              *((zval **)*(zobj->properties_table + property_info->offset)) = value;
            } else {
              _zend_hash_quick_add_or_update(zobj->properties,
                                             (char const   *)property_info->name,
                                             (uint )(property_info->name_length + 1),
                                             property_info->h,
                                             (void *)(& value),
                                             (uint )sizeof(zval *),
                                             (void **)(zobj->properties_table + property_info->offset),
                                             1);
            }
          } else {
            goto _L;
          }
        } else {
          _L: 
          if (! zobj->properties) {
            rebuild_object_properties(zobj);
          } else {

          }
          _zend_hash_quick_add_or_update(zobj->properties,
                                         (char const   *)property_info->name,
                                         (uint )(property_info->name_length + 1),
                                         property_info->h, (void *)(& value),
                                         (uint )sizeof(zval *),
                                         (void **)((void *)0), 1);
        }
      } else
      if ((zobj->ce)->__set) {
        if (guard) {
          if ((int )guard->in_set == 1) {
            if ((int )*(member->value.str.val + 0) == 0) {
              if (member->value.str.len == 0) {
                zend_error(1, "Cannot access empty property");
              } else {
                zend_error(1, "Cannot access property started with \'\\0\'");
              }
            } else {

            }
          } else {

          }
        } else {

        }
      } else {

      }
    }
  }
  tmp___26 = __builtin_expect((long )((unsigned long )tmp_member != (unsigned long )((void *)0)),
                              0L);
  if (tmp___26) {
    _zval_ptr_dtor(& tmp_member);
  } else {

  }
  return;
}
}
zval *zend_std_read_dimension(zval *object , zval *offset , int type ) 
{ 
  zend_class_entry *ce ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp ;
  zval *retval ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  zval *original_var ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  zend_bool tmp___2 ;
  long tmp___3 ;
  long tmp___4 ;
  zend_bool __attribute__((__visibility__("default")))  tmp___5 ;
  long tmp___6 ;

  {
  tmp = zend_get_class_entry((zval const   *)object);
  ce = (zend_class_entry *)tmp;
  tmp___5 = instanceof_function_ex((zend_class_entry const   *)ce,
                                   (zend_class_entry const   *)zend_ce_arrayaccess,
                                   (zend_bool )1);
  tmp___6 = __builtin_expect((long )((int __attribute__((__visibility__("default")))  )tmp___5 != (int __attribute__((__visibility__("default")))  )0),
                             1L);
  if (tmp___6) {
    if ((unsigned long )offset == (unsigned long )((void *)0)) {
      while (1) {
        tmp___0 = _emalloc(sizeof(zval_gc_info ));
        offset = (zval *)tmp___0;
        ((zval_gc_info *)offset)->u.buffered = (gc_root_buffer *)((void *)0);
        break;
      }
      *offset = (zval )zval_used_for_init;
    } else {
      tmp___2 = zval_isref_p(offset);
      if (tmp___2) {
        original_var = offset;
        while (1) {
          tmp___1 = _emalloc(sizeof(zval_gc_info ));
          offset = (zval *)tmp___1;
          ((zval_gc_info *)offset)->u.buffered = (gc_root_buffer *)((void *)0);
          break;
        }
        while (1) {
          while (1) {
            offset->value = original_var->value;
            offset->type = original_var->type;
            break;
          }
          zval_set_refcount_p(offset, (zend_uint )1);
          zval_unset_isref_p(offset);
          break;
        }
        _zval_copy_ctor(offset);
      } else {
        zval_addref_p(offset);
      }
    }
    zend_call_method(& object, ce, (zend_function **)((void *)0),
                     (char *)"offsetget", (int )(sizeof("offsetget") - 1UL),
                     & retval, 1, offset, (zval *)((void *)0));
    _zval_ptr_dtor(& offset);
    tmp___4 = __builtin_expect((long )(! retval), 0L);
    if (tmp___4) {
      tmp___3 = __builtin_expect((long )(! executor_globals.exception), 0L);
      if (tmp___3) {
        zend_error_noreturn(1,
                            "Undefined offset for object of type %s used as array",
                            ce->name);
      } else {

      }
      return ((zval *)0);
    } else {

    }
    zval_delref_p(retval);
    return (retval);
  } else {
    zend_error_noreturn(1, "Cannot use object of type %s as array", ce->name);
    return ((zval *)0);
  }
}
}
static void zend_std_write_dimension(zval *object , zval *offset , zval *value ) 
{ 
  zend_class_entry *ce ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  zval *original_var ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  zend_bool tmp___2 ;
  zend_bool __attribute__((__visibility__("default")))  tmp___3 ;
  long tmp___4 ;

  {
  tmp = zend_get_class_entry((zval const   *)object);
  ce = (zend_class_entry *)tmp;
  tmp___3 = instanceof_function_ex((zend_class_entry const   *)ce,
                                   (zend_class_entry const   *)zend_ce_arrayaccess,
                                   (zend_bool )1);
  tmp___4 = __builtin_expect((long )((int __attribute__((__visibility__("default")))  )tmp___3 != (int __attribute__((__visibility__("default")))  )0),
                             1L);
  if (tmp___4) {
    if (! offset) {
      while (1) {
        tmp___0 = _emalloc(sizeof(zval_gc_info ));
        offset = (zval *)tmp___0;
        ((zval_gc_info *)offset)->u.buffered = (gc_root_buffer *)((void *)0);
        break;
      }
      *offset = (zval )zval_used_for_init;
    } else {
      tmp___2 = zval_isref_p(offset);
      if (tmp___2) {
        original_var = offset;
        while (1) {
          tmp___1 = _emalloc(sizeof(zval_gc_info ));
          offset = (zval *)tmp___1;
          ((zval_gc_info *)offset)->u.buffered = (gc_root_buffer *)((void *)0);
          break;
        }
        while (1) {
          while (1) {
            offset->value = original_var->value;
            offset->type = original_var->type;
            break;
          }
          zval_set_refcount_p(offset, (zend_uint )1);
          zval_unset_isref_p(offset);
          break;
        }
        _zval_copy_ctor(offset);
      } else {
        zval_addref_p(offset);
      }
    }
    zend_call_method(& object, ce, (zend_function **)((void *)0),
                     (char *)"offsetset", (int )(sizeof("offsetset") - 1UL),
                     (zval **)((void *)0), 2, offset, value);
    _zval_ptr_dtor(& offset);
  } else {
    zend_error_noreturn(1, "Cannot use object of type %s as array", ce->name);
  }
  return;
}
}
static int zend_std_has_dimension(zval *object , zval *offset , int check_empty ) 
{ 
  zend_class_entry *ce ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp ;
  zval *retval ;
  int result ;
  zval *original_var ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  zend_bool tmp___1 ;
  long tmp___2 ;
  long tmp___3 ;
  zend_bool __attribute__((__visibility__("default")))  tmp___4 ;
  long tmp___5 ;

  {
  tmp = zend_get_class_entry((zval const   *)object);
  ce = (zend_class_entry *)tmp;
  tmp___4 = instanceof_function_ex((zend_class_entry const   *)ce,
                                   (zend_class_entry const   *)zend_ce_arrayaccess,
                                   (zend_bool )1);
  tmp___5 = __builtin_expect((long )((int __attribute__((__visibility__("default")))  )tmp___4 != (int __attribute__((__visibility__("default")))  )0),
                             1L);
  if (tmp___5) {
    tmp___1 = zval_isref_p(offset);
    if (tmp___1) {
      original_var = offset;
      while (1) {
        tmp___0 = _emalloc(sizeof(zval_gc_info ));
        offset = (zval *)tmp___0;
        ((zval_gc_info *)offset)->u.buffered = (gc_root_buffer *)((void *)0);
        break;
      }
      while (1) {
        while (1) {
          offset->value = original_var->value;
          offset->type = original_var->type;
          break;
        }
        zval_set_refcount_p(offset, (zend_uint )1);
        zval_unset_isref_p(offset);
        break;
      }
      _zval_copy_ctor(offset);
    } else {
      zval_addref_p(offset);
    }
    zend_call_method(& object, ce, (zend_function **)((void *)0),
                     (char *)"offsetexists",
                     (int )(sizeof("offsetexists") - 1UL), & retval, 1, offset,
                     (zval *)((void *)0));
    tmp___3 = __builtin_expect((long )((unsigned long )retval != (unsigned long )((void *)0)),
                               1L);
    if (tmp___3) {
      result = i_zend_is_true(retval);
      _zval_ptr_dtor(& retval);
      if (check_empty) {
        if (result) {
          tmp___2 = __builtin_expect((long )(! executor_globals.exception), 1L);
          if (tmp___2) {
            zend_call_method(& object, ce, (zend_function **)((void *)0),
                             (char *)"offsetget",
                             (int )(sizeof("offsetget") - 1UL), & retval, 1,
                             offset, (zval *)((void *)0));
            if (retval) {
              result = i_zend_is_true(retval);
              _zval_ptr_dtor(& retval);
            } else {

            }
          } else {

          }
        } else {

        }
      } else {

      }
    } else {
      result = 0;
    }
    _zval_ptr_dtor(& offset);
  } else {
    zend_error_noreturn(1, "Cannot use object of type %s as array", ce->name);
    return (0);
  }
  return (result);
}
}
static zval **zend_std_get_property_ptr_ptr(zval *object , zval *member ,
                                            zend_literal const   *key ) 
{ 
  zend_object *zobj ;
  zval tmp_member ;
  zval **retval ;
  zend_property_info *property_info ;
  long tmp ;
  zval *new_zval ;
  zend_guard *guard ;
  long tmp___0 ;
  int tmp___1 ;
  long tmp___2 ;
  int tmp___4 ;
  long tmp___5 ;
  int __attribute__((__visibility__("default")))  tmp___6 ;
  long tmp___7 ;
  int tmp___8 ;
  int tmp___9 ;
  long tmp___10 ;
  long tmp___11 ;

  {
  zobj = (zend_object *)(executor_globals.objects_store.object_buckets + object->value.obj.handle)->bucket.obj.object;
  tmp = __builtin_expect((long )((int )member->type != 6), 0L);
  if (tmp) {
    tmp_member = *member;
    _zval_copy_ctor(& tmp_member);
    if ((int )tmp_member.type != 6) {
      _convert_to_string(& tmp_member);
    } else {

    }
    member = & tmp_member;
    key = (zend_literal const   *)((void *)0);
  } else {

  }
  property_info = zend_get_property_info_quick(zobj->ce, member,
                                               (unsigned long )(zobj->ce)->__get != (unsigned long )((void *)0),
                                               key);
  tmp___2 = __builtin_expect((long )(! property_info), 0L);
  if (tmp___2) {
    goto _L___2;
  } else {
    tmp___10 = __builtin_expect((long )((property_info->flags & 1U) == 0U), 1L);
    if (tmp___10) {
      if (property_info->offset >= 0) {
        if (zobj->properties) {
          retval = (zval **)*(zobj->properties_table + property_info->offset);
          tmp___4 = (unsigned long )retval == (unsigned long )((void *)0);
        } else {
          retval = zobj->properties_table + property_info->offset;
          tmp___4 = (unsigned long )*retval == (unsigned long )((void *)0);
        }
        tmp___9 = tmp___4;
      } else {
        goto _L___1;
      }
    } else {
      _L___1: 
      tmp___5 = __builtin_expect((long )(! zobj->properties), 0L);
      if (tmp___5) {
        tmp___8 = 1;
      } else {
        tmp___6 = zend_hash_quick_find((HashTable const   *)zobj->properties,
                                       (char const   *)property_info->name,
                                       (uint )(property_info->name_length + 1),
                                       property_info->h, (void **)(& retval));
        tmp___7 = __builtin_expect((long )(tmp___6 == (int __attribute__((__visibility__("default")))  )-1),
                                   0L);
        if (tmp___7) {
          tmp___8 = 1;
        } else {
          tmp___8 = 0;
        }
      }
      tmp___9 = tmp___8;
    }
    if (tmp___9) {
      _L___2: 
      if (! (zobj->ce)->__get) {
        goto _L___0;
      } else {
        tmp___1 = zend_get_property_guard(zobj, property_info, member, & guard);
        if (tmp___1 != 0) {
          goto _L___0;
        } else
        if (property_info) {
          if (guard->in_get) {
            _L___0: 
            new_zval = & executor_globals.uninitialized_zval;
            zval_addref_p(new_zval);
            tmp___0 = __builtin_expect((long )((property_info->flags & 1U) == 0U),
                                       1L);
            if (tmp___0) {
              if (property_info->offset >= 0) {
                if (! zobj->properties) {
                  *(zobj->properties_table + property_info->offset) = new_zval;
                  retval = zobj->properties_table + property_info->offset;
                } else
                if (*(zobj->properties_table + property_info->offset)) {
                  *((zval **)*(zobj->properties_table + property_info->offset)) = new_zval;
                  retval = (zval **)*(zobj->properties_table + property_info->offset);
                } else {
                  _zend_hash_quick_add_or_update(zobj->properties,
                                                 (char const   *)property_info->name,
                                                 (uint )(property_info->name_length + 1),
                                                 property_info->h,
                                                 (void *)(& new_zval),
                                                 (uint )sizeof(zval *),
                                                 (void **)(zobj->properties_table + property_info->offset),
                                                 1);
                  retval = (zval **)*(zobj->properties_table + property_info->offset);
                }
              } else {
                goto _L;
              }
            } else {
              _L: 
              if (! zobj->properties) {
                rebuild_object_properties(zobj);
              } else {

              }
              _zend_hash_quick_add_or_update(zobj->properties,
                                             (char const   *)property_info->name,
                                             (uint )(property_info->name_length + 1),
                                             property_info->h,
                                             (void *)(& new_zval),
                                             (uint )sizeof(zval *),
                                             (void **)(& retval), 1);
            }
          } else {
            retval = (zval **)((void *)0);
          }
        } else {
          retval = (zval **)((void *)0);
        }
      }
    } else {

    }
  }
  tmp___11 = __builtin_expect((long )((unsigned long )member == (unsigned long )(& tmp_member)),
                              0L);
  if (tmp___11) {
    _zval_dtor(member);
  } else {

  }
  return (retval);
}
}
static void zend_std_unset_property(zval *object , zval *member ,
                                    zend_literal const   *key ) 
{ 
  zend_object *zobj ;
  zval *tmp_member ;
  zend_property_info *property_info ;
  void __attribute__((__visibility__("default")))  *tmp ;
  long tmp___0 ;
  zend_guard *guard ;
  zval *new_zv ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  zend_uint tmp___2 ;
  zend_bool tmp___3 ;
  int tmp___4 ;
  long tmp___5 ;
  long tmp___6 ;
  long tmp___7 ;
  int __attribute__((__visibility__("default")))  tmp___8 ;
  long tmp___9 ;
  long tmp___10 ;
  long tmp___11 ;
  long tmp___12 ;
  long tmp___13 ;

  {
  tmp_member = (zval *)((void *)0);
  zobj = (zend_object *)(executor_globals.objects_store.object_buckets + object->value.obj.handle)->bucket.obj.object;
  tmp___0 = __builtin_expect((long )((int )member->type != 6), 0L);
  if (tmp___0) {
    while (1) {
      tmp = _emalloc(sizeof(zval_gc_info ));
      tmp_member = (zval *)tmp;
      ((zval_gc_info *)tmp_member)->u.buffered = (gc_root_buffer *)((void *)0);
      break;
    }
    *tmp_member = *member;
    tmp_member->refcount__gc = (zend_uint )1;
    tmp_member->is_ref__gc = (zend_uchar )0;
    _zval_copy_ctor(tmp_member);
    if ((int )tmp_member->type != 6) {
      _convert_to_string(tmp_member);
    } else {

    }
    member = tmp_member;
    key = (zend_literal const   *)((void *)0);
  } else {

  }
  property_info = zend_get_property_info_quick(zobj->ce, member,
                                               (unsigned long )(zobj->ce)->__unset != (unsigned long )((void *)0),
                                               key);
  tmp___10 = __builtin_expect((long )((unsigned long )property_info != (unsigned long )((void *)0)),
                              1L);
  if (tmp___10) {
    tmp___11 = __builtin_expect((long )((property_info->flags & 1U) == 0U), 1L);
    if (tmp___11) {
      if (! zobj->properties) {
        if (property_info->offset >= 0) {
          tmp___12 = __builtin_expect((long )((unsigned long )*(zobj->properties_table + property_info->offset) != (unsigned long )((void *)0)),
                                      1L);
          if (tmp___12) {
            _zval_ptr_dtor(zobj->properties_table + property_info->offset);
            *(zobj->properties_table + property_info->offset) = (zval *)((void *)0);
          } else {
            goto _L___5;
          }
        } else {
          goto _L___5;
        }
      } else {
        goto _L___5;
      }
    } else {
      goto _L___5;
    }
  } else {
    _L___5: 
    tmp___7 = __builtin_expect((long )(! property_info), 0L);
    if (tmp___7) {
      goto _L___1;
    } else
    if (! zobj->properties) {
      goto _L___1;
    } else {
      tmp___8 = zend_hash_del_key_or_index(zobj->properties,
                                           (char const   *)property_info->name,
                                           (uint )(property_info->name_length + 1),
                                           property_info->h, 2);
      tmp___9 = __builtin_expect((long )(tmp___8 == (int __attribute__((__visibility__("default")))  )-1),
                                 0L);
      if (tmp___9) {
        _L___1: 
        guard = (zend_guard *)((void *)0);
        if ((zobj->ce)->__unset) {
          tmp___4 = zend_get_property_guard(zobj, property_info, member, & guard);
          if (tmp___4 == 0) {
            if (! guard->in_unset) {
              zval_addref_p(object);
              tmp___3 = zval_isref_p(object);
              if (tmp___3) {
                while (1) {
                  tmp___2 = zval_refcount_p(object);
                  if (tmp___2 > 1U) {
                    zval_delref_p(object);
                    while (1) {
                      tmp___1 = _emalloc(sizeof(zval_gc_info ));
                      new_zv = (zval *)tmp___1;
                      ((zval_gc_info *)new_zv)->u.buffered = (gc_root_buffer *)((void *)0);
                      break;
                    }
                    while (1) {
                      while (1) {
                        new_zv->value = object->value;
                        new_zv->type = object->type;
                        break;
                      }
                      zval_set_refcount_p(new_zv, (zend_uint )1);
                      zval_unset_isref_p(new_zv);
                      break;
                    }
                    object = new_zv;
                    _zval_copy_ctor(new_zv);
                  } else {

                  }
                  break;
                }
              } else {

              }
              guard->in_unset = (zend_bool )1;
              zend_std_call_unsetter(object, member);
              guard->in_unset = (zend_bool )0;
              _zval_ptr_dtor(& object);
            } else {
              goto _L___0;
            }
          } else {
            goto _L___0;
          }
        } else
        _L___0: 
        if ((zobj->ce)->__unset) {
          if (guard) {
            if ((int )guard->in_unset == 1) {
              if ((int )*(member->value.str.val + 0) == 0) {
                if (member->value.str.len == 0) {
                  zend_error(1, "Cannot access empty property");
                } else {
                  zend_error(1, "Cannot access property started with \'\\0\'");
                }
              } else {

              }
            } else {

            }
          } else {

          }
        } else {

        }
      } else {
        tmp___5 = __builtin_expect((long )((unsigned long )property_info != (unsigned long )((void *)0)),
                                   1L);
        if (tmp___5) {
          tmp___6 = __builtin_expect((long )((property_info->flags & 1U) == 0U),
                                     1L);
          if (tmp___6) {
            if (property_info->offset >= 0) {
              *(zobj->properties_table + property_info->offset) = (zval *)((void *)0);
            } else {

            }
          } else {

          }
        } else {

        }
      }
    }
  }
  tmp___13 = __builtin_expect((long )((unsigned long )tmp_member != (unsigned long )((void *)0)),
                              0L);
  if (tmp___13) {
    _zval_ptr_dtor(& tmp_member);
  } else {

  }
  return;
}
}
static void zend_std_unset_dimension(zval *object , zval *offset ) 
{ 
  zend_class_entry *ce ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp ;
  zval *original_var ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  zend_bool tmp___1 ;
  zend_bool __attribute__((__visibility__("default")))  tmp___2 ;

  {
  tmp = zend_get_class_entry((zval const   *)object);
  ce = (zend_class_entry *)tmp;
  tmp___2 = instanceof_function_ex((zend_class_entry const   *)ce,
                                   (zend_class_entry const   *)zend_ce_arrayaccess,
                                   (zend_bool )1);
  if (tmp___2) {
    tmp___1 = zval_isref_p(offset);
    if (tmp___1) {
      original_var = offset;
      while (1) {
        tmp___0 = _emalloc(sizeof(zval_gc_info ));
        offset = (zval *)tmp___0;
        ((zval_gc_info *)offset)->u.buffered = (gc_root_buffer *)((void *)0);
        break;
      }
      while (1) {
        while (1) {
          offset->value = original_var->value;
          offset->type = original_var->type;
          break;
        }
        zval_set_refcount_p(offset, (zend_uint )1);
        zval_unset_isref_p(offset);
        break;
      }
      _zval_copy_ctor(offset);
    } else {
      zval_addref_p(offset);
    }
    zend_call_method(& object, ce, (zend_function **)((void *)0),
                     (char *)"offsetunset", (int )(sizeof("offsetunset") - 1UL),
                     (zval **)((void *)0), 1, offset, (zval *)((void *)0));
    _zval_ptr_dtor(& offset);
  } else {
    zend_error_noreturn(1, "Cannot use object of type %s as array", ce->name);
  }
  return;
}
}
void __attribute__((__visibility__("default")))  zend_std_call_user_call(int ht ,
                                                                         zval *return_value ,
                                                                         zval **return_value_ptr ,
                                                                         zval *this_ptr ,
                                                                         int return_value_used ) 
{ 
  zend_internal_function *func ;
  zval *method_name_ptr ;
  zval *method_args_ptr ;
  zval *method_result_ptr ;
  zend_class_entry *ce ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  zval *__z ;
  int __attribute__((__visibility__("default")))  tmp___1 ;
  long tmp___2 ;
  void __attribute__((__visibility__("default")))  *tmp___3 ;
  char const   *__s ;
  zval *__z___0 ;
  size_t tmp___4 ;
  zend_uchar is_ref ;
  zend_bool tmp___6 ;
  zend_uint refcount ;
  zend_uint tmp___7 ;
  zend_uchar is_ref___0 ;
  zend_bool tmp___8 ;
  zend_uint refcount___0 ;
  zend_uint tmp___9 ;
  zend_bool tmp___10 ;
  zend_uint tmp___11 ;

  {
  func = (zend_internal_function *)(executor_globals.current_execute_data)->function_state.function;
  method_result_ptr = (zval *)((void *)0);
  tmp = zend_get_class_entry((zval const   *)this_ptr);
  ce = (zend_class_entry *)tmp;
  while (1) {
    tmp___0 = _emalloc(sizeof(zval_gc_info ));
    method_args_ptr = (zval *)tmp___0;
    ((zval_gc_info *)method_args_ptr)->u.buffered = (gc_root_buffer *)((void *)0);
    break;
  }
  method_args_ptr->refcount__gc = (zend_uint )1;
  method_args_ptr->is_ref__gc = (zend_uchar )0;
  _array_init(method_args_ptr, (uint )ht);
  tmp___1 = zend_copy_parameters_array(ht, method_args_ptr);
  tmp___2 = __builtin_expect((long )(tmp___1 == (int __attribute__((__visibility__("default")))  )-1),
                             0L);
  if (tmp___2) {
    _zval_dtor(method_args_ptr);
    zend_error_noreturn(1, "Cannot get arguments for __call");
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  while (1) {
    tmp___3 = _emalloc(sizeof(zval_gc_info ));
    method_name_ptr = (zval *)tmp___3;
    ((zval_gc_info *)method_name_ptr)->u.buffered = (gc_root_buffer *)((void *)0);
    break;
  }
  method_name_ptr->refcount__gc = (zend_uint )1;
  method_name_ptr->is_ref__gc = (zend_uchar )0;
  while (1) {
    __s = (char const   *)func->function_name;
    __z___0 = method_name_ptr;
    tmp___4 = strlen(__s);
    __z___0->value.str.len = (int )tmp___4;
    __z___0->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z___0->type = (zend_uchar )6;
    break;
  }
  zend_call_method(& this_ptr, ce, & ce->__call, (char *)"__call",
                   (int )(sizeof("__call") - 1UL), & method_result_ptr, 2,
                   method_name_ptr, method_args_ptr);
  if (method_result_ptr) {
    tmp___10 = zval_isref_p(method_result_ptr);
    if (tmp___10) {
      goto _L;
    } else {
      tmp___11 = zval_refcount_p(method_result_ptr);
      if (tmp___11 > 1U) {
        _L: 
        tmp___6 = zval_isref_p(return_value);
        is_ref = tmp___6;
        tmp___7 = zval_refcount_p(return_value);
        refcount = tmp___7;
        while (1) {
          return_value->value = method_result_ptr->value;
          return_value->type = method_result_ptr->type;
          break;
        }
        _zval_copy_ctor(return_value);
        _zval_ptr_dtor(& method_result_ptr);
        zval_set_isref_to_p(return_value, is_ref);
        zval_set_refcount_p(return_value, refcount);
      } else {
        tmp___8 = zval_isref_p(return_value);
        is_ref___0 = tmp___8;
        tmp___9 = zval_refcount_p(return_value);
        refcount___0 = tmp___9;
        while (1) {
          return_value->value = method_result_ptr->value;
          return_value->type = method_result_ptr->type;
          break;
        }
        method_result_ptr->type = (zend_uchar )0;
        _zval_ptr_dtor(& method_result_ptr);
        zval_set_isref_to_p(return_value, is_ref___0);
        zval_set_refcount_p(return_value, refcount___0);
      }
    }
  } else {

  }
  _zval_ptr_dtor(& method_args_ptr);
  _zval_ptr_dtor(& method_name_ptr);
  _efree((void *)func);
  return;
}
}
__inline static zend_function *zend_check_private_int(zend_function *fbc ,
                                                      zend_class_entry *ce ,
                                                      char *function_name_strval ,
                                                      int function_name_strlen ,
                                                      ulong hash_value ) 
{ 
  int __attribute__((__visibility__("default")))  tmp ;

  {
  if (! ce) {
    return ((zend_function *)0);
  } else {

  }
  if ((unsigned long )fbc->common.scope == (unsigned long )ce) {
    if ((unsigned long )executor_globals.scope == (unsigned long )ce) {
      return (fbc);
    } else {

    }
  } else {

  }
  ce = ce->parent;
  while (ce) {
    if ((unsigned long )ce == (unsigned long )executor_globals.scope) {
      tmp = zend_hash_quick_find((HashTable const   *)(& ce->function_table),
                                 (char const   *)function_name_strval,
                                 (uint )(function_name_strlen + 1), hash_value,
                                 (void **)(& fbc));
      if (tmp == (int __attribute__((__visibility__("default")))  )0) {
        if (fbc->op_array.fn_flags & 1024U) {
          if ((unsigned long )fbc->common.scope == (unsigned long )executor_globals.scope) {
            return (fbc);
          } else {

          }
        } else {

        }
      } else {

      }
      break;
    } else {

    }
    ce = ce->parent;
  }
  return ((zend_function *)((void *)0));
}
}
int __attribute__((__visibility__("default")))  zend_check_private(union _zend_function *fbc ,
                                                                   zend_class_entry *ce ,
                                                                   char *function_name_strval ,
                                                                   int function_name_strlen ) 
{ 
  ulong __attribute__((__visibility__("default")))  tmp ;
  zend_function *tmp___0 ;

  {
  tmp = zend_hash_func((char const   *)function_name_strval,
                       (uint )(function_name_strlen + 1));
  tmp___0 = zend_check_private_int(fbc, ce, function_name_strval,
                                   function_name_strlen, (ulong )tmp);
  return ((int __attribute__((__visibility__("default")))  )((unsigned long )tmp___0 != (unsigned long )((void *)0)));
}
}
int __attribute__((__visibility__("default")))  zend_check_protected(zend_class_entry *ce ,
                                                                     zend_class_entry *scope ) 
{ 
  zend_class_entry *fbc_scope ;

  {
  fbc_scope = ce;
  while (fbc_scope) {
    if ((unsigned long )fbc_scope == (unsigned long )scope) {
      return ((int __attribute__((__visibility__("default")))  )1);
    } else {

    }
    fbc_scope = fbc_scope->parent;
  }
  while (scope) {
    if ((unsigned long )scope == (unsigned long )ce) {
      return ((int __attribute__((__visibility__("default")))  )1);
    } else {

    }
    scope = scope->parent;
  }
  return ((int __attribute__((__visibility__("default")))  )0);
}
}
__inline static zend_class_entry *zend_get_function_root_class(zend_function *fbc ) 
{ 
  zend_class_entry *tmp ;

  {
  if (fbc->common.prototype) {
    tmp = (fbc->common.prototype)->common.scope;
  } else {
    tmp = fbc->common.scope;
  }
  return (tmp);
}
}
__inline static union _zend_function *zend_get_user_call_function(zend_class_entry *ce ,
                                                                  char const   *method_name ,
                                                                  int method_len ) 
{ 
  zend_internal_function *call_user_call ;
  void __attribute__((__visibility__("default")))  *tmp ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;

  {
  tmp = _emalloc(sizeof(zend_internal_function ));
  call_user_call = (zend_internal_function *)tmp;
  call_user_call->type = (zend_uchar )1;
  if ((int )ce->type == 1) {
    call_user_call->module = ce->info.internal.module;
  } else {
    call_user_call->module = (struct _zend_module_entry *)((void *)0);
  }
  call_user_call->handler = (void (*)(int ht , zval *return_value ,
                                      zval **return_value_ptr , zval *this_ptr ,
                                      int return_value_used ))(& zend_std_call_user_call);
  call_user_call->arg_info = (zend_arg_info *)((void *)0);
  call_user_call->num_args = (zend_uint )0;
  call_user_call->scope = ce;
  call_user_call->fn_flags = (zend_uint )2097152;
  tmp___0 = _estrndup(method_name, (unsigned int )method_len);
  call_user_call->function_name = (char *)tmp___0;
  return ((union _zend_function *)call_user_call);
}
}
static union _zend_function *zend_std_get_method(zval **object_ptr ,
                                                 char *method_name ,
                                                 int method_len ,
                                                 zend_literal const   *key ) 
{ 
  zend_function *fbc ;
  zval *object ;
  zend_object *zobj ;
  ulong hash_value ;
  char *lc_method_name ;
  zend_bool use_heap ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  void *tmp___1 ;
  long tmp___2 ;
  ulong __attribute__((__visibility__("default")))  tmp___3 ;
  long tmp___4 ;
  long tmp___5 ;
  long tmp___6 ;
  union _zend_function *tmp___7 ;
  int __attribute__((__visibility__("default")))  tmp___8 ;
  long tmp___9 ;
  zend_function *updated_fbc ;
  zend_class_entry *tmp___10 ;
  char const   *tmp___11 ;
  char const   *tmp___12 ;
  char *tmp___13 ;
  long tmp___14 ;
  zend_function *priv_fbc ;
  int __attribute__((__visibility__("default")))  tmp___15 ;
  zend_bool tmp___16 ;
  char const   *tmp___17 ;
  char const   *tmp___18 ;
  char *tmp___19 ;
  zend_class_entry *tmp___20 ;
  int __attribute__((__visibility__("default")))  tmp___21 ;
  int tmp___22 ;
  long tmp___23 ;
  long tmp___24 ;
  long tmp___25 ;

  {
  object = *object_ptr;
  zobj = (zend_object *)(executor_globals.objects_store.object_buckets + object->value.obj.handle)->bucket.obj.object;
  tmp___4 = __builtin_expect((long )((unsigned long )key != (unsigned long )((void *)0)),
                             1L);
  if (tmp___4) {
    lc_method_name = (char *)key->constant.value.str.val;
    hash_value = (ulong )key->hash_value;
  } else {
    tmp___2 = __builtin_expect((long )(method_len + 1 > 32768), 0L);
    use_heap = (zend_bool )tmp___2;
    if (use_heap) {
      tmp___0 = _emalloc((size_t )(method_len + 1));
      lc_method_name = (char *)tmp___0;
    } else {
      tmp___1 = __builtin_alloca((unsigned long )(method_len + 1));
      lc_method_name = (char *)tmp___1;
    }
    zend_str_tolower_copy(lc_method_name, (char const   *)method_name,
                          (unsigned int )method_len);
    tmp___3 = zend_hash_func((char const   *)lc_method_name,
                             (uint )(method_len + 1));
    hash_value = (ulong )tmp___3;
  }
  tmp___8 = zend_hash_quick_find((HashTable const   *)(& (zobj->ce)->function_table),
                                 (char const   *)lc_method_name,
                                 (uint )(method_len + 1), hash_value,
                                 (void **)(& fbc));
  tmp___9 = __builtin_expect((long )(tmp___8 == (int __attribute__((__visibility__("default")))  )-1),
                             0L);
  if (tmp___9) {
    tmp___6 = __builtin_expect((long )(! key), 0L);
    if (tmp___6) {
      while (1) {
        tmp___5 = __builtin_expect((long )use_heap, 0L);
        if (tmp___5) {
          _efree((void *)lc_method_name);
        } else {

        }
        break;
      }
    } else {

    }
    if ((zobj->ce)->__call) {
      tmp___7 = zend_get_user_call_function(zobj->ce,
                                            (char const   *)method_name,
                                            method_len);
      return (tmp___7);
    } else {
      return ((union _zend_function *)((void *)0));
    }
  } else {

  }
  if (fbc->op_array.fn_flags & 1024U) {
    tmp___10 = (*((object->value.obj.handlers)->get_class_entry))((zval const   *)object);
    updated_fbc = zend_check_private_int(fbc, tmp___10, lc_method_name,
                                         method_len, hash_value);
    tmp___14 = __builtin_expect((long )((unsigned long )updated_fbc != (unsigned long )((void *)0)),
                                1L);
    if (tmp___14) {
      fbc = updated_fbc;
    } else
    if ((zobj->ce)->__call) {
      fbc = zend_get_user_call_function(zobj->ce, (char const   *)method_name,
                                        method_len);
    } else {
      if (executor_globals.scope) {
        tmp___11 = (executor_globals.scope)->name;
      } else {
        tmp___11 = "";
      }
      if (fbc) {
        if (fbc->common.scope) {
          tmp___12 = (fbc->common.scope)->name;
        } else {
          tmp___12 = "";
        }
      } else {
        tmp___12 = "";
      }
      tmp___13 = zend_visibility_string(fbc->common.fn_flags);
      zend_error_noreturn(1, "Call to %s method %s::%s() from context \'%s\'",
                          tmp___13, tmp___12, method_name, tmp___11);
    }
  } else {
    if (executor_globals.scope) {
      tmp___16 = is_derived_class(fbc->common.scope, executor_globals.scope);
      if (tmp___16) {
        if (fbc->op_array.fn_flags & 2048U) {
          tmp___15 = zend_hash_quick_find((HashTable const   *)(& (executor_globals.scope)->function_table),
                                          (char const   *)lc_method_name,
                                          (uint )(method_len + 1), hash_value,
                                          (void **)(& priv_fbc));
          if (tmp___15 == (int __attribute__((__visibility__("default")))  )0) {
            if (priv_fbc->common.fn_flags & 1024U) {
              if ((unsigned long )priv_fbc->common.scope == (unsigned long )executor_globals.scope) {
                fbc = priv_fbc;
              } else {

              }
            } else {

            }
          } else {

          }
        } else {

        }
      } else {

      }
    } else {

    }
    if (fbc->common.fn_flags & 512U) {
      tmp___20 = zend_get_function_root_class(fbc);
      tmp___21 = zend_check_protected(tmp___20, executor_globals.scope);
      if (tmp___21) {
        tmp___22 = 0;
      } else {
        tmp___22 = 1;
      }
      tmp___23 = __builtin_expect((long )tmp___22, 0L);
      if (tmp___23) {
        if ((zobj->ce)->__call) {
          fbc = zend_get_user_call_function(zobj->ce,
                                            (char const   *)method_name,
                                            method_len);
        } else {
          if (executor_globals.scope) {
            tmp___17 = (executor_globals.scope)->name;
          } else {
            tmp___17 = "";
          }
          if (fbc) {
            if (fbc->common.scope) {
              tmp___18 = (fbc->common.scope)->name;
            } else {
              tmp___18 = "";
            }
          } else {
            tmp___18 = "";
          }
          tmp___19 = zend_visibility_string(fbc->common.fn_flags);
          zend_error_noreturn(1,
                              "Call to %s method %s::%s() from context \'%s\'",
                              tmp___19, tmp___18, method_name, tmp___17);
        }
      } else {

      }
    } else {

    }
  }
  tmp___25 = __builtin_expect((long )(! key), 0L);
  if (tmp___25) {
    while (1) {
      tmp___24 = __builtin_expect((long )use_heap, 0L);
      if (tmp___24) {
        _efree((void *)lc_method_name);
      } else {

      }
      break;
    }
  } else {

  }
  return (fbc);
}
}
void __attribute__((__visibility__("default")))  zend_std_callstatic_user_call(int ht ,
                                                                               zval *return_value ,
                                                                               zval **return_value_ptr ,
                                                                               zval *this_ptr ,
                                                                               int return_value_used ) 
{ 
  zend_internal_function *func ;
  zval *method_name_ptr ;
  zval *method_args_ptr ;
  zval *method_result_ptr ;
  zend_class_entry *ce ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zval *__z ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  long tmp___1 ;
  void __attribute__((__visibility__("default")))  *tmp___2 ;
  char const   *__s ;
  zval *__z___0 ;
  size_t tmp___3 ;
  zend_uchar is_ref ;
  zend_bool tmp___5 ;
  zend_uint refcount ;
  zend_uint tmp___6 ;
  zend_uchar is_ref___0 ;
  zend_bool tmp___7 ;
  zend_uint refcount___0 ;
  zend_uint tmp___8 ;
  zend_bool tmp___9 ;
  zend_uint tmp___10 ;

  {
  func = (zend_internal_function *)(executor_globals.current_execute_data)->function_state.function;
  method_result_ptr = (zval *)((void *)0);
  ce = executor_globals.scope;
  while (1) {
    tmp = _emalloc(sizeof(zval_gc_info ));
    method_args_ptr = (zval *)tmp;
    ((zval_gc_info *)method_args_ptr)->u.buffered = (gc_root_buffer *)((void *)0);
    break;
  }
  method_args_ptr->refcount__gc = (zend_uint )1;
  method_args_ptr->is_ref__gc = (zend_uchar )0;
  _array_init(method_args_ptr, (uint )ht);
  tmp___0 = zend_copy_parameters_array(ht, method_args_ptr);
  tmp___1 = __builtin_expect((long )(tmp___0 == (int __attribute__((__visibility__("default")))  )-1),
                             0L);
  if (tmp___1) {
    _zval_dtor(method_args_ptr);
    zend_error_noreturn(1, "Cannot get arguments for __callstatic");
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  while (1) {
    tmp___2 = _emalloc(sizeof(zval_gc_info ));
    method_name_ptr = (zval *)tmp___2;
    ((zval_gc_info *)method_name_ptr)->u.buffered = (gc_root_buffer *)((void *)0);
    break;
  }
  method_name_ptr->refcount__gc = (zend_uint )1;
  method_name_ptr->is_ref__gc = (zend_uchar )0;
  while (1) {
    __s = (char const   *)func->function_name;
    __z___0 = method_name_ptr;
    tmp___3 = strlen(__s);
    __z___0->value.str.len = (int )tmp___3;
    __z___0->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z___0->type = (zend_uchar )6;
    break;
  }
  zend_call_method((zval **)((void *)0), ce, & ce->__callstatic,
                   (char *)"__callstatic", (int )(sizeof("__callstatic") - 1UL),
                   & method_result_ptr, 2, method_name_ptr, method_args_ptr);
  if (method_result_ptr) {
    tmp___9 = zval_isref_p(method_result_ptr);
    if (tmp___9) {
      goto _L;
    } else {
      tmp___10 = zval_refcount_p(method_result_ptr);
      if (tmp___10 > 1U) {
        _L: 
        tmp___5 = zval_isref_p(return_value);
        is_ref = tmp___5;
        tmp___6 = zval_refcount_p(return_value);
        refcount = tmp___6;
        while (1) {
          return_value->value = method_result_ptr->value;
          return_value->type = method_result_ptr->type;
          break;
        }
        _zval_copy_ctor(return_value);
        _zval_ptr_dtor(& method_result_ptr);
        zval_set_isref_to_p(return_value, is_ref);
        zval_set_refcount_p(return_value, refcount);
      } else {
        tmp___7 = zval_isref_p(return_value);
        is_ref___0 = tmp___7;
        tmp___8 = zval_refcount_p(return_value);
        refcount___0 = tmp___8;
        while (1) {
          return_value->value = method_result_ptr->value;
          return_value->type = method_result_ptr->type;
          break;
        }
        method_result_ptr->type = (zend_uchar )0;
        _zval_ptr_dtor(& method_result_ptr);
        zval_set_isref_to_p(return_value, is_ref___0);
        zval_set_refcount_p(return_value, refcount___0);
      }
    }
  } else {

  }
  _zval_ptr_dtor(& method_args_ptr);
  _zval_ptr_dtor(& method_name_ptr);
  _efree((void *)func);
  return;
}
}
__inline static union _zend_function *zend_get_user_callstatic_function(zend_class_entry *ce ,
                                                                        char const   *method_name ,
                                                                        int method_len ) 
{ 
  zend_internal_function *callstatic_user_call ;
  void __attribute__((__visibility__("default")))  *tmp ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;

  {
  tmp = _emalloc(sizeof(zend_internal_function ));
  callstatic_user_call = (zend_internal_function *)tmp;
  callstatic_user_call->type = (zend_uchar )1;
  if ((int )ce->type == 1) {
    callstatic_user_call->module = ce->info.internal.module;
  } else {
    callstatic_user_call->module = (struct _zend_module_entry *)((void *)0);
  }
  callstatic_user_call->handler = (void (*)(int ht , zval *return_value ,
                                            zval **return_value_ptr ,
                                            zval *this_ptr ,
                                            int return_value_used ))(& zend_std_callstatic_user_call);
  callstatic_user_call->arg_info = (zend_arg_info *)((void *)0);
  callstatic_user_call->num_args = (zend_uint )0;
  callstatic_user_call->scope = ce;
  callstatic_user_call->fn_flags = (zend_uint )2097409;
  tmp___0 = _estrndup(method_name, (unsigned int )method_len);
  callstatic_user_call->function_name = (char *)tmp___0;
  return ((zend_function *)callstatic_user_call);
}
}
union _zend_function  __attribute__((__visibility__("default"))) *zend_std_get_static_method(zend_class_entry *ce ,
                                                                                             char *function_name_strval ,
                                                                                             int function_name_strlen ,
                                                                                             struct _zend_literal  const  *key ) 
{ 
  zend_function *fbc ;
  char *lc_class_name ;
  char *lc_function_name ;
  ulong hash_value ;
  zend_bool use_heap ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  void *tmp___1 ;
  long tmp___2 ;
  ulong __attribute__((__visibility__("default")))  tmp___3 ;
  long tmp___4 ;
  char __attribute__((__visibility__("default")))  *tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;
  long tmp___8 ;
  long tmp___9 ;
  union _zend_function *tmp___10 ;
  union _zend_function *tmp___11 ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp___12 ;
  zend_bool __attribute__((__visibility__("default")))  tmp___13 ;
  long tmp___14 ;
  int __attribute__((__visibility__("default")))  tmp___15 ;
  long tmp___16 ;
  zend_function *updated_fbc ;
  char const   *tmp___17 ;
  char const   *tmp___18 ;
  char *tmp___19 ;
  long tmp___20 ;
  char const   *tmp___21 ;
  char const   *tmp___22 ;
  char *tmp___23 ;
  zend_class_entry *tmp___24 ;
  int __attribute__((__visibility__("default")))  tmp___25 ;
  int tmp___26 ;
  long tmp___27 ;
  long tmp___28 ;
  long tmp___29 ;

  {
  fbc = (zend_function *)((void *)0);
  lc_function_name = (char *)((void *)0);
  tmp___4 = __builtin_expect((long )((unsigned long )key != (unsigned long )((void *)0)),
                             1L);
  if (tmp___4) {
    lc_function_name = (char *)key->constant.value.str.val;
    hash_value = (ulong )key->hash_value;
  } else {
    tmp___2 = __builtin_expect((long )(function_name_strlen + 1 > 32768), 0L);
    use_heap = (zend_bool )tmp___2;
    if (use_heap) {
      tmp___0 = _emalloc((size_t )(function_name_strlen + 1));
      lc_function_name = (char *)tmp___0;
    } else {
      tmp___1 = __builtin_alloca((unsigned long )(function_name_strlen + 1));
      lc_function_name = (char *)tmp___1;
    }
    zend_str_tolower_copy(lc_function_name,
                          (char const   *)function_name_strval,
                          (unsigned int )function_name_strlen);
    tmp___3 = zend_hash_func((char const   *)lc_function_name,
                             (uint )(function_name_strlen + 1));
    hash_value = (ulong )tmp___3;
  }
  if ((zend_uint )function_name_strlen == ce->name_length) {
    if (ce->constructor) {
      tmp___5 = zend_str_tolower_dup(ce->name, ce->name_length);
      lc_class_name = (char *)tmp___5;
      tmp___6 = memcmp((void const   *)lc_class_name,
                       (void const   *)lc_function_name,
                       (size_t )function_name_strlen);
      if (! tmp___6) {
        tmp___7 = memcmp((void const   *)(ce->constructor)->common.function_name,
                         (void const   *)"__", sizeof("__") - 1UL);
        if (tmp___7) {
          fbc = ce->constructor;
        } else {

        }
      } else {

      }
      _efree((void *)lc_class_name);
    } else {

    }
  } else {

  }
  tmp___14 = __builtin_expect((long )(! fbc), 1L);
  if (tmp___14) {
    tmp___15 = zend_hash_quick_find((HashTable const   *)(& ce->function_table),
                                    (char const   *)lc_function_name,
                                    (uint )(function_name_strlen + 1),
                                    hash_value, (void **)(& fbc));
    tmp___16 = __builtin_expect((long )(tmp___15 == (int __attribute__((__visibility__("default")))  )-1),
                                0L);
    if (tmp___16) {
      tmp___9 = __builtin_expect((long )(! key), 0L);
      if (tmp___9) {
        while (1) {
          tmp___8 = __builtin_expect((long )use_heap, 0L);
          if (tmp___8) {
            _efree((void *)lc_function_name);
          } else {

          }
          break;
        }
      } else {

      }
      if (ce->__call) {
        if (executor_globals.This) {
          if (((executor_globals.This)->value.obj.handlers)->get_class_entry) {
            tmp___12 = zend_get_class_entry((zval const   *)executor_globals.This);
            tmp___13 = instanceof_function((zend_class_entry const   *)tmp___12,
                                           (zend_class_entry const   *)ce);
            if (tmp___13) {
              tmp___10 = zend_get_user_call_function(ce,
                                                     (char const   *)function_name_strval,
                                                     function_name_strlen);
              return ((union _zend_function  __attribute__((__visibility__("default"))) *)tmp___10);
            } else {
              goto _L___1;
            }
          } else {
            goto _L___1;
          }
        } else {
          goto _L___1;
        }
      } else
      _L___1: 
      if (ce->__callstatic) {
        tmp___11 = zend_get_user_callstatic_function(ce,
                                                     (char const   *)function_name_strval,
                                                     function_name_strlen);
        return ((union _zend_function  __attribute__((__visibility__("default"))) *)tmp___11);
      } else {
        return ((union _zend_function  __attribute__((__visibility__("default"))) *)((void *)0));
      }
    } else {

    }
  } else {

  }
  if (! (fbc->op_array.fn_flags & 256U)) {
    if (fbc->op_array.fn_flags & 1024U) {
      updated_fbc = zend_check_private_int(fbc, executor_globals.scope,
                                           lc_function_name,
                                           function_name_strlen, hash_value);
      tmp___20 = __builtin_expect((long )((unsigned long )updated_fbc != (unsigned long )((void *)0)),
                                  1L);
      if (tmp___20) {
        fbc = updated_fbc;
      } else
      if (ce->__callstatic) {
        fbc = zend_get_user_callstatic_function(ce,
                                                (char const   *)function_name_strval,
                                                function_name_strlen);
      } else {
        if (executor_globals.scope) {
          tmp___17 = (executor_globals.scope)->name;
        } else {
          tmp___17 = "";
        }
        if (fbc) {
          if (fbc->common.scope) {
            tmp___18 = (fbc->common.scope)->name;
          } else {
            tmp___18 = "";
          }
        } else {
          tmp___18 = "";
        }
        tmp___19 = zend_visibility_string(fbc->common.fn_flags);
        zend_error_noreturn(1, "Call to %s method %s::%s() from context \'%s\'",
                            tmp___19, tmp___18, function_name_strval, tmp___17);
      }
    } else
    if (fbc->common.fn_flags & 512U) {
      tmp___24 = zend_get_function_root_class(fbc);
      tmp___25 = zend_check_protected(tmp___24, executor_globals.scope);
      if (tmp___25) {
        tmp___26 = 0;
      } else {
        tmp___26 = 1;
      }
      tmp___27 = __builtin_expect((long )tmp___26, 0L);
      if (tmp___27) {
        if (ce->__callstatic) {
          fbc = zend_get_user_callstatic_function(ce,
                                                  (char const   *)function_name_strval,
                                                  function_name_strlen);
        } else {
          if (executor_globals.scope) {
            tmp___21 = (executor_globals.scope)->name;
          } else {
            tmp___21 = "";
          }
          if (fbc) {
            if (fbc->common.scope) {
              tmp___22 = (fbc->common.scope)->name;
            } else {
              tmp___22 = "";
            }
          } else {
            tmp___22 = "";
          }
          tmp___23 = zend_visibility_string(fbc->common.fn_flags);
          zend_error_noreturn(1,
                              "Call to %s method %s::%s() from context \'%s\'",
                              tmp___23, tmp___22, function_name_strval, tmp___21);
        }
      } else {

      }
    } else {

    }
  } else {

  }
  tmp___29 = __builtin_expect((long )(! key), 0L);
  if (tmp___29) {
    while (1) {
      tmp___28 = __builtin_expect((long )use_heap, 0L);
      if (tmp___28) {
        _efree((void *)lc_function_name);
      } else {

      }
      break;
    }
  } else {

  }
  return ((union _zend_function  __attribute__((__visibility__("default"))) *)fbc);
}
}
zval __attribute__((__visibility__("default")))  **zend_std_get_static_property(zend_class_entry *ce ,
                                                                                char *property_name ,
                                                                                int property_name_len ,
                                                                                zend_bool silent ,
                                                                                struct _zend_literal  const  *key ) 
{ 
  zend_property_info *property_info ;
  ulong hash_value ;
  ulong __attribute__((__visibility__("default")))  tmp ;
  long tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;
  long tmp___2 ;
  char *tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  long tmp___6 ;
  long tmp___7 ;
  long tmp___8 ;
  long tmp___9 ;

  {
  tmp___9 = __builtin_expect((long )(! key), 0L);
  if (tmp___9) {
    goto _L;
  } else {
    if ((unsigned long )*((executor_globals.active_op_array)->run_time_cache + key->cache_slot) == (unsigned long )ce) {
      property_info = (zend_property_info *)*((executor_globals.active_op_array)->run_time_cache + (key->cache_slot + 1U));
    } else {
      property_info = (zend_property_info *)((void *)0);
    }
    if ((unsigned long )property_info == (unsigned long )((void *)0)) {
      _L: 
      tmp___0 = __builtin_expect((long )((unsigned long )key != (unsigned long )((void *)0)),
                                 1L);
      if (tmp___0) {
        hash_value = (ulong )key->hash_value;
      } else {
        tmp = zend_hash_func((char const   *)property_name,
                             (uint )(property_name_len + 1));
        hash_value = (ulong )tmp;
      }
      tmp___1 = zend_hash_quick_find((HashTable const   *)(& ce->properties_info),
                                     (char const   *)property_name,
                                     (uint )(property_name_len + 1), hash_value,
                                     (void **)(& property_info));
      tmp___2 = __builtin_expect((long )(tmp___1 == (int __attribute__((__visibility__("default")))  )-1),
                                 0L);
      if (tmp___2) {
        if (! silent) {
          zend_error_noreturn(1,
                              "Access to undeclared static property: %s::$%s",
                              ce->name, property_name);
        } else {

        }
        return ((zval __attribute__((__visibility__("default")))  **)((void *)0));
      } else {

      }
      tmp___4 = zend_verify_property_access(property_info, ce);
      if (tmp___4) {
        tmp___5 = 0;
      } else {
        tmp___5 = 1;
      }
      tmp___6 = __builtin_expect((long )tmp___5, 0L);
      if (tmp___6) {
        if (! silent) {
          tmp___3 = zend_visibility_string(property_info->flags);
          zend_error_noreturn(1, "Cannot access %s property %s::$%s", tmp___3,
                              ce->name, property_name);
        } else {

        }
        return ((zval __attribute__((__visibility__("default")))  **)((void *)0));
      } else {

      }
      tmp___7 = __builtin_expect((long )((property_info->flags & 1U) == 0U), 0L);
      if (tmp___7) {
        if (! silent) {
          zend_error_noreturn(1,
                              "Access to undeclared static property: %s::$%s",
                              ce->name, property_name);
        } else {

        }
        return ((zval __attribute__((__visibility__("default")))  **)((void *)0));
      } else {

      }
      zend_update_class_constants(ce);
      tmp___8 = __builtin_expect((long )((unsigned long )key != (unsigned long )((void *)0)),
                                 1L);
      if (tmp___8) {
        while (1) {
          *((executor_globals.active_op_array)->run_time_cache + key->cache_slot) = (void *)ce;
          *((executor_globals.active_op_array)->run_time_cache + (key->cache_slot + 1U)) = (void *)property_info;
          break;
        }
      } else {

      }
    } else {

    }
  }
  return ((zval __attribute__((__visibility__("default")))  **)(ce->static_members_table + property_info->offset));
}
}
zend_bool __attribute__((__visibility__("default")))  zend_std_unset_static_property(zend_class_entry *ce ,
                                                                                     char *property_name ,
                                                                                     int property_name_len ,
                                                                                     struct _zend_literal  const  *key ) 
{ 


  {
  zend_error_noreturn(1, "Attempt to unset static property %s::$%s", ce->name,
                      property_name);
  return ((zend_bool __attribute__((__visibility__("default")))  )0);
}
}
union _zend_function  __attribute__((__visibility__("default"))) *zend_std_get_constructor(zval *object ) 
{ 
  zend_object *zobj ;
  zend_function *constructor ;
  long tmp ;
  zend_class_entry *tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  zobj = (zend_object *)(executor_globals.objects_store.object_buckets + object->value.obj.handle)->bucket.obj.object;
  constructor = (zobj->ce)->constructor;
  if (constructor) {
    if (! (constructor->op_array.fn_flags & 256U)) {
      if (constructor->op_array.fn_flags & 1024U) {
        tmp = __builtin_expect((long )((unsigned long )constructor->common.scope != (unsigned long )executor_globals.scope),
                               0L);
        if (tmp) {
          if (executor_globals.scope) {
            zend_error_noreturn(1,
                                "Call to private %s::%s() from context \'%s\'",
                                (constructor->common.scope)->name,
                                constructor->common.function_name,
                                (executor_globals.scope)->name);
          } else {
            zend_error_noreturn(1,
                                "Call to private %s::%s() from invalid context",
                                (constructor->common.scope)->name,
                                constructor->common.function_name);
          }
        } else {

        }
      } else
      if (constructor->common.fn_flags & 512U) {
        tmp___0 = zend_get_function_root_class(constructor);
        tmp___1 = zend_check_protected(tmp___0, executor_globals.scope);
        if (tmp___1) {
          tmp___2 = 0;
        } else {
          tmp___2 = 1;
        }
        tmp___3 = __builtin_expect((long )tmp___2, 0L);
        if (tmp___3) {
          if (executor_globals.scope) {
            zend_error_noreturn(1,
                                "Call to protected %s::%s() from context \'%s\'",
                                (constructor->common.scope)->name,
                                constructor->common.function_name,
                                (executor_globals.scope)->name);
          } else {
            zend_error_noreturn(1,
                                "Call to protected %s::%s() from invalid context",
                                (constructor->common.scope)->name,
                                constructor->common.function_name);
          }
        } else {

        }
      } else {

      }
    } else {

    }
  } else {

  }
  return ((union _zend_function  __attribute__((__visibility__("default"))) *)constructor);
}
}
extern int zend_compare_symbol_tables_i(HashTable *ht1 , HashTable *ht2 ) ;
static int zend_std_compare_objects(zval *o1 , zval *o2 ) 
{ 
  zend_object *zobj1 ;
  zend_object *zobj2 ;
  int i ;
  zval result ;
  int __attribute__((__visibility__("default")))  tmp ;
  int tmp___0 ;

  {
  zobj1 = (zend_object *)(executor_globals.objects_store.object_buckets + o1->value.obj.handle)->bucket.obj.object;
  zobj2 = (zend_object *)(executor_globals.objects_store.object_buckets + o2->value.obj.handle)->bucket.obj.object;
  if ((unsigned long )zobj1->ce != (unsigned long )zobj2->ce) {
    return (1);
  } else {

  }
  if (! zobj1->properties) {
    if (! zobj2->properties) {
      i = 0;
      while (i < (zobj1->ce)->default_properties_count) {
        if (*(zobj1->properties_table + i)) {
          if (*(zobj2->properties_table + i)) {
            tmp = compare_function(& result, *(zobj1->properties_table + i),
                                   *(zobj2->properties_table + i));
            if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
              return (1);
            } else {

            }
            if (result.value.lval != 0L) {
              return ((int )result.value.lval);
            } else {

            }
          } else {
            return (1);
          }
        } else
        if (*(zobj2->properties_table + i)) {
          return (1);
        } else {
          return (0);
        }
        i ++;
      }
      return (0);
    } else {
      goto _L;
    }
  } else {
    _L: 
    if (! zobj1->properties) {
      rebuild_object_properties(zobj1);
    } else {

    }
    if (! zobj2->properties) {
      rebuild_object_properties(zobj2);
    } else {

    }
    tmp___0 = zend_compare_symbol_tables_i(zobj1->properties, zobj2->properties);
    return (tmp___0);
  }
}
}
static int zend_std_has_property(zval *object , zval *member ,
                                 int has_set_exists , zend_literal const   *key ) 
{ 
  zend_object *zobj ;
  int result ;
  zval **value ;
  zval *tmp_member ;
  zend_property_info *property_info ;
  void __attribute__((__visibility__("default")))  *tmp ;
  long tmp___0 ;
  zend_guard *guard ;
  zval *rv ;
  zval *new_zv ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  zend_uint tmp___2 ;
  zend_bool tmp___3 ;
  int __attribute__((__visibility__("default")))  tmp___4 ;
  long tmp___5 ;
  int tmp___6 ;
  int __attribute__((__visibility__("default")))  tmp___7 ;
  long tmp___8 ;
  int tmp___10 ;
  long tmp___11 ;
  int __attribute__((__visibility__("default")))  tmp___12 ;
  long tmp___13 ;
  int tmp___14 ;
  int tmp___15 ;
  long tmp___16 ;
  long tmp___17 ;

  {
  value = (zval **)((void *)0);
  tmp_member = (zval *)((void *)0);
  zobj = (zend_object *)(executor_globals.objects_store.object_buckets + object->value.obj.handle)->bucket.obj.object;
  tmp___0 = __builtin_expect((long )((int )member->type != 6), 0L);
  if (tmp___0) {
    while (1) {
      tmp = _emalloc(sizeof(zval_gc_info ));
      tmp_member = (zval *)tmp;
      ((zval_gc_info *)tmp_member)->u.buffered = (gc_root_buffer *)((void *)0);
      break;
    }
    *tmp_member = *member;
    tmp_member->refcount__gc = (zend_uint )1;
    tmp_member->is_ref__gc = (zend_uchar )0;
    _zval_copy_ctor(tmp_member);
    if ((int )tmp_member->type != 6) {
      _convert_to_string(tmp_member);
    } else {

    }
    member = tmp_member;
    key = (zend_literal const   *)((void *)0);
  } else {

  }
  property_info = zend_get_property_info_quick(zobj->ce, member, 1, key);
  tmp___8 = __builtin_expect((long )(! property_info), 0L);
  if (tmp___8) {
    goto _L___0;
  } else {
    tmp___16 = __builtin_expect((long )((property_info->flags & 1U) == 0U), 1L);
    if (tmp___16) {
      if (property_info->offset >= 0) {
        if (zobj->properties) {
          value = (zval **)*(zobj->properties_table + property_info->offset);
          tmp___10 = (unsigned long )value == (unsigned long )((void *)0);
        } else {
          value = zobj->properties_table + property_info->offset;
          tmp___10 = (unsigned long )*value == (unsigned long )((void *)0);
        }
        tmp___15 = tmp___10;
      } else {
        goto _L;
      }
    } else {
      _L: 
      tmp___11 = __builtin_expect((long )(! zobj->properties), 0L);
      if (tmp___11) {
        tmp___14 = 1;
      } else {
        tmp___12 = zend_hash_quick_find((HashTable const   *)zobj->properties,
                                        (char const   *)property_info->name,
                                        (uint )(property_info->name_length + 1),
                                        property_info->h, (void **)(& value));
        tmp___13 = __builtin_expect((long )(tmp___12 == (int __attribute__((__visibility__("default")))  )-1),
                                    0L);
        if (tmp___13) {
          tmp___14 = 1;
        } else {
          tmp___14 = 0;
        }
      }
      tmp___15 = tmp___14;
    }
    if (tmp___15) {
      _L___0: 
      result = 0;
      if (has_set_exists != 2) {
        if ((zobj->ce)->__isset) {
          tmp___6 = zend_get_property_guard(zobj, property_info, member, & guard);
          if (tmp___6 == 0) {
            if (! guard->in_isset) {
              zval_addref_p(object);
              tmp___3 = zval_isref_p(object);
              if (tmp___3) {
                while (1) {
                  tmp___2 = zval_refcount_p(object);
                  if (tmp___2 > 1U) {
                    zval_delref_p(object);
                    while (1) {
                      tmp___1 = _emalloc(sizeof(zval_gc_info ));
                      new_zv = (zval *)tmp___1;
                      ((zval_gc_info *)new_zv)->u.buffered = (gc_root_buffer *)((void *)0);
                      break;
                    }
                    while (1) {
                      while (1) {
                        new_zv->value = object->value;
                        new_zv->type = object->type;
                        break;
                      }
                      zval_set_refcount_p(new_zv, (zend_uint )1);
                      zval_unset_isref_p(new_zv);
                      break;
                    }
                    object = new_zv;
                    _zval_copy_ctor(new_zv);
                  } else {

                  }
                  break;
                }
              } else {

              }
              guard->in_isset = (zend_bool )1;
              rv = zend_std_call_issetter(object, member);
              if (rv) {
                tmp___4 = zend_is_true(rv);
                result = (int )tmp___4;
                _zval_ptr_dtor(& rv);
                if (has_set_exists) {
                  if (result) {
                    tmp___5 = __builtin_expect((long )(! executor_globals.exception),
                                               1L);
                    if (tmp___5) {
                      if ((zobj->ce)->__get) {
                        if (! guard->in_get) {
                          guard->in_get = (zend_bool )1;
                          rv = zend_std_call_getter(object, member);
                          guard->in_get = (zend_bool )0;
                          if (rv) {
                            zval_addref_p(rv);
                            result = i_zend_is_true(rv);
                            _zval_ptr_dtor(& rv);
                          } else {
                            result = 0;
                          }
                        } else {
                          result = 0;
                        }
                      } else {
                        result = 0;
                      }
                    } else {
                      result = 0;
                    }
                  } else {

                  }
                } else {

                }
              } else {

              }
              guard->in_isset = (zend_bool )0;
              _zval_ptr_dtor(& object);
            } else {

            }
          } else {

          }
        } else {

        }
      } else {

      }
    } else {
      switch (has_set_exists) {
      case 0: 
      result = (int )(*value)->type != 0;
      break;
      default: 
      tmp___7 = zend_is_true(*value);
      result = (int )tmp___7;
      break;
      case 2: 
      result = 1;
      break;
      }
    }
  }
  tmp___17 = __builtin_expect((long )((unsigned long )tmp_member != (unsigned long )((void *)0)),
                              0L);
  if (tmp___17) {
    _zval_ptr_dtor(& tmp_member);
  } else {

  }
  return (result);
}
}
zend_class_entry *zend_std_object_get_class(zval const   *object ) 
{ 
  zend_object *zobj ;

  {
  zobj = (zend_object *)(executor_globals.objects_store.object_buckets + object->value.obj.handle)->bucket.obj.object;
  return (zobj->ce);
}
}
int zend_std_object_get_class_name(zval const   *object , char **class_name ,
                                   zend_uint *class_name_len , int parent ) 
{ 
  zend_object *zobj ;
  zend_class_entry *ce ;
  char __attribute__((__visibility__("default")))  *tmp ;

  {
  zobj = (zend_object *)(executor_globals.objects_store.object_buckets + object->value.obj.handle)->bucket.obj.object;
  if (parent) {
    if (! (zobj->ce)->parent) {
      return (-1);
    } else {

    }
    ce = (zobj->ce)->parent;
  } else {
    ce = zobj->ce;
  }
  *class_name_len = ce->name_length;
  tmp = _estrndup(ce->name, ce->name_length);
  *class_name = (char *)tmp;
  return (0);
}
}
int __attribute__((__visibility__("default")))  zend_std_cast_object_tostring(zval *readobj ,
                                                                              zval *writeobj ,
                                                                              int type ) 
{ 
  zval *retval ;
  zend_class_entry *ce ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp ;
  long tmp___0 ;
  zend_uchar is_ref ;
  zend_bool tmp___1 ;
  zend_uint refcount ;
  zend_uint tmp___2 ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___3 ;
  long tmp___4 ;
  zval __attribute__((__visibility__("default")))  *tmp___5 ;
  zval *__z___0 ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp___6 ;
  zval *__z___1 ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp___7 ;
  zval *__z___2 ;

  {
  switch (type) {
  case 6: 
  tmp = zend_get_class_entry((zval const   *)readobj);
  ce = (zend_class_entry *)tmp;
  if (ce->__tostring) {
    tmp___5 = zend_call_method(& readobj, ce, & ce->__tostring,
                               (char *)"__tostring",
                               (int )(sizeof("__tostring") - 1UL), & retval, 0,
                               (zval *)((void *)0), (zval *)((void *)0));
    if (tmp___5) {
      goto _L;
    } else
    if (executor_globals.exception) {
      _L: 
      tmp___0 = __builtin_expect((long )((unsigned long )executor_globals.exception != (unsigned long )((void *)0)),
                                 0L);
      if (tmp___0) {
        if (retval) {
          _zval_ptr_dtor(& retval);
        } else {

        }
        zend_error_noreturn(1,
                            "Method %s::__toString() must not throw an exception",
                            ce->name);
        return ((int __attribute__((__visibility__("default")))  )-1);
      } else {

      }
      tmp___4 = __builtin_expect((long )((int )retval->type == 6), 1L);
      if (tmp___4) {
        writeobj->refcount__gc = (zend_uint )1;
        writeobj->is_ref__gc = (zend_uchar )0;
        if ((unsigned long )readobj == (unsigned long )writeobj) {
          _zval_dtor(readobj);
        } else {

        }
        tmp___1 = zval_isref_p(writeobj);
        is_ref = tmp___1;
        tmp___2 = zval_refcount_p(writeobj);
        refcount = tmp___2;
        while (1) {
          writeobj->value = retval->value;
          writeobj->type = retval->type;
          break;
        }
        _zval_copy_ctor(writeobj);
        _zval_ptr_dtor(& retval);
        zval_set_isref_to_p(writeobj, is_ref);
        zval_set_refcount_p(writeobj, refcount);
        if ((int )writeobj->type != type) {
          while (1) {
            switch (type) {
            case 0: 
            convert_to_null(writeobj);
            break;
            case 1: 
            convert_to_long(writeobj);
            break;
            case 2: 
            convert_to_double(writeobj);
            break;
            case 3: 
            convert_to_boolean(writeobj);
            break;
            case 4: 
            convert_to_array(writeobj);
            break;
            case 5: 
            convert_to_object(writeobj);
            break;
            case 6: 
            if ((int )writeobj->type != 6) {
              _convert_to_string(writeobj);
            } else {

            }
            break;
            default: 
            __assert_fail("0",
                          "/data/manybugs/php/2e25ec9eb7/src/Zend/zend_object_handlers.c",
                          1483U, "zend_std_cast_object_tostring");
            break;
            }
            break;
          }
        } else {

        }
        return ((int __attribute__((__visibility__("default")))  )0);
      } else {
        _zval_ptr_dtor(& retval);
        writeobj->refcount__gc = (zend_uint )1;
        writeobj->is_ref__gc = (zend_uchar )0;
        if ((unsigned long )readobj == (unsigned long )writeobj) {
          _zval_dtor(readobj);
        } else {

        }
        while (1) {
          __z = writeobj;
          __z->value.str.len = 0;
          tmp___3 = _estrndup("", (unsigned int )(sizeof("") - 1UL));
          __z->value.str.val = (char *)tmp___3;
          __z->type = (zend_uchar )6;
          break;
        }
        zend_error(1 << 12L,
                   "Method %s::__toString() must return a string value",
                   ce->name);
        return ((int __attribute__((__visibility__("default")))  )0);
      }
    } else {

    }
  } else {

  }
  return ((int __attribute__((__visibility__("default")))  )-1);
  case 3: 
  writeobj->refcount__gc = (zend_uint )1;
  writeobj->is_ref__gc = (zend_uchar )0;
  while (1) {
    __z___0 = writeobj;
    __z___0->value.lval = 1L;
    __z___0->type = (zend_uchar )3;
    break;
  }
  return ((int __attribute__((__visibility__("default")))  )0);
  case 1: 
  tmp___6 = zend_get_class_entry((zval const   *)readobj);
  ce = (zend_class_entry *)tmp___6;
  zend_error(1 << 3L, "Object of class %s could not be converted to int",
             ce->name);
  writeobj->refcount__gc = (zend_uint )1;
  writeobj->is_ref__gc = (zend_uchar )0;
  if ((unsigned long )readobj == (unsigned long )writeobj) {
    _zval_dtor(readobj);
  } else {

  }
  __z___1 = writeobj;
  __z___1->value.lval = 1L;
  __z___1->type = (zend_uchar )1;
  return ((int __attribute__((__visibility__("default")))  )0);
  case 2: 
  tmp___7 = zend_get_class_entry((zval const   *)readobj);
  ce = (zend_class_entry *)tmp___7;
  zend_error(1 << 3L, "Object of class %s could not be converted to double",
             ce->name);
  writeobj->refcount__gc = (zend_uint )1;
  writeobj->is_ref__gc = (zend_uchar )0;
  if ((unsigned long )readobj == (unsigned long )writeobj) {
    _zval_dtor(readobj);
  } else {

  }
  __z___2 = writeobj;
  __z___2->value.dval = (double )1;
  __z___2->type = (zend_uchar )2;
  return ((int __attribute__((__visibility__("default")))  )0);
  default: 
  writeobj->refcount__gc = (zend_uint )1;
  writeobj->is_ref__gc = (zend_uchar )0;
  writeobj->type = (zend_uchar )0;
  break;
  }
  return ((int __attribute__((__visibility__("default")))  )-1);
}
}
int zend_std_get_closure(zval *obj , zend_class_entry **ce_ptr ,
                         zend_function **fptr_ptr , zval **zobj_ptr ) 
{ 
  zend_class_entry *ce ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  if ((int )obj->type != 5) {
    return (-1);
  } else {

  }
  tmp = zend_get_class_entry((zval const   *)obj);
  ce = (zend_class_entry *)tmp;
  tmp___0 = zend_hash_find((HashTable const   *)(& ce->function_table),
                           "__invoke", (uint )sizeof("__invoke"),
                           (void **)fptr_ptr);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return (-1);
  } else {

  }
  *ce_ptr = ce;
  if ((*fptr_ptr)->common.fn_flags & 1U) {
    if (zobj_ptr) {
      *zobj_ptr = (zval *)((void *)0);
    } else {

    }
  } else
  if (zobj_ptr) {
    *zobj_ptr = obj;
  } else {

  }
  return (0);
}
}
struct _zend_object_handlers  __attribute__((__visibility__("default"))) std_object_handlers  = 
     {(void (*)(zval *object ))(& zend_objects_store_add_ref),
    (void (*)(zval *object ))(& zend_objects_store_del_ref),
    (zend_object_value (*)(zval *object ))(& zend_objects_clone_obj),
    & zend_std_read_property,
    (void (*)(zval *object , zval *member ,
              zval *value , struct _zend_literal  const  *key ))(& zend_std_write_property),
    & zend_std_read_dimension, & zend_std_write_dimension,
    & zend_std_get_property_ptr_ptr, (zval *(*)(zval *object ))((void *)0),
    (void (*)(zval **object , zval *value ))((void *)0),
    & zend_std_has_property, & zend_std_unset_property,
    & zend_std_has_dimension, & zend_std_unset_dimension,
    (HashTable *(*)(zval *object ))(& zend_std_get_properties),
    & zend_std_get_method, (int (*)(char *method , int ht , zval *return_value ,
                                    zval **return_value_ptr , zval *this_ptr ,
                                    int return_value_used ))((void *)0),
    (union _zend_function *(*)(zval *object ))(& zend_std_get_constructor),
    & zend_std_object_get_class, & zend_std_object_get_class_name,
    & zend_std_compare_objects,
    (int (*)(zval *readobj , zval *retval ,
             int type ))(& zend_std_cast_object_tostring),
    (int (*)(zval *object , long *count ))((void *)0),
    (HashTable *(*)(zval *object , int *is_temp ))((void *)0),
    & zend_std_get_closure};
