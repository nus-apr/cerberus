typedef unsigned long size_t;
typedef int __int32_t;
typedef unsigned long __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long __ino_t;
typedef unsigned int __mode_t;
typedef unsigned long __nlink_t;
typedef long __off_t;
typedef long __off64_t;
typedef long __time_t;
typedef long __blksize_t;
typedef long __blkcnt_t;
typedef long __ssize_t;
typedef long __syscall_slong_t;
typedef unsigned int __socklen_t;
struct _IO_FILE;
struct _IO_FILE;
struct _IO_FILE;
typedef struct _IO_FILE FILE;
typedef struct _IO_FILE __FILE;
union __anonunion___value_3 {
   unsigned int __wch ;
   char __wchb[4] ;
};
struct __anonstruct___mbstate_t_2 {
   int __count ;
   union __anonunion___value_3 __value ;
};
typedef struct __anonstruct___mbstate_t_2 __mbstate_t;
typedef __builtin_va_list __gnuc_va_list;
struct _IO_FILE;
typedef void _IO_lock_t;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
struct _IO_FILE {
   int _flags ;
   char *_IO_read_ptr ;
   char *_IO_read_end ;
   char *_IO_read_base ;
   char *_IO_write_base ;
   char *_IO_write_ptr ;
   char *_IO_write_end ;
   char *_IO_buf_base ;
   char *_IO_buf_end ;
   char *_IO_save_base ;
   char *_IO_backup_base ;
   char *_IO_save_end ;
   struct _IO_marker *_markers ;
   struct _IO_FILE *_chain ;
   int _fileno ;
   int _flags2 ;
   __off_t _old_offset ;
   unsigned short _cur_column ;
   signed char _vtable_offset ;
   char _shortbuf[1] ;
   _IO_lock_t *_lock ;
   __off64_t _offset ;
   void *__pad1 ;
   void *__pad2 ;
   void *__pad3 ;
   void *__pad4 ;
   size_t __pad5 ;
   int _mode ;
   char _unused2[(15UL * sizeof(int ) - 4UL * sizeof(void *)) - sizeof(size_t )] ;
};
typedef struct _IO_FILE _IO_FILE;
typedef __off_t off_t;
typedef __ssize_t ssize_t;
typedef int wchar_t;
typedef __gid_t gid_t;
typedef __uid_t uid_t;
typedef __time_t time_t;
typedef unsigned long ulong;
typedef unsigned int uint;
struct __anonstruct___sigset_t_13 {
   unsigned long __val[1024UL / (8UL * sizeof(unsigned long ))] ;
};
typedef struct __anonstruct___sigset_t_13 __sigset_t;
struct timespec {
   __time_t tv_sec ;
   __syscall_slong_t tv_nsec ;
};
union __anonunion___u_27 {
   long double __l ;
   int __i[3] ;
};
typedef unsigned char zend_bool;
typedef unsigned char zend_uchar;
typedef unsigned int zend_uint;
typedef unsigned long zend_ulong;
typedef unsigned long zend_uintptr_t;
typedef unsigned int zend_object_handle;
struct _zend_object_handlers;
struct _zend_object_handlers;
typedef struct _zend_object_handlers zend_object_handlers;
struct _zend_object_value {
   zend_object_handle handle ;
   zend_object_handlers *handlers ;
};
typedef struct _zend_object_value zend_object_value;
struct _hashtable;
struct _hashtable;
struct _hashtable;
struct bucket {
   ulong h ;
   uint nKeyLength ;
   void *pData ;
   void *pDataPtr ;
   struct bucket *pListNext ;
   struct bucket *pListLast ;
   struct bucket *pNext ;
   struct bucket *pLast ;
   char *arKey ;
};
typedef struct bucket Bucket;
struct _hashtable {
   uint nTableSize ;
   uint nTableMask ;
   uint nNumOfElements ;
   ulong nNextFreeElement ;
   Bucket *pInternalPointer ;
   Bucket *pListHead ;
   Bucket *pListTail ;
   Bucket **arBuckets ;
   void (*pDestructor)(void *pDest ) ;
   zend_bool persistent ;
   unsigned char nApplyCount ;
   zend_bool bApplyProtection ;
};
typedef struct _hashtable HashTable;
typedef Bucket *HashPosition;
struct _HashPointer {
   HashPosition pos ;
   ulong h ;
};
typedef struct _HashPointer HashPointer;
struct _zend_llist_element {
   struct _zend_llist_element *next ;
   struct _zend_llist_element *prev ;
   char data[1] ;
};
typedef struct _zend_llist_element zend_llist_element;
struct _zend_llist {
   zend_llist_element *head ;
   zend_llist_element *tail ;
   size_t count ;
   size_t size ;
   void (*dtor)(void * ) ;
   unsigned char persistent ;
   zend_llist_element *traverse_ptr ;
};
typedef struct _zend_llist zend_llist;
struct _zval_struct;
struct _zval_struct;
typedef struct _zval_struct zval;
struct _zend_class_entry;
struct _zend_class_entry;
typedef struct _zend_class_entry zend_class_entry;
union _zend_function;
union _zend_function;
union _zend_function;
struct _zend_property_info;
struct _zend_property_info;
struct _zend_property_info;
struct _zend_literal;
struct _zend_literal;
struct _zend_literal;
struct _zend_object_handlers {
   void (*add_ref)(zval *object ) ;
   void (*del_ref)(zval *object ) ;
   zend_object_value (*clone_obj)(zval *object ) ;
   zval *(*read_property)(zval *object , zval *member , int type ,
                          struct _zend_literal  const  *key ) ;
   void (*write_property)(zval *object , zval *member , zval *value ,
                          struct _zend_literal  const  *key ) ;
   zval *(*read_dimension)(zval *object , zval *offset , int type ) ;
   void (*write_dimension)(zval *object , zval *offset , zval *value ) ;
   zval **(*get_property_ptr_ptr)(zval *object , zval *member ,
                                  struct _zend_literal  const  *key ) ;
   zval *(*get)(zval *object ) ;
   void (*set)(zval **object , zval *value ) ;
   int (*has_property)(zval *object , zval *member , int has_set_exists ,
                       struct _zend_literal  const  *key ) ;
   void (*unset_property)(zval *object , zval *member ,
                          struct _zend_literal  const  *key ) ;
   int (*has_dimension)(zval *object , zval *member , int check_empty ) ;
   void (*unset_dimension)(zval *object , zval *offset ) ;
   HashTable *(*get_properties)(zval *object ) ;
   union _zend_function *(*get_method)(zval **object_ptr , char *method ,
                                       int method_len ,
                                       struct _zend_literal  const  *key ) ;
   int (*call_method)(char *method , int ht , zval *return_value ,
                      zval **return_value_ptr , zval *this_ptr ,
                      int return_value_used ) ;
   union _zend_function *(*get_constructor)(zval *object ) ;
   zend_class_entry *(*get_class_entry)(zval const   *object ) ;
   int (*get_class_name)(zval const   *object , char **class_name ,
                         zend_uint *class_name_len , int parent ) ;
   int (*compare_objects)(zval *object1 , zval *object2 ) ;
   int (*cast_object)(zval *readobj , zval *retval , int type ) ;
   int (*count_elements)(zval *object , long *count ) ;
   HashTable *(*get_debug_info)(zval *object , int *is_temp ) ;
   int (*get_closure)(zval *obj , zend_class_entry **ce_ptr ,
                      union _zend_function **fptr_ptr , zval **zobj_ptr ) ;
};
struct __anonstruct_str_28 {
   char *val ;
   int len ;
};
union _zvalue_value {
   long lval ;
   double dval ;
   struct __anonstruct_str_28 str ;
   HashTable *ht ;
   zend_object_value obj ;
};
typedef union _zvalue_value zvalue_value;
struct _zval_struct {
   zvalue_value value ;
   zend_uint refcount__gc ;
   zend_uchar type ;
   zend_uchar is_ref__gc ;
};
union _zend_function;
struct _zend_object_iterator;
struct _zend_object_iterator;
typedef struct _zend_object_iterator zend_object_iterator;
struct _zend_object_iterator_funcs {
   void (*dtor)(zend_object_iterator *iter ) ;
   int (*valid)(zend_object_iterator *iter ) ;
   void (*get_current_data)(zend_object_iterator *iter , zval ***data ) ;
   int (*get_current_key)(zend_object_iterator *iter , char **str_key ,
                          uint *str_key_len , ulong *int_key ) ;
   void (*move_forward)(zend_object_iterator *iter ) ;
   void (*rewind)(zend_object_iterator *iter ) ;
   void (*invalidate_current)(zend_object_iterator *iter ) ;
};
typedef struct _zend_object_iterator_funcs zend_object_iterator_funcs;
struct _zend_object_iterator {
   void *data ;
   zend_object_iterator_funcs *funcs ;
   ulong index ;
};
struct _zend_class_iterator_funcs {
   zend_object_iterator_funcs *funcs ;
   union _zend_function *zf_new_iterator ;
   union _zend_function *zf_valid ;
   union _zend_function *zf_current ;
   union _zend_function *zf_key ;
   union _zend_function *zf_next ;
   union _zend_function *zf_rewind ;
};
typedef struct _zend_class_iterator_funcs zend_class_iterator_funcs;
struct _zend_serialize_data;
struct _zend_serialize_data;
struct _zend_serialize_data;
struct _zend_unserialize_data;
struct _zend_unserialize_data;
struct _zend_unserialize_data;
typedef struct _zend_serialize_data zend_serialize_data;
typedef struct _zend_unserialize_data zend_unserialize_data;
struct _zend_trait_method_reference {
   char *method_name ;
   unsigned int mname_len ;
   zend_class_entry *ce ;
   char *class_name ;
   unsigned int cname_len ;
};
typedef struct _zend_trait_method_reference zend_trait_method_reference;
struct _zend_trait_precedence {
   zend_trait_method_reference *trait_method ;
   zend_class_entry **exclude_from_classes ;
   union _zend_function *function ;
};
typedef struct _zend_trait_precedence zend_trait_precedence;
struct _zend_trait_alias {
   zend_trait_method_reference *trait_method ;
   char *alias ;
   unsigned int alias_len ;
   zend_uint modifiers ;
   union _zend_function *function ;
};
typedef struct _zend_trait_alias zend_trait_alias;
struct __anonstruct_user_30 {
   char *filename ;
   zend_uint line_start ;
   zend_uint line_end ;
   char *doc_comment ;
   zend_uint doc_comment_len ;
};
struct _zend_function_entry;
struct _zend_function_entry;
struct _zend_module_entry;
struct _zend_module_entry;
struct __anonstruct_internal_31 {
   struct _zend_function_entry  const  *builtin_functions ;
   struct _zend_module_entry *module ;
};
union __anonunion_info_29 {
   struct __anonstruct_user_30 user ;
   struct __anonstruct_internal_31 internal ;
};
struct _zend_class_entry {
   char type ;
   char const   *name ;
   zend_uint name_length ;
   struct _zend_class_entry *parent ;
   int refcount ;
   zend_uint ce_flags ;
   HashTable function_table ;
   HashTable properties_info ;
   zval **default_properties_table ;
   zval **default_static_members_table ;
   zval **static_members_table ;
   HashTable constants_table ;
   int default_properties_count ;
   int default_static_members_count ;
   union _zend_function *constructor ;
   union _zend_function *destructor ;
   union _zend_function *clone ;
   union _zend_function *__get ;
   union _zend_function *__set ;
   union _zend_function *__unset ;
   union _zend_function *__isset ;
   union _zend_function *__call ;
   union _zend_function *__callstatic ;
   union _zend_function *__tostring ;
   union _zend_function *serialize_func ;
   union _zend_function *unserialize_func ;
   zend_class_iterator_funcs iterator_funcs ;
   zend_object_value (*create_object)(zend_class_entry *class_type ) ;
   zend_object_iterator *(*get_iterator)(zend_class_entry *ce , zval *object ,
                                         int by_ref ) ;
   int (*interface_gets_implemented)(zend_class_entry *iface ,
                                     zend_class_entry *class_type ) ;
   union _zend_function *(*get_static_method)(zend_class_entry *ce ,
                                              char *method , int method_len ) ;
   int (*serialize)(zval *object , unsigned char **buffer , zend_uint *buf_len ,
                    zend_serialize_data *data ) ;
   int (*unserialize)(zval **object , zend_class_entry *ce ,
                      unsigned char const   *buf , zend_uint buf_len ,
                      zend_unserialize_data *data ) ;
   zend_class_entry **interfaces ;
   zend_uint num_interfaces ;
   zend_class_entry **traits ;
   zend_uint num_traits ;
   zend_trait_alias **trait_aliases ;
   zend_trait_precedence **trait_precedences ;
   union __anonunion_info_29 info ;
};
union __anonunion_u_34 {
   zval *pz ;
   zend_object_handlers *handlers ;
};
struct _gc_root_buffer {
   struct _gc_root_buffer *prev ;
   struct _gc_root_buffer *next ;
   zend_object_handle handle ;
   union __anonunion_u_34 u ;
};
typedef struct _gc_root_buffer gc_root_buffer;
struct _zval_gc_info;
union __anonunion_u_35 {
   gc_root_buffer *buffered ;
   struct _zval_gc_info *next ;
};
struct _zval_gc_info {
   zval z ;
   union __anonunion_u_35 u ;
};
typedef struct _zval_gc_info zval_gc_info;
enum __anonenum_zend_error_handling_t_36 {
    EH_NORMAL = 0,
    EH_SUPPRESS = 1,
    EH_THROW = 2
} ;
typedef enum __anonenum_zend_error_handling_t_36 zend_error_handling_t;
struct _zend_op_array;
struct _zend_op_array;
typedef struct _zend_op_array zend_op_array;
struct _zend_op;
struct _zend_op;
typedef struct _zend_op zend_op;
struct _zend_compiler_context {
   zend_uint opcodes_size ;
   int vars_size ;
   int literals_size ;
   int current_brk_cont ;
   int backpatch_count ;
   HashTable *labels ;
};
typedef struct _zend_compiler_context zend_compiler_context;
struct _zend_literal {
   zval constant ;
   zend_ulong hash_value ;
   zend_uint cache_slot ;
};
typedef struct _zend_literal zend_literal;
union _znode_op {
   zend_uint constant ;
   zend_uint var ;
   zend_uint num ;
   zend_ulong hash ;
   zend_uint opline_num ;
   zend_op *jmp_addr ;
   zval *zv ;
   zend_literal *literal ;
   void *ptr ;
};
typedef union _znode_op znode_op;
union __anonunion_u_38 {
   znode_op op ;
   zval constant ;
   zend_op_array *op_array ;
};
struct _znode {
   int op_type ;
   union __anonunion_u_38 u ;
   zend_uint EA ;
};
typedef struct _znode znode;
struct _zend_execute_data;
struct _zend_execute_data;
typedef struct _zend_execute_data zend_execute_data;
struct _zend_op {
   int (*handler)(zend_execute_data *execute_data ) ;
   znode_op op1 ;
   znode_op op2 ;
   znode_op result ;
   ulong extended_value ;
   uint lineno ;
   zend_uchar opcode ;
   zend_uchar op1_type ;
   zend_uchar op2_type ;
   zend_uchar result_type ;
};
struct _zend_brk_cont_element {
   int start ;
   int cont ;
   int brk ;
   int parent ;
};
typedef struct _zend_brk_cont_element zend_brk_cont_element;
struct _zend_try_catch_element {
   zend_uint try_op ;
   zend_uint catch_op ;
};
typedef struct _zend_try_catch_element zend_try_catch_element;
struct _zend_property_info {
   zend_uint flags ;
   char *name ;
   int name_length ;
   ulong h ;
   int offset ;
   char *doc_comment ;
   int doc_comment_len ;
   zend_class_entry *ce ;
};
typedef struct _zend_property_info zend_property_info;
struct _zend_arg_info {
   char const   *name ;
   zend_uint name_len ;
   char const   *class_name ;
   zend_uint class_name_len ;
   zend_uchar type_hint ;
   zend_bool allow_null ;
   zend_bool pass_by_reference ;
};
typedef struct _zend_arg_info zend_arg_info;
struct _zend_compiled_variable {
   char *name ;
   int name_len ;
   ulong hash_value ;
};
typedef struct _zend_compiled_variable zend_compiled_variable;
struct _zend_op_array {
   zend_uchar type ;
   char *function_name ;
   zend_class_entry *scope ;
   zend_uint fn_flags ;
   union _zend_function *prototype ;
   zend_uint num_args ;
   zend_uint required_num_args ;
   zend_arg_info *arg_info ;
   zend_uint *refcount ;
   zend_op *opcodes ;
   zend_uint last ;
   zend_compiled_variable *vars ;
   int last_var ;
   zend_uint T ;
   zend_brk_cont_element *brk_cont_array ;
   int last_brk_cont ;
   zend_try_catch_element *try_catch_array ;
   int last_try_catch ;
   HashTable *static_variables ;
   zend_uint this_var ;
   char *filename ;
   zend_uint line_start ;
   zend_uint line_end ;
   char *doc_comment ;
   zend_uint doc_comment_len ;
   zend_uint early_binding ;
   zend_literal *literals ;
   int last_literal ;
   void **run_time_cache ;
   int last_cache_slot ;
   void *reserved[4] ;
};
struct _zend_internal_function {
   zend_uchar type ;
   char *function_name ;
   zend_class_entry *scope ;
   zend_uint fn_flags ;
   union _zend_function *prototype ;
   zend_uint num_args ;
   zend_uint required_num_args ;
   zend_arg_info *arg_info ;
   void (*handler)(int ht , zval *return_value , zval **return_value_ptr ,
                   zval *this_ptr , int return_value_used ) ;
   struct _zend_module_entry *module ;
};
typedef struct _zend_internal_function zend_internal_function;
struct __anonstruct_common_39 {
   zend_uchar type ;
   char *function_name ;
   zend_class_entry *scope ;
   zend_uint fn_flags ;
   union _zend_function *prototype ;
   zend_uint num_args ;
   zend_uint required_num_args ;
   zend_arg_info *arg_info ;
};
union _zend_function {
   zend_uchar type ;
   struct __anonstruct_common_39 common ;
   zend_op_array op_array ;
   zend_internal_function internal_function ;
};
typedef union _zend_function zend_function;
struct _zend_function_state {
   zend_function *function ;
   void **arguments ;
};
typedef struct _zend_function_state zend_function_state;
union _temp_variable;
union _temp_variable;
union _temp_variable;
struct _zend_execute_data {
   struct _zend_op *opline ;
   zend_function_state function_state ;
   zend_function *fbc ;
   zend_class_entry *called_scope ;
   zend_op_array *op_array ;
   zval *object ;
   union _temp_variable *Ts ;
   zval ***CVs ;
   HashTable *symbol_table ;
   struct _zend_execute_data *prev_execute_data ;
   zval *old_error_reporting ;
   zend_bool nested ;
   zval **original_return_value ;
   zend_class_entry *current_scope ;
   zend_class_entry *current_called_scope ;
   zval *current_this ;
   zval *current_object ;
};
typedef long __jmp_buf[8];
struct __jmp_buf_tag {
   __jmp_buf __jmpbuf ;
   int __mask_was_saved ;
   __sigset_t __saved_mask ;
};
typedef struct __jmp_buf_tag jmp_buf[1];
struct _zend_compiler_globals;
struct _zend_compiler_globals;
struct _zend_executor_globals;
struct _zend_executor_globals;
typedef struct _zend_executor_globals zend_executor_globals;
struct _zend_stack {
   int top ;
   int max ;
   void **elements ;
};
typedef struct _zend_stack zend_stack;
struct _zend_ptr_stack {
   int top ;
   int max ;
   void **elements ;
   void **top_element ;
   zend_bool persistent ;
};
typedef struct _zend_ptr_stack zend_ptr_stack;
struct _store_object {
   void *object ;
   void (*dtor)(void *object , zend_object_handle handle ) ;
   void (*free_storage)(void *object ) ;
   void (*clone)(void *object , void **object_clone ) ;
   zend_object_handlers const   *handlers ;
   zend_uint refcount ;
   gc_root_buffer *buffered ;
};
struct __anonstruct_free_list_40 {
   int next ;
};
union _store_bucket {
   struct _store_object obj ;
   struct __anonstruct_free_list_40 free_list ;
};
struct _zend_object_store_bucket {
   zend_bool destructor_called ;
   zend_bool valid ;
   union _store_bucket bucket ;
};
typedef struct _zend_object_store_bucket zend_object_store_bucket;
struct _zend_objects_store {
   zend_object_store_bucket *object_buckets ;
   zend_uint top ;
   zend_uint size ;
   int free_list_head ;
};
typedef struct _zend_objects_store zend_objects_store;
typedef unsigned short fpu_control_t;
struct _zend_encoding;
struct _zend_encoding;
typedef struct _zend_encoding zend_encoding;
struct _zend_declarables {
   zval ticks ;
};
typedef struct _zend_declarables zend_declarables;
struct _zend_vm_stack;
struct _zend_vm_stack;
typedef struct _zend_vm_stack *zend_vm_stack;
struct _zend_ini_entry;
struct _zend_ini_entry;
typedef struct _zend_ini_entry zend_ini_entry;
struct _zend_ini_parser_param;
struct _zend_ini_parser_param;
struct _zend_compiler_globals {
   zend_stack bp_stack ;
   zend_stack switch_cond_stack ;
   zend_stack foreach_copy_stack ;
   zend_stack object_stack ;
   zend_stack declare_stack ;
   zend_class_entry *active_class_entry ;
   zend_llist list_llist ;
   zend_llist dimension_llist ;
   zend_stack list_stack ;
   zend_stack function_call_stack ;
   char *compiled_filename ;
   int zend_lineno ;
   char *heredoc ;
   int heredoc_len ;
   zend_op_array *active_op_array ;
   HashTable *function_table ;
   HashTable *class_table ;
   HashTable filenames_table ;
   HashTable *auto_globals ;
   zend_bool in_compilation ;
   zend_bool short_tags ;
   zend_bool asp_tags ;
   zend_declarables declarables ;
   zend_bool unclean_shutdown ;
   zend_bool ini_parser_unbuffered_errors ;
   zend_llist open_files ;
   long catch_begin ;
   struct _zend_ini_parser_param *ini_parser_param ;
   int interactive ;
   zend_uint start_lineno ;
   zend_bool increment_lineno ;
   znode implementing_class ;
   zend_uint access_type ;
   char *doc_comment ;
   zend_uint doc_comment_len ;
   zend_uint compiler_options ;
   zval *current_namespace ;
   HashTable *current_import ;
   zend_bool in_namespace ;
   zend_bool has_bracketed_namespaces ;
   zend_compiler_context context ;
   zend_stack context_stack ;
   char *interned_strings_start ;
   char *interned_strings_end ;
   char *interned_strings_top ;
   char *interned_strings_snapshot_top ;
   HashTable interned_strings ;
   zend_encoding const   **script_encoding_list ;
   size_t script_encoding_list_size ;
   zend_bool multibyte ;
   zend_bool detect_unicode ;
   zend_bool encoding_declared ;
};
struct _zend_executor_globals {
   zval **return_value_ptr_ptr ;
   zval uninitialized_zval ;
   zval *uninitialized_zval_ptr ;
   zval error_zval ;
   zval *error_zval_ptr ;
   zend_ptr_stack arg_types_stack ;
   HashTable *symtable_cache[32] ;
   HashTable **symtable_cache_limit ;
   HashTable **symtable_cache_ptr ;
   zend_op **opline_ptr ;
   HashTable *active_symbol_table ;
   HashTable symbol_table ;
   HashTable included_files ;
   jmp_buf *bailout ;
   int error_reporting ;
   int orig_error_reporting ;
   int exit_status ;
   zend_op_array *active_op_array ;
   HashTable *function_table ;
   HashTable *class_table ;
   HashTable *zend_constants ;
   zend_class_entry *scope ;
   zend_class_entry *called_scope ;
   zval *This ;
   long precision ;
   int ticks_count ;
   zend_bool in_execution ;
   HashTable *in_autoload ;
   zend_function *autoload_func ;
   zend_bool full_tables_cleanup ;
   zend_bool no_extensions ;
   HashTable regular_list ;
   HashTable persistent_list ;
   zend_vm_stack argument_stack ;
   int user_error_handler_error_reporting ;
   zval *user_error_handler ;
   zval *user_exception_handler ;
   zend_stack user_error_handlers_error_reporting ;
   zend_ptr_stack user_error_handlers ;
   zend_ptr_stack user_exception_handlers ;
   zend_error_handling_t error_handling ;
   zend_class_entry *exception_class ;
   int timeout_seconds ;
   int lambda_count ;
   HashTable *ini_directives ;
   HashTable *modified_ini_directives ;
   zend_ini_entry *error_reporting_ini_entry ;
   zend_objects_store objects_store ;
   zval *exception ;
   zval *prev_exception ;
   zend_op *opline_before_exception ;
   zend_op exception_op[3] ;
   struct _zend_execute_data *current_execute_data ;
   struct _zend_module_entry *current_module ;
   zend_property_info std_property_info ;
   zend_bool active ;
   zend_op *start_op ;
   void *saved_fpu_cw_ptr ;
   fpu_control_t saved_fpu_cw ;
   void *reserved[4] ;
};
struct _zend_ini_entry;
typedef struct _zend_module_entry zend_module_entry;
struct _zend_module_dep;
struct _zend_module_dep;
struct _zend_module_entry {
   unsigned short size ;
   unsigned int zend_api ;
   unsigned char zend_debug ;
   unsigned char zts ;
   struct _zend_ini_entry  const  *ini_entry ;
   struct _zend_module_dep  const  *deps ;
   char const   *name ;
   struct _zend_function_entry  const  *functions ;
   int (*module_startup_func)(int type , int module_number ) ;
   int (*module_shutdown_func)(int type , int module_number ) ;
   int (*request_startup_func)(int type , int module_number ) ;
   int (*request_shutdown_func)(int type , int module_number ) ;
   void (*info_func)(zend_module_entry *zend_module ) ;
   char const   *version ;
   size_t globals_size ;
   void *globals_ptr ;
   void (*globals_ctor)(void *global ) ;
   void (*globals_dtor)(void *global ) ;
   int (*post_deactivate_func)(void) ;
   int module_started ;
   unsigned char type ;
   void *handle ;
   int module_number ;
   char const   *build_id ;
};
struct _zend_module_dep {
   char const   *name ;
   char const   *rel ;
   char const   *version ;
   unsigned char type ;
};
struct __anonstruct_var_41 {
   zval **ptr_ptr ;
   zval *ptr ;
   zend_bool fcall_returned_reference ;
};
struct __anonstruct_str_offset_42 {
   zval **ptr_ptr ;
   zval *str ;
   zend_uint offset ;
};
struct __anonstruct_fe_43 {
   zval **ptr_ptr ;
   zval *ptr ;
   HashPointer fe_pos ;
};
union _temp_variable {
   zval tmp_var ;
   struct __anonstruct_var_41 var ;
   struct __anonstruct_str_offset_42 str_offset ;
   struct __anonstruct_fe_43 fe ;
   zend_class_entry *class_entry ;
};
struct _zend_vm_stack {
   void **top ;
   void **end ;
   zend_vm_stack prev ;
};
struct _zend_function_entry {
   char const   *fname ;
   void (*handler)(int ht , zval *return_value , zval **return_value_ptr ,
                   zval *this_ptr , int return_value_used ) ;
   struct _zend_arg_info  const  *arg_info ;
   zend_uint num_args ;
   zend_uint flags ;
};
typedef struct _zend_function_entry zend_function_entry;
struct _zend_fcall_info {
   size_t size ;
   HashTable *function_table ;
   zval *function_name ;
   HashTable *symbol_table ;
   zval **retval_ptr_ptr ;
   zend_uint param_count ;
   zval ***params ;
   zval *object_ptr ;
   zend_bool no_separation ;
};
typedef struct _zend_fcall_info zend_fcall_info;
struct _zend_fcall_info_cache {
   zend_bool initialized ;
   zend_function *function_handler ;
   zend_class_entry *calling_scope ;
   zend_class_entry *called_scope ;
   zval *object_ptr ;
};
typedef struct _zend_fcall_info_cache zend_fcall_info_cache;
typedef __socklen_t socklen_t;
struct stat {
   __dev_t st_dev ;
   __ino_t st_ino ;
   __nlink_t st_nlink ;
   __mode_t st_mode ;
   __uid_t st_uid ;
   __gid_t st_gid ;
   int __pad0 ;
   __dev_t st_rdev ;
   __off_t st_size ;
   __blksize_t st_blksize ;
   __blkcnt_t st_blocks ;
   struct timespec st_atim ;
   struct timespec st_mtim ;
   struct timespec st_ctim ;
   __syscall_slong_t __glibc_reserved[3] ;
};
struct _php_stream;
struct _php_stream;
typedef struct _php_stream php_stream;
struct _php_stream_wrapper;
struct _php_stream_wrapper;
typedef struct _php_stream_wrapper php_stream_wrapper;
struct _php_stream_context;
struct _php_stream_context;
typedef struct _php_stream_context php_stream_context;
struct _php_stream_filter;
struct _php_stream_filter;
typedef struct _php_stream_filter php_stream_filter;
struct _php_stream_notifier;
struct _php_stream_notifier;
typedef struct _php_stream_notifier php_stream_notifier;
struct _php_stream_notifier {
   void (*func)(php_stream_context *context , int notifycode , int severity ,
                char *xmsg , int xcode , size_t bytes_sofar , size_t bytes_max ,
                void *ptr ) ;
   void (*dtor)(php_stream_notifier *notifier ) ;
   void *ptr ;
   int mask ;
   size_t progress ;
   size_t progress_max ;
};
struct _php_stream_context {
   php_stream_notifier *notifier ;
   zval *options ;
   zval *links ;
   int rsrc_id ;
};
struct _php_stream_bucket;
struct _php_stream_bucket;
typedef struct _php_stream_bucket php_stream_bucket;
struct _php_stream_bucket_brigade;
struct _php_stream_bucket_brigade;
typedef struct _php_stream_bucket_brigade php_stream_bucket_brigade;
struct _php_stream_bucket {
   php_stream_bucket *next ;
   php_stream_bucket *prev ;
   php_stream_bucket_brigade *brigade ;
   char *buf ;
   size_t buflen ;
   int own_buf ;
   int is_persistent ;
   int refcount ;
};
struct _php_stream_bucket_brigade {
   php_stream_bucket *head ;
   php_stream_bucket *tail ;
};
enum __anonenum_php_stream_filter_status_t_75 {
    PSFS_ERR_FATAL = 0,
    PSFS_FEED_ME = 1,
    PSFS_PASS_ON = 2
} ;
typedef enum __anonenum_php_stream_filter_status_t_75 php_stream_filter_status_t;
struct _php_stream_filter_ops {
   php_stream_filter_status_t (*filter)(php_stream *stream ,
                                        php_stream_filter *thisfilter ,
                                        php_stream_bucket_brigade *buckets_in ,
                                        php_stream_bucket_brigade *buckets_out ,
                                        size_t *bytes_consumed , int flags ) ;
   void (*dtor)(php_stream_filter *thisfilter ) ;
   char const   *label ;
};
typedef struct _php_stream_filter_ops php_stream_filter_ops;
struct _php_stream_filter_chain {
   php_stream_filter *head ;
   php_stream_filter *tail ;
   php_stream *stream ;
};
typedef struct _php_stream_filter_chain php_stream_filter_chain;
struct _php_stream_filter {
   php_stream_filter_ops *fops ;
   void *abstract ;
   php_stream_filter *next ;
   php_stream_filter *prev ;
   int is_persistent ;
   php_stream_filter_chain *chain ;
   php_stream_bucket_brigade buffer ;
   int rsrc_id ;
};
struct _php_stream_statbuf {
   struct stat sb ;
};
typedef struct _php_stream_statbuf php_stream_statbuf;
struct _php_stream_ops {
   size_t (*write)(php_stream *stream , char const   *buf , size_t count ) ;
   size_t (*read)(php_stream *stream , char *buf , size_t count ) ;
   int (*close)(php_stream *stream , int close_handle ) ;
   int (*flush)(php_stream *stream ) ;
   char const   *label ;
   int (*seek)(php_stream *stream , off_t offset , int whence ,
               off_t *newoffset ) ;
   int (*cast)(php_stream *stream , int castas , void **ret ) ;
   int (*stat)(php_stream *stream , php_stream_statbuf *ssb ) ;
   int (*set_option)(php_stream *stream , int option , int value ,
                     void *ptrparam ) ;
};
typedef struct _php_stream_ops php_stream_ops;
struct _php_stream_wrapper_ops {
   php_stream *(*stream_opener)(php_stream_wrapper *wrapper , char *filename ,
                                char *mode , int options , char **opened_path ,
                                php_stream_context *context ) ;
   int (*stream_closer)(php_stream_wrapper *wrapper , php_stream *stream ) ;
   int (*stream_stat)(php_stream_wrapper *wrapper , php_stream *stream ,
                      php_stream_statbuf *ssb ) ;
   int (*url_stat)(php_stream_wrapper *wrapper , char *url , int flags ,
                   php_stream_statbuf *ssb , php_stream_context *context ) ;
   php_stream *(*dir_opener)(php_stream_wrapper *wrapper , char *filename ,
                             char *mode , int options , char **opened_path ,
                             php_stream_context *context ) ;
   char const   *label ;
   int (*unlink)(php_stream_wrapper *wrapper , char *url , int options ,
                 php_stream_context *context ) ;
   int (*rename)(php_stream_wrapper *wrapper , char *url_from , char *url_to ,
                 int options , php_stream_context *context ) ;
   int (*stream_mkdir)(php_stream_wrapper *wrapper , char *url , int mode ,
                       int options , php_stream_context *context ) ;
   int (*stream_rmdir)(php_stream_wrapper *wrapper , char *url , int options ,
                       php_stream_context *context ) ;
};
typedef struct _php_stream_wrapper_ops php_stream_wrapper_ops;
struct _php_stream_wrapper {
   php_stream_wrapper_ops *wops ;
   void *abstract ;
   int is_url ;
   int err_count ;
   char **err_stack ;
};
struct _php_stream {
   php_stream_ops *ops ;
   void *abstract ;
   php_stream_filter_chain readfilters ;
   php_stream_filter_chain writefilters ;
   php_stream_wrapper *wrapper ;
   void *wrapperthis ;
   zval *wrapperdata ;
   int fgetss_state ;
   int is_persistent ;
   char mode[16] ;
   int rsrc_id ;
   int in_free ;
   int fclose_stdiocast ;
   FILE *stdiocast ;
   char *orig_path ;
   php_stream_context *context ;
   int flags ;
   off_t position ;
   unsigned char *readbuf ;
   size_t readbuflen ;
   off_t readpos ;
   off_t writepos ;
   size_t chunk_size ;
   int eof ;
   struct _php_stream *enclosing_stream ;
};
struct iovec {
   void *iov_base ;
   size_t iov_len ;
};
typedef unsigned short sa_family_t;
struct sockaddr {
   sa_family_t sa_family ;
   char sa_data[14] ;
};
struct msghdr {
   void *msg_name ;
   socklen_t msg_namelen ;
   struct iovec *msg_iov ;
   size_t msg_iovlen ;
   void *msg_control ;
   size_t msg_controllen ;
   int msg_flags ;
};
struct cmsghdr {
   size_t cmsg_len ;
   int cmsg_level ;
   int cmsg_type ;
   unsigned char __cmsg_data[] ;
};
struct _php_core_globals;
struct _php_core_globals;
struct _arg_separators {
   char *output ;
   char *input ;
};
typedef struct _arg_separators arg_separators;
struct _php_core_globals {
   zend_bool magic_quotes_gpc ;
   zend_bool magic_quotes_runtime ;
   zend_bool magic_quotes_sybase ;
   zend_bool implicit_flush ;
   long output_buffering ;
   zend_bool sql_safe_mode ;
   zend_bool enable_dl ;
   char *output_handler ;
   char *unserialize_callback_func ;
   long serialize_precision ;
   long memory_limit ;
   long max_input_time ;
   zend_bool track_errors ;
   zend_bool display_errors ;
   zend_bool display_startup_errors ;
   zend_bool log_errors ;
   long log_errors_max_len ;
   zend_bool ignore_repeated_errors ;
   zend_bool ignore_repeated_source ;
   zend_bool report_memleaks ;
   char *error_log ;
   char *doc_root ;
   char *user_dir ;
   char *include_path ;
   char *open_basedir ;
   char *extension_dir ;
   char *upload_tmp_dir ;
   long upload_max_filesize ;
   char *error_append_string ;
   char *error_prepend_string ;
   char *auto_prepend_file ;
   char *auto_append_file ;
   arg_separators arg_separator ;
   char *variables_order ;
   HashTable rfc1867_protected_variables ;
   short connection_status ;
   short ignore_user_abort ;
   unsigned char header_is_being_sent ;
   zend_llist tick_functions ;
   zval *http_globals[6] ;
   zend_bool expose_php ;
   zend_bool register_argc_argv ;
   zend_bool auto_globals_jit ;
   char *docref_root ;
   char *docref_ext ;
   zend_bool html_errors ;
   zend_bool xmlrpc_errors ;
   long xmlrpc_error_number ;
   zend_bool activated_auto_globals[8] ;
   zend_bool modules_activated ;
   zend_bool file_uploads ;
   zend_bool during_request_startup ;
   zend_bool allow_url_fopen ;
   zend_bool enable_post_data_reading ;
   zend_bool always_populate_raw_post_data ;
   zend_bool report_zend_debug ;
   int last_error_type ;
   char *last_error_message ;
   char *last_error_file ;
   int last_error_lineno ;
   char *disable_functions ;
   char *disable_classes ;
   zend_bool allow_url_include ;
   zend_bool exit_on_timeout ;
   long max_input_nesting_level ;
   zend_bool in_user_include ;
   char *user_ini_filename ;
   long user_ini_cache_ttl ;
   char *request_order ;
   zend_bool mail_x_header ;
   char *mail_log ;
   zend_bool in_error_log ;
};
struct _zend_ini_entry {
   int module_number ;
   int modifiable ;
   char *name ;
   uint name_length ;
   int (*on_modify)(zend_ini_entry *entry , char *new_value ,
                    uint new_value_length , void *mh_arg1 , void *mh_arg2 ,
                    void *mh_arg3 , int stage ) ;
   void *mh_arg1 ;
   void *mh_arg2 ;
   void *mh_arg3 ;
   char *value ;
   uint value_length ;
   char *orig_value ;
   uint orig_value_length ;
   int orig_modifiable ;
   int modified ;
   void (*displayer)(zend_ini_entry *ini_entry , int type ) ;
};
struct _zend_ini_parser_param {
   void (*ini_parser_cb)(zval *arg1 , zval *arg2 , zval *arg3 ,
                         int callback_type , void *arg ) ;
   void *arg ;
};
typedef unsigned int wint_t;
typedef __mbstate_t mbstate_t;
struct __anonstruct_smart_str_91 {
   char *c ;
   size_t len ;
   size_t a ;
};
typedef struct __anonstruct_smart_str_91 smart_str;
struct __anonstruct_url_adapt_state_ex_t_92 {
   smart_str tag ;
   smart_str arg ;
   smart_str val ;
   smart_str buf ;
   smart_str result ;
   smart_str form_app ;
   smart_str url_app ;
   int active ;
   char *lookup_data ;
   int state ;
   HashTable *tags ;
};
typedef struct __anonstruct_url_adapt_state_ex_t_92 url_adapt_state_ex_t;
typedef unsigned int php_uint32;
struct __anonstruct_serialize_93 {
   void *var_hash ;
   unsigned int level ;
};
struct __anonstruct_unserialize_94 {
   void *var_hash ;
   unsigned int level ;
};
struct _php_basic_globals {
   HashTable *user_shutdown_function_names ;
   HashTable putenv_ht ;
   zval *strtok_zval ;
   char *strtok_string ;
   char *locale_string ;
   char *strtok_last ;
   char strtok_table[256] ;
   ulong strtok_len ;
   char str_ebuf[40] ;
   zend_fcall_info array_walk_fci ;
   zend_fcall_info_cache array_walk_fci_cache ;
   zend_fcall_info user_compare_fci ;
   zend_fcall_info_cache user_compare_fci_cache ;
   zend_llist *user_tick_functions ;
   zval *active_ini_file_section ;
   long page_uid ;
   long page_gid ;
   long page_inode ;
   time_t page_mtime ;
   char *CurrentStatFile ;
   char *CurrentLStatFile ;
   php_stream_statbuf ssb ;
   php_stream_statbuf lssb ;
   php_uint32 state[625] ;
   php_uint32 *next ;
   int left ;
   unsigned int rand_seed ;
   zend_bool rand_is_seeded ;
   zend_bool mt_rand_is_seeded ;
   char *syslog_device ;
   zend_class_entry *incomplete_class ;
   struct __anonstruct_serialize_93 serialize ;
   struct __anonstruct_unserialize_94 unserialize ;
   url_adapt_state_ex_t url_adapt_state_ex ;
   void *mmap_file ;
   size_t mmap_len ;
   HashTable *user_filter_map ;
   int umask ;
};
typedef struct _php_basic_globals php_basic_globals;
struct lconv;
struct lconv;
struct __anonstruct_sapi_header_struct_96 {
   char *header ;
   uint header_len ;
};
typedef struct __anonstruct_sapi_header_struct_96 sapi_header_struct;
struct __anonstruct_sapi_headers_struct_97 {
   zend_llist headers ;
   int http_response_code ;
   unsigned char send_default_content_type ;
   char *mimetype ;
   char *http_status_line ;
};
typedef struct __anonstruct_sapi_headers_struct_97 sapi_headers_struct;
struct _sapi_module_struct;
struct _sapi_module_struct;
typedef struct _sapi_module_struct sapi_module_struct;
enum __anonenum_sapi_header_op_enum_100 {
    SAPI_HEADER_REPLACE = 0,
    SAPI_HEADER_ADD = 1,
    SAPI_HEADER_DELETE = 2,
    SAPI_HEADER_DELETE_ALL = 3,
    SAPI_HEADER_SET_STATUS = 4
} ;
typedef enum __anonenum_sapi_header_op_enum_100 sapi_header_op_enum;
struct _sapi_module_struct {
   char *name ;
   char *pretty_name ;
   int (*startup)(struct _sapi_module_struct *sapi_module ) ;
   int (*shutdown)(struct _sapi_module_struct *sapi_module ) ;
   int (*activate)(void) ;
   int (*deactivate)(void) ;
   int (*ub_write)(char const   *str , unsigned int str_length ) ;
   void (*flush)(void *server_context ) ;
   struct stat *(*get_stat)(void) ;
   char *(*getenv)(char *name , size_t name_len ) ;
   void (*sapi_error)(int type , char const   *error_msg  , ...) ;
   int (*header_handler)(sapi_header_struct *sapi_header ,
                         sapi_header_op_enum op ,
                         sapi_headers_struct *sapi_headers ) ;
   int (*send_headers)(sapi_headers_struct *sapi_headers ) ;
   void (*send_header)(sapi_header_struct *sapi_header , void *server_context ) ;
   int (*read_post)(char *buffer , uint count_bytes ) ;
   char *(*read_cookies)(void) ;
   void (*register_server_variables)(zval *track_vars_array ) ;
   void (*log_message)(char *message ) ;
   time_t (*get_request_time)(void) ;
   void (*terminate_process)(void) ;
   char *php_ini_path_override ;
   void (*block_interruptions)(void) ;
   void (*unblock_interruptions)(void) ;
   void (*default_post_reader)(void) ;
   void (*treat_data)(int arg , char *str , zval *destArray ) ;
   char *executable_location ;
   int php_ini_ignore ;
   int php_ini_ignore_cwd ;
   int (*get_fd)(int *fd ) ;
   int (*force_http_10)(void) ;
   int (*get_target_uid)(uid_t * ) ;
   int (*get_target_gid)(gid_t * ) ;
   unsigned int (*input_filter)(int arg , char *var , char **val ,
                                unsigned int val_len ,
                                unsigned int *new_val_len ) ;
   void (*ini_defaults)(HashTable *configuration_hash ) ;
   int phpinfo_as_text ;
   char *ini_entries ;
   zend_function_entry const   *additional_functions ;
   unsigned int (*input_filter_init)(void) ;
};
struct lconv {
   char *decimal_point ;
   char *thousands_sep ;
   char *grouping ;
   char *int_curr_symbol ;
   char *currency_symbol ;
   char *mon_decimal_point ;
   char *mon_thousands_sep ;
   char *mon_grouping ;
   char *positive_sign ;
   char *negative_sign ;
   char int_frac_digits ;
   char frac_digits ;
   char p_cs_precedes ;
   char p_sep_by_space ;
   char n_cs_precedes ;
   char n_sep_by_space ;
   char p_sign_posn ;
   char n_sign_posn ;
   char int_p_cs_precedes ;
   char int_p_sep_by_space ;
   char int_n_cs_precedes ;
   char int_n_sep_by_space ;
   char int_p_sign_posn ;
   char int_n_sign_posn ;
};
typedef int nl_item;
extern int __uflow(_IO_FILE * ) ;
extern int __overflow(_IO_FILE * , int  ) ;
extern int _IO_getc(_IO_FILE *__fp ) ;
extern int _IO_putc(int __c , _IO_FILE *__fp ) ;
extern struct _IO_FILE *stdin ;
extern struct _IO_FILE *stdout ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) fprintf)(FILE * __restrict  __stream ,
                             char const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) printf)(char const   * __restrict  __fmt  , ...) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) sprintf)(char * __restrict  __s ,
                                             char const   * __restrict  __fmt 
                                             , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vfprintf)(FILE * __restrict  __stream ,
                              char const   * __restrict  __fmt ,
                              __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vprintf)(char const   * __restrict  __fmt ,
                             __gnuc_va_list __ap ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) vsprintf)(char * __restrict  __s ,
                                              char const   * __restrict  __fmt ,
                                              __gnuc_va_list __ap ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) snprintf)(char * __restrict  __s ,
                              size_t __n , char const   * __restrict  __fmt 
                              , ...) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) vsnprintf)(char * __restrict  __s ,
                               size_t __n , char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vdprintf)(int __fd , char const   * __restrict  __fmt ,
                              __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) dprintf)(int __fd , char const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  getchar(void) ;
__inline extern int __attribute__((__gnu_inline__))  getc_unlocked(FILE *__fp ) ;
__inline extern int __attribute__((__gnu_inline__))  getchar_unlocked(void) ;
__inline extern int __attribute__((__gnu_inline__))  fgetc_unlocked(FILE *__fp ) ;
__inline extern int __attribute__((__gnu_inline__))  putchar(int __c ) ;
__inline extern int __attribute__((__gnu_inline__))  fputc_unlocked(int __c ,
                                                                    FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  putc_unlocked(int __c ,
                                                                   FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  putchar_unlocked(int __c ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) fgets)(char * __restrict  __s , int __n ,
                                           FILE * __restrict  __stream ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) fread)(void * __restrict  __ptr ,
                                           size_t __size , size_t __n ,
                                           FILE * __restrict  __stream ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fread_unlocked)(void * __restrict  __ptr ,
                                    size_t __size , size_t __n ,
                                    FILE * __restrict  __stream ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) feof_unlocked)(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) ferror_unlocked)(FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  getchar(void) 
{ 
  int tmp ;

  {
  tmp = _IO_getc(stdin);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  fgetc_unlocked(FILE *__fp ) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  tmp___3 = __builtin_expect((long )((unsigned long )__fp->_IO_read_ptr >= (unsigned long )__fp->_IO_read_end),
                             0L);
  if (tmp___3) {
    tmp___0 = __uflow(__fp);
    tmp___2 = tmp___0;
  } else {
    tmp___1 = __fp->_IO_read_ptr;
    (__fp->_IO_read_ptr) ++;
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
__inline extern int __attribute__((__gnu_inline__))  getc_unlocked(FILE *__fp ) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  tmp___3 = __builtin_expect((long )((unsigned long )__fp->_IO_read_ptr >= (unsigned long )__fp->_IO_read_end),
                             0L);
  if (tmp___3) {
    tmp___0 = __uflow(__fp);
    tmp___2 = tmp___0;
  } else {
    tmp___1 = __fp->_IO_read_ptr;
    (__fp->_IO_read_ptr) ++;
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
__inline extern int __attribute__((__gnu_inline__))  getchar_unlocked(void) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  tmp___3 = __builtin_expect((long )((unsigned long )stdin->_IO_read_ptr >= (unsigned long )stdin->_IO_read_end),
                             0L);
  if (tmp___3) {
    tmp___0 = __uflow(stdin);
    tmp___2 = tmp___0;
  } else {
    tmp___1 = stdin->_IO_read_ptr;
    (stdin->_IO_read_ptr) ++;
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
__inline extern int __attribute__((__gnu_inline__))  putchar(int __c ) 
{ 
  int tmp ;

  {
  tmp = _IO_putc(__c, stdout);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  fputc_unlocked(int __c ,
                                                                    FILE *__stream ) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  tmp___4 = __builtin_expect((long )((unsigned long )__stream->_IO_write_ptr >= (unsigned long )__stream->_IO_write_end),
                             0L);
  if (tmp___4) {
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    tmp___3 = tmp___0;
  } else {
    tmp___1 = __stream->_IO_write_ptr;
    (__stream->_IO_write_ptr) ++;
    tmp___2 = (char )__c;
    *tmp___1 = tmp___2;
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___3);
}
}
__inline extern int __attribute__((__gnu_inline__))  putc_unlocked(int __c ,
                                                                   FILE *__stream ) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  tmp___4 = __builtin_expect((long )((unsigned long )__stream->_IO_write_ptr >= (unsigned long )__stream->_IO_write_end),
                             0L);
  if (tmp___4) {
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    tmp___3 = tmp___0;
  } else {
    tmp___1 = __stream->_IO_write_ptr;
    (__stream->_IO_write_ptr) ++;
    tmp___2 = (char )__c;
    *tmp___1 = tmp___2;
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___3);
}
}
__inline extern int __attribute__((__gnu_inline__))  putchar_unlocked(int __c ) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  tmp___4 = __builtin_expect((long )((unsigned long )stdout->_IO_write_ptr >= (unsigned long )stdout->_IO_write_end),
                             0L);
  if (tmp___4) {
    tmp___0 = __overflow(stdout, (int )((unsigned char )__c));
    tmp___3 = tmp___0;
  } else {
    tmp___1 = stdout->_IO_write_ptr;
    (stdout->_IO_write_ptr) ++;
    tmp___2 = (char )__c;
    *tmp___1 = tmp___2;
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___3);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) feof_unlocked)(FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) feof_unlocked)(FILE *__stream ) 
{ 


  {
  return ((int __attribute__((__gnu_inline__))  )((__stream->_flags & 16) != 0));
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) ferror_unlocked)(FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) ferror_unlocked)(FILE *__stream ) 
{ 


  {
  return ((int __attribute__((__gnu_inline__))  )((__stream->_flags & 32) != 0));
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) sprintf)(char * __restrict  __s ,
                                             char const   * __restrict  __fmt 
                                             , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) sprintf)(char * __restrict  __s ,
                                             char const   * __restrict  __fmt 
                                             , ...) 
{ 
  unsigned long tmp ;
  int tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__s, 1);
  tmp___0 = __builtin___sprintf_chk((char *)__s, 1, tmp, (char const   *)__fmt,
                                    __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) vsprintf)(char * __restrict  __s ,
                                              char const   * __restrict  __fmt ,
                                              __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) vsprintf)(char * __restrict  __s ,
                                              char const   * __restrict  __fmt ,
                                              __gnuc_va_list __ap ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__s, 1);
  tmp___0 = __builtin___vsprintf_chk((char *)__s, 1, tmp, (char const   *)__fmt,
                                     __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) snprintf)(char * __restrict  __s ,
                              size_t __n , char const   * __restrict  __fmt 
                              , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) snprintf)(char * __restrict  __s ,
                              size_t __n , char const   * __restrict  __fmt 
                              , ...) 
{ 
  unsigned long tmp ;
  int tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__s, 1);
  tmp___0 = __builtin___snprintf_chk((char *)__s, __n, 1, tmp,
                                     (char const   *)__fmt,
                                     __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) vsnprintf)(char * __restrict  __s ,
                               size_t __n , char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) vsnprintf)(char * __restrict  __s ,
                               size_t __n , char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__s, 1);
  tmp___0 = __builtin___vsnprintf_chk((char *)__s, __n, 1, tmp,
                                      (char const   *)__fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
extern int __fprintf_chk(FILE * __restrict  __stream , int __flag ,
                         char const   * __restrict  __format  , ...) ;
extern int __printf_chk(int __flag , char const   * __restrict  __format  , ...) ;
extern int __vfprintf_chk(FILE * __restrict  __stream , int __flag ,
                          char const   * __restrict  __format ,
                          __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) fprintf)(FILE * __restrict  __stream ,
                             char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __fprintf_chk(__stream, 1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) printf)(char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __printf_chk(1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vprintf)(char const   * __restrict  __fmt ,
                             __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __vfprintf_chk((FILE */* __restrict  */)stdout, 1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vfprintf)(FILE * __restrict  __stream ,
                              char const   * __restrict  __fmt ,
                              __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __vfprintf_chk(__stream, 1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
extern int __dprintf_chk(int __fd , int __flag ,
                         char const   * __restrict  __fmt  , ...) ;
extern int __vdprintf_chk(int __fd , int __flag ,
                          char const   * __restrict  __fmt ,
                          __gnuc_va_list __arg ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) dprintf)(int __fd , char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __dprintf_chk(__fd, 1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vdprintf)(int __fd , char const   * __restrict  __fmt ,
                              __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __vdprintf_chk(__fd, 1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
extern char *( __attribute__((__warn_unused_result__)) __fgets_chk)(char * __restrict  __s ,
                                                                    size_t __size ,
                                                                    int __n ,
                                                                    FILE * __restrict  __stream ) ;
extern char *( __attribute__((__warn_unused_result__)) __fgets_alias)(char * __restrict  __s ,
                                                                      int __n ,
                                                                      FILE * __restrict  __stream )  __asm__("fgets")  ;
extern char *( __attribute__((__warn_unused_result__)) __fgets_chk_warn)(char * __restrict  __s ,
                                                                         size_t __size ,
                                                                         int __n ,
                                                                         FILE * __restrict  __stream )  __asm__("__fgets_chk") __attribute__((__warning__("fgets called with bigger size than length of destination buffer"))) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) fgets)(char * __restrict  __s , int __n ,
                                           FILE * __restrict  __stream ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  char *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__s, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s, 1);
    tmp___0 = __fgets_chk(__s, tmp, __n, __stream);
    return ((char __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__s, 1);
    if ((size_t )__n > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__s, 1);
      tmp___2 = __fgets_chk_warn(__s, tmp___1, __n, __stream);
      return ((char __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __fgets_alias(__s, __n, __stream);
  return ((char __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern size_t ( __attribute__((__warn_unused_result__)) __fread_chk)(void * __restrict  __ptr ,
                                                                     size_t __ptrlen ,
                                                                     size_t __size ,
                                                                     size_t __n ,
                                                                     FILE * __restrict  __stream ) ;
extern size_t ( __attribute__((__warn_unused_result__)) __fread_alias)(void * __restrict  __ptr ,
                                                                       size_t __size ,
                                                                       size_t __n ,
                                                                       FILE * __restrict  __stream )  __asm__("fread")  ;
extern size_t ( __attribute__((__warn_unused_result__)) __fread_chk_warn)(void * __restrict  __ptr ,
                                                                          size_t __ptrlen ,
                                                                          size_t __size ,
                                                                          size_t __n ,
                                                                          FILE * __restrict  __stream )  __asm__("__fread_chk") __attribute__((__warning__("fread called with bigger size * nmemb than length of destination buffer"))) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) fread)(void * __restrict  __ptr ,
                                           size_t __size , size_t __n ,
                                           FILE * __restrict  __stream ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__ptr, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__ptr, 0);
    tmp___0 = __fread_chk(__ptr, tmp, __size, __n, __stream);
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__ptr, 0);
    if (__size * __n > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__ptr, 0);
      tmp___2 = __fread_chk_warn(__ptr, tmp___1, __size, __n, __stream);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __fread_alias(__ptr, __size, __n, __stream);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern size_t ( __attribute__((__warn_unused_result__)) __fread_unlocked_chk)(void * __restrict  __ptr ,
                                                                              size_t __ptrlen ,
                                                                              size_t __size ,
                                                                              size_t __n ,
                                                                              FILE * __restrict  __stream ) ;
extern size_t ( __attribute__((__warn_unused_result__)) __fread_unlocked_alias)(void * __restrict  __ptr ,
                                                                                size_t __size ,
                                                                                size_t __n ,
                                                                                FILE * __restrict  __stream )  __asm__("fread_unlocked")  ;
extern size_t ( __attribute__((__warn_unused_result__)) __fread_unlocked_chk_warn)(void * __restrict  __ptr ,
                                                                                   size_t __ptrlen ,
                                                                                   size_t __size ,
                                                                                   size_t __n ,
                                                                                   FILE * __restrict  __stream )  __asm__("__fread_unlocked_chk") __attribute__((__warning__("fread_unlocked called with bigger size * nmemb than length of destination buffer"))) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fread_unlocked)(void * __restrict  __ptr ,
                                    size_t __size , size_t __n ,
                                    FILE * __restrict  __stream ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___11 ;

  {
  tmp___4 = __builtin_object_size((void *)__ptr, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__ptr, 0);
    tmp___0 = __fread_unlocked_chk(__ptr, tmp, __size, __n, __stream);
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__ptr, 0);
    if (__size * __n > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__ptr, 0);
      tmp___2 = __fread_unlocked_chk_warn(__ptr, tmp___1, __size, __n, __stream);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___11 = __fread_unlocked_alias(__ptr, __size, __n, __stream);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___11);
}
}
__inline extern  __attribute__((__nothrow__)) double __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atof)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atoi)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atol)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) long long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atoll)(char const   *__nptr )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) double ( __attribute__((__nonnull__(1),
__leaf__)) strtod)(char const   * __restrict  __nptr ,
                   char ** __restrict  __endptr ) ;
extern  __attribute__((__nothrow__)) long ( __attribute__((__nonnull__(1),
__leaf__)) strtol)(char const   * __restrict  __nptr ,
                   char ** __restrict  __endptr , int __base ) ;
extern  __attribute__((__nothrow__)) long long ( __attribute__((__nonnull__(1),
__leaf__)) strtoll)(char const   * __restrict  __nptr ,
                    char ** __restrict  __endptr , int __base ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atoi)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) atoi)(char const   *__nptr ) 
{ 
  long tmp ;

  {
  tmp = strtol((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)), 10);
  return ((int __attribute__((__gnu_inline__))  )((int )tmp));
}
}
__inline extern  __attribute__((__nothrow__)) long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atol)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) atol)(char const   *__nptr ) 
{ 
  long tmp ;

  {
  tmp = strtol((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)), 10);
  return ((long __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) long long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atoll)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern long long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) atoll)(char const   *__nptr ) 
{ 
  long long tmp ;

  {
  tmp = strtoll((char const   */* __restrict  */)__nptr,
                (char **/* __restrict  */)((char **)((void *)0)), 10);
  return ((long long __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_major)(unsigned long long __dev )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_minor)(unsigned long long __dev )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) unsigned long long __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_makedev)(unsigned int __major ,
                                                                                                                                               unsigned int __minor )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_major)(unsigned long long __dev )  __attribute__((__const__)) ;
__inline extern unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_major)(unsigned long long __dev ) 
{ 


  {
  return ((unsigned int __attribute__((__gnu_inline__))  )(((__dev >> 8) & 4095ULL) | (unsigned long long )((unsigned int )(__dev >> 32) & 4294963200U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_minor)(unsigned long long __dev )  __attribute__((__const__)) ;
__inline extern unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_minor)(unsigned long long __dev ) 
{ 


  {
  return ((unsigned int __attribute__((__gnu_inline__))  )((__dev & 255ULL) | (unsigned long long )((unsigned int )(__dev >> 12) & 4294967040U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned long long __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_makedev)(unsigned int __major ,
                                                                                                                                               unsigned int __minor )  __attribute__((__const__)) ;
__inline extern unsigned long long __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_makedev)(unsigned int __major ,
                                                                                                                 unsigned int __minor ) 
{ 


  {
  return ((unsigned long long __attribute__((__gnu_inline__))  )(((unsigned long long )((__minor & 255U) | ((__major & 4095U) << 8)) | ((unsigned long long )(__minor & 4294967040U) << 12)) | ((unsigned long long )(__major & 4294963200U) << 32)));
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) realpath)(char const   * __restrict  __name ,
                              char * __restrict  __resolved ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__nonnull__(1,2,5))) bsearch)(void const   *__key , void const   *__base ,
                              size_t __nmemb , size_t __size ,
                              int (*__compar)(void const   * , void const   * ) ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__nonnull__(1,2,5))) bsearch)(void const   *__key , void const   *__base ,
                              size_t __nmemb , size_t __size ,
                              int (*__compar)(void const   * , void const   * ) ) 
{ 
  size_t __l ;
  size_t __u ;
  size_t __idx ;
  void const   *__p ;
  int __comparison ;

  {
  __l = (size_t )0;
  __u = __nmemb;
  while (__l < __u) {
    __idx = (__l + __u) / 2UL;
    __p = (void const   *)((void *)((char const   *)__base + __idx * __size));
    __comparison = (*__compar)(__key, __p);
    if (__comparison < 0) {
      __u = __idx;
    } else
    if (__comparison > 0) {
      __l = __idx + 1UL;
    } else {
      return ((void __attribute__((__gnu_inline__))  *)((void *)__p));
    }
  }
  return ((void __attribute__((__gnu_inline__))  *)((void *)0));
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__leaf__)) mblen)(char const   *__s ,
                                                                            size_t __n ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) wctomb)(char *__s , wchar_t __wchar ) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) mbstowcs)(wchar_t * __restrict  __dst ,
                                              char const   * __restrict  __src ,
                                              size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcstombs)(char * __restrict  __dst ,
                              wchar_t const   * __restrict  __src ,
                              size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) double __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atof)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern double __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) atof)(char const   *__nptr ) 
{ 
  double tmp ;

  {
  tmp = strtod((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)));
  return ((double __attribute__((__gnu_inline__))  )tmp);
}
}
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__leaf__)) __realpath_chk)(char const   * __restrict  __name ,
                           char * __restrict  __resolved , size_t __resolvedlen ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__leaf__)) __realpath_alias)(char const   * __restrict  __name ,
                             char * __restrict  __resolved )  __asm__("realpath")  ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) realpath)(char const   * __restrict  __name ,
                              char * __restrict  __resolved ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) realpath)(char const   * __restrict  __name ,
                              char * __restrict  __resolved ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__resolved, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__resolved, 1);
    tmp___0 = __realpath_chk(__name, __resolved, tmp);
    return ((char __attribute__((__gnu_inline__))  *)tmp___0);
  } else {

  }
  tmp___2 = __realpath_alias(__name, __resolved);
  return ((char __attribute__((__gnu_inline__))  *)tmp___2);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ptsname_r_chk)(int __fd , char *__buf , size_t __buflen ,
                            size_t __nreal ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ptsname_r_alias)(int __fd , char *__buf , size_t __buflen )  __asm__("ptsname_r")  ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ptsname_r_chk_warn)(int __fd , char *__buf , size_t __buflen ,
                                 size_t __nreal )  __asm__("__ptsname_r_chk") __attribute__((__warning__("ptsname_r called with buflen bigger than size of buf"))) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) ptsname_r)(int __fd , char *__buf ,
                                               size_t __buflen ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) ptsname_r)(int __fd , char *__buf ,
                                               size_t __buflen ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) ptsname_r)(int __fd , char *__buf ,
                                               size_t __buflen ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __ptsname_r_chk(__fd, __buf, __buflen, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__buflen > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __ptsname_r_chk_warn(__fd, __buf, __buflen, tmp___1);
      return ((int __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __ptsname_r_alias(__fd, __buf, __buflen);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __wctomb_chk)(char *__s , wchar_t __wchar , size_t __buflen ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __wctomb_alias)(char *__s , wchar_t __wchar )  __asm__("wctomb")  ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) wctomb)(char *__s , wchar_t __wchar ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) wctomb)(char *__s , wchar_t __wchar ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  unsigned long tmp___2 ;
  int tmp___3 ;

  {
  tmp___1 = __builtin_object_size((void *)__s, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp___2 = __builtin_object_size((void *)__s, 1);
    if (16UL > tmp___2) {
      tmp = __builtin_object_size((void *)__s, 1);
      tmp___0 = __wctomb_chk(__s, __wchar, tmp);
      return ((int __attribute__((__gnu_inline__))  )tmp___0);
    } else {

    }
  } else {

  }
  tmp___3 = __wctomb_alias(__s, __wchar);
  return ((int __attribute__((__gnu_inline__))  )tmp___3);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbstowcs_chk)(wchar_t * __restrict  __dst ,
                                                                                        char const   * __restrict  __src ,
                                                                                        size_t __len ,
                                                                                        size_t __dstlen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbstowcs_alias)(wchar_t * __restrict  __dst ,
                                                                                          char const   * __restrict  __src ,
                                                                                          size_t __len )  __asm__("mbstowcs")  ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbstowcs_chk_warn)(wchar_t * __restrict  __dst ,
                                                                                             char const   * __restrict  __src ,
                                                                                             size_t __len ,
                                                                                             size_t __dstlen )  __asm__("__mbstowcs_chk") __attribute__((__warning__("mbstowcs called with dst buffer smaller than len * sizeof (wchar_t)"))) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) mbstowcs)(wchar_t * __restrict  __dst ,
                                              char const   * __restrict  __src ,
                                              size_t __len ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) mbstowcs)(wchar_t * __restrict  __dst ,
                                              char const   * __restrict  __src ,
                                              size_t __len ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__dst, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dst, 1);
    tmp___0 = __mbstowcs_chk(__dst, __src, __len, tmp / sizeof(wchar_t ));
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__dst, 1);
    if (__len > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__dst, 1);
      tmp___2 = __mbstowcs_chk_warn(__dst, __src, __len,
                                    tmp___1 / sizeof(wchar_t ));
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __mbstowcs_alias(__dst, __src, __len);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcstombs_chk)(char * __restrict  __dst ,
                                                                                        wchar_t const   * __restrict  __src ,
                                                                                        size_t __len ,
                                                                                        size_t __dstlen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcstombs_alias)(char * __restrict  __dst ,
                                                                                          wchar_t const   * __restrict  __src ,
                                                                                          size_t __len )  __asm__("wcstombs")  ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcstombs_chk_warn)(char * __restrict  __dst ,
                                                                                             wchar_t const   * __restrict  __src ,
                                                                                             size_t __len ,
                                                                                             size_t __dstlen )  __asm__("__wcstombs_chk") __attribute__((__warning__("wcstombs called with dst buffer smaller than len"))) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcstombs)(char * __restrict  __dst ,
                              wchar_t const   * __restrict  __src ,
                              size_t __len ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcstombs)(char * __restrict  __dst ,
                              wchar_t const   * __restrict  __src ,
                              size_t __len ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__dst, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dst, 1);
    tmp___0 = __wcstombs_chk(__dst, __src, __len, tmp);
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__dst, 1);
    if (__len > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__dst, 1);
      tmp___2 = __wcstombs_chk_warn(__dst, __src, __len, tmp___1);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wcstombs_alias(__dst, __src, __len);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memcpy)(void * __restrict  __dest ,
                            void const   * __restrict  __src , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memmove)(void *__dest , void const   *__src , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1),
__leaf__, __artificial__, __always_inline__)) memset)(void *__dest , int __ch ,
                                                      size_t __len ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2),
__leaf__)) memcmp)(void const   *__s1 , void const   *__s2 , size_t __n )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1),
__leaf__)) memchr)(void const   *__s , int __c , size_t __n )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcat)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncat)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2),
__leaf__)) strncmp)(char const   *__s1 , char const   *__s2 , size_t __n )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2),
__leaf__)) strcoll)(char const   *__s1 , char const   *__s2 )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1,2),
__leaf__)) strstr)(char const   *__haystack , char const   *__needle )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__nonnull__(1),
__leaf__)) strlen)(char const   *__s )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) bcopy)(void const   *__src , void *__dest , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) bzero)(void *__dest , size_t __len ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2),
__leaf__)) strcasecmp)(char const   *__s1 , char const   *__s2 )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2),
__leaf__)) strncasecmp)(char const   *__s1 , char const   *__s2 , size_t __n )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __n ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c1(char const   *__s ,
                                                                     int __reject ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c1(char const   *__s ,
                                                                     int __reject ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if ((int const   )*(__s + __result) != 0) {
      if (! ((int const   )*(__s + __result) != (int const   )__reject)) {
        break;
      } else {

      }
    } else {
      break;
    }
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c2(char const   *__s ,
                                                                     int __reject1 ,
                                                                     int __reject2 ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c2(char const   *__s ,
                                                                     int __reject1 ,
                                                                     int __reject2 ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if ((int const   )*(__s + __result) != 0) {
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        if (! ((int const   )*(__s + __result) != (int const   )__reject2)) {
          break;
        } else {

        }
      } else {
        break;
      }
    } else {
      break;
    }
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c3(char const   *__s ,
                                                                     int __reject1 ,
                                                                     int __reject2 ,
                                                                     int __reject3 ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c3(char const   *__s ,
                                                                     int __reject1 ,
                                                                     int __reject2 ,
                                                                     int __reject3 ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if ((int const   )*(__s + __result) != 0) {
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          if (! ((int const   )*(__s + __result) != (int const   )__reject3)) {
            break;
          } else {

          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c1(char const   *__s ,
                                                                    int __accept ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c1(char const   *__s ,
                                                                    int __accept ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while ((int const   )*(__s + __result) == (int const   )__accept) {
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c2(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c2(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if (! ((int const   )*(__s + __result) == (int const   )__accept1)) {
      if (! ((int const   )*(__s + __result) == (int const   )__accept2)) {
        break;
      } else {

      }
    } else {

    }
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c3(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ,
                                                                    int __accept3 ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c3(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ,
                                                                    int __accept3 ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if (! ((int const   )*(__s + __result) == (int const   )__accept1)) {
      if (! ((int const   )*(__s + __result) == (int const   )__accept2)) {
        if (! ((int const   )*(__s + __result) == (int const   )__accept3)) {
          break;
        } else {

        }
      } else {

      }
    } else {

    }
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strpbrk_c2(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strpbrk_c2(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ) 
{ 
  char *tmp ;

  {
  while (1) {
    if ((int const   )*__s != 0) {
      if ((int const   )*__s != (int const   )__accept1) {
        if (! ((int const   )*__s != (int const   )__accept2)) {
          break;
        } else {

        }
      } else {
        break;
      }
    } else {
      break;
    }
    __s ++;
  }
  if ((int const   )*__s == 0) {
    tmp = (char *)((void *)0);
  } else {
    tmp = (char *)((size_t )__s);
  }
  return ((char __attribute__((__gnu_inline__))  *)tmp);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strpbrk_c3(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ,
                                                                    int __accept3 ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strpbrk_c3(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ,
                                                                    int __accept3 ) 
{ 
  char *tmp ;

  {
  while (1) {
    if ((int const   )*__s != 0) {
      if ((int const   )*__s != (int const   )__accept1) {
        if ((int const   )*__s != (int const   )__accept2) {
          if (! ((int const   )*__s != (int const   )__accept3)) {
            break;
          } else {

          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    __s ++;
  }
  if ((int const   )*__s == 0) {
    tmp = (char *)((void *)0);
  } else {
    tmp = (char *)((size_t )__s);
  }
  return ((char __attribute__((__gnu_inline__))  *)tmp);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strtok_r_1c(char *__s ,
                                                                     char __sep ,
                                                                     char **__nextp ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strtok_r_1c(char *__s ,
                                                                     char __sep ,
                                                                     char **__nextp ) 
{ 
  char *__result ;
  char *tmp ;
  char *tmp___0 ;

  {
  if ((unsigned long )__s == (unsigned long )((void *)0)) {
    __s = *__nextp;
  } else {

  }
  while ((int )*__s == (int )__sep) {
    __s ++;
  }
  __result = (char *)((void *)0);
  if ((int )*__s != 0) {
    tmp = __s;
    __s ++;
    __result = tmp;
    while ((int )*__s != 0) {
      tmp___0 = __s;
      __s ++;
      if ((int )*tmp___0 == (int )__sep) {
        *(__s + -1) = (char )'\000';
        break;
      } else {

      }
    }
  } else {

  }
  *__nextp = __s;
  return ((char __attribute__((__gnu_inline__))  *)__result);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strsep_1c(char **__s ,
                                                                   char __reject ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strsep_1c(char **__s ,
                                                                   char __reject ) 
{ 
  char *__retval ;
  char *tmp ;
  char *tmp___0 ;
  char *tmp___2 ;

  {
  __retval = *__s;
  if ((unsigned long )__retval != (unsigned long )((void *)0)) {
    tmp___2 = __builtin_strchr(__retval, (int )__reject);
    tmp___0 = tmp___2;
    *__s = tmp___0;
    if ((unsigned long )tmp___0 != (unsigned long )((void *)0)) {
      tmp = *__s;
      (*__s) ++;
      *tmp = (char )'\000';
    } else {

    }
  } else {

  }
  return ((char __attribute__((__gnu_inline__))  *)__retval);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strsep_2c(char **__s ,
                                                                   char __reject1 ,
                                                                   char __reject2 ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strsep_2c(char **__s ,
                                                                   char __reject1 ,
                                                                   char __reject2 ) 
{ 
  char *__retval ;
  char *__cp ;
  char *tmp ;

  {
  __retval = *__s;
  if ((unsigned long )__retval != (unsigned long )((void *)0)) {
    __cp = __retval;
    while (1) {
      if ((int )*__cp == 0) {
        __cp = (char *)((void *)0);
        break;
      } else {

      }
      if ((int )*__cp == (int )__reject1) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else
      if ((int )*__cp == (int )__reject2) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else {

      }
      __cp ++;
    }
    *__s = __cp;
  } else {

  }
  return ((char __attribute__((__gnu_inline__))  *)__retval);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strsep_3c(char **__s ,
                                                                   char __reject1 ,
                                                                   char __reject2 ,
                                                                   char __reject3 ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strsep_3c(char **__s ,
                                                                   char __reject1 ,
                                                                   char __reject2 ,
                                                                   char __reject3 ) 
{ 
  char *__retval ;
  char *__cp ;
  char *tmp ;

  {
  __retval = *__s;
  if ((unsigned long )__retval != (unsigned long )((void *)0)) {
    __cp = __retval;
    while (1) {
      if ((int )*__cp == 0) {
        __cp = (char *)((void *)0);
        break;
      } else {

      }
      if ((int )*__cp == (int )__reject1) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else
      if ((int )*__cp == (int )__reject2) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else
      if ((int )*__cp == (int )__reject3) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else {

      }
      __cp ++;
    }
    *__s = __cp;
  } else {

  }
  return ((char __attribute__((__gnu_inline__))  *)__retval);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memcpy)(void * __restrict  __dest ,
                            void const   * __restrict  __src , size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memcpy)(void * __restrict  __dest ,
                            void const   * __restrict  __src , size_t __len ) 
{ 
  unsigned long tmp ;
  void *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 0);
  tmp___0 = __builtin___memcpy_chk((void *)__dest, (void const   *)__src, __len,
                                   tmp);
  return ((void __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memmove)(void *__dest , void const   *__src , size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memmove)(void *__dest , void const   *__src , size_t __len ) 
{ 
  unsigned long tmp ;
  void *tmp___0 ;

  {
  tmp = __builtin_object_size(__dest, 0);
  tmp___0 = __builtin___memmove_chk(__dest, __src, __len, tmp);
  return ((void __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1),
__leaf__, __artificial__, __always_inline__)) memset)(void *__dest , int __ch ,
                                                      size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1),
__leaf__, __artificial__, __always_inline__)) memset)(void *__dest , int __ch ,
                                                      size_t __len ) 
{ 
  unsigned long tmp ;
  void *tmp___0 ;

  {
  tmp = __builtin_object_size(__dest, 0);
  tmp___0 = __builtin___memset_chk(__dest, __ch, __len, tmp);
  return ((void __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) bcopy)(void const   *__src , void *__dest , size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) bcopy)(void const   *__src , void *__dest , size_t __len ) 
{ 
  unsigned long tmp ;

  {
  tmp = __builtin_object_size(__dest, 0);
  __builtin___memmove_chk(__dest, __src, __len, tmp);
  return;
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) bzero)(void *__dest , size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) bzero)(void *__dest , size_t __len ) 
{ 
  unsigned long tmp ;

  {
  tmp = __builtin_object_size(__dest, 0);
  __builtin___memset_chk(__dest, '\000', __len, tmp);
  return;
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 1);
  tmp___0 = __builtin___strcpy_chk((char *)__dest, (char const   *)__src, tmp);
  return ((char __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 1);
  tmp___0 = __builtin___strncpy_chk((char *)__dest, (char const   *)__src,
                                    __len, tmp);
  return ((char __attribute__((__gnu_inline__))  *)tmp___0);
}
}
extern  __attribute__((__nothrow__)) char *( __attribute__((__leaf__)) __stpncpy_chk)(char *__dest ,
                                                                                      char const   *__src ,
                                                                                      size_t __n ,
                                                                                      size_t __destlen ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__leaf__)) __stpncpy_alias)(char *__dest ,
                                                                                        char const   *__src ,
                                                                                        size_t __n )  __asm__("stpncpy")  ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __n ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __n ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___3 ;

  {
  tmp___1 = __builtin_object_size((void *)__dest, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dest, 1);
    tmp___0 = __stpncpy_chk((char *)__dest, (char const   *)__src, __n, tmp);
    return ((char __attribute__((__gnu_inline__))  *)tmp___0);
  } else {

  }
  tmp___3 = __stpncpy_alias((char *)__dest, (char const   *)__src, __n);
  return ((char __attribute__((__gnu_inline__))  *)tmp___3);
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcat)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcat)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 1);
  tmp___0 = __builtin___strcat_chk((char *)__dest, (char const   *)__src, tmp);
  return ((char __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncat)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncat)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 1);
  tmp___0 = __builtin___strncat_chk((char *)__dest, (char const   *)__src,
                                    __len, tmp);
  return ((char __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbit)(double __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitf)(float __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitl)(long double __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitf)(float __x )  __attribute__((__const__)) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitf)(float __x ) 
{ 
  int __m ;

  {
  __asm__  ("pmovmskb %1, %0": "=r" (__m): "x" (__x));
  return ((int __attribute__((__gnu_inline__))  )((__m & 8) != 0));
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbit)(double __x )  __attribute__((__const__)) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbit)(double __x ) 
{ 
  int __m ;

  {
  __asm__  ("pmovmskb %1, %0": "=r" (__m): "x" (__x));
  return ((int __attribute__((__gnu_inline__))  )((__m & 128) != 0));
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitl)(long double __x )  __attribute__((__const__)) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitl)(long double __x ) 
{ 
  union __anonunion___u_27 __u ;

  {
  __u.__l = __x;
  return ((int __attribute__((__gnu_inline__))  )((__u.__i[2] & 32768) != 0));
}
}
extern void __attribute__((__visibility__("default")))  *_emalloc(size_t size )  __attribute__((__malloc__)) ;
extern void __attribute__((__visibility__("default")))  *_safe_emalloc(size_t nmemb ,
                                                                       size_t size ,
                                                                       size_t offset )  __attribute__((__malloc__)) ;
extern void __attribute__((__visibility__("default")))  _efree(void *ptr ) ;
extern void __attribute__((__visibility__("default")))  *_erealloc(void *ptr ,
                                                                   size_t size ,
                                                                   int allow_failure ) ;
extern char __attribute__((__visibility__("default")))  *_estrdup(char const   *s )  __attribute__((__malloc__)) ;
extern char __attribute__((__visibility__("default")))  *_estrndup(char const   *s ,
                                                                   unsigned int length )  __attribute__((__malloc__)) ;
extern int __attribute__((__visibility__("default")))  _zend_hash_init(HashTable *ht ,
                                                                       uint nSize ,
                                                                       ulong (*pHashFunction)(char const   *arKey ,
                                                                                              uint nKeyLength ) ,
                                                                       void (*pDestructor)(void *pDest ) ,
                                                                       zend_bool persistent ) ;
extern void __attribute__((__visibility__("default")))  zend_hash_destroy(HashTable *ht ) ;
extern int __attribute__((__visibility__("default")))  _zend_hash_add_or_update(HashTable *ht ,
                                                                                char const   *arKey ,
                                                                                uint nKeyLength ,
                                                                                void *pData ,
                                                                                uint nDataSize ,
                                                                                void **pDest ,
                                                                                int flag ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_find(HashTable const   *ht ,
                                                                      char const   *arKey ,
                                                                      uint nKeyLength ,
                                                                      void **pData ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_move_forward_ex(HashTable *ht ,
                                                                                 HashPosition *pos ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_get_current_key_ex(HashTable const   *ht ,
                                                                                    char **str_index ,
                                                                                    uint *str_length ,
                                                                                    ulong *num_index ,
                                                                                    zend_bool duplicate ,
                                                                                    HashPosition *pos ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_get_current_data_ex(HashTable *ht ,
                                                                                     void **pData ,
                                                                                     HashPosition *pos ) ;
extern void __attribute__((__visibility__("default")))  zend_hash_internal_pointer_reset_ex(HashTable *ht ,
                                                                                            HashPosition *pos ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_num_elements(HashTable const   *ht ) ;
__inline static zend_uint ( __attribute__((__always_inline__)) zval_refcount_p)(zval *pz ) 
{ 


  {
  return (pz->refcount__gc);
}
}
__inline static zend_uint ( __attribute__((__always_inline__)) zval_set_refcount_p)(zval *pz ,
                                                                                    zend_uint rc ) 
{ 
  zend_uint tmp ;

  {
  tmp = rc;
  pz->refcount__gc = tmp;
  return (tmp);
}
}
__inline static zend_uint ( __attribute__((__always_inline__)) zval_addref_p)(zval *pz ) 
{ 


  {
  (pz->refcount__gc) ++;
  return (pz->refcount__gc);
}
}
__inline static zend_uint ( __attribute__((__always_inline__)) zval_delref_p)(zval *pz ) 
{ 


  {
  (pz->refcount__gc) --;
  return (pz->refcount__gc);
}
}
__inline static zend_bool ( __attribute__((__always_inline__)) zval_isref_p)(zval *pz ) 
{ 


  {
  return (pz->is_ref__gc);
}
}
__inline static zend_bool ( __attribute__((__always_inline__)) zval_unset_isref_p)(zval *pz ) 
{ 
  zend_uchar tmp ;

  {
  tmp = (zend_uchar )0;
  pz->is_ref__gc = tmp;
  return (tmp);
}
}
__inline static zend_bool ( __attribute__((__always_inline__)) zval_set_isref_to_p)(zval *pz ,
                                                                                    zend_bool isref ) 
{ 
  zend_uchar tmp ;

  {
  tmp = isref;
  pz->is_ref__gc = tmp;
  return (tmp);
}
}
extern void __attribute__((__visibility__("default")))  zend_make_printable_zval(zval *expr ,
                                                                                 zval *expr_copy ,
                                                                                 int *use_copy ) ;
extern void __attribute__((__visibility__("default")))  gc_remove_zval_from_buffer(zval *zv ) ;
__inline static char *zend_memnstr(char *haystack , char *needle ,
                                   int needle_len , char *end ) 
{ 
  char *p ;
  char ne ;
  void *tmp ;
  int tmp___0 ;
  void *tmp___1 ;

  {
  p = haystack;
  ne = *(needle + (needle_len - 1));
  if (needle_len == 1) {
    tmp = memchr((void const   *)p, (int )*needle, (size_t )(end - p));
    return ((char *)tmp);
  } else {

  }
  if ((long )needle_len > end - haystack) {
    return ((char *)((void *)0));
  } else {

  }
  end -= needle_len;
  while ((unsigned long )p <= (unsigned long )end) {
    tmp___1 = memchr((void const   *)p, (int )*needle, (size_t )((end - p) + 1L));
    p = (char *)tmp___1;
    if (p) {
      if ((int )ne == (int )*(p + (needle_len - 1))) {
        tmp___0 = memcmp((void const   *)needle, (void const   *)p,
                         (size_t )(needle_len - 1));
        if (! tmp___0) {
          return (p);
        } else {

        }
      } else {

      }
    } else {

    }
    if ((unsigned long )p == (unsigned long )((void *)0)) {
      return ((char *)((void *)0));
    } else {

    }
    p ++;
  }
  return ((char *)((void *)0));
}
}
__inline static void const   *zend_memrchr(void const   *s , int c , size_t n ) 
{ 
  register unsigned char const   *e ;

  {
  if (n <= 0UL) {
    return ((void const   *)((void *)0));
  } else {

  }
  e = ((unsigned char const   *)s + n) - 1;
  while ((unsigned long )e >= (unsigned long )((unsigned char const   *)s)) {
    if ((int const   )*e == (int const   )((unsigned char const   )c)) {
      return ((void const   *)e);
    } else {

    }
    e --;
  }
  return ((void const   *)((void *)0));
}
}
extern void __attribute__((__visibility__("default")))  _convert_to_string(zval *op ) ;
extern void __attribute__((__visibility__("default")))  convert_to_long(zval *op ) ;
extern void __attribute__((__visibility__("default")))  convert_to_double(zval *op ) ;
extern char __attribute__((__visibility__("default")))  *zend_str_tolower_dup(char const   *source ,
                                                                              unsigned int length ) ;
extern int __attribute__((__visibility__("default")))  zend_binary_strncmp(char const   *s1 ,
                                                                           uint len1 ,
                                                                           char const   *s2 ,
                                                                           uint len2 ,
                                                                           uint length ) ;
extern int __attribute__((__visibility__("default")))  zend_binary_strncasecmp(char const   *s1 ,
                                                                               uint len1 ,
                                                                               char const   *s2 ,
                                                                               uint len2 ,
                                                                               uint length ) ;
extern void __attribute__((__visibility__("default")))  _zval_dtor_func(zval *zvalue ) ;
__inline static void ( __attribute__((__always_inline__)) _zval_dtor)(zval *zvalue ) 
{ 


  {
  if ((int )zvalue->type <= 3) {
    return;
  } else {

  }
  _zval_dtor_func(zvalue);
  return;
}
}
extern void __attribute__((__visibility__("default")))  _zval_copy_ctor_func(zval *zvalue ) ;
__inline static void ( __attribute__((__always_inline__)) _zval_copy_ctor)(zval *zvalue ) 
{ 


  {
  if ((int )zvalue->type <= 3) {
    return;
  } else {

  }
  _zval_copy_ctor_func(zvalue);
  return;
}
}
extern void __attribute__((__visibility__("default")))  _zval_ptr_dtor(zval **zval_ptr ) ;
extern struct _zend_compiler_globals  __attribute__((__visibility__("default"))) compiler_globals ;
extern zend_executor_globals __attribute__((__visibility__("default")))  executor_globals ;
extern size_t __attribute__((__visibility__("default")))  zend_dirname(char *path ,
                                                                       size_t len ) ;
extern int __attribute__((__visibility__("default")))  zend_parse_parameters(int num_args ,
                                                                             char const   *type_spec 
                                                                             , ...) ;
extern int __attribute__((__visibility__("default")))  zend_parse_parameters_ex(int flags ,
                                                                                int num_args ,
                                                                                char const   *type_spec 
                                                                                , ...) ;
extern void __attribute__((__visibility__("default")))  zend_wrong_param_count(void) ;
extern int __attribute__((__visibility__("default")))  _array_init(zval *arg ,
                                                                   uint size ) ;
extern int __attribute__((__visibility__("default")))  add_assoc_long_ex(zval *arg ,
                                                                         char const   *key ,
                                                                         uint key_len ,
                                                                         long n ) ;
extern int __attribute__((__visibility__("default")))  add_assoc_string_ex(zval *arg ,
                                                                           char const   *key ,
                                                                           uint key_len ,
                                                                           char *str ,
                                                                           int duplicate ) ;
extern int __attribute__((__visibility__("default")))  add_assoc_stringl_ex(zval *arg ,
                                                                            char const   *key ,
                                                                            uint key_len ,
                                                                            char *str ,
                                                                            uint length ,
                                                                            int duplicate ) ;
extern int __attribute__((__visibility__("default")))  add_assoc_zval_ex(zval *arg ,
                                                                         char const   *key ,
                                                                         uint key_len ,
                                                                         zval *value ) ;
extern int __attribute__((__visibility__("default")))  add_index_long(zval *arg ,
                                                                      ulong idx ,
                                                                      long n ) ;
extern int __attribute__((__visibility__("default")))  add_index_stringl(zval *arg ,
                                                                         ulong idx ,
                                                                         char const   *str ,
                                                                         uint length ,
                                                                         int duplicate ) ;
extern int __attribute__((__visibility__("default")))  add_index_zval(zval *arg ,
                                                                      ulong index ,
                                                                      zval *value ) ;
extern int __attribute__((__visibility__("default")))  add_next_index_stringl(zval *arg ,
                                                                              char const   *str ,
                                                                              uint length ,
                                                                              int duplicate ) ;
extern void __attribute__((__visibility__("default")))  zend_rebuild_symbol_table(void) ;
extern  __attribute__((__nothrow__)) unsigned short const   **( __attribute__((__leaf__)) __ctype_b_loc)(void)  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) __int32_t const   **( __attribute__((__leaf__)) __ctype_tolower_loc)(void)  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) __int32_t const   **( __attribute__((__leaf__)) __ctype_toupper_loc)(void)  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) tolower)(int __c ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) toupper)(int __c ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) tolower)(int __c ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) tolower)(int __c ) 
{ 
  __int32_t const   **tmp ;
  __int32_t tmp___0 ;

  {
  if (__c >= -128) {
    if (__c < 256) {
      tmp = __ctype_tolower_loc();
      tmp___0 = (__int32_t )*(*tmp + __c);
    } else {
      tmp___0 = (__int32_t )((__int32_t const   )__c);
    }
  } else {
    tmp___0 = (__int32_t )((__int32_t const   )__c);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) toupper)(int __c ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) toupper)(int __c ) 
{ 
  __int32_t const   **tmp ;
  __int32_t tmp___0 ;

  {
  if (__c >= -128) {
    if (__c < 256) {
      tmp = __ctype_toupper_loc();
      tmp___0 = (__int32_t )*(*tmp + __c);
    } else {
      tmp___0 = (__int32_t )((__int32_t const   )__c);
    }
  } else {
    tmp___0 = (__int32_t )((__int32_t const   )__c);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) read)(int __fd , void *__buf ,
                                          size_t __nbytes ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) getcwd)(char *__buf , size_t __size ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__,
__deprecated__))  *( __attribute__((__warn_unused_result__, __nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) getwd)(char *__buf )  __attribute__((__deprecated__)) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) confstr)(int __name , char *__buf ,
                                             size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) getgroups)(int __size , __gid_t *__list ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(2), __leaf__, __artificial__,
__always_inline__)) ttyname_r)(int __fd , char *__buf , size_t __buflen ) ;
__inline extern  __attribute__((__nothrow__)) ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1,2), __leaf__, __artificial__,
__always_inline__)) readlink)(char const   * __restrict  __path ,
                              char * __restrict  __buf , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(2,3), __leaf__, __artificial__,
__always_inline__)) readlinkat)(int __fd , char const   * __restrict  __path ,
                                char * __restrict  __buf , size_t __len ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__artificial__,
__always_inline__)) getlogin_r)(char *__buf , size_t __buflen ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) gethostname)(char *__buf , size_t __buflen ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__, __artificial__,
__always_inline__)) getdomainname)(char *__buf , size_t __buflen ) ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __read_chk)(int __fd ,
                                                                     void *__buf ,
                                                                     size_t __nbytes ,
                                                                     size_t __buflen ) ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __read_alias)(int __fd ,
                                                                       void *__buf ,
                                                                       size_t __nbytes )  __asm__("read")  ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __read_chk_warn)(int __fd ,
                                                                          void *__buf ,
                                                                          size_t __nbytes ,
                                                                          size_t __buflen )  __asm__("__read_chk") __attribute__((__warning__("read called with bigger length than size of the destination buffer"))) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) read)(int __fd , void *__buf ,
                                          size_t __nbytes ) 
{ 
  unsigned long tmp ;
  ssize_t tmp___0 ;
  unsigned long tmp___1 ;
  ssize_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  ssize_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size(__buf, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size(__buf, 0);
    tmp___0 = __read_chk(__fd, __buf, __nbytes, tmp);
    return ((ssize_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size(__buf, 0);
    if (__nbytes > tmp___3) {
      tmp___1 = __builtin_object_size(__buf, 0);
      tmp___2 = __read_chk_warn(__fd, __buf, __nbytes, tmp___1);
      return ((ssize_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __read_alias(__fd, __buf, __nbytes);
  return ((ssize_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__warn_unused_result__,
__nonnull__(1,2), __leaf__)) __readlink_chk)(char const   * __restrict  __path ,
                                             char * __restrict  __buf ,
                                             size_t __len , size_t __buflen ) ;
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__warn_unused_result__,
__nonnull__(1,2),
__leaf__)) __readlink_alias)(char const   * __restrict  __path ,
                             char * __restrict  __buf , size_t __len )  __asm__("readlink")  ;
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__warn_unused_result__,
__nonnull__(1,2),
__leaf__)) __readlink_chk_warn)(char const   * __restrict  __path ,
                                char * __restrict  __buf , size_t __len ,
                                size_t __buflen )  __asm__("__readlink_chk") __attribute__((__warning__("readlink called with bigger length than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1,2), __leaf__, __artificial__,
__always_inline__)) readlink)(char const   * __restrict  __path ,
                              char * __restrict  __buf , size_t __len ) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1,2), __leaf__, __artificial__,
__always_inline__)) readlink)(char const   * __restrict  __path ,
                              char * __restrict  __buf , size_t __len ) 
{ 
  unsigned long tmp ;
  ssize_t tmp___0 ;
  unsigned long tmp___1 ;
  ssize_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  ssize_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __readlink_chk(__path, __buf, __len, tmp);
    return ((ssize_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__len > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __readlink_chk_warn(__path, __buf, __len, tmp___1);
      return ((ssize_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __readlink_alias(__path, __buf, __len);
  return ((ssize_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__warn_unused_result__,
__nonnull__(2,3),
__leaf__)) __readlinkat_chk)(int __fd , char const   * __restrict  __path ,
                             char * __restrict  __buf , size_t __len ,
                             size_t __buflen ) ;
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__warn_unused_result__,
__nonnull__(2,3),
__leaf__)) __readlinkat_alias)(int __fd , char const   * __restrict  __path ,
                               char * __restrict  __buf , size_t __len )  __asm__("readlinkat")  ;
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__warn_unused_result__,
__nonnull__(2,3),
__leaf__)) __readlinkat_chk_warn)(int __fd , char const   * __restrict  __path ,
                                  char * __restrict  __buf , size_t __len ,
                                  size_t __buflen )  __asm__("__readlinkat_chk") __attribute__((__warning__("readlinkat called with bigger length than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(2,3), __leaf__, __artificial__,
__always_inline__)) readlinkat)(int __fd , char const   * __restrict  __path ,
                                char * __restrict  __buf , size_t __len ) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(2,3), __leaf__, __artificial__,
__always_inline__)) readlinkat)(int __fd , char const   * __restrict  __path ,
                                char * __restrict  __buf , size_t __len ) 
{ 
  unsigned long tmp ;
  ssize_t tmp___0 ;
  unsigned long tmp___1 ;
  ssize_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  ssize_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __readlinkat_chk(__fd, __path, __buf, __len, tmp);
    return ((ssize_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__len > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __readlinkat_chk_warn(__fd, __path, __buf, __len, tmp___1);
      return ((ssize_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __readlinkat_alias(__fd, __path, __buf, __len);
  return ((ssize_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__leaf__)) __getcwd_chk)(char *__buf , size_t __size , size_t __buflen ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__leaf__)) __getcwd_alias)(char *__buf , size_t __size )  __asm__("getcwd")  ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__leaf__)) __getcwd_chk_warn)(char *__buf , size_t __size , size_t __buflen )  __asm__("__getcwd_chk") __attribute__((__warning__("getcwd caller with bigger length than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) getcwd)(char *__buf , size_t __size ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) getcwd)(char *__buf , size_t __size ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  char *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __getcwd_chk(__buf, __size, tmp);
    return ((char __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__size > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __getcwd_chk_warn(__buf, __size, tmp___1);
      return ((char __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __getcwd_alias(__buf, __size);
  return ((char __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) __getwd_chk)(char *__buf , size_t buflen ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) __getwd_warn)(char *__buf )  __asm__("getwd") __attribute__((__warning__("please use getcwd instead, as getwd doesn\'t specify buffer size"))) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__,
__deprecated__))  *( __attribute__((__warn_unused_result__, __nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) getwd)(char *__buf )  __attribute__((__deprecated__)) ;
__inline extern char __attribute__((__gnu_inline__,
__deprecated__))  *( __attribute__((__warn_unused_result__, __nonnull__(1),
__leaf__, __artificial__, __always_inline__)) getwd)(char *__buf ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__buf, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __getwd_chk(__buf, tmp);
    return ((char __attribute__((__gnu_inline__, __deprecated__))  *)tmp___0);
  } else {

  }
  tmp___2 = __getwd_warn(__buf);
  return ((char __attribute__((__gnu_inline__, __deprecated__))  *)tmp___2);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __confstr_chk)(int __name ,
                                                                                       char *__buf ,
                                                                                       size_t __len ,
                                                                                       size_t __buflen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __confstr_alias)(int __name ,
                                                                                         char *__buf ,
                                                                                         size_t __len )  __asm__("confstr")  ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __confstr_chk_warn)(int __name ,
                                                                                            char *__buf ,
                                                                                            size_t __len ,
                                                                                            size_t __buflen )  __asm__("__confstr_chk") __attribute__((__warning__("confstr called with bigger length than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) confstr)(int __name , char *__buf ,
                                             size_t __len ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) confstr)(int __name , char *__buf ,
                                             size_t __len ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __confstr_chk(__name, __buf, __len, tmp);
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (tmp___3 < __len) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __confstr_chk_warn(__name, __buf, __len, tmp___1);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __confstr_alias(__name, __buf, __len);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __getgroups_chk)(int __size , __gid_t *__list , size_t __listlen ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __getgroups_alias)(int __size , __gid_t *__list )  __asm__("getgroups")  ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __getgroups_chk_warn)(int __size , __gid_t *__list ,
                                 size_t __listlen )  __asm__("__getgroups_chk") __attribute__((__warning__("getgroups called with bigger group count than what can fit into destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) getgroups)(int __size , __gid_t *__list ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) getgroups)(int __size , __gid_t *__list ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__list, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__list, 1);
    tmp___0 = __getgroups_chk(__size, __list, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__list, 1);
    if ((unsigned long )__size * sizeof(__gid_t ) > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__list, 1);
      tmp___2 = __getgroups_chk_warn(__size, __list, tmp___1);
      return ((int __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __getgroups_alias(__size, __list);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ttyname_r_chk)(int __fd , char *__buf , size_t __buflen ,
                            size_t __nreal ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ttyname_r_alias)(int __fd , char *__buf , size_t __buflen )  __asm__("ttyname_r")  ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ttyname_r_chk_warn)(int __fd , char *__buf , size_t __buflen ,
                                 size_t __nreal )  __asm__("__ttyname_r_chk") __attribute__((__warning__("ttyname_r called with bigger buflen than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(2), __leaf__, __artificial__,
__always_inline__)) ttyname_r)(int __fd , char *__buf , size_t __buflen ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(2), __leaf__, __artificial__,
__always_inline__)) ttyname_r)(int __fd , char *__buf , size_t __buflen ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __ttyname_r_chk(__fd, __buf, __buflen, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__buflen > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __ttyname_r_chk_warn(__fd, __buf, __buflen, tmp___1);
      return ((int __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __ttyname_r_alias(__fd, __buf, __buflen);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern int ( __attribute__((__nonnull__(1))) __getlogin_r_chk)(char *__buf ,
                                                               size_t __buflen ,
                                                               size_t __nreal ) ;
extern int ( __attribute__((__nonnull__(1))) __getlogin_r_alias)(char *__buf ,
                                                                 size_t __buflen )  __asm__("getlogin_r")  ;
extern int ( __attribute__((__nonnull__(1))) __getlogin_r_chk_warn)(char *__buf ,
                                                                    size_t __buflen ,
                                                                    size_t __nreal )  __asm__("__getlogin_r_chk") __attribute__((__warning__("getlogin_r called with bigger buflen than size of destination buffer"))) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__artificial__, __always_inline__)) getlogin_r)(char *__buf , size_t __buflen ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __getlogin_r_chk(__buf, __buflen, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__buflen > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __getlogin_r_chk_warn(__buf, __buflen, tmp___1);
      return ((int __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __getlogin_r_alias(__buf, __buflen);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1),
__leaf__)) __gethostname_chk)(char *__buf , size_t __buflen , size_t __nreal ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1),
__leaf__)) __gethostname_alias)(char *__buf , size_t __buflen )  __asm__("gethostname")  ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1),
__leaf__)) __gethostname_chk_warn)(char *__buf , size_t __buflen ,
                                   size_t __nreal )  __asm__("__gethostname_chk") __attribute__((__warning__("gethostname called with bigger buflen than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) gethostname)(char *__buf , size_t __buflen ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) gethostname)(char *__buf , size_t __buflen ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __gethostname_chk(__buf, __buflen, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__buflen > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __gethostname_chk_warn(__buf, __buflen, tmp___1);
      return ((int __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __gethostname_alias(__buf, __buflen);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) __getdomainname_chk)(char *__buf , size_t __buflen ,
                                                size_t __nreal ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) __getdomainname_alias)(char *__buf , size_t __buflen )  __asm__("getdomainname")  ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) __getdomainname_chk_warn)(char *__buf , size_t __buflen ,
                                     size_t __nreal )  __asm__("__getdomainname_chk") __attribute__((__warning__("getdomainname called with bigger buflen than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__, __artificial__,
__always_inline__)) getdomainname)(char *__buf , size_t __buflen ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__, __artificial__,
__always_inline__)) getdomainname)(char *__buf , size_t __buflen ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __getdomainname_chk(__buf, __buflen, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__buflen > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __getdomainname_chk_warn(__buf, __buflen, tmp___1);
      return ((int __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __getdomainname_alias(__buf, __buflen);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
__inline extern int __attribute__((__gnu_inline__))  __sigismember(__sigset_t const   *__set ,
                                                                   int __sig ) ;
__inline extern int __attribute__((__gnu_inline__))  __sigaddset(__sigset_t *__set ,
                                                                 int __sig ) ;
__inline extern int __attribute__((__gnu_inline__))  __sigdelset(__sigset_t *__set ,
                                                                 int __sig ) ;
__inline extern int __attribute__((__gnu_inline__))  __sigismember(__sigset_t const   *__set ,
                                                                   int __sig ) 
{ 
  unsigned long __mask ;
  unsigned long __word ;
  int tmp ;

  {
  __mask = 1UL << (unsigned long )(__sig - 1) % (8UL * sizeof(unsigned long ));
  __word = (unsigned long )(__sig - 1) / (8UL * sizeof(unsigned long ));
  if (__set->__val[__word] & __mask) {
    tmp = 1;
  } else {
    tmp = 0;
  }
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  __sigaddset(__sigset_t *__set ,
                                                                 int __sig ) 
{ 
  unsigned long __mask ;
  unsigned long __word ;

  {
  __mask = 1UL << (unsigned long )(__sig - 1) % (8UL * sizeof(unsigned long ));
  __word = (unsigned long )(__sig - 1) / (8UL * sizeof(unsigned long ));
  __set->__val[__word] |= __mask;
  return ((int __attribute__((__gnu_inline__))  )0);
}
}
__inline extern int __attribute__((__gnu_inline__))  __sigdelset(__sigset_t *__set ,
                                                                 int __sig ) 
{ 
  unsigned long __mask ;
  unsigned long __word ;

  {
  __mask = 1UL << (unsigned long )(__sig - 1) % (8UL * sizeof(unsigned long ));
  __word = (unsigned long )(__sig - 1) / (8UL * sizeof(unsigned long ));
  __set->__val[__word] &= ~ __mask;
  return ((int __attribute__((__gnu_inline__))  )0);
}
}
extern int __attribute__((__visibility__("default")))  ap_php_slprintf(char *buf ,
                                                                       size_t len ,
                                                                       char const   *format 
                                                                       , ...) ;
extern int __attribute__((__visibility__("default")))  php_sprintf(char *s ,
                                                                   char const   *format 
                                                                   , ...) ;
extern int __attribute__((__visibility__("default")))  spprintf(char **pbuf ,
                                                                size_t max_len ,
                                                                char const   *format 
                                                                , ...) ;
extern void __attribute__((__visibility__("default")))  php_error_docref0(char const   *docref ,
                                                                          int type ,
                                                                          char const   *format 
                                                                          , ...) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) stat)(char const   * __restrict  __path ,
                 struct stat * __restrict  __statbuf ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) fstat)(int __fd , struct stat *__statbuf ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2,3),
__leaf__)) fstatat)(int __fd , char const   * __restrict  __filename ,
                    struct stat * __restrict  __statbuf , int __flag ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) lstat)(char const   * __restrict  __path ,
                  struct stat * __restrict  __statbuf ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__)) mknod)(char const   *__path , __mode_t __mode , __dev_t __dev ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) mknodat)(int __fd , char const   *__path , __mode_t __mode ,
                    __dev_t __dev ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3),
__leaf__)) __fxstat)(int __ver , int __fildes , struct stat *__stat_buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,3),
__leaf__)) __xstat)(int __ver , char const   *__filename ,
                    struct stat *__stat_buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,3),
__leaf__)) __lxstat)(int __ver , char const   *__filename ,
                     struct stat *__stat_buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3,4),
__leaf__)) __fxstatat)(int __ver , int __fildes , char const   *__filename ,
                       struct stat *__stat_buf , int __flag ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,4),
__leaf__)) __xmknod)(int __ver , char const   *__path , __mode_t __mode ,
                     __dev_t *__dev ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3,5),
__leaf__)) __xmknodat)(int __ver , int __fd , char const   *__path ,
                       __mode_t __mode , __dev_t *__dev ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) stat)(char const   * __restrict  __path ,
                 struct stat * __restrict  __statbuf ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) stat)(char const   * __restrict  __path ,
                 struct stat * __restrict  __statbuf ) 
{ 
  int tmp ;

  {
  tmp = __xstat(1, (char const   *)__path, (struct stat *)__statbuf);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) lstat)(char const   * __restrict  __path ,
                  struct stat * __restrict  __statbuf ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) lstat)(char const   * __restrict  __path ,
                  struct stat * __restrict  __statbuf ) 
{ 
  int tmp ;

  {
  tmp = __lxstat(1, (char const   *)__path, (struct stat *)__statbuf);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) fstat)(int __fd , struct stat *__statbuf ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) fstat)(int __fd , struct stat *__statbuf ) 
{ 
  int tmp ;

  {
  tmp = __fxstat(1, __fd, __statbuf);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2,3),
__leaf__)) fstatat)(int __fd , char const   * __restrict  __filename ,
                    struct stat * __restrict  __statbuf , int __flag ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2,3),
__leaf__)) fstatat)(int __fd , char const   * __restrict  __filename ,
                    struct stat * __restrict  __statbuf , int __flag ) 
{ 
  int tmp ;

  {
  tmp = __fxstatat(1, __fd, (char const   *)__filename,
                   (struct stat *)__statbuf, __flag);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__)) mknod)(char const   *__path , __mode_t __mode , __dev_t __dev ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__)) mknod)(char const   *__path , __mode_t __mode , __dev_t __dev ) 
{ 
  int tmp ;

  {
  tmp = __xmknod(0, __path, __mode, & __dev);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) mknodat)(int __fd , char const   *__path , __mode_t __mode ,
                    __dev_t __dev ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) mknodat)(int __fd , char const   *__path , __mode_t __mode ,
                    __dev_t __dev ) 
{ 
  int tmp ;

  {
  tmp = __xmknodat(0, __fd, __path, __mode, & __dev);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) struct cmsghdr  __attribute__((__gnu_inline__)) *( __attribute__((__leaf__)) __cmsg_nxthdr)(struct msghdr *__mhdr ,
                                                                                                                                          struct cmsghdr *__cmsg ) ;
__inline extern  __attribute__((__nothrow__)) struct cmsghdr  __attribute__((__gnu_inline__)) *( __attribute__((__leaf__)) __cmsg_nxthdr)(struct msghdr *__mhdr ,
                                                                                                                                          struct cmsghdr *__cmsg ) ;
__inline extern struct cmsghdr  __attribute__((__gnu_inline__)) *( __attribute__((__leaf__)) __cmsg_nxthdr)(struct msghdr *__mhdr ,
                                                                                                            struct cmsghdr *__cmsg ) 
{ 


  {
  if (__cmsg->cmsg_len < sizeof(struct cmsghdr )) {
    return ((struct cmsghdr  __attribute__((__gnu_inline__)) *)((struct cmsghdr *)0));
  } else {

  }
  __cmsg = (struct cmsghdr *)((unsigned char *)__cmsg + (((__cmsg->cmsg_len + sizeof(size_t )) - 1UL) & ~ (sizeof(size_t ) - 1UL)));
  if ((unsigned long )((unsigned char *)(__cmsg + 1)) > (unsigned long )((unsigned char *)__mhdr->msg_control + __mhdr->msg_controllen)) {
    return ((struct cmsghdr  __attribute__((__gnu_inline__)) *)((struct cmsghdr *)0));
  } else
  if ((unsigned long )((unsigned char *)__cmsg + (((__cmsg->cmsg_len + sizeof(size_t )) - 1UL) & ~ (sizeof(size_t ) - 1UL))) > (unsigned long )((unsigned char *)__mhdr->msg_control + __mhdr->msg_controllen)) {
    return ((struct cmsghdr  __attribute__((__gnu_inline__)) *)((struct cmsghdr *)0));
  } else {

  }
  return ((struct cmsghdr  __attribute__((__gnu_inline__)) *)__cmsg);
}
}
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) recv)(int __fd , void *__buf , size_t __n , int __flags ) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) recvfrom)(int __fd , void * __restrict  __buf , size_t __n ,
                              int __flags ,
                              struct sockaddr * __restrict  __addr ,
                              socklen_t * __restrict  __addr_len ) ;
extern ssize_t __recv_chk(int __fd , void *__buf , size_t __n ,
                          size_t __buflen , int __flags ) ;
extern ssize_t __recv_alias(int __fd , void *__buf , size_t __n , int __flags )  __asm__("recv")  ;
extern ssize_t __recv_chk_warn(int __fd , void *__buf , size_t __n ,
                               size_t __buflen , int __flags )  __asm__("__recv_chk") __attribute__((__warning__("recv called with bigger length than size of destination buffer"))) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) recv)(int __fd , void *__buf , size_t __n , int __flags ) 
{ 
  unsigned long tmp ;
  ssize_t tmp___0 ;
  unsigned long tmp___1 ;
  ssize_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  ssize_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size(__buf, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size(__buf, 0);
    tmp___0 = __recv_chk(__fd, __buf, __n, tmp, __flags);
    return ((ssize_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size(__buf, 0);
    if (__n > tmp___3) {
      tmp___1 = __builtin_object_size(__buf, 0);
      tmp___2 = __recv_chk_warn(__fd, __buf, __n, tmp___1, __flags);
      return ((ssize_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __recv_alias(__fd, __buf, __n, __flags);
  return ((ssize_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern ssize_t __recvfrom_chk(int __fd , void * __restrict  __buf , size_t __n ,
                              size_t __buflen , int __flags ,
                              struct sockaddr * __restrict  __addr ,
                              socklen_t * __restrict  __addr_len ) ;
extern ssize_t __recvfrom_alias(int __fd , void * __restrict  __buf ,
                                size_t __n , int __flags ,
                                struct sockaddr * __restrict  __addr ,
                                socklen_t * __restrict  __addr_len )  __asm__("recvfrom")  ;
extern ssize_t __recvfrom_chk_warn(int __fd , void * __restrict  __buf ,
                                   size_t __n , size_t __buflen , int __flags ,
                                   struct sockaddr * __restrict  __addr ,
                                   socklen_t * __restrict  __addr_len )  __asm__("__recvfrom_chk") __attribute__((__warning__("recvfrom called with bigger length than size of destination buffer"))) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) recvfrom)(int __fd , void * __restrict  __buf , size_t __n ,
                              int __flags ,
                              struct sockaddr * __restrict  __addr ,
                              socklen_t * __restrict  __addr_len ) 
{ 
  unsigned long tmp ;
  ssize_t tmp___0 ;
  unsigned long tmp___1 ;
  ssize_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  ssize_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 0);
    tmp___0 = __recvfrom_chk(__fd, __buf, __n, tmp, __flags, __addr, __addr_len);
    return ((ssize_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 0);
    if (__n > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 0);
      tmp___2 = __recvfrom_chk_warn(__fd, __buf, __n, tmp___1, __flags, __addr,
                                    __addr_len);
      return ((ssize_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __recvfrom_alias(__fd, __buf, __n, __flags, __addr, __addr_len);
  return ((ssize_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern struct _php_core_globals  __attribute__((__visibility__("default"))) core_globals ;
extern void __attribute__((__visibility__("default")))  zend_register_long_constant(char const   *name ,
                                                                                    uint name_len ,
                                                                                    long lval ,
                                                                                    int flags ,
                                                                                    int module_number ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcscpy)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcsncpy)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcscat)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcsncat)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wmemcpy)(wchar_t * __restrict  __s1 ,
                             wchar_t const   * __restrict  __s2 , size_t __n ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__, __always_inline__)) wmemmove)(wchar_t *__s1 ,
                                              wchar_t const   *__s2 ,
                                              size_t __n ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__, __always_inline__)) wmemset)(wchar_t *__s , wchar_t __c ,
                                             size_t __n ) ;
__inline extern  __attribute__((__nothrow__)) wint_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) btowc)(int __c ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) wctob)(wint_t __wc ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) mbrtowc)(wchar_t * __restrict  __pwc ,
                                                                                 char const   * __restrict  __s ,
                                                                                 size_t __n ,
                                                                                 mbstate_t * __restrict  __p ) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) wcrtomb)(char * __restrict  __s , wchar_t __wchar ,
                             mbstate_t * __restrict  __ps ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbrlen)(char const   * __restrict  __s ,
                                                                                  size_t __n ,
                                                                                  mbstate_t * __restrict  __ps ) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) mbrlen)(char const   * __restrict  __s ,
                                                                                                                          size_t __n ,
                                                                                                                          mbstate_t * __restrict  __ps ) ;
extern wint_t __btowc_alias(int __c )  __asm__("btowc")  ;
__inline extern  __attribute__((__nothrow__)) wint_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) btowc)(int __c ) ;
__inline extern wint_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) btowc)(int __c ) 
{ 
  wint_t tmp ;

  {
  tmp = __btowc_alias(__c);
  return ((wint_t __attribute__((__gnu_inline__))  )tmp);
}
}
extern int __wctob_alias(wint_t __c )  __asm__("wctob")  ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) wctob)(wint_t __wc ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) wctob)(wint_t __wc ) 
{ 
  int tmp ;

  {
  tmp = __wctob_alias(__wc);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) mbrlen)(char const   * __restrict  __s ,
                                                                                                                          size_t __n ,
                                                                                                                          mbstate_t * __restrict  __ps ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) mbrlen)(char const   * __restrict  __s ,
                                                                                            size_t __n ,
                                                                                            mbstate_t * __restrict  __ps ) 
{ 
  size_t tmp ;
  size_t tmp___0 ;
  size_t tmp___1 ;

  {
  if ((unsigned long )__ps != (unsigned long )((void *)0)) {
    tmp = mbrtowc((wchar_t */* __restrict  */)((void *)0), __s, __n, __ps);
    tmp___1 = tmp;
  } else {
    tmp___0 = __mbrlen(__s, __n, (mbstate_t */* __restrict  */)((void *)0));
    tmp___1 = tmp___0;
  }
  return ((size_t __attribute__((__gnu_inline__))  )tmp___1);
}
}
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) mbsrtowcs)(wchar_t * __restrict  __dst ,
                               char const   ** __restrict  __src ,
                               size_t __len , mbstate_t * __restrict  __ps ) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcsrtombs)(char * __restrict  __dst ,
                               wchar_t const   ** __restrict  __src ,
                               size_t __len , mbstate_t * __restrict  __ps ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcpcpy)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcpncpy)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) fwprintf)(__FILE * __restrict  __stream ,
                              wchar_t const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) wprintf)(wchar_t const   * __restrict  __fmt  , ...) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) swprintf)(wchar_t * __restrict  __s ,
                              size_t __n , wchar_t const   * __restrict  __fmt 
                              , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vfwprintf)(__FILE * __restrict  __stream ,
                               wchar_t const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vwprintf)(wchar_t const   * __restrict  __fmt ,
                              __gnuc_va_list __ap ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) vswprintf)(wchar_t * __restrict  __s ,
                               size_t __n ,
                               wchar_t const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fgetws)(wchar_t * __restrict  __s ,
                            int __n , __FILE * __restrict  __stream ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemcpy_chk)(wchar_t * __restrict  __s1 ,
                                                                                         wchar_t const   * __restrict  __s2 ,
                                                                                         size_t __n ,
                                                                                         size_t __ns1 ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemcpy_alias)(wchar_t * __restrict  __s1 ,
                                                                                           wchar_t const   * __restrict  __s2 ,
                                                                                           size_t __n )  __asm__("wmemcpy")  ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemcpy_chk_warn)(wchar_t * __restrict  __s1 ,
                                                                                              wchar_t const   * __restrict  __s2 ,
                                                                                              size_t __n ,
                                                                                              size_t __ns1 )  __asm__("__wmemcpy_chk") __attribute__((__warning__("wmemcpy called with length bigger than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wmemcpy)(wchar_t * __restrict  __s1 ,
                             wchar_t const   * __restrict  __s2 , size_t __n ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wmemcpy)(wchar_t * __restrict  __s1 ,
                             wchar_t const   * __restrict  __s2 , size_t __n ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  wchar_t *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__s1, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s1, 0);
    tmp___0 = __wmemcpy_chk(__s1, __s2, __n, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__s1, 0);
    if (__n > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__s1, 0);
      tmp___2 = __wmemcpy_chk_warn(__s1, __s2, __n, tmp___1 / sizeof(wchar_t ));
      return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wmemcpy_alias(__s1, __s2, __n);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemmove_chk)(wchar_t *__s1 ,
                                                                                          wchar_t const   *__s2 ,
                                                                                          size_t __n ,
                                                                                          size_t __ns1 ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemmove_alias)(wchar_t *__s1 ,
                                                                                            wchar_t const   *__s2 ,
                                                                                            size_t __n )  __asm__("wmemmove")  ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemmove_chk_warn)(wchar_t *__s1 ,
                                                                                               wchar_t const   *__s2 ,
                                                                                               size_t __n ,
                                                                                               size_t __ns1 )  __asm__("__wmemmove_chk") __attribute__((__warning__("wmemmove called with length bigger than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__, __always_inline__)) wmemmove)(wchar_t *__s1 ,
                                              wchar_t const   *__s2 ,
                                              size_t __n ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__, __always_inline__)) wmemmove)(wchar_t *__s1 ,
                                              wchar_t const   *__s2 ,
                                              size_t __n ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  wchar_t *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__s1, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s1, 0);
    tmp___0 = __wmemmove_chk(__s1, __s2, __n, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__s1, 0);
    if (__n > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__s1, 0);
      tmp___2 = __wmemmove_chk_warn(__s1, __s2, __n, tmp___1 / sizeof(wchar_t ));
      return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wmemmove_alias(__s1, __s2, __n);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemset_chk)(wchar_t *__s ,
                                                                                         wchar_t __c ,
                                                                                         size_t __n ,
                                                                                         size_t __ns ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemset_alias)(wchar_t *__s ,
                                                                                           wchar_t __c ,
                                                                                           size_t __n )  __asm__("wmemset")  ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemset_chk_warn)(wchar_t *__s ,
                                                                                              wchar_t __c ,
                                                                                              size_t __n ,
                                                                                              size_t __ns )  __asm__("__wmemset_chk") __attribute__((__warning__("wmemset called with length bigger than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__, __always_inline__)) wmemset)(wchar_t *__s , wchar_t __c ,
                                             size_t __n ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__, __always_inline__)) wmemset)(wchar_t *__s , wchar_t __c ,
                                             size_t __n ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  wchar_t *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__s, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s, 0);
    tmp___0 = __wmemset_chk(__s, __c, __n, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__s, 0);
    if (__n > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__s, 0);
      tmp___2 = __wmemset_chk_warn(__s, __c, __n, tmp___1 / sizeof(wchar_t ));
      return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wmemset_alias(__s, __c, __n);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcscpy_chk)(wchar_t * __restrict  __dest ,
                                                                                        wchar_t const   * __restrict  __src ,
                                                                                        size_t __n ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcscpy_alias)(wchar_t * __restrict  __dest ,
                                                                                          wchar_t const   * __restrict  __src )  __asm__("wcscpy")  ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcscpy)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcscpy)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__dest, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dest, 1);
    tmp___0 = __wcscpy_chk(__dest, __src, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
  } else {

  }
  tmp___2 = __wcscpy_alias(__dest, __src);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
}
}
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcpcpy_chk)(wchar_t * __restrict  __dest ,
                                                                                        wchar_t const   * __restrict  __src ,
                                                                                        size_t __destlen ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcpcpy_alias)(wchar_t * __restrict  __dest ,
                                                                                          wchar_t const   * __restrict  __src )  __asm__("wcpcpy")  ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcpcpy)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcpcpy)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__dest, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dest, 1);
    tmp___0 = __wcpcpy_chk(__dest, __src, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
  } else {

  }
  tmp___2 = __wcpcpy_alias(__dest, __src);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
}
}
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcsncpy_chk)(wchar_t * __restrict  __dest ,
                                                                                         wchar_t const   * __restrict  __src ,
                                                                                         size_t __n ,
                                                                                         size_t __destlen ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcsncpy_alias)(wchar_t * __restrict  __dest ,
                                                                                           wchar_t const   * __restrict  __src ,
                                                                                           size_t __n )  __asm__("wcsncpy")  ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcsncpy_chk_warn)(wchar_t * __restrict  __dest ,
                                                                                              wchar_t const   * __restrict  __src ,
                                                                                              size_t __n ,
                                                                                              size_t __destlen )  __asm__("__wcsncpy_chk") __attribute__((__warning__("wcsncpy called with length bigger than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcsncpy)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcsncpy)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  wchar_t *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__dest, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dest, 1);
    tmp___0 = __wcsncpy_chk(__dest, __src, __n, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__dest, 1);
    if (__n > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__dest, 1);
      tmp___2 = __wcsncpy_chk_warn(__dest, __src, __n,
                                   tmp___1 / sizeof(wchar_t ));
      return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wcsncpy_alias(__dest, __src, __n);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcpncpy_chk)(wchar_t * __restrict  __dest ,
                                                                                         wchar_t const   * __restrict  __src ,
                                                                                         size_t __n ,
                                                                                         size_t __destlen ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcpncpy_alias)(wchar_t * __restrict  __dest ,
                                                                                           wchar_t const   * __restrict  __src ,
                                                                                           size_t __n )  __asm__("wcpncpy")  ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcpncpy_chk_warn)(wchar_t * __restrict  __dest ,
                                                                                              wchar_t const   * __restrict  __src ,
                                                                                              size_t __n ,
                                                                                              size_t __destlen )  __asm__("__wcpncpy_chk") __attribute__((__warning__("wcpncpy called with length bigger than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcpncpy)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcpncpy)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  wchar_t *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__dest, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dest, 1);
    tmp___0 = __wcpncpy_chk(__dest, __src, __n, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__dest, 1);
    if (__n > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__dest, 1);
      tmp___2 = __wcpncpy_chk_warn(__dest, __src, __n,
                                   tmp___1 / sizeof(wchar_t ));
      return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wcpncpy_alias(__dest, __src, __n);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcscat_chk)(wchar_t * __restrict  __dest ,
                                                                                        wchar_t const   * __restrict  __src ,
                                                                                        size_t __destlen ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcscat_alias)(wchar_t * __restrict  __dest ,
                                                                                          wchar_t const   * __restrict  __src )  __asm__("wcscat")  ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcscat)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcscat)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__dest, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dest, 1);
    tmp___0 = __wcscat_chk(__dest, __src, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
  } else {

  }
  tmp___2 = __wcscat_alias(__dest, __src);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
}
}
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcsncat_chk)(wchar_t * __restrict  __dest ,
                                                                                         wchar_t const   * __restrict  __src ,
                                                                                         size_t __n ,
                                                                                         size_t __destlen ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcsncat_alias)(wchar_t * __restrict  __dest ,
                                                                                           wchar_t const   * __restrict  __src ,
                                                                                           size_t __n )  __asm__("wcsncat")  ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcsncat)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcsncat)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__dest, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dest, 1);
    tmp___0 = __wcsncat_chk(__dest, __src, __n, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
  } else {

  }
  tmp___2 = __wcsncat_alias(__dest, __src, __n);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__leaf__)) __swprintf_chk)(wchar_t * __restrict  __s ,
                                                                                     size_t __n ,
                                                                                     int __flag ,
                                                                                     size_t __s_len ,
                                                                                     wchar_t const   * __restrict  __format 
                                                                                     , ...) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__leaf__)) __swprintf_alias)(wchar_t * __restrict  __s ,
                                                                                       size_t __n ,
                                                                                       wchar_t const   * __restrict  __fmt 
                                                                                       , ...)  __asm__("swprintf")  ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) swprintf)(wchar_t * __restrict  __s ,
                              size_t __n , wchar_t const   * __restrict  __fmt 
                              , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) swprintf)(wchar_t * __restrict  __s ,
                              size_t __n , wchar_t const   * __restrict  __fmt 
                              , ...) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__s, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s, 1);
    tmp___0 = __swprintf_chk(__s, __n, 1, tmp / sizeof(wchar_t ), __fmt,
                             __builtin_va_arg_pack());
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
  } else {
    tmp = __builtin_object_size((void *)__s, 1);
    tmp___0 = __swprintf_chk(__s, __n, 1, tmp / sizeof(wchar_t ), __fmt,
                             __builtin_va_arg_pack());
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
  }
  tmp___2 = __swprintf_alias(__s, __n, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__leaf__)) __vswprintf_chk)(wchar_t * __restrict  __s ,
                                                                                      size_t __n ,
                                                                                      int __flag ,
                                                                                      size_t __s_len ,
                                                                                      wchar_t const   * __restrict  __format ,
                                                                                      __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__leaf__)) __vswprintf_alias)(wchar_t * __restrict  __s ,
                                                                                        size_t __n ,
                                                                                        wchar_t const   * __restrict  __fmt ,
                                                                                        __gnuc_va_list __ap )  __asm__("vswprintf")  ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) vswprintf)(wchar_t * __restrict  __s ,
                               size_t __n ,
                               wchar_t const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) vswprintf)(wchar_t * __restrict  __s ,
                               size_t __n ,
                               wchar_t const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__s, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s, 1);
    tmp___0 = __vswprintf_chk(__s, __n, 1, tmp / sizeof(wchar_t ), __fmt, __ap);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
  } else {
    tmp = __builtin_object_size((void *)__s, 1);
    tmp___0 = __vswprintf_chk(__s, __n, 1, tmp / sizeof(wchar_t ), __fmt, __ap);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
  }
  tmp___2 = __vswprintf_alias(__s, __n, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
extern int __fwprintf_chk(__FILE * __restrict  __stream , int __flag ,
                          wchar_t const   * __restrict  __format  , ...) ;
extern int __wprintf_chk(int __flag , wchar_t const   * __restrict  __format 
                         , ...) ;
extern int __vfwprintf_chk(__FILE * __restrict  __stream , int __flag ,
                           wchar_t const   * __restrict  __format ,
                           __gnuc_va_list __ap ) ;
extern int __vwprintf_chk(int __flag , wchar_t const   * __restrict  __format ,
                          __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) wprintf)(wchar_t const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __wprintf_chk(1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) fwprintf)(__FILE * __restrict  __stream ,
                              wchar_t const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __fwprintf_chk(__stream, 1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vwprintf)(wchar_t const   * __restrict  __fmt ,
                              __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __vwprintf_chk(1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vfwprintf)(__FILE * __restrict  __stream ,
                               wchar_t const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __vfwprintf_chk(__stream, 1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
extern wchar_t *( __attribute__((__warn_unused_result__)) __fgetws_chk)(wchar_t * __restrict  __s ,
                                                                        size_t __size ,
                                                                        int __n ,
                                                                        __FILE * __restrict  __stream ) ;
extern wchar_t *( __attribute__((__warn_unused_result__)) __fgetws_alias)(wchar_t * __restrict  __s ,
                                                                          int __n ,
                                                                          __FILE * __restrict  __stream )  __asm__("fgetws")  ;
extern wchar_t *( __attribute__((__warn_unused_result__)) __fgetws_chk_warn)(wchar_t * __restrict  __s ,
                                                                             size_t __size ,
                                                                             int __n ,
                                                                             __FILE * __restrict  __stream )  __asm__("__fgetws_chk") __attribute__((__warning__("fgetws called with bigger size than length of destination buffer"))) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fgetws)(wchar_t * __restrict  __s ,
                            int __n , __FILE * __restrict  __stream ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  wchar_t *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__s, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s, 1);
    tmp___0 = __fgetws_chk(__s, tmp / sizeof(wchar_t ), __n, __stream);
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__s, 1);
    if ((size_t )__n > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__s, 1);
      tmp___2 = __fgetws_chk_warn(__s, tmp___1 / sizeof(wchar_t ), __n, __stream);
      return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __fgetws_alias(__s, __n, __stream);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__warn_unused_result__,
__leaf__)) __wcrtomb_chk)(char * __restrict  __s , wchar_t __wchar ,
                          mbstate_t * __restrict  __p , size_t __buflen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__warn_unused_result__,
__leaf__)) __wcrtomb_alias)(char * __restrict  __s , wchar_t __wchar ,
                            mbstate_t * __restrict  __ps )  __asm__("wcrtomb")  ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) wcrtomb)(char * __restrict  __s , wchar_t __wchar ,
                             mbstate_t * __restrict  __ps ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) wcrtomb)(char * __restrict  __s , wchar_t __wchar ,
                             mbstate_t * __restrict  __ps ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  unsigned long tmp___2 ;
  size_t tmp___3 ;

  {
  tmp___1 = __builtin_object_size((void *)__s, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp___2 = __builtin_object_size((void *)__s, 1);
    if (16UL > tmp___2) {
      tmp = __builtin_object_size((void *)__s, 1);
      tmp___0 = __wcrtomb_chk(__s, __wchar, __ps, tmp);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    } else {

    }
  } else {

  }
  tmp___3 = __wcrtomb_alias(__s, __wchar, __ps);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___3);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbsrtowcs_chk)(wchar_t * __restrict  __dst ,
                                                                                         char const   ** __restrict  __src ,
                                                                                         size_t __len ,
                                                                                         mbstate_t * __restrict  __ps ,
                                                                                         size_t __dstlen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbsrtowcs_alias)(wchar_t * __restrict  __dst ,
                                                                                           char const   ** __restrict  __src ,
                                                                                           size_t __len ,
                                                                                           mbstate_t * __restrict  __ps )  __asm__("mbsrtowcs")  ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbsrtowcs_chk_warn)(wchar_t * __restrict  __dst ,
                                                                                              char const   ** __restrict  __src ,
                                                                                              size_t __len ,
                                                                                              mbstate_t * __restrict  __ps ,
                                                                                              size_t __dstlen )  __asm__("__mbsrtowcs_chk") __attribute__((__warning__("mbsrtowcs called with dst buffer smaller than len * sizeof (wchar_t)"))) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) mbsrtowcs)(wchar_t * __restrict  __dst ,
                               char const   ** __restrict  __src ,
                               size_t __len , mbstate_t * __restrict  __ps ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) mbsrtowcs)(wchar_t * __restrict  __dst ,
                               char const   ** __restrict  __src ,
                               size_t __len , mbstate_t * __restrict  __ps ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__dst, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dst, 1);
    tmp___0 = __mbsrtowcs_chk(__dst, __src, __len, __ps, tmp / sizeof(wchar_t ));
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__dst, 1);
    if (__len > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__dst, 1);
      tmp___2 = __mbsrtowcs_chk_warn(__dst, __src, __len, __ps,
                                     tmp___1 / sizeof(wchar_t ));
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __mbsrtowcs_alias(__dst, __src, __len, __ps);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcsrtombs_chk)(char * __restrict  __dst ,
                                                                                         wchar_t const   ** __restrict  __src ,
                                                                                         size_t __len ,
                                                                                         mbstate_t * __restrict  __ps ,
                                                                                         size_t __dstlen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcsrtombs_alias)(char * __restrict  __dst ,
                                                                                           wchar_t const   ** __restrict  __src ,
                                                                                           size_t __len ,
                                                                                           mbstate_t * __restrict  __ps )  __asm__("wcsrtombs")  ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcsrtombs_chk_warn)(char * __restrict  __dst ,
                                                                                              wchar_t const   ** __restrict  __src ,
                                                                                              size_t __len ,
                                                                                              mbstate_t * __restrict  __ps ,
                                                                                              size_t __dstlen )  __asm__("__wcsrtombs_chk") __attribute__((__warning__("wcsrtombs called with dst buffer smaller than len"))) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcsrtombs)(char * __restrict  __dst ,
                               wchar_t const   ** __restrict  __src ,
                               size_t __len , mbstate_t * __restrict  __ps ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcsrtombs)(char * __restrict  __dst ,
                               wchar_t const   ** __restrict  __src ,
                               size_t __len , mbstate_t * __restrict  __ps ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__dst, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dst, 1);
    tmp___0 = __wcsrtombs_chk(__dst, __src, __len, __ps, tmp);
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__dst, 1);
    if (__len > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__dst, 1);
      tmp___2 = __wcsrtombs_chk_warn(__dst, __src, __len, __ps, tmp___1);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wcsrtombs_alias(__dst, __src, __len, __ps);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
void zif_str_rot13(int ht , zval *return_value , zval **return_value_ptr ,
                   zval *this_ptr , int return_value_used ) ;
extern php_basic_globals __attribute__((__visibility__("default")))  basic_globals ;
extern long __attribute__((__visibility__("default")))  php_rand(void) ;
void zif_strspn(int ht , zval *return_value , zval **return_value_ptr ,
                zval *this_ptr , int return_value_used ) ;
void zif_strcspn(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) ;
void zif_str_replace(int ht , zval *return_value , zval **return_value_ptr ,
                     zval *this_ptr , int return_value_used ) ;
void zif_str_ireplace(int ht , zval *return_value , zval **return_value_ptr ,
                      zval *this_ptr , int return_value_used ) ;
void zif_rtrim(int ht , zval *return_value , zval **return_value_ptr ,
               zval *this_ptr , int return_value_used ) ;
void zif_trim(int ht , zval *return_value , zval **return_value_ptr ,
              zval *this_ptr , int return_value_used ) ;
void zif_ltrim(int ht , zval *return_value , zval **return_value_ptr ,
               zval *this_ptr , int return_value_used ) ;
void zif_count_chars(int ht , zval *return_value , zval **return_value_ptr ,
                     zval *this_ptr , int return_value_used ) ;
void zif_wordwrap(int ht , zval *return_value , zval **return_value_ptr ,
                  zval *this_ptr , int return_value_used ) ;
void zif_explode(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) ;
void zif_implode(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) ;
void zif_strtok(int ht , zval *return_value , zval **return_value_ptr ,
                zval *this_ptr , int return_value_used ) ;
void zif_strtoupper(int ht , zval *return_value , zval **return_value_ptr ,
                    zval *this_ptr , int return_value_used ) ;
void zif_strtolower(int ht , zval *return_value , zval **return_value_ptr ,
                    zval *this_ptr , int return_value_used ) ;
void zif_basename(int ht , zval *return_value , zval **return_value_ptr ,
                  zval *this_ptr , int return_value_used ) ;
void zif_dirname(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) ;
void zif_pathinfo(int ht , zval *return_value , zval **return_value_ptr ,
                  zval *this_ptr , int return_value_used ) ;
void zif_strstr(int ht , zval *return_value , zval **return_value_ptr ,
                zval *this_ptr , int return_value_used ) ;
void zif_strpos(int ht , zval *return_value , zval **return_value_ptr ,
                zval *this_ptr , int return_value_used ) ;
void zif_stripos(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) ;
void zif_strrpos(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) ;
void zif_strripos(int ht , zval *return_value , zval **return_value_ptr ,
                  zval *this_ptr , int return_value_used ) ;
void zif_strrchr(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) ;
void zif_substr(int ht , zval *return_value , zval **return_value_ptr ,
                zval *this_ptr , int return_value_used ) ;
void zif_quotemeta(int ht , zval *return_value , zval **return_value_ptr ,
                   zval *this_ptr , int return_value_used ) ;
void zif_ucfirst(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) ;
void zif_lcfirst(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) ;
void zif_ucwords(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) ;
void zif_strtr(int ht , zval *return_value , zval **return_value_ptr ,
               zval *this_ptr , int return_value_used ) ;
void zif_strrev(int ht , zval *return_value , zval **return_value_ptr ,
                zval *this_ptr , int return_value_used ) ;
void zif_hebrev(int ht , zval *return_value , zval **return_value_ptr ,
                zval *this_ptr , int return_value_used ) ;
void zif_hebrevc(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) ;
void zif_addcslashes(int ht , zval *return_value , zval **return_value_ptr ,
                     zval *this_ptr , int return_value_used ) ;
void zif_addslashes(int ht , zval *return_value , zval **return_value_ptr ,
                    zval *this_ptr , int return_value_used ) ;
void zif_stripcslashes(int ht , zval *return_value , zval **return_value_ptr ,
                       zval *this_ptr , int return_value_used ) ;
void zif_stripslashes(int ht , zval *return_value , zval **return_value_ptr ,
                      zval *this_ptr , int return_value_used ) ;
void zif_chr(int ht , zval *return_value , zval **return_value_ptr ,
             zval *this_ptr , int return_value_used ) ;
void zif_ord(int ht , zval *return_value , zval **return_value_ptr ,
             zval *this_ptr , int return_value_used ) ;
void zif_nl2br(int ht , zval *return_value , zval **return_value_ptr ,
               zval *this_ptr , int return_value_used ) ;
void zif_setlocale(int ht , zval *return_value , zval **return_value_ptr ,
                   zval *this_ptr , int return_value_used ) ;
void zif_localeconv(int ht , zval *return_value , zval **return_value_ptr ,
                    zval *this_ptr , int return_value_used ) ;
void zif_nl_langinfo(int ht , zval *return_value , zval **return_value_ptr ,
                     zval *this_ptr , int return_value_used ) ;
void zif_stristr(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) ;
void zif_chunk_split(int ht , zval *return_value , zval **return_value_ptr ,
                     zval *this_ptr , int return_value_used ) ;
void zif_parse_str(int ht , zval *return_value , zval **return_value_ptr ,
                   zval *this_ptr , int return_value_used ) ;
void zif_str_getcsv(int ht , zval *return_value , zval **return_value_ptr ,
                    zval *this_ptr , int return_value_used ) ;
void zif_bin2hex(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) ;
void zif_similar_text(int ht , zval *return_value , zval **return_value_ptr ,
                      zval *this_ptr , int return_value_used ) ;
void zif_strip_tags(int ht , zval *return_value , zval **return_value_ptr ,
                    zval *this_ptr , int return_value_used ) ;
void zif_str_repeat(int ht , zval *return_value , zval **return_value_ptr ,
                    zval *this_ptr , int return_value_used ) ;
void zif_substr_replace(int ht , zval *return_value , zval **return_value_ptr ,
                        zval *this_ptr , int return_value_used ) ;
void zif_strnatcmp(int ht , zval *return_value , zval **return_value_ptr ,
                   zval *this_ptr , int return_value_used ) ;
void zif_strnatcasecmp(int ht , zval *return_value , zval **return_value_ptr ,
                       zval *this_ptr , int return_value_used ) ;
void zif_substr_count(int ht , zval *return_value , zval **return_value_ptr ,
                      zval *this_ptr , int return_value_used ) ;
void zif_str_pad(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) ;
void zif_sscanf(int ht , zval *return_value , zval **return_value_ptr ,
                zval *this_ptr , int return_value_used ) ;
void zif_str_shuffle(int ht , zval *return_value , zval **return_value_ptr ,
                     zval *this_ptr , int return_value_used ) ;
void zif_str_word_count(int ht , zval *return_value , zval **return_value_ptr ,
                        zval *this_ptr , int return_value_used ) ;
void zif_str_split(int ht , zval *return_value , zval **return_value_ptr ,
                   zval *this_ptr , int return_value_used ) ;
void zif_strpbrk(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) ;
void zif_substr_compare(int ht , zval *return_value , zval **return_value_ptr ,
                        zval *this_ptr , int return_value_used ) ;
void zif_strcoll(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) ;
void zif_money_format(int ht , zval *return_value , zval **return_value_ptr ,
                      zval *this_ptr , int return_value_used ) ;
int zm_startup_nl_langinfo(int type , int module_number ) ;
extern int __attribute__((__visibility__("default")))  strnatcmp_ex(char const   *a ,
                                                                    size_t a_len ,
                                                                    char const   *b ,
                                                                    size_t b_len ,
                                                                    int fold_case ) ;
struct lconv  __attribute__((__visibility__("default"))) *localeconv_r(struct lconv *out ) ;
char __attribute__((__visibility__("default")))  *php_strtoupper(char *s ,
                                                                 size_t len ) ;
char __attribute__((__visibility__("default")))  *php_strtolower(char *s ,
                                                                 size_t len ) ;
char __attribute__((__visibility__("default")))  *php_strtr(char *str ,
                                                            int len ,
                                                            char *str_from ,
                                                            char *str_to ,
                                                            int trlen ) ;
char __attribute__((__visibility__("default")))  *php_addslashes(char *str ,
                                                                 int length ,
                                                                 int *new_length ,
                                                                 int should_free ) ;
char __attribute__((__visibility__("default")))  *php_addslashes_ex(char *str ,
                                                                    int length ,
                                                                    int *new_length ,
                                                                    int should_free ,
                                                                    int ignore_sybase ) ;
char __attribute__((__visibility__("default")))  *php_addcslashes(char *str ,
                                                                  int length ,
                                                                  int *new_length ,
                                                                  int should_free ,
                                                                  char *what ,
                                                                  int wlength ) ;
void __attribute__((__visibility__("default")))  php_stripslashes(char *str ,
                                                                  int *len ) ;
void __attribute__((__visibility__("default")))  php_stripcslashes(char *str ,
                                                                   int *len ) ;
void __attribute__((__visibility__("default")))  php_basename(char *s ,
                                                              size_t len ,
                                                              char *suffix ,
                                                              size_t sufflen ,
                                                              char **p_ret ,
                                                              size_t *p_len ) ;
size_t __attribute__((__visibility__("default")))  php_dirname(char *path ,
                                                               size_t len ) ;
char __attribute__((__visibility__("default")))  *php_stristr(char *s ,
                                                              char *t ,
                                                              size_t s_len ,
                                                              size_t t_len ) ;
char __attribute__((__visibility__("default")))  *php_str_to_str_ex(char *haystack ,
                                                                    int length ,
                                                                    char *needle ,
                                                                    int needle_len ,
                                                                    char *str ,
                                                                    int str_len ,
                                                                    int *_new_length ,
                                                                    int case_sensitivity ,
                                                                    int *replace_count ) ;
char __attribute__((__visibility__("default")))  *php_str_to_str(char *haystack ,
                                                                 int length ,
                                                                 char *needle ,
                                                                 int needle_len ,
                                                                 char *str ,
                                                                 int str_len ,
                                                                 int *_new_length ) ;
char __attribute__((__visibility__("default")))  *php_trim(char *c , int len ,
                                                           char *what ,
                                                           int what_len ,
                                                           zval *return_value ,
                                                           int mode ) ;
size_t __attribute__((__visibility__("default")))  php_strip_tags(char *rbuf ,
                                                                  int len ,
                                                                  int *stateptr ,
                                                                  char *allow ,
                                                                  int allow_len ) ;
size_t __attribute__((__visibility__("default")))  php_strip_tags_ex(char *rbuf ,
                                                                     int len ,
                                                                     int *stateptr ,
                                                                     char *allow ,
                                                                     int allow_len ,
                                                                     zend_bool allow_tag_spaces ) ;
int __attribute__((__visibility__("default")))  php_char_to_str_ex(char *str ,
                                                                   uint len ,
                                                                   char from ,
                                                                   char *to ,
                                                                   int to_len ,
                                                                   zval *result ,
                                                                   int case_sensitivity ,
                                                                   int *replace_count ) ;
int __attribute__((__visibility__("default")))  php_char_to_str(char *str ,
                                                                uint len ,
                                                                char from ,
                                                                char *to ,
                                                                int to_len ,
                                                                zval *result ) ;
void __attribute__((__visibility__("default")))  php_implode(zval *delim ,
                                                             zval *arr ,
                                                             zval *return_value ) ;
void __attribute__((__visibility__("default")))  php_explode(zval *delim ,
                                                             zval *str ,
                                                             zval *return_value ,
                                                             long limit ) ;
size_t __attribute__((__visibility__("default")))  php_strspn(char *s1 ,
                                                              char *s2 ,
                                                              char *s1_end ,
                                                              char *s2_end ) ;
size_t __attribute__((__visibility__("default")))  php_strcspn(char *s1 ,
                                                               char *s2 ,
                                                               char *s1_end ,
                                                               char *s2_end ) ;
void register_string_constants(int type , int module_number ) ;
extern sapi_module_struct __attribute__((__visibility__("default")))  sapi_module ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__leaf__)) setlocale)(int __category ,
                                                                                  char const   *__locale ) ;
extern  __attribute__((__nothrow__)) struct lconv *( __attribute__((__leaf__)) localeconv)(void) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__leaf__)) nl_langinfo)(nl_item __item ) ;
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__leaf__)) strfmon)(char * __restrict  __s ,
                                                                                  size_t __maxsize ,
                                                                                  char const   * __restrict  __format 
                                                                                  , ...) ;
extern int __attribute__((__visibility__("default")))  php_sscanf_internal(char *string ,
                                                                           char *format ,
                                                                           int argCount ,
                                                                           zval ***args ,
                                                                           int varStart ,
                                                                           zval **return_value ) ;
extern void __attribute__((__visibility__("default")))  php_fgetcsv(php_stream *stream ,
                                                                    char delimiter ,
                                                                    char enclosure ,
                                                                    char escape_char ,
                                                                    size_t buf_len ,
                                                                    char *buf ,
                                                                    zval *return_value ) ;
void register_string_constants(int type , int module_number ) 
{ 


  {
  zend_register_long_constant("STR_PAD_LEFT", (uint )sizeof("STR_PAD_LEFT"), 0L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("STR_PAD_RIGHT", (uint )sizeof("STR_PAD_RIGHT"),
                              1L, 1 | (1 << 1), module_number);
  zend_register_long_constant("STR_PAD_BOTH", (uint )sizeof("STR_PAD_BOTH"), 2L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("PATHINFO_DIRNAME",
                              (uint )sizeof("PATHINFO_DIRNAME"), 1L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("PATHINFO_BASENAME",
                              (uint )sizeof("PATHINFO_BASENAME"), 2L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("PATHINFO_EXTENSION",
                              (uint )sizeof("PATHINFO_EXTENSION"), 4L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("PATHINFO_FILENAME",
                              (uint )sizeof("PATHINFO_FILENAME"), 8L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("CHAR_MAX", (uint )sizeof("CHAR_MAX"), 127L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("LC_CTYPE", (uint )sizeof("LC_CTYPE"), 0L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("LC_NUMERIC", (uint )sizeof("LC_NUMERIC"), 1L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("LC_TIME", (uint )sizeof("LC_TIME"), 2L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("LC_COLLATE", (uint )sizeof("LC_COLLATE"), 3L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("LC_MONETARY", (uint )sizeof("LC_MONETARY"), 4L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("LC_ALL", (uint )sizeof("LC_ALL"), 6L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("LC_MESSAGES", (uint )sizeof("LC_MESSAGES"), 5L,
                              1 | (1 << 1), module_number);
  return;
}
}
int php_tag_find(char *tag , int len , char *set ) ;
static char hexconvtab[17]  = 
  {      (char )'0',      (char )'1',      (char )'2',      (char )'3', 
        (char )'4',      (char )'5',      (char )'6',      (char )'7', 
        (char )'8',      (char )'9',      (char )'a',      (char )'b', 
        (char )'c',      (char )'d',      (char )'e',      (char )'f', 
        (char )'\000'};
static char *php_bin2hex(unsigned char const   *old , size_t const   oldlen ,
                         size_t *newlen ) 
{ 
  register unsigned char *result ;
  size_t i ;
  size_t j ;
  void __attribute__((__visibility__("default")))  *tmp ;
  size_t tmp___0 ;
  size_t tmp___1 ;

  {
  result = (unsigned char *)((void *)0);
  tmp = _safe_emalloc((size_t )(oldlen * 2UL), sizeof(char ), (size_t )1);
  result = (unsigned char *)tmp;
  j = (size_t )0;
  i = j;
  while (i < (size_t )oldlen) {
    tmp___0 = j;
    j ++;
    *(result + tmp___0) = (unsigned char )hexconvtab[(int const   )*(old + i) >> 4];
    tmp___1 = j;
    j ++;
    *(result + tmp___1) = (unsigned char )hexconvtab[(int const   )*(old + i) & 15];
    i ++;
  }
  *(result + j) = (unsigned char )'\000';
  if (newlen) {
    *newlen = (size_t )((oldlen * 2UL) * (size_t const   )sizeof(char ));
  } else {

  }
  return ((char *)result);
}
}
struct lconv  __attribute__((__visibility__("default"))) *localeconv_r(struct lconv *out ) 
{ 
  struct lconv *res ;

  {
  res = localeconv();
  *out = *res;
  return ((struct lconv  __attribute__((__visibility__("default"))) *)out);
}
}
void zif_bin2hex(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) 
{ 
  char *result ;
  char *data ;
  size_t newlen ;
  int datalen ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  char const   *__s ;
  int __l ;
  zval *__z___0 ;

  {
  tmp = zend_parse_parameters(ht, "s", & data, & datalen);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  result = php_bin2hex((unsigned char const   *)((unsigned char *)data),
                       (size_t const   )datalen, & newlen);
  if (! result) {
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  while (1) {
    __s = (char const   *)result;
    __l = (int )newlen;
    __z___0 = return_value;
    __z___0->value.str.len = __l;
    __z___0->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z___0->type = (zend_uchar )6;
    break;
  }
  return;
}
}
static void php_spn_common_handler(int ht , zval *return_value ,
                                   zval **return_value_ptr , zval *this_ptr ,
                                   int return_value_used , int behavior ) 
{ 
  char *s11 ;
  char *s22 ;
  int len1 ;
  int len2 ;
  long start ;
  long len ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  zval *__z___0 ;
  zval *__z___1 ;
  size_t __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z___2 ;
  size_t __attribute__((__visibility__("default")))  tmp___1 ;

  {
  start = 0L;
  len = 0L;
  tmp = zend_parse_parameters(ht, "ss|ll", & s11, & len1, & s22, & len2,
                              & start, & len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (ht < 4) {
    len = (long )len1;
  } else {

  }
  if (start < 0L) {
    start += (long )len1;
    if (start < 0L) {
      start = 0L;
    } else {

    }
  } else
  if (start > (long )len1) {
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  if (len < 0L) {
    len += (long )len1 - start;
    if (len < 0L) {
      len = 0L;
    } else {

    }
  } else {

  }
  if (len > (long )len1 - start) {
    len = (long )len1 - start;
  } else {

  }
  if (len == 0L) {
    __z___0 = return_value;
    __z___0->value.lval = 0L;
    __z___0->type = (zend_uchar )1;
    return;
  } else {

  }
  if (behavior == 0) {
    __z___1 = return_value;
    tmp___0 = php_strspn(s11 + start, s22, (s11 + start) + len, s22 + len2);
    __z___1->value.lval = (long )tmp___0;
    __z___1->type = (zend_uchar )1;
    return;
  } else
  if (behavior == 1) {
    __z___2 = return_value;
    tmp___1 = php_strcspn(s11 + start, s22, (s11 + start) + len, s22 + len2);
    __z___2->value.lval = (long )tmp___1;
    __z___2->type = (zend_uchar )1;
    return;
  } else {

  }
  return;
}
}
void zif_strspn(int ht , zval *return_value , zval **return_value_ptr ,
                zval *this_ptr , int return_value_used ) 
{ 


  {
  php_spn_common_handler(ht, return_value, return_value_ptr, this_ptr,
                         return_value_used, 0);
  return;
}
}
void zif_strcspn(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) 
{ 


  {
  php_spn_common_handler(ht, return_value, return_value_ptr, this_ptr,
                         return_value_used, 1);
  return;
}
}
int zm_startup_nl_langinfo(int type , int module_number ) 
{ 


  {
  zend_register_long_constant("ABDAY_1", (uint )sizeof("ABDAY_1"), 131072L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("ABDAY_2", (uint )sizeof("ABDAY_2"), 131073L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("ABDAY_3", (uint )sizeof("ABDAY_3"), 131074L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("ABDAY_4", (uint )sizeof("ABDAY_4"), 131075L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("ABDAY_5", (uint )sizeof("ABDAY_5"), 131076L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("ABDAY_6", (uint )sizeof("ABDAY_6"), 131077L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("ABDAY_7", (uint )sizeof("ABDAY_7"), 131078L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("DAY_1", (uint )sizeof("DAY_1"), 131079L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("DAY_2", (uint )sizeof("DAY_2"), 131080L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("DAY_3", (uint )sizeof("DAY_3"), 131081L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("DAY_4", (uint )sizeof("DAY_4"), 131082L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("DAY_5", (uint )sizeof("DAY_5"), 131083L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("DAY_6", (uint )sizeof("DAY_6"), 131084L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("DAY_7", (uint )sizeof("DAY_7"), 131085L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("ABMON_1", (uint )sizeof("ABMON_1"), 131086L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("ABMON_2", (uint )sizeof("ABMON_2"), 131087L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("ABMON_3", (uint )sizeof("ABMON_3"), 131088L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("ABMON_4", (uint )sizeof("ABMON_4"), 131089L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("ABMON_5", (uint )sizeof("ABMON_5"), 131090L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("ABMON_6", (uint )sizeof("ABMON_6"), 131091L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("ABMON_7", (uint )sizeof("ABMON_7"), 131092L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("ABMON_8", (uint )sizeof("ABMON_8"), 131093L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("ABMON_9", (uint )sizeof("ABMON_9"), 131094L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("ABMON_10", (uint )sizeof("ABMON_10"), 131095L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("ABMON_11", (uint )sizeof("ABMON_11"), 131096L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("ABMON_12", (uint )sizeof("ABMON_12"), 131097L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("MON_1", (uint )sizeof("MON_1"), 131098L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("MON_2", (uint )sizeof("MON_2"), 131099L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("MON_3", (uint )sizeof("MON_3"), 131100L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("MON_4", (uint )sizeof("MON_4"), 131101L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("MON_5", (uint )sizeof("MON_5"), 131102L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("MON_6", (uint )sizeof("MON_6"), 131103L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("MON_7", (uint )sizeof("MON_7"), 131104L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("MON_8", (uint )sizeof("MON_8"), 131105L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("MON_9", (uint )sizeof("MON_9"), 131106L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("MON_10", (uint )sizeof("MON_10"), 131107L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("MON_11", (uint )sizeof("MON_11"), 131108L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("MON_12", (uint )sizeof("MON_12"), 131109L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("AM_STR", (uint )sizeof("AM_STR"), 131110L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("PM_STR", (uint )sizeof("PM_STR"), 131111L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("D_T_FMT", (uint )sizeof("D_T_FMT"), 131112L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("D_FMT", (uint )sizeof("D_FMT"), 131113L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("T_FMT", (uint )sizeof("T_FMT"), 131114L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("T_FMT_AMPM", (uint )sizeof("T_FMT_AMPM"),
                              131115L, 1 | (1 << 1), module_number);
  zend_register_long_constant("ERA", (uint )sizeof("ERA"), 131116L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("ERA_D_T_FMT", (uint )sizeof("ERA_D_T_FMT"),
                              131120L, 1 | (1 << 1), module_number);
  zend_register_long_constant("ERA_D_FMT", (uint )sizeof("ERA_D_FMT"), 131118L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("ERA_T_FMT", (uint )sizeof("ERA_T_FMT"), 131121L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("ALT_DIGITS", (uint )sizeof("ALT_DIGITS"),
                              131119L, 1 | (1 << 1), module_number);
  zend_register_long_constant("CRNCYSTR", (uint )sizeof("CRNCYSTR"), 262159L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("RADIXCHAR", (uint )sizeof("RADIXCHAR"), 65536L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("THOUSEP", (uint )sizeof("THOUSEP"), 65537L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("YESEXPR", (uint )sizeof("YESEXPR"), 327680L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("NOEXPR", (uint )sizeof("NOEXPR"), 327681L,
                              1 | (1 << 1), module_number);
  zend_register_long_constant("CODESET", (uint )sizeof("CODESET"), 14L,
                              1 | (1 << 1), module_number);
  return (0);
}
}
void zif_nl_langinfo(int ht , zval *return_value , zval **return_value_ptr ,
                     zval *this_ptr , int return_value_used ) 
{ 
  long item ;
  char *value ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  zval *__z___0 ;
  char const   *__s ;
  zval *__z___1 ;
  size_t tmp___0 ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;

  {
  tmp = zend_parse_parameters(ht, "l", & item);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  switch (item) {
  case 131072L: 
  case 131073L: 
  case 131074L: 
  case 131075L: 
  case 131076L: 
  case 131077L: 
  case 131078L: 
  case 131079L: 
  case 131080L: 
  case 131081L: 
  case 131082L: 
  case 131083L: 
  case 131084L: 
  case 131085L: 
  case 131086L: 
  case 131087L: 
  case 131088L: 
  case 131089L: 
  case 131090L: 
  case 131091L: 
  case 131092L: 
  case 131093L: 
  case 131094L: 
  case 131095L: 
  case 131096L: 
  case 131097L: 
  case 131098L: 
  case 131099L: 
  case 131100L: 
  case 131101L: 
  case 131102L: 
  case 131103L: 
  case 131104L: 
  case 131105L: 
  case 131106L: 
  case 131107L: 
  case 131108L: 
  case 131109L: 
  case 131110L: 
  case 131111L: 
  case 131112L: 
  case 131113L: 
  case 131114L: 
  case 131115L: 
  case 131116L: 
  case 131120L: 
  case 131118L: 
  case 131121L: 
  case 131119L: 
  case 262159L: 
  case 65536L: 
  case 65537L: 
  case 327680L: 
  case 327681L: 
  case 14L: 
  break;
  default: 
  php_error_docref0((char const   *)((void *)0), 1 << 1L,
                    "Item \'%ld\' is not valid", item);
  while (1) {
    __z = return_value;
    __z->value.lval = 0L;
    __z->type = (zend_uchar )3;
    break;
  }
  return;
  }
  value = nl_langinfo((nl_item )item);
  if ((unsigned long )value == (unsigned long )((void *)0)) {
    while (1) {
      __z___0 = return_value;
      __z___0->value.lval = 0L;
      __z___0->type = (zend_uchar )3;
      break;
    }
    return;
  } else {
    while (1) {
      __s = (char const   *)value;
      __z___1 = return_value;
      tmp___0 = strlen(__s);
      __z___1->value.str.len = (int )tmp___0;
      tmp___1 = _estrndup(__s, (unsigned int )__z___1->value.str.len);
      __z___1->value.str.val = (char *)tmp___1;
      __z___1->type = (zend_uchar )6;
      break;
    }
    return;
  }
}
}
void zif_strcoll(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) 
{ 
  char *s1 ;
  char *s2 ;
  int s1len ;
  int s2len ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  int tmp___0 ;

  {
  tmp = zend_parse_parameters(ht, "ss", & s1, & s1len, & s2, & s2len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  __z = return_value;
  tmp___0 = strcoll((char const   *)s1, (char const   *)s2);
  __z->value.lval = (long )tmp___0;
  __z->type = (zend_uchar )1;
  return;
}
}
__inline static int php_charmask(unsigned char *input , int len , char *mask ) 
{ 
  unsigned char *end ;
  unsigned char c ;
  int result ;

  {
  result = 0;
  memset((void *)mask, 0, (size_t )256);
  end = input + len;
  while ((unsigned long )input < (unsigned long )end) {
    c = *input;
    if ((unsigned long )(input + 3) < (unsigned long )end) {
      if ((int )*(input + 1) == 46) {
        if ((int )*(input + 2) == 46) {
          if ((int )*(input + 3) >= (int )c) {
            memset((void *)(mask + (int )c), 1,
                   (size_t )(((int )*(input + 3) - (int )c) + 1));
            input += 3;
          } else {
            goto _L___1;
          }
        } else {
          goto _L___1;
        }
      } else {
        goto _L___1;
      }
    } else
    _L___1: 
    if ((unsigned long )(input + 1) < (unsigned long )end) {
      if ((int )*(input + 0) == 46) {
        if ((int )*(input + 1) == 46) {
          if ((unsigned long )(end - len) >= (unsigned long )input) {
            php_error_docref0((char const   *)((void *)0), 1 << 1L,
                              "Invalid \'..\'-range, no character to the left of \'..\'");
            result = -1;
            goto __Cont;
          } else {

          }
          if ((unsigned long )(input + 2) >= (unsigned long )end) {
            php_error_docref0((char const   *)((void *)0), 1 << 1L,
                              "Invalid \'..\'-range, no character to the right of \'..\'");
            result = -1;
            goto __Cont;
          } else {

          }
          if ((int )*(input + -1) > (int )*(input + 2)) {
            php_error_docref0((char const   *)((void *)0), 1 << 1L,
                              "Invalid \'..\'-range, \'..\'-range needs to be incrementing");
            result = -1;
            goto __Cont;
          } else {

          }
          php_error_docref0((char const   *)((void *)0), 1 << 1L,
                            "Invalid \'..\'-range");
          result = -1;
          goto __Cont;
        } else {
          *(mask + (int )c) = (char)1;
        }
      } else {
        *(mask + (int )c) = (char)1;
      }
    } else {
      *(mask + (int )c) = (char)1;
    }
    __Cont: 
    input ++;
  }
  return (result);
}
}
char __attribute__((__visibility__("default")))  *php_trim(char *c , int len ,
                                                           char *what ,
                                                           int what_len ,
                                                           zval *return_value ,
                                                           int mode ) 
{ 
  register int i ;
  int trimmed ;
  char mask[256] ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;

  {
  trimmed = 0;
  if (what) {
    php_charmask((unsigned char *)what, what_len, mask);
  } else {
    php_charmask((unsigned char *)" \n\r\t\v\000", 6, mask);
  }
  if (mode & 1) {
    i = 0;
    while (i < len) {
      if (mask[(unsigned char )*(c + i)]) {
        trimmed ++;
      } else {
        break;
      }
      i ++;
    }
    len -= trimmed;
    c += trimmed;
  } else {

  }
  if (mode & 2) {
    i = len - 1;
    while (i >= 0) {
      if (mask[(unsigned char )*(c + i)]) {
        len --;
      } else {
        break;
      }
      i --;
    }
  } else {

  }
  if (return_value) {
    while (1) {
      __s = (char const   *)c;
      __l = len;
      __z = return_value;
      __z->value.str.len = __l;
      tmp = _estrndup(__s, (unsigned int )__l);
      __z->value.str.val = (char *)tmp;
      __z->type = (zend_uchar )6;
      break;
    }
  } else {
    tmp___0 = _estrndup((char const   *)c, (unsigned int )len);
    return (tmp___0);
  }
  return ((char __attribute__((__visibility__("default")))  *)"");
}
}
static void php_do_trim(int ht , zval *return_value , zval **return_value_ptr ,
                        zval *this_ptr , int return_value_used , int mode ) 
{ 
  char *str ;
  char *what ;
  int str_len ;
  int what_len ;
  int __attribute__((__visibility__("default")))  tmp ;

  {
  what = (char *)((void *)0);
  what_len = 0;
  tmp = zend_parse_parameters(ht, "s|s", & str, & str_len, & what, & what_len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  php_trim(str, str_len, what, what_len, return_value, mode);
  return;
}
}
void zif_trim(int ht , zval *return_value , zval **return_value_ptr ,
              zval *this_ptr , int return_value_used ) 
{ 


  {
  php_do_trim(ht, return_value, return_value_ptr, this_ptr, return_value_used, 3);
  return;
}
}
void zif_rtrim(int ht , zval *return_value , zval **return_value_ptr ,
               zval *this_ptr , int return_value_used ) 
{ 


  {
  php_do_trim(ht, return_value, return_value_ptr, this_ptr, return_value_used, 2);
  return;
}
}
void zif_ltrim(int ht , zval *return_value , zval **return_value_ptr ,
               zval *this_ptr , int return_value_used ) 
{ 


  {
  php_do_trim(ht, return_value, return_value_ptr, this_ptr, return_value_used, 1);
  return;
}
}
void zif_wordwrap(int ht , zval *return_value , zval **return_value_ptr ,
                  zval *this_ptr , int return_value_used ) 
{ 
  char const   *text ;
  char const   *breakchar ;
  char *newtext ;
  int textlen ;
  int breakcharlen ;
  int newtextlen ;
  int chk ;
  size_t alloced ;
  long current ;
  long laststart ;
  long lastspace ;
  long linelength ;
  zend_bool docut ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  zval *__z___0 ;
  zval *__z___1 ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  char const   *__s ;
  int __l ;
  zval *__z___2 ;
  void __attribute__((__visibility__("default")))  *tmp___3 ;
  void __attribute__((__visibility__("default")))  *tmp___4 ;
  void __attribute__((__visibility__("default")))  *tmp___5 ;
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp___9 ;
  int tmp___12 ;
  int tmp___13 ;
  int tmp___14 ;
  int tmp___15 ;
  int tmp___16 ;
  void __attribute__((__visibility__("default")))  *tmp___19 ;
  char const   *__s___0 ;
  int __l___0 ;
  zval *__z___3 ;

  {
  breakchar = "\n";
  breakcharlen = 1;
  current = 0L;
  laststart = 0L;
  lastspace = 0L;
  linelength = 75L;
  docut = (zend_bool )0;
  tmp = zend_parse_parameters(ht, "s|lsb", & text, & textlen, & linelength,
                              & breakchar, & breakcharlen, & docut);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (textlen == 0) {
    while (1) {
      __z = return_value;
      __z->value.str.len = 0;
      tmp___0 = _estrndup("", (unsigned int )(sizeof("") - 1UL));
      __z->value.str.val = (char *)tmp___0;
      __z->type = (zend_uchar )6;
      break;
    }
    return;
  } else {

  }
  if (breakcharlen == 0) {
    php_error_docref0((char const   *)((void *)0), 1 << 1L,
                      "Break string cannot be empty");
    while (1) {
      __z___0 = return_value;
      __z___0->value.lval = 0L;
      __z___0->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  if (linelength == 0L) {
    if (docut) {
      php_error_docref0((char const   *)((void *)0), 1 << 1L,
                        "Can\'t force cut when width is zero");
      while (1) {
        __z___1 = return_value;
        __z___1->value.lval = 0L;
        __z___1->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
  } else {

  }
  if (breakcharlen == 1) {
    if (! docut) {
      tmp___1 = _estrndup(text, (unsigned int )textlen);
      newtext = (char *)tmp___1;
      lastspace = 0L;
      laststart = lastspace;
      current = 0L;
      while (current < (long )textlen) {
        if ((int const   )*(text + current) == (int const   )*(breakchar + 0)) {
          lastspace = current + 1L;
          laststart = lastspace;
        } else
        if ((int const   )*(text + current) == 32) {
          if (current - laststart >= linelength) {
            *(newtext + current) = (char )*(breakchar + 0);
            laststart = current + 1L;
          } else {

          }
          lastspace = current;
        } else
        if (current - laststart >= linelength) {
          if (laststart != lastspace) {
            *(newtext + lastspace) = (char )*(breakchar + 0);
            laststart = lastspace + 1L;
          } else {

          }
        } else {

        }
        current ++;
      }
      while (1) {
        __s = (char const   *)newtext;
        __l = textlen;
        __z___2 = return_value;
        __z___2->value.str.len = __l;
        __z___2->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
        __z___2->type = (zend_uchar )6;
        break;
      }
      return;
    } else {
      goto _L___5;
    }
  } else {
    _L___5: 
    if (linelength > 0L) {
      chk = (int )((long )textlen / linelength + 1L);
      tmp___3 = _safe_emalloc((size_t )chk, (size_t )breakcharlen,
                              (size_t )(textlen + 1));
      newtext = (char *)tmp___3;
      alloced = (size_t )((textlen + chk * breakcharlen) + 1);
    } else {
      chk = textlen;
      alloced = (size_t )(textlen * (breakcharlen + 1) + 1);
      tmp___4 = _safe_emalloc((size_t )textlen, (size_t )(breakcharlen + 1),
                              (size_t )1);
      newtext = (char *)tmp___4;
    }
    newtextlen = 0;
    lastspace = 0L;
    laststart = lastspace;
    current = 0L;
    while (current < (long )textlen) {
      if (chk <= 0) {
        alloced += (size_t )((int )(((((long )textlen - current) + 1L) / linelength + 1L) * (long )breakcharlen) + 1);
        tmp___5 = _erealloc((void *)newtext, alloced, 0);
        newtext = (char *)tmp___5;
        chk = (int )(((long )textlen - current) / linelength) + 1;
      } else {

      }
      if ((int const   )*(text + current) == (int const   )*(breakchar + 0)) {
        if (current + (long )breakcharlen < (long )textlen) {
          if (0) {
            if (0) {
              __s1_len = __builtin_strlen(text + current);
              __s2_len = __builtin_strlen(breakchar);
              if (! ((size_t )((void const   *)((text + current) + 1)) - (size_t )((void const   *)(text + current)) == 1UL)) {
                goto _L___2;
              } else
              if (__s1_len >= 4UL) {
                _L___2: 
                if (! ((size_t )((void const   *)(breakchar + 1)) - (size_t )((void const   *)breakchar) == 1UL)) {
                  tmp___14 = 1;
                } else
                if (__s2_len >= 4UL) {
                  tmp___14 = 1;
                } else {
                  tmp___14 = 0;
                }
              } else {
                tmp___14 = 0;
              }
              if (tmp___14) {
                tmp___9 = __builtin_strcmp(text + current, breakchar);
                tmp___13 = tmp___9;
              } else {
                tmp___12 = __builtin_strcmp(text + current, breakchar);
                tmp___13 = tmp___12;
              }
            } else {
              tmp___12 = __builtin_strcmp(text + current, breakchar);
              tmp___13 = tmp___12;
            }
            tmp___16 = tmp___13;
          } else {
            tmp___15 = strncmp(text + current, breakchar, (size_t )breakcharlen);
            tmp___16 = tmp___15;
          }
          if (tmp___16) {
            goto _L___4;
          } else {
            memcpy((void */* __restrict  */)(newtext + newtextlen),
                   (void const   */* __restrict  */)(text + laststart),
                   (size_t )((current - laststart) + (long )breakcharlen));
            newtextlen = (int )((long )newtextlen + ((current - laststart) + (long )breakcharlen));
            current += (long )(breakcharlen - 1);
            lastspace = current + 1L;
            laststart = lastspace;
            chk --;
          }
        } else {
          goto _L___4;
        }
      } else
      _L___4: 
      if ((int const   )*(text + current) == 32) {
        if (current - laststart >= linelength) {
          memcpy((void */* __restrict  */)(newtext + newtextlen),
                 (void const   */* __restrict  */)(text + laststart),
                 (size_t )(current - laststart));
          newtextlen = (int )((long )newtextlen + (current - laststart));
          memcpy((void */* __restrict  */)(newtext + newtextlen),
                 (void const   */* __restrict  */)breakchar,
                 (size_t )breakcharlen);
          newtextlen += breakcharlen;
          laststart = current + 1L;
          chk --;
        } else {

        }
        lastspace = current;
      } else
      if (current - laststart >= linelength) {
        if (docut) {
          if (laststart >= lastspace) {
            memcpy((void */* __restrict  */)(newtext + newtextlen),
                   (void const   */* __restrict  */)(text + laststart),
                   (size_t )(current - laststart));
            newtextlen = (int )((long )newtextlen + (current - laststart));
            memcpy((void */* __restrict  */)(newtext + newtextlen),
                   (void const   */* __restrict  */)breakchar,
                   (size_t )breakcharlen);
            newtextlen += breakcharlen;
            lastspace = current;
            laststart = lastspace;
            chk --;
          } else {
            goto _L___0;
          }
        } else {
          goto _L___0;
        }
      } else
      _L___0: 
      if (current - laststart >= linelength) {
        if (laststart < lastspace) {
          memcpy((void */* __restrict  */)(newtext + newtextlen),
                 (void const   */* __restrict  */)(text + laststart),
                 (size_t )(lastspace - laststart));
          newtextlen = (int )((long )newtextlen + (lastspace - laststart));
          memcpy((void */* __restrict  */)(newtext + newtextlen),
                 (void const   */* __restrict  */)breakchar,
                 (size_t )breakcharlen);
          newtextlen += breakcharlen;
          lastspace ++;
          laststart = lastspace;
          chk --;
        } else {

        }
      } else {

      }
      current ++;
    }
    if (laststart != current) {
      memcpy((void */* __restrict  */)(newtext + newtextlen),
             (void const   */* __restrict  */)(text + laststart),
             (size_t )(current - laststart));
      newtextlen = (int )((long )newtextlen + (current - laststart));
    } else {

    }
    *(newtext + newtextlen) = (char )'\000';
    tmp___19 = _erealloc((void *)newtext, (size_t )(newtextlen + 1), 0);
    newtext = (char *)tmp___19;
    while (1) {
      __s___0 = (char const   *)newtext;
      __l___0 = newtextlen;
      __z___3 = return_value;
      __z___3->value.str.len = __l___0;
      __z___3->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s___0));
      __z___3->type = (zend_uchar )6;
      break;
    }
    return;
  }
}
}
void __attribute__((__visibility__("default")))  php_explode(zval *delim ,
                                                             zval *str ,
                                                             zval *return_value ,
                                                             long limit ) 
{ 
  char *p1 ;
  char *p2 ;
  char *endp ;

  {
  endp = str->value.str.val + str->value.str.len;
  p1 = str->value.str.val;
  p2 = zend_memnstr(str->value.str.val, delim->value.str.val,
                    delim->value.str.len, endp);
  if ((unsigned long )p2 == (unsigned long )((void *)0)) {
    add_next_index_stringl(return_value, (char const   *)p1,
                           (uint )str->value.str.len, 1);
  } else {
    while (1) {
      add_next_index_stringl(return_value, (char const   *)p1, (uint )(p2 - p1),
                             1);
      p1 = p2 + delim->value.str.len;
      p2 = zend_memnstr(p1, delim->value.str.val, delim->value.str.len, endp);
      if ((unsigned long )p2 != (unsigned long )((void *)0)) {
        limit --;
        if (! (limit > 1L)) {
          break;
        } else {

        }
      } else {
        break;
      }
    }
    if ((unsigned long )p1 <= (unsigned long )endp) {
      add_next_index_stringl(return_value, (char const   *)p1,
                             (uint )(endp - p1), 1);
    } else {

    }
  }
  return;
}
}
void __attribute__((__visibility__("default")))  php_explode_negative_limit(zval *delim ,
                                                                            zval *str ,
                                                                            zval *return_value ,
                                                                            long limit ) 
{ 
  char *p1 ;
  char *p2 ;
  char *endp ;
  int allocated ;
  int found ;
  long i ;
  long to_return ;
  char **positions ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  int tmp___2 ;

  {
  endp = str->value.str.val + str->value.str.len;
  p1 = str->value.str.val;
  p2 = zend_memnstr(str->value.str.val, delim->value.str.val,
                    delim->value.str.len, endp);
  if (! ((unsigned long )p2 == (unsigned long )((void *)0))) {
    allocated = 64;
    found = 0;
    tmp = _emalloc((unsigned long )allocated * sizeof(char *));
    positions = (char **)tmp;
    tmp___0 = found;
    found ++;
    *(positions + tmp___0) = p1;
    while (1) {
      if (found >= allocated) {
        allocated = found + 64;
        tmp___1 = _erealloc((void *)positions,
                            (unsigned long )allocated * sizeof(char *), 0);
        positions = (char **)tmp___1;
      } else {

      }
      tmp___2 = found;
      found ++;
      p1 = p2 + delim->value.str.len;
      *(positions + tmp___2) = p1;
      p2 = zend_memnstr(p1, delim->value.str.val, delim->value.str.len, endp);
      if (! ((unsigned long )p2 != (unsigned long )((void *)0))) {
        break;
      } else {

      }
    }
    to_return = limit + (long )found;
    i = 0L;
    while (i < to_return) {
      add_next_index_stringl(return_value, (char const   *)*(positions + i),
                             (uint )((*(positions + (i + 1L)) - delim->value.str.len) - *(positions + i)),
                             1);
      i ++;
    }
    _efree((void *)positions);
  } else {

  }
  return;
}
}
void zif_explode(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) 
{ 
  char *str ;
  char *delim ;
  int str_len ;
  int delim_len ;
  long limit ;
  zval zdelim ;
  zval zstr ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  char const   *__s ;
  int __l ;
  zval *__z___0 ;
  char const   *__s___0 ;
  int __l___0 ;
  zval *__z___1 ;

  {
  str_len = 0;
  delim_len = 0;
  limit = 9223372036854775807L;
  tmp = zend_parse_parameters(ht, "ss|l", & delim, & delim_len, & str,
                              & str_len, & limit);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (delim_len == 0) {
    php_error_docref0((char const   *)((void *)0), 1 << 1L, "Empty delimiter");
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  _array_init(return_value, (uint )0);
  if (str_len == 0) {
    if (limit >= 0L) {
      add_next_index_stringl(return_value, "", (uint )(sizeof("") - 1UL), 1);
    } else {

    }
    return;
  } else {

  }
  while (1) {
    __s = (char const   *)str;
    __l = str_len;
    __z___0 = & zstr;
    __z___0->value.str.len = __l;
    __z___0->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z___0->type = (zend_uchar )6;
    break;
  }
  while (1) {
    __s___0 = (char const   *)delim;
    __l___0 = delim_len;
    __z___1 = & zdelim;
    __z___1->value.str.len = __l___0;
    __z___1->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s___0));
    __z___1->type = (zend_uchar )6;
    break;
  }
  if (limit > 1L) {
    php_explode(& zdelim, & zstr, return_value, limit);
  } else
  if (limit < 0L) {
    php_explode_negative_limit(& zdelim, & zstr, return_value, limit);
  } else {
    add_index_stringl(return_value, (ulong )0, (char const   *)str,
                      (uint )str_len, 1);
  }
  return;
}
}
void __attribute__((__visibility__("default")))  php_implode(zval *delim ,
                                                             zval *arr ,
                                                             zval *return_value ) 
{ 
  zval **tmp ;
  HashPosition pos ;
  smart_str implstr ;
  int numelems ;
  int i ;
  zval tmp_val ;
  int str_len ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  register size_t __nl ;
  smart_str *__dest ;
  void __attribute__((__visibility__("default")))  *tmp___3 ;
  void __attribute__((__visibility__("default")))  *tmp___5 ;
  char stmp[21] ;
  int __attribute__((__visibility__("default")))  tmp___6 ;
  register size_t __nl___0 ;
  smart_str *__dest___0 ;
  void __attribute__((__visibility__("default")))  *tmp___8 ;
  void __attribute__((__visibility__("default")))  *tmp___10 ;
  register size_t __nl___1 ;
  smart_str *__dest___1 ;
  void __attribute__((__visibility__("default")))  *tmp___12 ;
  void __attribute__((__visibility__("default")))  *tmp___14 ;
  char *stmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___15 ;
  register size_t __nl___2 ;
  smart_str *__dest___2 ;
  void __attribute__((__visibility__("default")))  *tmp___17 ;
  void __attribute__((__visibility__("default")))  *tmp___19 ;
  int copy ;
  zval expr ;
  register size_t __nl___3 ;
  smart_str *__dest___3 ;
  void __attribute__((__visibility__("default")))  *tmp___21 ;
  void __attribute__((__visibility__("default")))  *tmp___23 ;
  register size_t __nl___4 ;
  smart_str *__dest___4 ;
  void __attribute__((__visibility__("default")))  *tmp___25 ;
  void __attribute__((__visibility__("default")))  *tmp___27 ;
  register size_t __nl___5 ;
  smart_str *__dest___5 ;
  void __attribute__((__visibility__("default")))  *tmp___29 ;
  void __attribute__((__visibility__("default")))  *tmp___31 ;
  int __attribute__((__visibility__("default")))  tmp___32 ;
  char const   *__s ;
  int __l ;
  zval *__z___0 ;
  smart_str *__s___0 ;
  size_t tmp___34 ;
  zval *__z___1 ;
  char __attribute__((__visibility__("default")))  *tmp___35 ;

  {
  implstr.c = (char *)0;
  implstr.len = 0UL;
  implstr.a = 0UL;
  i = 0;
  tmp___0 = zend_hash_num_elements((HashTable const   *)arr->value.ht);
  numelems = (int )tmp___0;
  if (numelems == 0) {
    while (1) {
      __z = return_value;
      __z->value.str.len = 0;
      tmp___1 = _estrndup("", (unsigned int )(sizeof("") - 1UL));
      __z->value.str.val = (char *)tmp___1;
      __z->type = (zend_uchar )6;
      break;
    }
    return;
  } else {

  }
  zend_hash_internal_pointer_reset_ex(arr->value.ht, & pos);
  while (1) {
    tmp___32 = zend_hash_get_current_data_ex(arr->value.ht, (void **)(& tmp),
                                             & pos);
    if (! (tmp___32 == (int __attribute__((__visibility__("default")))  )0)) {
      break;
    } else {

    }
    switch ((int )(*tmp)->type) {
    case 6: 
    while (1) {
      __dest = & implstr;
      while (1) {
        if (! __dest->c) {
          __dest->len = (size_t )0;
          __nl = (size_t )(*tmp)->value.str.len;
          if (__nl < 78UL) {
            __dest->a = (size_t )78;
          } else {
            __dest->a = __nl + 128UL;
          }
          tmp___3 = _erealloc((void *)__dest->c, __dest->a + 1UL, 0);
          __dest->c = (char *)((void *)tmp___3);
        } else {
          __nl = __dest->len + (size_t )(*tmp)->value.str.len;
          if (__nl >= __dest->a) {
            __dest->a = __nl + 128UL;
            tmp___5 = _erealloc((void *)__dest->c, __dest->a + 1UL, 0);
            __dest->c = (char *)((void *)tmp___5);
          } else {

          }
        }
        break;
      }
      memcpy((void */* __restrict  */)(__dest->c + __dest->len),
             (void const   */* __restrict  */)(*tmp)->value.str.val,
             (size_t )(*tmp)->value.str.len);
      __dest->len = __nl;
      break;
    }
    break;
    case 1: 
    tmp___6 = ap_php_slprintf(stmp, sizeof(stmp), "%ld", (*tmp)->value.lval);
    str_len = (int )tmp___6;
    while (1) {
      __dest___0 = & implstr;
      while (1) {
        if (! __dest___0->c) {
          __dest___0->len = (size_t )0;
          __nl___0 = (size_t )str_len;
          if (__nl___0 < 78UL) {
            __dest___0->a = (size_t )78;
          } else {
            __dest___0->a = __nl___0 + 128UL;
          }
          tmp___8 = _erealloc((void *)__dest___0->c, __dest___0->a + 1UL, 0);
          __dest___0->c = (char *)((void *)tmp___8);
        } else {
          __nl___0 = __dest___0->len + (size_t )str_len;
          if (__nl___0 >= __dest___0->a) {
            __dest___0->a = __nl___0 + 128UL;
            tmp___10 = _erealloc((void *)__dest___0->c, __dest___0->a + 1UL, 0);
            __dest___0->c = (char *)((void *)tmp___10);
          } else {

          }
        }
        break;
      }
      memcpy((void */* __restrict  */)(__dest___0->c + __dest___0->len),
             (void const   */* __restrict  */)(stmp), (size_t )str_len);
      __dest___0->len = __nl___0;
      break;
    }
    break;
    case 3: 
    if ((*tmp)->value.lval == 1L) {
      while (1) {
        __dest___1 = & implstr;
        while (1) {
          if (! __dest___1->c) {
            __dest___1->len = (size_t )0;
            __nl___1 = sizeof("1") - 1UL;
            if (__nl___1 < 78UL) {
              __dest___1->a = (size_t )78;
            } else {
              __dest___1->a = __nl___1 + 128UL;
            }
            tmp___12 = _erealloc((void *)__dest___1->c, __dest___1->a + 1UL, 0);
            __dest___1->c = (char *)((void *)tmp___12);
          } else {
            __nl___1 = __dest___1->len + (sizeof("1") - 1UL);
            if (__nl___1 >= __dest___1->a) {
              __dest___1->a = __nl___1 + 128UL;
              tmp___14 = _erealloc((void *)__dest___1->c, __dest___1->a + 1UL, 0);
              __dest___1->c = (char *)((void *)tmp___14);
            } else {

            }
          }
          break;
        }
        memcpy((void */* __restrict  */)(__dest___1->c + __dest___1->len),
               (void const   */* __restrict  */)"1", sizeof("1") - 1UL);
        __dest___1->len = __nl___1;
        break;
      }
    } else {

    }
    break;
    case 0: 
    break;
    case 2: 
    tmp___15 = spprintf(& stmp___0, (size_t )0, "%.*G",
                        (int )executor_globals.precision, (*tmp)->value.dval);
    str_len = (int )tmp___15;
    while (1) {
      __dest___2 = & implstr;
      while (1) {
        if (! __dest___2->c) {
          __dest___2->len = (size_t )0;
          __nl___2 = (size_t )str_len;
          if (__nl___2 < 78UL) {
            __dest___2->a = (size_t )78;
          } else {
            __dest___2->a = __nl___2 + 128UL;
          }
          tmp___17 = _erealloc((void *)__dest___2->c, __dest___2->a + 1UL, 0);
          __dest___2->c = (char *)((void *)tmp___17);
        } else {
          __nl___2 = __dest___2->len + (size_t )str_len;
          if (__nl___2 >= __dest___2->a) {
            __dest___2->a = __nl___2 + 128UL;
            tmp___19 = _erealloc((void *)__dest___2->c, __dest___2->a + 1UL, 0);
            __dest___2->c = (char *)((void *)tmp___19);
          } else {

          }
        }
        break;
      }
      memcpy((void */* __restrict  */)(__dest___2->c + __dest___2->len),
             (void const   */* __restrict  */)stmp___0, (size_t )str_len);
      __dest___2->len = __nl___2;
      break;
    }
    _efree((void *)stmp___0);
    break;
    case 5: 
    zend_make_printable_zval(*tmp, & expr, & copy);
    while (1) {
      __dest___3 = & implstr;
      while (1) {
        if (! __dest___3->c) {
          __dest___3->len = (size_t )0;
          __nl___3 = (size_t )expr.value.str.len;
          if (__nl___3 < 78UL) {
            __dest___3->a = (size_t )78;
          } else {
            __dest___3->a = __nl___3 + 128UL;
          }
          tmp___21 = _erealloc((void *)__dest___3->c, __dest___3->a + 1UL, 0);
          __dest___3->c = (char *)((void *)tmp___21);
        } else {
          __nl___3 = __dest___3->len + (size_t )expr.value.str.len;
          if (__nl___3 >= __dest___3->a) {
            __dest___3->a = __nl___3 + 128UL;
            tmp___23 = _erealloc((void *)__dest___3->c, __dest___3->a + 1UL, 0);
            __dest___3->c = (char *)((void *)tmp___23);
          } else {

          }
        }
        break;
      }
      memcpy((void */* __restrict  */)(__dest___3->c + __dest___3->len),
             (void const   */* __restrict  */)expr.value.str.val,
             (size_t )expr.value.str.len);
      __dest___3->len = __nl___3;
      break;
    }
    if (copy) {
      _zval_dtor(& expr);
    } else {

    }
    break;
    default: 
    tmp_val = *(*tmp);
    _zval_copy_ctor(& tmp_val);
    if ((int )tmp_val.type != 6) {
      _convert_to_string(& tmp_val);
    } else {

    }
    while (1) {
      __dest___4 = & implstr;
      while (1) {
        if (! __dest___4->c) {
          __dest___4->len = (size_t )0;
          __nl___4 = (size_t )tmp_val.value.str.len;
          if (__nl___4 < 78UL) {
            __dest___4->a = (size_t )78;
          } else {
            __dest___4->a = __nl___4 + 128UL;
          }
          tmp___25 = _erealloc((void *)__dest___4->c, __dest___4->a + 1UL, 0);
          __dest___4->c = (char *)((void *)tmp___25);
        } else {
          __nl___4 = __dest___4->len + (size_t )tmp_val.value.str.len;
          if (__nl___4 >= __dest___4->a) {
            __dest___4->a = __nl___4 + 128UL;
            tmp___27 = _erealloc((void *)__dest___4->c, __dest___4->a + 1UL, 0);
            __dest___4->c = (char *)((void *)tmp___27);
          } else {

          }
        }
        break;
      }
      memcpy((void */* __restrict  */)(__dest___4->c + __dest___4->len),
             (void const   */* __restrict  */)tmp_val.value.str.val,
             (size_t )tmp_val.value.str.len);
      __dest___4->len = __nl___4;
      break;
    }
    _zval_dtor(& tmp_val);
    break;
    }
    i ++;
    if (i != numelems) {
      while (1) {
        __dest___5 = & implstr;
        while (1) {
          if (! __dest___5->c) {
            __dest___5->len = (size_t )0;
            __nl___5 = (size_t )delim->value.str.len;
            if (__nl___5 < 78UL) {
              __dest___5->a = (size_t )78;
            } else {
              __dest___5->a = __nl___5 + 128UL;
            }
            tmp___29 = _erealloc((void *)__dest___5->c, __dest___5->a + 1UL, 0);
            __dest___5->c = (char *)((void *)tmp___29);
          } else {
            __nl___5 = __dest___5->len + (size_t )delim->value.str.len;
            if (__nl___5 >= __dest___5->a) {
              __dest___5->a = __nl___5 + 128UL;
              tmp___31 = _erealloc((void *)__dest___5->c, __dest___5->a + 1UL, 0);
              __dest___5->c = (char *)((void *)tmp___31);
            } else {

            }
          }
          break;
        }
        memcpy((void */* __restrict  */)(__dest___5->c + __dest___5->len),
               (void const   */* __restrict  */)delim->value.str.val,
               (size_t )delim->value.str.len);
        __dest___5->len = __nl___5;
        break;
      }
    } else {

    }
    zend_hash_move_forward_ex(arr->value.ht, & pos);
  }
  while (1) {
    if (implstr.c) {
      *(implstr.c + implstr.len) = (char )'\000';
    } else {

    }
    break;
  }
  if (implstr.len) {
    while (1) {
      __s = (char const   *)implstr.c;
      __l = (int )implstr.len;
      __z___0 = return_value;
      __z___0->value.str.len = __l;
      __z___0->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
      __z___0->type = (zend_uchar )6;
      break;
    }
    return;
  } else {
    while (1) {
      __s___0 = & implstr;
      if (__s___0->c) {
        _efree((void *)__s___0->c);
        __s___0->c = (char *)((void *)0);
      } else {

      }
      tmp___34 = (size_t )0;
      __s___0->len = tmp___34;
      __s___0->a = tmp___34;
      break;
    }
    while (1) {
      __z___1 = return_value;
      __z___1->value.str.len = 0;
      tmp___35 = _estrndup("", (unsigned int )(sizeof("") - 1UL));
      __z___1->value.str.val = (char *)tmp___35;
      __z___1->type = (zend_uchar )6;
      break;
    }
    return;
  }
}
}
void zif_implode(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) 
{ 
  zval **arg1 ;
  zval **arg2 ;
  zval *delim ;
  zval *arr ;
  int __attribute__((__visibility__("default")))  tmp ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  zval *new_zv ;
  void __attribute__((__visibility__("default")))  *tmp___2 ;
  zend_uint tmp___3 ;
  zval *new_zv___0 ;
  void __attribute__((__visibility__("default")))  *tmp___4 ;
  zend_uint tmp___5 ;
  zend_bool tmp___6 ;
  zval *new_zv___1 ;
  void __attribute__((__visibility__("default")))  *tmp___7 ;
  zend_uint tmp___8 ;
  zend_bool tmp___9 ;

  {
  arg1 = (zval **)((void *)0);
  arg2 = (zval **)((void *)0);
  tmp = zend_parse_parameters(ht, "Z|Z", & arg1, & arg2);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if ((unsigned long )arg2 == (unsigned long )((void *)0)) {
    if ((int )(*arg1)->type != 4) {
      php_error_docref0((char const   *)((void *)0), 1 << 1L,
                        "Argument must be an array");
      return;
    } else {

    }
    while (1) {
      tmp___0 = _emalloc(sizeof(zval_gc_info ));
      delim = (zval *)tmp___0;
      ((zval_gc_info *)delim)->u.buffered = (gc_root_buffer *)((void *)0);
      break;
    }
    delim->refcount__gc = (zend_uint )1;
    delim->is_ref__gc = (zend_uchar )0;
    while (1) {
      __s = "";
      __l = (int )(sizeof("") - 1UL);
      __z = delim;
      __z->value.str.len = __l;
      __z->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
      __z->type = (zend_uchar )6;
      break;
    }
    while (1) {
      tmp___3 = zval_refcount_p(*arg1);
      if (tmp___3 > 1U) {
        zval_delref_p(*arg1);
        while (1) {
          tmp___2 = _emalloc(sizeof(zval_gc_info ));
          new_zv = (zval *)tmp___2;
          ((zval_gc_info *)new_zv)->u.buffered = (gc_root_buffer *)((void *)0);
          break;
        }
        while (1) {
          while (1) {
            new_zv->value = (*arg1)->value;
            new_zv->type = (*arg1)->type;
            break;
          }
          zval_set_refcount_p(new_zv, (zend_uint )1);
          zval_unset_isref_p(new_zv);
          break;
        }
        *arg1 = new_zv;
        _zval_copy_ctor(new_zv);
      } else {

      }
      break;
    }
    arr = *arg1;
  } else
  if ((int )(*arg1)->type == 4) {
    arr = *arg1;
    if ((int )(*arg2)->type != 6) {
      tmp___6 = zval_isref_p(*arg2);
      if (! tmp___6) {
        while (1) {
          tmp___5 = zval_refcount_p(*arg2);
          if (tmp___5 > 1U) {
            zval_delref_p(*arg2);
            while (1) {
              tmp___4 = _emalloc(sizeof(zval_gc_info ));
              new_zv___0 = (zval *)tmp___4;
              ((zval_gc_info *)new_zv___0)->u.buffered = (gc_root_buffer *)((void *)0);
              break;
            }
            while (1) {
              while (1) {
                new_zv___0->value = (*arg2)->value;
                new_zv___0->type = (*arg2)->type;
                break;
              }
              zval_set_refcount_p(new_zv___0, (zend_uint )1);
              zval_unset_isref_p(new_zv___0);
              break;
            }
            *arg2 = new_zv___0;
            _zval_copy_ctor(new_zv___0);
          } else {

          }
          break;
        }
      } else {

      }
      if ((int )(*arg2)->type != 6) {
        _convert_to_string(*arg2);
      } else {

      }
    } else {

    }
    delim = *arg2;
  } else
  if ((int )(*arg2)->type == 4) {
    arr = *arg2;
    if ((int )(*arg1)->type != 6) {
      tmp___9 = zval_isref_p(*arg1);
      if (! tmp___9) {
        while (1) {
          tmp___8 = zval_refcount_p(*arg1);
          if (tmp___8 > 1U) {
            zval_delref_p(*arg1);
            while (1) {
              tmp___7 = _emalloc(sizeof(zval_gc_info ));
              new_zv___1 = (zval *)tmp___7;
              ((zval_gc_info *)new_zv___1)->u.buffered = (gc_root_buffer *)((void *)0);
              break;
            }
            while (1) {
              while (1) {
                new_zv___1->value = (*arg1)->value;
                new_zv___1->type = (*arg1)->type;
                break;
              }
              zval_set_refcount_p(new_zv___1, (zend_uint )1);
              zval_unset_isref_p(new_zv___1);
              break;
            }
            *arg1 = new_zv___1;
            _zval_copy_ctor(new_zv___1);
          } else {

          }
          break;
        }
      } else {

      }
      if ((int )(*arg1)->type != 6) {
        _convert_to_string(*arg1);
      } else {

      }
    } else {

    }
    delim = *arg1;
  } else {
    php_error_docref0((char const   *)((void *)0), 1 << 1L,
                      "Invalid arguments passed");
    return;
  }
  php_implode(delim, arr, return_value);
  if ((unsigned long )arg2 == (unsigned long )((void *)0)) {
    while (1) {
      if ((gc_root_buffer *)((zend_uintptr_t )((zval_gc_info *)delim)->u.buffered & 0xfffffffffffffffcUL)) {
        gc_remove_zval_from_buffer(delim);
      } else {

      }
      _efree((void *)delim);
      break;
    }
  } else {

  }
  return;
}
}
void zif_strtok(int ht , zval *return_value , zval **return_value_ptr ,
                zval *this_ptr , int return_value_used ) 
{ 
  char *str ;
  char *tok ;
  int str_len ;
  int tok_len ;
  zval *zv ;
  char *token ;
  char *token_end ;
  char *p ;
  char *pe ;
  int skipped ;
  int __attribute__((__visibility__("default")))  tmp ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  zval *__z___0 ;
  char *tmp___2 ;
  zval *__z___1 ;
  char const   *__s___0 ;
  int __l___0 ;
  zval *__z___2 ;
  char __attribute__((__visibility__("default")))  *tmp___3 ;
  zval *__z___3 ;
  char *tmp___4 ;

  {
  tok = (char *)((void *)0);
  tok_len = 0;
  skipped = 0;
  tmp = zend_parse_parameters(ht, "s|s", & str, & str_len, & tok, & tok_len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (ht == 1) {
    tok = str;
    tok_len = str_len;
  } else {
    if (basic_globals.strtok_zval) {
      _zval_ptr_dtor(& basic_globals.strtok_zval);
    } else {

    }
    while (1) {
      tmp___0 = _emalloc(sizeof(zval_gc_info ));
      zv = (zval *)tmp___0;
      ((zval_gc_info *)zv)->u.buffered = (gc_root_buffer *)((void *)0);
      break;
    }
    zv->refcount__gc = (zend_uint )1;
    zv->is_ref__gc = (zend_uchar )0;
    while (1) {
      __s = (char const   *)str;
      __l = str_len;
      __z = zv;
      __z->value.str.len = __l;
      tmp___1 = _estrndup(__s, (unsigned int )__l);
      __z->value.str.val = (char *)tmp___1;
      __z->type = (zend_uchar )6;
      break;
    }
    basic_globals.strtok_zval = zv;
    basic_globals.strtok_string = zv->value.str.val;
    basic_globals.strtok_last = basic_globals.strtok_string;
    basic_globals.strtok_len = (ulong )str_len;
  }
  p = basic_globals.strtok_last;
  pe = basic_globals.strtok_string + basic_globals.strtok_len;
  if (! p) {
    goto _L;
  } else
  if ((unsigned long )p >= (unsigned long )pe) {
    _L: 
    while (1) {
      __z___0 = return_value;
      __z___0->value.lval = 0L;
      __z___0->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  token = tok;
  token_end = token + tok_len;
  while ((unsigned long )token < (unsigned long )token_end) {
    tmp___2 = token;
    token ++;
    basic_globals.strtok_table[(unsigned char )*tmp___2] = (char)1;
  }
  while (basic_globals.strtok_table[(unsigned char )*p]) {
    p ++;
    if ((unsigned long )p >= (unsigned long )pe) {
      basic_globals.strtok_last = (char *)((void *)0);
      while (1) {
        __z___1 = return_value;
        __z___1->value.lval = 0L;
        __z___1->type = (zend_uchar )3;
        break;
      }
      goto restore;
    } else {

    }
    skipped ++;
  }
  while (1) {
    p ++;
    if (! ((unsigned long )p < (unsigned long )pe)) {
      break;
    } else {

    }
    if (basic_globals.strtok_table[(unsigned char )*p]) {
      goto return_token;
    } else {

    }
  }
  if (p - basic_globals.strtok_last) {
    return_token: 
    while (1) {
      __s___0 = (char const   *)(basic_globals.strtok_last + skipped);
      __l___0 = (int )((p - basic_globals.strtok_last) - (long )skipped);
      __z___2 = return_value;
      __z___2->value.str.len = __l___0;
      tmp___3 = _estrndup(__s___0, (unsigned int )__l___0);
      __z___2->value.str.val = (char *)tmp___3;
      __z___2->type = (zend_uchar )6;
      break;
    }
    basic_globals.strtok_last = p + 1;
  } else {
    while (1) {
      __z___3 = return_value;
      __z___3->value.lval = 0L;
      __z___3->type = (zend_uchar )3;
      break;
    }
    basic_globals.strtok_last = (char *)((void *)0);
  }
  restore: 
  token = tok;
  while ((unsigned long )token < (unsigned long )token_end) {
    tmp___4 = token;
    token ++;
    basic_globals.strtok_table[(unsigned char )*tmp___4] = (char)0;
  }
  return;
}
}
char __attribute__((__visibility__("default")))  *php_strtoupper(char *s ,
                                                                 size_t len ) 
{ 
  unsigned char *c ;
  unsigned char *e ;
  int __res ;
  int __attribute__((__gnu_inline__))  tmp___0 ;
  __int32_t const   **tmp___1 ;

  {
  c = (unsigned char *)s;
  e = c + len;
  while ((unsigned long )c < (unsigned long )e) {
    if (sizeof(*c) > 1UL) {
      tmp___0 = toupper((int )*c);
      __res = (int )tmp___0;
    } else {
      tmp___1 = __ctype_toupper_loc();
      __res = (int )*(*tmp___1 + (int )*c);
    }
    *c = (unsigned char )__res;
    c ++;
  }
  return ((char __attribute__((__visibility__("default")))  *)s);
}
}
void zif_strtoupper(int ht , zval *return_value , zval **return_value_ptr ,
                    zval *this_ptr , int return_value_used ) 
{ 
  char *arg ;
  int arglen ;
  int __attribute__((__visibility__("default")))  tmp ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  char const   *__s ;
  int __l ;
  zval *__z ;

  {
  tmp = zend_parse_parameters(ht, "s", & arg, & arglen);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  tmp___0 = _estrndup((char const   *)arg, (unsigned int )arglen);
  arg = (char *)tmp___0;
  php_strtoupper(arg, (size_t )arglen);
  while (1) {
    __s = (char const   *)arg;
    __l = arglen;
    __z = return_value;
    __z->value.str.len = __l;
    __z->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z->type = (zend_uchar )6;
    break;
  }
  return;
}
}
char __attribute__((__visibility__("default")))  *php_strtolower(char *s ,
                                                                 size_t len ) 
{ 
  unsigned char *c ;
  unsigned char *e ;
  int __res ;
  int __attribute__((__gnu_inline__))  tmp___0 ;
  __int32_t const   **tmp___1 ;

  {
  c = (unsigned char *)s;
  e = c + len;
  while ((unsigned long )c < (unsigned long )e) {
    if (sizeof(*c) > 1UL) {
      tmp___0 = tolower((int )*c);
      __res = (int )tmp___0;
    } else {
      tmp___1 = __ctype_tolower_loc();
      __res = (int )*(*tmp___1 + (int )*c);
    }
    *c = (unsigned char )__res;
    c ++;
  }
  return ((char __attribute__((__visibility__("default")))  *)s);
}
}
void zif_strtolower(int ht , zval *return_value , zval **return_value_ptr ,
                    zval *this_ptr , int return_value_used ) 
{ 
  char *str ;
  int arglen ;
  int __attribute__((__visibility__("default")))  tmp ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  char const   *__s ;
  int __l ;
  zval *__z ;

  {
  tmp = zend_parse_parameters(ht, "s", & str, & arglen);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  tmp___0 = _estrndup((char const   *)str, (unsigned int )arglen);
  str = (char *)tmp___0;
  php_strtolower(str, (size_t )arglen);
  while (1) {
    __s = (char const   *)str;
    __l = arglen;
    __z = return_value;
    __z->value.str.len = __l;
    __z->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z->type = (zend_uchar )6;
    break;
  }
  return;
}
}
void __attribute__((__visibility__("default")))  php_basename(char *s ,
                                                              size_t len ,
                                                              char *suffix ,
                                                              size_t sufflen ,
                                                              char **p_ret ,
                                                              size_t *p_len ) 
{ 
  char *ret ;
  char *c ;
  char *comp ;
  char *cend ;
  size_t inc_len ;
  size_t cnt ;
  int state ;
  int tmp ;
  int tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;

  {
  ret = (char *)((void *)0);
  cend = s;
  comp = cend;
  c = comp;
  cnt = len;
  state = 0;
  while (cnt > 0UL) {
    if ((int )*c == 0) {
      inc_len = (size_t )1;
    } else {
      tmp = mblen((char const   *)c, cnt);
      inc_len = (size_t )tmp;
    }
    switch (inc_len) {
    case 0xfffffffffffffffeUL: 
    case 0xffffffffffffffffUL: 
    inc_len = (size_t )1;
    mblen((char const   *)((void *)0), (size_t )0);
    break;
    case 0UL: 
    goto quit_loop;
    case 1UL: 
    if ((int )*c == 47) {
      if (state == 1) {
        state = 0;
        cend = c;
      } else {

      }
    } else
    if (state == 0) {
      comp = c;
      state = 1;
    } else {

    }
    break;
    default: 
    if (state == 0) {
      comp = c;
      state = 1;
    } else {

    }
    break;
    }
    c += inc_len;
    cnt -= inc_len;
  }
  quit_loop: 
  if (state == 1) {
    cend = c;
  } else {

  }
  if ((unsigned long )suffix != (unsigned long )((void *)0)) {
    if (sufflen < (size_t )((uint )(cend - comp))) {
      tmp___0 = memcmp((void const   *)(cend - sufflen), (void const   *)suffix,
                       sufflen);
      if (tmp___0 == 0) {
        cend -= sufflen;
      } else {

      }
    } else {

    }
  } else {

  }
  len = (size_t )(cend - comp);
  if (p_ret) {
    tmp___1 = _emalloc(len + 1UL);
    ret = (char *)tmp___1;
    memcpy((void */* __restrict  */)ret, (void const   */* __restrict  */)comp,
           len);
    *(ret + len) = (char )'\000';
    *p_ret = ret;
  } else {

  }
  if (p_len) {
    *p_len = len;
  } else {

  }
  return;
}
}
void zif_basename(int ht , zval *return_value , zval **return_value_ptr ,
                  zval *this_ptr , int return_value_used ) 
{ 
  char *string ;
  char *suffix ;
  char *ret ;
  int string_len ;
  int suffix_len ;
  size_t ret_len ;
  int __attribute__((__visibility__("default")))  tmp ;
  char const   *__s ;
  int __l ;
  zval *__z ;

  {
  suffix = (char *)((void *)0);
  suffix_len = 0;
  tmp = zend_parse_parameters(ht, "s|s", & string, & string_len, & suffix,
                              & suffix_len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  php_basename(string, (size_t )string_len, suffix, (size_t )suffix_len, & ret,
               & ret_len);
  while (1) {
    __s = (char const   *)ret;
    __l = (int )ret_len;
    __z = return_value;
    __z->value.str.len = __l;
    __z->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z->type = (zend_uchar )6;
    break;
  }
  return;
}
}
size_t __attribute__((__visibility__("default")))  php_dirname(char *path ,
                                                               size_t len ) 
{ 
  size_t __attribute__((__visibility__("default")))  tmp ;

  {
  tmp = zend_dirname(path, len);
  return (tmp);
}
}
void zif_dirname(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) 
{ 
  char *str ;
  char *ret ;
  int str_len ;
  size_t ret_len ;
  int __attribute__((__visibility__("default")))  tmp ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  size_t __attribute__((__visibility__("default")))  tmp___1 ;
  char const   *__s ;
  int __l ;
  zval *__z ;

  {
  tmp = zend_parse_parameters(ht, "s", & str, & str_len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  tmp___0 = _estrndup((char const   *)str, (unsigned int )str_len);
  ret = (char *)tmp___0;
  tmp___1 = php_dirname(ret, (size_t )str_len);
  ret_len = (size_t )tmp___1;
  while (1) {
    __s = (char const   *)ret;
    __l = (int )ret_len;
    __z = return_value;
    __z->value.str.len = __l;
    __z->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z->type = (zend_uchar )6;
    break;
  }
  return;
}
}
void zif_pathinfo(int ht , zval *return_value , zval **return_value_ptr ,
                  zval *this_ptr , int return_value_used ) 
{ 
  zval *tmp ;
  char *path ;
  char *ret ;
  int path_len ;
  int have_basename ;
  size_t ret_len ;
  long opt ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;
  size_t tmp___3 ;
  size_t tmp___4 ;
  char const   *p ;
  int idx ;
  void const   *tmp___5 ;
  size_t tmp___6 ;
  char const   *p___0 ;
  int idx___0 ;
  void const   *tmp___7 ;
  size_t tmp___8 ;
  zend_uchar is_ref ;
  zend_bool tmp___9 ;
  zend_uint refcount ;
  zend_uint tmp___10 ;
  zval **element ;
  zend_uchar is_ref___0 ;
  zend_bool tmp___11 ;
  zend_uint refcount___0 ;
  zend_uint tmp___12 ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___13 ;
  int __attribute__((__visibility__("default")))  tmp___14 ;

  {
  ret = (char *)((void *)0);
  opt = 15L;
  tmp___0 = zend_parse_parameters(ht, "s|l", & path, & path_len, & opt);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  have_basename = (opt & 2L) == 2L;
  while (1) {
    tmp___1 = _emalloc(sizeof(zval_gc_info ));
    tmp = (zval *)tmp___1;
    ((zval_gc_info *)tmp)->u.buffered = (gc_root_buffer *)((void *)0);
    break;
  }
  tmp->refcount__gc = (zend_uint )1;
  tmp->is_ref__gc = (zend_uchar )0;
  _array_init(tmp, (uint )0);
  if ((opt & 1L) == 1L) {
    tmp___2 = _estrndup((char const   *)path, (unsigned int )path_len);
    ret = (char *)tmp___2;
    php_dirname(ret, (size_t )path_len);
    if (*ret) {
      tmp___3 = strlen("dirname");
      add_assoc_string_ex(tmp, "dirname", (uint )(tmp___3 + 1UL), ret, 1);
    } else {

    }
    _efree((void *)ret);
    ret = (char *)((void *)0);
  } else {

  }
  if (have_basename) {
    php_basename(path, (size_t )path_len, (char *)((void *)0), (size_t )0,
                 & ret, & ret_len);
    tmp___4 = strlen("basename");
    add_assoc_stringl_ex(tmp, "basename", (uint )(tmp___4 + 1UL), ret,
                         (uint )ret_len, 0);
  } else {

  }
  if ((opt & 4L) == 4L) {
    if (! have_basename) {
      php_basename(path, (size_t )path_len, (char *)((void *)0), (size_t )0,
                   & ret, & ret_len);
    } else {

    }
    tmp___5 = zend_memrchr((void const   *)ret, '.', ret_len);
    p = (char const   *)tmp___5;
    if (p) {
      idx = (int )(p - (char const   *)ret);
      tmp___6 = strlen("extension");
      add_assoc_stringl_ex(tmp, "extension", (uint )(tmp___6 + 1UL),
                           (ret + idx) + 1,
                           (uint )((ret_len - (size_t )idx) - 1UL), 1);
    } else {

    }
  } else {

  }
  if ((opt & 8L) == 8L) {
    if (! have_basename) {
      if (! ret) {
        php_basename(path, (size_t )path_len, (char *)((void *)0), (size_t )0,
                     & ret, & ret_len);
      } else {

      }
    } else {

    }
    tmp___7 = zend_memrchr((void const   *)ret, '.', ret_len);
    p___0 = (char const   *)tmp___7;
    if (p___0) {
      idx___0 = (int )(p___0 - (char const   *)ret);
    } else {
      idx___0 = (int )ret_len;
    }
    tmp___8 = strlen("filename");
    add_assoc_stringl_ex(tmp, "filename", (uint )(tmp___8 + 1UL), ret,
                         (uint )idx___0, 1);
  } else {

  }
  if (! have_basename) {
    if (ret) {
      _efree((void *)ret);
    } else {

    }
  } else {

  }
  if (opt == 15L) {
    tmp___9 = zval_isref_p(return_value);
    is_ref = tmp___9;
    tmp___10 = zval_refcount_p(return_value);
    refcount = tmp___10;
    while (1) {
      return_value->value = tmp->value;
      return_value->type = tmp->type;
      break;
    }
    tmp->type = (zend_uchar )0;
    _zval_ptr_dtor(& tmp);
    zval_set_isref_to_p(return_value, is_ref);
    zval_set_refcount_p(return_value, refcount);
    return;
  } else {
    tmp___14 = zend_hash_get_current_data_ex(tmp->value.ht,
                                             (void **)(& element),
                                             (HashPosition *)((void *)0));
    if (tmp___14 == (int __attribute__((__visibility__("default")))  )0) {
      tmp___11 = zval_isref_p(return_value);
      is_ref___0 = tmp___11;
      tmp___12 = zval_refcount_p(return_value);
      refcount___0 = tmp___12;
      while (1) {
        return_value->value = (*element)->value;
        return_value->type = (*element)->type;
        break;
      }
      _zval_copy_ctor(return_value);
      zval_set_isref_to_p(return_value, is_ref___0);
      zval_set_refcount_p(return_value, refcount___0);
    } else {
      while (1) {
        __z = return_value;
        __z->value.str.len = 0;
        tmp___13 = _estrndup("", (unsigned int )(sizeof("") - 1UL));
        __z->value.str.val = (char *)tmp___13;
        __z->type = (zend_uchar )6;
        break;
      }
    }
  }
  _zval_ptr_dtor(& tmp);
  return;
}
}
char __attribute__((__visibility__("default")))  *php_stristr(char *s ,
                                                              char *t ,
                                                              size_t s_len ,
                                                              size_t t_len ) 
{ 
  char *tmp ;

  {
  php_strtolower(s, s_len);
  php_strtolower(t, t_len);
  tmp = zend_memnstr(s, t, (int )t_len, s + s_len);
  return ((char __attribute__((__visibility__("default")))  *)tmp);
}
}
size_t __attribute__((__visibility__("default")))  php_strspn(char *s1 ,
                                                              char *s2 ,
                                                              char *s1_end ,
                                                              char *s2_end ) 
{ 
  register char const   *p ;
  register char const   *spanp ;
  register char c ;
  char const   *tmp ;

  {
  p = (char const   *)s1;
  c = (char )*p;
  cont: 
  spanp = (char const   *)s2;
  while (1) {
    if ((unsigned long )p != (unsigned long )s1_end) {
      if (! ((unsigned long )spanp != (unsigned long )s2_end)) {
        break;
      } else {

      }
    } else {
      break;
    }
    tmp = spanp;
    spanp ++;
    if ((int const   )*tmp == (int const   )c) {
      p ++;
      c = (char )*p;
      goto cont;
    } else {

    }
  }
  return ((size_t __attribute__((__visibility__("default")))  )(p - (char const   *)s1));
}
}
size_t __attribute__((__visibility__("default")))  php_strcspn(char *s1 ,
                                                               char *s2 ,
                                                               char *s1_end ,
                                                               char *s2_end ) 
{ 
  register char const   *p ;
  register char const   *spanp ;
  register char c ;
  char const   *tmp ;

  {
  c = *s1;
  p = (char const   *)s1;
  while (1) {
    spanp = (char const   *)s2;
    while (1) {
      if ((int const   )*spanp == (int const   )c) {
        return ((size_t __attribute__((__visibility__("default")))  )(p - (char const   *)s1));
      } else
      if ((unsigned long )p == (unsigned long )s1_end) {
        return ((size_t __attribute__((__visibility__("default")))  )(p - (char const   *)s1));
      } else {

      }
      tmp = spanp;
      spanp ++;
      if (! ((unsigned long )tmp < (unsigned long )(s2_end - 1))) {
        break;
      } else {

      }
    }
    p ++;
    c = (char )*p;
  }
}
}
static int php_needle_char(zval *needle , char *target ) 
{ 
  zval holder ;

  {
  switch ((int )needle->type) {
  case 1: 
  case 3: 
  *target = (char )needle->value.lval;
  return (0);
  case 0: 
  *target = (char )'\000';
  return (0);
  case 2: 
  *target = (char )((int )needle->value.dval);
  return (0);
  case 5: 
  holder = *needle;
  _zval_copy_ctor(& holder);
  convert_to_long(& holder);
  if ((int )holder.type != 1) {
    return (-1);
  } else {

  }
  *target = (char )holder.value.lval;
  return (0);
  default: 
  php_error_docref0((char const   *)((void *)0), 1 << 1L,
                    "needle is not a string or an integer");
  return (-1);
  }
}
}
void zif_stristr(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) 
{ 
  zval *needle ;
  char *haystack ;
  int haystack_len ;
  char *found ;
  int found_offset ;
  char *haystack_dup ;
  char needle_char[2] ;
  zend_bool part ;
  int __attribute__((__visibility__("default")))  tmp ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  char *orig_needle ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;
  zval *__z___0 ;
  int tmp___3 ;
  char __attribute__((__visibility__("default")))  *tmp___4 ;
  char const   *__s ;
  int __l ;
  zval *__z___1 ;
  char __attribute__((__visibility__("default")))  *tmp___5 ;
  char const   *__s___0 ;
  int __l___0 ;
  zval *__z___2 ;
  char __attribute__((__visibility__("default")))  *tmp___6 ;
  zval *__z___3 ;

  {
  found = (char *)((void *)0);
  part = (zend_bool )0;
  tmp = zend_parse_parameters(ht, "sz|b", & haystack, & haystack_len, & needle,
                              & part);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  tmp___0 = _estrndup((char const   *)haystack, (unsigned int )haystack_len);
  haystack_dup = (char *)tmp___0;
  if ((int )needle->type == 6) {
    if (! needle->value.str.len) {
      php_error_docref0((char const   *)((void *)0), 1 << 1L, "Empty delimiter");
      _efree((void *)haystack_dup);
      while (1) {
        __z = return_value;
        __z->value.lval = 0L;
        __z->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    tmp___1 = _estrndup((char const   *)needle->value.str.val,
                        (unsigned int )needle->value.str.len);
    orig_needle = (char *)tmp___1;
    tmp___2 = php_stristr(haystack_dup, orig_needle, (size_t )haystack_len,
                          (size_t )needle->value.str.len);
    found = (char *)tmp___2;
    _efree((void *)orig_needle);
  } else {
    tmp___3 = php_needle_char(needle, needle_char);
    if (tmp___3 != 0) {
      _efree((void *)haystack_dup);
      while (1) {
        __z___0 = return_value;
        __z___0->value.lval = 0L;
        __z___0->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    needle_char[1] = (char)0;
    tmp___4 = php_stristr(haystack_dup, needle_char, (size_t )haystack_len,
                          (size_t )1);
    found = (char *)tmp___4;
  }
  if (found) {
    found_offset = (int )(found - haystack_dup);
    if (part) {
      while (1) {
        __s = (char const   *)haystack;
        __l = found_offset;
        __z___1 = return_value;
        __z___1->value.str.len = __l;
        tmp___5 = _estrndup(__s, (unsigned int )__l);
        __z___1->value.str.val = (char *)tmp___5;
        __z___1->type = (zend_uchar )6;
        break;
      }
    } else {
      while (1) {
        __s___0 = (char const   *)(haystack + found_offset);
        __l___0 = haystack_len - found_offset;
        __z___2 = return_value;
        __z___2->value.str.len = __l___0;
        tmp___6 = _estrndup(__s___0, (unsigned int )__l___0);
        __z___2->value.str.val = (char *)tmp___6;
        __z___2->type = (zend_uchar )6;
        break;
      }
    }
  } else {
    while (1) {
      __z___3 = return_value;
      __z___3->value.lval = 0L;
      __z___3->type = (zend_uchar )3;
      break;
    }
  }
  _efree((void *)haystack_dup);
  return;
}
}
void zif_strstr(int ht , zval *return_value , zval **return_value_ptr ,
                zval *this_ptr , int return_value_used ) 
{ 
  zval *needle ;
  char *haystack ;
  int haystack_len ;
  char *found ;
  char needle_char[2] ;
  long found_offset ;
  zend_bool part ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  zval *__z___0 ;
  int tmp___0 ;
  char const   *__s ;
  int __l ;
  zval *__z___1 ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  char const   *__s___0 ;
  int __l___0 ;
  zval *__z___2 ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;
  zval *__z___3 ;

  {
  found = (char *)((void *)0);
  part = (zend_bool )0;
  tmp = zend_parse_parameters(ht, "sz|b", & haystack, & haystack_len, & needle,
                              & part);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if ((int )needle->type == 6) {
    if (! needle->value.str.len) {
      php_error_docref0((char const   *)((void *)0), 1 << 1L, "Empty delimiter");
      while (1) {
        __z = return_value;
        __z->value.lval = 0L;
        __z->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    found = zend_memnstr(haystack, needle->value.str.val, needle->value.str.len,
                         haystack + haystack_len);
  } else {
    tmp___0 = php_needle_char(needle, needle_char);
    if (tmp___0 != 0) {
      while (1) {
        __z___0 = return_value;
        __z___0->value.lval = 0L;
        __z___0->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    needle_char[1] = (char)0;
    found = zend_memnstr(haystack, needle_char, 1, haystack + haystack_len);
  }
  if (found) {
    found_offset = found - haystack;
    if (part) {
      while (1) {
        __s = (char const   *)haystack;
        __l = (int )found_offset;
        __z___1 = return_value;
        __z___1->value.str.len = __l;
        tmp___1 = _estrndup(__s, (unsigned int )__l);
        __z___1->value.str.val = (char *)tmp___1;
        __z___1->type = (zend_uchar )6;
        break;
      }
      return;
    } else {
      while (1) {
        __s___0 = (char const   *)found;
        __l___0 = (int )((long )haystack_len - found_offset);
        __z___2 = return_value;
        __z___2->value.str.len = __l___0;
        tmp___2 = _estrndup(__s___0, (unsigned int )__l___0);
        __z___2->value.str.val = (char *)tmp___2;
        __z___2->type = (zend_uchar )6;
        break;
      }
      return;
    }
  } else {

  }
  while (1) {
    __z___3 = return_value;
    __z___3->value.lval = 0L;
    __z___3->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zif_strpos(int ht , zval *return_value , zval **return_value_ptr ,
                zval *this_ptr , int return_value_used ) 
{ 
  zval *needle ;
  char *haystack ;
  char *found ;
  char needle_char[2] ;
  long offset ;
  int haystack_len ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  zval *__z___0 ;
  zval *__z___1 ;
  int tmp___0 ;
  zval *__z___2 ;
  zval *__z___3 ;

  {
  found = (char *)((void *)0);
  offset = 0L;
  tmp = zend_parse_parameters(ht, "sz|l", & haystack, & haystack_len, & needle,
                              & offset);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (offset < 0L) {
    goto _L;
  } else
  if (offset > (long )haystack_len) {
    _L: 
    php_error_docref0((char const   *)((void *)0), 1 << 1L,
                      "Offset not contained in string");
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  if ((int )needle->type == 6) {
    if (! needle->value.str.len) {
      php_error_docref0((char const   *)((void *)0), 1 << 1L, "Empty delimiter");
      while (1) {
        __z___0 = return_value;
        __z___0->value.lval = 0L;
        __z___0->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    found = zend_memnstr(haystack + offset, needle->value.str.val,
                         needle->value.str.len, haystack + haystack_len);
  } else {
    tmp___0 = php_needle_char(needle, needle_char);
    if (tmp___0 != 0) {
      while (1) {
        __z___1 = return_value;
        __z___1->value.lval = 0L;
        __z___1->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    needle_char[1] = (char)0;
    found = zend_memnstr(haystack + offset, needle_char, 1,
                         haystack + haystack_len);
  }
  if (found) {
    __z___2 = return_value;
    __z___2->value.lval = found - haystack;
    __z___2->type = (zend_uchar )1;
    return;
  } else {
    while (1) {
      __z___3 = return_value;
      __z___3->value.lval = 0L;
      __z___3->type = (zend_uchar )3;
      break;
    }
    return;
  }
}
}
void zif_stripos(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) 
{ 
  char *found ;
  char *haystack ;
  int haystack_len ;
  long offset ;
  char *needle_dup ;
  char *haystack_dup ;
  char needle_char[2] ;
  zval *needle ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  zval *__z___0 ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  zval *__z___1 ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  zval *__z___2 ;
  int tmp___2 ;
  int __res ;
  int __attribute__((__gnu_inline__))  tmp___4 ;
  __int32_t const   **tmp___5 ;
  zval *__z___3 ;
  zval *__z___4 ;

  {
  found = (char *)((void *)0);
  offset = 0L;
  needle_dup = (char *)((void *)0);
  tmp = zend_parse_parameters(ht, "sz|l", & haystack, & haystack_len, & needle,
                              & offset);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (offset < 0L) {
    goto _L;
  } else
  if (offset > (long )haystack_len) {
    _L: 
    php_error_docref0((char const   *)((void *)0), 1 << 1L,
                      "Offset not contained in string");
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  if (haystack_len == 0) {
    while (1) {
      __z___0 = return_value;
      __z___0->value.lval = 0L;
      __z___0->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  tmp___0 = _estrndup((char const   *)haystack, (unsigned int )haystack_len);
  haystack_dup = (char *)tmp___0;
  php_strtolower(haystack_dup, (size_t )haystack_len);
  if ((int )needle->type == 6) {
    if (needle->value.str.len == 0) {
      goto _L___0;
    } else
    if (needle->value.str.len > haystack_len) {
      _L___0: 
      _efree((void *)haystack_dup);
      while (1) {
        __z___1 = return_value;
        __z___1->value.lval = 0L;
        __z___1->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    tmp___1 = _estrndup((char const   *)needle->value.str.val,
                        (unsigned int )needle->value.str.len);
    needle_dup = (char *)tmp___1;
    php_strtolower(needle_dup, (size_t )needle->value.str.len);
    found = zend_memnstr(haystack_dup + offset, needle_dup,
                         needle->value.str.len, haystack_dup + haystack_len);
  } else {
    tmp___2 = php_needle_char(needle, needle_char);
    if (tmp___2 != 0) {
      _efree((void *)haystack_dup);
      while (1) {
        __z___2 = return_value;
        __z___2->value.lval = 0L;
        __z___2->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    if (sizeof(needle_char[0]) > 1UL) {
      tmp___4 = tolower((int )needle_char[0]);
      __res = (int )tmp___4;
    } else {
      tmp___5 = __ctype_tolower_loc();
      __res = (int )*(*tmp___5 + (int )needle_char[0]);
    }
    needle_char[0] = (char )__res;
    needle_char[1] = (char )'\000';
    found = zend_memnstr(haystack_dup + offset, needle_char,
                         (int )(sizeof(needle_char) - 1UL),
                         haystack_dup + haystack_len);
  }
  _efree((void *)haystack_dup);
  if (needle_dup) {
    _efree((void *)needle_dup);
  } else {

  }
  if (found) {
    __z___3 = return_value;
    __z___3->value.lval = found - haystack_dup;
    __z___3->type = (zend_uchar )1;
    return;
  } else {
    while (1) {
      __z___4 = return_value;
      __z___4->value.lval = 0L;
      __z___4->type = (zend_uchar )3;
      break;
    }
    return;
  }
}
}
void zif_strrpos(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) 
{ 
  zval *zneedle ;
  char *needle ;
  char *haystack ;
  int needle_len ;
  int haystack_len ;
  long offset ;
  char *p ;
  char *e ;
  char ord_needle[2] ;
  zval *__z ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z___0 ;
  int tmp___0 ;
  zval *__z___1 ;
  zval *__z___2 ;
  zval *__z___3 ;
  zval *__z___4 ;
  long tmp___1 ;
  zval *__z___5 ;
  zval *__z___6 ;
  long tmp___2 ;
  int tmp___3 ;
  zval *__z___7 ;

  {
  offset = 0L;
  tmp = zend_parse_parameters(ht, "sz|l", & haystack, & haystack_len, & zneedle,
                              & offset);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  if ((int )zneedle->type == 6) {
    needle = zneedle->value.str.val;
    needle_len = zneedle->value.str.len;
  } else {
    tmp___0 = php_needle_char(zneedle, ord_needle);
    if (tmp___0 != 0) {
      while (1) {
        __z___0 = return_value;
        __z___0->value.lval = 0L;
        __z___0->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    ord_needle[1] = (char )'\000';
    needle = ord_needle;
    needle_len = 1;
  }
  if (haystack_len == 0) {
    goto _L;
  } else
  if (needle_len == 0) {
    _L: 
    while (1) {
      __z___1 = return_value;
      __z___1->value.lval = 0L;
      __z___1->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  if (offset >= 0L) {
    if (offset > (long )haystack_len) {
      php_error_docref0((char const   *)((void *)0), 1 << 1L,
                        "Offset is greater than the length of haystack string");
      while (1) {
        __z___2 = return_value;
        __z___2->value.lval = 0L;
        __z___2->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    p = haystack + offset;
    e = (haystack + haystack_len) - needle_len;
  } else {
    if (offset < -2147483647L) {
      goto _L___0;
    } else
    if (- offset > (long )haystack_len) {
      _L___0: 
      php_error_docref0((char const   *)((void *)0), 1 << 1L,
                        "Offset is greater than the length of haystack string");
      while (1) {
        __z___3 = return_value;
        __z___3->value.lval = 0L;
        __z___3->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    p = haystack;
    if ((long )needle_len > - offset) {
      e = (haystack + haystack_len) - needle_len;
    } else {
      e = (haystack + haystack_len) + offset;
    }
  }
  if (needle_len == 1) {
    while ((unsigned long )e >= (unsigned long )p) {
      if ((int )*e == (int )*needle) {
        __z___4 = return_value;
        if (offset > 0L) {
          tmp___1 = offset;
        } else {
          tmp___1 = 0L;
        }
        __z___4->value.lval = (e - p) + tmp___1;
        __z___4->type = (zend_uchar )1;
        return;
      } else {

      }
      e --;
    }
    while (1) {
      __z___5 = return_value;
      __z___5->value.lval = 0L;
      __z___5->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  while ((unsigned long )e >= (unsigned long )p) {
    tmp___3 = memcmp((void const   *)e, (void const   *)needle,
                     (size_t )needle_len);
    if (tmp___3 == 0) {
      __z___6 = return_value;
      if (offset > 0L) {
        tmp___2 = offset;
      } else {
        tmp___2 = 0L;
      }
      __z___6->value.lval = (e - p) + tmp___2;
      __z___6->type = (zend_uchar )1;
      return;
    } else {

    }
    e --;
  }
  while (1) {
    __z___7 = return_value;
    __z___7->value.lval = 0L;
    __z___7->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zif_strripos(int ht , zval *return_value , zval **return_value_ptr ,
                  zval *this_ptr , int return_value_used ) 
{ 
  zval *zneedle ;
  char *needle ;
  char *haystack ;
  int needle_len ;
  int haystack_len ;
  long offset ;
  char *p ;
  char *e ;
  char ord_needle[2] ;
  char *needle_dup ;
  char *haystack_dup ;
  zval *__z ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z___0 ;
  int tmp___0 ;
  zval *__z___1 ;
  zval *__z___2 ;
  zval *__z___3 ;
  int __res ;
  int __attribute__((__gnu_inline__))  tmp___2 ;
  __int32_t const   **tmp___3 ;
  zval *__z___4 ;
  long tmp___4 ;
  int __res___0 ;
  int __attribute__((__gnu_inline__))  tmp___6 ;
  __int32_t const   **tmp___7 ;
  zval *__z___5 ;
  char __attribute__((__visibility__("default")))  *tmp___8 ;
  char __attribute__((__visibility__("default")))  *tmp___9 ;
  zval *__z___6 ;
  zval *__z___7 ;
  zval *__z___8 ;
  long tmp___10 ;
  int tmp___11 ;
  zval *__z___9 ;

  {
  offset = 0L;
  tmp = zend_parse_parameters(ht, "sz|l", & haystack, & haystack_len, & zneedle,
                              & offset);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  if ((int )zneedle->type == 6) {
    needle = zneedle->value.str.val;
    needle_len = zneedle->value.str.len;
  } else {
    tmp___0 = php_needle_char(zneedle, ord_needle);
    if (tmp___0 != 0) {
      while (1) {
        __z___0 = return_value;
        __z___0->value.lval = 0L;
        __z___0->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    ord_needle[1] = (char )'\000';
    needle = ord_needle;
    needle_len = 1;
  }
  if (haystack_len == 0) {
    goto _L;
  } else
  if (needle_len == 0) {
    _L: 
    while (1) {
      __z___1 = return_value;
      __z___1->value.lval = 0L;
      __z___1->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  if (needle_len == 1) {
    if (offset >= 0L) {
      if (offset > (long )haystack_len) {
        php_error_docref0((char const   *)((void *)0), 1 << 1L,
                          "Offset is greater than the length of haystack string");
        while (1) {
          __z___2 = return_value;
          __z___2->value.lval = 0L;
          __z___2->type = (zend_uchar )3;
          break;
        }
        return;
      } else {

      }
      p = haystack + offset;
      e = (haystack + haystack_len) - 1;
    } else {
      p = haystack;
      if (offset < -2147483647L) {
        goto _L___0;
      } else
      if (- offset > (long )haystack_len) {
        _L___0: 
        php_error_docref0((char const   *)((void *)0), 1 << 1L,
                          "Offset is greater than the length of haystack string");
        while (1) {
          __z___3 = return_value;
          __z___3->value.lval = 0L;
          __z___3->type = (zend_uchar )3;
          break;
        }
        return;
      } else {

      }
      e = (haystack + haystack_len) + offset;
    }
    if (sizeof(*needle) > 1UL) {
      tmp___2 = tolower((int )*needle);
      __res = (int )tmp___2;
    } else {
      tmp___3 = __ctype_tolower_loc();
      __res = (int )*(*tmp___3 + (int )*needle);
    }
    ord_needle[0] = (char )__res;
    while ((unsigned long )e >= (unsigned long )p) {
      if (sizeof(*e) > 1UL) {
        tmp___6 = tolower((int )*e);
        __res___0 = (int )tmp___6;
      } else {
        tmp___7 = __ctype_tolower_loc();
        __res___0 = (int )*(*tmp___7 + (int )*e);
      }
      if (__res___0 == (int )ord_needle[0]) {
        __z___4 = return_value;
        if (offset > 0L) {
          tmp___4 = offset;
        } else {
          tmp___4 = 0L;
        }
        __z___4->value.lval = (e - p) + tmp___4;
        __z___4->type = (zend_uchar )1;
        return;
      } else {

      }
      e --;
    }
    while (1) {
      __z___5 = return_value;
      __z___5->value.lval = 0L;
      __z___5->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  tmp___8 = _estrndup((char const   *)needle, (unsigned int )needle_len);
  needle_dup = (char *)tmp___8;
  php_strtolower(needle_dup, (size_t )needle_len);
  tmp___9 = _estrndup((char const   *)haystack, (unsigned int )haystack_len);
  haystack_dup = (char *)tmp___9;
  php_strtolower(haystack_dup, (size_t )haystack_len);
  if (offset >= 0L) {
    if (offset > (long )haystack_len) {
      _efree((void *)needle_dup);
      _efree((void *)haystack_dup);
      php_error_docref0((char const   *)((void *)0), 1 << 1L,
                        "Offset is greater than the length of haystack string");
      while (1) {
        __z___6 = return_value;
        __z___6->value.lval = 0L;
        __z___6->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    p = haystack_dup + offset;
    e = (haystack_dup + haystack_len) - needle_len;
  } else {
    if (offset < -2147483647L) {
      goto _L___1;
    } else
    if (- offset > (long )haystack_len) {
      _L___1: 
      _efree((void *)needle_dup);
      _efree((void *)haystack_dup);
      php_error_docref0((char const   *)((void *)0), 1 << 1L,
                        "Offset is greater than the length of haystack string");
      while (1) {
        __z___7 = return_value;
        __z___7->value.lval = 0L;
        __z___7->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    p = haystack_dup;
    if ((long )needle_len > - offset) {
      e = (haystack_dup + haystack_len) - needle_len;
    } else {
      e = (haystack_dup + haystack_len) + offset;
    }
  }
  while ((unsigned long )e >= (unsigned long )p) {
    tmp___11 = memcmp((void const   *)e, (void const   *)needle_dup,
                      (size_t )needle_len);
    if (tmp___11 == 0) {
      _efree((void *)haystack_dup);
      _efree((void *)needle_dup);
      __z___8 = return_value;
      if (offset > 0L) {
        tmp___10 = offset;
      } else {
        tmp___10 = 0L;
      }
      __z___8->value.lval = (e - p) + tmp___10;
      __z___8->type = (zend_uchar )1;
      return;
    } else {

    }
    e --;
  }
  _efree((void *)haystack_dup);
  _efree((void *)needle_dup);
  while (1) {
    __z___9 = return_value;
    __z___9->value.lval = 0L;
    __z___9->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zif_strrchr(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) 
{ 
  zval *needle ;
  char *haystack ;
  char const   *found ;
  long found_offset ;
  int haystack_len ;
  int __attribute__((__visibility__("default")))  tmp ;
  void const   *tmp___0 ;
  char needle_chr ;
  zval *__z ;
  int tmp___1 ;
  void const   *tmp___2 ;
  char const   *__s ;
  int __l ;
  zval *__z___0 ;
  char __attribute__((__visibility__("default")))  *tmp___3 ;
  zval *__z___1 ;

  {
  found = (char const   *)((void *)0);
  tmp = zend_parse_parameters(ht, "sz", & haystack, & haystack_len, & needle);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if ((int )needle->type == 6) {
    tmp___0 = zend_memrchr((void const   *)haystack,
                           (int )*(needle->value.str.val), (size_t )haystack_len);
    found = (char const   *)tmp___0;
  } else {
    tmp___1 = php_needle_char(needle, & needle_chr);
    if (tmp___1 != 0) {
      while (1) {
        __z = return_value;
        __z->value.lval = 0L;
        __z->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    tmp___2 = zend_memrchr((void const   *)haystack, (int )needle_chr,
                           (size_t )haystack_len);
    found = (char const   *)tmp___2;
  }
  if (found) {
    found_offset = found - (char const   *)haystack;
    while (1) {
      __s = found;
      __l = (int )((long )haystack_len - found_offset);
      __z___0 = return_value;
      __z___0->value.str.len = __l;
      tmp___3 = _estrndup(__s, (unsigned int )__l);
      __z___0->value.str.val = (char *)tmp___3;
      __z___0->type = (zend_uchar )6;
      break;
    }
    return;
  } else {
    while (1) {
      __z___1 = return_value;
      __z___1->value.lval = 0L;
      __z___1->type = (zend_uchar )3;
      break;
    }
    return;
  }
}
}
static char *php_chunk_split(char *src , int srclen , char *end , int endlen ,
                             int chunklen , int *destlen ) 
{ 
  char *dest ;
  char *p ;
  char *q ;
  int chunks ;
  int restlen ;
  int out_len ;
  void __attribute__((__visibility__("default")))  *tmp ;

  {
  chunks = srclen / chunklen;
  restlen = srclen - chunks * chunklen;
  if (chunks > 2147483646) {
    return ((char *)((void *)0));
  } else {

  }
  out_len = chunks + 1;
  if (endlen != 0) {
    if (out_len > 2147483647 / endlen) {
      return ((char *)((void *)0));
    } else {

    }
  } else {

  }
  out_len *= endlen;
  if (out_len > (2147483647 - srclen) - 1) {
    return ((char *)((void *)0));
  } else {

  }
  out_len += srclen + 1;
  tmp = _safe_emalloc((size_t )out_len, sizeof(char ), (size_t )0);
  dest = (char *)tmp;
  p = src;
  q = dest;
  while ((unsigned long )p < (unsigned long )(((src + srclen) - chunklen) + 1)) {
    memcpy((void */* __restrict  */)q, (void const   */* __restrict  */)p,
           (size_t )chunklen);
    q += chunklen;
    memcpy((void */* __restrict  */)q, (void const   */* __restrict  */)end,
           (size_t )endlen);
    q += endlen;
    p += chunklen;
  }
  if (restlen) {
    memcpy((void */* __restrict  */)q, (void const   */* __restrict  */)p,
           (size_t )restlen);
    q += restlen;
    memcpy((void */* __restrict  */)q, (void const   */* __restrict  */)end,
           (size_t )endlen);
    q += endlen;
  } else {

  }
  *q = (char )'\000';
  if (destlen) {
    *destlen = (int )(q - dest);
  } else {

  }
  return (dest);
}
}
void zif_chunk_split(int ht , zval *return_value , zval **return_value_ptr ,
                     zval *this_ptr , int return_value_used ) 
{ 
  char *str ;
  char *result ;
  char *end ;
  int endlen ;
  long chunklen ;
  int result_len ;
  int str_len ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  char const   *__s ;
  int __l ;
  zval *__z___0 ;
  zval *__z___1 ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;
  char const   *__s___0 ;
  int __l___0 ;
  zval *__z___2 ;
  zval *__z___3 ;

  {
  end = (char *)"\r\n";
  endlen = 2;
  chunklen = 76L;
  tmp = zend_parse_parameters(ht, "s|ls", & str, & str_len, & chunklen, & end,
                              & endlen);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (chunklen <= 0L) {
    php_error_docref0((char const   *)((void *)0), 1 << 1L,
                      "Chunk length should be greater than zero");
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  if (chunklen > (long )str_len) {
    result_len = endlen + str_len;
    tmp___0 = _emalloc((size_t )(result_len + 1));
    result = (char *)tmp___0;
    memcpy((void */* __restrict  */)result,
           (void const   */* __restrict  */)str, (size_t )str_len);
    memcpy((void */* __restrict  */)(result + str_len),
           (void const   */* __restrict  */)end, (size_t )endlen);
    *(result + result_len) = (char )'\000';
    while (1) {
      __s = (char const   *)result;
      __l = result_len;
      __z___0 = return_value;
      __z___0->value.str.len = __l;
      __z___0->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
      __z___0->type = (zend_uchar )6;
      break;
    }
    return;
  } else {

  }
  if (! str_len) {
    while (1) {
      __z___1 = return_value;
      __z___1->value.str.len = 0;
      tmp___2 = _estrndup("", (unsigned int )(sizeof("") - 1UL));
      __z___1->value.str.val = (char *)tmp___2;
      __z___1->type = (zend_uchar )6;
      break;
    }
    return;
  } else {

  }
  result = php_chunk_split(str, str_len, end, endlen, (int )chunklen,
                           & result_len);
  if (result) {
    while (1) {
      __s___0 = (char const   *)result;
      __l___0 = result_len;
      __z___2 = return_value;
      __z___2->value.str.len = __l___0;
      __z___2->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s___0));
      __z___2->type = (zend_uchar )6;
      break;
    }
    return;
  } else {
    while (1) {
      __z___3 = return_value;
      __z___3->value.lval = 0L;
      __z___3->type = (zend_uchar )3;
      break;
    }
    return;
  }
}
}
void zif_substr(int ht , zval *return_value , zval **return_value_ptr ,
                zval *this_ptr , int return_value_used ) 
{ 
  char *str ;
  long l ;
  long f ;
  int str_len ;
  int argc ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  zval *__z___0 ;
  zval *__z___1 ;
  zval *__z___2 ;
  char const   *__s ;
  int __l ;
  zval *__z___3 ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;

  {
  l = 0L;
  argc = ht;
  tmp = zend_parse_parameters(ht, "sl|l", & str, & str_len, & f, & l);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (argc > 2) {
    if (l < 0L) {
      if (- l > (long )str_len) {
        while (1) {
          __z = return_value;
          __z->value.lval = 0L;
          __z->type = (zend_uchar )3;
          break;
        }
        return;
      } else {
        goto _L;
      }
    } else
    _L: 
    if (l > (long )str_len) {
      l = (long )str_len;
    } else {

    }
  } else {
    l = (long )str_len;
  }
  if (f > (long )str_len) {
    while (1) {
      __z___0 = return_value;
      __z___0->value.lval = 0L;
      __z___0->type = (zend_uchar )3;
      break;
    }
    return;
  } else
  if (f < 0L) {
    if (- f > (long )str_len) {
      f = 0L;
    } else {

    }
  } else {

  }
  if (l < 0L) {
    if ((l + (long )str_len) - f < 0L) {
      while (1) {
        __z___1 = return_value;
        __z___1->value.lval = 0L;
        __z___1->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
  } else {

  }
  if (f < 0L) {
    f = (long )str_len + f;
    if (f < 0L) {
      f = 0L;
    } else {

    }
  } else {

  }
  if (l < 0L) {
    l = ((long )str_len - f) + l;
    if (l < 0L) {
      l = 0L;
    } else {

    }
  } else {

  }
  if (f >= (long )str_len) {
    while (1) {
      __z___2 = return_value;
      __z___2->value.lval = 0L;
      __z___2->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  if (f + l > (long )str_len) {
    l = (long )str_len - f;
  } else {

  }
  while (1) {
    __s = (char const   *)(str + f);
    __l = (int )l;
    __z___3 = return_value;
    __z___3->value.str.len = __l;
    tmp___0 = _estrndup(__s, (unsigned int )__l);
    __z___3->value.str.val = (char *)tmp___0;
    __z___3->type = (zend_uchar )6;
    break;
  }
  return;
}
}
void zif_substr_replace(int ht , zval *return_value , zval **return_value_ptr ,
                        zval *this_ptr , int return_value_used ) 
{ 
  zval **str ;
  zval **from ;
  zval **len ;
  zval **repl ;
  char *result ;
  int result_len ;
  int l ;
  int f ;
  int argc ;
  HashPosition pos_str ;
  HashPosition pos_from ;
  HashPosition pos_repl ;
  HashPosition pos_len ;
  zval **tmp_str ;
  zval **tmp_from ;
  zval **tmp_repl ;
  zval **tmp_len ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *new_zv ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  zend_uint tmp___1 ;
  zend_bool tmp___2 ;
  zval *new_zv___0 ;
  void __attribute__((__visibility__("default")))  *tmp___3 ;
  zend_uint tmp___4 ;
  zend_bool tmp___5 ;
  zval *new_zv___1 ;
  void __attribute__((__visibility__("default")))  *tmp___6 ;
  zend_uint tmp___7 ;
  zend_bool tmp___8 ;
  zval *new_zv___2 ;
  void __attribute__((__visibility__("default")))  *tmp___9 ;
  zend_uint tmp___10 ;
  zend_bool tmp___11 ;
  zval *new_zv___3 ;
  void __attribute__((__visibility__("default")))  *tmp___12 ;
  zend_uint tmp___13 ;
  zend_bool tmp___14 ;
  zval *new_zv___4 ;
  void __attribute__((__visibility__("default")))  *tmp___15 ;
  zend_uint tmp___16 ;
  zend_bool tmp___17 ;
  zval *new_zv___5 ;
  void __attribute__((__visibility__("default")))  *tmp___18 ;
  zend_uint tmp___19 ;
  zval *new_zv___6 ;
  void __attribute__((__visibility__("default")))  *tmp___20 ;
  zend_uint tmp___21 ;
  zend_bool tmp___22 ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___23 ;
  char const   *__s___0 ;
  int __l___0 ;
  zval *__z___0 ;
  char __attribute__((__visibility__("default")))  *tmp___24 ;
  int __attribute__((__visibility__("default")))  tmp___25 ;
  int __attribute__((__visibility__("default")))  tmp___26 ;
  int repl_len ;
  zval *__z___1 ;
  zval *new_zv___7 ;
  void __attribute__((__visibility__("default")))  *tmp___27 ;
  zend_uint tmp___28 ;
  zend_bool tmp___29 ;
  int __attribute__((__visibility__("default")))  tmp___30 ;
  void __attribute__((__visibility__("default")))  *tmp___31 ;
  char *tmp___32 ;
  char const   *__s___1 ;
  int __l___1 ;
  zval *__z___2 ;
  char const   *__s___2 ;
  int __l___2 ;
  zval *__z___3 ;
  char __attribute__((__visibility__("default")))  *tmp___34 ;
  zval *new_zv___8 ;
  void __attribute__((__visibility__("default")))  *tmp___35 ;
  zend_uint tmp___36 ;
  zend_bool tmp___37 ;
  zval *new_zv___9 ;
  void __attribute__((__visibility__("default")))  *tmp___38 ;
  zend_uint tmp___39 ;
  zend_bool tmp___40 ;
  int __attribute__((__visibility__("default")))  tmp___41 ;
  zval *new_zv___10 ;
  void __attribute__((__visibility__("default")))  *tmp___42 ;
  zend_uint tmp___43 ;
  zend_bool tmp___44 ;
  int __attribute__((__visibility__("default")))  tmp___45 ;
  zval *new_zv___11 ;
  void __attribute__((__visibility__("default")))  *tmp___46 ;
  zend_uint tmp___47 ;
  zend_bool tmp___48 ;
  void __attribute__((__visibility__("default")))  *tmp___49 ;
  void __attribute__((__visibility__("default")))  *tmp___50 ;
  int __attribute__((__visibility__("default")))  tmp___51 ;
  void __attribute__((__visibility__("default")))  *tmp___52 ;
  int __attribute__((__visibility__("default")))  tmp___53 ;

  {
  len = (zval **)((void *)0);
  l = 0;
  argc = ht;
  tmp_str = (zval **)((void *)0);
  tmp_from = (zval **)((void *)0);
  tmp_repl = (zval **)((void *)0);
  tmp_len = (zval **)((void *)0);
  tmp = zend_parse_parameters(ht, "ZZZ|Z", & str, & repl, & from, & len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if ((int )(*str)->type != 4) {
    tmp___2 = zval_isref_p(*str);
    if (tmp___2) {
      while (1) {
        tmp___1 = zval_refcount_p(*str);
        if (tmp___1 > 1U) {
          zval_delref_p(*str);
          while (1) {
            tmp___0 = _emalloc(sizeof(zval_gc_info ));
            new_zv = (zval *)tmp___0;
            ((zval_gc_info *)new_zv)->u.buffered = (gc_root_buffer *)((void *)0);
            break;
          }
          while (1) {
            while (1) {
              new_zv->value = (*str)->value;
              new_zv->type = (*str)->type;
              break;
            }
            zval_set_refcount_p(new_zv, (zend_uint )1);
            zval_unset_isref_p(new_zv);
            break;
          }
          *str = new_zv;
          _zval_copy_ctor(new_zv);
        } else {

        }
        break;
      }
    } else {

    }
    if ((int )(*str)->type != 6) {
      tmp___5 = zval_isref_p(*str);
      if (! tmp___5) {
        while (1) {
          tmp___4 = zval_refcount_p(*str);
          if (tmp___4 > 1U) {
            zval_delref_p(*str);
            while (1) {
              tmp___3 = _emalloc(sizeof(zval_gc_info ));
              new_zv___0 = (zval *)tmp___3;
              ((zval_gc_info *)new_zv___0)->u.buffered = (gc_root_buffer *)((void *)0);
              break;
            }
            while (1) {
              while (1) {
                new_zv___0->value = (*str)->value;
                new_zv___0->type = (*str)->type;
                break;
              }
              zval_set_refcount_p(new_zv___0, (zend_uint )1);
              zval_unset_isref_p(new_zv___0);
              break;
            }
            *str = new_zv___0;
            _zval_copy_ctor(new_zv___0);
          } else {

          }
          break;
        }
      } else {

      }
      if ((int )(*str)->type != 6) {
        _convert_to_string(*str);
      } else {

      }
    } else {

    }
  } else {

  }
  if ((int )(*repl)->type != 4) {
    tmp___8 = zval_isref_p(*repl);
    if (tmp___8) {
      while (1) {
        tmp___7 = zval_refcount_p(*repl);
        if (tmp___7 > 1U) {
          zval_delref_p(*repl);
          while (1) {
            tmp___6 = _emalloc(sizeof(zval_gc_info ));
            new_zv___1 = (zval *)tmp___6;
            ((zval_gc_info *)new_zv___1)->u.buffered = (gc_root_buffer *)((void *)0);
            break;
          }
          while (1) {
            while (1) {
              new_zv___1->value = (*repl)->value;
              new_zv___1->type = (*repl)->type;
              break;
            }
            zval_set_refcount_p(new_zv___1, (zend_uint )1);
            zval_unset_isref_p(new_zv___1);
            break;
          }
          *repl = new_zv___1;
          _zval_copy_ctor(new_zv___1);
        } else {

        }
        break;
      }
    } else {

    }
    if ((int )(*repl)->type != 6) {
      tmp___11 = zval_isref_p(*repl);
      if (! tmp___11) {
        while (1) {
          tmp___10 = zval_refcount_p(*repl);
          if (tmp___10 > 1U) {
            zval_delref_p(*repl);
            while (1) {
              tmp___9 = _emalloc(sizeof(zval_gc_info ));
              new_zv___2 = (zval *)tmp___9;
              ((zval_gc_info *)new_zv___2)->u.buffered = (gc_root_buffer *)((void *)0);
              break;
            }
            while (1) {
              while (1) {
                new_zv___2->value = (*repl)->value;
                new_zv___2->type = (*repl)->type;
                break;
              }
              zval_set_refcount_p(new_zv___2, (zend_uint )1);
              zval_unset_isref_p(new_zv___2);
              break;
            }
            *repl = new_zv___2;
            _zval_copy_ctor(new_zv___2);
          } else {

          }
          break;
        }
      } else {

      }
      if ((int )(*repl)->type != 6) {
        _convert_to_string(*repl);
      } else {

      }
    } else {

    }
  } else {

  }
  if ((int )(*from)->type != 4) {
    tmp___14 = zval_isref_p(*from);
    if (tmp___14) {
      while (1) {
        tmp___13 = zval_refcount_p(*from);
        if (tmp___13 > 1U) {
          zval_delref_p(*from);
          while (1) {
            tmp___12 = _emalloc(sizeof(zval_gc_info ));
            new_zv___3 = (zval *)tmp___12;
            ((zval_gc_info *)new_zv___3)->u.buffered = (gc_root_buffer *)((void *)0);
            break;
          }
          while (1) {
            while (1) {
              new_zv___3->value = (*from)->value;
              new_zv___3->type = (*from)->type;
              break;
            }
            zval_set_refcount_p(new_zv___3, (zend_uint )1);
            zval_unset_isref_p(new_zv___3);
            break;
          }
          *from = new_zv___3;
          _zval_copy_ctor(new_zv___3);
        } else {

        }
        break;
      }
    } else {

    }
    if ((int )(*from)->type != 1) {
      tmp___17 = zval_isref_p(*from);
      if (! tmp___17) {
        while (1) {
          tmp___16 = zval_refcount_p(*from);
          if (tmp___16 > 1U) {
            zval_delref_p(*from);
            while (1) {
              tmp___15 = _emalloc(sizeof(zval_gc_info ));
              new_zv___4 = (zval *)tmp___15;
              ((zval_gc_info *)new_zv___4)->u.buffered = (gc_root_buffer *)((void *)0);
              break;
            }
            while (1) {
              while (1) {
                new_zv___4->value = (*from)->value;
                new_zv___4->type = (*from)->type;
                break;
              }
              zval_set_refcount_p(new_zv___4, (zend_uint )1);
              zval_unset_isref_p(new_zv___4);
              break;
            }
            *from = new_zv___4;
            _zval_copy_ctor(new_zv___4);
          } else {

          }
          break;
        }
      } else {

      }
      convert_to_long(*from);
    } else {

    }
  } else {

  }
  if (argc > 3) {
    while (1) {
      tmp___19 = zval_refcount_p(*len);
      if (tmp___19 > 1U) {
        zval_delref_p(*len);
        while (1) {
          tmp___18 = _emalloc(sizeof(zval_gc_info ));
          new_zv___5 = (zval *)tmp___18;
          ((zval_gc_info *)new_zv___5)->u.buffered = (gc_root_buffer *)((void *)0);
          break;
        }
        while (1) {
          while (1) {
            new_zv___5->value = (*len)->value;
            new_zv___5->type = (*len)->type;
            break;
          }
          zval_set_refcount_p(new_zv___5, (zend_uint )1);
          zval_unset_isref_p(new_zv___5);
          break;
        }
        *len = new_zv___5;
        _zval_copy_ctor(new_zv___5);
      } else {

      }
      break;
    }
    if ((int )(*len)->type != 4) {
      if ((int )(*len)->type != 1) {
        tmp___22 = zval_isref_p(*len);
        if (! tmp___22) {
          while (1) {
            tmp___21 = zval_refcount_p(*len);
            if (tmp___21 > 1U) {
              zval_delref_p(*len);
              while (1) {
                tmp___20 = _emalloc(sizeof(zval_gc_info ));
                new_zv___6 = (zval *)tmp___20;
                ((zval_gc_info *)new_zv___6)->u.buffered = (gc_root_buffer *)((void *)0);
                break;
              }
              while (1) {
                while (1) {
                  new_zv___6->value = (*len)->value;
                  new_zv___6->type = (*len)->type;
                  break;
                }
                zval_set_refcount_p(new_zv___6, (zend_uint )1);
                zval_unset_isref_p(new_zv___6);
                break;
              }
              *len = new_zv___6;
              _zval_copy_ctor(new_zv___6);
            } else {

            }
            break;
          }
        } else {

        }
        convert_to_long(*len);
      } else {

      }
      l = (int )(*len)->value.lval;
    } else {

    }
  } else
  if ((int )(*str)->type != 4) {
    l = (*str)->value.str.len;
  } else {

  }
  if ((int )(*str)->type == 6) {
    if (argc == 3) {
      if ((int )(*from)->type == 4) {
        goto _L;
      } else {
        goto _L___0;
      }
    } else
    _L___0: 
    if (argc == 4) {
      if ((int )(*from)->type != (int )(*len)->type) {
        _L: 
        php_error_docref0((char const   *)((void *)0), 1 << 1L,
                          "\'from\' and \'len\' should be of same type - numerical or array ");
        while (1) {
          __s = (char const   *)(*str)->value.str.val;
          __l = (*str)->value.str.len;
          __z = return_value;
          __z->value.str.len = __l;
          tmp___23 = _estrndup(__s, (unsigned int )__l);
          __z->value.str.val = (char *)tmp___23;
          __z->type = (zend_uchar )6;
          break;
        }
        return;
      } else {

      }
    } else {

    }
    if (argc == 4) {
      if ((int )(*from)->type == 4) {
        tmp___25 = zend_hash_num_elements((HashTable const   *)(*from)->value.ht);
        tmp___26 = zend_hash_num_elements((HashTable const   *)(*len)->value.ht);
        if (tmp___25 != tmp___26) {
          php_error_docref0((char const   *)((void *)0), 1 << 1L,
                            "\'from\' and \'len\' should have the same number of elements");
          while (1) {
            __s___0 = (char const   *)(*str)->value.str.val;
            __l___0 = (*str)->value.str.len;
            __z___0 = return_value;
            __z___0->value.str.len = __l___0;
            tmp___24 = _estrndup(__s___0, (unsigned int )__l___0);
            __z___0->value.str.val = (char *)tmp___24;
            __z___0->type = (zend_uchar )6;
            break;
          }
          return;
        } else {

        }
      } else {

      }
    } else {

    }
  } else {

  }
  if ((int )(*str)->type != 4) {
    if ((int )(*from)->type != 4) {
      repl_len = 0;
      f = (int )(*from)->value.lval;
      if (f < 0) {
        f = (*str)->value.str.len + f;
        if (f < 0) {
          f = 0;
        } else {

        }
      } else
      if (f > (*str)->value.str.len) {
        f = (*str)->value.str.len;
      } else {

      }
      if (l < 0) {
        l = ((*str)->value.str.len - f) + l;
        if (l < 0) {
          l = 0;
        } else {

        }
      } else {

      }
      if (f > (*str)->value.str.len) {
        goto _L___1;
      } else
      if (f < 0) {
        if (- f > (*str)->value.str.len) {
          _L___1: 
          while (1) {
            __z___1 = return_value;
            __z___1->value.lval = 0L;
            __z___1->type = (zend_uchar )3;
            break;
          }
          return;
        } else {
          goto _L___2;
        }
      } else
      _L___2: 
      if (l > (*str)->value.str.len) {
        l = (*str)->value.str.len;
      } else
      if (l < 0) {
        if (- l > (*str)->value.str.len) {
          l = (*str)->value.str.len;
        } else {

        }
      } else {

      }
      if (f + l > (*str)->value.str.len) {
        l = (*str)->value.str.len - f;
      } else {

      }
      if ((int )(*repl)->type == 4) {
        zend_hash_internal_pointer_reset_ex((*repl)->value.ht, & pos_repl);
        tmp___30 = zend_hash_get_current_data_ex((*repl)->value.ht,
                                                 (void **)(& tmp_repl),
                                                 & pos_repl);
        if (0 == (int )tmp___30) {
          if ((int )(*tmp_repl)->type != 6) {
            tmp___29 = zval_isref_p(*tmp_repl);
            if (! tmp___29) {
              while (1) {
                tmp___28 = zval_refcount_p(*tmp_repl);
                if (tmp___28 > 1U) {
                  zval_delref_p(*tmp_repl);
                  while (1) {
                    tmp___27 = _emalloc(sizeof(zval_gc_info ));
                    new_zv___7 = (zval *)tmp___27;
                    ((zval_gc_info *)new_zv___7)->u.buffered = (gc_root_buffer *)((void *)0);
                    break;
                  }
                  while (1) {
                    while (1) {
                      new_zv___7->value = (*tmp_repl)->value;
                      new_zv___7->type = (*tmp_repl)->type;
                      break;
                    }
                    zval_set_refcount_p(new_zv___7, (zend_uint )1);
                    zval_unset_isref_p(new_zv___7);
                    break;
                  }
                  *tmp_repl = new_zv___7;
                  _zval_copy_ctor(new_zv___7);
                } else {

                }
                break;
              }
            } else {

            }
            if ((int )(*tmp_repl)->type != 6) {
              _convert_to_string(*tmp_repl);
            } else {

            }
          } else {

          }
          repl_len = (*tmp_repl)->value.str.len;
        } else {

        }
      } else {
        repl_len = (*repl)->value.str.len;
      }
      result_len = ((*str)->value.str.len - l) + repl_len;
      tmp___31 = _emalloc((size_t )(result_len + 1));
      result = (char *)tmp___31;
      memcpy((void */* __restrict  */)result,
             (void const   */* __restrict  */)(*str)->value.str.val, (size_t )f);
      if (repl_len) {
        if ((int )(*repl)->type == 4) {
          tmp___32 = (*tmp_repl)->value.str.val;
        } else {
          tmp___32 = (*repl)->value.str.val;
        }
        memcpy((void */* __restrict  */)(result + f),
               (void const   */* __restrict  */)tmp___32, (size_t )repl_len);
      } else {

      }
      memcpy((void */* __restrict  */)((result + f) + repl_len),
             (void const   */* __restrict  */)(((*str)->value.str.val + f) + l),
             (size_t )(((*str)->value.str.len - f) - l));
      *(result + result_len) = (char )'\000';
      while (1) {
        __s___1 = (char const   *)result;
        __l___1 = result_len;
        __z___2 = return_value;
        __z___2->value.str.len = __l___1;
        __z___2->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s___1));
        __z___2->type = (zend_uchar )6;
        break;
      }
      return;
    } else {
      php_error_docref0((char const   *)((void *)0), 1 << 1L,
                        "Functionality of \'from\' and \'len\' as arrays is not implemented");
      while (1) {
        __s___2 = (char const   *)(*str)->value.str.val;
        __l___2 = (*str)->value.str.len;
        __z___3 = return_value;
        __z___3->value.str.len = __l___2;
        tmp___34 = _estrndup(__s___2, (unsigned int )__l___2);
        __z___3->value.str.val = (char *)tmp___34;
        __z___3->type = (zend_uchar )6;
        break;
      }
      return;
    }
  } else {
    _array_init(return_value, (uint )0);
    if ((int )(*from)->type == 4) {
      zend_hash_internal_pointer_reset_ex((*from)->value.ht, & pos_from);
    } else {

    }
    if (argc > 3) {
      if ((int )(*len)->type == 4) {
        zend_hash_internal_pointer_reset_ex((*len)->value.ht, & pos_len);
      } else {

      }
    } else {

    }
    if ((int )(*repl)->type == 4) {
      zend_hash_internal_pointer_reset_ex((*repl)->value.ht, & pos_repl);
    } else {

    }
    zend_hash_internal_pointer_reset_ex((*str)->value.ht, & pos_str);
    while (1) {
      tmp___53 = zend_hash_get_current_data_ex((*str)->value.ht,
                                               (void **)(& tmp_str), & pos_str);
      if (! (tmp___53 == (int __attribute__((__visibility__("default")))  )0)) {
        break;
      } else {

      }
      if ((int )(*tmp_str)->type != 6) {
        tmp___37 = zval_isref_p(*tmp_str);
        if (! tmp___37) {
          while (1) {
            tmp___36 = zval_refcount_p(*tmp_str);
            if (tmp___36 > 1U) {
              zval_delref_p(*tmp_str);
              while (1) {
                tmp___35 = _emalloc(sizeof(zval_gc_info ));
                new_zv___8 = (zval *)tmp___35;
                ((zval_gc_info *)new_zv___8)->u.buffered = (gc_root_buffer *)((void *)0);
                break;
              }
              while (1) {
                while (1) {
                  new_zv___8->value = (*tmp_str)->value;
                  new_zv___8->type = (*tmp_str)->type;
                  break;
                }
                zval_set_refcount_p(new_zv___8, (zend_uint )1);
                zval_unset_isref_p(new_zv___8);
                break;
              }
              *tmp_str = new_zv___8;
              _zval_copy_ctor(new_zv___8);
            } else {

            }
            break;
          }
        } else {

        }
        if ((int )(*tmp_str)->type != 6) {
          _convert_to_string(*tmp_str);
        } else {

        }
      } else {

      }
      if ((int )(*from)->type == 4) {
        tmp___41 = zend_hash_get_current_data_ex((*from)->value.ht,
                                                 (void **)(& tmp_from),
                                                 & pos_from);
        if (0 == (int )tmp___41) {
          if ((int )(*tmp_from)->type != 1) {
            tmp___40 = zval_isref_p(*tmp_from);
            if (! tmp___40) {
              while (1) {
                tmp___39 = zval_refcount_p(*tmp_from);
                if (tmp___39 > 1U) {
                  zval_delref_p(*tmp_from);
                  while (1) {
                    tmp___38 = _emalloc(sizeof(zval_gc_info ));
                    new_zv___9 = (zval *)tmp___38;
                    ((zval_gc_info *)new_zv___9)->u.buffered = (gc_root_buffer *)((void *)0);
                    break;
                  }
                  while (1) {
                    while (1) {
                      new_zv___9->value = (*tmp_from)->value;
                      new_zv___9->type = (*tmp_from)->type;
                      break;
                    }
                    zval_set_refcount_p(new_zv___9, (zend_uint )1);
                    zval_unset_isref_p(new_zv___9);
                    break;
                  }
                  *tmp_from = new_zv___9;
                  _zval_copy_ctor(new_zv___9);
                } else {

                }
                break;
              }
            } else {

            }
            convert_to_long(*tmp_from);
          } else {

          }
          f = (int )(*tmp_from)->value.lval;
          if (f < 0) {
            f = (*tmp_str)->value.str.len + f;
            if (f < 0) {
              f = 0;
            } else {

            }
          } else
          if (f > (*tmp_str)->value.str.len) {
            f = (*tmp_str)->value.str.len;
          } else {

          }
          zend_hash_move_forward_ex((*from)->value.ht, & pos_from);
        } else {
          f = 0;
        }
      } else {
        f = (int )(*from)->value.lval;
        if (f < 0) {
          f = (*tmp_str)->value.str.len + f;
          if (f < 0) {
            f = 0;
          } else {

          }
        } else
        if (f > (*tmp_str)->value.str.len) {
          f = (*tmp_str)->value.str.len;
        } else {

        }
      }
      if (argc > 3) {
        if ((int )(*len)->type == 4) {
          tmp___45 = zend_hash_get_current_data_ex((*len)->value.ht,
                                                   (void **)(& tmp_len),
                                                   & pos_len);
          if (0 == (int )tmp___45) {
            if ((int )(*tmp_len)->type != 1) {
              tmp___44 = zval_isref_p(*tmp_len);
              if (! tmp___44) {
                while (1) {
                  tmp___43 = zval_refcount_p(*tmp_len);
                  if (tmp___43 > 1U) {
                    zval_delref_p(*tmp_len);
                    while (1) {
                      tmp___42 = _emalloc(sizeof(zval_gc_info ));
                      new_zv___10 = (zval *)tmp___42;
                      ((zval_gc_info *)new_zv___10)->u.buffered = (gc_root_buffer *)((void *)0);
                      break;
                    }
                    while (1) {
                      while (1) {
                        new_zv___10->value = (*tmp_len)->value;
                        new_zv___10->type = (*tmp_len)->type;
                        break;
                      }
                      zval_set_refcount_p(new_zv___10, (zend_uint )1);
                      zval_unset_isref_p(new_zv___10);
                      break;
                    }
                    *tmp_len = new_zv___10;
                    _zval_copy_ctor(new_zv___10);
                  } else {

                  }
                  break;
                }
              } else {

              }
              convert_to_long(*tmp_len);
            } else {

            }
            l = (int )(*tmp_len)->value.lval;
            zend_hash_move_forward_ex((*len)->value.ht, & pos_len);
          } else {
            l = (*tmp_str)->value.str.len;
          }
        } else {
          goto _L___3;
        }
      } else
      _L___3: 
      if (argc > 3) {
        l = (int )(*len)->value.lval;
      } else {
        l = (*tmp_str)->value.str.len;
      }
      if (l < 0) {
        l = ((*tmp_str)->value.str.len - f) + l;
        if (l < 0) {
          l = 0;
        } else {

        }
      } else {

      }
      if (f + l > (*tmp_str)->value.str.len) {
        l = (*tmp_str)->value.str.len - f;
      } else {

      }
      result_len = (*tmp_str)->value.str.len - l;
      if ((int )(*repl)->type == 4) {
        tmp___51 = zend_hash_get_current_data_ex((*repl)->value.ht,
                                                 (void **)(& tmp_repl),
                                                 & pos_repl);
        if (0 == (int )tmp___51) {
          if ((int )(*tmp_repl)->type != 6) {
            tmp___48 = zval_isref_p(*tmp_repl);
            if (! tmp___48) {
              while (1) {
                tmp___47 = zval_refcount_p(*tmp_repl);
                if (tmp___47 > 1U) {
                  zval_delref_p(*tmp_repl);
                  while (1) {
                    tmp___46 = _emalloc(sizeof(zval_gc_info ));
                    new_zv___11 = (zval *)tmp___46;
                    ((zval_gc_info *)new_zv___11)->u.buffered = (gc_root_buffer *)((void *)0);
                    break;
                  }
                  while (1) {
                    while (1) {
                      new_zv___11->value = (*tmp_repl)->value;
                      new_zv___11->type = (*tmp_repl)->type;
                      break;
                    }
                    zval_set_refcount_p(new_zv___11, (zend_uint )1);
                    zval_unset_isref_p(new_zv___11);
                    break;
                  }
                  *tmp_repl = new_zv___11;
                  _zval_copy_ctor(new_zv___11);
                } else {

                }
                break;
              }
            } else {

            }
            if ((int )(*tmp_repl)->type != 6) {
              _convert_to_string(*tmp_repl);
            } else {

            }
          } else {

          }
          result_len += (*tmp_repl)->value.str.len;
          zend_hash_move_forward_ex((*repl)->value.ht, & pos_repl);
          tmp___49 = _emalloc((size_t )(result_len + 1));
          result = (char *)tmp___49;
          memcpy((void */* __restrict  */)result,
                 (void const   */* __restrict  */)(*tmp_str)->value.str.val,
                 (size_t )f);
          memcpy((void */* __restrict  */)(result + f),
                 (void const   */* __restrict  */)(*tmp_repl)->value.str.val,
                 (size_t )(*tmp_repl)->value.str.len);
          memcpy((void */* __restrict  */)((result + f) + (*tmp_repl)->value.str.len),
                 (void const   */* __restrict  */)(((*tmp_str)->value.str.val + f) + l),
                 (size_t )(((*tmp_str)->value.str.len - f) - l));
        } else {
          tmp___50 = _emalloc((size_t )(result_len + 1));
          result = (char *)tmp___50;
          memcpy((void */* __restrict  */)result,
                 (void const   */* __restrict  */)(*tmp_str)->value.str.val,
                 (size_t )f);
          memcpy((void */* __restrict  */)(result + f),
                 (void const   */* __restrict  */)(((*tmp_str)->value.str.val + f) + l),
                 (size_t )(((*tmp_str)->value.str.len - f) - l));
        }
      } else {
        result_len += (*repl)->value.str.len;
        tmp___52 = _emalloc((size_t )(result_len + 1));
        result = (char *)tmp___52;
        memcpy((void */* __restrict  */)result,
               (void const   */* __restrict  */)(*tmp_str)->value.str.val,
               (size_t )f);
        memcpy((void */* __restrict  */)(result + f),
               (void const   */* __restrict  */)(*repl)->value.str.val,
               (size_t )(*repl)->value.str.len);
        memcpy((void */* __restrict  */)((result + f) + (*repl)->value.str.len),
               (void const   */* __restrict  */)(((*tmp_str)->value.str.val + f) + l),
               (size_t )(((*tmp_str)->value.str.len - f) - l));
      }
      *(result + result_len) = (char )'\000';
      add_next_index_stringl(return_value, (char const   *)result,
                             (uint )result_len, 0);
      zend_hash_move_forward_ex((*str)->value.ht, & pos_str);
    }
  }
  return;
}
}
void zif_quotemeta(int ht , zval *return_value , zval **return_value_ptr ,
                   zval *this_ptr , int return_value_used ) 
{ 
  char *str ;
  char *old ;
  char *old_end ;
  char *p ;
  char *q ;
  char c ;
  int old_len ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  char *tmp___1 ;
  char *tmp___2 ;
  char const   *__s ;
  void __attribute__((__visibility__("default")))  *tmp___3 ;
  int __l ;
  zval *__z___0 ;

  {
  tmp = zend_parse_parameters(ht, "s", & old, & old_len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  old_end = old + old_len;
  if ((unsigned long )old == (unsigned long )old_end) {
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  tmp___0 = _safe_emalloc((size_t )2, (size_t )old_len, (size_t )1);
  str = (char *)tmp___0;
  p = old;
  q = str;
  while ((unsigned long )p != (unsigned long )old_end) {
    c = *p;
    switch ((int )c) {
    case 46: 
    case 92: 
    case 43: 
    case 42: 
    case 63: 
    case 91: 
    case 94: 
    case 93: 
    case 36: 
    case 40: 
    case 41: 
    tmp___1 = q;
    q ++;
    *tmp___1 = (char )'\\';
    default: 
    tmp___2 = q;
    q ++;
    *tmp___2 = c;
    }
    p ++;
  }
  *q = (char)0;
  while (1) {
    tmp___3 = _erealloc((void *)str, (size_t )((q - str) + 1L), 0);
    __s = (char const   *)tmp___3;
    __l = (int )(q - str);
    __z___0 = return_value;
    __z___0->value.str.len = __l;
    __z___0->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z___0->type = (zend_uchar )6;
    break;
  }
  return;
}
}
void zif_ord(int ht , zval *return_value , zval **return_value_ptr ,
             zval *this_ptr , int return_value_used ) 
{ 
  char *str ;
  int str_len ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;

  {
  tmp = zend_parse_parameters(ht, "s", & str, & str_len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  __z = return_value;
  __z->value.lval = (long )((unsigned char )*(str + 0));
  __z->type = (zend_uchar )1;
  return;
}
}
void zif_chr(int ht , zval *return_value , zval **return_value_ptr ,
             zval *this_ptr , int return_value_used ) 
{ 
  long c ;
  char temp[2] ;
  int __attribute__((__visibility__("default")))  tmp ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;

  {
  if (ht != 1) {
    zend_wrong_param_count();
    return;
  } else {

  }
  tmp = zend_parse_parameters_ex(1 << 1, ht, "l", & c);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    c = 0L;
  } else {

  }
  temp[0] = (char )c;
  temp[1] = (char )'\000';
  while (1) {
    __s = (char const   *)(temp);
    __l = 1;
    __z = return_value;
    __z->value.str.len = __l;
    tmp___0 = _estrndup(__s, (unsigned int )__l);
    __z->value.str.val = (char *)tmp___0;
    __z->type = (zend_uchar )6;
    break;
  }
  return;
}
}
static void php_ucfirst(char *str ) 
{ 
  register char *r ;
  int __res ;
  int __attribute__((__gnu_inline__))  tmp___0 ;
  __int32_t const   **tmp___1 ;

  {
  r = str;
  if (sizeof((unsigned char )*r) > 1UL) {
    tmp___0 = toupper((int )((unsigned char )*r));
    __res = (int )tmp___0;
  } else {
    tmp___1 = __ctype_toupper_loc();
    __res = (int )*(*tmp___1 + (int )((unsigned char )*r));
  }
  *r = (char )__res;
  return;
}
}
void zif_ucfirst(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) 
{ 
  char *str ;
  int str_len ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  char const   *__s ;
  int __l ;
  zval *__z___0 ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;

  {
  tmp = zend_parse_parameters(ht, "s", & str, & str_len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (! str_len) {
    while (1) {
      __z = return_value;
      __z->value.str.len = 0;
      tmp___0 = _estrndup("", (unsigned int )(sizeof("") - 1UL));
      __z->value.str.val = (char *)tmp___0;
      __z->type = (zend_uchar )6;
      break;
    }
    return;
  } else {

  }
  while (1) {
    __s = (char const   *)str;
    __l = str_len;
    __z___0 = return_value;
    __z___0->value.str.len = __l;
    tmp___1 = _estrndup(__s, (unsigned int )__l);
    __z___0->value.str.val = (char *)tmp___1;
    __z___0->type = (zend_uchar )6;
    break;
  }
  php_ucfirst(return_value->value.str.val);
  return;
}
}
static void php_lcfirst(char *str ) 
{ 
  register char *r ;
  int __res ;
  int __attribute__((__gnu_inline__))  tmp___0 ;
  __int32_t const   **tmp___1 ;

  {
  r = str;
  if (sizeof((unsigned char )*r) > 1UL) {
    tmp___0 = tolower((int )((unsigned char )*r));
    __res = (int )tmp___0;
  } else {
    tmp___1 = __ctype_tolower_loc();
    __res = (int )*(*tmp___1 + (int )((unsigned char )*r));
  }
  *r = (char )__res;
  return;
}
}
void zif_lcfirst(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) 
{ 
  char *str ;
  int str_len ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  char const   *__s ;
  int __l ;
  zval *__z___0 ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;

  {
  tmp = zend_parse_parameters(ht, "s", & str, & str_len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (! str_len) {
    while (1) {
      __z = return_value;
      __z->value.str.len = 0;
      tmp___0 = _estrndup("", (unsigned int )(sizeof("") - 1UL));
      __z->value.str.val = (char *)tmp___0;
      __z->type = (zend_uchar )6;
      break;
    }
    return;
  } else {

  }
  while (1) {
    __s = (char const   *)str;
    __l = str_len;
    __z___0 = return_value;
    __z___0->value.str.len = __l;
    tmp___1 = _estrndup(__s, (unsigned int )__l);
    __z___0->value.str.val = (char *)tmp___1;
    __z___0->type = (zend_uchar )6;
    break;
  }
  php_lcfirst(return_value->value.str.val);
  return;
}
}
void zif_ucwords(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) 
{ 
  char *str ;
  register char *r ;
  register char *r_end ;
  int str_len ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  char const   *__s ;
  int __l ;
  zval *__z___0 ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  int __res ;
  int __attribute__((__gnu_inline__))  tmp___3 ;
  __int32_t const   **tmp___4 ;
  int __res___0 ;
  int __attribute__((__gnu_inline__))  tmp___6 ;
  __int32_t const   **tmp___7 ;
  unsigned short const   **tmp___8 ;
  char *tmp___9 ;

  {
  tmp = zend_parse_parameters(ht, "s", & str, & str_len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (! str_len) {
    while (1) {
      __z = return_value;
      __z->value.str.len = 0;
      tmp___0 = _estrndup("", (unsigned int )(sizeof("") - 1UL));
      __z->value.str.val = (char *)tmp___0;
      __z->type = (zend_uchar )6;
      break;
    }
    return;
  } else {

  }
  while (1) {
    __s = (char const   *)str;
    __l = str_len;
    __z___0 = return_value;
    __z___0->value.str.len = __l;
    tmp___1 = _estrndup(__s, (unsigned int )__l);
    __z___0->value.str.val = (char *)tmp___1;
    __z___0->type = (zend_uchar )6;
    break;
  }
  r = return_value->value.str.val;
  if (sizeof((unsigned char )*r) > 1UL) {
    tmp___3 = toupper((int )((unsigned char )*r));
    __res = (int )tmp___3;
  } else {
    tmp___4 = __ctype_toupper_loc();
    __res = (int )*(*tmp___4 + (int )((unsigned char )*r));
  }
  *r = (char )__res;
  r_end = (r + return_value->value.str.len) - 1;
  while ((unsigned long )r < (unsigned long )r_end) {
    tmp___8 = __ctype_b_loc();
    tmp___9 = r;
    r ++;
    if ((int const   )*(*tmp___8 + (int )*((unsigned char *)tmp___9)) & 8192) {
      if (sizeof((unsigned char )*r) > 1UL) {
        tmp___6 = toupper((int )((unsigned char )*r));
        __res___0 = (int )tmp___6;
      } else {
        tmp___7 = __ctype_toupper_loc();
        __res___0 = (int )*(*tmp___7 + (int )((unsigned char )*r));
      }
      *r = (char )__res___0;
    } else {

    }
  }
  return;
}
}
char __attribute__((__visibility__("default")))  *php_strtr(char *str ,
                                                            int len ,
                                                            char *str_from ,
                                                            char *str_to ,
                                                            int trlen ) 
{ 
  int i ;
  unsigned char xlat[256] ;

  {
  if (trlen < 1) {
    return ((char __attribute__((__visibility__("default")))  *)str);
  } else
  if (len < 1) {
    return ((char __attribute__((__visibility__("default")))  *)str);
  } else {

  }
  i = 0;
  while (i < 256) {
    xlat[i] = (unsigned char )i;
    i ++;
  }
  i = 0;
  while (i < trlen) {
    xlat[(unsigned char )*(str_from + i)] = (unsigned char )*(str_to + i);
    i ++;
  }
  i = 0;
  while (i < len) {
    *(str + i) = (char )xlat[(unsigned char )*(str + i)];
    i ++;
  }
  return ((char __attribute__((__visibility__("default")))  *)str);
}
}
static void php_strtr_array(zval *return_value , char *str , int slen ,
                            HashTable *hash ) 
{ 
  zval **entry ;
  char *string_key ;
  uint string_key_len ;
  zval **trans ;
  zval ctmp ;
  ulong num_key ;
  int minlen ;
  int maxlen ;
  int pos ;
  int len ;
  int found ;
  char *key ;
  HashPosition hpos ;
  smart_str result ;
  HashTable tmp_hash ;
  int __attribute__((__visibility__("default")))  tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z ;
  int __attribute__((__visibility__("default")))  tmp___1 ;
  void __attribute__((__visibility__("default")))  *tmp___2 ;
  char *tval ;
  int tlen ;
  zval tmp___3 ;
  register size_t __nl ;
  smart_str *__dest ;
  void __attribute__((__visibility__("default")))  *tmp___5 ;
  void __attribute__((__visibility__("default")))  *tmp___7 ;
  int __attribute__((__visibility__("default")))  tmp___8 ;
  register size_t __nl___0 ;
  void __attribute__((__visibility__("default")))  *tmp___10 ;
  void __attribute__((__visibility__("default")))  *tmp___12 ;
  int tmp___13 ;
  char const   *__s ;
  int __l ;
  zval *__z___0 ;

  {
  minlen = 131072;
  maxlen = 0;
  result.c = (char *)0;
  result.len = 0UL;
  result.a = 0UL;
  tmp = zend_hash_num_elements((HashTable const   *)hash);
  _zend_hash_init(& tmp_hash, (uint )tmp,
                  (ulong (*)(char const   *arKey , uint nKeyLength ))((void *)0),
                  (void (*)(void *pDest ))((void *)0), (zend_bool )0);
  zend_hash_internal_pointer_reset_ex(hash, & hpos);
  while (1) {
    tmp___1 = zend_hash_get_current_data_ex(hash, (void **)(& entry), & hpos);
    if (! (tmp___1 == (int __attribute__((__visibility__("default")))  )0)) {
      break;
    } else {

    }
    tmp___0 = zend_hash_get_current_key_ex((HashTable const   *)hash,
                                           & string_key, & string_key_len,
                                           & num_key, (zend_bool )0, & hpos);
    switch (tmp___0) {
    case (int __attribute__((__visibility__("default")))  )1: 
    len = (int )(string_key_len - 1U);
    if (len < 1) {
      zend_hash_destroy(& tmp_hash);
      while (1) {
        __z = return_value;
        __z->value.lval = 0L;
        __z->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    _zend_hash_add_or_update(& tmp_hash, (char const   *)string_key,
                             string_key_len, (void *)entry,
                             (uint )sizeof(zval *), (void **)((void *)0), 1 << 1);
    if (len > maxlen) {
      maxlen = len;
    } else {

    }
    if (len < minlen) {
      minlen = len;
    } else {

    }
    break;
    case (int __attribute__((__visibility__("default")))  )2: 
    ctmp.type = (zend_uchar )1;
    ctmp.value.lval = (long )num_key;
    if ((int )ctmp.type != 6) {
      _convert_to_string(& ctmp);
    } else {

    }
    len = ctmp.value.str.len;
    _zend_hash_add_or_update(& tmp_hash, (char const   *)ctmp.value.str.val,
                             (uint )(len + 1), (void *)entry,
                             (uint )sizeof(zval *), (void **)((void *)0), 1 << 1);
    _zval_dtor(& ctmp);
    if (len > maxlen) {
      maxlen = len;
    } else {

    }
    if (len < minlen) {
      minlen = len;
    } else {

    }
    break;
    }
    zend_hash_move_forward_ex(hash, & hpos);
  }
  tmp___2 = _emalloc((size_t )(maxlen + 1));
  key = (char *)tmp___2;
  pos = 0;
  while (pos < slen) {
    if (pos + maxlen > slen) {
      maxlen = slen - pos;
    } else {

    }
    found = 0;
    memcpy((void */* __restrict  */)key,
           (void const   */* __restrict  */)(str + pos), (size_t )maxlen);
    len = maxlen;
    while (len >= minlen) {
      *(key + len) = (char)0;
      tmp___8 = zend_hash_find((HashTable const   *)(& tmp_hash),
                               (char const   *)key, (uint )(len + 1),
                               (void **)(& trans));
      if (tmp___8 == (int __attribute__((__visibility__("default")))  )0) {
        if ((int )(*trans)->type != 6) {
          tmp___3 = *(*trans);
          _zval_copy_ctor(& tmp___3);
          if ((int )tmp___3.type != 6) {
            _convert_to_string(& tmp___3);
          } else {

          }
          tval = tmp___3.value.str.val;
          tlen = tmp___3.value.str.len;
        } else {
          tval = (*trans)->value.str.val;
          tlen = (*trans)->value.str.len;
        }
        while (1) {
          __dest = & result;
          while (1) {
            if (! __dest->c) {
              __dest->len = (size_t )0;
              __nl = (size_t )tlen;
              if (__nl < 78UL) {
                __dest->a = (size_t )78;
              } else {
                __dest->a = __nl + 128UL;
              }
              tmp___5 = _erealloc((void *)__dest->c, __dest->a + 1UL, 0);
              __dest->c = (char *)((void *)tmp___5);
            } else {
              __nl = __dest->len + (size_t )tlen;
              if (__nl >= __dest->a) {
                __dest->a = __nl + 128UL;
                tmp___7 = _erealloc((void *)__dest->c, __dest->a + 1UL, 0);
                __dest->c = (char *)((void *)tmp___7);
              } else {

              }
            }
            break;
          }
          memcpy((void */* __restrict  */)(__dest->c + __dest->len),
                 (void const   */* __restrict  */)tval, (size_t )tlen);
          __dest->len = __nl;
          break;
        }
        pos += len;
        found = 1;
        if ((int )(*trans)->type != 6) {
          _zval_dtor(& tmp___3);
        } else {

        }
        break;
      } else {

      }
      len --;
    }
    if (! found) {
      while (1) {
        while (1) {
          if (! result.c) {
            result.len = (size_t )0;
            __nl___0 = (size_t )1;
            if (__nl___0 < 78UL) {
              result.a = (size_t )78;
            } else {
              result.a = __nl___0 + 128UL;
            }
            tmp___10 = _erealloc((void *)result.c, result.a + 1UL, 0);
            result.c = (char *)((void *)tmp___10);
          } else {
            __nl___0 = result.len + 1UL;
            if (__nl___0 >= result.a) {
              result.a = __nl___0 + 128UL;
              tmp___12 = _erealloc((void *)result.c, result.a + 1UL, 0);
              result.c = (char *)((void *)tmp___12);
            } else {

            }
          }
          break;
        }
        result.len = __nl___0;
        tmp___13 = pos;
        pos ++;
        *((unsigned char *)result.c + (result.len - 1UL)) = (unsigned char )*(str + tmp___13);
        break;
      }
    } else {

    }
  }
  _efree((void *)key);
  zend_hash_destroy(& tmp_hash);
  while (1) {
    if (result.c) {
      *(result.c + result.len) = (char )'\000';
    } else {

    }
    break;
  }
  while (1) {
    __s = (char const   *)result.c;
    __l = (int )result.len;
    __z___0 = return_value;
    __z___0->value.str.len = __l;
    __z___0->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z___0->type = (zend_uchar )6;
    break;
  }
  return;
}
}
void zif_strtr(int ht , zval *return_value , zval **return_value_ptr ,
               zval *this_ptr , int return_value_used ) 
{ 
  zval **from ;
  char *str ;
  char *to ;
  int str_len ;
  int to_len ;
  int ac ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  zval *__z___0 ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  HashTable *tmp___1 ;
  HashTable *tmp___2 ;
  HashTable *tmp___3 ;
  zval *new_zv ;
  void __attribute__((__visibility__("default")))  *tmp___4 ;
  zend_uint tmp___5 ;
  zend_bool tmp___6 ;
  char const   *__s ;
  int __l ;
  zval *__z___1 ;
  char __attribute__((__visibility__("default")))  *tmp___7 ;
  int tmp___8 ;

  {
  to = (char *)((void *)0);
  to_len = 0;
  ac = ht;
  tmp = zend_parse_parameters(ht, "sZ|s", & str, & str_len, & from, & to,
                              & to_len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (ac == 2) {
    if ((int )(*from)->type != 4) {
      php_error_docref0((char const   *)((void *)0), 1 << 1L,
                        "The second argument is not an array");
      while (1) {
        __z = return_value;
        __z->value.lval = 0L;
        __z->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
  } else {

  }
  if (str_len == 0) {
    while (1) {
      __z___0 = return_value;
      __z___0->value.str.len = 0;
      tmp___0 = _estrndup("", (unsigned int )(sizeof("") - 1UL));
      __z___0->value.str.val = (char *)tmp___0;
      __z___0->type = (zend_uchar )6;
      break;
    }
    return;
  } else {

  }
  if (ac == 2) {
    if ((int )(*from)->type == 4) {
      tmp___3 = (*from)->value.ht;
    } else {
      if ((int )(*from)->type == 5) {
        tmp___1 = (*(((*from)->value.obj.handlers)->get_properties))(*from);
        tmp___2 = tmp___1;
      } else {
        tmp___2 = (HashTable *)((void *)0);
      }
      tmp___3 = tmp___2;
    }
    php_strtr_array(return_value, str, str_len, tmp___3);
  } else {
    if ((int )(*from)->type != 6) {
      tmp___6 = zval_isref_p(*from);
      if (! tmp___6) {
        while (1) {
          tmp___5 = zval_refcount_p(*from);
          if (tmp___5 > 1U) {
            zval_delref_p(*from);
            while (1) {
              tmp___4 = _emalloc(sizeof(zval_gc_info ));
              new_zv = (zval *)tmp___4;
              ((zval_gc_info *)new_zv)->u.buffered = (gc_root_buffer *)((void *)0);
              break;
            }
            while (1) {
              while (1) {
                new_zv->value = (*from)->value;
                new_zv->type = (*from)->type;
                break;
              }
              zval_set_refcount_p(new_zv, (zend_uint )1);
              zval_unset_isref_p(new_zv);
              break;
            }
            *from = new_zv;
            _zval_copy_ctor(new_zv);
          } else {

          }
          break;
        }
      } else {

      }
      if ((int )(*from)->type != 6) {
        _convert_to_string(*from);
      } else {

      }
    } else {

    }
    while (1) {
      __s = (char const   *)str;
      __l = str_len;
      __z___1 = return_value;
      __z___1->value.str.len = __l;
      tmp___7 = _estrndup(__s, (unsigned int )__l);
      __z___1->value.str.val = (char *)tmp___7;
      __z___1->type = (zend_uchar )6;
      break;
    }
    if ((*from)->value.str.len < to_len) {
      tmp___8 = (*from)->value.str.len;
    } else {
      tmp___8 = to_len;
    }
    php_strtr(return_value->value.str.val, return_value->value.str.len,
              (*from)->value.str.val, to, tmp___8);
  }
  return;
}
}
void zif_strrev(int ht , zval *return_value , zval **return_value_ptr ,
                zval *this_ptr , int return_value_used ) 
{ 
  char *str ;
  char *e ;
  char *n ;
  char *p ;
  int str_len ;
  int __attribute__((__visibility__("default")))  tmp ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  char *tmp___1 ;
  char const   *__s ;
  int __l ;
  zval *__z ;

  {
  tmp = zend_parse_parameters(ht, "s", & str, & str_len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  tmp___0 = _emalloc((size_t )(str_len + 1));
  n = (char *)tmp___0;
  p = n;
  e = str + str_len;
  while (1) {
    e --;
    if (! ((unsigned long )e >= (unsigned long )str)) {
      break;
    } else {

    }
    tmp___1 = p;
    p ++;
    *tmp___1 = *e;
  }
  *p = (char )'\000';
  while (1) {
    __s = (char const   *)n;
    __l = str_len;
    __z = return_value;
    __z->value.str.len = __l;
    __z->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z->type = (zend_uchar )6;
    break;
  }
  return;
}
}
static void php_similar_str(char const   *txt1 , int len1 , char const   *txt2 ,
                            int len2 , int *pos1 , int *pos2 , int *max ) 
{ 
  char *p ;
  char *q ;
  char *end1 ;
  char *end2 ;
  int l ;

  {
  end1 = (char *)txt1 + len1;
  end2 = (char *)txt2 + len2;
  *max = 0;
  p = (char *)txt1;
  while ((unsigned long )p < (unsigned long )end1) {
    q = (char *)txt2;
    while ((unsigned long )q < (unsigned long )end2) {
      l = 0;
      while (1) {
        if ((unsigned long )(p + l) < (unsigned long )end1) {
          if ((unsigned long )(q + l) < (unsigned long )end2) {
            if (! ((int )*(p + l) == (int )*(q + l))) {
              break;
            } else {

            }
          } else {
            break;
          }
        } else {
          break;
        }
        l ++;
      }
      if (l > *max) {
        *max = l;
        *pos1 = (int )(p - (char *)txt1);
        *pos2 = (int )(q - (char *)txt2);
      } else {

      }
      q ++;
    }
    p ++;
  }
  return;
}
}
static int php_similar_char(char const   *txt1 , int len1 , char const   *txt2 ,
                            int len2 ) 
{ 
  int sum ;
  int pos1 ;
  int pos2 ;
  int max ;
  int tmp ;
  int tmp___0 ;

  {
  php_similar_str(txt1, len1, txt2, len2, & pos1, & pos2, & max);
  sum = max;
  if (sum) {
    if (pos1) {
      if (pos2) {
        tmp = php_similar_char(txt1, pos1, txt2, pos2);
        sum += tmp;
      } else {

      }
    } else {

    }
    if (pos1 + max < len1) {
      if (pos2 + max < len2) {
        tmp___0 = php_similar_char((txt1 + pos1) + max, (len1 - pos1) - max,
                                   (txt2 + pos2) + max, (len2 - pos2) - max);
        sum += tmp___0;
      } else {

      }
    } else {

    }
  } else {

  }
  return (sum);
}
}
void zif_similar_text(int ht , zval *return_value , zval **return_value_ptr ,
                      zval *this_ptr , int return_value_used ) 
{ 
  char *t1 ;
  char *t2 ;
  zval **percent ;
  int ac ;
  int sim ;
  int t1_len ;
  int t2_len ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *new_zv ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  zend_uint tmp___1 ;
  zend_bool tmp___2 ;
  zval *__z ;
  zval *__z___0 ;

  {
  percent = (zval **)((void *)0);
  ac = ht;
  tmp = zend_parse_parameters(ht, "ss|Z", & t1, & t1_len, & t2, & t2_len,
                              & percent);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (ac > 2) {
    if ((int )(*percent)->type != 2) {
      tmp___2 = zval_isref_p(*percent);
      if (! tmp___2) {
        while (1) {
          tmp___1 = zval_refcount_p(*percent);
          if (tmp___1 > 1U) {
            zval_delref_p(*percent);
            while (1) {
              tmp___0 = _emalloc(sizeof(zval_gc_info ));
              new_zv = (zval *)tmp___0;
              ((zval_gc_info *)new_zv)->u.buffered = (gc_root_buffer *)((void *)0);
              break;
            }
            while (1) {
              while (1) {
                new_zv->value = (*percent)->value;
                new_zv->type = (*percent)->type;
                break;
              }
              zval_set_refcount_p(new_zv, (zend_uint )1);
              zval_unset_isref_p(new_zv);
              break;
            }
            *percent = new_zv;
            _zval_copy_ctor(new_zv);
          } else {

          }
          break;
        }
      } else {

      }
      convert_to_double(*percent);
    } else {

    }
  } else {

  }
  if (t1_len + t2_len == 0) {
    if (ac > 2) {
      (*percent)->value.dval = (double )0;
    } else {

    }
    __z = return_value;
    __z->value.lval = 0L;
    __z->type = (zend_uchar )1;
    return;
  } else {

  }
  sim = php_similar_char((char const   *)t1, t1_len, (char const   *)t2, t2_len);
  if (ac > 2) {
    (*percent)->value.dval = ((double )sim * 200.0) / (double )(t1_len + t2_len);
  } else {

  }
  __z___0 = return_value;
  __z___0->value.lval = (long )sim;
  __z___0->type = (zend_uchar )1;
  return;
}
}
void __attribute__((__visibility__("default")))  php_stripslashes(char *str ,
                                                                  int *len ) 
{ 
  char *s ;
  char *t ;
  int l ;
  size_t tmp ;
  char *tmp___0 ;
  char *tmp___1 ;
  char *tmp___2 ;
  char *tmp___3 ;
  char *tmp___4 ;
  char *tmp___5 ;
  char *tmp___6 ;
  char *tmp___7 ;
  char *tmp___8 ;
  char *tmp___9 ;

  {
  if ((unsigned long )len != (unsigned long )((void *)0)) {
    l = *len;
  } else {
    tmp = strlen((char const   *)str);
    l = (int )tmp;
  }
  s = str;
  t = str;
  if (core_globals.magic_quotes_sybase) {
    while (l > 0) {
      if ((int )*t == 39) {
        if (l > 0) {
          if ((int )*(t + 1) == 39) {
            t ++;
            if ((unsigned long )len != (unsigned long )((void *)0)) {
              (*len) --;
            } else {

            }
            l --;
          } else {

          }
        } else {

        }
        tmp___0 = s;
        s ++;
        tmp___1 = t;
        t ++;
        *tmp___0 = *tmp___1;
      } else
      if ((int )*t == 92) {
        if ((int )*(t + 1) == 48) {
          if (l > 0) {
            tmp___2 = s;
            s ++;
            *tmp___2 = (char )'\000';
            t += 2;
            if ((unsigned long )len != (unsigned long )((void *)0)) {
              (*len) --;
            } else {

            }
            l --;
          } else {
            tmp___3 = s;
            s ++;
            tmp___4 = t;
            t ++;
            *tmp___3 = *tmp___4;
          }
        } else {
          tmp___3 = s;
          s ++;
          tmp___4 = t;
          t ++;
          *tmp___3 = *tmp___4;
        }
      } else {
        tmp___3 = s;
        s ++;
        tmp___4 = t;
        t ++;
        *tmp___3 = *tmp___4;
      }
      l --;
    }
    *s = (char )'\000';
    return;
  } else {

  }
  while (l > 0) {
    if ((int )*t == 92) {
      t ++;
      if ((unsigned long )len != (unsigned long )((void *)0)) {
        (*len) --;
      } else {

      }
      l --;
      if (l > 0) {
        if ((int )*t == 48) {
          tmp___5 = s;
          s ++;
          *tmp___5 = (char )'\000';
          t ++;
        } else {
          tmp___6 = s;
          s ++;
          tmp___7 = t;
          t ++;
          *tmp___6 = *tmp___7;
        }
        l --;
      } else {

      }
    } else {
      tmp___8 = s;
      s ++;
      tmp___9 = t;
      t ++;
      *tmp___8 = *tmp___9;
      l --;
    }
  }
  if ((unsigned long )s != (unsigned long )t) {
    *s = (char )'\000';
  } else {

  }
  return;
}
}
void zif_addcslashes(int ht , zval *return_value , zval **return_value_ptr ,
                     zval *this_ptr , int return_value_used ) 
{ 
  char *str ;
  char *what ;
  int str_len ;
  int what_len ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  char const   *__s ;
  int __l ;
  zval *__z___0 ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;
  char const   *__s___0 ;
  int __l___0 ;
  zval *__z___1 ;

  {
  tmp = zend_parse_parameters(ht, "ss", & str, & str_len, & what, & what_len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (str_len == 0) {
    while (1) {
      __z = return_value;
      __z->value.str.len = 0;
      tmp___0 = _estrndup("", (unsigned int )(sizeof("") - 1UL));
      __z->value.str.val = (char *)tmp___0;
      __z->type = (zend_uchar )6;
      break;
    }
    return;
  } else {

  }
  if (what_len == 0) {
    while (1) {
      __s = (char const   *)str;
      __l = str_len;
      __z___0 = return_value;
      __z___0->value.str.len = __l;
      tmp___1 = _estrndup(__s, (unsigned int )__l);
      __z___0->value.str.val = (char *)tmp___1;
      __z___0->type = (zend_uchar )6;
      break;
    }
    return;
  } else {

  }
  tmp___2 = php_addcslashes(str, str_len, & return_value->value.str.len, 0,
                            what, what_len);
  return_value->value.str.val = (char *)tmp___2;
  while (1) {
    __s___0 = (char const   *)return_value->value.str.val;
    __l___0 = return_value->value.str.len;
    __z___1 = return_value;
    __z___1->value.str.len = __l___0;
    __z___1->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s___0));
    __z___1->type = (zend_uchar )6;
    break;
  }
  return;
}
}
void zif_addslashes(int ht , zval *return_value , zval **return_value_ptr ,
                    zval *this_ptr , int return_value_used ) 
{ 
  char *str ;
  int str_len ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  char const   *__s ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  zval *__z___0 ;
  size_t tmp___2 ;

  {
  tmp = zend_parse_parameters(ht, "s", & str, & str_len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (str_len == 0) {
    while (1) {
      __z = return_value;
      __z->value.str.len = 0;
      tmp___0 = _estrndup("", (unsigned int )(sizeof("") - 1UL));
      __z->value.str.val = (char *)tmp___0;
      __z->type = (zend_uchar )6;
      break;
    }
    return;
  } else {

  }
  while (1) {
    tmp___1 = php_addslashes(str, str_len, & return_value->value.str.len, 0);
    __s = (char const   *)tmp___1;
    __z___0 = return_value;
    tmp___2 = strlen(__s);
    __z___0->value.str.len = (int )tmp___2;
    __z___0->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z___0->type = (zend_uchar )6;
    break;
  }
  return;
}
}
void zif_stripcslashes(int ht , zval *return_value , zval **return_value_ptr ,
                       zval *this_ptr , int return_value_used ) 
{ 
  char *str ;
  int str_len ;
  int __attribute__((__visibility__("default")))  tmp ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;

  {
  tmp = zend_parse_parameters(ht, "s", & str, & str_len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  while (1) {
    __s = (char const   *)str;
    __l = str_len;
    __z = return_value;
    __z->value.str.len = __l;
    tmp___0 = _estrndup(__s, (unsigned int )__l);
    __z->value.str.val = (char *)tmp___0;
    __z->type = (zend_uchar )6;
    break;
  }
  php_stripcslashes(return_value->value.str.val, & return_value->value.str.len);
  return;
}
}
void zif_stripslashes(int ht , zval *return_value , zval **return_value_ptr ,
                      zval *this_ptr , int return_value_used ) 
{ 
  char *str ;
  int str_len ;
  int __attribute__((__visibility__("default")))  tmp ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;

  {
  tmp = zend_parse_parameters(ht, "s", & str, & str_len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  while (1) {
    __s = (char const   *)str;
    __l = str_len;
    __z = return_value;
    __z->value.str.len = __l;
    tmp___0 = _estrndup(__s, (unsigned int )__l);
    __z->value.str.val = (char *)tmp___0;
    __z->type = (zend_uchar )6;
    break;
  }
  php_stripslashes(return_value->value.str.val, & return_value->value.str.len);
  return;
}
}
void __attribute__((__visibility__("default")))  php_stripcslashes(char *str ,
                                                                   int *len ) 
{ 
  char *source ;
  char *target ;
  char *end ;
  int nlen ;
  int i ;
  char numtmp[4] ;
  char *tmp ;
  char *tmp___0 ;
  char *tmp___1 ;
  char *tmp___2 ;
  char *tmp___3 ;
  char *tmp___4 ;
  char *tmp___5 ;
  char *tmp___6 ;
  unsigned short const   **tmp___7 ;
  char *tmp___8 ;
  long tmp___9 ;
  unsigned short const   **tmp___10 ;
  int tmp___11 ;
  char *tmp___12 ;
  char *tmp___13 ;
  long tmp___14 ;
  char *tmp___15 ;
  char *tmp___16 ;

  {
  nlen = *len;
  source = str;
  end = str + nlen;
  target = str;
  while ((unsigned long )source < (unsigned long )end) {
    if ((int )*source == 92) {
      if ((unsigned long )(source + 1) < (unsigned long )end) {
        source ++;
        switch ((int )*source) {
        case 110: 
        tmp = target;
        target ++;
        *tmp = (char )'\n';
        nlen --;
        break;
        case 114: 
        tmp___0 = target;
        target ++;
        *tmp___0 = (char )'\r';
        nlen --;
        break;
        case 97: 
        tmp___1 = target;
        target ++;
        *tmp___1 = (char )'\a';
        nlen --;
        break;
        case 116: 
        tmp___2 = target;
        target ++;
        *tmp___2 = (char )'\t';
        nlen --;
        break;
        case 118: 
        tmp___3 = target;
        target ++;
        *tmp___3 = (char )'\v';
        nlen --;
        break;
        case 98: 
        tmp___4 = target;
        target ++;
        *tmp___4 = (char )'\b';
        nlen --;
        break;
        case 102: 
        tmp___5 = target;
        target ++;
        *tmp___5 = (char )'\f';
        nlen --;
        break;
        case 92: 
        tmp___6 = target;
        target ++;
        *tmp___6 = (char )'\\';
        nlen --;
        break;
        case 120: 
        if ((unsigned long )(source + 1) < (unsigned long )end) {
          tmp___10 = __ctype_b_loc();
          if ((int const   )*(*tmp___10 + (int )*(source + 1)) & 4096) {
            source ++;
            numtmp[0] = *source;
            if ((unsigned long )(source + 1) < (unsigned long )end) {
              tmp___7 = __ctype_b_loc();
              if ((int const   )*(*tmp___7 + (int )*(source + 1)) & 4096) {
                source ++;
                numtmp[1] = *source;
                numtmp[2] = (char )'\000';
                nlen -= 3;
              } else {
                numtmp[1] = (char )'\000';
                nlen -= 2;
              }
            } else {
              numtmp[1] = (char )'\000';
              nlen -= 2;
            }
            tmp___8 = target;
            target ++;
            tmp___9 = strtol((char const   */* __restrict  */)(numtmp),
                             (char **/* __restrict  */)((void *)0), 16);
            *tmp___8 = (char )tmp___9;
            break;
          } else {

          }
        } else {

        }
        default: 
        i = 0;
        while (1) {
          if ((unsigned long )source < (unsigned long )end) {
            if ((int )*source >= 48) {
              if ((int )*source <= 55) {
                if (! (i < 3)) {
                  break;
                } else {

                }
              } else {
                break;
              }
            } else {
              break;
            }
          } else {
            break;
          }
          tmp___11 = i;
          i ++;
          tmp___12 = source;
          source ++;
          numtmp[tmp___11] = *tmp___12;
        }
        if (i) {
          numtmp[i] = (char )'\000';
          tmp___13 = target;
          target ++;
          tmp___14 = strtol((char const   */* __restrict  */)(numtmp),
                            (char **/* __restrict  */)((void *)0), 8);
          *tmp___13 = (char )tmp___14;
          nlen -= i;
          source --;
        } else {
          tmp___15 = target;
          target ++;
          *tmp___15 = *source;
          nlen --;
        }
        }
      } else {
        tmp___16 = target;
        target ++;
        *tmp___16 = *source;
      }
    } else {
      tmp___16 = target;
      target ++;
      *tmp___16 = *source;
    }
    source ++;
  }
  if (nlen != 0) {
    *target = (char )'\000';
  } else {

  }
  *len = nlen;
  return;
}
}
char __attribute__((__visibility__("default")))  *php_addcslashes(char *str ,
                                                                  int length ,
                                                                  int *new_length ,
                                                                  int should_free ,
                                                                  char *what ,
                                                                  int wlength ) 
{ 
  char flags[256] ;
  char *new_str ;
  size_t tmp ;
  int tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  char *source ;
  char *target ;
  char *end ;
  char c ;
  int newlen ;
  size_t tmp___2 ;
  char *tmp___3 ;
  char *tmp___4 ;
  char *tmp___5 ;
  char *tmp___6 ;
  char *tmp___7 ;
  char *tmp___8 ;
  char *tmp___9 ;
  char *tmp___10 ;
  int __attribute__((__visibility__("default")))  tmp___11 ;
  char *tmp___12 ;
  char *tmp___13 ;
  void __attribute__((__visibility__("default")))  *tmp___14 ;

  {
  if (length) {
    tmp___0 = length;
  } else {
    tmp = strlen((char const   *)str);
    length = (int )tmp;
    tmp___0 = length;
  }
  tmp___1 = _safe_emalloc((size_t )4, (size_t )tmp___0, (size_t )1);
  new_str = (char *)tmp___1;
  if (! wlength) {
    tmp___2 = strlen((char const   *)what);
    wlength = (int )tmp___2;
  } else {

  }
  php_charmask((unsigned char *)what, wlength, flags);
  source = str;
  end = source + length;
  target = new_str;
  while ((unsigned long )source < (unsigned long )end) {
    c = *source;
    if (flags[(unsigned char )c]) {
      if ((int )((unsigned char )c) < 32) {
        goto _L;
      } else
      if ((int )((unsigned char )c) > 126) {
        _L: 
        tmp___3 = target;
        target ++;
        *tmp___3 = (char )'\\';
        switch ((int )c) {
        case 10: 
        tmp___4 = target;
        target ++;
        *tmp___4 = (char )'n';
        break;
        case 9: 
        tmp___5 = target;
        target ++;
        *tmp___5 = (char )'t';
        break;
        case 13: 
        tmp___6 = target;
        target ++;
        *tmp___6 = (char )'r';
        break;
        case 7: 
        tmp___7 = target;
        target ++;
        *tmp___7 = (char )'a';
        break;
        case 11: 
        tmp___8 = target;
        target ++;
        *tmp___8 = (char )'v';
        break;
        case 8: 
        tmp___9 = target;
        target ++;
        *tmp___9 = (char )'b';
        break;
        case 12: 
        tmp___10 = target;
        target ++;
        *tmp___10 = (char )'f';
        break;
        default: 
        tmp___11 = php_sprintf(target, "%03o", (int )((unsigned char )c));
        target += tmp___11;
        }
        goto __Cont;
      } else {

      }
      tmp___12 = target;
      target ++;
      *tmp___12 = (char )'\\';
    } else {

    }
    tmp___13 = target;
    target ++;
    *tmp___13 = c;
    __Cont: 
    source ++;
  }
  *target = (char)0;
  newlen = (int )(target - new_str);
  if (target - new_str < (long )(length * 4)) {
    tmp___14 = _erealloc((void *)new_str, (size_t )(newlen + 1), 0);
    new_str = (char *)tmp___14;
  } else {

  }
  if (new_length) {
    *new_length = newlen;
  } else {

  }
  if (should_free) {
    if (str) {
      if ((unsigned long )str >= (unsigned long )compiler_globals.interned_strings_start) {
        if (! ((unsigned long )str < (unsigned long )compiler_globals.interned_strings_end)) {
          _efree((void *)str);
        } else {

        }
      } else {
        _efree((void *)str);
      }
    } else {

    }
  } else {

  }
  return ((char __attribute__((__visibility__("default")))  *)new_str);
}
}
char __attribute__((__visibility__("default")))  *php_addslashes(char *str ,
                                                                 int length ,
                                                                 int *new_length ,
                                                                 int should_free ) 
{ 
  char __attribute__((__visibility__("default")))  *tmp ;

  {
  tmp = php_addslashes_ex(str, length, new_length, should_free, 0);
  return (tmp);
}
}
char __attribute__((__visibility__("default")))  *php_addslashes_ex(char *str ,
                                                                    int length ,
                                                                    int *new_length ,
                                                                    int should_free ,
                                                                    int ignore_sybase ) 
{ 
  char *new_str ;
  char *source ;
  char *target ;
  char *end ;
  int local_new_length ;
  size_t tmp ;
  int tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  char *tmp___2 ;
  char *tmp___3 ;
  char *tmp___4 ;
  char *tmp___5 ;
  char *tmp___6 ;
  char *tmp___7 ;
  char *tmp___8 ;
  char *tmp___9 ;
  char *tmp___10 ;
  void __attribute__((__visibility__("default")))  *tmp___11 ;

  {
  if (! new_length) {
    new_length = & local_new_length;
  } else {

  }
  if (! str) {
    *new_length = 0;
    return ((char __attribute__((__visibility__("default")))  *)str);
  } else {

  }
  if (length) {
    tmp___0 = length;
  } else {
    tmp = strlen((char const   *)str);
    length = (int )tmp;
    tmp___0 = length;
  }
  tmp___1 = _safe_emalloc((size_t )2, (size_t )tmp___0, (size_t )1);
  new_str = (char *)tmp___1;
  source = str;
  end = source + length;
  target = new_str;
  if (! ignore_sybase) {
    if (core_globals.magic_quotes_sybase) {
      while ((unsigned long )source < (unsigned long )end) {
        switch ((int )*source) {
        case 0: 
        tmp___2 = target;
        target ++;
        *tmp___2 = (char )'\\';
        tmp___3 = target;
        target ++;
        *tmp___3 = (char )'0';
        break;
        case 39: 
        tmp___4 = target;
        target ++;
        *tmp___4 = (char )'\'';
        tmp___5 = target;
        target ++;
        *tmp___5 = (char )'\'';
        break;
        default: 
        tmp___6 = target;
        target ++;
        *tmp___6 = *source;
        break;
        }
        source ++;
      }
    } else {
      goto _L;
    }
  } else {
    _L: 
    while ((unsigned long )source < (unsigned long )end) {
      switch ((int )*source) {
      case 0: 
      tmp___7 = target;
      target ++;
      *tmp___7 = (char )'\\';
      tmp___8 = target;
      target ++;
      *tmp___8 = (char )'0';
      break;
      case 39: 
      case 34: 
      case 92: 
      tmp___9 = target;
      target ++;
      *tmp___9 = (char )'\\';
      default: 
      tmp___10 = target;
      target ++;
      *tmp___10 = *source;
      break;
      }
      source ++;
    }
  }
  *target = (char)0;
  *new_length = (int )(target - new_str);
  if (should_free) {
    if (str) {
      if ((unsigned long )str >= (unsigned long )compiler_globals.interned_strings_start) {
        if (! ((unsigned long )str < (unsigned long )compiler_globals.interned_strings_end)) {
          _efree((void *)str);
        } else {

        }
      } else {
        _efree((void *)str);
      }
    } else {

    }
  } else {

  }
  tmp___11 = _erealloc((void *)new_str, (size_t )(*new_length + 1), 0);
  new_str = (char *)tmp___11;
  return ((char __attribute__((__visibility__("default")))  *)new_str);
}
}
int __attribute__((__visibility__("default")))  php_char_to_str_ex(char *str ,
                                                                   uint len ,
                                                                   char from ,
                                                                   char *to ,
                                                                   int to_len ,
                                                                   zval *result ,
                                                                   int case_sensitivity ,
                                                                   int *replace_count ) 
{ 
  int char_count ;
  int replaced ;
  char *source ;
  char *target ;
  char *tmp ;
  char *source_end ;
  char *tmp_end ;
  char *p ;
  char *e ;
  void *tmp___0 ;
  int __res ;
  int __attribute__((__gnu_inline__))  tmp___2 ;
  __int32_t const   **tmp___3 ;
  int __res___0 ;
  int __attribute__((__gnu_inline__))  tmp___5 ;
  __int32_t const   **tmp___6 ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___7 ;
  void __attribute__((__visibility__("default")))  *tmp___8 ;
  char *p___0 ;
  char *e___0 ;
  char *s ;
  void *tmp___9 ;
  int __res___1 ;
  int __attribute__((__gnu_inline__))  tmp___11 ;
  __int32_t const   **tmp___12 ;
  int __res___2 ;
  int __attribute__((__gnu_inline__))  tmp___14 ;
  __int32_t const   **tmp___15 ;

  {
  char_count = 0;
  replaced = 0;
  source_end = str + len;
  tmp_end = (char *)((void *)0);
  if (case_sensitivity) {
    p = str;
    e = p + len;
    while (1) {
      tmp___0 = memchr((void const   *)p, (int )from, (size_t )(e - p));
      p = (char *)tmp___0;
      if (! p) {
        break;
      } else {

      }
      char_count ++;
      p ++;
    }
  } else {
    source = str;
    while ((unsigned long )source < (unsigned long )source_end) {
      if (sizeof(*source) > 1UL) {
        tmp___2 = tolower((int )*source);
        __res = (int )tmp___2;
      } else {
        tmp___3 = __ctype_tolower_loc();
        __res = (int )*(*tmp___3 + (int )*source);
      }
      if (sizeof(from) > 1UL) {
        tmp___5 = tolower((int )from);
        __res___0 = (int )tmp___5;
      } else {
        tmp___6 = __ctype_tolower_loc();
        __res___0 = (int )*(*tmp___6 + (int )from);
      }
      if (__res == __res___0) {
        char_count ++;
      } else {

      }
      source ++;
    }
  }
  if (char_count == 0) {
    if (case_sensitivity) {
      while (1) {
        __s = (char const   *)str;
        __l = (int )len;
        __z = result;
        __z->value.str.len = __l;
        tmp___7 = _estrndup(__s, (unsigned int )__l);
        __z->value.str.val = (char *)tmp___7;
        __z->type = (zend_uchar )6;
        break;
      }
      return ((int __attribute__((__visibility__("default")))  )0);
    } else {

    }
  } else {

  }
  result->value.str.len = (int )(len + (uint )(char_count * (to_len - 1)));
  tmp___8 = _safe_emalloc((size_t )char_count, (size_t )to_len,
                          (size_t )(len + 1U));
  target = (char *)tmp___8;
  result->value.str.val = target;
  result->type = (zend_uchar )6;
  if (case_sensitivity) {
    p___0 = str;
    e___0 = p___0 + len;
    s = str;
    while (1) {
      tmp___9 = memchr((void const   *)p___0, (int )from,
                       (size_t )(e___0 - p___0));
      p___0 = (char *)tmp___9;
      if (! p___0) {
        break;
      } else {

      }
      memcpy((void */* __restrict  */)target,
             (void const   */* __restrict  */)s, (size_t )(p___0 - s));
      target += p___0 - s;
      memcpy((void */* __restrict  */)target,
             (void const   */* __restrict  */)to, (size_t )to_len);
      target += to_len;
      p___0 ++;
      s = p___0;
      if (replace_count) {
        (*replace_count) ++;
      } else {

      }
    }
    if ((unsigned long )s < (unsigned long )e___0) {
      memcpy((void */* __restrict  */)target,
             (void const   */* __restrict  */)s, (size_t )(e___0 - s));
      target += e___0 - s;
    } else {

    }
  } else {
    source = str;
    while ((unsigned long )source < (unsigned long )source_end) {
      if (sizeof(*source) > 1UL) {
        tmp___11 = tolower((int )*source);
        __res___1 = (int )tmp___11;
      } else {
        tmp___12 = __ctype_tolower_loc();
        __res___1 = (int )*(*tmp___12 + (int )*source);
      }
      if (sizeof(from) > 1UL) {
        tmp___14 = tolower((int )from);
        __res___2 = (int )tmp___14;
      } else {
        tmp___15 = __ctype_tolower_loc();
        __res___2 = (int )*(*tmp___15 + (int )from);
      }
      if (__res___1 == __res___2) {
        replaced = 1;
        if (replace_count) {
          (*replace_count) ++;
        } else {

        }
        tmp = to;
        tmp_end = tmp + to_len;
        while ((unsigned long )tmp < (unsigned long )tmp_end) {
          *target = *tmp;
          target ++;
          tmp ++;
        }
      } else {
        *target = *source;
        target ++;
      }
      source ++;
    }
  }
  *target = (char)0;
  return ((int __attribute__((__visibility__("default")))  )replaced);
}
}
int __attribute__((__visibility__("default")))  php_char_to_str(char *str ,
                                                                uint len ,
                                                                char from ,
                                                                char *to ,
                                                                int to_len ,
                                                                zval *result ) 
{ 
  int __attribute__((__visibility__("default")))  tmp ;

  {
  tmp = php_char_to_str_ex(str, len, from, to, to_len, result, 1,
                           (int *)((void *)0));
  return (tmp);
}
}
char __attribute__((__visibility__("default")))  *php_str_to_str_ex(char *haystack ,
                                                                    int length ,
                                                                    char *needle ,
                                                                    int needle_len ,
                                                                    char *str ,
                                                                    int str_len ,
                                                                    int *_new_length ,
                                                                    int case_sensitivity ,
                                                                    int *replace_count ) 
{ 
  char *new_str ;
  char *end ;
  char *haystack_dup ;
  char *needle_dup ;
  char *e ;
  char *s ;
  char *p ;
  char *r ;
  char __attribute__((__visibility__("default")))  *tmp ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;
  char __attribute__((__visibility__("default")))  *tmp___3 ;
  void __attribute__((__visibility__("default")))  *tmp___4 ;
  int count ;
  char *o ;
  char *n ;
  char *endp ;
  char __attribute__((__visibility__("default")))  *tmp___5 ;
  void __attribute__((__visibility__("default")))  *tmp___6 ;
  void __attribute__((__visibility__("default")))  *tmp___7 ;
  char __attribute__((__visibility__("default")))  *tmp___8 ;
  char *l_haystack ;
  char *l_needle ;
  char __attribute__((__visibility__("default")))  *tmp___9 ;
  char __attribute__((__visibility__("default")))  *tmp___10 ;
  int tmp___11 ;
  int tmp___12 ;
  char __attribute__((__visibility__("default")))  *tmp___13 ;

  {
  if (needle_len < length) {
    haystack_dup = (char *)((void *)0);
    needle_dup = (char *)((void *)0);
    if (needle_len == str_len) {
      tmp = _estrndup((char const   *)haystack, (unsigned int )length);
      new_str = (char *)tmp;
      *_new_length = length;
      if (case_sensitivity) {
        end = new_str + length;
        p = new_str;
        while (1) {
          r = zend_memnstr(p, needle, needle_len, end);
          if (! r) {
            break;
          } else {

          }
          memcpy((void */* __restrict  */)r,
                 (void const   */* __restrict  */)str, (size_t )str_len);
          if (replace_count) {
            (*replace_count) ++;
          } else {

          }
          p = r + needle_len;
        }
      } else {
        tmp___0 = _estrndup((char const   *)haystack, (unsigned int )length);
        haystack_dup = (char *)tmp___0;
        tmp___1 = _estrndup((char const   *)needle, (unsigned int )needle_len);
        needle_dup = (char *)tmp___1;
        php_strtolower(haystack_dup, (size_t )length);
        php_strtolower(needle_dup, (size_t )needle_len);
        end = haystack_dup + length;
        p = haystack_dup;
        while (1) {
          r = zend_memnstr(p, needle_dup, needle_len, end);
          if (! r) {
            break;
          } else {

          }
          memcpy((void */* __restrict  */)(new_str + (r - haystack_dup)),
                 (void const   */* __restrict  */)str, (size_t )str_len);
          if (replace_count) {
            (*replace_count) ++;
          } else {

          }
          p = r + needle_len;
        }
        _efree((void *)haystack_dup);
        _efree((void *)needle_dup);
      }
      return ((char __attribute__((__visibility__("default")))  *)new_str);
    } else {
      if (! case_sensitivity) {
        tmp___2 = _estrndup((char const   *)haystack, (unsigned int )length);
        haystack_dup = (char *)tmp___2;
        tmp___3 = _estrndup((char const   *)needle, (unsigned int )needle_len);
        needle_dup = (char *)tmp___3;
        php_strtolower(haystack_dup, (size_t )length);
        php_strtolower(needle_dup, (size_t )needle_len);
      } else {

      }
      if (str_len < needle_len) {
        tmp___4 = _emalloc((size_t )(length + 1));
        new_str = (char *)tmp___4;
      } else {
        count = 0;
        if (case_sensitivity) {
          o = haystack;
          n = needle;
        } else {
          o = haystack_dup;
          n = needle_dup;
        }
        endp = o + length;
        while (1) {
          o = zend_memnstr(o, n, needle_len, endp);
          if (! o) {
            break;
          } else {

          }
          o += needle_len;
          count ++;
        }
        if (count == 0) {
          if (haystack_dup) {
            _efree((void *)haystack_dup);
          } else {

          }
          if (needle_dup) {
            _efree((void *)needle_dup);
          } else {

          }
          tmp___5 = _estrndup((char const   *)haystack, (unsigned int )length);
          new_str = (char *)tmp___5;
          if (_new_length) {
            *_new_length = length;
          } else {

          }
          return ((char __attribute__((__visibility__("default")))  *)new_str);
        } else {
          tmp___6 = _safe_emalloc((size_t )count,
                                  (size_t )(str_len - needle_len),
                                  (size_t )(length + 1));
          new_str = (char *)tmp___6;
        }
      }
      s = new_str;
      e = s;
      if (case_sensitivity) {
        end = haystack + length;
        p = haystack;
        while (1) {
          r = zend_memnstr(p, needle, needle_len, end);
          if (! r) {
            break;
          } else {

          }
          memcpy((void */* __restrict  */)e, (void const   */* __restrict  */)p,
                 (size_t )(r - p));
          e += r - p;
          memcpy((void */* __restrict  */)e,
                 (void const   */* __restrict  */)str, (size_t )str_len);
          e += str_len;
          if (replace_count) {
            (*replace_count) ++;
          } else {

          }
          p = r + needle_len;
        }
        if ((unsigned long )p < (unsigned long )end) {
          memcpy((void */* __restrict  */)e, (void const   */* __restrict  */)p,
                 (size_t )(end - p));
          e += end - p;
        } else {

        }
      } else {
        end = haystack_dup + length;
        p = haystack_dup;
        while (1) {
          r = zend_memnstr(p, needle_dup, needle_len, end);
          if (! r) {
            break;
          } else {

          }
          memcpy((void */* __restrict  */)e,
                 (void const   */* __restrict  */)(haystack + (p - haystack_dup)),
                 (size_t )(r - p));
          e += r - p;
          memcpy((void */* __restrict  */)e,
                 (void const   */* __restrict  */)str, (size_t )str_len);
          e += str_len;
          if (replace_count) {
            (*replace_count) ++;
          } else {

          }
          p = r + needle_len;
        }
        if ((unsigned long )p < (unsigned long )end) {
          memcpy((void */* __restrict  */)e,
                 (void const   */* __restrict  */)(haystack + (p - haystack_dup)),
                 (size_t )(end - p));
          e += end - p;
        } else {

        }
      }
      if (haystack_dup) {
        _efree((void *)haystack_dup);
      } else {

      }
      if (needle_dup) {
        _efree((void *)needle_dup);
      } else {

      }
      *e = (char )'\000';
      *_new_length = (int )(e - s);
      tmp___7 = _erealloc((void *)new_str, (size_t )(*_new_length + 1), 0);
      new_str = (char *)tmp___7;
      return ((char __attribute__((__visibility__("default")))  *)new_str);
    }
  } else
  if (needle_len > length) {
    nothing_todo: 
    *_new_length = length;
    tmp___8 = _estrndup((char const   *)haystack, (unsigned int )length);
    new_str = (char *)tmp___8;
    return ((char __attribute__((__visibility__("default")))  *)new_str);
  } else {
    if (case_sensitivity) {
      tmp___12 = memcmp((void const   *)haystack, (void const   *)needle,
                        (size_t )length);
      if (tmp___12) {
        goto nothing_todo;
      } else {
        goto _L;
      }
    } else
    _L: 
    if (! case_sensitivity) {
      tmp___9 = _estrndup((char const   *)haystack, (unsigned int )length);
      l_haystack = (char *)tmp___9;
      tmp___10 = _estrndup((char const   *)needle, (unsigned int )length);
      l_needle = (char *)tmp___10;
      php_strtolower(l_haystack, (size_t )length);
      php_strtolower(l_needle, (size_t )length);
      tmp___11 = memcmp((void const   *)l_haystack, (void const   *)l_needle,
                        (size_t )length);
      if (tmp___11) {
        _efree((void *)l_haystack);
        _efree((void *)l_needle);
        goto nothing_todo;
      } else {

      }
      _efree((void *)l_haystack);
      _efree((void *)l_needle);
    } else {

    }
    *_new_length = str_len;
    tmp___13 = _estrndup((char const   *)str, (unsigned int )str_len);
    new_str = (char *)tmp___13;
    if (replace_count) {
      (*replace_count) ++;
    } else {

    }
    return ((char __attribute__((__visibility__("default")))  *)new_str);
  }
}
}
char __attribute__((__visibility__("default")))  *php_str_to_str(char *haystack ,
                                                                 int length ,
                                                                 char *needle ,
                                                                 int needle_len ,
                                                                 char *str ,
                                                                 int str_len ,
                                                                 int *_new_length ) 
{ 
  char __attribute__((__visibility__("default")))  *tmp ;

  {
  tmp = php_str_to_str_ex(haystack, length, needle, needle_len, str, str_len,
                          _new_length, 1, (int *)((void *)0));
  return (tmp);
}
}
static void php_str_replace_in_subject(zval *search , zval *replace ,
                                       zval **subject , zval *result ,
                                       int case_sensitivity ,
                                       int *replace_count ) 
{ 
  zval **search_entry ;
  zval **replace_entry ;
  zval temp_result ;
  char *replace_value ;
  int replace_len ;
  zval *new_zv ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_uint tmp___0 ;
  zend_bool tmp___1 ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;
  zval *new_zv___0 ;
  void __attribute__((__visibility__("default")))  *tmp___3 ;
  zend_uint tmp___4 ;
  zval *new_zv___1 ;
  void __attribute__((__visibility__("default")))  *tmp___5 ;
  zend_uint tmp___6 ;
  zend_bool tmp___7 ;
  int __attribute__((__visibility__("default")))  tmp___8 ;
  char __attribute__((__visibility__("default")))  *tmp___9 ;
  int __attribute__((__visibility__("default")))  tmp___10 ;
  char __attribute__((__visibility__("default")))  *tmp___11 ;

  {
  replace_entry = (zval **)((void *)0);
  replace_value = (char *)((void *)0);
  replace_len = 0;
  if ((int )(*subject)->type != 6) {
    tmp___1 = zval_isref_p(*subject);
    if (! tmp___1) {
      while (1) {
        tmp___0 = zval_refcount_p(*subject);
        if (tmp___0 > 1U) {
          zval_delref_p(*subject);
          while (1) {
            tmp = _emalloc(sizeof(zval_gc_info ));
            new_zv = (zval *)tmp;
            ((zval_gc_info *)new_zv)->u.buffered = (gc_root_buffer *)((void *)0);
            break;
          }
          while (1) {
            while (1) {
              new_zv->value = (*subject)->value;
              new_zv->type = (*subject)->type;
              break;
            }
            zval_set_refcount_p(new_zv, (zend_uint )1);
            zval_unset_isref_p(new_zv);
            break;
          }
          *subject = new_zv;
          _zval_copy_ctor(new_zv);
        } else {

        }
        break;
      }
    } else {

    }
    if ((int )(*subject)->type != 6) {
      _convert_to_string(*subject);
    } else {

    }
  } else {

  }
  result->type = (zend_uchar )6;
  if ((*subject)->value.str.len == 0) {
    while (1) {
      __s = "";
      __l = 0;
      __z = result;
      __z->value.str.len = __l;
      tmp___2 = _estrndup(__s, (unsigned int )__l);
      __z->value.str.val = (char *)tmp___2;
      __z->type = (zend_uchar )6;
      break;
    }
    return;
  } else {

  }
  if ((int )search->type == 4) {
    while (1) {
      while (1) {
        result->value = (*subject)->value;
        result->type = (*subject)->type;
        break;
      }
      zval_set_refcount_p(result, (zend_uint )1);
      zval_unset_isref_p(result);
      break;
    }
    _zval_copy_ctor(result);
    zend_hash_internal_pointer_reset_ex(search->value.ht,
                                        (HashPosition *)((void *)0));
    if ((int )replace->type == 4) {
      zend_hash_internal_pointer_reset_ex(replace->value.ht,
                                          (HashPosition *)((void *)0));
    } else {
      replace_value = replace->value.str.val;
      replace_len = replace->value.str.len;
    }
    while (1) {
      tmp___10 = zend_hash_get_current_data_ex(search->value.ht,
                                               (void **)(& search_entry),
                                               (HashPosition *)((void *)0));
      if (! (tmp___10 == (int __attribute__((__visibility__("default")))  )0)) {
        break;
      } else {

      }
      while (1) {
        tmp___4 = zval_refcount_p(*search_entry);
        if (tmp___4 > 1U) {
          zval_delref_p(*search_entry);
          while (1) {
            tmp___3 = _emalloc(sizeof(zval_gc_info ));
            new_zv___0 = (zval *)tmp___3;
            ((zval_gc_info *)new_zv___0)->u.buffered = (gc_root_buffer *)((void *)0);
            break;
          }
          while (1) {
            while (1) {
              new_zv___0->value = (*search_entry)->value;
              new_zv___0->type = (*search_entry)->type;
              break;
            }
            zval_set_refcount_p(new_zv___0, (zend_uint )1);
            zval_unset_isref_p(new_zv___0);
            break;
          }
          *search_entry = new_zv___0;
          _zval_copy_ctor(new_zv___0);
        } else {

        }
        break;
      }
      if ((int )(*search_entry)->type != 6) {
        _convert_to_string(*search_entry);
      } else {

      }
      if ((*search_entry)->value.str.len == 0) {
        zend_hash_move_forward_ex(search->value.ht, (HashPosition *)((void *)0));
        if ((int )replace->type == 4) {
          zend_hash_move_forward_ex(replace->value.ht,
                                    (HashPosition *)((void *)0));
        } else {

        }
        continue;
      } else {

      }
      if ((int )replace->type == 4) {
        tmp___8 = zend_hash_get_current_data_ex(replace->value.ht,
                                                (void **)(& replace_entry),
                                                (HashPosition *)((void *)0));
        if (tmp___8 == (int __attribute__((__visibility__("default")))  )0) {
          if ((int )(*replace_entry)->type != 6) {
            tmp___7 = zval_isref_p(*replace_entry);
            if (! tmp___7) {
              while (1) {
                tmp___6 = zval_refcount_p(*replace_entry);
                if (tmp___6 > 1U) {
                  zval_delref_p(*replace_entry);
                  while (1) {
                    tmp___5 = _emalloc(sizeof(zval_gc_info ));
                    new_zv___1 = (zval *)tmp___5;
                    ((zval_gc_info *)new_zv___1)->u.buffered = (gc_root_buffer *)((void *)0);
                    break;
                  }
                  while (1) {
                    while (1) {
                      new_zv___1->value = (*replace_entry)->value;
                      new_zv___1->type = (*replace_entry)->type;
                      break;
                    }
                    zval_set_refcount_p(new_zv___1, (zend_uint )1);
                    zval_unset_isref_p(new_zv___1);
                    break;
                  }
                  *replace_entry = new_zv___1;
                  _zval_copy_ctor(new_zv___1);
                } else {

                }
                break;
              }
            } else {

            }
            if ((int )(*replace_entry)->type != 6) {
              _convert_to_string(*replace_entry);
            } else {

            }
          } else {

          }
          replace_value = (*replace_entry)->value.str.val;
          replace_len = (*replace_entry)->value.str.len;
          zend_hash_move_forward_ex(replace->value.ht,
                                    (HashPosition *)((void *)0));
        } else {
          replace_value = (char *)"";
          replace_len = 0;
        }
      } else {

      }
      if ((*search_entry)->value.str.len == 1) {
        php_char_to_str_ex(result->value.str.val, (uint )result->value.str.len,
                           *((*search_entry)->value.str.val + 0), replace_value,
                           replace_len, & temp_result, case_sensitivity,
                           replace_count);
      } else
      if ((*search_entry)->value.str.len > 1) {
        tmp___9 = php_str_to_str_ex(result->value.str.val,
                                    result->value.str.len,
                                    (*search_entry)->value.str.val,
                                    (*search_entry)->value.str.len,
                                    replace_value, replace_len,
                                    & temp_result.value.str.len,
                                    case_sensitivity, replace_count);
        temp_result.value.str.val = (char *)tmp___9;
      } else {

      }
      while (1) {
        if ((unsigned long )result->value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
          if (! ((unsigned long )result->value.str.val < (unsigned long )compiler_globals.interned_strings_end)) {
            _efree((void *)result->value.str.val);
          } else {

          }
        } else {
          _efree((void *)result->value.str.val);
        }
        break;
      }
      result->value.str.val = temp_result.value.str.val;
      result->value.str.len = temp_result.value.str.len;
      if (result->value.str.len == 0) {
        return;
      } else {

      }
      zend_hash_move_forward_ex(search->value.ht, (HashPosition *)((void *)0));
    }
  } else
  if (search->value.str.len == 1) {
    php_char_to_str_ex((*subject)->value.str.val,
                       (uint )(*subject)->value.str.len,
                       *(search->value.str.val + 0), replace->value.str.val,
                       replace->value.str.len, result, case_sensitivity,
                       replace_count);
  } else
  if (search->value.str.len > 1) {
    tmp___11 = php_str_to_str_ex((*subject)->value.str.val,
                                 (*subject)->value.str.len,
                                 search->value.str.val, search->value.str.len,
                                 replace->value.str.val, replace->value.str.len,
                                 & result->value.str.len, case_sensitivity,
                                 replace_count);
    result->value.str.val = (char *)tmp___11;
  } else {
    while (1) {
      while (1) {
        result->value = (*subject)->value;
        result->type = (*subject)->type;
        break;
      }
      zval_set_refcount_p(result, (zend_uint )1);
      zval_unset_isref_p(result);
      break;
    }
    _zval_copy_ctor(result);
  }
  return;
}
}
static void php_str_replace_common(int ht , zval *return_value ,
                                   zval **return_value_ptr , zval *this_ptr ,
                                   int return_value_used , int case_sensitivity ) 
{ 
  zval **subject ;
  zval **search ;
  zval **replace ;
  zval **subject_entry ;
  zval **zcount ;
  zval *result ;
  char *string_key ;
  uint string_key_len ;
  ulong num_key ;
  int count ;
  int argc ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *new_zv ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  zend_uint tmp___1 ;
  zval *new_zv___0 ;
  void __attribute__((__visibility__("default")))  *tmp___2 ;
  zend_uint tmp___3 ;
  zval *new_zv___1 ;
  void __attribute__((__visibility__("default")))  *tmp___4 ;
  zend_uint tmp___5 ;
  zval *new_zv___2 ;
  void __attribute__((__visibility__("default")))  *tmp___6 ;
  zend_uint tmp___7 ;
  zend_bool tmp___8 ;
  zval *new_zv___3 ;
  void __attribute__((__visibility__("default")))  *tmp___9 ;
  zend_uint tmp___10 ;
  zend_bool tmp___11 ;
  zval *new_zv___4 ;
  void __attribute__((__visibility__("default")))  *tmp___12 ;
  zend_uint tmp___13 ;
  zend_bool tmp___14 ;
  void __attribute__((__visibility__("default")))  *tmp___15 ;
  zval *new_zv___5 ;
  void __attribute__((__visibility__("default")))  *tmp___16 ;
  zend_uint tmp___17 ;
  int *tmp___18 ;
  void __attribute__((__visibility__("default")))  *tmp___19 ;
  zend_uint tmp___20 ;
  int __attribute__((__visibility__("default")))  tmp___21 ;
  int __attribute__((__visibility__("default")))  tmp___22 ;
  int *tmp___23 ;
  zval *__z ;

  {
  zcount = (zval **)((void *)0);
  count = 0;
  argc = ht;
  tmp = zend_parse_parameters(ht, "ZZZ|Z", & search, & replace, & subject,
                              & zcount);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  while (1) {
    tmp___1 = zval_refcount_p(*search);
    if (tmp___1 > 1U) {
      zval_delref_p(*search);
      while (1) {
        tmp___0 = _emalloc(sizeof(zval_gc_info ));
        new_zv = (zval *)tmp___0;
        ((zval_gc_info *)new_zv)->u.buffered = (gc_root_buffer *)((void *)0);
        break;
      }
      while (1) {
        while (1) {
          new_zv->value = (*search)->value;
          new_zv->type = (*search)->type;
          break;
        }
        zval_set_refcount_p(new_zv, (zend_uint )1);
        zval_unset_isref_p(new_zv);
        break;
      }
      *search = new_zv;
      _zval_copy_ctor(new_zv);
    } else {

    }
    break;
  }
  while (1) {
    tmp___3 = zval_refcount_p(*replace);
    if (tmp___3 > 1U) {
      zval_delref_p(*replace);
      while (1) {
        tmp___2 = _emalloc(sizeof(zval_gc_info ));
        new_zv___0 = (zval *)tmp___2;
        ((zval_gc_info *)new_zv___0)->u.buffered = (gc_root_buffer *)((void *)0);
        break;
      }
      while (1) {
        while (1) {
          new_zv___0->value = (*replace)->value;
          new_zv___0->type = (*replace)->type;
          break;
        }
        zval_set_refcount_p(new_zv___0, (zend_uint )1);
        zval_unset_isref_p(new_zv___0);
        break;
      }
      *replace = new_zv___0;
      _zval_copy_ctor(new_zv___0);
    } else {

    }
    break;
  }
  while (1) {
    tmp___5 = zval_refcount_p(*subject);
    if (tmp___5 > 1U) {
      zval_delref_p(*subject);
      while (1) {
        tmp___4 = _emalloc(sizeof(zval_gc_info ));
        new_zv___1 = (zval *)tmp___4;
        ((zval_gc_info *)new_zv___1)->u.buffered = (gc_root_buffer *)((void *)0);
        break;
      }
      while (1) {
        while (1) {
          new_zv___1->value = (*subject)->value;
          new_zv___1->type = (*subject)->type;
          break;
        }
        zval_set_refcount_p(new_zv___1, (zend_uint )1);
        zval_unset_isref_p(new_zv___1);
        break;
      }
      *subject = new_zv___1;
      _zval_copy_ctor(new_zv___1);
    } else {

    }
    break;
  }
  if ((int )(*search)->type != 4) {
    if ((int )(*search)->type != 6) {
      tmp___8 = zval_isref_p(*search);
      if (! tmp___8) {
        while (1) {
          tmp___7 = zval_refcount_p(*search);
          if (tmp___7 > 1U) {
            zval_delref_p(*search);
            while (1) {
              tmp___6 = _emalloc(sizeof(zval_gc_info ));
              new_zv___2 = (zval *)tmp___6;
              ((zval_gc_info *)new_zv___2)->u.buffered = (gc_root_buffer *)((void *)0);
              break;
            }
            while (1) {
              while (1) {
                new_zv___2->value = (*search)->value;
                new_zv___2->type = (*search)->type;
                break;
              }
              zval_set_refcount_p(new_zv___2, (zend_uint )1);
              zval_unset_isref_p(new_zv___2);
              break;
            }
            *search = new_zv___2;
            _zval_copy_ctor(new_zv___2);
          } else {

          }
          break;
        }
      } else {

      }
      if ((int )(*search)->type != 6) {
        _convert_to_string(*search);
      } else {

      }
    } else {

    }
    if ((int )(*replace)->type != 6) {
      tmp___11 = zval_isref_p(*replace);
      if (! tmp___11) {
        while (1) {
          tmp___10 = zval_refcount_p(*replace);
          if (tmp___10 > 1U) {
            zval_delref_p(*replace);
            while (1) {
              tmp___9 = _emalloc(sizeof(zval_gc_info ));
              new_zv___3 = (zval *)tmp___9;
              ((zval_gc_info *)new_zv___3)->u.buffered = (gc_root_buffer *)((void *)0);
              break;
            }
            while (1) {
              while (1) {
                new_zv___3->value = (*replace)->value;
                new_zv___3->type = (*replace)->type;
                break;
              }
              zval_set_refcount_p(new_zv___3, (zend_uint )1);
              zval_unset_isref_p(new_zv___3);
              break;
            }
            *replace = new_zv___3;
            _zval_copy_ctor(new_zv___3);
          } else {

          }
          break;
        }
      } else {

      }
      if ((int )(*replace)->type != 6) {
        _convert_to_string(*replace);
      } else {

      }
    } else {

    }
  } else
  if ((int )(*replace)->type != 4) {
    if ((int )(*replace)->type != 6) {
      tmp___14 = zval_isref_p(*replace);
      if (! tmp___14) {
        while (1) {
          tmp___13 = zval_refcount_p(*replace);
          if (tmp___13 > 1U) {
            zval_delref_p(*replace);
            while (1) {
              tmp___12 = _emalloc(sizeof(zval_gc_info ));
              new_zv___4 = (zval *)tmp___12;
              ((zval_gc_info *)new_zv___4)->u.buffered = (gc_root_buffer *)((void *)0);
              break;
            }
            while (1) {
              while (1) {
                new_zv___4->value = (*replace)->value;
                new_zv___4->type = (*replace)->type;
                break;
              }
              zval_set_refcount_p(new_zv___4, (zend_uint )1);
              zval_unset_isref_p(new_zv___4);
              break;
            }
            *replace = new_zv___4;
            _zval_copy_ctor(new_zv___4);
          } else {

          }
          break;
        }
      } else {

      }
      if ((int )(*replace)->type != 6) {
        _convert_to_string(*replace);
      } else {

      }
    } else {

    }
  } else {

  }
  if ((int )(*subject)->type == 4) {
    _array_init(return_value, (uint )0);
    zend_hash_internal_pointer_reset_ex((*subject)->value.ht,
                                        (HashPosition *)((void *)0));
    while (1) {
      tmp___22 = zend_hash_get_current_data_ex((*subject)->value.ht,
                                               (void **)(& subject_entry),
                                               (HashPosition *)((void *)0));
      if (! (tmp___22 == (int __attribute__((__visibility__("default")))  )0)) {
        break;
      } else {

      }
      if ((int )(*subject_entry)->type != 4) {
        if ((int )(*subject_entry)->type != 5) {
          while (1) {
            tmp___15 = _emalloc(sizeof(zval_gc_info ));
            result = (zval *)tmp___15;
            ((zval_gc_info *)result)->u.buffered = (gc_root_buffer *)((void *)0);
            break;
          }
          result->refcount__gc = (zend_uint )1;
          result->is_ref__gc = (zend_uchar )0;
          while (1) {
            tmp___17 = zval_refcount_p(*subject_entry);
            if (tmp___17 > 1U) {
              zval_delref_p(*subject_entry);
              while (1) {
                tmp___16 = _emalloc(sizeof(zval_gc_info ));
                new_zv___5 = (zval *)tmp___16;
                ((zval_gc_info *)new_zv___5)->u.buffered = (gc_root_buffer *)((void *)0);
                break;
              }
              while (1) {
                while (1) {
                  new_zv___5->value = (*subject_entry)->value;
                  new_zv___5->type = (*subject_entry)->type;
                  break;
                }
                zval_set_refcount_p(new_zv___5, (zend_uint )1);
                zval_unset_isref_p(new_zv___5);
                break;
              }
              *subject_entry = new_zv___5;
              _zval_copy_ctor(new_zv___5);
            } else {

            }
            break;
          }
          if (argc > 3) {
            tmp___18 = & count;
          } else {
            tmp___18 = (int *)((void *)0);
          }
          php_str_replace_in_subject(*search, *replace, subject_entry, result,
                                     case_sensitivity, tmp___18);
        } else {
          goto _L;
        }
      } else {
        _L: 
        while (1) {
          tmp___19 = _emalloc(sizeof(zval_gc_info ));
          result = (zval *)tmp___19;
          ((zval_gc_info *)result)->u.buffered = (gc_root_buffer *)((void *)0);
          break;
        }
        zval_addref_p(*subject_entry);
        *result = *(*subject_entry);
        tmp___20 = zval_refcount_p(*subject_entry);
        if (tmp___20 > 1U) {
          _zval_copy_ctor(result);
          zval_delref_p(*subject_entry);
        } else {
          while (1) {
            if ((gc_root_buffer *)((zend_uintptr_t )((zval_gc_info *)*subject_entry)->u.buffered & 0xfffffffffffffffcUL)) {
              gc_remove_zval_from_buffer(*subject_entry);
            } else {

            }
            _efree((void *)*subject_entry);
            break;
          }
        }
        result->refcount__gc = (zend_uint )1;
        result->is_ref__gc = (zend_uchar )0;
      }
      tmp___21 = zend_hash_get_current_key_ex((HashTable const   *)(*subject)->value.ht,
                                              & string_key, & string_key_len,
                                              & num_key, (zend_bool )0,
                                              (HashPosition *)((void *)0));
      switch (tmp___21) {
      case (int __attribute__((__visibility__("default")))  )1: 
      add_assoc_zval_ex(return_value, (char const   *)string_key,
                        string_key_len, result);
      break;
      case (int __attribute__((__visibility__("default")))  )2: 
      add_index_zval(return_value, num_key, result);
      break;
      }
      zend_hash_move_forward_ex((*subject)->value.ht,
                                (HashPosition *)((void *)0));
    }
  } else {
    if (argc > 3) {
      tmp___23 = & count;
    } else {
      tmp___23 = (int *)((void *)0);
    }
    php_str_replace_in_subject(*search, *replace, subject, return_value,
                               case_sensitivity, tmp___23);
  }
  if (argc > 3) {
    _zval_dtor(*zcount);
    __z = *zcount;
    __z->value.lval = (long )count;
    __z->type = (zend_uchar )1;
  } else {

  }
  return;
}
}
void zif_str_replace(int ht , zval *return_value , zval **return_value_ptr ,
                     zval *this_ptr , int return_value_used ) 
{ 


  {
  php_str_replace_common(ht, return_value, return_value_ptr, this_ptr,
                         return_value_used, 1);
  return;
}
}
void zif_str_ireplace(int ht , zval *return_value , zval **return_value_ptr ,
                      zval *this_ptr , int return_value_used ) 
{ 


  {
  php_str_replace_common(ht, return_value, return_value_ptr, this_ptr,
                         return_value_used, 0);
  return;
}
}
static void php_hebrev(int ht , zval *return_value , zval **return_value_ptr ,
                       zval *this_ptr , int return_value_used ,
                       int convert_newlines ) 
{ 
  char *str ;
  char *heb_str ;
  char *tmp ;
  char *target ;
  char *broken_str ;
  int block_start ;
  int block_end ;
  int block_type ;
  int block_length ;
  int i ;
  long max_chars ;
  int begin ;
  int end ;
  int char_count ;
  int orig_begin ;
  int str_len ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval *__z ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  unsigned short const   **tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;
  unsigned short const   **tmp___8 ;
  void __attribute__((__visibility__("default")))  *tmp___9 ;
  int tmp___10 ;
  int tmp___11 ;
  int new_char_count ;
  int new_begin ;
  int tmp___12 ;
  int tmp___13 ;
  int tmp___14 ;
  int tmp___15 ;
  int tmp___16 ;

  {
  max_chars = 0L;
  tmp___0 = zend_parse_parameters(ht, "s|l", & str, & str_len, & max_chars);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (str_len == 0) {
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  tmp = str;
  block_end = 0;
  block_start = block_end;
  tmp___1 = _emalloc((size_t )(str_len + 1));
  heb_str = (char *)tmp___1;
  target = heb_str + str_len;
  *target = (char)0;
  target --;
  block_length = 0;
  if ((int )((unsigned char )*tmp) >= 224) {
    if ((int )((unsigned char )*tmp) <= 250) {
      tmp___2 = 1;
    } else {
      tmp___2 = 0;
    }
  } else {
    tmp___2 = 0;
  }
  if (tmp___2) {
    block_type = 2;
  } else {
    block_type = 1;
  }
  while (1) {
    if (block_type == 2) {
      while (1) {
        if ((int )((unsigned char )((int )*(tmp + 1))) >= 224) {
          if ((int )((unsigned char )((int )*(tmp + 1))) <= 250) {
            tmp___3 = 1;
          } else {
            tmp___3 = 0;
          }
        } else {
          tmp___3 = 0;
        }
        if (tmp___3) {
          goto _L;
        } else {
          if ((int )((unsigned char )((int )*(tmp + 1))) == 32) {
            tmp___4 = 1;
          } else
          if ((int )((unsigned char )((int )*(tmp + 1))) == 9) {
            tmp___4 = 1;
          } else {
            tmp___4 = 0;
          }
          if (tmp___4) {
            goto _L;
          } else {
            tmp___5 = __ctype_b_loc();
            if ((int const   )*(*tmp___5 + (int )*(tmp + 1)) & 4) {
              goto _L;
            } else
            if ((int )*(tmp + 1) == 10) {
              _L: 
              if (! (block_end < str_len - 1)) {
                break;
              } else {

              }
            } else {
              break;
            }
          }
        }
        tmp ++;
        block_end ++;
        block_length ++;
      }
      i = block_start;
      while (i <= block_end) {
        *target = *(str + i);
        switch ((int )*target) {
        case 40: 
        *target = (char )')';
        break;
        case 41: 
        *target = (char )'(';
        break;
        case 91: 
        *target = (char )']';
        break;
        case 93: 
        *target = (char )'[';
        break;
        case 123: 
        *target = (char )'}';
        break;
        case 125: 
        *target = (char )'{';
        break;
        case 60: 
        *target = (char )'>';
        break;
        case 62: 
        *target = (char )'<';
        break;
        case 92: 
        *target = (char )'/';
        break;
        case 47: 
        *target = (char )'\\';
        break;
        default: 
        break;
        }
        target --;
        i ++;
      }
      block_type = 1;
    } else {
      while (1) {
        if ((int )((unsigned char )*(tmp + 1)) >= 224) {
          if ((int )((unsigned char )*(tmp + 1)) <= 250) {
            tmp___6 = 1;
          } else {
            tmp___6 = 0;
          }
        } else {
          tmp___6 = 0;
        }
        if (tmp___6) {
          break;
        } else
        if ((int )*(tmp + 1) != 10) {
          if (! (block_end < str_len - 1)) {
            break;
          } else {

          }
        } else {
          break;
        }
        tmp ++;
        block_end ++;
        block_length ++;
      }
      while (1) {
        if ((int )((unsigned char )((int )*tmp)) == 32) {
          tmp___7 = 1;
        } else
        if ((int )((unsigned char )((int )*tmp)) == 9) {
          tmp___7 = 1;
        } else {
          tmp___7 = 0;
        }
        if (tmp___7) {
          goto _L___0;
        } else {
          tmp___8 = __ctype_b_loc();
          if ((int const   )*(*tmp___8 + (int )*tmp) & 4) {
            _L___0: 
            if ((int )*tmp != 47) {
              if ((int )*tmp != 45) {
                if (! (block_end > block_start)) {
                  break;
                } else {

                }
              } else {
                break;
              }
            } else {
              break;
            }
          } else {
            break;
          }
        }
        tmp --;
        block_end --;
      }
      i = block_end;
      while (i >= block_start) {
        *target = *(str + i);
        target --;
        i --;
      }
      block_type = 2;
    }
    block_start = block_end + 1;
    if (! (block_end < str_len - 1)) {
      break;
    } else {

    }
  }
  tmp___9 = _emalloc((size_t )(str_len + 1));
  broken_str = (char *)tmp___9;
  end = str_len - 1;
  begin = end;
  target = broken_str;
  while (1) {
    char_count = 0;
    while (1) {
      if (! max_chars) {
        goto _L___2;
      } else
      if ((long )char_count < max_chars) {
        _L___2: 
        if (! (begin > 0)) {
          break;
        } else {

        }
      } else {
        break;
      }
      char_count ++;
      begin --;
      if (begin <= 0) {
        goto _L___1;
      } else {
        if ((int )((unsigned char )*(heb_str + begin)) == 10) {
          tmp___11 = 1;
        } else
        if ((int )((unsigned char )*(heb_str + begin)) == 13) {
          tmp___11 = 1;
        } else {
          tmp___11 = 0;
        }
        if (tmp___11) {
          _L___1: 
          while (1) {
            if (begin > 0) {
              if ((int )((unsigned char )*(heb_str + (begin - 1))) == 10) {
                tmp___10 = 1;
              } else
              if ((int )((unsigned char )*(heb_str + (begin - 1))) == 13) {
                tmp___10 = 1;
              } else {
                tmp___10 = 0;
              }
              if (! tmp___10) {
                break;
              } else {

              }
            } else {
              break;
            }
            begin --;
            char_count ++;
          }
          break;
        } else {

        }
      }
    }
    if ((long )char_count == max_chars) {
      new_char_count = char_count;
      new_begin = begin;
      while (new_char_count > 0) {
        if ((int )((unsigned char )*(heb_str + new_begin)) == 32) {
          tmp___12 = 1;
        } else
        if ((int )((unsigned char )*(heb_str + new_begin)) == 9) {
          tmp___12 = 1;
        } else {
          tmp___12 = 0;
        }
        if (tmp___12) {
          break;
        } else {
          if ((int )((unsigned char )*(heb_str + new_begin)) == 10) {
            tmp___13 = 1;
          } else
          if ((int )((unsigned char )*(heb_str + new_begin)) == 13) {
            tmp___13 = 1;
          } else {
            tmp___13 = 0;
          }
          if (tmp___13) {
            break;
          } else {

          }
        }
        new_begin ++;
        new_char_count --;
      }
      if (new_char_count > 0) {
        char_count = new_char_count;
        begin = new_begin;
      } else {

      }
    } else {

    }
    orig_begin = begin;
    if ((int )((unsigned char )*(heb_str + begin)) == 32) {
      tmp___14 = 1;
    } else
    if ((int )((unsigned char )*(heb_str + begin)) == 9) {
      tmp___14 = 1;
    } else {
      tmp___14 = 0;
    }
    if (tmp___14) {
      *(heb_str + begin) = (char )'\n';
    } else {

    }
    while (1) {
      if (begin <= end) {
        if ((int )((unsigned char )*(heb_str + begin)) == 10) {
          tmp___15 = 1;
        } else
        if ((int )((unsigned char )*(heb_str + begin)) == 13) {
          tmp___15 = 1;
        } else {
          tmp___15 = 0;
        }
        if (! tmp___15) {
          break;
        } else {

        }
      } else {
        break;
      }
      begin ++;
    }
    i = begin;
    while (i <= end) {
      *target = *(heb_str + i);
      target ++;
      i ++;
    }
    i = orig_begin;
    while (1) {
      if (i <= end) {
        if ((int )((unsigned char )*(heb_str + i)) == 10) {
          tmp___16 = 1;
        } else
        if ((int )((unsigned char )*(heb_str + i)) == 13) {
          tmp___16 = 1;
        } else {
          tmp___16 = 0;
        }
        if (! tmp___16) {
          break;
        } else {

        }
      } else {
        break;
      }
      *target = *(heb_str + i);
      target ++;
      i ++;
    }
    begin = orig_begin;
    if (begin <= 0) {
      *target = (char)0;
      break;
    } else {

    }
    begin --;
    end = begin;
  }
  _efree((void *)heb_str);
  if (convert_newlines) {
    php_char_to_str(broken_str, (uint )str_len, (char )'\n', (char *)"<br />\n",
                    7, return_value);
    _efree((void *)broken_str);
  } else {
    return_value->value.str.val = broken_str;
    return_value->value.str.len = str_len;
    return_value->type = (zend_uchar )6;
  }
  return;
}
}
void zif_hebrev(int ht , zval *return_value , zval **return_value_ptr ,
                zval *this_ptr , int return_value_used ) 
{ 


  {
  php_hebrev(ht, return_value, return_value_ptr, this_ptr, return_value_used, 0);
  return;
}
}
void zif_hebrevc(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) 
{ 


  {
  php_hebrev(ht, return_value, return_value_ptr, this_ptr, return_value_used, 1);
  return;
}
}
void zif_nl2br(int ht , zval *return_value , zval **return_value_ptr ,
               zval *this_ptr , int return_value_used ) 
{ 
  char *tmp ;
  char *str ;
  int new_length ;
  char *end ;
  char *target ;
  int repl_cnt ;
  int str_len ;
  zend_bool is_xhtml ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  void __attribute__((__visibility__("default")))  *tmp___2 ;
  char *tmp___3 ;
  char *tmp___4 ;
  char *tmp___5 ;
  char *tmp___6 ;
  char *tmp___7 ;
  char *tmp___8 ;
  char *tmp___9 ;
  char *tmp___10 ;
  char *tmp___11 ;
  char const   *__s___0 ;
  int __l___0 ;
  zval *__z___0 ;

  {
  repl_cnt = 0;
  is_xhtml = (zend_bool )1;
  tmp___0 = zend_parse_parameters(ht, "s|b", & str, & str_len, & is_xhtml);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  tmp = str;
  end = str + str_len;
  while ((unsigned long )tmp < (unsigned long )end) {
    if ((int )*tmp == 13) {
      if ((int )*(tmp + 1) == 10) {
        tmp ++;
      } else {

      }
      repl_cnt ++;
    } else
    if ((int )*tmp == 10) {
      if ((int )*(tmp + 1) == 13) {
        tmp ++;
      } else {

      }
      repl_cnt ++;
    } else {

    }
    tmp ++;
  }
  if (repl_cnt == 0) {
    while (1) {
      __s = (char const   *)str;
      __l = str_len;
      __z = return_value;
      __z->value.str.len = __l;
      tmp___1 = _estrndup(__s, (unsigned int )__l);
      __z->value.str.val = (char *)tmp___1;
      __z->type = (zend_uchar )6;
      break;
    }
    return;
  } else {

  }
  if (is_xhtml) {
    new_length = (int )((unsigned long )str_len + (unsigned long )repl_cnt * (sizeof("<br />") - 1UL));
  } else {
    new_length = (int )((unsigned long )str_len + (unsigned long )repl_cnt * (sizeof("<br>") - 1UL));
  }
  tmp___2 = _emalloc((size_t )(new_length + 1));
  target = (char *)tmp___2;
  tmp = target;
  while ((unsigned long )str < (unsigned long )end) {
    switch ((int )*str) {
    case 13: 
    case 10: 
    tmp___3 = target;
    target ++;
    *tmp___3 = (char )'<';
    tmp___4 = target;
    target ++;
    *tmp___4 = (char )'b';
    tmp___5 = target;
    target ++;
    *tmp___5 = (char )'r';
    if (is_xhtml) {
      tmp___6 = target;
      target ++;
      *tmp___6 = (char )' ';
      tmp___7 = target;
      target ++;
      *tmp___7 = (char )'/';
    } else {

    }
    tmp___8 = target;
    target ++;
    *tmp___8 = (char )'>';
    if ((int )*str == 13) {
      if ((int )*(str + 1) == 10) {
        tmp___9 = target;
        target ++;
        tmp___10 = str;
        str ++;
        *tmp___9 = *tmp___10;
      } else {
        goto _L;
      }
    } else
    _L: 
    if ((int )*str == 10) {
      if ((int )*(str + 1) == 13) {
        tmp___9 = target;
        target ++;
        tmp___10 = str;
        str ++;
        *tmp___9 = *tmp___10;
      } else {

      }
    } else {

    }
    default: 
    tmp___11 = target;
    target ++;
    *tmp___11 = *str;
    }
    str ++;
  }
  *target = (char )'\000';
  while (1) {
    __s___0 = (char const   *)tmp;
    __l___0 = new_length;
    __z___0 = return_value;
    __z___0->value.str.len = __l___0;
    __z___0->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s___0));
    __z___0->type = (zend_uchar )6;
    break;
  }
  return;
}
}
void zif_strip_tags(int ht , zval *return_value , zval **return_value_ptr ,
                    zval *this_ptr , int return_value_used ) 
{ 
  char *buf ;
  char *str ;
  zval **allow ;
  char *allowed_tags ;
  int allowed_tags_len ;
  int str_len ;
  size_t retval_len ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *new_zv ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  zend_uint tmp___1 ;
  zend_bool tmp___2 ;
  char __attribute__((__visibility__("default")))  *tmp___3 ;
  size_t __attribute__((__visibility__("default")))  tmp___4 ;
  char const   *__s ;
  int __l ;
  zval *__z ;

  {
  allow = (zval **)((void *)0);
  allowed_tags = (char *)((void *)0);
  allowed_tags_len = 0;
  tmp = zend_parse_parameters(ht, "s|Z", & str, & str_len, & allow);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if ((unsigned long )allow != (unsigned long )((void *)0)) {
    if ((int )(*allow)->type != 6) {
      tmp___2 = zval_isref_p(*allow);
      if (! tmp___2) {
        while (1) {
          tmp___1 = zval_refcount_p(*allow);
          if (tmp___1 > 1U) {
            zval_delref_p(*allow);
            while (1) {
              tmp___0 = _emalloc(sizeof(zval_gc_info ));
              new_zv = (zval *)tmp___0;
              ((zval_gc_info *)new_zv)->u.buffered = (gc_root_buffer *)((void *)0);
              break;
            }
            while (1) {
              while (1) {
                new_zv->value = (*allow)->value;
                new_zv->type = (*allow)->type;
                break;
              }
              zval_set_refcount_p(new_zv, (zend_uint )1);
              zval_unset_isref_p(new_zv);
              break;
            }
            *allow = new_zv;
            _zval_copy_ctor(new_zv);
          } else {

          }
          break;
        }
      } else {

      }
      if ((int )(*allow)->type != 6) {
        _convert_to_string(*allow);
      } else {

      }
    } else {

    }
    allowed_tags = (*allow)->value.str.val;
    allowed_tags_len = (*allow)->value.str.len;
  } else {

  }
  tmp___3 = _estrndup((char const   *)str, (unsigned int )str_len);
  buf = (char *)tmp___3;
  tmp___4 = php_strip_tags_ex(buf, str_len, (int *)((void *)0), allowed_tags,
                              allowed_tags_len, (zend_bool )0);
  retval_len = (size_t )tmp___4;
  while (1) {
    __s = (char const   *)buf;
    __l = (int )retval_len;
    __z = return_value;
    __z->value.str.len = __l;
    __z->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z->type = (zend_uchar )6;
    break;
  }
  return;
}
}
void zif_setlocale(int ht , zval *return_value , zval **return_value_ptr ,
                   zval *this_ptr , int return_value_used ) 
{ 
  zval ***args ;
  zval **pcategory ;
  zval **plocale ;
  int num_args ;
  int cat ;
  int i ;
  char *loc ;
  char *retval ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *new_zv ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  zend_uint tmp___1 ;
  zend_bool tmp___2 ;
  char *category ;
  zval *new_zv___0 ;
  void __attribute__((__visibility__("default")))  *tmp___3 ;
  zend_uint tmp___4 ;
  zend_bool tmp___5 ;
  zval *__z ;
  int tmp___6 ;
  int tmp___7 ;
  int tmp___8 ;
  int tmp___9 ;
  int tmp___10 ;
  int tmp___11 ;
  int tmp___12 ;
  int __attribute__((__visibility__("default")))  tmp___13 ;
  zval *new_zv___1 ;
  void __attribute__((__visibility__("default")))  *tmp___14 ;
  zend_uint tmp___15 ;
  zend_bool tmp___16 ;
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp___18 ;
  int tmp___21 ;
  int tmp___22 ;
  int tmp___23 ;
  char __attribute__((__visibility__("default")))  *tmp___24 ;
  char const   *__s ;
  zval *__z___0 ;
  size_t tmp___25 ;
  char __attribute__((__visibility__("default")))  *tmp___26 ;
  int __attribute__((__visibility__("default")))  tmp___27 ;
  zval *__z___1 ;

  {
  args = (zval ***)((void *)0);
  i = 0;
  tmp = zend_parse_parameters(ht, "Z+", & pcategory, & args, & num_args);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if ((int )(*pcategory)->type == 1) {
    if ((int )(*pcategory)->type != 1) {
      tmp___2 = zval_isref_p(*pcategory);
      if (! tmp___2) {
        while (1) {
          tmp___1 = zval_refcount_p(*pcategory);
          if (tmp___1 > 1U) {
            zval_delref_p(*pcategory);
            while (1) {
              tmp___0 = _emalloc(sizeof(zval_gc_info ));
              new_zv = (zval *)tmp___0;
              ((zval_gc_info *)new_zv)->u.buffered = (gc_root_buffer *)((void *)0);
              break;
            }
            while (1) {
              while (1) {
                new_zv->value = (*pcategory)->value;
                new_zv->type = (*pcategory)->type;
                break;
              }
              zval_set_refcount_p(new_zv, (zend_uint )1);
              zval_unset_isref_p(new_zv);
              break;
            }
            *pcategory = new_zv;
            _zval_copy_ctor(new_zv);
          } else {

          }
          break;
        }
      } else {

      }
      convert_to_long(*pcategory);
    } else {

    }
    cat = (int )(*pcategory)->value.lval;
  } else {
    php_error_docref0((char const   *)((void *)0), 1 << 13L,
                      "Passing locale category name as string is deprecated. Use the LC_* -constants instead");
    if ((int )(*pcategory)->type != 6) {
      tmp___5 = zval_isref_p(*pcategory);
      if (! tmp___5) {
        while (1) {
          tmp___4 = zval_refcount_p(*pcategory);
          if (tmp___4 > 1U) {
            zval_delref_p(*pcategory);
            while (1) {
              tmp___3 = _emalloc(sizeof(zval_gc_info ));
              new_zv___0 = (zval *)tmp___3;
              ((zval_gc_info *)new_zv___0)->u.buffered = (gc_root_buffer *)((void *)0);
              break;
            }
            while (1) {
              while (1) {
                new_zv___0->value = (*pcategory)->value;
                new_zv___0->type = (*pcategory)->type;
                break;
              }
              zval_set_refcount_p(new_zv___0, (zend_uint )1);
              zval_unset_isref_p(new_zv___0);
              break;
            }
            *pcategory = new_zv___0;
            _zval_copy_ctor(new_zv___0);
          } else {

          }
          break;
        }
      } else {

      }
      if ((int )(*pcategory)->type != 6) {
        _convert_to_string(*pcategory);
      } else {

      }
    } else {

    }
    category = (*pcategory)->value.str.val;
    tmp___12 = strcasecmp("LC_ALL", (char const   *)category);
    if (tmp___12) {
      tmp___11 = strcasecmp("LC_COLLATE", (char const   *)category);
      if (tmp___11) {
        tmp___10 = strcasecmp("LC_CTYPE", (char const   *)category);
        if (tmp___10) {
          tmp___9 = strcasecmp("LC_MESSAGES", (char const   *)category);
          if (tmp___9) {
            tmp___8 = strcasecmp("LC_MONETARY", (char const   *)category);
            if (tmp___8) {
              tmp___7 = strcasecmp("LC_NUMERIC", (char const   *)category);
              if (tmp___7) {
                tmp___6 = strcasecmp("LC_TIME", (char const   *)category);
                if (tmp___6) {
                  php_error_docref0((char const   *)((void *)0), 1 << 1L,
                                    "Invalid locale category name %s, must be one of LC_ALL, LC_COLLATE, LC_CTYPE, LC_MONETARY, LC_NUMERIC, or LC_TIME",
                                    category);
                  if (args) {
                    _efree((void *)args);
                  } else {

                  }
                  while (1) {
                    __z = return_value;
                    __z->value.lval = 0L;
                    __z->type = (zend_uchar )3;
                    break;
                  }
                  return;
                } else {
                  cat = 2;
                }
              } else {
                cat = 1;
              }
            } else {
              cat = 4;
            }
          } else {
            cat = 5;
          }
        } else {
          cat = 0;
        }
      } else {
        cat = 3;
      }
    } else {
      cat = 6;
    }
  }
  if ((int )(*(*(args + 0)))->type == 4) {
    zend_hash_internal_pointer_reset_ex((*(*(args + 0)))->value.ht,
                                        (HashPosition *)((void *)0));
  } else {

  }
  while (1) {
    if ((int )(*(*(args + 0)))->type == 4) {
      tmp___13 = zend_hash_num_elements((HashTable const   *)(*(*(args + 0)))->value.ht);
      if (! tmp___13) {
        break;
      } else {

      }
      zend_hash_get_current_data_ex((*(*(args + 0)))->value.ht,
                                    (void **)(& plocale),
                                    (HashPosition *)((void *)0));
    } else {
      plocale = *(args + i);
    }
    if ((int )(*plocale)->type != 6) {
      tmp___16 = zval_isref_p(*plocale);
      if (! tmp___16) {
        while (1) {
          tmp___15 = zval_refcount_p(*plocale);
          if (tmp___15 > 1U) {
            zval_delref_p(*plocale);
            while (1) {
              tmp___14 = _emalloc(sizeof(zval_gc_info ));
              new_zv___1 = (zval *)tmp___14;
              ((zval_gc_info *)new_zv___1)->u.buffered = (gc_root_buffer *)((void *)0);
              break;
            }
            while (1) {
              while (1) {
                new_zv___1->value = (*plocale)->value;
                new_zv___1->type = (*plocale)->type;
                break;
              }
              zval_set_refcount_p(new_zv___1, (zend_uint )1);
              zval_unset_isref_p(new_zv___1);
              break;
            }
            *plocale = new_zv___1;
            _zval_copy_ctor(new_zv___1);
          } else {

          }
          break;
        }
      } else {

      }
      if ((int )(*plocale)->type != 6) {
        _convert_to_string(*plocale);
      } else {

      }
    } else {

    }
    if (0) {
      __s1_len = __builtin_strlen("0");
      __s2_len = __builtin_strlen((char const   *)(*plocale)->value.str.val);
      if (! ((size_t )((void const   *)("0" + 1)) - (size_t )((void const   *)"0") == 1UL)) {
        goto _L___0;
      } else
      if (__s1_len >= 4UL) {
        _L___0: 
        if (! ((size_t )((void const   *)((*plocale)->value.str.val + 1)) - (size_t )((void const   *)(*plocale)->value.str.val) == 1UL)) {
          tmp___23 = 1;
        } else
        if (__s2_len >= 4UL) {
          tmp___23 = 1;
        } else {
          tmp___23 = 0;
        }
      } else {
        tmp___23 = 0;
      }
      if (tmp___23) {
        tmp___18 = __builtin_strcmp("0",
                                    (char const   *)(*plocale)->value.str.val);
        tmp___22 = tmp___18;
      } else {
        tmp___21 = __builtin_strcmp("0",
                                    (char const   *)(*plocale)->value.str.val);
        tmp___22 = tmp___21;
      }
    } else {
      tmp___21 = __builtin_strcmp("0", (char const   *)(*plocale)->value.str.val);
      tmp___22 = tmp___21;
    }
    if (tmp___22) {
      loc = (*plocale)->value.str.val;
      if ((*plocale)->value.str.len >= 255) {
        php_error_docref0((char const   *)((void *)0), 1 << 1L,
                          "Specified locale name is too long");
        break;
      } else {

      }
    } else {
      loc = (char *)((void *)0);
    }
    retval = setlocale(cat, (char const   *)loc);
    if (retval) {
      if (loc) {
        if (basic_globals.locale_string) {
          if ((unsigned long )basic_globals.locale_string >= (unsigned long )compiler_globals.interned_strings_start) {
            if (! ((unsigned long )basic_globals.locale_string < (unsigned long )compiler_globals.interned_strings_end)) {
              _efree((void *)basic_globals.locale_string);
            } else {

            }
          } else {
            _efree((void *)basic_globals.locale_string);
          }
        } else {

        }
        tmp___24 = _estrdup((char const   *)retval);
        basic_globals.locale_string = (char *)tmp___24;
      } else {

      }
      if (args) {
        _efree((void *)args);
      } else {

      }
      while (1) {
        __s = (char const   *)retval;
        __z___0 = return_value;
        tmp___25 = strlen(__s);
        __z___0->value.str.len = (int )tmp___25;
        tmp___26 = _estrndup(__s, (unsigned int )__z___0->value.str.len);
        __z___0->value.str.val = (char *)tmp___26;
        __z___0->type = (zend_uchar )6;
        break;
      }
      return;
    } else {

    }
    if ((int )(*(*(args + 0)))->type == 4) {
      tmp___27 = zend_hash_move_forward_ex((*(*(args + 0)))->value.ht,
                                           (HashPosition *)((void *)0));
      if (tmp___27 == (int __attribute__((__visibility__("default")))  )-1) {
        break;
      } else {

      }
    } else {
      i ++;
      if (i >= num_args) {
        break;
      } else {

      }
    }
  }
  if (args) {
    _efree((void *)args);
  } else {

  }
  while (1) {
    __z___1 = return_value;
    __z___1->value.lval = 0L;
    __z___1->type = (zend_uchar )3;
    break;
  }
  return;
}
}
void zif_parse_str(int ht , zval *return_value , zval **return_value_ptr ,
                   zval *this_ptr , int return_value_used ) 
{ 
  char *arg ;
  zval *arrayArg ;
  char *res ;
  int arglen ;
  int __attribute__((__visibility__("default")))  tmp ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  zval tmp___1 ;
  zval ret ;

  {
  arrayArg = (zval *)((void *)0);
  res = (char *)((void *)0);
  tmp = zend_parse_parameters(ht, "s|z", & arg, & arglen, & arrayArg);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  tmp___0 = _estrndup((char const   *)arg, (unsigned int )arglen);
  res = (char *)tmp___0;
  if ((unsigned long )arrayArg == (unsigned long )((void *)0)) {
    if (! executor_globals.active_symbol_table) {
      zend_rebuild_symbol_table();
    } else {

    }
    tmp___1.value.ht = executor_globals.active_symbol_table;
    (*(sapi_module.treat_data))(3, res, & tmp___1);
  } else {
    _array_init(& ret, (uint )0);
    (*(sapi_module.treat_data))(3, res, & ret);
    _zval_dtor(arrayArg);
    while (1) {
      arrayArg->value = ret.value;
      arrayArg->type = ret.type;
      break;
    }
  }
  return;
}
}
int php_tag_find(char *tag , int len , char *set ) 
{ 
  char c ;
  char *n ;
  char *t ;
  int state ;
  int done ;
  char *norm ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __res ;
  int __attribute__((__gnu_inline__))  tmp___1 ;
  __int32_t const   **tmp___2 ;
  char *tmp___3 ;
  char *tmp___4 ;
  unsigned short const   **tmp___5 ;
  int __res___0 ;
  int __attribute__((__gnu_inline__))  tmp___7 ;
  __int32_t const   **tmp___8 ;
  char *tmp___9 ;
  char *tmp___10 ;

  {
  state = 0;
  done = 0;
  if (len <= 0) {
    return (0);
  } else {

  }
  tmp = _emalloc((size_t )(len + 1));
  norm = (char *)tmp;
  n = norm;
  t = tag;
  if (sizeof(*t) > 1UL) {
    tmp___1 = tolower((int )*t);
    __res = (int )tmp___1;
  } else {
    tmp___2 = __ctype_tolower_loc();
    __res = (int )*(*tmp___2 + (int )*t);
  }
  c = (char )__res;
  while (! done) {
    switch ((int )c) {
    case 60: 
    tmp___3 = n;
    n ++;
    *tmp___3 = c;
    break;
    case 62: 
    done = 1;
    break;
    default: 
    tmp___5 = __ctype_b_loc();
    if ((int const   )*(*tmp___5 + (int )c) & 8192) {
      if (state == 1) {
        done = 1;
      } else {

      }
    } else {
      if (state == 0) {
        state = 1;
      } else {

      }
      if ((int )c != 47) {
        tmp___4 = n;
        n ++;
        *tmp___4 = c;
      } else {

      }
    }
    break;
    }
    if (sizeof(*t) > 1UL) {
      t ++;
      tmp___7 = tolower((int )*t);
      __res___0 = (int )tmp___7;
    } else {
      tmp___8 = __ctype_tolower_loc();
      t ++;
      __res___0 = (int )*(*tmp___8 + (int )*t);
    }
    c = (char )__res___0;
  }
  tmp___9 = n;
  n ++;
  *tmp___9 = (char )'>';
  *n = (char )'\000';
  tmp___10 = strstr((char const   *)set, (char const   *)norm);
  if (tmp___10) {
    done = 1;
  } else {
    done = 0;
  }
  _efree((void *)norm);
  return (done);
}
}
size_t __attribute__((__visibility__("default")))  php_strip_tags(char *rbuf ,
                                                                  int len ,
                                                                  int *stateptr ,
                                                                  char *allow ,
                                                                  int allow_len ) 
{ 
  size_t __attribute__((__visibility__("default")))  tmp ;

  {
  tmp = php_strip_tags_ex(rbuf, len, stateptr, allow, allow_len, (zend_bool )0);
  return (tmp);
}
}
size_t __attribute__((__visibility__("default")))  php_strip_tags_ex(char *rbuf ,
                                                                     int len ,
                                                                     int *stateptr ,
                                                                     char *allow ,
                                                                     int allow_len ,
                                                                     zend_bool allow_tag_spaces ) 
{ 
  char *tbuf ;
  char *buf ;
  char *p ;
  char *tp ;
  char *rp ;
  char c ;
  char lc ;
  int br ;
  int i ;
  int depth ;
  int in_q ;
  int state ;
  int pos ;
  char *allow_free ;
  char __attribute__((__visibility__("default")))  *tmp ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  unsigned short const   **tmp___2 ;
  void __attribute__((__visibility__("default")))  *tmp___3 ;
  char *tmp___4 ;
  void __attribute__((__visibility__("default")))  *tmp___5 ;
  char *tmp___6 ;
  char *tmp___7 ;
  void __attribute__((__visibility__("default")))  *tmp___8 ;
  char *tmp___9 ;
  char *tmp___10 ;
  void __attribute__((__visibility__("default")))  *tmp___11 ;
  char *tmp___12 ;
  int tmp___13 ;
  char *tmp___14 ;
  char *tmp___15 ;
  void __attribute__((__visibility__("default")))  *tmp___16 ;
  char *tmp___17 ;
  char *tmp___18 ;
  void __attribute__((__visibility__("default")))  *tmp___19 ;
  char *tmp___20 ;
  int __res ;
  int __attribute__((__gnu_inline__))  tmp___22 ;
  __int32_t const   **tmp___23 ;
  int __res___0 ;
  int __attribute__((__gnu_inline__))  tmp___25 ;
  __int32_t const   **tmp___26 ;
  int __res___1 ;
  int __attribute__((__gnu_inline__))  tmp___28 ;
  __int32_t const   **tmp___29 ;
  int __res___2 ;
  int __attribute__((__gnu_inline__))  tmp___31 ;
  __int32_t const   **tmp___32 ;
  int __res___3 ;
  int __attribute__((__gnu_inline__))  tmp___34 ;
  __int32_t const   **tmp___35 ;
  int __res___4 ;
  int __attribute__((__gnu_inline__))  tmp___37 ;
  __int32_t const   **tmp___38 ;
  int tmp___39 ;
  char *tmp___40 ;
  void __attribute__((__visibility__("default")))  *tmp___41 ;
  char *tmp___42 ;

  {
  i = 0;
  depth = 0;
  in_q = 0;
  state = 0;
  if (stateptr) {
    state = *stateptr;
  } else {

  }
  tmp = _estrndup((char const   *)rbuf, (unsigned int )len);
  buf = (char *)tmp;
  c = *buf;
  lc = (char )'\000';
  p = buf;
  rp = rbuf;
  br = 0;
  if (allow) {
    if ((unsigned long )allow >= (unsigned long )compiler_globals.interned_strings_start) {
      if ((unsigned long )allow < (unsigned long )compiler_globals.interned_strings_end) {
        tmp___0 = zend_str_tolower_dup((char const   *)allow,
                                       (unsigned int )allow_len);
        allow = (char *)tmp___0;
        allow_free = allow;
      } else {
        allow_free = (char *)((void *)0);
        php_strtolower(allow, (size_t )allow_len);
      }
    } else {
      allow_free = (char *)((void *)0);
      php_strtolower(allow, (size_t )allow_len);
    }
    tmp___1 = _emalloc((size_t )1024);
    tbuf = (char *)tmp___1;
    tp = tbuf;
  } else {
    tp = (char *)((void *)0);
    tbuf = tp;
  }
  while (i < len) {
    switch ((int )c) {
    case 0: 
    break;
    case 60: 
    if (in_q) {
      break;
    } else {

    }
    tmp___2 = __ctype_b_loc();
    if ((int const   )*(*tmp___2 + (int )*(p + 1)) & 8192) {
      if (! allow_tag_spaces) {
        goto reg_char;
      } else {

      }
    } else {

    }
    if (state == 0) {
      lc = (char )'<';
      state = 1;
      if (allow) {
        if (tp - tbuf >= 1023L) {
          pos = (int )(tp - tbuf);
          tmp___3 = _erealloc((void *)tbuf,
                              (size_t )(((tp - tbuf) + 1023L) + 1L), 0);
          tbuf = (char *)tmp___3;
          tp = tbuf + pos;
        } else {

        }
        tmp___4 = tp;
        tp ++;
        *tmp___4 = (char )'<';
      } else {

      }
    } else
    if (state == 1) {
      depth ++;
    } else {

    }
    break;
    case 40: 
    if (state == 2) {
      if ((int )lc != 34) {
        if ((int )lc != 39) {
          lc = (char )'(';
          br ++;
        } else {

        }
      } else {

      }
    } else
    if (allow) {
      if (state == 1) {
        if (tp - tbuf >= 1023L) {
          pos = (int )(tp - tbuf);
          tmp___5 = _erealloc((void *)tbuf,
                              (size_t )(((tp - tbuf) + 1023L) + 1L), 0);
          tbuf = (char *)tmp___5;
          tp = tbuf + pos;
        } else {

        }
        tmp___6 = tp;
        tp ++;
        *tmp___6 = c;
      } else {
        goto _L;
      }
    } else
    _L: 
    if (state == 0) {
      tmp___7 = rp;
      rp ++;
      *tmp___7 = c;
    } else {

    }
    break;
    case 41: 
    if (state == 2) {
      if ((int )lc != 34) {
        if ((int )lc != 39) {
          lc = (char )')';
          br --;
        } else {

        }
      } else {

      }
    } else
    if (allow) {
      if (state == 1) {
        if (tp - tbuf >= 1023L) {
          pos = (int )(tp - tbuf);
          tmp___8 = _erealloc((void *)tbuf,
                              (size_t )(((tp - tbuf) + 1023L) + 1L), 0);
          tbuf = (char *)tmp___8;
          tp = tbuf + pos;
        } else {

        }
        tmp___9 = tp;
        tp ++;
        *tmp___9 = c;
      } else {
        goto _L___0;
      }
    } else
    _L___0: 
    if (state == 0) {
      tmp___10 = rp;
      rp ++;
      *tmp___10 = c;
    } else {

    }
    break;
    case 62: 
    if (depth) {
      depth --;
      break;
    } else {

    }
    if (in_q) {
      break;
    } else {

    }
    switch (state) {
    case 1: 
    lc = (char )'>';
    state = 0;
    in_q = state;
    if (allow) {
      if (tp - tbuf >= 1023L) {
        pos = (int )(tp - tbuf);
        tmp___11 = _erealloc((void *)tbuf,
                             (size_t )(((tp - tbuf) + 1023L) + 1L), 0);
        tbuf = (char *)tmp___11;
        tp = tbuf + pos;
      } else {

      }
      tmp___12 = tp;
      tp ++;
      *tmp___12 = (char )'>';
      *tp = (char )'\000';
      tmp___13 = php_tag_find(tbuf, (int )(tp - tbuf), allow);
      if (tmp___13) {
        memcpy((void */* __restrict  */)rp,
               (void const   */* __restrict  */)tbuf, (size_t )(tp - tbuf));
        rp += tp - tbuf;
      } else {

      }
      tp = tbuf;
    } else {

    }
    break;
    case 2: 
    if (! br) {
      if ((int )lc != 34) {
        if ((int )*(p - 1) == 63) {
          state = 0;
          in_q = state;
          tp = tbuf;
        } else {

        }
      } else {

      }
    } else {

    }
    break;
    case 3: 
    state = 0;
    in_q = state;
    tp = tbuf;
    break;
    case 4: 
    if ((unsigned long )p >= (unsigned long )(buf + 2)) {
      if ((int )*(p - 1) == 45) {
        if ((int )*(p - 2) == 45) {
          state = 0;
          in_q = state;
          tp = tbuf;
        } else {

        }
      } else {

      }
    } else {

    }
    break;
    default: 
    tmp___14 = rp;
    rp ++;
    *tmp___14 = c;
    break;
    }
    break;
    case 34: 
    case 39: 
    if (state == 4) {
      break;
    } else
    if (state == 2) {
      if ((int )*(p - 1) != 92) {
        if ((int )lc == (int )c) {
          lc = (char )'\000';
        } else
        if ((int )lc != 92) {
          lc = c;
        } else {

        }
      } else {
        goto _L___1;
      }
    } else
    _L___1: 
    if (state == 0) {
      tmp___15 = rp;
      rp ++;
      *tmp___15 = c;
    } else
    if (allow) {
      if (state == 1) {
        if (tp - tbuf >= 1023L) {
          pos = (int )(tp - tbuf);
          tmp___16 = _erealloc((void *)tbuf,
                               (size_t )(((tp - tbuf) + 1023L) + 1L), 0);
          tbuf = (char *)tmp___16;
          tp = tbuf + pos;
        } else {

        }
        tmp___17 = tp;
        tp ++;
        *tmp___17 = c;
      } else {

      }
    } else {

    }
    if (state) {
      if ((unsigned long )p != (unsigned long )buf) {
        if (state == 1) {
          goto _L___3;
        } else
        if ((int )*(p - 1) != 92) {
          _L___3: 
          if (! in_q) {
            goto _L___2;
          } else
          if ((int )*p == in_q) {
            _L___2: 
            if (in_q) {
              in_q = 0;
            } else {
              in_q = (int )*p;
            }
          } else {

          }
        } else {

        }
      } else {

      }
    } else {

    }
    break;
    case 33: 
    if (state == 1) {
      if ((int )*(p - 1) == 60) {
        state = 3;
        lc = c;
      } else {
        goto _L___4;
      }
    } else
    _L___4: 
    if (state == 0) {
      tmp___18 = rp;
      rp ++;
      *tmp___18 = c;
    } else
    if (allow) {
      if (state == 1) {
        if (tp - tbuf >= 1023L) {
          pos = (int )(tp - tbuf);
          tmp___19 = _erealloc((void *)tbuf,
                               (size_t )(((tp - tbuf) + 1023L) + 1L), 0);
          tbuf = (char *)tmp___19;
          tp = tbuf + pos;
        } else {

        }
        tmp___20 = tp;
        tp ++;
        *tmp___20 = c;
      } else {

      }
    } else {

    }
    break;
    case 45: 
    if (state == 3) {
      if ((unsigned long )p >= (unsigned long )(buf + 2)) {
        if ((int )*(p - 1) == 45) {
          if ((int )*(p - 2) == 33) {
            state = 4;
          } else {
            goto reg_char;
          }
        } else {
          goto reg_char;
        }
      } else {
        goto reg_char;
      }
    } else {
      goto reg_char;
    }
    break;
    case 63: 
    if (state == 1) {
      if ((int )*(p - 1) == 60) {
        br = 0;
        state = 2;
        break;
      } else {

      }
    } else {

    }
    case 69: 
    case 101: 
    if (state == 3) {
      if ((unsigned long )p > (unsigned long )(buf + 6)) {
        if (sizeof(*(p - 1)) > 1UL) {
          tmp___22 = tolower((int )*(p - 1));
          __res = (int )tmp___22;
        } else {
          tmp___23 = __ctype_tolower_loc();
          __res = (int )*(*tmp___23 + (int )*(p - 1));
        }
        if (__res == 112) {
          if (sizeof(*(p - 2)) > 1UL) {
            tmp___25 = tolower((int )*(p - 2));
            __res___0 = (int )tmp___25;
          } else {
            tmp___26 = __ctype_tolower_loc();
            __res___0 = (int )*(*tmp___26 + (int )*(p - 2));
          }
          if (__res___0 == 121) {
            if (sizeof(*(p - 3)) > 1UL) {
              tmp___28 = tolower((int )*(p - 3));
              __res___1 = (int )tmp___28;
            } else {
              tmp___29 = __ctype_tolower_loc();
              __res___1 = (int )*(*tmp___29 + (int )*(p - 3));
            }
            if (__res___1 == 116) {
              if (sizeof(*(p - 4)) > 1UL) {
                tmp___31 = tolower((int )*(p - 4));
                __res___2 = (int )tmp___31;
              } else {
                tmp___32 = __ctype_tolower_loc();
                __res___2 = (int )*(*tmp___32 + (int )*(p - 4));
              }
              if (__res___2 == 99) {
                if (sizeof(*(p - 5)) > 1UL) {
                  tmp___34 = tolower((int )*(p - 5));
                  __res___3 = (int )tmp___34;
                } else {
                  tmp___35 = __ctype_tolower_loc();
                  __res___3 = (int )*(*tmp___35 + (int )*(p - 5));
                }
                if (__res___3 == 111) {
                  if (sizeof(*(p - 6)) > 1UL) {
                    tmp___37 = tolower((int )*(p - 6));
                    __res___4 = (int )tmp___37;
                  } else {
                    tmp___38 = __ctype_tolower_loc();
                    __res___4 = (int )*(*tmp___38 + (int )*(p - 6));
                  }
                  if (__res___4 == 100) {
                    state = 1;
                    break;
                  } else {

                  }
                } else {

                }
              } else {

              }
            } else {

            }
          } else {

          }
        } else {

        }
      } else {

      }
    } else {

    }
    case 108: 
    case 76: 
    if (state == 2) {
      if ((unsigned long )p > (unsigned long )(buf + 2)) {
        tmp___39 = strncasecmp((char const   *)(p - 2), "xm", (size_t )2);
        if (tmp___39 == 0) {
          state = 1;
          break;
        } else {

        }
      } else {

      }
    } else {

    }
    default: 
    reg_char: 
    if (state == 0) {
      tmp___40 = rp;
      rp ++;
      *tmp___40 = c;
    } else
    if (allow) {
      if (state == 1) {
        if (tp - tbuf >= 1023L) {
          pos = (int )(tp - tbuf);
          tmp___41 = _erealloc((void *)tbuf,
                               (size_t )(((tp - tbuf) + 1023L) + 1L), 0);
          tbuf = (char *)tmp___41;
          tp = tbuf + pos;
        } else {

        }
        tmp___42 = tp;
        tp ++;
        *tmp___42 = c;
      } else {

      }
    } else {

    }
    break;
    }
    p ++;
    c = *p;
    i ++;
  }
  if ((unsigned long )rp < (unsigned long )(rbuf + len)) {
    *rp = (char )'\000';
  } else {

  }
  _efree((void *)buf);
  if (allow) {
    _efree((void *)tbuf);
    if (allow_free) {
      _efree((void *)allow_free);
    } else {

    }
  } else {

  }
  if (stateptr) {
    *stateptr = state;
  } else {

  }
  return ((size_t __attribute__((__visibility__("default")))  )((size_t )(rp - rbuf)));
}
}
void zif_str_getcsv(int ht , zval *return_value , zval **return_value_ptr ,
                    zval *this_ptr , int return_value_used ) 
{ 
  char *str ;
  char delim ;
  char enc ;
  char esc ;
  char *delim_str ;
  char *enc_str ;
  char *esc_str ;
  int str_len ;
  int delim_len ;
  int enc_len ;
  int esc_len ;
  int __attribute__((__visibility__("default")))  tmp ;

  {
  delim = (char )',';
  enc = (char )'\"';
  esc = (char )'\\';
  delim_str = (char *)((void *)0);
  enc_str = (char *)((void *)0);
  esc_str = (char *)((void *)0);
  str_len = 0;
  delim_len = 0;
  enc_len = 0;
  esc_len = 0;
  tmp = zend_parse_parameters(ht, "s|sss", & str, & str_len, & delim_str,
                              & delim_len, & enc_str, & enc_len, & esc_str,
                              & esc_len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (delim_len) {
    delim = *(delim_str + 0);
  } else {
    delim = delim;
  }
  if (enc_len) {
    enc = *(enc_str + 0);
  } else {
    enc = enc;
  }
  if (esc_len) {
    esc = *(esc_str + 0);
  } else {
    esc = esc;
  }
  php_fgetcsv((php_stream *)((void *)0), delim, enc, esc, (size_t )str_len, str,
              return_value);
  return;
}
}
void zif_str_repeat(int ht , zval *return_value , zval **return_value_ptr ,
                    zval *this_ptr , int return_value_used ) 
{ 
  char *input_str ;
  int input_len ;
  long mult ;
  char *result ;
  size_t result_len ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  char *s ;
  char *e ;
  char *ee ;
  int l ;
  char const   *__s ;
  int __l ;
  zval *__z___0 ;

  {
  tmp = zend_parse_parameters(ht, "sl", & input_str, & input_len, & mult);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (mult < 0L) {
    php_error_docref0((char const   *)((void *)0), 1 << 1L,
                      "Second argument has to be greater than or equal to 0");
    return;
  } else {

  }
  if (input_len == 0) {
    goto _L;
  } else
  if (mult == 0L) {
    _L: 
    while (1) {
      __z = return_value;
      __z->value.str.len = 0;
      tmp___0 = _estrndup("", (unsigned int )(sizeof("") - 1UL));
      __z->value.str.val = (char *)tmp___0;
      __z->type = (zend_uchar )6;
      break;
    }
    return;
  } else {

  }
  result_len = (size_t )((long )input_len * mult);
  tmp___1 = _safe_emalloc((size_t )input_len, (size_t )mult, (size_t )1);
  result = (char *)tmp___1;
  if (input_len == 1) {
    memset((void *)result, (int )*input_str, (size_t )mult);
  } else {
    l = 0;
    memcpy((void */* __restrict  */)result,
           (void const   */* __restrict  */)input_str, (size_t )input_len);
    s = result;
    e = result + input_len;
    ee = result + result_len;
    while ((unsigned long )e < (unsigned long )ee) {
      if (e - s < ee - e) {
        l = (int )(e - s);
      } else {
        l = (int )(ee - e);
      }
      memmove((void *)e, (void const   *)s, (size_t )l);
      e += l;
    }
  }
  *(result + result_len) = (char )'\000';
  while (1) {
    __s = (char const   *)result;
    __l = (int )result_len;
    __z___0 = return_value;
    __z___0->value.str.len = __l;
    __z___0->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z___0->type = (zend_uchar )6;
    break;
  }
  return;
}
}
void zif_count_chars(int ht , zval *return_value , zval **return_value_ptr ,
                     zval *this_ptr , int return_value_used ) 
{ 
  char *input ;
  int chars[256] ;
  long mymode ;
  unsigned char *buf ;
  int len ;
  int inx ;
  char retstr[256] ;
  int retlen ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  int tmp___0 ;
  int tmp___1 ;
  char const   *__s ;
  int __l ;
  zval *__z___0 ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;

  {
  mymode = 0L;
  retlen = 0;
  tmp = zend_parse_parameters(ht, "s|l", & input, & len, & mymode);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (mymode < 0L) {
    goto _L;
  } else
  if (mymode > 4L) {
    _L: 
    php_error_docref0((char const   *)((void *)0), 1 << 1L, "Unknown mode");
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  buf = (unsigned char *)input;
  memset((void *)(chars), 0, sizeof(chars));
  while (len > 0) {
    (chars[*buf]) ++;
    buf ++;
    len --;
  }
  if (mymode < 3L) {
    _array_init(return_value, (uint )0);
  } else {

  }
  inx = 0;
  while (inx < 256) {
    switch (mymode) {
    case 0L: 
    add_index_long(return_value, (ulong )inx, (long )chars[inx]);
    break;
    case 1L: 
    if (chars[inx] != 0) {
      add_index_long(return_value, (ulong )inx, (long )chars[inx]);
    } else {

    }
    break;
    case 2L: 
    if (chars[inx] == 0) {
      add_index_long(return_value, (ulong )inx, (long )chars[inx]);
    } else {

    }
    break;
    case 3L: 
    if (chars[inx] != 0) {
      tmp___0 = retlen;
      retlen ++;
      retstr[tmp___0] = (char )inx;
    } else {

    }
    break;
    case 4L: 
    if (chars[inx] == 0) {
      tmp___1 = retlen;
      retlen ++;
      retstr[tmp___1] = (char )inx;
    } else {

    }
    break;
    }
    inx ++;
  }
  if (mymode >= 3L) {
    if (mymode <= 4L) {
      while (1) {
        __s = (char const   *)(retstr);
        __l = retlen;
        __z___0 = return_value;
        __z___0->value.str.len = __l;
        tmp___2 = _estrndup(__s, (unsigned int )__l);
        __z___0->value.str.val = (char *)tmp___2;
        __z___0->type = (zend_uchar )6;
        break;
      }
      return;
    } else {

    }
  } else {

  }
  return;
}
}
static void php_strnatcmp(int ht , zval *return_value ,
                          zval **return_value_ptr , zval *this_ptr ,
                          int return_value_used , int fold_case ) 
{ 
  char *s1 ;
  char *s2 ;
  int s1_len ;
  int s2_len ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = zend_parse_parameters(ht, "ss", & s1, & s1_len, & s2, & s2_len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  __z = return_value;
  tmp___0 = strnatcmp_ex((char const   *)s1, (size_t )s1_len,
                         (char const   *)s2, (size_t )s2_len, fold_case);
  __z->value.lval = (long )tmp___0;
  __z->type = (zend_uchar )1;
  return;
}
}
void zif_strnatcmp(int ht , zval *return_value , zval **return_value_ptr ,
                   zval *this_ptr , int return_value_used ) 
{ 


  {
  php_strnatcmp(ht, return_value, return_value_ptr, this_ptr, return_value_used,
                0);
  return;
}
}
void zif_localeconv(int ht , zval *return_value , zval **return_value_ptr ,
                    zval *this_ptr , int return_value_used ) 
{ 
  zval *grouping ;
  zval *mon_grouping ;
  int len ;
  int i ;
  int __attribute__((__visibility__("default")))  tmp ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  struct lconv currlocdata ;
  size_t tmp___2 ;
  size_t tmp___3 ;
  size_t tmp___4 ;
  size_t tmp___5 ;
  size_t tmp___6 ;
  size_t tmp___7 ;
  size_t tmp___8 ;
  size_t tmp___9 ;
  size_t tmp___10 ;
  size_t tmp___11 ;
  size_t tmp___12 ;
  size_t tmp___13 ;
  size_t tmp___14 ;
  size_t tmp___15 ;
  size_t tmp___16 ;
  size_t tmp___17 ;
  size_t tmp___18 ;
  size_t tmp___19 ;

  {
  tmp = zend_parse_parameters(ht, "");
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  while (1) {
    tmp___0 = _emalloc(sizeof(zval_gc_info ));
    grouping = (zval *)tmp___0;
    ((zval_gc_info *)grouping)->u.buffered = (gc_root_buffer *)((void *)0);
    break;
  }
  grouping->refcount__gc = (zend_uint )1;
  grouping->is_ref__gc = (zend_uchar )0;
  while (1) {
    tmp___1 = _emalloc(sizeof(zval_gc_info ));
    mon_grouping = (zval *)tmp___1;
    ((zval_gc_info *)mon_grouping)->u.buffered = (gc_root_buffer *)((void *)0);
    break;
  }
  mon_grouping->refcount__gc = (zend_uint )1;
  mon_grouping->is_ref__gc = (zend_uchar )0;
  _array_init(return_value, (uint )0);
  _array_init(grouping, (uint )0);
  _array_init(mon_grouping, (uint )0);
  localeconv_r(& currlocdata);
  tmp___2 = strlen((char const   *)currlocdata.grouping);
  len = (int )tmp___2;
  i = 0;
  while (i < len) {
    add_index_long(grouping, (ulong )i, (long )*(currlocdata.grouping + i));
    i ++;
  }
  tmp___3 = strlen((char const   *)currlocdata.mon_grouping);
  len = (int )tmp___3;
  i = 0;
  while (i < len) {
    add_index_long(mon_grouping, (ulong )i,
                   (long )*(currlocdata.mon_grouping + i));
    i ++;
  }
  tmp___4 = strlen("decimal_point");
  add_assoc_string_ex(return_value, "decimal_point", (uint )(tmp___4 + 1UL),
                      currlocdata.decimal_point, 1);
  tmp___5 = strlen("thousands_sep");
  add_assoc_string_ex(return_value, "thousands_sep", (uint )(tmp___5 + 1UL),
                      currlocdata.thousands_sep, 1);
  tmp___6 = strlen("int_curr_symbol");
  add_assoc_string_ex(return_value, "int_curr_symbol", (uint )(tmp___6 + 1UL),
                      currlocdata.int_curr_symbol, 1);
  tmp___7 = strlen("currency_symbol");
  add_assoc_string_ex(return_value, "currency_symbol", (uint )(tmp___7 + 1UL),
                      currlocdata.currency_symbol, 1);
  tmp___8 = strlen("mon_decimal_point");
  add_assoc_string_ex(return_value, "mon_decimal_point", (uint )(tmp___8 + 1UL),
                      currlocdata.mon_decimal_point, 1);
  tmp___9 = strlen("mon_thousands_sep");
  add_assoc_string_ex(return_value, "mon_thousands_sep", (uint )(tmp___9 + 1UL),
                      currlocdata.mon_thousands_sep, 1);
  tmp___10 = strlen("positive_sign");
  add_assoc_string_ex(return_value, "positive_sign", (uint )(tmp___10 + 1UL),
                      currlocdata.positive_sign, 1);
  tmp___11 = strlen("negative_sign");
  add_assoc_string_ex(return_value, "negative_sign", (uint )(tmp___11 + 1UL),
                      currlocdata.negative_sign, 1);
  tmp___12 = strlen("int_frac_digits");
  add_assoc_long_ex(return_value, "int_frac_digits", (uint )(tmp___12 + 1UL),
                    (long )currlocdata.int_frac_digits);
  tmp___13 = strlen("frac_digits");
  add_assoc_long_ex(return_value, "frac_digits", (uint )(tmp___13 + 1UL),
                    (long )currlocdata.frac_digits);
  tmp___14 = strlen("p_cs_precedes");
  add_assoc_long_ex(return_value, "p_cs_precedes", (uint )(tmp___14 + 1UL),
                    (long )currlocdata.p_cs_precedes);
  tmp___15 = strlen("p_sep_by_space");
  add_assoc_long_ex(return_value, "p_sep_by_space", (uint )(tmp___15 + 1UL),
                    (long )currlocdata.p_sep_by_space);
  tmp___16 = strlen("n_cs_precedes");
  add_assoc_long_ex(return_value, "n_cs_precedes", (uint )(tmp___16 + 1UL),
                    (long )currlocdata.n_cs_precedes);
  tmp___17 = strlen("n_sep_by_space");
  add_assoc_long_ex(return_value, "n_sep_by_space", (uint )(tmp___17 + 1UL),
                    (long )currlocdata.n_sep_by_space);
  tmp___18 = strlen("p_sign_posn");
  add_assoc_long_ex(return_value, "p_sign_posn", (uint )(tmp___18 + 1UL),
                    (long )currlocdata.p_sign_posn);
  tmp___19 = strlen("n_sign_posn");
  add_assoc_long_ex(return_value, "n_sign_posn", (uint )(tmp___19 + 1UL),
                    (long )currlocdata.n_sign_posn);
  _zend_hash_add_or_update(return_value->value.ht, "grouping", (uint )9,
                           (void *)(& grouping), (uint )sizeof(zval *),
                           (void **)((void *)0), 1);
  _zend_hash_add_or_update(return_value->value.ht, "mon_grouping", (uint )13,
                           (void *)(& mon_grouping), (uint )sizeof(zval *),
                           (void **)((void *)0), 1);
  return;
}
}
void zif_strnatcasecmp(int ht , zval *return_value , zval **return_value_ptr ,
                       zval *this_ptr , int return_value_used ) 
{ 


  {
  php_strnatcmp(ht, return_value, return_value_ptr, this_ptr, return_value_used,
                1);
  return;
}
}
void zif_substr_count(int ht , zval *return_value , zval **return_value_ptr ,
                      zval *this_ptr , int return_value_used ) 
{ 
  char *haystack ;
  char *needle ;
  long offset ;
  long length ;
  int ac ;
  int count ;
  int haystack_len ;
  int needle_len ;
  char *p ;
  char *endp ;
  char cmp ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  zval *__z___0 ;
  zval *__z___1 ;
  zval *__z___2 ;
  zval *__z___3 ;
  void *tmp___0 ;
  zval *__z___4 ;

  {
  offset = 0L;
  length = 0L;
  ac = ht;
  count = 0;
  tmp = zend_parse_parameters(ht, "ss|ll", & haystack, & haystack_len, & needle,
                              & needle_len, & offset, & length);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (needle_len == 0) {
    php_error_docref0((char const   *)((void *)0), 1 << 1L, "Empty substring");
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  p = haystack;
  endp = p + haystack_len;
  if (offset < 0L) {
    php_error_docref0((char const   *)((void *)0), 1 << 1L,
                      "Offset should be greater than or equal to 0");
    while (1) {
      __z___0 = return_value;
      __z___0->value.lval = 0L;
      __z___0->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  if (offset > (long )haystack_len) {
    php_error_docref0((char const   *)((void *)0), 1 << 1L,
                      "Offset value %ld exceeds string length", offset);
    while (1) {
      __z___1 = return_value;
      __z___1->value.lval = 0L;
      __z___1->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  p += offset;
  if (ac == 4) {
    if (length <= 0L) {
      php_error_docref0((char const   *)((void *)0), 1 << 1L,
                        "Length should be greater than 0");
      while (1) {
        __z___2 = return_value;
        __z___2->value.lval = 0L;
        __z___2->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    if (length > (long )haystack_len - offset) {
      php_error_docref0((char const   *)((void *)0), 1 << 1L,
                        "Length value %ld exceeds string length", length);
      while (1) {
        __z___3 = return_value;
        __z___3->value.lval = 0L;
        __z___3->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
    endp = p + length;
  } else {

  }
  if (needle_len == 1) {
    cmp = *(needle + 0);
    while (1) {
      tmp___0 = memchr((void const   *)p, (int )cmp, (size_t )(endp - p));
      p = (char *)tmp___0;
      if (! p) {
        break;
      } else {

      }
      count ++;
      p ++;
    }
  } else {
    while (1) {
      p = zend_memnstr(p, needle, needle_len, endp);
      if (! p) {
        break;
      } else {

      }
      p += needle_len;
      count ++;
    }
  }
  __z___4 = return_value;
  __z___4->value.lval = (long )count;
  __z___4->type = (zend_uchar )1;
  return;
}
}
void zif_str_pad(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) 
{ 
  char *input ;
  int input_len ;
  long pad_length ;
  size_t num_pad_chars ;
  char *result ;
  int result_len ;
  char *pad_str_val ;
  int pad_str_len ;
  long pad_type_val ;
  int i ;
  int left_pad ;
  int right_pad ;
  int __attribute__((__visibility__("default")))  tmp ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  char const   *__s___0 ;
  int __l___0 ;
  zval *__z___0 ;

  {
  result = (char *)((void *)0);
  result_len = 0;
  pad_str_val = (char *)" ";
  pad_str_len = 1;
  pad_type_val = 1L;
  left_pad = 0;
  right_pad = 0;
  tmp = zend_parse_parameters(ht, "sl|sl", & input, & input_len, & pad_length,
                              & pad_str_val, & pad_str_len, & pad_type_val);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (pad_length <= 0L) {
    goto _L;
  } else
  if (pad_length - (long )input_len <= 0L) {
    _L: 
    while (1) {
      __s = (char const   *)input;
      __l = input_len;
      __z = return_value;
      __z->value.str.len = __l;
      tmp___0 = _estrndup(__s, (unsigned int )__l);
      __z->value.str.val = (char *)tmp___0;
      __z->type = (zend_uchar )6;
      break;
    }
    return;
  } else {

  }
  if (pad_str_len == 0) {
    php_error_docref0((char const   *)((void *)0), 1 << 1L,
                      "Padding string cannot be empty");
    return;
  } else {

  }
  if (pad_type_val < 0L) {
    php_error_docref0((char const   *)((void *)0), 1 << 1L,
                      "Padding type has to be STR_PAD_LEFT, STR_PAD_RIGHT, or STR_PAD_BOTH");
    return;
  } else
  if (pad_type_val > 2L) {
    php_error_docref0((char const   *)((void *)0), 1 << 1L,
                      "Padding type has to be STR_PAD_LEFT, STR_PAD_RIGHT, or STR_PAD_BOTH");
    return;
  } else {

  }
  num_pad_chars = (size_t )(pad_length - (long )input_len);
  if (num_pad_chars >= 2147483647UL) {
    php_error_docref0((char const   *)((void *)0), 1 << 1L,
                      "Padding length is too long");
    return;
  } else {

  }
  tmp___1 = _emalloc(((size_t )input_len + num_pad_chars) + 1UL);
  result = (char *)tmp___1;
  switch (pad_type_val) {
  case 1L: 
  left_pad = 0;
  right_pad = (int )num_pad_chars;
  break;
  case 0L: 
  left_pad = (int )num_pad_chars;
  right_pad = 0;
  break;
  case 2L: 
  left_pad = (int )(num_pad_chars / 2UL);
  right_pad = (int )(num_pad_chars - (size_t )left_pad);
  break;
  }
  i = 0;
  while (i < left_pad) {
    tmp___2 = result_len;
    result_len ++;
    *(result + tmp___2) = *(pad_str_val + i % pad_str_len);
    i ++;
  }
  memcpy((void */* __restrict  */)(result + result_len),
         (void const   */* __restrict  */)input, (size_t )input_len);
  result_len += input_len;
  i = 0;
  while (i < right_pad) {
    tmp___3 = result_len;
    result_len ++;
    *(result + tmp___3) = *(pad_str_val + i % pad_str_len);
    i ++;
  }
  *(result + result_len) = (char )'\000';
  while (1) {
    __s___0 = (char const   *)result;
    __l___0 = result_len;
    __z___0 = return_value;
    __z___0->value.str.len = __l___0;
    __z___0->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s___0));
    __z___0->type = (zend_uchar )6;
    break;
  }
  return;
}
}
void zif_sscanf(int ht , zval *return_value , zval **return_value_ptr ,
                zval *this_ptr , int return_value_used ) 
{ 
  zval ***args ;
  char *str ;
  char *format ;
  int str_len ;
  int format_len ;
  int result ;
  int num_args ;
  int __attribute__((__visibility__("default")))  tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  args = (zval ***)((void *)0);
  num_args = 0;
  tmp = zend_parse_parameters(ht, "ss*", & str, & str_len, & format,
                              & format_len, & args, & num_args);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  tmp___0 = php_sscanf_internal(str, format, num_args, args, 0, & return_value);
  result = (int )tmp___0;
  if (args) {
    _efree((void *)args);
  } else {

  }
  if (-4 == result) {
    zend_wrong_param_count();
    return;
  } else {

  }
  return;
}
}
static char rot13_from[53]  = 
  {      (char )'a',      (char )'b',      (char )'c',      (char )'d', 
        (char )'e',      (char )'f',      (char )'g',      (char )'h', 
        (char )'i',      (char )'j',      (char )'k',      (char )'l', 
        (char )'m',      (char )'n',      (char )'o',      (char )'p', 
        (char )'q',      (char )'r',      (char )'s',      (char )'t', 
        (char )'u',      (char )'v',      (char )'w',      (char )'x', 
        (char )'y',      (char )'z',      (char )'A',      (char )'B', 
        (char )'C',      (char )'D',      (char )'E',      (char )'F', 
        (char )'G',      (char )'H',      (char )'I',      (char )'J', 
        (char )'K',      (char )'L',      (char )'M',      (char )'N', 
        (char )'O',      (char )'P',      (char )'Q',      (char )'R', 
        (char )'S',      (char )'T',      (char )'U',      (char )'V', 
        (char )'W',      (char )'X',      (char )'Y',      (char )'Z', 
        (char )'\000'};
static char rot13_to[53]  = 
  {      (char )'n',      (char )'o',      (char )'p',      (char )'q', 
        (char )'r',      (char )'s',      (char )'t',      (char )'u', 
        (char )'v',      (char )'w',      (char )'x',      (char )'y', 
        (char )'z',      (char )'a',      (char )'b',      (char )'c', 
        (char )'d',      (char )'e',      (char )'f',      (char )'g', 
        (char )'h',      (char )'i',      (char )'j',      (char )'k', 
        (char )'l',      (char )'m',      (char )'N',      (char )'O', 
        (char )'P',      (char )'Q',      (char )'R',      (char )'S', 
        (char )'T',      (char )'U',      (char )'V',      (char )'W', 
        (char )'X',      (char )'Y',      (char )'Z',      (char )'A', 
        (char )'B',      (char )'C',      (char )'D',      (char )'E', 
        (char )'F',      (char )'G',      (char )'H',      (char )'I', 
        (char )'J',      (char )'K',      (char )'L',      (char )'M', 
        (char )'\000'};
void zif_str_rot13(int ht , zval *return_value , zval **return_value_ptr ,
                   zval *this_ptr , int return_value_used ) 
{ 
  char *arg ;
  int arglen ;
  int __attribute__((__visibility__("default")))  tmp ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;

  {
  tmp = zend_parse_parameters(ht, "s", & arg, & arglen);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  while (1) {
    __s = (char const   *)arg;
    __l = arglen;
    __z = return_value;
    __z->value.str.len = __l;
    tmp___0 = _estrndup(__s, (unsigned int )__l);
    __z->value.str.val = (char *)tmp___0;
    __z->type = (zend_uchar )6;
    break;
  }
  php_strtr(return_value->value.str.val, return_value->value.str.len,
            rot13_from, rot13_to, 52);
  return;
}
}
static void php_string_shuffle(char *str , long len ) 
{ 
  long n_elems ;
  long rnd_idx ;
  long n_left ;
  char temp ;
  long __attribute__((__visibility__("default")))  tmp ;

  {
  n_elems = len;
  if (n_elems <= 1L) {
    return;
  } else {

  }
  n_left = n_elems;
  while (1) {
    n_left --;
    if (! n_left) {
      break;
    } else {

    }
    tmp = php_rand();
    rnd_idx = (long )tmp;
    rnd_idx = (long )((((double )n_left - (double )0) + 1.0) * ((double )rnd_idx / ((double )2147483647 + 1.0)));
    if (rnd_idx != n_left) {
      temp = *(str + n_left);
      *(str + n_left) = *(str + rnd_idx);
      *(str + rnd_idx) = temp;
    } else {

    }
  }
  return;
}
}
void zif_str_shuffle(int ht , zval *return_value , zval **return_value_ptr ,
                     zval *this_ptr , int return_value_used ) 
{ 
  char *arg ;
  int arglen ;
  int __attribute__((__visibility__("default")))  tmp ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;

  {
  tmp = zend_parse_parameters(ht, "s", & arg, & arglen);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  while (1) {
    __s = (char const   *)arg;
    __l = arglen;
    __z = return_value;
    __z->value.str.len = __l;
    tmp___0 = _estrndup(__s, (unsigned int )__l);
    __z->value.str.val = (char *)tmp___0;
    __z->type = (zend_uchar )6;
    break;
  }
  if (return_value->value.str.len > 1) {
    php_string_shuffle(return_value->value.str.val,
                       (long )return_value->value.str.len);
  } else {

  }
  return;
}
}
void zif_str_word_count(int ht , zval *return_value , zval **return_value_ptr ,
                        zval *this_ptr , int return_value_used ) 
{ 
  char *buf ;
  char *str ;
  char *char_list ;
  char *p ;
  char *e ;
  char *s ;
  char ch[256] ;
  int str_len ;
  int char_list_len ;
  int word_count ;
  long type ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  zval *__z___0 ;
  unsigned short const   **tmp___0 ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;
  zval *__z___1 ;

  {
  char_list = (char *)((void *)0);
  char_list_len = 0;
  word_count = 0;
  type = 0L;
  tmp = zend_parse_parameters(ht, "s|ls", & str, & str_len, & type, & char_list,
                              & char_list_len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  switch (type) {
  case 1L: 
  case 2L: 
  _array_init(return_value, (uint )0);
  if (! str_len) {
    return;
  } else {

  }
  break;
  case 0L: 
  if (! str_len) {
    __z = return_value;
    __z->value.lval = 0L;
    __z->type = (zend_uchar )1;
    return;
  } else {

  }
  break;
  default: 
  php_error_docref0((char const   *)((void *)0), 1 << 1L,
                    "Invalid format value %ld", type);
  while (1) {
    __z___0 = return_value;
    __z___0->value.lval = 0L;
    __z___0->type = (zend_uchar )3;
    break;
  }
  return;
  }
  if (char_list) {
    php_charmask((unsigned char *)char_list, char_list_len, ch);
  } else {

  }
  p = str;
  e = str + str_len;
  if ((int )*p == 39) {
    if (! char_list) {
      p ++;
    } else
    if (! ch[39]) {
      p ++;
    } else {
      goto _L;
    }
  } else
  _L: 
  if ((int )*p == 45) {
    if (! char_list) {
      p ++;
    } else
    if (! ch[45]) {
      p ++;
    } else {

    }
  } else {

  }
  if ((int )*(e - 1) == 45) {
    if (! char_list) {
      e --;
    } else
    if (! ch[45]) {
      e --;
    } else {

    }
  } else {

  }
  while ((unsigned long )p < (unsigned long )e) {
    s = p;
    while (1) {
      if ((unsigned long )p < (unsigned long )e) {
        tmp___0 = __ctype_b_loc();
        if (! ((int const   )*(*tmp___0 + (int )((unsigned char )*p)) & 1024)) {
          if (char_list) {
            if (! ch[(unsigned char )*p]) {
              goto _L___0;
            } else {

            }
          } else
          _L___0: 
          if (! ((int )*p == 39)) {
            if (! ((int )*p == 45)) {
              break;
            } else {

            }
          } else {

          }
        } else {

        }
      } else {
        break;
      }
      p ++;
    }
    if ((unsigned long )p > (unsigned long )s) {
      switch (type) {
      case 1L: 
      tmp___1 = _estrndup((char const   *)s, (unsigned int )(p - s));
      buf = (char *)tmp___1;
      add_next_index_stringl(return_value, (char const   *)buf, (uint )(p - s),
                             0);
      break;
      case 2L: 
      tmp___2 = _estrndup((char const   *)s, (unsigned int )(p - s));
      buf = (char *)tmp___2;
      add_index_stringl(return_value, (ulong )(s - str), (char const   *)buf,
                        (uint )(p - s), 0);
      break;
      default: 
      word_count ++;
      break;
      }
    } else {

    }
    p ++;
  }
  if (! type) {
    __z___1 = return_value;
    __z___1->value.lval = (long )word_count;
    __z___1->type = (zend_uchar )1;
    return;
  } else {

  }
  return;
}
}
void zif_money_format(int ht , zval *return_value , zval **return_value_ptr ,
                      zval *this_ptr , int return_value_used ) 
{ 
  int format_len ;
  int str_len ;
  char *format ;
  char *str ;
  char *p ;
  char *e ;
  double value ;
  zend_bool check ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  void *tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  zval *__z___0 ;
  ssize_t tmp___2 ;
  char const   *__s ;
  void __attribute__((__visibility__("default")))  *tmp___3 ;
  int __l ;
  zval *__z___1 ;

  {
  format_len = 0;
  check = (zend_bool )0;
  tmp = zend_parse_parameters(ht, "sd", & format, & format_len, & value);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  p = format;
  e = p + format_len;
  while (1) {
    tmp___0 = memchr((void const   *)p, '%', (size_t )(e - p));
    p = (char *)tmp___0;
    if (! p) {
      break;
    } else {

    }
    if ((int )*(p + 1) == 37) {
      p += 2;
    } else
    if (! check) {
      check = (zend_bool )1;
      p ++;
    } else {
      php_error_docref0((char const   *)((void *)0), 1 << 1L,
                        "Only a single %%i or %%n token can be used");
      while (1) {
        __z = return_value;
        __z->value.lval = 0L;
        __z->type = (zend_uchar )3;
        break;
      }
      return;
    }
  }
  str_len = format_len + 1024;
  tmp___1 = _emalloc((size_t )str_len);
  str = (char *)tmp___1;
  tmp___2 = strfmon((char */* __restrict  */)str, (size_t )str_len,
                    (char const   */* __restrict  */)format, value);
  str_len = (int )tmp___2;
  if (str_len < 0) {
    _efree((void *)str);
    while (1) {
      __z___0 = return_value;
      __z___0->value.lval = 0L;
      __z___0->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  *(str + str_len) = (char)0;
  while (1) {
    tmp___3 = _erealloc((void *)str, (size_t )(str_len + 1), 0);
    __s = (char const   *)tmp___3;
    __l = str_len;
    __z___1 = return_value;
    __z___1->value.str.len = __l;
    __z___1->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z___1->type = (zend_uchar )6;
    break;
  }
  return;
}
}
void zif_str_split(int ht , zval *return_value , zval **return_value_ptr ,
                   zval *this_ptr , int return_value_used ) 
{ 
  char *str ;
  int str_len ;
  long split_length ;
  char *p ;
  int n_reg_segments ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;
  int tmp___0 ;

  {
  split_length = 1L;
  tmp = zend_parse_parameters(ht, "s|l", & str, & str_len, & split_length);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  if (split_length <= 0L) {
    php_error_docref0((char const   *)((void *)0), 1 << 1L,
                      "The length of each segment must be greater than zero");
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  _array_init(return_value, (uint )((long )(str_len - 1) / split_length + 1L));
  if (split_length >= (long )str_len) {
    add_next_index_stringl(return_value, (char const   *)str, (uint )str_len, 1);
    return;
  } else {

  }
  n_reg_segments = (int )((long )str_len / split_length);
  p = str;
  while (1) {
    tmp___0 = n_reg_segments;
    n_reg_segments --;
    if (! (tmp___0 > 0)) {
      break;
    } else {

    }
    add_next_index_stringl(return_value, (char const   *)p, (uint )split_length,
                           1);
    p += split_length;
  }
  if ((unsigned long )p != (unsigned long )(str + str_len)) {
    add_next_index_stringl(return_value, (char const   *)p,
                           (uint )((str + str_len) - p), 1);
  } else {

  }
  return;
}
}
void zif_strpbrk(int ht , zval *return_value , zval **return_value_ptr ,
                 zval *this_ptr , int return_value_used ) 
{ 
  char *haystack ;
  char *char_list ;
  int haystack_len ;
  int char_list_len ;
  char *p ;
  zval *__z ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z___0 ;
  char const   *__s ;
  int __l ;
  zval *__z___1 ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  zval *__z___2 ;
  char *tmp___10 ;

  {
  tmp = zend_parse_parameters(ht, "ss", & haystack, & haystack_len, & char_list,
                              & char_list_len);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  if (! char_list_len) {
    php_error_docref0((char const   *)((void *)0), 1 << 1L,
                      "The character list cannot be empty");
    while (1) {
      __z___0 = return_value;
      __z___0->value.lval = 0L;
      __z___0->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  tmp___10 = __builtin_strpbrk((char const   *)haystack,
                               (char const   *)char_list);
  p = (char *)((char __attribute__((__gnu_inline__))  *)tmp___10);
  if (p) {
    while (1) {
      __s = (char const   *)p;
      __l = (int )((haystack + haystack_len) - p);
      __z___1 = return_value;
      __z___1->value.str.len = __l;
      tmp___0 = _estrndup(__s, (unsigned int )__l);
      __z___1->value.str.val = (char *)tmp___0;
      __z___1->type = (zend_uchar )6;
      break;
    }
    return;
  } else {
    while (1) {
      __z___2 = return_value;
      __z___2->value.lval = 0L;
      __z___2->type = (zend_uchar )3;
      break;
    }
    return;
  }
}
}
void zif_substr_compare(int ht , zval *return_value , zval **return_value_ptr ,
                        zval *this_ptr , int return_value_used ) 
{ 
  char *s1 ;
  char *s2 ;
  int s1_len ;
  int s2_len ;
  long offset ;
  long len ;
  zend_bool cs ;
  uint cmp_len ;
  zval *__z ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z___0 ;
  zval *__z___1 ;
  long tmp___0 ;
  long tmp___1 ;
  zval *__z___2 ;
  int __attribute__((__visibility__("default")))  tmp___2 ;
  zval *__z___3 ;
  int __attribute__((__visibility__("default")))  tmp___3 ;

  {
  len = 0L;
  cs = (zend_bool )0;
  tmp = zend_parse_parameters(ht, "ssl|lb", & s1, & s1_len, & s2, & s2_len,
                              & offset, & len, & cs);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    while (1) {
      __z = return_value;
      __z->value.lval = 0L;
      __z->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  if (ht >= 4) {
    if (len <= 0L) {
      php_error_docref0((char const   *)((void *)0), 1 << 1L,
                        "The length must be greater than zero");
      while (1) {
        __z___0 = return_value;
        __z___0->value.lval = 0L;
        __z___0->type = (zend_uchar )3;
        break;
      }
      return;
    } else {

    }
  } else {

  }
  if (offset < 0L) {
    offset = (long )s1_len + offset;
    if (offset < 0L) {
      offset = 0L;
    } else {
      offset = offset;
    }
  } else {

  }
  if (offset >= (long )s1_len) {
    php_error_docref0((char const   *)((void *)0), 1 << 1L,
                      "The start position cannot exceed initial string length");
    while (1) {
      __z___1 = return_value;
      __z___1->value.lval = 0L;
      __z___1->type = (zend_uchar )3;
      break;
    }
    return;
  } else {

  }
  __repair_del_7068__0: /* CIL Label */ ;
  if (len) {
    tmp___1 = len;
  } else {
    if ((long )s2_len > (long )s1_len - offset) {
      tmp___0 = (long )s2_len;
    } else {
      tmp___0 = (long )s1_len - offset;
    }
    tmp___1 = tmp___0;
  }
  cmp_len = (uint )tmp___1;
  if (! cs) {
    __z___2 = return_value;
    tmp___2 = zend_binary_strncmp((char const   *)(s1 + offset),
                                  (uint )((long )s1_len - offset),
                                  (char const   *)s2, (uint )s2_len, cmp_len);
    __z___2->value.lval = (long )tmp___2;
    __z___2->type = (zend_uchar )1;
    return;
  } else {
    __z___3 = return_value;
    tmp___3 = zend_binary_strncasecmp((char const   *)(s1 + offset),
                                      (uint )((long )s1_len - offset),
                                      (char const   *)s2, (uint )s2_len, cmp_len);
    __z___3->value.lval = (long )tmp___3;
    __z___3->type = (zend_uchar )1;
    return;
  }
}
}
