typedef unsigned long size_t;
typedef int wchar_t;
typedef int __int32_t;
typedef unsigned long __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long __ino_t;
typedef unsigned long __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long __nlink_t;
typedef long __off_t;
typedef long __off64_t;
typedef long __time_t;
typedef long __suseconds_t;
typedef long __blksize_t;
typedef long __blkcnt_t;
typedef long __blkcnt64_t;
typedef long __ssize_t;
typedef long __syscall_slong_t;
typedef unsigned int __socklen_t;
typedef __off_t off_t;
typedef __ssize_t ssize_t;
typedef __time_t time_t;
typedef unsigned long ulong;
typedef unsigned int uint;
struct __anonstruct___sigset_t_9 {
   unsigned long __val[1024UL / (8UL * sizeof(unsigned long ))] ;
};
typedef struct __anonstruct___sigset_t_9 __sigset_t;
struct timespec {
   __time_t tv_sec ;
   __syscall_slong_t tv_nsec ;
};
struct timeval {
   __time_t tv_sec ;
   __suseconds_t tv_usec ;
};
union __anonunion___u_23 {
   long double __l ;
   int __i[3] ;
};
struct _IO_FILE;
struct _IO_FILE;
struct _IO_FILE;
typedef struct _IO_FILE FILE;
typedef struct _IO_FILE __FILE;
union __anonunion___value_25 {
   unsigned int __wch ;
   char __wchb[4] ;
};
struct __anonstruct___mbstate_t_24 {
   int __count ;
   union __anonunion___value_25 __value ;
};
typedef struct __anonstruct___mbstate_t_24 __mbstate_t;
typedef __builtin_va_list __gnuc_va_list;
struct _IO_FILE;
typedef void _IO_lock_t;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
struct _IO_FILE {
   int _flags ;
   char *_IO_read_ptr ;
   char *_IO_read_end ;
   char *_IO_read_base ;
   char *_IO_write_base ;
   char *_IO_write_ptr ;
   char *_IO_write_end ;
   char *_IO_buf_base ;
   char *_IO_buf_end ;
   char *_IO_save_base ;
   char *_IO_backup_base ;
   char *_IO_save_end ;
   struct _IO_marker *_markers ;
   struct _IO_FILE *_chain ;
   int _fileno ;
   int _flags2 ;
   __off_t _old_offset ;
   unsigned short _cur_column ;
   signed char _vtable_offset ;
   char _shortbuf[1] ;
   _IO_lock_t *_lock ;
   __off64_t _offset ;
   void *__pad1 ;
   void *__pad2 ;
   void *__pad3 ;
   void *__pad4 ;
   size_t __pad5 ;
   int _mode ;
   char _unused2[(15UL * sizeof(int ) - 4UL * sizeof(void *)) - sizeof(size_t )] ;
};
typedef struct _IO_FILE _IO_FILE;
typedef __gnuc_va_list va_list;
struct obstack;
struct obstack;
struct obstack;
typedef unsigned char zend_bool;
typedef unsigned char zend_uchar;
typedef unsigned int zend_uint;
typedef unsigned long zend_ulong;
typedef unsigned int zend_object_handle;
struct _zend_object_handlers;
struct _zend_object_handlers;
typedef struct _zend_object_handlers zend_object_handlers;
struct _zend_object_value {
   zend_object_handle handle ;
   zend_object_handlers const   *handlers ;
};
typedef struct _zend_object_value zend_object_value;
struct _hashtable;
struct _hashtable;
struct _hashtable;
struct bucket {
   ulong h ;
   uint nKeyLength ;
   void *pData ;
   void *pDataPtr ;
   struct bucket *pListNext ;
   struct bucket *pListLast ;
   struct bucket *pNext ;
   struct bucket *pLast ;
   char const   *arKey ;
};
typedef struct bucket Bucket;
struct _hashtable {
   uint nTableSize ;
   uint nTableMask ;
   uint nNumOfElements ;
   ulong nNextFreeElement ;
   Bucket *pInternalPointer ;
   Bucket *pListHead ;
   Bucket *pListTail ;
   Bucket **arBuckets ;
   void (*pDestructor)(void *pDest ) ;
   zend_bool persistent ;
   unsigned char nApplyCount ;
   zend_bool bApplyProtection ;
};
typedef struct _hashtable HashTable;
typedef Bucket *HashPosition;
struct _HashPointer {
   HashPosition pos ;
   ulong h ;
};
typedef struct _HashPointer HashPointer;
struct _zend_llist_element {
   struct _zend_llist_element *next ;
   struct _zend_llist_element *prev ;
   char data[1] ;
};
typedef struct _zend_llist_element zend_llist_element;
struct _zend_llist {
   zend_llist_element *head ;
   zend_llist_element *tail ;
   size_t count ;
   size_t size ;
   void (*dtor)(void * ) ;
   unsigned char persistent ;
   zend_llist_element *traverse_ptr ;
};
typedef struct _zend_llist zend_llist;
typedef zend_llist_element *zend_llist_position;
struct _zval_struct;
struct _zval_struct;
typedef struct _zval_struct zval;
struct _zend_class_entry;
struct _zend_class_entry;
typedef struct _zend_class_entry zend_class_entry;
union _zend_function;
union _zend_function;
union _zend_function;
struct _zend_property_info;
struct _zend_property_info;
struct _zend_property_info;
struct _zend_literal;
struct _zend_literal;
struct _zend_literal;
struct _zend_object_handlers {
   void (*add_ref)(zval *object ) ;
   void (*del_ref)(zval *object ) ;
   zend_object_value (*clone_obj)(zval *object ) ;
   zval *(*read_property)(zval *object , zval *member , int type ,
                          struct _zend_literal  const  *key ) ;
   void (*write_property)(zval *object , zval *member , zval *value ,
                          struct _zend_literal  const  *key ) ;
   zval *(*read_dimension)(zval *object , zval *offset , int type ) ;
   void (*write_dimension)(zval *object , zval *offset , zval *value ) ;
   zval **(*get_property_ptr_ptr)(zval *object , zval *member ,
                                  struct _zend_literal  const  *key ) ;
   zval *(*get)(zval *object ) ;
   void (*set)(zval **object , zval *value ) ;
   int (*has_property)(zval *object , zval *member , int has_set_exists ,
                       struct _zend_literal  const  *key ) ;
   void (*unset_property)(zval *object , zval *member ,
                          struct _zend_literal  const  *key ) ;
   int (*has_dimension)(zval *object , zval *member , int check_empty ) ;
   void (*unset_dimension)(zval *object , zval *offset ) ;
   HashTable *(*get_properties)(zval *object ) ;
   union _zend_function *(*get_method)(zval **object_ptr , char *method ,
                                       int method_len ,
                                       struct _zend_literal  const  *key ) ;
   int (*call_method)(char const   *method , int ht , zval *return_value ,
                      zval **return_value_ptr , zval *this_ptr ,
                      int return_value_used ) ;
   union _zend_function *(*get_constructor)(zval *object ) ;
   zend_class_entry *(*get_class_entry)(zval const   *object ) ;
   int (*get_class_name)(zval const   *object , char const   **class_name ,
                         zend_uint *class_name_len , int parent ) ;
   int (*compare_objects)(zval *object1 , zval *object2 ) ;
   int (*cast_object)(zval *readobj , zval *retval , int type ) ;
   int (*count_elements)(zval *object , long *count ) ;
   HashTable *(*get_debug_info)(zval *object , int *is_temp ) ;
   int (*get_closure)(zval *obj , zend_class_entry **ce_ptr ,
                      union _zend_function **fptr_ptr , zval **zobj_ptr ) ;
   HashTable *(*get_gc)(zval *object , zval ***table , int *n ) ;
};
struct __anonstruct_str_34 {
   char *val ;
   int len ;
};
union _zvalue_value {
   long lval ;
   double dval ;
   struct __anonstruct_str_34 str ;
   HashTable *ht ;
   zend_object_value obj ;
};
typedef union _zvalue_value zvalue_value;
struct _zval_struct {
   zvalue_value value ;
   zend_uint refcount__gc ;
   zend_uchar type ;
   zend_uchar is_ref__gc ;
};
union _zend_function;
struct _zend_object_iterator;
struct _zend_object_iterator;
typedef struct _zend_object_iterator zend_object_iterator;
struct _zend_object_iterator_funcs {
   void (*dtor)(zend_object_iterator *iter ) ;
   int (*valid)(zend_object_iterator *iter ) ;
   void (*get_current_data)(zend_object_iterator *iter , zval ***data ) ;
   int (*get_current_key)(zend_object_iterator *iter , char **str_key ,
                          uint *str_key_len , ulong *int_key ) ;
   void (*move_forward)(zend_object_iterator *iter ) ;
   void (*rewind)(zend_object_iterator *iter ) ;
   void (*invalidate_current)(zend_object_iterator *iter ) ;
};
typedef struct _zend_object_iterator_funcs zend_object_iterator_funcs;
struct _zend_object_iterator {
   void *data ;
   zend_object_iterator_funcs *funcs ;
   ulong index ;
};
struct _zend_class_iterator_funcs {
   zend_object_iterator_funcs *funcs ;
   union _zend_function *zf_new_iterator ;
   union _zend_function *zf_valid ;
   union _zend_function *zf_current ;
   union _zend_function *zf_key ;
   union _zend_function *zf_next ;
   union _zend_function *zf_rewind ;
};
typedef struct _zend_class_iterator_funcs zend_class_iterator_funcs;
struct _zend_serialize_data;
struct _zend_serialize_data;
struct _zend_serialize_data;
struct _zend_unserialize_data;
struct _zend_unserialize_data;
struct _zend_unserialize_data;
typedef struct _zend_serialize_data zend_serialize_data;
typedef struct _zend_unserialize_data zend_unserialize_data;
struct _zend_trait_method_reference {
   char const   *method_name ;
   unsigned int mname_len ;
   zend_class_entry *ce ;
   char const   *class_name ;
   unsigned int cname_len ;
};
typedef struct _zend_trait_method_reference zend_trait_method_reference;
struct _zend_trait_precedence {
   zend_trait_method_reference *trait_method ;
   zend_class_entry **exclude_from_classes ;
   union _zend_function *function ;
};
typedef struct _zend_trait_precedence zend_trait_precedence;
struct _zend_trait_alias {
   zend_trait_method_reference *trait_method ;
   char const   *alias ;
   unsigned int alias_len ;
   zend_uint modifiers ;
   union _zend_function *function ;
};
typedef struct _zend_trait_alias zend_trait_alias;
struct __anonstruct_user_36 {
   char const   *filename ;
   zend_uint line_start ;
   zend_uint line_end ;
   char const   *doc_comment ;
   zend_uint doc_comment_len ;
};
struct _zend_function_entry;
struct _zend_function_entry;
struct _zend_module_entry;
struct _zend_module_entry;
struct __anonstruct_internal_37 {
   struct _zend_function_entry  const  *builtin_functions ;
   struct _zend_module_entry *module ;
};
union __anonunion_info_35 {
   struct __anonstruct_user_36 user ;
   struct __anonstruct_internal_37 internal ;
};
struct _zend_class_entry {
   char type ;
   char const   *name ;
   zend_uint name_length ;
   struct _zend_class_entry *parent ;
   int refcount ;
   zend_uint ce_flags ;
   HashTable function_table ;
   HashTable properties_info ;
   zval **default_properties_table ;
   zval **default_static_members_table ;
   zval **static_members_table ;
   HashTable constants_table ;
   int default_properties_count ;
   int default_static_members_count ;
   union _zend_function *constructor ;
   union _zend_function *destructor ;
   union _zend_function *clone ;
   union _zend_function *__get ;
   union _zend_function *__set ;
   union _zend_function *__unset ;
   union _zend_function *__isset ;
   union _zend_function *__call ;
   union _zend_function *__callstatic ;
   union _zend_function *__tostring ;
   union _zend_function *serialize_func ;
   union _zend_function *unserialize_func ;
   zend_class_iterator_funcs iterator_funcs ;
   zend_object_value (*create_object)(zend_class_entry *class_type ) ;
   zend_object_iterator *(*get_iterator)(zend_class_entry *ce , zval *object ,
                                         int by_ref ) ;
   int (*interface_gets_implemented)(zend_class_entry *iface ,
                                     zend_class_entry *class_type ) ;
   union _zend_function *(*get_static_method)(zend_class_entry *ce ,
                                              char *method , int method_len ) ;
   int (*serialize)(zval *object , unsigned char **buffer , zend_uint *buf_len ,
                    zend_serialize_data *data ) ;
   int (*unserialize)(zval **object , zend_class_entry *ce ,
                      unsigned char const   *buf , zend_uint buf_len ,
                      zend_unserialize_data *data ) ;
   zend_class_entry **interfaces ;
   zend_uint num_interfaces ;
   zend_class_entry **traits ;
   zend_uint num_traits ;
   zend_trait_alias **trait_aliases ;
   zend_trait_precedence **trait_precedences ;
   union __anonunion_info_35 info ;
};
union __anonunion_u_40 {
   zval *pz ;
   zend_object_handlers const   *handlers ;
};
struct _gc_root_buffer {
   struct _gc_root_buffer *prev ;
   struct _gc_root_buffer *next ;
   zend_object_handle handle ;
   union __anonunion_u_40 u ;
};
typedef struct _gc_root_buffer gc_root_buffer;
struct _zval_gc_info;
union __anonunion_u_41 {
   gc_root_buffer *buffered ;
   struct _zval_gc_info *next ;
};
struct _zval_gc_info {
   zval z ;
   union __anonunion_u_41 u ;
};
typedef struct _zval_gc_info zval_gc_info;
enum __anonenum_zend_error_handling_t_42 {
    EH_NORMAL = 0,
    EH_SUPPRESS = 1,
    EH_THROW = 2
} ;
typedef enum __anonenum_zend_error_handling_t_42 zend_error_handling_t;
struct _zend_op_array;
struct _zend_op_array;
typedef struct _zend_op_array zend_op_array;
struct _zend_op;
struct _zend_op;
typedef struct _zend_op zend_op;
struct _zend_literal {
   zval constant ;
   zend_ulong hash_value ;
   zend_uint cache_slot ;
};
typedef struct _zend_literal zend_literal;
union _znode_op {
   zend_uint constant ;
   zend_uint var ;
   zend_uint num ;
   zend_ulong hash ;
   zend_uint opline_num ;
   zend_op *jmp_addr ;
   zval *zv ;
   zend_literal *literal ;
   void *ptr ;
};
typedef union _znode_op znode_op;
struct _zend_execute_data;
struct _zend_execute_data;
typedef struct _zend_execute_data zend_execute_data;
struct _zend_op {
   int (*handler)(zend_execute_data *execute_data ) ;
   znode_op op1 ;
   znode_op op2 ;
   znode_op result ;
   ulong extended_value ;
   uint lineno ;
   zend_uchar opcode ;
   zend_uchar op1_type ;
   zend_uchar op2_type ;
   zend_uchar result_type ;
};
struct _zend_brk_cont_element {
   int start ;
   int cont ;
   int brk ;
   int parent ;
};
typedef struct _zend_brk_cont_element zend_brk_cont_element;
struct _zend_try_catch_element {
   zend_uint try_op ;
   zend_uint catch_op ;
};
typedef struct _zend_try_catch_element zend_try_catch_element;
struct _zend_property_info {
   zend_uint flags ;
   char const   *name ;
   int name_length ;
   ulong h ;
   int offset ;
   char const   *doc_comment ;
   int doc_comment_len ;
   zend_class_entry *ce ;
};
typedef struct _zend_property_info zend_property_info;
struct _zend_arg_info {
   char const   *name ;
   zend_uint name_len ;
   char const   *class_name ;
   zend_uint class_name_len ;
   zend_uchar type_hint ;
   zend_bool allow_null ;
   zend_bool pass_by_reference ;
};
typedef struct _zend_arg_info zend_arg_info;
struct _zend_compiled_variable {
   char const   *name ;
   int name_len ;
   ulong hash_value ;
};
typedef struct _zend_compiled_variable zend_compiled_variable;
struct _zend_op_array {
   zend_uchar type ;
   char const   *function_name ;
   zend_class_entry *scope ;
   zend_uint fn_flags ;
   union _zend_function *prototype ;
   zend_uint num_args ;
   zend_uint required_num_args ;
   zend_arg_info *arg_info ;
   zend_uint *refcount ;
   zend_op *opcodes ;
   zend_uint last ;
   zend_compiled_variable *vars ;
   int last_var ;
   zend_uint T ;
   zend_brk_cont_element *brk_cont_array ;
   int last_brk_cont ;
   zend_try_catch_element *try_catch_array ;
   int last_try_catch ;
   HashTable *static_variables ;
   zend_uint this_var ;
   char const   *filename ;
   zend_uint line_start ;
   zend_uint line_end ;
   char const   *doc_comment ;
   zend_uint doc_comment_len ;
   zend_uint early_binding ;
   zend_literal *literals ;
   int last_literal ;
   void **run_time_cache ;
   int last_cache_slot ;
   void *reserved[4] ;
};
struct _zend_internal_function {
   zend_uchar type ;
   char const   *function_name ;
   zend_class_entry *scope ;
   zend_uint fn_flags ;
   union _zend_function *prototype ;
   zend_uint num_args ;
   zend_uint required_num_args ;
   zend_arg_info *arg_info ;
   void (*handler)(int ht , zval *return_value , zval **return_value_ptr ,
                   zval *this_ptr , int return_value_used ) ;
   struct _zend_module_entry *module ;
};
typedef struct _zend_internal_function zend_internal_function;
struct __anonstruct_common_45 {
   zend_uchar type ;
   char const   *function_name ;
   zend_class_entry *scope ;
   zend_uint fn_flags ;
   union _zend_function *prototype ;
   zend_uint num_args ;
   zend_uint required_num_args ;
   zend_arg_info *arg_info ;
};
union _zend_function {
   zend_uchar type ;
   struct __anonstruct_common_45 common ;
   zend_op_array op_array ;
   zend_internal_function internal_function ;
};
typedef union _zend_function zend_function;
struct _zend_function_state {
   zend_function *function ;
   void **arguments ;
};
typedef struct _zend_function_state zend_function_state;
union _temp_variable;
union _temp_variable;
union _temp_variable;
struct _zend_execute_data {
   struct _zend_op *opline ;
   zend_function_state function_state ;
   zend_function *fbc ;
   zend_class_entry *called_scope ;
   zend_op_array *op_array ;
   zval *object ;
   union _temp_variable *Ts ;
   zval ***CVs ;
   HashTable *symbol_table ;
   struct _zend_execute_data *prev_execute_data ;
   zval *old_error_reporting ;
   zend_bool nested ;
   zval **original_return_value ;
   zend_class_entry *current_scope ;
   zend_class_entry *current_called_scope ;
   zval *current_this ;
   zval *current_object ;
};
typedef long __jmp_buf[8];
struct __jmp_buf_tag {
   __jmp_buf __jmpbuf ;
   int __mask_was_saved ;
   __sigset_t __saved_mask ;
};
typedef struct __jmp_buf_tag jmp_buf[1];
struct _zend_executor_globals;
struct _zend_executor_globals;
typedef struct _zend_executor_globals zend_executor_globals;
struct _zend_stack {
   int top ;
   int max ;
   void **elements ;
};
typedef struct _zend_stack zend_stack;
struct _zend_ptr_stack {
   int top ;
   int max ;
   void **elements ;
   void **top_element ;
   zend_bool persistent ;
};
typedef struct _zend_ptr_stack zend_ptr_stack;
struct _store_object {
   void *object ;
   void (*dtor)(void *object , zend_object_handle handle ) ;
   void (*free_storage)(void *object ) ;
   void (*clone)(void *object , void **object_clone ) ;
   zend_object_handlers const   *handlers ;
   zend_uint refcount ;
   gc_root_buffer *buffered ;
};
struct __anonstruct_free_list_46 {
   int next ;
};
union _store_bucket {
   struct _store_object obj ;
   struct __anonstruct_free_list_46 free_list ;
};
struct _zend_object_store_bucket {
   zend_bool destructor_called ;
   zend_bool valid ;
   union _store_bucket bucket ;
};
typedef struct _zend_object_store_bucket zend_object_store_bucket;
struct _zend_objects_store {
   zend_object_store_bucket *object_buckets ;
   zend_uint top ;
   zend_uint size ;
   int free_list_head ;
};
typedef struct _zend_objects_store zend_objects_store;
typedef unsigned short fpu_control_t;
struct _zend_vm_stack;
struct _zend_vm_stack;
typedef struct _zend_vm_stack *zend_vm_stack;
struct _zend_ini_entry;
struct _zend_ini_entry;
typedef struct _zend_ini_entry zend_ini_entry;
struct _zend_executor_globals {
   zval **return_value_ptr_ptr ;
   zval uninitialized_zval ;
   zval *uninitialized_zval_ptr ;
   zval error_zval ;
   zval *error_zval_ptr ;
   zend_ptr_stack arg_types_stack ;
   HashTable *symtable_cache[32] ;
   HashTable **symtable_cache_limit ;
   HashTable **symtable_cache_ptr ;
   zend_op **opline_ptr ;
   HashTable *active_symbol_table ;
   HashTable symbol_table ;
   HashTable included_files ;
   jmp_buf *bailout ;
   int error_reporting ;
   int orig_error_reporting ;
   int exit_status ;
   zend_op_array *active_op_array ;
   HashTable *function_table ;
   HashTable *class_table ;
   HashTable *zend_constants ;
   zend_class_entry *scope ;
   zend_class_entry *called_scope ;
   zval *This ;
   long precision ;
   int ticks_count ;
   zend_bool in_execution ;
   HashTable *in_autoload ;
   zend_function *autoload_func ;
   zend_bool full_tables_cleanup ;
   zend_bool no_extensions ;
   HashTable regular_list ;
   HashTable persistent_list ;
   zend_vm_stack argument_stack ;
   int user_error_handler_error_reporting ;
   zval *user_error_handler ;
   zval *user_exception_handler ;
   zend_stack user_error_handlers_error_reporting ;
   zend_ptr_stack user_error_handlers ;
   zend_ptr_stack user_exception_handlers ;
   zend_error_handling_t error_handling ;
   zend_class_entry *exception_class ;
   int timeout_seconds ;
   int lambda_count ;
   HashTable *ini_directives ;
   HashTable *modified_ini_directives ;
   zend_ini_entry *error_reporting_ini_entry ;
   zend_objects_store objects_store ;
   zval *exception ;
   zval *prev_exception ;
   zend_op *opline_before_exception ;
   zend_op exception_op[3] ;
   struct _zend_execute_data *current_execute_data ;
   struct _zend_module_entry *current_module ;
   zend_property_info std_property_info ;
   zend_bool active ;
   zend_op *start_op ;
   void *saved_fpu_cw_ptr ;
   fpu_control_t saved_fpu_cw ;
   void *reserved[4] ;
};
struct _zend_ini_entry;
typedef struct _zend_module_entry zend_module_entry;
struct _zend_module_dep;
struct _zend_module_dep;
struct _zend_module_entry {
   unsigned short size ;
   unsigned int zend_api ;
   unsigned char zend_debug ;
   unsigned char zts ;
   struct _zend_ini_entry  const  *ini_entry ;
   struct _zend_module_dep  const  *deps ;
   char const   *name ;
   struct _zend_function_entry  const  *functions ;
   int (*module_startup_func)(int type , int module_number ) ;
   int (*module_shutdown_func)(int type , int module_number ) ;
   int (*request_startup_func)(int type , int module_number ) ;
   int (*request_shutdown_func)(int type , int module_number ) ;
   void (*info_func)(zend_module_entry *zend_module ) ;
   char const   *version ;
   size_t globals_size ;
   void *globals_ptr ;
   void (*globals_ctor)(void *global ) ;
   void (*globals_dtor)(void *global ) ;
   int (*post_deactivate_func)(void) ;
   int module_started ;
   unsigned char type ;
   void *handle ;
   int module_number ;
   char const   *build_id ;
};
struct _zend_module_dep {
   char const   *name ;
   char const   *rel ;
   char const   *version ;
   unsigned char type ;
};
struct _zend_rsrc_list_entry {
   void *ptr ;
   int type ;
   int refcount ;
};
typedef struct _zend_rsrc_list_entry zend_rsrc_list_entry;
struct __anonstruct_var_47 {
   zval **ptr_ptr ;
   zval *ptr ;
   zend_bool fcall_returned_reference ;
};
struct __anonstruct_str_offset_48 {
   zval **ptr_ptr ;
   zval *str ;
   zend_uint offset ;
};
struct __anonstruct_fe_49 {
   zval **ptr_ptr ;
   zval *ptr ;
   HashPointer fe_pos ;
};
union _temp_variable {
   zval tmp_var ;
   struct __anonstruct_var_47 var ;
   struct __anonstruct_str_offset_48 str_offset ;
   struct __anonstruct_fe_49 fe ;
   zend_class_entry *class_entry ;
};
struct _zend_vm_stack {
   void **top ;
   void **end ;
   zend_vm_stack prev ;
};
struct _zend_function_entry {
   char const   *fname ;
   void (*handler)(int ht , zval *return_value , zval **return_value_ptr ,
                   zval *this_ptr , int return_value_used ) ;
   struct _zend_arg_info  const  *arg_info ;
   zend_uint num_args ;
   zend_uint flags ;
};
struct _zend_fcall_info {
   size_t size ;
   HashTable *function_table ;
   zval *function_name ;
   HashTable *symbol_table ;
   zval **retval_ptr_ptr ;
   zend_uint param_count ;
   zval ***params ;
   zval *object_ptr ;
   zend_bool no_separation ;
};
typedef struct _zend_fcall_info zend_fcall_info;
struct _zend_fcall_info_cache {
   zend_bool initialized ;
   zend_function *function_handler ;
   zend_class_entry *calling_scope ;
   zend_class_entry *called_scope ;
   zval *object_ptr ;
};
typedef struct _zend_fcall_info_cache zend_fcall_info_cache;
typedef __socklen_t socklen_t;
struct stat {
   __dev_t st_dev ;
   __ino_t st_ino ;
   __nlink_t st_nlink ;
   __mode_t st_mode ;
   __uid_t st_uid ;
   __gid_t st_gid ;
   int __pad0 ;
   __dev_t st_rdev ;
   __off_t st_size ;
   __blksize_t st_blksize ;
   __blkcnt_t st_blocks ;
   struct timespec st_atim ;
   struct timespec st_mtim ;
   struct timespec st_ctim ;
   __syscall_slong_t __glibc_reserved[3] ;
};
struct stat64 {
   __dev_t st_dev ;
   __ino64_t st_ino ;
   __nlink_t st_nlink ;
   __mode_t st_mode ;
   __uid_t st_uid ;
   __gid_t st_gid ;
   int __pad0 ;
   __dev_t st_rdev ;
   __off_t st_size ;
   __blksize_t st_blksize ;
   __blkcnt64_t st_blocks ;
   struct timespec st_atim ;
   struct timespec st_mtim ;
   struct timespec st_ctim ;
   __syscall_slong_t __glibc_reserved[3] ;
};
struct _php_stream;
struct _php_stream;
typedef struct _php_stream php_stream;
struct _php_stream_wrapper;
struct _php_stream_wrapper;
typedef struct _php_stream_wrapper php_stream_wrapper;
struct _php_stream_context;
struct _php_stream_context;
typedef struct _php_stream_context php_stream_context;
struct _php_stream_filter;
struct _php_stream_filter;
typedef struct _php_stream_filter php_stream_filter;
struct _php_stream_notifier;
struct _php_stream_notifier;
typedef struct _php_stream_notifier php_stream_notifier;
struct _php_stream_notifier {
   void (*func)(php_stream_context *context , int notifycode , int severity ,
                char *xmsg , int xcode , size_t bytes_sofar , size_t bytes_max ,
                void *ptr ) ;
   void (*dtor)(php_stream_notifier *notifier ) ;
   void *ptr ;
   int mask ;
   size_t progress ;
   size_t progress_max ;
};
struct _php_stream_context {
   php_stream_notifier *notifier ;
   zval *options ;
   int rsrc_id ;
};
struct _php_stream_bucket;
struct _php_stream_bucket;
typedef struct _php_stream_bucket php_stream_bucket;
struct _php_stream_bucket_brigade;
struct _php_stream_bucket_brigade;
typedef struct _php_stream_bucket_brigade php_stream_bucket_brigade;
struct _php_stream_bucket {
   php_stream_bucket *next ;
   php_stream_bucket *prev ;
   php_stream_bucket_brigade *brigade ;
   char *buf ;
   size_t buflen ;
   int own_buf ;
   int is_persistent ;
   int refcount ;
};
struct _php_stream_bucket_brigade {
   php_stream_bucket *head ;
   php_stream_bucket *tail ;
};
enum __anonenum_php_stream_filter_status_t_83 {
    PSFS_ERR_FATAL = 0,
    PSFS_FEED_ME = 1,
    PSFS_PASS_ON = 2
} ;
typedef enum __anonenum_php_stream_filter_status_t_83 php_stream_filter_status_t;
struct _php_stream_filter_ops {
   php_stream_filter_status_t (*filter)(php_stream *stream ,
                                        php_stream_filter *thisfilter ,
                                        php_stream_bucket_brigade *buckets_in ,
                                        php_stream_bucket_brigade *buckets_out ,
                                        size_t *bytes_consumed , int flags ) ;
   void (*dtor)(php_stream_filter *thisfilter ) ;
   char const   *label ;
};
typedef struct _php_stream_filter_ops php_stream_filter_ops;
struct _php_stream_filter_chain {
   php_stream_filter *head ;
   php_stream_filter *tail ;
   php_stream *stream ;
};
typedef struct _php_stream_filter_chain php_stream_filter_chain;
struct _php_stream_filter {
   php_stream_filter_ops *fops ;
   void *abstract ;
   php_stream_filter *next ;
   php_stream_filter *prev ;
   int is_persistent ;
   php_stream_filter_chain *chain ;
   php_stream_bucket_brigade buffer ;
   int rsrc_id ;
};
struct _php_stream_statbuf {
   struct stat sb ;
};
typedef struct _php_stream_statbuf php_stream_statbuf;
struct _php_stream_dirent {
   char d_name[4096] ;
};
typedef struct _php_stream_dirent php_stream_dirent;
struct _php_stream_ops {
   size_t (*write)(php_stream *stream , char const   *buf , size_t count ) ;
   size_t (*read)(php_stream *stream , char *buf , size_t count ) ;
   int (*close)(php_stream *stream , int close_handle ) ;
   int (*flush)(php_stream *stream ) ;
   char const   *label ;
   int (*seek)(php_stream *stream , off_t offset , int whence ,
               off_t *newoffset ) ;
   int (*cast)(php_stream *stream , int castas , void **ret ) ;
   int (*stat)(php_stream *stream , php_stream_statbuf *ssb ) ;
   int (*set_option)(php_stream *stream , int option , int value ,
                     void *ptrparam ) ;
};
typedef struct _php_stream_ops php_stream_ops;
struct _php_stream_wrapper_ops {
   php_stream *(*stream_opener)(php_stream_wrapper *wrapper , char *filename ,
                                char *mode , int options , char **opened_path ,
                                php_stream_context *context ) ;
   int (*stream_closer)(php_stream_wrapper *wrapper , php_stream *stream ) ;
   int (*stream_stat)(php_stream_wrapper *wrapper , php_stream *stream ,
                      php_stream_statbuf *ssb ) ;
   int (*url_stat)(php_stream_wrapper *wrapper , char *url , int flags ,
                   php_stream_statbuf *ssb , php_stream_context *context ) ;
   php_stream *(*dir_opener)(php_stream_wrapper *wrapper , char *filename ,
                             char *mode , int options , char **opened_path ,
                             php_stream_context *context ) ;
   char const   *label ;
   int (*unlink)(php_stream_wrapper *wrapper , char *url , int options ,
                 php_stream_context *context ) ;
   int (*rename)(php_stream_wrapper *wrapper , char *url_from , char *url_to ,
                 int options , php_stream_context *context ) ;
   int (*stream_mkdir)(php_stream_wrapper *wrapper , char *url , int mode ,
                       int options , php_stream_context *context ) ;
   int (*stream_rmdir)(php_stream_wrapper *wrapper , char *url , int options ,
                       php_stream_context *context ) ;
   int (*stream_metadata)(php_stream_wrapper *wrapper , char *url ,
                          int options , void *value ,
                          php_stream_context *context ) ;
};
typedef struct _php_stream_wrapper_ops php_stream_wrapper_ops;
struct _php_stream_wrapper {
   php_stream_wrapper_ops *wops ;
   void *abstract ;
   int is_url ;
};
struct _php_stream {
   php_stream_ops *ops ;
   void *abstract ;
   php_stream_filter_chain readfilters ;
   php_stream_filter_chain writefilters ;
   php_stream_wrapper *wrapper ;
   void *wrapperthis ;
   zval *wrapperdata ;
   int fgetss_state ;
   int is_persistent ;
   char mode[16] ;
   int rsrc_id ;
   int in_free ;
   int fclose_stdiocast ;
   FILE *stdiocast ;
   char *orig_path ;
   php_stream_context *context ;
   int flags ;
   off_t position ;
   unsigned char *readbuf ;
   size_t readbuflen ;
   off_t readpos ;
   off_t writepos ;
   size_t chunk_size ;
   int eof ;
   struct _php_stream *enclosing_stream ;
};
struct iovec {
   void *iov_base ;
   size_t iov_len ;
};
typedef unsigned short sa_family_t;
struct sockaddr {
   sa_family_t sa_family ;
   char sa_data[14] ;
};
struct msghdr {
   void *msg_name ;
   socklen_t msg_namelen ;
   struct iovec *msg_iov ;
   size_t msg_iovlen ;
   void *msg_control ;
   size_t msg_controllen ;
   int msg_flags ;
};
struct cmsghdr {
   size_t cmsg_len ;
   int cmsg_level ;
   int cmsg_type ;
   unsigned char __cmsg_data[] ;
};
struct sockaddr_at;
struct sockaddr_at;
struct sockaddr_ax25;
struct sockaddr_ax25;
struct sockaddr_dl;
struct sockaddr_dl;
struct sockaddr_eon;
struct sockaddr_eon;
struct sockaddr_in;
struct sockaddr_in;
struct sockaddr_in6;
struct sockaddr_in6;
struct sockaddr_inarp;
struct sockaddr_inarp;
struct sockaddr_ipx;
struct sockaddr_ipx;
struct sockaddr_iso;
struct sockaddr_iso;
struct sockaddr_ns;
struct sockaddr_ns;
struct sockaddr_un;
struct sockaddr_un;
struct sockaddr_x25;
struct sockaddr_x25;
union __anonunion___SOCKADDR_ARG_87 {
   struct sockaddr * __restrict  __sockaddr__ ;
   struct sockaddr_at * __restrict  __sockaddr_at__ ;
   struct sockaddr_ax25 * __restrict  __sockaddr_ax25__ ;
   struct sockaddr_dl * __restrict  __sockaddr_dl__ ;
   struct sockaddr_eon * __restrict  __sockaddr_eon__ ;
   struct sockaddr_in * __restrict  __sockaddr_in__ ;
   struct sockaddr_in6 * __restrict  __sockaddr_in6__ ;
   struct sockaddr_inarp * __restrict  __sockaddr_inarp__ ;
   struct sockaddr_ipx * __restrict  __sockaddr_ipx__ ;
   struct sockaddr_iso * __restrict  __sockaddr_iso__ ;
   struct sockaddr_ns * __restrict  __sockaddr_ns__ ;
   struct sockaddr_un * __restrict  __sockaddr_un__ ;
   struct sockaddr_x25 * __restrict  __sockaddr_x25__ ;
};
typedef union __anonunion___SOCKADDR_ARG_87  __attribute__((__transparent_union__)) __SOCKADDR_ARG;
typedef php_stream *php_stream_transport_factory_func(char const   *proto ,
                                                      long protolen ,
                                                      char *resourcename ,
                                                      long resourcenamelen ,
                                                      char const   *persistent_id ,
                                                      int options , int flags ,
                                                      struct timeval *timeout ,
                                                      php_stream_context *context );
typedef php_stream_transport_factory_func *php_stream_transport_factory;
enum __anonenum_php_stream_mmap_operation_t_97 {
    PHP_STREAM_MMAP_SUPPORTED = 0,
    PHP_STREAM_MMAP_MAP_RANGE = 1,
    PHP_STREAM_MMAP_UNMAP = 2
} ;
typedef enum __anonenum_php_stream_mmap_operation_t_97 php_stream_mmap_operation_t;
struct _php_core_globals;
struct _php_core_globals;
struct _arg_separators {
   char *output ;
   char *input ;
};
typedef struct _arg_separators arg_separators;
struct _php_core_globals {
   zend_bool implicit_flush ;
   long output_buffering ;
   zend_bool sql_safe_mode ;
   zend_bool enable_dl ;
   char *output_handler ;
   char *unserialize_callback_func ;
   long serialize_precision ;
   long memory_limit ;
   long max_input_time ;
   zend_bool track_errors ;
   zend_bool display_errors ;
   zend_bool display_startup_errors ;
   zend_bool log_errors ;
   long log_errors_max_len ;
   zend_bool ignore_repeated_errors ;
   zend_bool ignore_repeated_source ;
   zend_bool report_memleaks ;
   char *error_log ;
   char *doc_root ;
   char *user_dir ;
   char *include_path ;
   char *open_basedir ;
   char *extension_dir ;
   char *php_binary ;
   char *upload_tmp_dir ;
   long upload_max_filesize ;
   char *error_append_string ;
   char *error_prepend_string ;
   char *auto_prepend_file ;
   char *auto_append_file ;
   arg_separators arg_separator ;
   char *variables_order ;
   HashTable rfc1867_protected_variables ;
   short connection_status ;
   short ignore_user_abort ;
   unsigned char header_is_being_sent ;
   zend_llist tick_functions ;
   zval *http_globals[6] ;
   zend_bool expose_php ;
   zend_bool register_argc_argv ;
   zend_bool auto_globals_jit ;
   char *docref_root ;
   char *docref_ext ;
   zend_bool html_errors ;
   zend_bool xmlrpc_errors ;
   long xmlrpc_error_number ;
   zend_bool activated_auto_globals[8] ;
   zend_bool modules_activated ;
   zend_bool file_uploads ;
   zend_bool during_request_startup ;
   zend_bool allow_url_fopen ;
   zend_bool enable_post_data_reading ;
   zend_bool always_populate_raw_post_data ;
   zend_bool report_zend_debug ;
   int last_error_type ;
   char *last_error_message ;
   char *last_error_file ;
   int last_error_lineno ;
   char *disable_functions ;
   char *disable_classes ;
   zend_bool allow_url_include ;
   zend_bool exit_on_timeout ;
   long max_input_nesting_level ;
   long max_input_vars ;
   zend_bool in_user_include ;
   char *user_ini_filename ;
   long user_ini_cache_ttl ;
   char *request_order ;
   zend_bool mail_x_header ;
   char *mail_log ;
   zend_bool in_error_log ;
};
struct _zend_ini_entry {
   int module_number ;
   int modifiable ;
   char *name ;
   uint name_length ;
   int (*on_modify)(zend_ini_entry *entry , char *new_value ,
                    uint new_value_length , void *mh_arg1 , void *mh_arg2 ,
                    void *mh_arg3 , int stage ) ;
   void *mh_arg1 ;
   void *mh_arg2 ;
   void *mh_arg3 ;
   char *value ;
   uint value_length ;
   char *orig_value ;
   uint orig_value_length ;
   int orig_modifiable ;
   int modified ;
   void (*displayer)(zend_ini_entry *ini_entry , int type ) ;
};
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef uint32_t in_addr_t;
struct in_addr {
   in_addr_t s_addr ;
};
typedef uint16_t in_port_t;
union __anonunion___in6_u_104 {
   uint8_t __u6_addr8[16] ;
   uint16_t __u6_addr16[8] ;
   uint32_t __u6_addr32[4] ;
};
struct in6_addr {
   union __anonunion___in6_u_104 __in6_u ;
};
struct sockaddr_in {
   sa_family_t sin_family ;
   in_port_t sin_port ;
   struct in_addr sin_addr ;
   unsigned char sin_zero[((sizeof(struct sockaddr ) - sizeof(unsigned short )) - sizeof(in_port_t )) - sizeof(struct in_addr )] ;
};
struct sockaddr_in6 {
   sa_family_t sin6_family ;
   in_port_t sin6_port ;
   uint32_t sin6_flowinfo ;
   struct in6_addr sin6_addr ;
   uint32_t sin6_scope_id ;
};
struct cmsghdr;
typedef unsigned long nfds_t;
struct pollfd {
   int fd ;
   short events ;
   short revents ;
};
struct __anonstruct_php_file_globals_105 {
   int pclose_ret ;
   size_t def_chunk_size ;
   long auto_detect_line_endings ;
   long default_socket_timeout ;
   char *user_agent ;
   char *from_address ;
   char *user_stream_current_filename ;
   php_stream_context *default_context ;
   HashTable *stream_wrappers ;
   HashTable *stream_filters ;
   HashTable *wrapper_errors ;
};
typedef struct __anonstruct_php_file_globals_105 php_file_globals;
typedef unsigned int wint_t;
typedef __mbstate_t mbstate_t;
struct __anonstruct_smart_str_106 {
   char *c ;
   size_t len ;
   size_t a ;
};
typedef struct __anonstruct_smart_str_106 smart_str;
struct __anonstruct_url_adapt_state_ex_t_107 {
   smart_str tag ;
   smart_str arg ;
   smart_str val ;
   smart_str buf ;
   smart_str result ;
   smart_str form_app ;
   smart_str url_app ;
   int active ;
   char *lookup_data ;
   int state ;
   HashTable *tags ;
};
typedef struct __anonstruct_url_adapt_state_ex_t_107 url_adapt_state_ex_t;
typedef unsigned int php_uint32;
struct __anonstruct_serialize_108 {
   void *var_hash ;
   unsigned int level ;
};
struct __anonstruct_unserialize_109 {
   void *var_hash ;
   unsigned int level ;
};
struct _php_basic_globals {
   HashTable *user_shutdown_function_names ;
   HashTable putenv_ht ;
   zval *strtok_zval ;
   char *strtok_string ;
   char *locale_string ;
   char *strtok_last ;
   char strtok_table[256] ;
   ulong strtok_len ;
   char str_ebuf[40] ;
   zend_fcall_info array_walk_fci ;
   zend_fcall_info_cache array_walk_fci_cache ;
   zend_fcall_info user_compare_fci ;
   zend_fcall_info_cache user_compare_fci_cache ;
   zend_llist *user_tick_functions ;
   zval *active_ini_file_section ;
   long page_uid ;
   long page_gid ;
   long page_inode ;
   time_t page_mtime ;
   char *CurrentStatFile ;
   char *CurrentLStatFile ;
   php_stream_statbuf ssb ;
   php_stream_statbuf lssb ;
   php_uint32 state[625] ;
   php_uint32 *next ;
   int left ;
   unsigned int rand_seed ;
   zend_bool rand_is_seeded ;
   zend_bool mt_rand_is_seeded ;
   char *syslog_device ;
   zend_class_entry *incomplete_class ;
   unsigned int serialize_lock ;
   struct __anonstruct_serialize_108 serialize ;
   struct __anonstruct_unserialize_109 unserialize ;
   url_adapt_state_ex_t url_adapt_state_ex ;
   void *mmap_file ;
   size_t mmap_len ;
   HashTable *user_filter_map ;
   int umask ;
};
typedef struct _php_basic_globals php_basic_globals;
__inline extern  __attribute__((__nothrow__)) double __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atof)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atoi)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atol)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) long long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atoll)(char const   *__nptr )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) double ( __attribute__((__nonnull__(1),
__leaf__)) strtod)(char const   * __restrict  __nptr ,
                   char ** __restrict  __endptr ) ;
extern  __attribute__((__nothrow__)) long ( __attribute__((__nonnull__(1),
__leaf__)) strtol)(char const   * __restrict  __nptr ,
                   char ** __restrict  __endptr , int __base ) ;
extern  __attribute__((__nothrow__)) long long ( __attribute__((__nonnull__(1),
__leaf__)) strtoll)(char const   * __restrict  __nptr ,
                    char ** __restrict  __endptr , int __base ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atoi)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) atoi)(char const   *__nptr ) 
{ 
  long tmp ;

  {
  tmp = strtol((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)), 10);
  return ((int __attribute__((__gnu_inline__))  )((int )tmp));
}
}
__inline extern  __attribute__((__nothrow__)) long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atol)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) atol)(char const   *__nptr ) 
{ 
  long tmp ;

  {
  tmp = strtol((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)), 10);
  return ((long __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) long long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atoll)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern long long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) atoll)(char const   *__nptr ) 
{ 
  long long tmp ;

  {
  tmp = strtoll((char const   */* __restrict  */)__nptr,
                (char **/* __restrict  */)((char **)((void *)0)), 10);
  return ((long long __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_major)(unsigned long long __dev )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_minor)(unsigned long long __dev )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) unsigned long long __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_makedev)(unsigned int __major ,
                                                                                                                                               unsigned int __minor )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_major)(unsigned long long __dev )  __attribute__((__const__)) ;
__inline extern unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_major)(unsigned long long __dev ) 
{ 


  {
  return ((unsigned int __attribute__((__gnu_inline__))  )(((__dev >> 8) & 4095ULL) | (unsigned long long )((unsigned int )(__dev >> 32) & 4294963200U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_minor)(unsigned long long __dev )  __attribute__((__const__)) ;
__inline extern unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_minor)(unsigned long long __dev ) 
{ 


  {
  return ((unsigned int __attribute__((__gnu_inline__))  )((__dev & 255ULL) | (unsigned long long )((unsigned int )(__dev >> 12) & 4294967040U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned long long __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_makedev)(unsigned int __major ,
                                                                                                                                               unsigned int __minor )  __attribute__((__const__)) ;
__inline extern unsigned long long __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_makedev)(unsigned int __major ,
                                                                                                                 unsigned int __minor ) 
{ 


  {
  return ((unsigned long long __attribute__((__gnu_inline__))  )(((unsigned long long )((__minor & 255U) | ((__major & 4095U) << 8)) | ((unsigned long long )(__minor & 4294967040U) << 12)) | ((unsigned long long )(__major & 4294963200U) << 32)));
}
}
extern  __attribute__((__nothrow__)) void *( __attribute__((__warn_unused_result__,
__leaf__)) malloc)(size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__warn_unused_result__,
__leaf__)) realloc)(void *__ptr , size_t __size ) ;
extern  __attribute__((__nothrow__)) void ( __attribute__((__leaf__)) free)(void *__ptr ) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void ( __attribute__((__leaf__)) exit)(int __status ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) realpath)(char const   * __restrict  __name ,
                              char * __restrict  __resolved ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__nonnull__(1,2,5))) bsearch)(void const   *__key , void const   *__base ,
                              size_t __nmemb , size_t __size ,
                              int (*__compar)(void const   * , void const   * ) ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__nonnull__(1,2,5))) bsearch)(void const   *__key , void const   *__base ,
                              size_t __nmemb , size_t __size ,
                              int (*__compar)(void const   * , void const   * ) ) 
{ 
  size_t __l ;
  size_t __u ;
  size_t __idx ;
  void const   *__p ;
  int __comparison ;

  {
  __l = (size_t )0;
  __u = __nmemb;
  while (__l < __u) {
    __idx = (__l + __u) / 2UL;
    __p = (void const   *)((void *)((char const   *)__base + __idx * __size));
    __comparison = (*__compar)(__key, __p);
    if (__comparison < 0) {
      __u = __idx;
    } else
    if (__comparison > 0) {
      __l = __idx + 1UL;
    } else {
      return ((void __attribute__((__gnu_inline__))  *)((void *)__p));
    }
  }
  return ((void __attribute__((__gnu_inline__))  *)((void *)0));
}
}
extern void ( __attribute__((__nonnull__(1,4))) qsort)(void *__base ,
                                                       size_t __nmemb ,
                                                       size_t __size ,
                                                       int (*__compar)(void const   * ,
                                                                       void const   * ) ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) wctomb)(char *__s , wchar_t __wchar ) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) mbstowcs)(wchar_t * __restrict  __dst ,
                                              char const   * __restrict  __src ,
                                              size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcstombs)(char * __restrict  __dst ,
                              wchar_t const   * __restrict  __src ,
                              size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__, __artificial__,
__always_inline__)) ptsname_r)(int __fd , char *__buf , size_t __buflen ) ;
__inline extern  __attribute__((__nothrow__)) double __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atof)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern double __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) atof)(char const   *__nptr ) 
{ 
  double tmp ;

  {
  tmp = strtod((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)));
  return ((double __attribute__((__gnu_inline__))  )tmp);
}
}
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__leaf__)) __realpath_chk)(char const   * __restrict  __name ,
                           char * __restrict  __resolved , size_t __resolvedlen ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__leaf__)) __realpath_alias)(char const   * __restrict  __name ,
                             char * __restrict  __resolved )  __asm__("realpath")  ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) realpath)(char const   * __restrict  __name ,
                              char * __restrict  __resolved ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) realpath)(char const   * __restrict  __name ,
                              char * __restrict  __resolved ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__resolved, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__resolved, 1);
    tmp___0 = __realpath_chk(__name, __resolved, tmp);
    return ((char __attribute__((__gnu_inline__))  *)tmp___0);
  } else {

  }
  tmp___2 = __realpath_alias(__name, __resolved);
  return ((char __attribute__((__gnu_inline__))  *)tmp___2);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ptsname_r_chk)(int __fd , char *__buf , size_t __buflen ,
                            size_t __nreal ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ptsname_r_alias)(int __fd , char *__buf , size_t __buflen )  __asm__("ptsname_r")  ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ptsname_r_chk_warn)(int __fd , char *__buf , size_t __buflen ,
                                 size_t __nreal )  __asm__("__ptsname_r_chk") __attribute__((__warning__("ptsname_r called with buflen bigger than size of buf"))) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__, __artificial__,
__always_inline__)) ptsname_r)(int __fd , char *__buf , size_t __buflen ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__, __artificial__,
__always_inline__)) ptsname_r)(int __fd , char *__buf , size_t __buflen ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __ptsname_r_chk(__fd, __buf, __buflen, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__buflen > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __ptsname_r_chk_warn(__fd, __buf, __buflen, tmp___1);
      return ((int __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __ptsname_r_alias(__fd, __buf, __buflen);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __wctomb_chk)(char *__s , wchar_t __wchar , size_t __buflen ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __wctomb_alias)(char *__s , wchar_t __wchar )  __asm__("wctomb")  ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) wctomb)(char *__s , wchar_t __wchar ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) wctomb)(char *__s , wchar_t __wchar ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  unsigned long tmp___2 ;
  int tmp___3 ;

  {
  tmp___1 = __builtin_object_size((void *)__s, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp___2 = __builtin_object_size((void *)__s, 1);
    if (16UL > tmp___2) {
      tmp = __builtin_object_size((void *)__s, 1);
      tmp___0 = __wctomb_chk(__s, __wchar, tmp);
      return ((int __attribute__((__gnu_inline__))  )tmp___0);
    } else {

    }
  } else {

  }
  tmp___3 = __wctomb_alias(__s, __wchar);
  return ((int __attribute__((__gnu_inline__))  )tmp___3);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbstowcs_chk)(wchar_t * __restrict  __dst ,
                                                                                        char const   * __restrict  __src ,
                                                                                        size_t __len ,
                                                                                        size_t __dstlen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbstowcs_alias)(wchar_t * __restrict  __dst ,
                                                                                          char const   * __restrict  __src ,
                                                                                          size_t __len )  __asm__("mbstowcs")  ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbstowcs_chk_warn)(wchar_t * __restrict  __dst ,
                                                                                             char const   * __restrict  __src ,
                                                                                             size_t __len ,
                                                                                             size_t __dstlen )  __asm__("__mbstowcs_chk") __attribute__((__warning__("mbstowcs called with dst buffer smaller than len * sizeof (wchar_t)"))) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) mbstowcs)(wchar_t * __restrict  __dst ,
                                              char const   * __restrict  __src ,
                                              size_t __len ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) mbstowcs)(wchar_t * __restrict  __dst ,
                                              char const   * __restrict  __src ,
                                              size_t __len ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__dst, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dst, 1);
    tmp___0 = __mbstowcs_chk(__dst, __src, __len, tmp / sizeof(wchar_t ));
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__dst, 1);
    if (__len > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__dst, 1);
      tmp___2 = __mbstowcs_chk_warn(__dst, __src, __len,
                                    tmp___1 / sizeof(wchar_t ));
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __mbstowcs_alias(__dst, __src, __len);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcstombs_chk)(char * __restrict  __dst ,
                                                                                        wchar_t const   * __restrict  __src ,
                                                                                        size_t __len ,
                                                                                        size_t __dstlen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcstombs_alias)(char * __restrict  __dst ,
                                                                                          wchar_t const   * __restrict  __src ,
                                                                                          size_t __len )  __asm__("wcstombs")  ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcstombs_chk_warn)(char * __restrict  __dst ,
                                                                                             wchar_t const   * __restrict  __src ,
                                                                                             size_t __len ,
                                                                                             size_t __dstlen )  __asm__("__wcstombs_chk") __attribute__((__warning__("wcstombs called with dst buffer smaller than len"))) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcstombs)(char * __restrict  __dst ,
                              wchar_t const   * __restrict  __src ,
                              size_t __len ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcstombs)(char * __restrict  __dst ,
                              wchar_t const   * __restrict  __src ,
                              size_t __len ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__dst, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dst, 1);
    tmp___0 = __wcstombs_chk(__dst, __src, __len, tmp);
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__dst, 1);
    if (__len > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__dst, 1);
      tmp___2 = __wcstombs_chk_warn(__dst, __src, __len, tmp___1);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wcstombs_alias(__dst, __src, __len);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memcpy)(void * __restrict  __dest ,
                            void const   * __restrict  __src , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memmove)(void *__dest , void const   *__src , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1),
__leaf__, __artificial__, __always_inline__)) memset)(void *__dest , int __ch ,
                                                      size_t __len ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2),
__leaf__)) memcmp)(void const   *__s1 , void const   *__s2 , size_t __n )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1),
__leaf__)) memchr)(void const   *__s , int __c , size_t __n )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcat)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncat)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2),
__leaf__)) strncmp)(char const   *__s1 , char const   *__s2 , size_t __n )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2),
__leaf__)) strcoll)(char const   *__s1 , char const   *__s2 )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) mempcpy)(void * __restrict  __dest ,
                             void const   * __restrict  __src , size_t __len ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__nonnull__(1),
__leaf__)) strlen)(char const   *__s )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__leaf__)) strerror)(int __errnum ) ;
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) bcopy)(void const   *__src , void *__dest , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) bzero)(void *__dest , size_t __len ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2),
__leaf__)) strncasecmp)(char const   *__s1 , char const   *__s2 , size_t __n )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __n ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c1(char const   *__s ,
                                                                     int __reject ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c1(char const   *__s ,
                                                                     int __reject ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if ((int const   )*(__s + __result) != 0) {
      if (! ((int const   )*(__s + __result) != (int const   )__reject)) {
        break;
      } else {

      }
    } else {
      break;
    }
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c2(char const   *__s ,
                                                                     int __reject1 ,
                                                                     int __reject2 ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c2(char const   *__s ,
                                                                     int __reject1 ,
                                                                     int __reject2 ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if ((int const   )*(__s + __result) != 0) {
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        if (! ((int const   )*(__s + __result) != (int const   )__reject2)) {
          break;
        } else {

        }
      } else {
        break;
      }
    } else {
      break;
    }
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c3(char const   *__s ,
                                                                     int __reject1 ,
                                                                     int __reject2 ,
                                                                     int __reject3 ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c3(char const   *__s ,
                                                                     int __reject1 ,
                                                                     int __reject2 ,
                                                                     int __reject3 ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if ((int const   )*(__s + __result) != 0) {
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          if (! ((int const   )*(__s + __result) != (int const   )__reject3)) {
            break;
          } else {

          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c1(char const   *__s ,
                                                                    int __accept ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c1(char const   *__s ,
                                                                    int __accept ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while ((int const   )*(__s + __result) == (int const   )__accept) {
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c2(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c2(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if (! ((int const   )*(__s + __result) == (int const   )__accept1)) {
      if (! ((int const   )*(__s + __result) == (int const   )__accept2)) {
        break;
      } else {

      }
    } else {

    }
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c3(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ,
                                                                    int __accept3 ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c3(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ,
                                                                    int __accept3 ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if (! ((int const   )*(__s + __result) == (int const   )__accept1)) {
      if (! ((int const   )*(__s + __result) == (int const   )__accept2)) {
        if (! ((int const   )*(__s + __result) == (int const   )__accept3)) {
          break;
        } else {

        }
      } else {

      }
    } else {

    }
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strpbrk_c2(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strpbrk_c2(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ) 
{ 
  char *tmp ;

  {
  while (1) {
    if ((int const   )*__s != 0) {
      if ((int const   )*__s != (int const   )__accept1) {
        if (! ((int const   )*__s != (int const   )__accept2)) {
          break;
        } else {

        }
      } else {
        break;
      }
    } else {
      break;
    }
    __s ++;
  }
  if ((int const   )*__s == 0) {
    tmp = (char *)((void *)0);
  } else {
    tmp = (char *)((size_t )__s);
  }
  return ((char __attribute__((__gnu_inline__))  *)tmp);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strpbrk_c3(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ,
                                                                    int __accept3 ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strpbrk_c3(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ,
                                                                    int __accept3 ) 
{ 
  char *tmp ;

  {
  while (1) {
    if ((int const   )*__s != 0) {
      if ((int const   )*__s != (int const   )__accept1) {
        if ((int const   )*__s != (int const   )__accept2) {
          if (! ((int const   )*__s != (int const   )__accept3)) {
            break;
          } else {

          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    __s ++;
  }
  if ((int const   )*__s == 0) {
    tmp = (char *)((void *)0);
  } else {
    tmp = (char *)((size_t )__s);
  }
  return ((char __attribute__((__gnu_inline__))  *)tmp);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strtok_r_1c(char *__s ,
                                                                     char __sep ,
                                                                     char **__nextp ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strtok_r_1c(char *__s ,
                                                                     char __sep ,
                                                                     char **__nextp ) 
{ 
  char *__result ;
  char *tmp ;
  char *tmp___0 ;

  {
  if ((unsigned long )__s == (unsigned long )((void *)0)) {
    __s = *__nextp;
  } else {

  }
  while ((int )*__s == (int )__sep) {
    __s ++;
  }
  __result = (char *)((void *)0);
  if ((int )*__s != 0) {
    tmp = __s;
    __s ++;
    __result = tmp;
    while ((int )*__s != 0) {
      tmp___0 = __s;
      __s ++;
      if ((int )*tmp___0 == (int )__sep) {
        *(__s + -1) = (char )'\000';
        break;
      } else {

      }
    }
  } else {

  }
  *__nextp = __s;
  return ((char __attribute__((__gnu_inline__))  *)__result);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strsep_1c(char **__s ,
                                                                   char __reject ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strsep_1c(char **__s ,
                                                                   char __reject ) 
{ 
  char *__retval ;
  char *tmp ;
  char *tmp___0 ;
  char *tmp___2 ;

  {
  __retval = *__s;
  if ((unsigned long )__retval != (unsigned long )((void *)0)) {
    tmp___2 = __builtin_strchr(__retval, (int )__reject);
    tmp___0 = tmp___2;
    *__s = tmp___0;
    if ((unsigned long )tmp___0 != (unsigned long )((void *)0)) {
      tmp = *__s;
      (*__s) ++;
      *tmp = (char )'\000';
    } else {

    }
  } else {

  }
  return ((char __attribute__((__gnu_inline__))  *)__retval);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strsep_2c(char **__s ,
                                                                   char __reject1 ,
                                                                   char __reject2 ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strsep_2c(char **__s ,
                                                                   char __reject1 ,
                                                                   char __reject2 ) 
{ 
  char *__retval ;
  char *__cp ;
  char *tmp ;

  {
  __retval = *__s;
  if ((unsigned long )__retval != (unsigned long )((void *)0)) {
    __cp = __retval;
    while (1) {
      if ((int )*__cp == 0) {
        __cp = (char *)((void *)0);
        break;
      } else {

      }
      if ((int )*__cp == (int )__reject1) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else
      if ((int )*__cp == (int )__reject2) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else {

      }
      __cp ++;
    }
    *__s = __cp;
  } else {

  }
  return ((char __attribute__((__gnu_inline__))  *)__retval);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strsep_3c(char **__s ,
                                                                   char __reject1 ,
                                                                   char __reject2 ,
                                                                   char __reject3 ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strsep_3c(char **__s ,
                                                                   char __reject1 ,
                                                                   char __reject2 ,
                                                                   char __reject3 ) 
{ 
  char *__retval ;
  char *__cp ;
  char *tmp ;

  {
  __retval = *__s;
  if ((unsigned long )__retval != (unsigned long )((void *)0)) {
    __cp = __retval;
    while (1) {
      if ((int )*__cp == 0) {
        __cp = (char *)((void *)0);
        break;
      } else {

      }
      if ((int )*__cp == (int )__reject1) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else
      if ((int )*__cp == (int )__reject2) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else
      if ((int )*__cp == (int )__reject3) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else {

      }
      __cp ++;
    }
    *__s = __cp;
  } else {

  }
  return ((char __attribute__((__gnu_inline__))  *)__retval);
}
}
extern  __attribute__((__nothrow__)) char *( __attribute__((__leaf__)) __strdup)(char const   *__string )  __attribute__((__malloc__)) ;
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memcpy)(void * __restrict  __dest ,
                            void const   * __restrict  __src , size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memcpy)(void * __restrict  __dest ,
                            void const   * __restrict  __src , size_t __len ) 
{ 
  unsigned long tmp ;
  void *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 0);
  tmp___0 = __builtin___memcpy_chk((void *)__dest, (void const   *)__src, __len,
                                   tmp);
  return ((void __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memmove)(void *__dest , void const   *__src , size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memmove)(void *__dest , void const   *__src , size_t __len ) 
{ 
  unsigned long tmp ;
  void *tmp___0 ;

  {
  tmp = __builtin_object_size(__dest, 0);
  tmp___0 = __builtin___memmove_chk(__dest, __src, __len, tmp);
  return ((void __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) mempcpy)(void * __restrict  __dest ,
                             void const   * __restrict  __src , size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) mempcpy)(void * __restrict  __dest ,
                             void const   * __restrict  __src , size_t __len ) 
{ 
  unsigned long tmp ;
  void *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 0);
  tmp___0 = __builtin___mempcpy_chk((void *)__dest, (void const   *)__src,
                                    __len, tmp);
  return ((void __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1),
__leaf__, __artificial__, __always_inline__)) memset)(void *__dest , int __ch ,
                                                      size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1),
__leaf__, __artificial__, __always_inline__)) memset)(void *__dest , int __ch ,
                                                      size_t __len ) 
{ 
  unsigned long tmp ;
  void *tmp___0 ;

  {
  tmp = __builtin_object_size(__dest, 0);
  tmp___0 = __builtin___memset_chk(__dest, __ch, __len, tmp);
  return ((void __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) bcopy)(void const   *__src , void *__dest , size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) bcopy)(void const   *__src , void *__dest , size_t __len ) 
{ 
  unsigned long tmp ;

  {
  tmp = __builtin_object_size(__dest, 0);
  __builtin___memmove_chk(__dest, __src, __len, tmp);
  return;
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) bzero)(void *__dest , size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) bzero)(void *__dest , size_t __len ) 
{ 
  unsigned long tmp ;

  {
  tmp = __builtin_object_size(__dest, 0);
  __builtin___memset_chk(__dest, '\000', __len, tmp);
  return;
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 1);
  tmp___0 = __builtin___strcpy_chk((char *)__dest, (char const   *)__src, tmp);
  return ((char __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 1);
  tmp___0 = __builtin___stpcpy_chk((char *)__dest, (char const   *)__src, tmp);
  return ((char __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 1);
  tmp___0 = __builtin___strncpy_chk((char *)__dest, (char const   *)__src,
                                    __len, tmp);
  return ((char __attribute__((__gnu_inline__))  *)tmp___0);
}
}
extern  __attribute__((__nothrow__)) char *( __attribute__((__leaf__)) __stpncpy_chk)(char *__dest ,
                                                                                      char const   *__src ,
                                                                                      size_t __n ,
                                                                                      size_t __destlen ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__leaf__)) __stpncpy_alias)(char *__dest ,
                                                                                        char const   *__src ,
                                                                                        size_t __n )  __asm__("stpncpy")  ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __n ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __n ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___3 ;

  {
  tmp___1 = __builtin_object_size((void *)__dest, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dest, 1);
    tmp___0 = __stpncpy_chk((char *)__dest, (char const   *)__src, __n, tmp);
    return ((char __attribute__((__gnu_inline__))  *)tmp___0);
  } else {

  }
  tmp___3 = __stpncpy_alias((char *)__dest, (char const   *)__src, __n);
  return ((char __attribute__((__gnu_inline__))  *)tmp___3);
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcat)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcat)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 1);
  tmp___0 = __builtin___strcat_chk((char *)__dest, (char const   *)__src, tmp);
  return ((char __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncat)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncat)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 1);
  tmp___0 = __builtin___strncat_chk((char *)__dest, (char const   *)__src,
                                    __len, tmp);
  return ((char __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbit)(double __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitf)(float __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitl)(long double __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitf)(float __x )  __attribute__((__const__)) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitf)(float __x ) 
{ 
  int __m ;

  {
  __asm__  ("pmovmskb %1, %0": "=r" (__m): "x" (__x));
  return ((int __attribute__((__gnu_inline__))  )((__m & 8) != 0));
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbit)(double __x )  __attribute__((__const__)) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbit)(double __x ) 
{ 
  int __m ;

  {
  __asm__  ("pmovmskb %1, %0": "=r" (__m): "x" (__x));
  return ((int __attribute__((__gnu_inline__))  )((__m & 128) != 0));
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitl)(long double __x )  __attribute__((__const__)) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitl)(long double __x ) 
{ 
  union __anonunion___u_23 __u ;

  {
  __u.__l = __x;
  return ((int __attribute__((__gnu_inline__))  )((__u.__i[2] & 32768) != 0));
}
}
extern int __uflow(_IO_FILE * ) ;
extern int __overflow(_IO_FILE * , int  ) ;
extern int _IO_getc(_IO_FILE *__fp ) ;
extern int _IO_putc(int __c , _IO_FILE *__fp ) ;
extern struct _IO_FILE *stdin ;
extern struct _IO_FILE *stdout ;
extern struct _IO_FILE *stderr ;
extern int fclose(FILE *__stream ) ;
extern int fflush(FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) fprintf)(FILE * __restrict  __stream ,
                             char const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) printf)(char const   * __restrict  __fmt  , ...) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) sprintf)(char * __restrict  __s ,
                                             char const   * __restrict  __fmt 
                                             , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vfprintf)(FILE * __restrict  __stream ,
                              char const   * __restrict  __fmt ,
                              __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vprintf)(char const   * __restrict  __fmt ,
                             __gnuc_va_list __ap ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) vsprintf)(char * __restrict  __s ,
                                              char const   * __restrict  __fmt ,
                                              __gnuc_va_list __ap ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) snprintf)(char * __restrict  __s ,
                              size_t __n , char const   * __restrict  __fmt 
                              , ...) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) vsnprintf)(char * __restrict  __s ,
                               size_t __n , char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) vasprintf)(char ** __restrict  __ptr ,
                               char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) __asprintf)(char ** __restrict  __ptr ,
                                char const   * __restrict  __fmt  , ...) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) asprintf)(char ** __restrict  __ptr ,
                              char const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vdprintf)(int __fd , char const   * __restrict  __fmt ,
                              __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) dprintf)(int __fd , char const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  getchar(void) ;
__inline extern int __attribute__((__gnu_inline__))  getc_unlocked(FILE *__fp ) ;
__inline extern int __attribute__((__gnu_inline__))  getchar_unlocked(void) ;
__inline extern int __attribute__((__gnu_inline__))  fgetc_unlocked(FILE *__fp ) ;
__inline extern int __attribute__((__gnu_inline__))  putchar(int __c ) ;
__inline extern int __attribute__((__gnu_inline__))  fputc_unlocked(int __c ,
                                                                    FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  putc_unlocked(int __c ,
                                                                   FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  putchar_unlocked(int __c ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) fgets)(char * __restrict  __s , int __n ,
                                           FILE * __restrict  __stream ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fgets_unlocked)(char * __restrict  __s ,
                                    int __n , FILE * __restrict  __stream ) ;
extern __ssize_t ( __attribute__((__warn_unused_result__)) __getdelim)(char ** __restrict  __lineptr ,
                                                                       size_t * __restrict  __n ,
                                                                       int __delimiter ,
                                                                       FILE * __restrict  __stream ) ;
__inline extern __ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__)) getline)(char ** __restrict  __lineptr ,
                                                                                                              size_t * __restrict  __n ,
                                                                                                              FILE * __restrict  __stream ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) fread)(void * __restrict  __ptr ,
                                           size_t __size , size_t __n ,
                                           FILE * __restrict  __stream ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fread_unlocked)(void * __restrict  __ptr ,
                                    size_t __size , size_t __n ,
                                    FILE * __restrict  __stream ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) feof_unlocked)(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) ferror_unlocked)(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) obstack_printf)(struct obstack * __restrict  __obstack ,
                                    char const   * __restrict  __fmt  , ...) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) obstack_vprintf)(struct obstack * __restrict  __obstack ,
                                     char const   * __restrict  __fmt ,
                                     __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  getchar(void) 
{ 
  int tmp ;

  {
  tmp = _IO_getc(stdin);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  fgetc_unlocked(FILE *__fp ) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  tmp___3 = __builtin_expect((long )((unsigned long )__fp->_IO_read_ptr >= (unsigned long )__fp->_IO_read_end),
                             0L);
  if (tmp___3) {
    tmp___0 = __uflow(__fp);
    tmp___2 = tmp___0;
  } else {
    tmp___1 = __fp->_IO_read_ptr;
    (__fp->_IO_read_ptr) ++;
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
__inline extern int __attribute__((__gnu_inline__))  getc_unlocked(FILE *__fp ) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  tmp___3 = __builtin_expect((long )((unsigned long )__fp->_IO_read_ptr >= (unsigned long )__fp->_IO_read_end),
                             0L);
  if (tmp___3) {
    tmp___0 = __uflow(__fp);
    tmp___2 = tmp___0;
  } else {
    tmp___1 = __fp->_IO_read_ptr;
    (__fp->_IO_read_ptr) ++;
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
__inline extern int __attribute__((__gnu_inline__))  getchar_unlocked(void) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  tmp___3 = __builtin_expect((long )((unsigned long )stdin->_IO_read_ptr >= (unsigned long )stdin->_IO_read_end),
                             0L);
  if (tmp___3) {
    tmp___0 = __uflow(stdin);
    tmp___2 = tmp___0;
  } else {
    tmp___1 = stdin->_IO_read_ptr;
    (stdin->_IO_read_ptr) ++;
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
__inline extern int __attribute__((__gnu_inline__))  putchar(int __c ) 
{ 
  int tmp ;

  {
  tmp = _IO_putc(__c, stdout);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  fputc_unlocked(int __c ,
                                                                    FILE *__stream ) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  tmp___4 = __builtin_expect((long )((unsigned long )__stream->_IO_write_ptr >= (unsigned long )__stream->_IO_write_end),
                             0L);
  if (tmp___4) {
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    tmp___3 = tmp___0;
  } else {
    tmp___1 = __stream->_IO_write_ptr;
    (__stream->_IO_write_ptr) ++;
    tmp___2 = (char )__c;
    *tmp___1 = tmp___2;
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___3);
}
}
__inline extern int __attribute__((__gnu_inline__))  putc_unlocked(int __c ,
                                                                   FILE *__stream ) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  tmp___4 = __builtin_expect((long )((unsigned long )__stream->_IO_write_ptr >= (unsigned long )__stream->_IO_write_end),
                             0L);
  if (tmp___4) {
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    tmp___3 = tmp___0;
  } else {
    tmp___1 = __stream->_IO_write_ptr;
    (__stream->_IO_write_ptr) ++;
    tmp___2 = (char )__c;
    *tmp___1 = tmp___2;
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___3);
}
}
__inline extern int __attribute__((__gnu_inline__))  putchar_unlocked(int __c ) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  tmp___4 = __builtin_expect((long )((unsigned long )stdout->_IO_write_ptr >= (unsigned long )stdout->_IO_write_end),
                             0L);
  if (tmp___4) {
    tmp___0 = __overflow(stdout, (int )((unsigned char )__c));
    tmp___3 = tmp___0;
  } else {
    tmp___1 = stdout->_IO_write_ptr;
    (stdout->_IO_write_ptr) ++;
    tmp___2 = (char )__c;
    *tmp___1 = tmp___2;
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___3);
}
}
__inline extern __ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__)) getline)(char ** __restrict  __lineptr ,
                                                                                                              size_t * __restrict  __n ,
                                                                                                              FILE * __restrict  __stream ) 
{ 
  __ssize_t tmp ;

  {
  tmp = __getdelim(__lineptr, __n, '\n', __stream);
  return ((__ssize_t __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) feof_unlocked)(FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) feof_unlocked)(FILE *__stream ) 
{ 


  {
  return ((int __attribute__((__gnu_inline__))  )((__stream->_flags & 16) != 0));
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) ferror_unlocked)(FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) ferror_unlocked)(FILE *__stream ) 
{ 


  {
  return ((int __attribute__((__gnu_inline__))  )((__stream->_flags & 32) != 0));
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) sprintf)(char * __restrict  __s ,
                                             char const   * __restrict  __fmt 
                                             , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) sprintf)(char * __restrict  __s ,
                                             char const   * __restrict  __fmt 
                                             , ...) 
{ 
  unsigned long tmp ;
  int tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__s, 1);
  tmp___0 = __builtin___sprintf_chk((char *)__s, 1, tmp, (char const   *)__fmt,
                                    __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) vsprintf)(char * __restrict  __s ,
                                              char const   * __restrict  __fmt ,
                                              __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) vsprintf)(char * __restrict  __s ,
                                              char const   * __restrict  __fmt ,
                                              __gnuc_va_list __ap ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__s, 1);
  tmp___0 = __builtin___vsprintf_chk((char *)__s, 1, tmp, (char const   *)__fmt,
                                     __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) snprintf)(char * __restrict  __s ,
                              size_t __n , char const   * __restrict  __fmt 
                              , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) snprintf)(char * __restrict  __s ,
                              size_t __n , char const   * __restrict  __fmt 
                              , ...) 
{ 
  unsigned long tmp ;
  int tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__s, 1);
  tmp___0 = __builtin___snprintf_chk((char *)__s, __n, 1, tmp,
                                     (char const   *)__fmt,
                                     __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) vsnprintf)(char * __restrict  __s ,
                               size_t __n , char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) vsnprintf)(char * __restrict  __s ,
                               size_t __n , char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__s, 1);
  tmp___0 = __builtin___vsnprintf_chk((char *)__s, __n, 1, tmp,
                                      (char const   *)__fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
extern int __fprintf_chk(FILE * __restrict  __stream , int __flag ,
                         char const   * __restrict  __format  , ...) ;
extern int __printf_chk(int __flag , char const   * __restrict  __format  , ...) ;
extern int __vfprintf_chk(FILE * __restrict  __stream , int __flag ,
                          char const   * __restrict  __format ,
                          __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) fprintf)(FILE * __restrict  __stream ,
                             char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __fprintf_chk(__stream, 1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) printf)(char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __printf_chk(1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vprintf)(char const   * __restrict  __fmt ,
                             __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __vfprintf_chk((FILE */* __restrict  */)stdout, 1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vfprintf)(FILE * __restrict  __stream ,
                              char const   * __restrict  __fmt ,
                              __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __vfprintf_chk(__stream, 1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
extern int __dprintf_chk(int __fd , int __flag ,
                         char const   * __restrict  __fmt  , ...) ;
extern int __vdprintf_chk(int __fd , int __flag ,
                          char const   * __restrict  __fmt ,
                          __gnuc_va_list __arg ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) dprintf)(int __fd , char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __dprintf_chk(__fd, 1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vdprintf)(int __fd , char const   * __restrict  __fmt ,
                              __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __vdprintf_chk(__fd, 1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __asprintf_chk)(char ** __restrict  __ptr , int __flag ,
                           char const   * __restrict  __fmt  , ...) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __vasprintf_chk)(char ** __restrict  __ptr , int __flag ,
                            char const   * __restrict  __fmt ,
                            __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__leaf__)) __obstack_printf_chk)(struct obstack * __restrict  __obstack ,
                                                                                           int __flag ,
                                                                                           char const   * __restrict  __format 
                                                                                           , ...) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__leaf__)) __obstack_vprintf_chk)(struct obstack * __restrict  __obstack ,
                                                                                            int __flag ,
                                                                                            char const   * __restrict  __format ,
                                                                                            __gnuc_va_list __args ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) asprintf)(char ** __restrict  __ptr ,
                              char const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) asprintf)(char ** __restrict  __ptr ,
                              char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __asprintf_chk(__ptr, 1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) __asprintf)(char ** __restrict  __ptr ,
                                char const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) __asprintf)(char ** __restrict  __ptr ,
                                char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __asprintf_chk(__ptr, 1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) obstack_printf)(struct obstack * __restrict  __obstack ,
                                    char const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) obstack_printf)(struct obstack * __restrict  __obstack ,
                                    char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __obstack_printf_chk(__obstack, 1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) vasprintf)(char ** __restrict  __ptr ,
                               char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) vasprintf)(char ** __restrict  __ptr ,
                               char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __vasprintf_chk(__ptr, 1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) obstack_vprintf)(struct obstack * __restrict  __obstack ,
                                     char const   * __restrict  __fmt ,
                                     __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) obstack_vprintf)(struct obstack * __restrict  __obstack ,
                                     char const   * __restrict  __fmt ,
                                     __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __obstack_vprintf_chk(__obstack, 1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
extern char *( __attribute__((__warn_unused_result__)) __fgets_chk)(char * __restrict  __s ,
                                                                    size_t __size ,
                                                                    int __n ,
                                                                    FILE * __restrict  __stream ) ;
extern char *( __attribute__((__warn_unused_result__)) __fgets_alias)(char * __restrict  __s ,
                                                                      int __n ,
                                                                      FILE * __restrict  __stream )  __asm__("fgets")  ;
extern char *( __attribute__((__warn_unused_result__)) __fgets_chk_warn)(char * __restrict  __s ,
                                                                         size_t __size ,
                                                                         int __n ,
                                                                         FILE * __restrict  __stream )  __asm__("__fgets_chk") __attribute__((__warning__("fgets called with bigger size than length of destination buffer"))) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) fgets)(char * __restrict  __s , int __n ,
                                           FILE * __restrict  __stream ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  char *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__s, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s, 1);
    tmp___0 = __fgets_chk(__s, tmp, __n, __stream);
    return ((char __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__s, 1);
    if ((size_t )__n > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__s, 1);
      tmp___2 = __fgets_chk_warn(__s, tmp___1, __n, __stream);
      return ((char __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __fgets_alias(__s, __n, __stream);
  return ((char __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern size_t ( __attribute__((__warn_unused_result__)) __fread_chk)(void * __restrict  __ptr ,
                                                                     size_t __ptrlen ,
                                                                     size_t __size ,
                                                                     size_t __n ,
                                                                     FILE * __restrict  __stream ) ;
extern size_t ( __attribute__((__warn_unused_result__)) __fread_alias)(void * __restrict  __ptr ,
                                                                       size_t __size ,
                                                                       size_t __n ,
                                                                       FILE * __restrict  __stream )  __asm__("fread")  ;
extern size_t ( __attribute__((__warn_unused_result__)) __fread_chk_warn)(void * __restrict  __ptr ,
                                                                          size_t __ptrlen ,
                                                                          size_t __size ,
                                                                          size_t __n ,
                                                                          FILE * __restrict  __stream )  __asm__("__fread_chk") __attribute__((__warning__("fread called with bigger size * nmemb than length of destination buffer"))) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) fread)(void * __restrict  __ptr ,
                                           size_t __size , size_t __n ,
                                           FILE * __restrict  __stream ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__ptr, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__ptr, 0);
    tmp___0 = __fread_chk(__ptr, tmp, __size, __n, __stream);
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__ptr, 0);
    if (__size * __n > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__ptr, 0);
      tmp___2 = __fread_chk_warn(__ptr, tmp___1, __size, __n, __stream);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __fread_alias(__ptr, __size, __n, __stream);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern char *( __attribute__((__warn_unused_result__)) __fgets_unlocked_chk)(char * __restrict  __s ,
                                                                             size_t __size ,
                                                                             int __n ,
                                                                             FILE * __restrict  __stream ) ;
extern char *( __attribute__((__warn_unused_result__)) __fgets_unlocked_alias)(char * __restrict  __s ,
                                                                               int __n ,
                                                                               FILE * __restrict  __stream )  __asm__("fgets_unlocked")  ;
extern char *( __attribute__((__warn_unused_result__)) __fgets_unlocked_chk_warn)(char * __restrict  __s ,
                                                                                  size_t __size ,
                                                                                  int __n ,
                                                                                  FILE * __restrict  __stream )  __asm__("__fgets_unlocked_chk") __attribute__((__warning__("fgets_unlocked called with bigger size than length of destination buffer"))) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fgets_unlocked)(char * __restrict  __s ,
                                    int __n , FILE * __restrict  __stream ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  char *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__s, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s, 1);
    tmp___0 = __fgets_unlocked_chk(__s, tmp, __n, __stream);
    return ((char __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__s, 1);
    if ((size_t )__n > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__s, 1);
      tmp___2 = __fgets_unlocked_chk_warn(__s, tmp___1, __n, __stream);
      return ((char __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __fgets_unlocked_alias(__s, __n, __stream);
  return ((char __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern size_t ( __attribute__((__warn_unused_result__)) __fread_unlocked_chk)(void * __restrict  __ptr ,
                                                                              size_t __ptrlen ,
                                                                              size_t __size ,
                                                                              size_t __n ,
                                                                              FILE * __restrict  __stream ) ;
extern size_t ( __attribute__((__warn_unused_result__)) __fread_unlocked_alias)(void * __restrict  __ptr ,
                                                                                size_t __size ,
                                                                                size_t __n ,
                                                                                FILE * __restrict  __stream )  __asm__("fread_unlocked")  ;
extern size_t ( __attribute__((__warn_unused_result__)) __fread_unlocked_chk_warn)(void * __restrict  __ptr ,
                                                                                   size_t __ptrlen ,
                                                                                   size_t __size ,
                                                                                   size_t __n ,
                                                                                   FILE * __restrict  __stream )  __asm__("__fread_unlocked_chk") __attribute__((__warning__("fread_unlocked called with bigger size * nmemb than length of destination buffer"))) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fread_unlocked)(void * __restrict  __ptr ,
                                    size_t __size , size_t __n ,
                                    FILE * __restrict  __stream ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___11 ;

  {
  tmp___4 = __builtin_object_size((void *)__ptr, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__ptr, 0);
    tmp___0 = __fread_unlocked_chk(__ptr, tmp, __size, __n, __stream);
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__ptr, 0);
    if (__size * __n > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__ptr, 0);
      tmp___2 = __fread_unlocked_chk_warn(__ptr, tmp___1, __size, __n, __stream);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___11 = __fread_unlocked_alias(__ptr, __size, __n, __stream);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___11);
}
}
extern void __attribute__((__visibility__("default")))  *_emalloc(size_t size )  __attribute__((__malloc__)) ;
extern void __attribute__((__visibility__("default")))  _efree(void *ptr ) ;
extern void __attribute__((__visibility__("default")))  *_ecalloc(size_t nmemb ,
                                                                  size_t size )  __attribute__((__malloc__)) ;
extern void __attribute__((__visibility__("default")))  *_erealloc(void *ptr ,
                                                                   size_t size ,
                                                                   int allow_failure ) ;
extern char __attribute__((__visibility__("default")))  *_estrdup(char const   *s )  __attribute__((__malloc__)) ;
extern char __attribute__((__visibility__("default")))  *_estrndup(char const   *s ,
                                                                   unsigned int length )  __attribute__((__malloc__)) ;
__inline static void *__zend_malloc(size_t len ) 
{ 
  void *tmp ;
  void *tmp___0 ;

  {
  tmp___0 = malloc(len);
  tmp = tmp___0;
  if (tmp) {
    return (tmp);
  } else {

  }
  fprintf((FILE */* __restrict  */)stderr,
          (char const   */* __restrict  */)"Out of memory\n");
  exit(1);
}
}
__inline static void *__zend_realloc(void *p , size_t len ) 
{ 


  {
  p = realloc(p, len);
  if (p) {
    return (p);
  } else {

  }
  fprintf((FILE */* __restrict  */)stderr,
          (char const   */* __restrict  */)"Out of memory\n");
  exit(1);
}
}
extern int __attribute__((__visibility__("default")))  _zend_hash_init(HashTable *ht ,
                                                                       uint nSize ,
                                                                       ulong (*pHashFunction)(char const   *arKey ,
                                                                                              uint nKeyLength ) ,
                                                                       void (*pDestructor)(void *pDest ) ,
                                                                       zend_bool persistent ) ;
extern void __attribute__((__visibility__("default")))  zend_hash_destroy(HashTable *ht ) ;
extern int __attribute__((__visibility__("default")))  _zend_hash_add_or_update(HashTable *ht ,
                                                                                char const   *arKey ,
                                                                                uint nKeyLength ,
                                                                                void *pData ,
                                                                                uint nDataSize ,
                                                                                void **pDest ,
                                                                                int flag ) ;
extern void __attribute__((__visibility__("default")))  zend_hash_apply(HashTable *ht ,
                                                                        int (*apply_func)(void *pDest ) ) ;
extern void __attribute__((__visibility__("default")))  zend_hash_apply_with_argument(HashTable *ht ,
                                                                                      int (*apply_func)(void *pDest ,
                                                                                                        void *argument ) ,
                                                                                      void * ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_del_key_or_index(HashTable *ht ,
                                                                                  char const   *arKey ,
                                                                                  uint nKeyLength ,
                                                                                  ulong h ,
                                                                                  int flag ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_find(HashTable const   *ht ,
                                                                      char const   *arKey ,
                                                                      uint nKeyLength ,
                                                                      void **pData ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_move_forward_ex(HashTable *ht ,
                                                                                 HashPosition *pos ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_get_current_key_ex(HashTable const   *ht ,
                                                                                    char **str_index ,
                                                                                    uint *str_length ,
                                                                                    ulong *num_index ,
                                                                                    zend_bool duplicate ,
                                                                                    HashPosition *pos ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_get_current_data_ex(HashTable *ht ,
                                                                                     void **pData ,
                                                                                     HashPosition *pos ) ;
extern void __attribute__((__visibility__("default")))  zend_hash_internal_pointer_reset_ex(HashTable *ht ,
                                                                                            HashPosition *pos ) ;
extern void __attribute__((__visibility__("default")))  zend_hash_copy(HashTable *target ,
                                                                       HashTable *source ,
                                                                       void (*pCopyConstructor)(void *pElement ) ,
                                                                       void *tmp ,
                                                                       uint size ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_num_elements(HashTable const   *ht ) ;
extern void __attribute__((__visibility__("default")))  zend_llist_init(zend_llist *l ,
                                                                        size_t size ,
                                                                        void (*dtor)(void * ) ,
                                                                        unsigned char persistent ) ;
extern void __attribute__((__visibility__("default")))  zend_llist_add_element(zend_llist *l ,
                                                                               void *element ) ;
extern void __attribute__((__visibility__("default")))  zend_llist_destroy(zend_llist *l ) ;
extern int __attribute__((__visibility__("default")))  zend_llist_count(zend_llist *l ) ;
extern void __attribute__((__visibility__("default")))  *zend_llist_get_first_ex(zend_llist *l ,
                                                                                 zend_llist_position *pos ) ;
extern void __attribute__((__visibility__("default")))  *zend_llist_get_next_ex(zend_llist *l ,
                                                                                zend_llist_position *pos ) ;
extern char __attribute__((__visibility__("default")))  *(*zend_resolve_path)(char const   *filename ,
                                                                              int filename_len ) ;
extern zval __attribute__((__visibility__("default")))  zval_used_for_init ;
extern  __attribute__((__nothrow__)) int *( __attribute__((__leaf__)) __errno_location)(void)  __attribute__((__const__)) ;
__inline static char *zend_memnstr(char *haystack , char *needle ,
                                   int needle_len , char *end ) 
{ 
  char *p ;
  char ne ;
  void *tmp ;
  int tmp___0 ;
  void *tmp___1 ;

  {
  p = haystack;
  ne = *(needle + (needle_len - 1));
  if (needle_len == 1) {
    tmp = memchr((void const   *)p, (int )*needle, (size_t )(end - p));
    return ((char *)tmp);
  } else {

  }
  if ((long )needle_len > end - haystack) {
    return ((char *)((void *)0));
  } else {

  }
  end -= needle_len;
  while ((unsigned long )p <= (unsigned long )end) {
    tmp___1 = memchr((void const   *)p, (int )*needle, (size_t )((end - p) + 1L));
    p = (char *)tmp___1;
    if (p) {
      if ((int )ne == (int )*(p + (needle_len - 1))) {
        tmp___0 = memcmp((void const   *)needle, (void const   *)p,
                         (size_t )(needle_len - 1));
        if (! tmp___0) {
          return (p);
        } else {

        }
      } else {

      }
    } else {

    }
    if ((unsigned long )p == (unsigned long )((void *)0)) {
      return ((char *)((void *)0));
    } else {

    }
    p ++;
  }
  return ((char *)((void *)0));
}
}
extern void __attribute__((__visibility__("default")))  _zval_copy_ctor_func(zval *zvalue ) ;
__inline static void ( __attribute__((__always_inline__)) _zval_copy_ctor)(zval *zvalue ) 
{ 


  {
  if ((int )zvalue->type <= 3) {
    return;
  } else {

  }
  _zval_copy_ctor_func(zvalue);
  return;
}
}
extern void __attribute__((__visibility__("default")))  _zval_ptr_dtor(zval **zval_ptr ) ;
extern zend_executor_globals __attribute__((__visibility__("default")))  executor_globals ;
extern int __attribute__((__visibility__("default")))  zend_register_list_destructors_ex(void (*ld)(zend_rsrc_list_entry *rsrc ) ,
                                                                                         void (*pld)(zend_rsrc_list_entry *rsrc ) ,
                                                                                         char const   *type_name ,
                                                                                         int module_number ) ;
extern int __attribute__((__visibility__("default")))  _zend_list_addref(int id ) ;
extern int __attribute__((__visibility__("default")))  _zend_list_delete(int id ) ;
extern int __attribute__((__visibility__("default")))  zend_register_resource(zval *rsrc_result ,
                                                                              void *rsrc_pointer ,
                                                                              int rsrc_type ) ;
extern int __attribute__((__visibility__("default")))  _array_init(zval *arg ,
                                                                   uint size ) ;
extern size_t __attribute__((__visibility__("default")))  php_strlcpy(char *dst ,
                                                                      char const   *src ,
                                                                      size_t siz ) ;
extern  __attribute__((__nothrow__)) unsigned short const   **( __attribute__((__leaf__)) __ctype_b_loc)(void)  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) __int32_t const   **( __attribute__((__leaf__)) __ctype_tolower_loc)(void)  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) __int32_t const   **( __attribute__((__leaf__)) __ctype_toupper_loc)(void)  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) tolower)(int __c ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) toupper)(int __c ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) tolower)(int __c ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) tolower)(int __c ) 
{ 
  __int32_t const   **tmp ;
  __int32_t tmp___0 ;

  {
  if (__c >= -128) {
    if (__c < 256) {
      tmp = __ctype_tolower_loc();
      tmp___0 = (__int32_t )*(*tmp + __c);
    } else {
      tmp___0 = (__int32_t )((__int32_t const   )__c);
    }
  } else {
    tmp___0 = (__int32_t )((__int32_t const   )__c);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) toupper)(int __c ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) toupper)(int __c ) 
{ 
  __int32_t const   **tmp ;
  __int32_t tmp___0 ;

  {
  if (__c >= -128) {
    if (__c < 256) {
      tmp = __ctype_toupper_loc();
      tmp___0 = (__int32_t )*(*tmp + __c);
    } else {
      tmp___0 = (__int32_t )((__int32_t const   )__c);
    }
  } else {
    tmp___0 = (__int32_t )((__int32_t const   )__c);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) read)(int __fd , void *__buf ,
                                          size_t __nbytes ) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) pread)(int __fd , void *__buf ,
                           size_t __nbytes , __off_t __offset ) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) pread64)(int __fd , void *__buf ,
                                             size_t __nbytes ,
                                             __off64_t __offset ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) getcwd)(char *__buf , size_t __size ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__,
__deprecated__))  *( __attribute__((__warn_unused_result__, __nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) getwd)(char *__buf )  __attribute__((__deprecated__)) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) confstr)(int __name , char *__buf ,
                                             size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) getgroups)(int __size , __gid_t *__list ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(2), __leaf__, __artificial__,
__always_inline__)) ttyname_r)(int __fd , char *__buf , size_t __buflen ) ;
__inline extern  __attribute__((__nothrow__)) ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1,2), __leaf__, __artificial__,
__always_inline__)) readlink)(char const   * __restrict  __path ,
                              char * __restrict  __buf , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(2,3), __leaf__, __artificial__,
__always_inline__)) readlinkat)(int __fd , char const   * __restrict  __path ,
                                char * __restrict  __buf , size_t __len ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__artificial__,
__always_inline__)) getlogin_r)(char *__buf , size_t __buflen ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) gethostname)(char *__buf , size_t __buflen ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__, __artificial__,
__always_inline__)) getdomainname)(char *__buf , size_t __buflen ) ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __read_chk)(int __fd ,
                                                                     void *__buf ,
                                                                     size_t __nbytes ,
                                                                     size_t __buflen ) ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __read_alias)(int __fd ,
                                                                       void *__buf ,
                                                                       size_t __nbytes )  __asm__("read")  ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __read_chk_warn)(int __fd ,
                                                                          void *__buf ,
                                                                          size_t __nbytes ,
                                                                          size_t __buflen )  __asm__("__read_chk") __attribute__((__warning__("read called with bigger length than size of the destination buffer"))) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) read)(int __fd , void *__buf ,
                                          size_t __nbytes ) 
{ 
  unsigned long tmp ;
  ssize_t tmp___0 ;
  unsigned long tmp___1 ;
  ssize_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  ssize_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size(__buf, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size(__buf, 0);
    tmp___0 = __read_chk(__fd, __buf, __nbytes, tmp);
    return ((ssize_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size(__buf, 0);
    if (__nbytes > tmp___3) {
      tmp___1 = __builtin_object_size(__buf, 0);
      tmp___2 = __read_chk_warn(__fd, __buf, __nbytes, tmp___1);
      return ((ssize_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __read_alias(__fd, __buf, __nbytes);
  return ((ssize_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern ssize_t ( __attribute__((__warn_unused_result__)) __pread_chk)(int __fd ,
                                                                      void *__buf ,
                                                                      size_t __nbytes ,
                                                                      __off_t __offset ,
                                                                      size_t __bufsize ) ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __pread64_chk)(int __fd ,
                                                                        void *__buf ,
                                                                        size_t __nbytes ,
                                                                        __off64_t __offset ,
                                                                        size_t __bufsize ) ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __pread_alias)(int __fd ,
                                                                        void *__buf ,
                                                                        size_t __nbytes ,
                                                                        __off_t __offset )  __asm__("pread")  ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __pread64_alias)(int __fd ,
                                                                          void *__buf ,
                                                                          size_t __nbytes ,
                                                                          __off64_t __offset )  __asm__("pread64")  ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __pread_chk_warn)(int __fd ,
                                                                           void *__buf ,
                                                                           size_t __nbytes ,
                                                                           __off_t __offset ,
                                                                           size_t __bufsize )  __asm__("__pread_chk") __attribute__((__warning__("pread called with bigger length than size of the destination buffer"))) ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __pread64_chk_warn)(int __fd ,
                                                                             void *__buf ,
                                                                             size_t __nbytes ,
                                                                             __off64_t __offset ,
                                                                             size_t __bufsize )  __asm__("__pread64_chk") __attribute__((__warning__("pread64 called with bigger length than size of the destination buffer"))) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) pread)(int __fd , void *__buf ,
                                           size_t __nbytes , __off_t __offset ) 
{ 
  unsigned long tmp ;
  ssize_t tmp___0 ;
  unsigned long tmp___1 ;
  ssize_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  ssize_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size(__buf, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size(__buf, 0);
    tmp___0 = __pread_chk(__fd, __buf, __nbytes, __offset, tmp);
    return ((ssize_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size(__buf, 0);
    if (__nbytes > tmp___3) {
      tmp___1 = __builtin_object_size(__buf, 0);
      tmp___2 = __pread_chk_warn(__fd, __buf, __nbytes, __offset, tmp___1);
      return ((ssize_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __pread_alias(__fd, __buf, __nbytes, __offset);
  return ((ssize_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) pread64)(int __fd , void *__buf ,
                                             size_t __nbytes ,
                                             __off64_t __offset ) 
{ 
  unsigned long tmp ;
  ssize_t tmp___0 ;
  unsigned long tmp___1 ;
  ssize_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  ssize_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size(__buf, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size(__buf, 0);
    tmp___0 = __pread64_chk(__fd, __buf, __nbytes, __offset, tmp);
    return ((ssize_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size(__buf, 0);
    if (__nbytes > tmp___3) {
      tmp___1 = __builtin_object_size(__buf, 0);
      tmp___2 = __pread64_chk_warn(__fd, __buf, __nbytes, __offset, tmp___1);
      return ((ssize_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __pread64_alias(__fd, __buf, __nbytes, __offset);
  return ((ssize_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__warn_unused_result__,
__nonnull__(1,2), __leaf__)) __readlink_chk)(char const   * __restrict  __path ,
                                             char * __restrict  __buf ,
                                             size_t __len , size_t __buflen ) ;
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__warn_unused_result__,
__nonnull__(1,2),
__leaf__)) __readlink_alias)(char const   * __restrict  __path ,
                             char * __restrict  __buf , size_t __len )  __asm__("readlink")  ;
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__warn_unused_result__,
__nonnull__(1,2),
__leaf__)) __readlink_chk_warn)(char const   * __restrict  __path ,
                                char * __restrict  __buf , size_t __len ,
                                size_t __buflen )  __asm__("__readlink_chk") __attribute__((__warning__("readlink called with bigger length than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1,2), __leaf__, __artificial__,
__always_inline__)) readlink)(char const   * __restrict  __path ,
                              char * __restrict  __buf , size_t __len ) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1,2), __leaf__, __artificial__,
__always_inline__)) readlink)(char const   * __restrict  __path ,
                              char * __restrict  __buf , size_t __len ) 
{ 
  unsigned long tmp ;
  ssize_t tmp___0 ;
  unsigned long tmp___1 ;
  ssize_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  ssize_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __readlink_chk(__path, __buf, __len, tmp);
    return ((ssize_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__len > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __readlink_chk_warn(__path, __buf, __len, tmp___1);
      return ((ssize_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __readlink_alias(__path, __buf, __len);
  return ((ssize_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__warn_unused_result__,
__nonnull__(2,3),
__leaf__)) __readlinkat_chk)(int __fd , char const   * __restrict  __path ,
                             char * __restrict  __buf , size_t __len ,
                             size_t __buflen ) ;
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__warn_unused_result__,
__nonnull__(2,3),
__leaf__)) __readlinkat_alias)(int __fd , char const   * __restrict  __path ,
                               char * __restrict  __buf , size_t __len )  __asm__("readlinkat")  ;
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__warn_unused_result__,
__nonnull__(2,3),
__leaf__)) __readlinkat_chk_warn)(int __fd , char const   * __restrict  __path ,
                                  char * __restrict  __buf , size_t __len ,
                                  size_t __buflen )  __asm__("__readlinkat_chk") __attribute__((__warning__("readlinkat called with bigger length than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(2,3), __leaf__, __artificial__,
__always_inline__)) readlinkat)(int __fd , char const   * __restrict  __path ,
                                char * __restrict  __buf , size_t __len ) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(2,3), __leaf__, __artificial__,
__always_inline__)) readlinkat)(int __fd , char const   * __restrict  __path ,
                                char * __restrict  __buf , size_t __len ) 
{ 
  unsigned long tmp ;
  ssize_t tmp___0 ;
  unsigned long tmp___1 ;
  ssize_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  ssize_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __readlinkat_chk(__fd, __path, __buf, __len, tmp);
    return ((ssize_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__len > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __readlinkat_chk_warn(__fd, __path, __buf, __len, tmp___1);
      return ((ssize_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __readlinkat_alias(__fd, __path, __buf, __len);
  return ((ssize_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__leaf__)) __getcwd_chk)(char *__buf , size_t __size , size_t __buflen ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__leaf__)) __getcwd_alias)(char *__buf , size_t __size )  __asm__("getcwd")  ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__leaf__)) __getcwd_chk_warn)(char *__buf , size_t __size , size_t __buflen )  __asm__("__getcwd_chk") __attribute__((__warning__("getcwd caller with bigger length than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) getcwd)(char *__buf , size_t __size ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) getcwd)(char *__buf , size_t __size ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  char *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __getcwd_chk(__buf, __size, tmp);
    return ((char __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__size > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __getcwd_chk_warn(__buf, __size, tmp___1);
      return ((char __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __getcwd_alias(__buf, __size);
  return ((char __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) __getwd_chk)(char *__buf , size_t buflen ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) __getwd_warn)(char *__buf )  __asm__("getwd") __attribute__((__warning__("please use getcwd instead, as getwd doesn\'t specify buffer size"))) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__,
__deprecated__))  *( __attribute__((__warn_unused_result__, __nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) getwd)(char *__buf )  __attribute__((__deprecated__)) ;
__inline extern char __attribute__((__gnu_inline__,
__deprecated__))  *( __attribute__((__warn_unused_result__, __nonnull__(1),
__leaf__, __artificial__, __always_inline__)) getwd)(char *__buf ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__buf, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __getwd_chk(__buf, tmp);
    return ((char __attribute__((__gnu_inline__, __deprecated__))  *)tmp___0);
  } else {

  }
  tmp___2 = __getwd_warn(__buf);
  return ((char __attribute__((__gnu_inline__, __deprecated__))  *)tmp___2);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __confstr_chk)(int __name ,
                                                                                       char *__buf ,
                                                                                       size_t __len ,
                                                                                       size_t __buflen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __confstr_alias)(int __name ,
                                                                                         char *__buf ,
                                                                                         size_t __len )  __asm__("confstr")  ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __confstr_chk_warn)(int __name ,
                                                                                            char *__buf ,
                                                                                            size_t __len ,
                                                                                            size_t __buflen )  __asm__("__confstr_chk") __attribute__((__warning__("confstr called with bigger length than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) confstr)(int __name , char *__buf ,
                                             size_t __len ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) confstr)(int __name , char *__buf ,
                                             size_t __len ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __confstr_chk(__name, __buf, __len, tmp);
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (tmp___3 < __len) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __confstr_chk_warn(__name, __buf, __len, tmp___1);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __confstr_alias(__name, __buf, __len);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __getgroups_chk)(int __size , __gid_t *__list , size_t __listlen ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __getgroups_alias)(int __size , __gid_t *__list )  __asm__("getgroups")  ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __getgroups_chk_warn)(int __size , __gid_t *__list ,
                                 size_t __listlen )  __asm__("__getgroups_chk") __attribute__((__warning__("getgroups called with bigger group count than what can fit into destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) getgroups)(int __size , __gid_t *__list ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) getgroups)(int __size , __gid_t *__list ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__list, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__list, 1);
    tmp___0 = __getgroups_chk(__size, __list, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__list, 1);
    if ((unsigned long )__size * sizeof(__gid_t ) > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__list, 1);
      tmp___2 = __getgroups_chk_warn(__size, __list, tmp___1);
      return ((int __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __getgroups_alias(__size, __list);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ttyname_r_chk)(int __fd , char *__buf , size_t __buflen ,
                            size_t __nreal ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ttyname_r_alias)(int __fd , char *__buf , size_t __buflen )  __asm__("ttyname_r")  ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ttyname_r_chk_warn)(int __fd , char *__buf , size_t __buflen ,
                                 size_t __nreal )  __asm__("__ttyname_r_chk") __attribute__((__warning__("ttyname_r called with bigger buflen than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(2), __leaf__, __artificial__,
__always_inline__)) ttyname_r)(int __fd , char *__buf , size_t __buflen ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(2), __leaf__, __artificial__,
__always_inline__)) ttyname_r)(int __fd , char *__buf , size_t __buflen ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __ttyname_r_chk(__fd, __buf, __buflen, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__buflen > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __ttyname_r_chk_warn(__fd, __buf, __buflen, tmp___1);
      return ((int __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __ttyname_r_alias(__fd, __buf, __buflen);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern int ( __attribute__((__nonnull__(1))) __getlogin_r_chk)(char *__buf ,
                                                               size_t __buflen ,
                                                               size_t __nreal ) ;
extern int ( __attribute__((__nonnull__(1))) __getlogin_r_alias)(char *__buf ,
                                                                 size_t __buflen )  __asm__("getlogin_r")  ;
extern int ( __attribute__((__nonnull__(1))) __getlogin_r_chk_warn)(char *__buf ,
                                                                    size_t __buflen ,
                                                                    size_t __nreal )  __asm__("__getlogin_r_chk") __attribute__((__warning__("getlogin_r called with bigger buflen than size of destination buffer"))) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__artificial__, __always_inline__)) getlogin_r)(char *__buf , size_t __buflen ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __getlogin_r_chk(__buf, __buflen, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__buflen > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __getlogin_r_chk_warn(__buf, __buflen, tmp___1);
      return ((int __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __getlogin_r_alias(__buf, __buflen);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1),
__leaf__)) __gethostname_chk)(char *__buf , size_t __buflen , size_t __nreal ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1),
__leaf__)) __gethostname_alias)(char *__buf , size_t __buflen )  __asm__("gethostname")  ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1),
__leaf__)) __gethostname_chk_warn)(char *__buf , size_t __buflen ,
                                   size_t __nreal )  __asm__("__gethostname_chk") __attribute__((__warning__("gethostname called with bigger buflen than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) gethostname)(char *__buf , size_t __buflen ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) gethostname)(char *__buf , size_t __buflen ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __gethostname_chk(__buf, __buflen, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__buflen > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __gethostname_chk_warn(__buf, __buflen, tmp___1);
      return ((int __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __gethostname_alias(__buf, __buflen);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) __getdomainname_chk)(char *__buf , size_t __buflen ,
                                                size_t __nreal ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) __getdomainname_alias)(char *__buf , size_t __buflen )  __asm__("getdomainname")  ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) __getdomainname_chk_warn)(char *__buf , size_t __buflen ,
                                     size_t __nreal )  __asm__("__getdomainname_chk") __attribute__((__warning__("getdomainname called with bigger buflen than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__, __artificial__,
__always_inline__)) getdomainname)(char *__buf , size_t __buflen ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__, __artificial__,
__always_inline__)) getdomainname)(char *__buf , size_t __buflen ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __getdomainname_chk(__buf, __buflen, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__buflen > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __getdomainname_chk_warn(__buf, __buflen, tmp___1);
      return ((int __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __getdomainname_alias(__buf, __buflen);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
__inline extern int __attribute__((__gnu_inline__))  __sigismember(__sigset_t const   *__set ,
                                                                   int __sig ) ;
__inline extern int __attribute__((__gnu_inline__))  __sigaddset(__sigset_t *__set ,
                                                                 int __sig ) ;
__inline extern int __attribute__((__gnu_inline__))  __sigdelset(__sigset_t *__set ,
                                                                 int __sig ) ;
__inline extern int __attribute__((__gnu_inline__))  __sigismember(__sigset_t const   *__set ,
                                                                   int __sig ) 
{ 
  unsigned long __mask ;
  unsigned long __word ;
  int tmp ;

  {
  __mask = 1UL << (unsigned long )(__sig - 1) % (8UL * sizeof(unsigned long ));
  __word = (unsigned long )(__sig - 1) / (8UL * sizeof(unsigned long ));
  if (__set->__val[__word] & __mask) {
    tmp = 1;
  } else {
    tmp = 0;
  }
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  __sigaddset(__sigset_t *__set ,
                                                                 int __sig ) 
{ 
  unsigned long __mask ;
  unsigned long __word ;

  {
  __mask = 1UL << (unsigned long )(__sig - 1) % (8UL * sizeof(unsigned long ));
  __word = (unsigned long )(__sig - 1) / (8UL * sizeof(unsigned long ));
  __set->__val[__word] |= __mask;
  return ((int __attribute__((__gnu_inline__))  )0);
}
}
__inline extern int __attribute__((__gnu_inline__))  __sigdelset(__sigset_t *__set ,
                                                                 int __sig ) 
{ 
  unsigned long __mask ;
  unsigned long __word ;

  {
  __mask = 1UL << (unsigned long )(__sig - 1) % (8UL * sizeof(unsigned long ));
  __word = (unsigned long )(__sig - 1) / (8UL * sizeof(unsigned long ));
  __set->__val[__word] &= ~ __mask;
  return ((int __attribute__((__gnu_inline__))  )0);
}
}
extern int __attribute__((__visibility__("default")))  vspprintf(char **pbuf ,
                                                                 size_t max_len ,
                                                                 char const   *format ,
                                                                 va_list ap ) ;
extern void __attribute__((__visibility__("default")))  php_error_docref0(char const   *docref ,
                                                                          int type ,
                                                                          char const   *format 
                                                                          , ...) ;
extern void __attribute__((__visibility__("default")))  php_error_docref1(char const   *docref ,
                                                                          char const   *param1 ,
                                                                          int type ,
                                                                          char const   *format 
                                                                          , ...) ;
extern int __attribute__((__visibility__("default")))  php_output_write(char const   *str ,
                                                                        size_t len ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) stat)(char const   * __restrict  __path ,
                 struct stat * __restrict  __statbuf ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) fstat)(int __fd , struct stat *__statbuf ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) stat64)(char const   * __restrict  __path ,
                   struct stat64 * __restrict  __statbuf ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) fstat64)(int __fd , struct stat64 *__statbuf ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2,3),
__leaf__)) fstatat)(int __fd , char const   * __restrict  __filename ,
                    struct stat * __restrict  __statbuf , int __flag ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2,3),
__leaf__)) fstatat64)(int __fd , char const   * __restrict  __filename ,
                      struct stat64 * __restrict  __statbuf , int __flag ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) lstat)(char const   * __restrict  __path ,
                  struct stat * __restrict  __statbuf ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) lstat64)(char const   * __restrict  __path ,
                    struct stat64 * __restrict  __statbuf ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__)) mknod)(char const   *__path , __mode_t __mode , __dev_t __dev ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) mknodat)(int __fd , char const   *__path , __mode_t __mode ,
                    __dev_t __dev ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3),
__leaf__)) __fxstat)(int __ver , int __fildes , struct stat *__stat_buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,3),
__leaf__)) __xstat)(int __ver , char const   *__filename ,
                    struct stat *__stat_buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,3),
__leaf__)) __lxstat)(int __ver , char const   *__filename ,
                     struct stat *__stat_buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3,4),
__leaf__)) __fxstatat)(int __ver , int __fildes , char const   *__filename ,
                       struct stat *__stat_buf , int __flag ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3),
__leaf__)) __fxstat64)(int __ver , int __fildes , struct stat64 *__stat_buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,3),
__leaf__)) __xstat64)(int __ver , char const   *__filename ,
                      struct stat64 *__stat_buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,3),
__leaf__)) __lxstat64)(int __ver , char const   *__filename ,
                       struct stat64 *__stat_buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3,4),
__leaf__)) __fxstatat64)(int __ver , int __fildes , char const   *__filename ,
                         struct stat64 *__stat_buf , int __flag ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,4),
__leaf__)) __xmknod)(int __ver , char const   *__path , __mode_t __mode ,
                     __dev_t *__dev ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3,5),
__leaf__)) __xmknodat)(int __ver , int __fd , char const   *__path ,
                       __mode_t __mode , __dev_t *__dev ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) stat)(char const   * __restrict  __path ,
                 struct stat * __restrict  __statbuf ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) stat)(char const   * __restrict  __path ,
                 struct stat * __restrict  __statbuf ) 
{ 
  int tmp ;

  {
  tmp = __xstat(1, (char const   *)__path, (struct stat *)__statbuf);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) lstat)(char const   * __restrict  __path ,
                  struct stat * __restrict  __statbuf ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) lstat)(char const   * __restrict  __path ,
                  struct stat * __restrict  __statbuf ) 
{ 
  int tmp ;

  {
  tmp = __lxstat(1, (char const   *)__path, (struct stat *)__statbuf);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) fstat)(int __fd , struct stat *__statbuf ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) fstat)(int __fd , struct stat *__statbuf ) 
{ 
  int tmp ;

  {
  tmp = __fxstat(1, __fd, __statbuf);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2,3),
__leaf__)) fstatat)(int __fd , char const   * __restrict  __filename ,
                    struct stat * __restrict  __statbuf , int __flag ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2,3),
__leaf__)) fstatat)(int __fd , char const   * __restrict  __filename ,
                    struct stat * __restrict  __statbuf , int __flag ) 
{ 
  int tmp ;

  {
  tmp = __fxstatat(1, __fd, (char const   *)__filename,
                   (struct stat *)__statbuf, __flag);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__)) mknod)(char const   *__path , __mode_t __mode , __dev_t __dev ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__)) mknod)(char const   *__path , __mode_t __mode , __dev_t __dev ) 
{ 
  int tmp ;

  {
  tmp = __xmknod(0, __path, __mode, & __dev);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) mknodat)(int __fd , char const   *__path , __mode_t __mode ,
                    __dev_t __dev ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) mknodat)(int __fd , char const   *__path , __mode_t __mode ,
                    __dev_t __dev ) 
{ 
  int tmp ;

  {
  tmp = __xmknodat(0, __fd, __path, __mode, & __dev);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) stat64)(char const   * __restrict  __path ,
                   struct stat64 * __restrict  __statbuf ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) stat64)(char const   * __restrict  __path ,
                   struct stat64 * __restrict  __statbuf ) 
{ 
  int tmp ;

  {
  tmp = __xstat64(1, (char const   *)__path, (struct stat64 *)__statbuf);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) lstat64)(char const   * __restrict  __path ,
                    struct stat64 * __restrict  __statbuf ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) lstat64)(char const   * __restrict  __path ,
                    struct stat64 * __restrict  __statbuf ) 
{ 
  int tmp ;

  {
  tmp = __lxstat64(1, (char const   *)__path, (struct stat64 *)__statbuf);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) fstat64)(int __fd , struct stat64 *__statbuf ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) fstat64)(int __fd , struct stat64 *__statbuf ) 
{ 
  int tmp ;

  {
  tmp = __fxstat64(1, __fd, __statbuf);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2,3),
__leaf__)) fstatat64)(int __fd , char const   * __restrict  __filename ,
                      struct stat64 * __restrict  __statbuf , int __flag ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2,3),
__leaf__)) fstatat64)(int __fd , char const   * __restrict  __filename ,
                      struct stat64 * __restrict  __statbuf , int __flag ) 
{ 
  int tmp ;

  {
  tmp = __fxstatat64(1, __fd, (char const   *)__filename,
                     (struct stat64 *)__statbuf, __flag);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
int __attribute__((__visibility__("default")))  php_file_le_stream(void) ;
int __attribute__((__visibility__("default")))  php_file_le_pstream(void) ;
int __attribute__((__visibility__("default")))  php_file_le_stream_filter(void) ;
void __attribute__((__visibility__("default")))  php_stream_context_free(php_stream_context *context ) ;
php_stream_context __attribute__((__visibility__("default")))  *php_stream_context_alloc(void) ;
int __attribute__((__visibility__("default")))  php_stream_context_get_option(php_stream_context *context ,
                                                                              char const   *wrappername ,
                                                                              char const   *optionname ,
                                                                              zval ***optionvalue ) ;
int __attribute__((__visibility__("default")))  php_stream_context_set_option(php_stream_context *context ,
                                                                              char const   *wrappername ,
                                                                              char const   *optionname ,
                                                                              zval *optionvalue ) ;
php_stream_notifier __attribute__((__visibility__("default")))  *php_stream_notification_alloc(void) ;
void __attribute__((__visibility__("default")))  php_stream_notification_free(php_stream_notifier *notifier ) ;
void __attribute__((__visibility__("default")))  php_stream_notification_notify(php_stream_context *context ,
                                                                                int notifycode ,
                                                                                int severity ,
                                                                                char *xmsg ,
                                                                                int xcode ,
                                                                                size_t bytes_sofar ,
                                                                                size_t bytes_max ,
                                                                                void *ptr ) ;
php_stream_context __attribute__((__visibility__("default")))  *php_stream_context_set(php_stream *stream ,
                                                                                       php_stream_context *context ) ;
extern php_stream_bucket __attribute__((__visibility__("default")))  *php_stream_bucket_new(php_stream *stream ,
                                                                                            char *buf ,
                                                                                            size_t buflen ,
                                                                                            int own_buf ,
                                                                                            int buf_persistent ) ;
extern void __attribute__((__visibility__("default")))  php_stream_bucket_delref(php_stream_bucket *bucket ) ;
extern void __attribute__((__visibility__("default")))  php_stream_bucket_append(php_stream_bucket_brigade *brigade ,
                                                                                 php_stream_bucket *bucket ) ;
extern void __attribute__((__visibility__("default")))  php_stream_bucket_unlink(php_stream_bucket *bucket ) ;
extern php_stream_filter __attribute__((__visibility__("default")))  *php_stream_filter_remove(php_stream_filter *filter ,
                                                                                               int call_dtor ) ;
php_stream __attribute__((__visibility__("default")))  *_php_stream_alloc(php_stream_ops *ops ,
                                                                          void *abstract ,
                                                                          char const   *persistent_id ,
                                                                          char const   *mode ) ;
php_stream __attribute__((__visibility__("default")))  *php_stream_encloses(php_stream *enclosing ,
                                                                            php_stream *enclosed ) ;
int __attribute__((__visibility__("default")))  _php_stream_free_enclosed(php_stream *stream_enclosed ,
                                                                          int close_options ) ;
int __attribute__((__visibility__("default")))  php_stream_from_persistent_id(char const   *persistent_id ,
                                                                              php_stream **stream ) ;
int __attribute__((__visibility__("default")))  _php_stream_free(php_stream *stream ,
                                                                 int close_options ) ;
int __attribute__((__visibility__("default")))  _php_stream_seek(php_stream *stream ,
                                                                 off_t offset ,
                                                                 int whence ) ;
off_t __attribute__((__visibility__("default")))  _php_stream_tell(php_stream *stream ) ;
size_t __attribute__((__visibility__("default")))  _php_stream_read(php_stream *stream ,
                                                                    char *buf ,
                                                                    size_t size ) ;
size_t __attribute__((__visibility__("default")))  _php_stream_write(php_stream *stream ,
                                                                     char const   *buf ,
                                                                     size_t count ) ;
size_t __attribute__((__visibility__("default")))  _php_stream_printf(php_stream *stream ,
                                                                      char const   *fmt 
                                                                      , ...) ;
int __attribute__((__visibility__("default")))  _php_stream_eof(php_stream *stream ) ;
int __attribute__((__visibility__("default")))  _php_stream_getc(php_stream *stream ) ;
int __attribute__((__visibility__("default")))  _php_stream_putc(php_stream *stream ,
                                                                 int c ) ;
int __attribute__((__visibility__("default")))  _php_stream_flush(php_stream *stream ,
                                                                  int closing ) ;
char __attribute__((__visibility__("default")))  *_php_stream_get_line(php_stream *stream ,
                                                                       char *buf ,
                                                                       size_t maxlen ,
                                                                       size_t *returned_len ) ;
char __attribute__((__visibility__("default")))  *php_stream_get_record(php_stream *stream ,
                                                                        size_t maxlen ,
                                                                        size_t *returned_len ,
                                                                        char *delim ,
                                                                        size_t delim_len ) ;
int __attribute__((__visibility__("default")))  _php_stream_puts(php_stream *stream ,
                                                                 char *buf ) ;
int __attribute__((__visibility__("default")))  _php_stream_stat(php_stream *stream ,
                                                                 php_stream_statbuf *ssb ) ;
int __attribute__((__visibility__("default")))  _php_stream_stat_path(char *path ,
                                                                      int flags ,
                                                                      php_stream_statbuf *ssb ,
                                                                      php_stream_context *context ) ;
int __attribute__((__visibility__("default")))  _php_stream_mkdir(char *path ,
                                                                  int mode ,
                                                                  int options ,
                                                                  php_stream_context *context ) ;
int __attribute__((__visibility__("default")))  _php_stream_rmdir(char *path ,
                                                                  int options ,
                                                                  php_stream_context *context ) ;
php_stream __attribute__((__visibility__("default")))  *_php_stream_opendir(char *path ,
                                                                            int options ,
                                                                            php_stream_context *context ) ;
php_stream_dirent __attribute__((__visibility__("default")))  *_php_stream_readdir(php_stream *dirstream ,
                                                                                   php_stream_dirent *ent ) ;
int __attribute__((__visibility__("default")))  php_stream_dirent_alphasort(char const   **a ,
                                                                            char const   **b ) ;
int __attribute__((__visibility__("default")))  php_stream_dirent_alphasortr(char const   **a ,
                                                                             char const   **b ) ;
int __attribute__((__visibility__("default")))  _php_stream_scandir(char *dirname ,
                                                                    char ***namelist ,
                                                                    int flags ,
                                                                    php_stream_context *context ,
                                                                    int (*compare)(char const   **a ,
                                                                                   char const   **b ) ) ;
int __attribute__((__visibility__("default")))  _php_stream_set_option(php_stream *stream ,
                                                                       int option ,
                                                                       int value ,
                                                                       void *ptrparam ) ;
int __attribute__((__visibility__("default")))  _php_stream_truncate_set_size(php_stream *stream ,
                                                                              size_t newsize ) ;
size_t __attribute__((__visibility__("default"),
__deprecated__))  _php_stream_copy_to_stream(php_stream *src ,
                                             php_stream *dest , size_t maxlen ) ;
int __attribute__((__visibility__("default")))  _php_stream_copy_to_stream_ex(php_stream *src ,
                                                                              php_stream *dest ,
                                                                              size_t maxlen ,
                                                                              size_t *len ) ;
size_t __attribute__((__visibility__("default")))  _php_stream_copy_to_mem(php_stream *src ,
                                                                           char **buf ,
                                                                           size_t maxlen ,
                                                                           int persistent ) ;
size_t __attribute__((__visibility__("default")))  _php_stream_passthru(php_stream *stream ) ;
__inline extern  __attribute__((__nothrow__)) struct cmsghdr  __attribute__((__gnu_inline__)) *( __attribute__((__leaf__)) __cmsg_nxthdr)(struct msghdr *__mhdr ,
                                                                                                                                          struct cmsghdr *__cmsg ) ;
__inline extern  __attribute__((__nothrow__)) struct cmsghdr  __attribute__((__gnu_inline__)) *( __attribute__((__leaf__)) __cmsg_nxthdr)(struct msghdr *__mhdr ,
                                                                                                                                          struct cmsghdr *__cmsg ) ;
__inline extern struct cmsghdr  __attribute__((__gnu_inline__)) *( __attribute__((__leaf__)) __cmsg_nxthdr)(struct msghdr *__mhdr ,
                                                                                                            struct cmsghdr *__cmsg ) 
{ 


  {
  if (__cmsg->cmsg_len < sizeof(struct cmsghdr )) {
    return ((struct cmsghdr  __attribute__((__gnu_inline__)) *)((struct cmsghdr *)0));
  } else {

  }
  __cmsg = (struct cmsghdr *)((unsigned char *)__cmsg + (((__cmsg->cmsg_len + sizeof(size_t )) - 1UL) & ~ (sizeof(size_t ) - 1UL)));
  if ((unsigned long )((unsigned char *)(__cmsg + 1)) > (unsigned long )((unsigned char *)__mhdr->msg_control + __mhdr->msg_controllen)) {
    return ((struct cmsghdr  __attribute__((__gnu_inline__)) *)((struct cmsghdr *)0));
  } else
  if ((unsigned long )((unsigned char *)__cmsg + (((__cmsg->cmsg_len + sizeof(size_t )) - 1UL) & ~ (sizeof(size_t ) - 1UL))) > (unsigned long )((unsigned char *)__mhdr->msg_control + __mhdr->msg_controllen)) {
    return ((struct cmsghdr  __attribute__((__gnu_inline__)) *)((struct cmsghdr *)0));
  } else {

  }
  return ((struct cmsghdr  __attribute__((__gnu_inline__)) *)__cmsg);
}
}
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) recv)(int __fd , void *__buf , size_t __n , int __flags ) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) recvfrom)(int __fd , void * __restrict  __buf , size_t __n ,
                              int __flags ,
                              struct sockaddr * __restrict  __cil_tmp14 ,
                              socklen_t * __restrict  __addr_len ) ;
extern ssize_t __recv_chk(int __fd , void *__buf , size_t __n ,
                          size_t __buflen , int __flags ) ;
extern ssize_t __recv_alias(int __fd , void *__buf , size_t __n , int __flags )  __asm__("recv")  ;
extern ssize_t __recv_chk_warn(int __fd , void *__buf , size_t __n ,
                               size_t __buflen , int __flags )  __asm__("__recv_chk") __attribute__((__warning__("recv called with bigger length than size of destination buffer"))) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) recv)(int __fd , void *__buf , size_t __n , int __flags ) 
{ 
  unsigned long tmp ;
  ssize_t tmp___0 ;
  unsigned long tmp___1 ;
  ssize_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  ssize_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size(__buf, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size(__buf, 0);
    tmp___0 = __recv_chk(__fd, __buf, __n, tmp, __flags);
    return ((ssize_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size(__buf, 0);
    if (__n > tmp___3) {
      tmp___1 = __builtin_object_size(__buf, 0);
      tmp___2 = __recv_chk_warn(__fd, __buf, __n, tmp___1, __flags);
      return ((ssize_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __recv_alias(__fd, __buf, __n, __flags);
  return ((ssize_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern ssize_t __recvfrom_chk(int __fd , void * __restrict  __buf , size_t __n ,
                              size_t __buflen , int __flags ,
                              struct sockaddr * __restrict  __addr ,
                              socklen_t * __restrict  __addr_len ) ;
extern ssize_t __recvfrom_alias(int __fd , void * __restrict  __buf ,
                                size_t __n , int __flags ,
                                struct sockaddr * __restrict  __addr ,
                                socklen_t * __restrict  __addr_len )  __asm__("recvfrom")  ;
extern ssize_t __recvfrom_chk_warn(int __fd , void * __restrict  __buf ,
                                   size_t __n , size_t __buflen , int __flags ,
                                   struct sockaddr * __restrict  __addr ,
                                   socklen_t * __restrict  __addr_len )  __asm__("__recvfrom_chk") __attribute__((__warning__("recvfrom called with bigger length than size of destination buffer"))) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) recvfrom)(int __fd , void * __restrict  __buf , size_t __n ,
                              int __flags ,
                              struct sockaddr * __restrict  __cil_tmp14 ,
                              socklen_t * __restrict  __addr_len ) 
{ 
  __SOCKADDR_ARG __addr ;
  unsigned long tmp ;
  ssize_t tmp___0 ;
  unsigned long tmp___1 ;
  ssize_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  ssize_t tmp___5 ;

  {
  __addr.__sockaddr__ = __cil_tmp14;
  tmp___4 = __builtin_object_size((void *)__buf, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 0);
    tmp___0 = __recvfrom_chk(__fd, __buf, __n, tmp, __flags,
                             __addr.__sockaddr__, __addr_len);
    return ((ssize_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 0);
    if (__n > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 0);
      tmp___2 = __recvfrom_chk_warn(__fd, __buf, __n, tmp___1, __flags,
                                    __addr.__sockaddr__, __addr_len);
      return ((ssize_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __recvfrom_alias(__fd, __buf, __n, __flags, __addr.__sockaddr__,
                             __addr_len);
  return ((ssize_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern int __attribute__((__visibility__("default")))  php_stream_xport_register(char *protocol ,
                                                                                 php_stream_transport_factory factory ) ;
extern HashTable __attribute__((__visibility__("default")))  *php_stream_xport_get_hash(void) ;
extern php_stream_transport_factory_func __attribute__((__visibility__("default")))  php_stream_generic_socket_factory ;
extern php_stream_wrapper __attribute__((__visibility__("default")))  php_plain_files_wrapper ;
extern char __attribute__((__visibility__("default")))  *_php_stream_mmap_range(php_stream *stream ,
                                                                                size_t offset ,
                                                                                size_t length ,
                                                                                php_stream_mmap_operation_t mode ,
                                                                                size_t *mapped_len ) ;
extern int __attribute__((__visibility__("default")))  _php_stream_mmap_unmap_ex(php_stream *stream ,
                                                                                 off_t readden ) ;
int php_init_stream_wrappers(int module_number ) ;
int php_shutdown_stream_wrappers(int module_number ) ;
void php_shutdown_stream_hashes(void) ;
int zm_deactivate_streams(int type , int module_number ) ;
int __attribute__((__visibility__("default")))  php_register_url_stream_wrapper(char *protocol ,
                                                                                php_stream_wrapper *wrapper ) ;
int __attribute__((__visibility__("default")))  php_unregister_url_stream_wrapper(char *protocol ) ;
int __attribute__((__visibility__("default")))  php_register_url_stream_wrapper_volatile(char *protocol ,
                                                                                         php_stream_wrapper *wrapper ) ;
int __attribute__((__visibility__("default")))  php_unregister_url_stream_wrapper_volatile(char *protocol ) ;
php_stream __attribute__((__visibility__("default")))  *_php_stream_open_wrapper_ex(char *path ,
                                                                                    char *mode ,
                                                                                    int options ,
                                                                                    char **opened_path ,
                                                                                    php_stream_context *context ) ;
php_stream_wrapper __attribute__((__visibility__("default")))  *php_stream_locate_url_wrapper(char const   *path ,
                                                                                              char **path_for_open ,
                                                                                              int options ) ;
char __attribute__((__visibility__("default")))  *php_stream_locate_eol(php_stream *stream ,
                                                                        char *buf ,
                                                                        size_t buf_len ) ;
void __attribute__((__visibility__("default")))  php_stream_wrapper_log_error(php_stream_wrapper *wrapper ,
                                                                              int options ,
                                                                              char const   *fmt 
                                                                              , ...) ;
extern int __attribute__((__visibility__("default")))  _php_stream_make_seekable(php_stream *origstream ,
                                                                                 php_stream **newstream ,
                                                                                 int flags ) ;
HashTable __attribute__((__visibility__("default")))  *_php_stream_get_url_stream_wrappers_hash(void) ;
HashTable __attribute__((__visibility__("default")))  *php_stream_get_url_stream_wrappers_hash_global(void) ;
extern HashTable __attribute__((__visibility__("default")))  *php_get_stream_filters_hash_global(void) ;
extern struct _php_core_globals  __attribute__((__visibility__("default"))) core_globals ;
extern char __attribute__((__visibility__("default")))  *php_strip_url_passwd(char *path ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) poll)(struct pollfd *__fds , nfds_t __nfds , int __timeout ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) ppoll)(struct pollfd *__fds , nfds_t __nfds ,
                           struct timespec  const  *__timeout ,
                           __sigset_t const   *__ss ) ;
extern int __poll_alias(struct pollfd *__fds , nfds_t __nfds , int __timeout )  __asm__("poll")  ;
extern int __poll_chk(struct pollfd *__fds , nfds_t __nfds , int __timeout ,
                      unsigned long __fdslen ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) poll)(struct pollfd *__fds , nfds_t __nfds , int __timeout ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__fds, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__fds, 1);
    tmp___0 = __poll_chk(__fds, __nfds, __timeout, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
  } else {

  }
  tmp___5 = __poll_alias(__fds, __nfds, __timeout);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern int __ppoll_alias(struct pollfd *__fds , nfds_t __nfds ,
                         struct timespec  const  *__timeout ,
                         __sigset_t const   *__ss )  __asm__("ppoll")  ;
extern int __ppoll_chk(struct pollfd *__fds , nfds_t __nfds ,
                       struct timespec  const  *__timeout ,
                       __sigset_t const   *__ss , unsigned long __fdslen ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) ppoll)(struct pollfd *__fds , nfds_t __nfds ,
                           struct timespec  const  *__timeout ,
                           __sigset_t const   *__ss ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__fds, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__fds, 1);
    tmp___0 = __ppoll_chk(__fds, __nfds, __timeout, __ss, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
  } else {

  }
  tmp___5 = __ppoll_alias(__fds, __nfds, __timeout, __ss);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern int __attribute__((__visibility__("default")))  php_le_stream_context(void) ;
extern php_file_globals __attribute__((__visibility__("default")))  file_globals ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcscpy)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcsncpy)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcscat)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcsncat)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wmemcpy)(wchar_t * __restrict  __s1 ,
                             wchar_t const   * __restrict  __s2 , size_t __n ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__, __always_inline__)) wmemmove)(wchar_t *__s1 ,
                                              wchar_t const   *__s2 ,
                                              size_t __n ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__, __always_inline__)) wmemset)(wchar_t *__s , wchar_t __c ,
                                             size_t __n ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wmempcpy)(wchar_t * __restrict  __s1 ,
                              wchar_t const   * __restrict  __s2 , size_t __n ) ;
__inline extern  __attribute__((__nothrow__)) wint_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) btowc)(int __c ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) wctob)(wint_t __wc ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) mbrtowc)(wchar_t * __restrict  __pwc ,
                                                                                 char const   * __restrict  __s ,
                                                                                 size_t __n ,
                                                                                 mbstate_t * __restrict  __p ) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) wcrtomb)(char * __restrict  __s , wchar_t __wchar ,
                             mbstate_t * __restrict  __ps ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbrlen)(char const   * __restrict  __s ,
                                                                                  size_t __n ,
                                                                                  mbstate_t * __restrict  __ps ) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) mbrlen)(char const   * __restrict  __s ,
                                                                                                                          size_t __n ,
                                                                                                                          mbstate_t * __restrict  __ps ) ;
extern wint_t __btowc_alias(int __c )  __asm__("btowc")  ;
__inline extern  __attribute__((__nothrow__)) wint_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) btowc)(int __c ) ;
__inline extern wint_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) btowc)(int __c ) 
{ 
  wint_t tmp ;

  {
  tmp = __btowc_alias(__c);
  return ((wint_t __attribute__((__gnu_inline__))  )tmp);
}
}
extern int __wctob_alias(wint_t __c )  __asm__("wctob")  ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) wctob)(wint_t __wc ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) wctob)(wint_t __wc ) 
{ 
  int tmp ;

  {
  tmp = __wctob_alias(__wc);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) mbrlen)(char const   * __restrict  __s ,
                                                                                                                          size_t __n ,
                                                                                                                          mbstate_t * __restrict  __ps ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) mbrlen)(char const   * __restrict  __s ,
                                                                                            size_t __n ,
                                                                                            mbstate_t * __restrict  __ps ) 
{ 
  size_t tmp ;
  size_t tmp___0 ;
  size_t tmp___1 ;

  {
  if ((unsigned long )__ps != (unsigned long )((void *)0)) {
    tmp = mbrtowc((wchar_t */* __restrict  */)((void *)0), __s, __n, __ps);
    tmp___1 = tmp;
  } else {
    tmp___0 = __mbrlen(__s, __n, (mbstate_t */* __restrict  */)((void *)0));
    tmp___1 = tmp___0;
  }
  return ((size_t __attribute__((__gnu_inline__))  )tmp___1);
}
}
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) mbsrtowcs)(wchar_t * __restrict  __dst ,
                               char const   ** __restrict  __src ,
                               size_t __len , mbstate_t * __restrict  __ps ) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcsrtombs)(char * __restrict  __dst ,
                               wchar_t const   ** __restrict  __src ,
                               size_t __len , mbstate_t * __restrict  __ps ) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) mbsnrtowcs)(wchar_t * __restrict  __dst ,
                                char const   ** __restrict  __src ,
                                size_t __nmc , size_t __len ,
                                mbstate_t * __restrict  __ps ) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcsnrtombs)(char * __restrict  __dst ,
                                wchar_t const   ** __restrict  __src ,
                                size_t __nwc , size_t __len ,
                                mbstate_t * __restrict  __ps ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcpcpy)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcpncpy)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) fwprintf)(__FILE * __restrict  __stream ,
                              wchar_t const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) wprintf)(wchar_t const   * __restrict  __fmt  , ...) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) swprintf)(wchar_t * __restrict  __s ,
                              size_t __n , wchar_t const   * __restrict  __fmt 
                              , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vfwprintf)(__FILE * __restrict  __stream ,
                               wchar_t const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vwprintf)(wchar_t const   * __restrict  __fmt ,
                              __gnuc_va_list __ap ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) vswprintf)(wchar_t * __restrict  __s ,
                               size_t __n ,
                               wchar_t const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fgetws)(wchar_t * __restrict  __s ,
                            int __n , __FILE * __restrict  __stream ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fgetws_unlocked)(wchar_t * __restrict  __s ,
                                     int __n , __FILE * __restrict  __stream ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemcpy_chk)(wchar_t * __restrict  __s1 ,
                                                                                         wchar_t const   * __restrict  __s2 ,
                                                                                         size_t __n ,
                                                                                         size_t __ns1 ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemcpy_alias)(wchar_t * __restrict  __s1 ,
                                                                                           wchar_t const   * __restrict  __s2 ,
                                                                                           size_t __n )  __asm__("wmemcpy")  ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemcpy_chk_warn)(wchar_t * __restrict  __s1 ,
                                                                                              wchar_t const   * __restrict  __s2 ,
                                                                                              size_t __n ,
                                                                                              size_t __ns1 )  __asm__("__wmemcpy_chk") __attribute__((__warning__("wmemcpy called with length bigger than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wmemcpy)(wchar_t * __restrict  __s1 ,
                             wchar_t const   * __restrict  __s2 , size_t __n ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wmemcpy)(wchar_t * __restrict  __s1 ,
                             wchar_t const   * __restrict  __s2 , size_t __n ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  wchar_t *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__s1, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s1, 0);
    tmp___0 = __wmemcpy_chk(__s1, __s2, __n, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__s1, 0);
    if (__n > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__s1, 0);
      tmp___2 = __wmemcpy_chk_warn(__s1, __s2, __n, tmp___1 / sizeof(wchar_t ));
      return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wmemcpy_alias(__s1, __s2, __n);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemmove_chk)(wchar_t *__s1 ,
                                                                                          wchar_t const   *__s2 ,
                                                                                          size_t __n ,
                                                                                          size_t __ns1 ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemmove_alias)(wchar_t *__s1 ,
                                                                                            wchar_t const   *__s2 ,
                                                                                            size_t __n )  __asm__("wmemmove")  ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemmove_chk_warn)(wchar_t *__s1 ,
                                                                                               wchar_t const   *__s2 ,
                                                                                               size_t __n ,
                                                                                               size_t __ns1 )  __asm__("__wmemmove_chk") __attribute__((__warning__("wmemmove called with length bigger than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__, __always_inline__)) wmemmove)(wchar_t *__s1 ,
                                              wchar_t const   *__s2 ,
                                              size_t __n ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__, __always_inline__)) wmemmove)(wchar_t *__s1 ,
                                              wchar_t const   *__s2 ,
                                              size_t __n ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  wchar_t *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__s1, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s1, 0);
    tmp___0 = __wmemmove_chk(__s1, __s2, __n, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__s1, 0);
    if (__n > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__s1, 0);
      tmp___2 = __wmemmove_chk_warn(__s1, __s2, __n, tmp___1 / sizeof(wchar_t ));
      return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wmemmove_alias(__s1, __s2, __n);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmempcpy_chk)(wchar_t * __restrict  __s1 ,
                                                                                          wchar_t const   * __restrict  __s2 ,
                                                                                          size_t __n ,
                                                                                          size_t __ns1 ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmempcpy_alias)(wchar_t * __restrict  __s1 ,
                                                                                            wchar_t const   * __restrict  __s2 ,
                                                                                            size_t __n )  __asm__("wmempcpy")  ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmempcpy_chk_warn)(wchar_t * __restrict  __s1 ,
                                                                                               wchar_t const   * __restrict  __s2 ,
                                                                                               size_t __n ,
                                                                                               size_t __ns1 )  __asm__("__wmempcpy_chk") __attribute__((__warning__("wmempcpy called with length bigger than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wmempcpy)(wchar_t * __restrict  __s1 ,
                              wchar_t const   * __restrict  __s2 , size_t __n ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wmempcpy)(wchar_t * __restrict  __s1 ,
                              wchar_t const   * __restrict  __s2 , size_t __n ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  wchar_t *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__s1, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s1, 0);
    tmp___0 = __wmempcpy_chk(__s1, __s2, __n, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__s1, 0);
    if (__n > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__s1, 0);
      tmp___2 = __wmempcpy_chk_warn(__s1, __s2, __n, tmp___1 / sizeof(wchar_t ));
      return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wmempcpy_alias(__s1, __s2, __n);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemset_chk)(wchar_t *__s ,
                                                                                         wchar_t __c ,
                                                                                         size_t __n ,
                                                                                         size_t __ns ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemset_alias)(wchar_t *__s ,
                                                                                           wchar_t __c ,
                                                                                           size_t __n )  __asm__("wmemset")  ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wmemset_chk_warn)(wchar_t *__s ,
                                                                                              wchar_t __c ,
                                                                                              size_t __n ,
                                                                                              size_t __ns )  __asm__("__wmemset_chk") __attribute__((__warning__("wmemset called with length bigger than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__, __always_inline__)) wmemset)(wchar_t *__s , wchar_t __c ,
                                             size_t __n ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__, __always_inline__)) wmemset)(wchar_t *__s , wchar_t __c ,
                                             size_t __n ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  wchar_t *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__s, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s, 0);
    tmp___0 = __wmemset_chk(__s, __c, __n, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__s, 0);
    if (__n > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__s, 0);
      tmp___2 = __wmemset_chk_warn(__s, __c, __n, tmp___1 / sizeof(wchar_t ));
      return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wmemset_alias(__s, __c, __n);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcscpy_chk)(wchar_t * __restrict  __dest ,
                                                                                        wchar_t const   * __restrict  __src ,
                                                                                        size_t __n ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcscpy_alias)(wchar_t * __restrict  __dest ,
                                                                                          wchar_t const   * __restrict  __src )  __asm__("wcscpy")  ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcscpy)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcscpy)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__dest, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dest, 1);
    tmp___0 = __wcscpy_chk(__dest, __src, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
  } else {

  }
  tmp___2 = __wcscpy_alias(__dest, __src);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
}
}
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcpcpy_chk)(wchar_t * __restrict  __dest ,
                                                                                        wchar_t const   * __restrict  __src ,
                                                                                        size_t __destlen ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcpcpy_alias)(wchar_t * __restrict  __dest ,
                                                                                          wchar_t const   * __restrict  __src )  __asm__("wcpcpy")  ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcpcpy)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcpcpy)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__dest, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dest, 1);
    tmp___0 = __wcpcpy_chk(__dest, __src, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
  } else {

  }
  tmp___2 = __wcpcpy_alias(__dest, __src);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
}
}
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcsncpy_chk)(wchar_t * __restrict  __dest ,
                                                                                         wchar_t const   * __restrict  __src ,
                                                                                         size_t __n ,
                                                                                         size_t __destlen ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcsncpy_alias)(wchar_t * __restrict  __dest ,
                                                                                           wchar_t const   * __restrict  __src ,
                                                                                           size_t __n )  __asm__("wcsncpy")  ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcsncpy_chk_warn)(wchar_t * __restrict  __dest ,
                                                                                              wchar_t const   * __restrict  __src ,
                                                                                              size_t __n ,
                                                                                              size_t __destlen )  __asm__("__wcsncpy_chk") __attribute__((__warning__("wcsncpy called with length bigger than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcsncpy)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcsncpy)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  wchar_t *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__dest, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dest, 1);
    tmp___0 = __wcsncpy_chk(__dest, __src, __n, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__dest, 1);
    if (__n > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__dest, 1);
      tmp___2 = __wcsncpy_chk_warn(__dest, __src, __n,
                                   tmp___1 / sizeof(wchar_t ));
      return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wcsncpy_alias(__dest, __src, __n);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcpncpy_chk)(wchar_t * __restrict  __dest ,
                                                                                         wchar_t const   * __restrict  __src ,
                                                                                         size_t __n ,
                                                                                         size_t __destlen ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcpncpy_alias)(wchar_t * __restrict  __dest ,
                                                                                           wchar_t const   * __restrict  __src ,
                                                                                           size_t __n )  __asm__("wcpncpy")  ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcpncpy_chk_warn)(wchar_t * __restrict  __dest ,
                                                                                              wchar_t const   * __restrict  __src ,
                                                                                              size_t __n ,
                                                                                              size_t __destlen )  __asm__("__wcpncpy_chk") __attribute__((__warning__("wcpncpy called with length bigger than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcpncpy)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcpncpy)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  wchar_t *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__dest, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dest, 1);
    tmp___0 = __wcpncpy_chk(__dest, __src, __n, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__dest, 1);
    if (__n > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__dest, 1);
      tmp___2 = __wcpncpy_chk_warn(__dest, __src, __n,
                                   tmp___1 / sizeof(wchar_t ));
      return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wcpncpy_alias(__dest, __src, __n);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcscat_chk)(wchar_t * __restrict  __dest ,
                                                                                        wchar_t const   * __restrict  __src ,
                                                                                        size_t __destlen ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcscat_alias)(wchar_t * __restrict  __dest ,
                                                                                          wchar_t const   * __restrict  __src )  __asm__("wcscat")  ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcscat)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcscat)(wchar_t * __restrict  __dest ,
                            wchar_t const   * __restrict  __src ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__dest, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dest, 1);
    tmp___0 = __wcscat_chk(__dest, __src, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
  } else {

  }
  tmp___2 = __wcscat_alias(__dest, __src);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
}
}
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcsncat_chk)(wchar_t * __restrict  __dest ,
                                                                                         wchar_t const   * __restrict  __src ,
                                                                                         size_t __n ,
                                                                                         size_t __destlen ) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) __wcsncat_alias)(wchar_t * __restrict  __dest ,
                                                                                           wchar_t const   * __restrict  __src ,
                                                                                           size_t __n )  __asm__("wcsncat")  ;
__inline extern  __attribute__((__nothrow__)) wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcsncat)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) wcsncat)(wchar_t * __restrict  __dest ,
                             wchar_t const   * __restrict  __src , size_t __n ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__dest, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dest, 1);
    tmp___0 = __wcsncat_chk(__dest, __src, __n, tmp / sizeof(wchar_t ));
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
  } else {

  }
  tmp___2 = __wcsncat_alias(__dest, __src, __n);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__leaf__)) __swprintf_chk)(wchar_t * __restrict  __s ,
                                                                                     size_t __n ,
                                                                                     int __flag ,
                                                                                     size_t __s_len ,
                                                                                     wchar_t const   * __restrict  __format 
                                                                                     , ...) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__leaf__)) __swprintf_alias)(wchar_t * __restrict  __s ,
                                                                                       size_t __n ,
                                                                                       wchar_t const   * __restrict  __fmt 
                                                                                       , ...)  __asm__("swprintf")  ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) swprintf)(wchar_t * __restrict  __s ,
                              size_t __n , wchar_t const   * __restrict  __fmt 
                              , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) swprintf)(wchar_t * __restrict  __s ,
                              size_t __n , wchar_t const   * __restrict  __fmt 
                              , ...) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__s, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s, 1);
    tmp___0 = __swprintf_chk(__s, __n, 1, tmp / sizeof(wchar_t ), __fmt,
                             __builtin_va_arg_pack());
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
  } else {
    tmp = __builtin_object_size((void *)__s, 1);
    tmp___0 = __swprintf_chk(__s, __n, 1, tmp / sizeof(wchar_t ), __fmt,
                             __builtin_va_arg_pack());
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
  }
  tmp___2 = __swprintf_alias(__s, __n, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__leaf__)) __vswprintf_chk)(wchar_t * __restrict  __s ,
                                                                                      size_t __n ,
                                                                                      int __flag ,
                                                                                      size_t __s_len ,
                                                                                      wchar_t const   * __restrict  __format ,
                                                                                      __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__leaf__)) __vswprintf_alias)(wchar_t * __restrict  __s ,
                                                                                        size_t __n ,
                                                                                        wchar_t const   * __restrict  __fmt ,
                                                                                        __gnuc_va_list __ap )  __asm__("vswprintf")  ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) vswprintf)(wchar_t * __restrict  __s ,
                               size_t __n ,
                               wchar_t const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) vswprintf)(wchar_t * __restrict  __s ,
                               size_t __n ,
                               wchar_t const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__s, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s, 1);
    tmp___0 = __vswprintf_chk(__s, __n, 1, tmp / sizeof(wchar_t ), __fmt, __ap);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
  } else {
    tmp = __builtin_object_size((void *)__s, 1);
    tmp___0 = __vswprintf_chk(__s, __n, 1, tmp / sizeof(wchar_t ), __fmt, __ap);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
  }
  tmp___2 = __vswprintf_alias(__s, __n, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
extern int __fwprintf_chk(__FILE * __restrict  __stream , int __flag ,
                          wchar_t const   * __restrict  __format  , ...) ;
extern int __wprintf_chk(int __flag , wchar_t const   * __restrict  __format 
                         , ...) ;
extern int __vfwprintf_chk(__FILE * __restrict  __stream , int __flag ,
                           wchar_t const   * __restrict  __format ,
                           __gnuc_va_list __ap ) ;
extern int __vwprintf_chk(int __flag , wchar_t const   * __restrict  __format ,
                          __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) wprintf)(wchar_t const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __wprintf_chk(1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) fwprintf)(__FILE * __restrict  __stream ,
                              wchar_t const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __fwprintf_chk(__stream, 1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vwprintf)(wchar_t const   * __restrict  __fmt ,
                              __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __vwprintf_chk(1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vfwprintf)(__FILE * __restrict  __stream ,
                               wchar_t const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __vfwprintf_chk(__stream, 1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
extern wchar_t *( __attribute__((__warn_unused_result__)) __fgetws_chk)(wchar_t * __restrict  __s ,
                                                                        size_t __size ,
                                                                        int __n ,
                                                                        __FILE * __restrict  __stream ) ;
extern wchar_t *( __attribute__((__warn_unused_result__)) __fgetws_alias)(wchar_t * __restrict  __s ,
                                                                          int __n ,
                                                                          __FILE * __restrict  __stream )  __asm__("fgetws")  ;
extern wchar_t *( __attribute__((__warn_unused_result__)) __fgetws_chk_warn)(wchar_t * __restrict  __s ,
                                                                             size_t __size ,
                                                                             int __n ,
                                                                             __FILE * __restrict  __stream )  __asm__("__fgetws_chk") __attribute__((__warning__("fgetws called with bigger size than length of destination buffer"))) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fgetws)(wchar_t * __restrict  __s ,
                            int __n , __FILE * __restrict  __stream ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  wchar_t *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__s, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s, 1);
    tmp___0 = __fgetws_chk(__s, tmp / sizeof(wchar_t ), __n, __stream);
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__s, 1);
    if ((size_t )__n > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__s, 1);
      tmp___2 = __fgetws_chk_warn(__s, tmp___1 / sizeof(wchar_t ), __n, __stream);
      return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __fgetws_alias(__s, __n, __stream);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern wchar_t *( __attribute__((__warn_unused_result__)) __fgetws_unlocked_chk)(wchar_t * __restrict  __s ,
                                                                                 size_t __size ,
                                                                                 int __n ,
                                                                                 __FILE * __restrict  __stream ) ;
extern wchar_t *( __attribute__((__warn_unused_result__)) __fgetws_unlocked_alias)(wchar_t * __restrict  __s ,
                                                                                   int __n ,
                                                                                   __FILE * __restrict  __stream )  __asm__("fgetws_unlocked")  ;
extern wchar_t *( __attribute__((__warn_unused_result__)) __fgetws_unlocked_chk_warn)(wchar_t * __restrict  __s ,
                                                                                      size_t __size ,
                                                                                      int __n ,
                                                                                      __FILE * __restrict  __stream )  __asm__("__fgetws_unlocked_chk") __attribute__((__warning__("fgetws_unlocked called with bigger size than length of destination buffer"))) ;
__inline extern wchar_t __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fgetws_unlocked)(wchar_t * __restrict  __s ,
                                     int __n , __FILE * __restrict  __stream ) 
{ 
  unsigned long tmp ;
  wchar_t *tmp___0 ;
  unsigned long tmp___1 ;
  wchar_t *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  wchar_t *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__s, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s, 1);
    tmp___0 = __fgetws_unlocked_chk(__s, tmp / sizeof(wchar_t ), __n, __stream);
    return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__s, 1);
    if ((size_t )__n > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__s, 1);
      tmp___2 = __fgetws_unlocked_chk_warn(__s, tmp___1 / sizeof(wchar_t ), __n,
                                           __stream);
      return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __fgetws_unlocked_alias(__s, __n, __stream);
  return ((wchar_t __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__warn_unused_result__,
__leaf__)) __wcrtomb_chk)(char * __restrict  __s , wchar_t __wchar ,
                          mbstate_t * __restrict  __p , size_t __buflen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__warn_unused_result__,
__leaf__)) __wcrtomb_alias)(char * __restrict  __s , wchar_t __wchar ,
                            mbstate_t * __restrict  __ps )  __asm__("wcrtomb")  ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) wcrtomb)(char * __restrict  __s , wchar_t __wchar ,
                             mbstate_t * __restrict  __ps ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) wcrtomb)(char * __restrict  __s , wchar_t __wchar ,
                             mbstate_t * __restrict  __ps ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  unsigned long tmp___2 ;
  size_t tmp___3 ;

  {
  tmp___1 = __builtin_object_size((void *)__s, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp___2 = __builtin_object_size((void *)__s, 1);
    if (16UL > tmp___2) {
      tmp = __builtin_object_size((void *)__s, 1);
      tmp___0 = __wcrtomb_chk(__s, __wchar, __ps, tmp);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    } else {

    }
  } else {

  }
  tmp___3 = __wcrtomb_alias(__s, __wchar, __ps);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___3);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbsrtowcs_chk)(wchar_t * __restrict  __dst ,
                                                                                         char const   ** __restrict  __src ,
                                                                                         size_t __len ,
                                                                                         mbstate_t * __restrict  __ps ,
                                                                                         size_t __dstlen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbsrtowcs_alias)(wchar_t * __restrict  __dst ,
                                                                                           char const   ** __restrict  __src ,
                                                                                           size_t __len ,
                                                                                           mbstate_t * __restrict  __ps )  __asm__("mbsrtowcs")  ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbsrtowcs_chk_warn)(wchar_t * __restrict  __dst ,
                                                                                              char const   ** __restrict  __src ,
                                                                                              size_t __len ,
                                                                                              mbstate_t * __restrict  __ps ,
                                                                                              size_t __dstlen )  __asm__("__mbsrtowcs_chk") __attribute__((__warning__("mbsrtowcs called with dst buffer smaller than len * sizeof (wchar_t)"))) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) mbsrtowcs)(wchar_t * __restrict  __dst ,
                               char const   ** __restrict  __src ,
                               size_t __len , mbstate_t * __restrict  __ps ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) mbsrtowcs)(wchar_t * __restrict  __dst ,
                               char const   ** __restrict  __src ,
                               size_t __len , mbstate_t * __restrict  __ps ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__dst, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dst, 1);
    tmp___0 = __mbsrtowcs_chk(__dst, __src, __len, __ps, tmp / sizeof(wchar_t ));
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__dst, 1);
    if (__len > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__dst, 1);
      tmp___2 = __mbsrtowcs_chk_warn(__dst, __src, __len, __ps,
                                     tmp___1 / sizeof(wchar_t ));
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __mbsrtowcs_alias(__dst, __src, __len, __ps);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcsrtombs_chk)(char * __restrict  __dst ,
                                                                                         wchar_t const   ** __restrict  __src ,
                                                                                         size_t __len ,
                                                                                         mbstate_t * __restrict  __ps ,
                                                                                         size_t __dstlen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcsrtombs_alias)(char * __restrict  __dst ,
                                                                                           wchar_t const   ** __restrict  __src ,
                                                                                           size_t __len ,
                                                                                           mbstate_t * __restrict  __ps )  __asm__("wcsrtombs")  ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcsrtombs_chk_warn)(char * __restrict  __dst ,
                                                                                              wchar_t const   ** __restrict  __src ,
                                                                                              size_t __len ,
                                                                                              mbstate_t * __restrict  __ps ,
                                                                                              size_t __dstlen )  __asm__("__wcsrtombs_chk") __attribute__((__warning__("wcsrtombs called with dst buffer smaller than len"))) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcsrtombs)(char * __restrict  __dst ,
                               wchar_t const   ** __restrict  __src ,
                               size_t __len , mbstate_t * __restrict  __ps ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcsrtombs)(char * __restrict  __dst ,
                               wchar_t const   ** __restrict  __src ,
                               size_t __len , mbstate_t * __restrict  __ps ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__dst, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dst, 1);
    tmp___0 = __wcsrtombs_chk(__dst, __src, __len, __ps, tmp);
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__dst, 1);
    if (__len > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__dst, 1);
      tmp___2 = __wcsrtombs_chk_warn(__dst, __src, __len, __ps, tmp___1);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wcsrtombs_alias(__dst, __src, __len, __ps);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbsnrtowcs_chk)(wchar_t * __restrict  __dst ,
                                                                                          char const   ** __restrict  __src ,
                                                                                          size_t __nmc ,
                                                                                          size_t __len ,
                                                                                          mbstate_t * __restrict  __ps ,
                                                                                          size_t __dstlen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbsnrtowcs_alias)(wchar_t * __restrict  __dst ,
                                                                                            char const   ** __restrict  __src ,
                                                                                            size_t __nmc ,
                                                                                            size_t __len ,
                                                                                            mbstate_t * __restrict  __ps )  __asm__("mbsnrtowcs")  ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbsnrtowcs_chk_warn)(wchar_t * __restrict  __dst ,
                                                                                               char const   ** __restrict  __src ,
                                                                                               size_t __nmc ,
                                                                                               size_t __len ,
                                                                                               mbstate_t * __restrict  __ps ,
                                                                                               size_t __dstlen )  __asm__("__mbsnrtowcs_chk") __attribute__((__warning__("mbsnrtowcs called with dst buffer smaller than len * sizeof (wchar_t)"))) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) mbsnrtowcs)(wchar_t * __restrict  __dst ,
                                char const   ** __restrict  __src ,
                                size_t __nmc , size_t __len ,
                                mbstate_t * __restrict  __ps ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) mbsnrtowcs)(wchar_t * __restrict  __dst ,
                                char const   ** __restrict  __src ,
                                size_t __nmc , size_t __len ,
                                mbstate_t * __restrict  __ps ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__dst, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dst, 1);
    tmp___0 = __mbsnrtowcs_chk(__dst, __src, __nmc, __len, __ps,
                               tmp / sizeof(wchar_t ));
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__dst, 1);
    if (__len > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__dst, 1);
      tmp___2 = __mbsnrtowcs_chk_warn(__dst, __src, __nmc, __len, __ps,
                                      tmp___1 / sizeof(wchar_t ));
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __mbsnrtowcs_alias(__dst, __src, __nmc, __len, __ps);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcsnrtombs_chk)(char * __restrict  __dst ,
                                                                                          wchar_t const   ** __restrict  __src ,
                                                                                          size_t __nwc ,
                                                                                          size_t __len ,
                                                                                          mbstate_t * __restrict  __ps ,
                                                                                          size_t __dstlen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcsnrtombs_alias)(char * __restrict  __dst ,
                                                                                            wchar_t const   ** __restrict  __src ,
                                                                                            size_t __nwc ,
                                                                                            size_t __len ,
                                                                                            mbstate_t * __restrict  __ps )  __asm__("wcsnrtombs")  ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcsnrtombs_chk_warn)(char * __restrict  __dst ,
                                                                                               wchar_t const   ** __restrict  __src ,
                                                                                               size_t __nwc ,
                                                                                               size_t __len ,
                                                                                               mbstate_t * __restrict  __ps ,
                                                                                               size_t __dstlen )  __asm__("__wcsnrtombs_chk") __attribute__((__warning__("wcsnrtombs called with dst buffer smaller than len"))) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcsnrtombs)(char * __restrict  __dst ,
                                wchar_t const   ** __restrict  __src ,
                                size_t __nwc , size_t __len ,
                                mbstate_t * __restrict  __ps ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcsnrtombs)(char * __restrict  __dst ,
                                wchar_t const   ** __restrict  __src ,
                                size_t __nwc , size_t __len ,
                                mbstate_t * __restrict  __ps ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__dst, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dst, 1);
    tmp___0 = __wcsnrtombs_chk(__dst, __src, __nwc, __len, __ps, tmp);
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__dst, 1);
    if (__len > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__dst, 1);
      tmp___2 = __wcsnrtombs_chk_warn(__dst, __src, __nwc, __len, __ps, tmp___1);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wcsnrtombs_alias(__dst, __src, __nwc, __len, __ps);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern php_basic_globals __attribute__((__visibility__("default")))  basic_globals ;
extern char __attribute__((__visibility__("default")))  *php_strtolower(char *s ,
                                                                        size_t len ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__artificial__, __always_inline__)) open)(char const   *__path , int __oflag 
                                          , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__artificial__, __always_inline__)) open64)(char const   *__path , int __oflag 
                                            , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__artificial__, __always_inline__)) openat)(int __fd , char const   *__path ,
                                            int __oflag  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__artificial__, __always_inline__)) openat64)(int __fd , char const   *__path ,
                                              int __oflag  , ...) ;
extern int ( __attribute__((__nonnull__(1))) __open_2)(char const   *__path ,
                                                       int __oflag ) ;
extern int ( __attribute__((__nonnull__(1))) __open_alias)(char const   *__path ,
                                                           int __oflag  , ...)  __asm__("open")  ;
extern void __open_too_many_args(void)  __attribute__((__error__("open can be called either with 2 or 3 arguments, not more"))) ;
extern void __open_missing_mode(void)  __attribute__((__error__("open with O_CREAT or O_TMPFILE in second argument needs 3 arguments"))) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__artificial__, __always_inline__)) open)(char const   *__path , int __oflag 
                                          , ...) 
{ 
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;

  {
  tmp = __builtin_va_arg_pack_len();
  if (tmp > 1) {
    __open_too_many_args();
  } else {

  }
  if (0) {
    if ((__oflag & 64) != 0) {
      goto _L;
    } else
    if ((__oflag & 4259840) == 4259840) {
      _L: 
      tmp___1 = __builtin_va_arg_pack_len();
      if (tmp___1 < 1) {
        __open_missing_mode();
        tmp___0 = __open_2(__path, __oflag);
        return ((int __attribute__((__gnu_inline__))  )tmp___0);
      } else {

      }
    } else {

    }
    tmp___2 = __open_alias(__path, __oflag, __builtin_va_arg_pack());
    return ((int __attribute__((__gnu_inline__))  )tmp___2);
  } else {

  }
  tmp___4 = __builtin_va_arg_pack_len();
  if (tmp___4 < 1) {
    tmp___3 = __open_2(__path, __oflag);
    return ((int __attribute__((__gnu_inline__))  )tmp___3);
  } else {

  }
  tmp___5 = __open_alias(__path, __oflag, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern int ( __attribute__((__nonnull__(1))) __open64_2)(char const   *__path ,
                                                         int __oflag ) ;
extern int ( __attribute__((__nonnull__(1))) __open64_alias)(char const   *__path ,
                                                             int __oflag  , ...)  __asm__("open64")  ;
extern void __open64_too_many_args(void)  __attribute__((__error__("open64 can be called either with 2 or 3 arguments, not more"))) ;
extern void __open64_missing_mode(void)  __attribute__((__error__("open64 with O_CREAT or O_TMPFILE in second argument needs 3 arguments"))) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__artificial__, __always_inline__)) open64)(char const   *__path , int __oflag 
                                            , ...) 
{ 
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;

  {
  tmp = __builtin_va_arg_pack_len();
  if (tmp > 1) {
    __open64_too_many_args();
  } else {

  }
  if (0) {
    if ((__oflag & 64) != 0) {
      goto _L;
    } else
    if ((__oflag & 4259840) == 4259840) {
      _L: 
      tmp___1 = __builtin_va_arg_pack_len();
      if (tmp___1 < 1) {
        __open64_missing_mode();
        tmp___0 = __open64_2(__path, __oflag);
        return ((int __attribute__((__gnu_inline__))  )tmp___0);
      } else {

      }
    } else {

    }
    tmp___2 = __open64_alias(__path, __oflag, __builtin_va_arg_pack());
    return ((int __attribute__((__gnu_inline__))  )tmp___2);
  } else {

  }
  tmp___4 = __builtin_va_arg_pack_len();
  if (tmp___4 < 1) {
    tmp___3 = __open64_2(__path, __oflag);
    return ((int __attribute__((__gnu_inline__))  )tmp___3);
  } else {

  }
  tmp___5 = __open64_alias(__path, __oflag, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern int ( __attribute__((__nonnull__(2))) __openat_2)(int __fd ,
                                                         char const   *__path ,
                                                         int __oflag ) ;
extern int ( __attribute__((__nonnull__(2))) __openat_alias)(int __fd ,
                                                             char const   *__path ,
                                                             int __oflag  , ...)  __asm__("openat")  ;
extern void __openat_too_many_args(void)  __attribute__((__error__("openat can be called either with 3 or 4 arguments, not more"))) ;
extern void __openat_missing_mode(void)  __attribute__((__error__("openat with O_CREAT or O_TMPFILE in third argument needs 4 arguments"))) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__artificial__, __always_inline__)) openat)(int __fd , char const   *__path ,
                                            int __oflag  , ...) 
{ 
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;

  {
  tmp = __builtin_va_arg_pack_len();
  if (tmp > 1) {
    __openat_too_many_args();
  } else {

  }
  if (0) {
    if ((__oflag & 64) != 0) {
      goto _L;
    } else
    if ((__oflag & 4259840) == 4259840) {
      _L: 
      tmp___1 = __builtin_va_arg_pack_len();
      if (tmp___1 < 1) {
        __openat_missing_mode();
        tmp___0 = __openat_2(__fd, __path, __oflag);
        return ((int __attribute__((__gnu_inline__))  )tmp___0);
      } else {

      }
    } else {

    }
    tmp___2 = __openat_alias(__fd, __path, __oflag, __builtin_va_arg_pack());
    return ((int __attribute__((__gnu_inline__))  )tmp___2);
  } else {

  }
  tmp___4 = __builtin_va_arg_pack_len();
  if (tmp___4 < 1) {
    tmp___3 = __openat_2(__fd, __path, __oflag);
    return ((int __attribute__((__gnu_inline__))  )tmp___3);
  } else {

  }
  tmp___5 = __openat_alias(__fd, __path, __oflag, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern int ( __attribute__((__nonnull__(2))) __openat64_2)(int __fd ,
                                                           char const   *__path ,
                                                           int __oflag ) ;
extern int ( __attribute__((__nonnull__(2))) __openat64_alias)(int __fd ,
                                                               char const   *__path ,
                                                               int __oflag 
                                                               , ...)  __asm__("openat64")  ;
extern void __openat64_too_many_args(void)  __attribute__((__error__("openat64 can be called either with 3 or 4 arguments, not more"))) ;
extern void __openat64_missing_mode(void)  __attribute__((__error__("openat64 with O_CREAT or O_TMPFILE in third argument needs 4 arguments"))) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__artificial__, __always_inline__)) openat64)(int __fd , char const   *__path ,
                                              int __oflag  , ...) 
{ 
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;

  {
  tmp = __builtin_va_arg_pack_len();
  if (tmp > 1) {
    __openat64_too_many_args();
  } else {

  }
  if (0) {
    if ((__oflag & 64) != 0) {
      goto _L;
    } else
    if ((__oflag & 4259840) == 4259840) {
      _L: 
      tmp___1 = __builtin_va_arg_pack_len();
      if (tmp___1 < 1) {
        __openat64_missing_mode();
        tmp___0 = __openat64_2(__fd, __path, __oflag);
        return ((int __attribute__((__gnu_inline__))  )tmp___0);
      } else {

      }
    } else {

    }
    tmp___2 = __openat64_alias(__fd, __path, __oflag, __builtin_va_arg_pack());
    return ((int __attribute__((__gnu_inline__))  )tmp___2);
  } else {

  }
  tmp___4 = __builtin_va_arg_pack_len();
  if (tmp___4 < 1) {
    tmp___3 = __openat64_2(__fd, __path, __oflag);
    return ((int __attribute__((__gnu_inline__))  )tmp___3);
  } else {

  }
  tmp___5 = __openat64_alias(__fd, __path, __oflag, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
void php_stream_tidy_wrapper_error_log(php_stream_wrapper *wrapper ) ;
void php_stream_display_wrapper_errors(php_stream_wrapper *wrapper ,
                                       char const   *path ,
                                       char const   *caption ) ;
static HashTable url_stream_wrappers_hash  ;
static int le_stream  =    -1;
static int le_pstream  =    -1;
static int le_stream_filter  =    -1;
int __attribute__((__visibility__("default")))  php_file_le_stream(void) 
{ 


  {
  return ((int __attribute__((__visibility__("default")))  )le_stream);
}
}
int __attribute__((__visibility__("default")))  php_file_le_pstream(void) 
{ 


  {
  return ((int __attribute__((__visibility__("default")))  )le_pstream);
}
}
int __attribute__((__visibility__("default")))  php_file_le_stream_filter(void) 
{ 


  {
  return ((int __attribute__((__visibility__("default")))  )le_stream_filter);
}
}
HashTable __attribute__((__visibility__("default")))  *_php_stream_get_url_stream_wrappers_hash(void) 
{ 
  HashTable *tmp ;

  {
  if (file_globals.stream_wrappers) {
    tmp = file_globals.stream_wrappers;
  } else {
    tmp = & url_stream_wrappers_hash;
  }
  return ((HashTable __attribute__((__visibility__("default")))  *)tmp);
}
}
HashTable __attribute__((__visibility__("default")))  *php_stream_get_url_stream_wrappers_hash_global(void) 
{ 


  {
  return ((HashTable __attribute__((__visibility__("default")))  *)(& url_stream_wrappers_hash));
}
}
static int _php_stream_release_context(zend_rsrc_list_entry *le ,
                                       void *pContext ) 
{ 


  {
  if ((unsigned long )le->ptr == (unsigned long )pContext) {
    (le->refcount) --;
    return (le->refcount == 0);
  } else {

  }
  return (0);
}
}
static int forget_persistent_resource_id_numbers(zend_rsrc_list_entry *rsrc ) 
{ 
  php_stream *stream ;

  {
  if (rsrc->type != le_pstream) {
    return (0);
  } else {

  }
  stream = (php_stream *)rsrc->ptr;
  stream->rsrc_id = -1;
  if (stream->context) {
    zend_hash_apply_with_argument(& executor_globals.regular_list,
                                  (int (*)(void *pDest , void *argument ))(& _php_stream_release_context),
                                  (void *)stream->context);
    stream->context = (php_stream_context *)((void *)0);
  } else {

  }
  return (0);
}
}
int zm_deactivate_streams(int type , int module_number ) 
{ 


  {
  zend_hash_apply(& executor_globals.persistent_list,
                  (int (*)(void *pDest ))(& forget_persistent_resource_id_numbers));
  return (0);
}
}
php_stream __attribute__((__visibility__("default")))  *php_stream_encloses(php_stream *enclosing ,
                                                                            php_stream *enclosed ) 
{ 
  php_stream *orig ;

  {
  orig = enclosed->enclosing_stream;
  enclosed->enclosing_stream = enclosing;
  return ((php_stream __attribute__((__visibility__("default")))  *)orig);
}
}
int __attribute__((__visibility__("default")))  php_stream_from_persistent_id(char const   *persistent_id ,
                                                                              php_stream **stream ) 
{ 
  zend_rsrc_list_entry *le ;
  HashPosition pos ;
  zend_rsrc_list_entry *regentry ;
  ulong index___0 ;
  int __attribute__((__visibility__("default")))  tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  size_t tmp___1 ;
  int __attribute__((__visibility__("default")))  tmp___2 ;

  {
  tmp___1 = strlen(persistent_id);
  tmp___2 = zend_hash_find((HashTable const   *)(& executor_globals.persistent_list),
                           (char const   *)((char *)persistent_id),
                           (uint )(tmp___1 + 1UL), (void **)((void *)(& le)));
  if (tmp___2 == (int __attribute__((__visibility__("default")))  )0) {
    if (le->type == le_pstream) {
      if (stream) {
        index___0 = (ulong )-1;
        zend_hash_internal_pointer_reset_ex(& executor_globals.regular_list,
                                            & pos);
        while (1) {
          tmp = zend_hash_get_current_data_ex(& executor_globals.regular_list,
                                              (void **)(& regentry), & pos);
          if (! (tmp == (int __attribute__((__visibility__("default")))  )0)) {
            break;
          } else {

          }
          if ((unsigned long )regentry->ptr == (unsigned long )le->ptr) {
            zend_hash_get_current_key_ex((HashTable const   *)(& executor_globals.regular_list),
                                         (char **)((void *)0),
                                         (uint *)((void *)0), & index___0,
                                         (zend_bool )0, & pos);
            break;
          } else {

          }
          zend_hash_move_forward_ex(& executor_globals.regular_list, & pos);
        }
        *stream = (php_stream *)le->ptr;
        if (index___0 == 0xffffffffffffffffUL) {
          (le->refcount) ++;
          tmp___0 = zend_register_resource((zval *)((void *)0), (void *)*stream,
                                           le_pstream);
          (*stream)->rsrc_id = (int )tmp___0;
        } else {
          (regentry->refcount) ++;
          (*stream)->rsrc_id = (int )index___0;
        }
      } else {

      }
      return ((int __attribute__((__visibility__("default")))  )0);
    } else {

    }
    return ((int __attribute__((__visibility__("default")))  )1);
  } else {

  }
  return ((int __attribute__((__visibility__("default")))  )2);
}
}
static zend_llist *php_get_wrapper_errors_list(php_stream_wrapper *wrapper ) 
{ 
  zend_llist *list ;

  {
  list = (zend_llist *)((void *)0);
  if (! file_globals.wrapper_errors) {
    return ((zend_llist *)((void *)0));
  } else {
    zend_hash_find((HashTable const   *)file_globals.wrapper_errors,
                   (char const   *)(& wrapper), (uint )sizeof(wrapper),
                   (void **)(& list));
    return (list);
  }
}
}
void php_stream_display_wrapper_errors(php_stream_wrapper *wrapper ,
                                       char const   *path ,
                                       char const   *caption ) 
{ 
  char *tmp ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  char *msg ;
  int free_msg ;
  zend_llist *err_list ;
  zend_llist *tmp___1 ;
  size_t l ;
  int brlen ;
  int i ;
  int count ;
  int __attribute__((__visibility__("default")))  tmp___2 ;
  char const   *br ;
  char const   **err_buf_p ;
  zend_llist_position pos ;
  void __attribute__((__visibility__("default")))  *tmp___3 ;
  void __attribute__((__visibility__("default")))  *tmp___4 ;
  size_t tmp___5 ;
  void __attribute__((__visibility__("default")))  *tmp___6 ;
  void __attribute__((__visibility__("default")))  *tmp___7 ;
  void __attribute__((__visibility__("default")))  *tmp___8 ;
  int *tmp___9 ;

  {
  tmp___0 = _estrdup(path);
  tmp = (char *)tmp___0;
  free_msg = 0;
  if (wrapper) {
    tmp___1 = php_get_wrapper_errors_list(wrapper);
    err_list = tmp___1;
    if (err_list) {
      l = (size_t )0;
      tmp___2 = zend_llist_count(err_list);
      count = (int )tmp___2;
      if (core_globals.html_errors) {
        brlen = 7;
        br = "<br />\n";
      } else {
        brlen = 1;
        br = "\n";
      }
      tmp___3 = zend_llist_get_first_ex(err_list, & pos);
      err_buf_p = (char const   **)tmp___3;
      i = 0;
      while (err_buf_p) {
        tmp___5 = strlen(*err_buf_p);
        l += tmp___5;
        if (i < count - 1) {
          l += (size_t )brlen;
        } else {

        }
        tmp___4 = zend_llist_get_next_ex(err_list, & pos);
        err_buf_p = (char const   **)tmp___4;
        i ++;
      }
      tmp___6 = _emalloc(l + 1UL);
      msg = (char *)tmp___6;
      *(msg + 0) = (char )'\000';
      tmp___7 = zend_llist_get_first_ex(err_list, & pos);
      err_buf_p = (char const   **)tmp___7;
      i = 0;
      while (err_buf_p) {
        strcat((char */* __restrict  */)msg,
               (char const   */* __restrict  */)*err_buf_p);
        if (i < count - 1) {
          __repair_del_1244__0: /* CIL Label */ ;
        } else {

        }
        tmp___8 = zend_llist_get_next_ex(err_list, & pos);
        err_buf_p = (char const   **)tmp___8;
        i ++;
      }
      free_msg = 1;
    } else
    if ((unsigned long )wrapper == (unsigned long )(& php_plain_files_wrapper)) {
      tmp___9 = __errno_location();
      msg = strerror(*tmp___9);
    } else {
      msg = (char *)"operation failed";
    }
  } else {
    msg = (char *)"no suitable wrapper could be found";
  }
  php_strip_url_passwd(tmp);
  php_error_docref1((char const   *)((void *)0), (char const   *)tmp, 1 << 1L,
                    "%s: %s", caption, msg);
  _efree((void *)tmp);
  if (free_msg) {
    _efree((void *)msg);
  } else {

  }
  return;
}
}
void php_stream_tidy_wrapper_error_log(php_stream_wrapper *wrapper ) 
{ 


  {
  if (wrapper) {
    if (file_globals.wrapper_errors) {
      zend_hash_del_key_or_index(file_globals.wrapper_errors,
                                 (char const   *)(& wrapper),
                                 (uint )sizeof(wrapper), (ulong )0, 0);
    } else {

    }
  } else {

  }
  return;
}
}
static void wrapper_error_dtor(void *error ) 
{ 


  {
  _efree((void *)*((char **)error));
  return;
}
}
void __attribute__((__visibility__("default")))  php_stream_wrapper_log_error(php_stream_wrapper *wrapper ,
                                                                              int options ,
                                                                              char const   *fmt 
                                                                              , ...) 
{ 
  va_list args ;
  char *buffer ;
  zend_llist *list ;
  void __attribute__((__visibility__("default")))  *tmp ;
  zend_llist new_list ;

  {
  buffer = (char *)((void *)0);
  __builtin_va_start(args, fmt);
  vspprintf(& buffer, (size_t )0, fmt, args);
  __builtin_va_end(args);
  if (options & 8) {
    php_error_docref0((char const   *)((void *)0), 1 << 1L, "%s", buffer);
    _efree((void *)buffer);
  } else
  if ((unsigned long )wrapper == (unsigned long )((void *)0)) {
    php_error_docref0((char const   *)((void *)0), 1 << 1L, "%s", buffer);
    _efree((void *)buffer);
  } else {
    list = (zend_llist *)((void *)0);
    if (! file_globals.wrapper_errors) {
      tmp = _emalloc(sizeof(HashTable ));
      file_globals.wrapper_errors = (HashTable *)tmp;
      _zend_hash_init(file_globals.wrapper_errors, (uint )8,
                      (ulong (*)(char const   *arKey , uint nKeyLength ))((void *)0),
                      (void (*)(void *pDest ))(& zend_llist_destroy),
                      (zend_bool )0);
    } else {
      zend_hash_find((HashTable const   *)file_globals.wrapper_errors,
                     (char const   *)(& wrapper), (uint )sizeof(wrapper),
                     (void **)(& list));
    }
    if (! list) {
      zend_llist_init(& new_list, sizeof(buffer), & wrapper_error_dtor,
                      (unsigned char)0);
      _zend_hash_add_or_update(file_globals.wrapper_errors,
                               (char const   *)(& wrapper),
                               (uint )sizeof(wrapper), (void *)(& new_list),
                               (uint )sizeof(new_list), (void **)(& list), 1);
    } else {

    }
    zend_llist_add_element(list, (void *)(& buffer));
  }
  return;
}
}
php_stream __attribute__((__visibility__("default")))  *_php_stream_alloc(php_stream_ops *ops ,
                                                                          void *abstract ,
                                                                          char const   *persistent_id ,
                                                                          char const   *mode ) 
{ 
  php_stream *ret ;
  void *tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  void *tmp___2 ;
  int tmp___3 ;
  zend_rsrc_list_entry le ;
  size_t tmp___4 ;
  int __attribute__((__visibility__("default")))  tmp___5 ;
  int tmp___6 ;
  int __attribute__((__visibility__("default")))  tmp___7 ;

  {
  if (persistent_id) {
    tmp___3 = 1;
  } else {
    tmp___3 = 0;
  }
  if (tmp___3) {
    tmp___0 = __zend_malloc(sizeof(php_stream ));
    tmp___2 = tmp___0;
  } else {
    tmp___1 = _emalloc(sizeof(php_stream ));
    tmp___2 = (void *)tmp___1;
  }
  ret = (php_stream *)tmp___2;
  memset((void *)ret, 0, sizeof(php_stream ));
  ret->readfilters.stream = ret;
  ret->writefilters.stream = ret;
  ret->ops = ops;
  ret->abstract = abstract;
  if (persistent_id) {
    ret->is_persistent = 1;
  } else {
    ret->is_persistent = 0;
  }
  ret->chunk_size = file_globals.def_chunk_size;
  if (file_globals.auto_detect_line_endings) {
    ret->flags |= 4;
  } else {

  }
  if (persistent_id) {
    le.type = le_pstream;
    le.ptr = (void *)ret;
    le.refcount = 0;
    tmp___4 = strlen(persistent_id);
    tmp___5 = _zend_hash_add_or_update(& executor_globals.persistent_list,
                                       (char const   *)((char *)persistent_id),
                                       (uint )(tmp___4 + 1UL), (void *)(& le),
                                       (uint )sizeof(le), (void **)((void *)0),
                                       1);
    if (-1 == (int )tmp___5) {
      free((void *)ret);
      return ((php_stream __attribute__((__visibility__("default")))  *)((void *)0));
    } else {

    }
  } else {

  }
  if (persistent_id) {
    tmp___6 = le_pstream;
  } else {
    tmp___6 = le_stream;
  }
  tmp___7 = zend_register_resource((zval *)((void *)0), (void *)ret, tmp___6);
  ret->rsrc_id = (int )tmp___7;
  php_strlcpy(ret->mode, mode, sizeof(ret->mode));
  ret->wrapper = (php_stream_wrapper *)((void *)0);
  ret->wrapperthis = (void *)0;
  ret->wrapperdata = (zval *)((void *)0);
  ret->stdiocast = (FILE *)((void *)0);
  ret->orig_path = (char *)((void *)0);
  ret->context = (php_stream_context *)((void *)0);
  ret->readbuf = (unsigned char *)((void *)0);
  ret->enclosing_stream = (struct _php_stream *)((void *)0);
  return ((php_stream __attribute__((__visibility__("default")))  *)ret);
}
}
int __attribute__((__visibility__("default")))  _php_stream_free_enclosed(php_stream *stream_enclosed ,
                                                                          int close_options ) 
{ 
  int __attribute__((__visibility__("default")))  tmp ;

  {
  tmp = _php_stream_free(stream_enclosed, close_options | 32);
  return (tmp);
}
}
static int _php_stream_free_persistent(zend_rsrc_list_entry *le , void *pStream ) 
{ 


  {
  return ((unsigned long )le->ptr == (unsigned long )pStream);
}
}
int __attribute__((__visibility__("default")))  _php_stream_free(php_stream *stream ,
                                                                 int close_options ) 
{ 
  int ret ;
  int preserve_handle ;
  int tmp ;
  int release_cast ;
  php_stream_context *context ;
  php_stream *enclosing_stream ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;

  {
  ret = 1;
  if (close_options & 4) {
    tmp = 1;
  } else {
    tmp = 0;
  }
  preserve_handle = tmp;
  release_cast = 1;
  context = (php_stream_context *)((void *)0);
  if (! (close_options & 8)) {
    context = stream->context;
  } else {

  }
  if (stream->flags & 32) {
    preserve_handle = 1;
  } else {

  }
  if (stream->in_free) {
    if (stream->in_free == 1) {
      if (close_options & 32) {
        if ((unsigned long )stream->enclosing_stream == (unsigned long )((void *)0)) {
          close_options |= 8;
        } else {
          return ((int __attribute__((__visibility__("default")))  )1);
        }
      } else {
        return ((int __attribute__((__visibility__("default")))  )1);
      }
    } else {
      return ((int __attribute__((__visibility__("default")))  )1);
    }
  } else {

  }
  (stream->in_free) ++;
  if (close_options & 8) {
    if (! (close_options & 32)) {
      if (close_options & 3) {
        if ((unsigned long )stream->enclosing_stream != (unsigned long )((void *)0)) {
          enclosing_stream = stream->enclosing_stream;
          stream->enclosing_stream = (struct _php_stream *)((void *)0);
          tmp___0 = _php_stream_free(enclosing_stream, (close_options | 1) & -9);
          return (tmp___0);
        } else {

        }
      } else {

      }
    } else {

    }
  } else {

  }
  if (preserve_handle) {
    if (stream->fclose_stdiocast == 2) {
      (stream->in_free) --;
      return ((int __attribute__((__visibility__("default")))  )0);
    } else {

    }
    release_cast = 0;
  } else {

  }
  _php_stream_flush(stream, 1);
  if ((close_options & 8) == 0) {
    while (1) {
      tmp___1 = _zend_list_delete(stream->rsrc_id);
      if (! (tmp___1 == (int __attribute__((__visibility__("default")))  )0)) {
        break;
      } else {

      }
    }
  } else {

  }
  if (close_options & 1) {
    if (release_cast) {
      if (stream->fclose_stdiocast == 2) {
        stream->in_free = 0;
        tmp___2 = fclose(stream->stdiocast);
        return ((int __attribute__((__visibility__("default")))  )tmp___2);
      } else {

      }
    } else {

    }
    if (preserve_handle) {
      tmp___3 = 0;
    } else {
      tmp___3 = 1;
    }
    ret = (*((stream->ops)->close))(stream, tmp___3);
    stream->abstract = (void *)0;
    if (release_cast) {
      if (stream->fclose_stdiocast == 1) {
        if (stream->stdiocast) {
          fclose(stream->stdiocast);
          stream->stdiocast = (FILE *)((void *)0);
          stream->fclose_stdiocast = 0;
        } else {

        }
      } else {

      }
    } else {

    }
  } else {

  }
  if (close_options & 2) {
    while (stream->readfilters.head) {
      php_stream_filter_remove(stream->readfilters.head, 1);
    }
    while (stream->writefilters.head) {
      php_stream_filter_remove(stream->writefilters.head, 1);
    }
    if (stream->wrapper) {
      if ((stream->wrapper)->wops) {
        if (((stream->wrapper)->wops)->stream_closer) {
          (*(((stream->wrapper)->wops)->stream_closer))(stream->wrapper, stream);
          stream->wrapper = (php_stream_wrapper *)((void *)0);
        } else {

        }
      } else {

      }
    } else {

    }
    if (stream->wrapperdata) {
      _zval_ptr_dtor(& stream->wrapperdata);
      stream->wrapperdata = (zval *)((void *)0);
    } else {

    }
    if (stream->readbuf) {
      if (stream->is_persistent) {
        free((void *)stream->readbuf);
      } else {
        _efree((void *)stream->readbuf);
      }
      stream->readbuf = (unsigned char *)((void *)0);
    } else {

    }
    if (stream->is_persistent) {
      if (close_options & 16) {
        zend_hash_apply_with_argument(& executor_globals.persistent_list,
                                      (int (*)(void *pDest , void *argument ))(& _php_stream_free_persistent),
                                      (void *)stream);
      } else {

      }
    } else {

    }
    if (stream->orig_path) {
      if (stream->is_persistent) {
        free((void *)stream->orig_path);
      } else {
        _efree((void *)stream->orig_path);
      }
      stream->orig_path = (char *)((void *)0);
    } else {

    }
    if (stream->is_persistent) {
      free((void *)stream);
    } else {
      _efree((void *)stream);
    }
  } else {

  }
  if (context) {
    _zend_list_delete(context->rsrc_id);
  } else {

  }
  return ((int __attribute__((__visibility__("default")))  )ret);
}
}
static void php_stream_fill_read_buffer(php_stream *stream , size_t size ) 
{ 
  char *chunk_buf ;
  int err_flag ;
  php_stream_bucket_brigade brig_in ;
  php_stream_bucket_brigade brig_out ;
  php_stream_bucket_brigade *brig_inp ;
  php_stream_bucket_brigade *brig_outp ;
  php_stream_bucket_brigade *brig_swap ;
  off_t tmp ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  size_t justread ;
  int flags ;
  php_stream_bucket *bucket ;
  php_stream_filter_status_t status ;
  php_stream_filter *filter ;
  php_stream_bucket __attribute__((__visibility__("default")))  *tmp___1 ;
  void *tmp___2 ;
  void __attribute__((__visibility__("default")))  *tmp___3 ;
  size_t justread___0 ;
  void *tmp___4 ;
  void __attribute__((__visibility__("default")))  *tmp___5 ;

  {
  if (stream->readfilters.head) {
    err_flag = 0;
    brig_in.head = (php_stream_bucket *)((void *)0);
    brig_in.tail = (php_stream_bucket *)((void *)0);
    brig_out.head = (php_stream_bucket *)((void *)0);
    brig_out.tail = (php_stream_bucket *)((void *)0);
    brig_inp = & brig_in;
    brig_outp = & brig_out;
    tmp = (off_t )0;
    stream->readpos = tmp;
    stream->writepos = tmp;
    tmp___0 = _emalloc(stream->chunk_size);
    chunk_buf = (char *)tmp___0;
    while (1) {
      if (! stream->eof) {
        if (! err_flag) {
          if (! (stream->writepos - stream->readpos < (off_t )size)) {
            break;
          } else {

          }
        } else {
          break;
        }
      } else {
        break;
      }
      justread = (size_t )0;
      status = (php_stream_filter_status_t )0;
      justread = (*((stream->ops)->read))(stream, chunk_buf, stream->chunk_size);
      if (justread) {
        if (justread != 0xffffffffffffffffUL) {
          tmp___1 = php_stream_bucket_new(stream, chunk_buf, justread, 0, 0);
          bucket = (php_stream_bucket *)tmp___1;
          php_stream_bucket_append(brig_inp, bucket);
          flags = 0;
        } else {
          goto _L;
        }
      } else
      _L: 
      if (stream->eof) {
        flags = 2;
      } else {
        flags = 1;
      }
      filter = stream->readfilters.head;
      while (filter) {
        status = (*((filter->fops)->filter))(stream, filter, brig_inp,
                                             brig_outp, (size_t *)((void *)0),
                                             flags);
        if ((unsigned int )status != 2U) {
          break;
        } else {

        }
        brig_swap = brig_inp;
        brig_inp = brig_outp;
        brig_outp = brig_swap;
        memset((void *)brig_outp, 0, sizeof(*brig_outp));
        filter = filter->next;
      }
      switch ((unsigned int )status) {
      case 2U: 
      while (brig_inp->head) {
        bucket = brig_inp->head;
        if (stream->readbuflen - (size_t )stream->writepos < bucket->buflen) {
          stream->readbuflen += bucket->buflen;
          if (stream->is_persistent) {
            tmp___2 = __zend_realloc((void *)stream->readbuf, stream->readbuflen);
            stream->readbuf = (unsigned char *)tmp___2;
          } else {
            tmp___3 = _erealloc((void *)stream->readbuf, stream->readbuflen, 0);
            stream->readbuf = (unsigned char *)tmp___3;
          }
        } else {

        }
        memcpy((void */* __restrict  */)(stream->readbuf + stream->writepos),
               (void const   */* __restrict  */)bucket->buf, bucket->buflen);
        stream->writepos = (off_t )((size_t )stream->writepos + bucket->buflen);
        php_stream_bucket_unlink(bucket);
        php_stream_bucket_delref(bucket);
      }
      break;
      case 1U: 
      if (justread == 0UL) {
        err_flag = 1;
        break;
      } else {

      }
      continue;
      case 0U: 
      err_flag = 1;
      break;
      }
      if (justread == 0UL) {
        break;
      } else
      if (justread == 0xffffffffffffffffUL) {
        break;
      } else {

      }
    }
    _efree((void *)chunk_buf);
  } else
  if (stream->writepos - stream->readpos < (off_t )size) {
    justread___0 = (size_t )0;
    if (stream->readbuf) {
      if (stream->readbuflen - (size_t )stream->writepos < stream->chunk_size) {
        memmove((void *)stream->readbuf,
                (void const   *)(stream->readbuf + stream->readpos),
                stream->readbuflen - (size_t )stream->readpos);
        stream->writepos -= stream->readpos;
        stream->readpos = (off_t )0;
      } else {

      }
    } else {

    }
    if (stream->readbuflen - (size_t )stream->writepos < stream->chunk_size) {
      stream->readbuflen += stream->chunk_size;
      if (stream->is_persistent) {
        tmp___4 = __zend_realloc((void *)stream->readbuf, stream->readbuflen);
        stream->readbuf = (unsigned char *)tmp___4;
      } else {
        tmp___5 = _erealloc((void *)stream->readbuf, stream->readbuflen, 0);
        stream->readbuf = (unsigned char *)tmp___5;
      }
    } else {

    }
    justread___0 = (*((stream->ops)->read))(stream,
                                            (char *)(stream->readbuf + stream->writepos),
                                            stream->readbuflen - (size_t )stream->writepos);
    if (justread___0 != 0xffffffffffffffffUL) {
      stream->writepos = (off_t )((size_t )stream->writepos + justread___0);
    } else {

    }
  } else {

  }
  return;
}
}
size_t __attribute__((__visibility__("default")))  _php_stream_read(php_stream *stream ,
                                                                    char *buf ,
                                                                    size_t size ) 
{ 
  size_t toread ;
  size_t didread ;

  {
  toread = (size_t )0;
  didread = (size_t )0;
  while (size > 0UL) {
    if (stream->writepos > stream->readpos) {
      toread = (size_t )(stream->writepos - stream->readpos);
      if (toread > size) {
        toread = size;
      } else {

      }
      memcpy((void */* __restrict  */)buf,
             (void const   */* __restrict  */)(stream->readbuf + stream->readpos),
             toread);
      stream->readpos = (off_t )((size_t )stream->readpos + toread);
      size -= toread;
      buf += toread;
      didread += toread;
    } else {

    }
    if (size == 0UL) {
      break;
    } else {

    }
    if (! stream->readfilters.head) {
      if (stream->flags & 2) {
        toread = (*((stream->ops)->read))(stream, buf, size);
      } else
      if (stream->chunk_size == 1UL) {
        toread = (*((stream->ops)->read))(stream, buf, size);
      } else {
        goto _L;
      }
    } else {
      _L: 
      php_stream_fill_read_buffer(stream, size);
      toread = (size_t )(stream->writepos - stream->readpos);
      if (toread > size) {
        toread = size;
      } else {

      }
      if (toread > 0UL) {
        memcpy((void */* __restrict  */)buf,
               (void const   */* __restrict  */)(stream->readbuf + stream->readpos),
               toread);
        stream->readpos = (off_t )((size_t )stream->readpos + toread);
      } else {

      }
    }
    if (toread > 0UL) {
      didread += toread;
      buf += toread;
      size -= toread;
    } else {
      break;
    }
    if ((unsigned long )stream->wrapper != (unsigned long )(& php_plain_files_wrapper)) {
      break;
    } else {

    }
  }
  if (didread > 0UL) {
    stream->position = (off_t )((size_t )stream->position + didread);
  } else {

  }
  return ((size_t __attribute__((__visibility__("default")))  )didread);
}
}
int __attribute__((__visibility__("default")))  _php_stream_eof(php_stream *stream ) 
{ 
  int __attribute__((__visibility__("default")))  tmp ;

  {
  if (stream->writepos - stream->readpos > 0L) {
    return ((int __attribute__((__visibility__("default")))  )0);
  } else {

  }
  if (! stream->eof) {
    tmp = _php_stream_set_option(stream, 12, 0, (void *)0);
    if (-1 == (int )tmp) {
      stream->eof = 1;
    } else {

    }
  } else {

  }
  return ((int __attribute__((__visibility__("default")))  )stream->eof);
}
}
int __attribute__((__visibility__("default")))  _php_stream_putc(php_stream *stream ,
                                                                 int c ) 
{ 
  unsigned char buf ;
  size_t __attribute__((__visibility__("default")))  tmp ;

  {
  buf = (unsigned char )c;
  tmp = _php_stream_write(stream, (char const   *)(& buf), (size_t )1);
  if (tmp > (size_t __attribute__((__visibility__("default")))  )0) {
    return ((int __attribute__((__visibility__("default")))  )1);
  } else {

  }
  return ((int __attribute__((__visibility__("default")))  )-1);
}
}
int __attribute__((__visibility__("default")))  _php_stream_getc(php_stream *stream ) 
{ 
  char buf ;
  size_t __attribute__((__visibility__("default")))  tmp ;

  {
  tmp = _php_stream_read(stream, & buf, (size_t )1);
  if (tmp > (size_t __attribute__((__visibility__("default")))  )0) {
    return ((int __attribute__((__visibility__("default")))  )((int )buf & 255));
  } else {

  }
  return ((int __attribute__((__visibility__("default")))  )-1);
}
}
int __attribute__((__visibility__("default")))  _php_stream_puts(php_stream *stream ,
                                                                 char *buf ) 
{ 
  int len ;
  char newline[2] ;
  size_t tmp ;
  size_t __attribute__((__visibility__("default")))  tmp___0 ;
  size_t __attribute__((__visibility__("default")))  tmp___1 ;

  {
  newline[0] = (char )'\n';
  newline[1] = (char )'\000';
  tmp = strlen((char const   *)buf);
  len = (int )tmp;
  if (len > 0) {
    tmp___0 = _php_stream_write(stream, (char const   *)buf, (size_t )len);
    if (tmp___0) {
      tmp___1 = _php_stream_write(stream, (char const   *)(newline), (size_t )1);
      if (tmp___1) {
        return ((int __attribute__((__visibility__("default")))  )1);
      } else {

      }
    } else {

    }
  } else {

  }
  return ((int __attribute__((__visibility__("default")))  )0);
}
}
int __attribute__((__visibility__("default")))  _php_stream_stat(php_stream *stream ,
                                                                 php_stream_statbuf *ssb ) 
{ 
  int tmp ;
  int tmp___0 ;

  {
  memset((void *)ssb, 0, sizeof(*ssb));
  if (stream->wrapper) {
    if ((unsigned long )((stream->wrapper)->wops)->stream_stat != (unsigned long )((void *)0)) {
      tmp = (*(((stream->wrapper)->wops)->stream_stat))(stream->wrapper, stream,
                                                        ssb);
      return ((int __attribute__((__visibility__("default")))  )tmp);
    } else {

    }
  } else {

  }
  if ((unsigned long )(stream->ops)->stat == (unsigned long )((void *)0)) {
    return ((int __attribute__((__visibility__("default")))  )-1);
  } else {

  }
  tmp___0 = (*((stream->ops)->stat))(stream, ssb);
  return ((int __attribute__((__visibility__("default")))  )tmp___0);
}
}
char __attribute__((__visibility__("default")))  *php_stream_locate_eol(php_stream *stream ,
                                                                        char *buf ,
                                                                        size_t buf_len ) 
{ 
  size_t avail ;
  char *cr ;
  char *lf ;
  char *eol ;
  char *readptr ;
  void *tmp ;
  void *tmp___0 ;
  void *tmp___1 ;
  void *tmp___2 ;

  {
  eol = (char *)((void *)0);
  if (! buf) {
    readptr = (char *)(stream->readbuf + stream->readpos);
    avail = (size_t )(stream->writepos - stream->readpos);
  } else {
    readptr = buf;
    avail = buf_len;
  }
  if (stream->flags & 4) {
    tmp = memchr((void const   *)readptr, '\r', avail);
    cr = (char *)tmp;
    tmp___0 = memchr((void const   *)readptr, '\n', avail);
    lf = (char *)tmp___0;
    if (cr) {
      if ((unsigned long )lf != (unsigned long )(cr + 1)) {
        if (lf) {
          if ((unsigned long )lf < (unsigned long )cr) {
            goto _L___2;
          } else {
            stream->flags ^= 4;
            stream->flags |= 8;
            eol = cr;
          }
        } else {
          stream->flags ^= 4;
          stream->flags |= 8;
          eol = cr;
        }
      } else {
        goto _L___2;
      }
    } else
    _L___2: 
    if (cr) {
      if (lf) {
        if ((unsigned long )cr == (unsigned long )(lf - 1)) {
          stream->flags ^= 4;
          eol = lf;
        } else {
          goto _L___0;
        }
      } else {
        goto _L___0;
      }
    } else
    _L___0: 
    if (lf) {
      stream->flags ^= 4;
      eol = lf;
    } else {

    }
  } else
  if (stream->flags & 8) {
    tmp___1 = memchr((void const   *)readptr, '\r', avail);
    eol = (char *)tmp___1;
  } else {
    tmp___2 = memchr((void const   *)readptr, '\n', avail);
    eol = (char *)tmp___2;
  }
  return ((char __attribute__((__visibility__("default")))  *)eol);
}
}
char __attribute__((__visibility__("default")))  *_php_stream_get_line(php_stream *stream ,
                                                                       char *buf ,
                                                                       size_t maxlen ,
                                                                       size_t *returned_len ) 
{ 
  size_t avail ;
  size_t current_buf_size ;
  size_t total_copied ;
  int grow_mode ;
  char *bufstart ;
  size_t cpysz ;
  char *readptr ;
  char *eol ;
  int done ;
  char __attribute__((__visibility__("default")))  *tmp ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  size_t toread ;

  {
  avail = (size_t )0;
  current_buf_size = (size_t )0;
  total_copied = (size_t )0;
  grow_mode = 0;
  bufstart = buf;
  if ((unsigned long )buf == (unsigned long )((void *)0)) {
    grow_mode = 1;
  } else
  if (maxlen == 0UL) {
    return ((char __attribute__((__visibility__("default")))  *)((void *)0));
  } else {

  }
  while (1) {
    avail = (size_t )(stream->writepos - stream->readpos);
    if (avail > 0UL) {
      cpysz = (size_t )0;
      done = 0;
      readptr = (char *)(stream->readbuf + stream->readpos);
      tmp = php_stream_locate_eol(stream, (char *)((void *)0), (size_t )0);
      eol = (char *)tmp;
      if (eol) {
        cpysz = (size_t )((eol - readptr) + 1L);
        done = 1;
      } else {
        cpysz = avail;
      }
      if (grow_mode) {
        tmp___0 = _erealloc((void *)bufstart, (current_buf_size + cpysz) + 1UL,
                            0);
        bufstart = (char *)tmp___0;
        current_buf_size += cpysz + 1UL;
        buf = bufstart + total_copied;
      } else
      if (cpysz >= maxlen - 1UL) {
        cpysz = maxlen - 1UL;
        done = 1;
      } else {

      }
      memcpy((void */* __restrict  */)buf,
             (void const   */* __restrict  */)readptr, cpysz);
      stream->position = (off_t )((size_t )stream->position + cpysz);
      stream->readpos = (off_t )((size_t )stream->readpos + cpysz);
      buf += cpysz;
      maxlen -= cpysz;
      total_copied += cpysz;
      if (done) {
        break;
      } else {

      }
    } else
    if (stream->eof) {
      break;
    } else {
      if (grow_mode) {
        toread = stream->chunk_size;
      } else {
        toread = maxlen - 1UL;
        if (toread > stream->chunk_size) {
          toread = stream->chunk_size;
        } else {

        }
      }
      php_stream_fill_read_buffer(stream, toread);
      if (stream->writepos - stream->readpos == 0L) {
        break;
      } else {

      }
    }
  }
  if (total_copied == 0UL) {
    return ((char __attribute__((__visibility__("default")))  *)((void *)0));
  } else {

  }
  *(buf + 0) = (char )'\000';
  if (returned_len) {
    *returned_len = total_copied;
  } else {

  }
  return ((char __attribute__((__visibility__("default")))  *)bufstart);
}
}
static char *_php_stream_search_delim(php_stream *stream , size_t maxlen ,
                                      size_t skiplen , char *delim ,
                                      size_t delim_len ) 
{ 
  size_t seek_len ;
  void *tmp ;
  char *tmp___0 ;

  {
  if ((size_t )(stream->writepos - stream->readpos) < maxlen) {
    seek_len = (size_t )(stream->writepos - stream->readpos);
  } else {
    seek_len = maxlen;
  }
  if (seek_len <= skiplen) {
    return ((char *)((void *)0));
  } else {

  }
  if (delim_len == 1UL) {
    tmp = memchr((void const   *)(stream->readbuf + ((size_t )stream->readpos + skiplen)),
                 (int )*(delim + 0), seek_len - skiplen);
    return ((char *)tmp);
  } else {
    tmp___0 = zend_memnstr((char *)(stream->readbuf + ((size_t )stream->readpos + skiplen)),
                           delim, (int )delim_len,
                           (char *)(stream->readbuf + ((size_t )stream->readpos + seek_len)));
    return (tmp___0);
  }
}
}
char __attribute__((__visibility__("default")))  *php_stream_get_record(php_stream *stream ,
                                                                        size_t maxlen ,
                                                                        size_t *returned_len ,
                                                                        char *delim ,
                                                                        size_t delim_len ) 
{ 
  char *ret_buf ;
  char *found_delim ;
  size_t buffered_len ;
  size_t tent_ret_len ;
  int has_delim ;
  int tmp ;
  size_t just_read ;
  size_t to_read_now ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  size_t __attribute__((__visibility__("default")))  tmp___1 ;

  {
  found_delim = (char *)((void *)0);
  if (delim_len > 0UL) {
    if ((int )*(delim + 0) != 0) {
      tmp = 1;
    } else {
      tmp = 0;
    }
  } else {
    tmp = 0;
  }
  has_delim = tmp;
  if (maxlen == 0UL) {
    return ((char __attribute__((__visibility__("default")))  *)((void *)0));
  } else {

  }
  if (has_delim) {
    found_delim = _php_stream_search_delim(stream, maxlen, (size_t )0, delim,
                                           delim_len);
  } else {

  }
  buffered_len = (size_t )(stream->writepos - stream->readpos);
  while (1) {
    if (! found_delim) {
      if (! (buffered_len < maxlen)) {
        break;
      } else {

      }
    } else {
      break;
    }
    if (maxlen - buffered_len < stream->chunk_size) {
      to_read_now = maxlen - buffered_len;
    } else {
      to_read_now = stream->chunk_size;
    }
    php_stream_fill_read_buffer(stream, buffered_len + to_read_now);
    just_read = (size_t )(stream->writepos - stream->readpos) - buffered_len;
    if (just_read == 0UL) {
      break;
    } else {

    }
    if (has_delim) {
      found_delim = _php_stream_search_delim(stream, maxlen, buffered_len,
                                             delim, delim_len);
      if (found_delim) {
        break;
      } else {

      }
    } else {

    }
    buffered_len += just_read;
  }
  if (has_delim) {
    if (found_delim) {
      tent_ret_len = (size_t )(found_delim - (char *)(stream->readbuf + stream->readpos));
    } else {
      goto _L___2;
    }
  } else
  _L___2: 
  if (! has_delim) {
    if ((size_t )(stream->writepos - stream->readpos) >= maxlen) {
      tent_ret_len = maxlen;
    } else {
      goto _L___1;
    }
  } else
  _L___1: 
  if ((size_t )(stream->writepos - stream->readpos) < maxlen) {
    if (! stream->eof) {
      return ((char __attribute__((__visibility__("default")))  *)((void *)0));
    } else {
      goto _L___0;
    }
  } else
  _L___0: 
  if ((size_t )(stream->writepos - stream->readpos) == 0UL) {
    if (stream->eof) {
      return ((char __attribute__((__visibility__("default")))  *)((void *)0));
    } else {
      goto _L;
    }
  } else
  _L: 
  if ((size_t )(stream->writepos - stream->readpos) < maxlen) {
    tent_ret_len = (size_t )(stream->writepos - stream->readpos);
  } else {
    tent_ret_len = maxlen;
  }
  tmp___0 = _emalloc(tent_ret_len + 1UL);
  ret_buf = (char *)tmp___0;
  tmp___1 = _php_stream_read(stream, ret_buf, tent_ret_len);
  *returned_len = (size_t )tmp___1;
  if (found_delim) {
    stream->readpos = (off_t )((size_t )stream->readpos + delim_len);
    stream->position = (off_t )((size_t )stream->position + delim_len);
  } else {

  }
  *(ret_buf + *returned_len) = (char )'\000';
  return ((char __attribute__((__visibility__("default")))  *)ret_buf);
}
}
static size_t _php_stream_write_buffer(php_stream *stream , char const   *buf ,
                                       size_t count ) 
{ 
  size_t didwrite ;
  size_t towrite ;
  size_t justwrote ;
  off_t tmp ;

  {
  didwrite = (size_t )0;
  if ((stream->ops)->seek) {
    if ((stream->flags & 1) == 0) {
      if (stream->readpos != stream->writepos) {
        tmp = (off_t )0;
        stream->writepos = tmp;
        stream->readpos = tmp;
        (*((stream->ops)->seek))(stream, stream->position, 0, & stream->position);
      } else {

      }
    } else {

    }
  } else {

  }
  while (count > 0UL) {
    towrite = count;
    if (towrite > stream->chunk_size) {
      towrite = stream->chunk_size;
    } else {

    }
    justwrote = (*((stream->ops)->write))(stream, buf, towrite);
    if ((int )justwrote > 0) {
      buf += justwrote;
      count -= justwrote;
      didwrite += justwrote;
      if ((stream->ops)->seek) {
        if ((stream->flags & 1) == 0) {
          stream->position = (off_t )((size_t )stream->position + justwrote);
        } else {

        }
      } else {

      }
    } else {
      break;
    }
  }
  return (didwrite);
}
}
static size_t _php_stream_write_filtered(php_stream *stream ,
                                         char const   *buf , size_t count ,
                                         int flags ) 
{ 
  size_t consumed ;
  php_stream_bucket *bucket ;
  php_stream_bucket_brigade brig_in ;
  php_stream_bucket_brigade brig_out ;
  php_stream_bucket_brigade *brig_inp ;
  php_stream_bucket_brigade *brig_outp ;
  php_stream_bucket_brigade *brig_swap ;
  php_stream_filter_status_t status ;
  php_stream_filter *filter ;
  php_stream_bucket __attribute__((__visibility__("default")))  *tmp ;
  size_t *tmp___0 ;

  {
  consumed = (size_t )0;
  brig_in.head = (php_stream_bucket *)((void *)0);
  brig_in.tail = (php_stream_bucket *)((void *)0);
  brig_out.head = (php_stream_bucket *)((void *)0);
  brig_out.tail = (php_stream_bucket *)((void *)0);
  brig_inp = & brig_in;
  brig_outp = & brig_out;
  status = (php_stream_filter_status_t )0;
  if (buf) {
    tmp = php_stream_bucket_new(stream, (char *)buf, count, 0, 0);
    bucket = (php_stream_bucket *)tmp;
    php_stream_bucket_append(& brig_in, bucket);
  } else {

  }
  filter = stream->writefilters.head;
  while (filter) {
    if ((unsigned long )filter == (unsigned long )stream->writefilters.head) {
      tmp___0 = & consumed;
    } else {
      tmp___0 = (size_t *)((void *)0);
    }
    status = (*((filter->fops)->filter))(stream, filter, brig_inp, brig_outp,
                                         tmp___0, flags);
    if ((unsigned int )status != 2U) {
      break;
    } else {

    }
    brig_swap = brig_inp;
    brig_inp = brig_outp;
    brig_outp = brig_swap;
    memset((void *)brig_outp, 0, sizeof(*brig_outp));
    filter = filter->next;
  }
  switch ((unsigned int )status) {
  case 2U: 
  while (brig_inp->head) {
    bucket = brig_inp->head;
    _php_stream_write_buffer(stream, (char const   *)bucket->buf, bucket->buflen);
    php_stream_bucket_unlink(bucket);
    php_stream_bucket_delref(bucket);
  }
  break;
  case 1U: 
  break;
  case 0U: 
  break;
  }
  return (consumed);
}
}
int __attribute__((__visibility__("default")))  _php_stream_flush(php_stream *stream ,
                                                                  int closing ) 
{ 
  int ret ;
  int tmp ;

  {
  ret = 0;
  if (stream->writefilters.head) {
    if (closing) {
      tmp = 2;
    } else {
      tmp = 1;
    }
    _php_stream_write_filtered(stream, (char const   *)((void *)0), (size_t )0,
                               tmp);
  } else {

  }
  if ((stream->ops)->flush) {
    ret = (*((stream->ops)->flush))(stream);
  } else {

  }
  return ((int __attribute__((__visibility__("default")))  )ret);
}
}
size_t __attribute__((__visibility__("default")))  _php_stream_write(php_stream *stream ,
                                                                     char const   *buf ,
                                                                     size_t count ) 
{ 
  size_t tmp ;
  size_t tmp___0 ;

  {
  if ((unsigned long )buf == (unsigned long )((void *)0)) {
    return ((size_t __attribute__((__visibility__("default")))  )0);
  } else
  if (count == 0UL) {
    return ((size_t __attribute__((__visibility__("default")))  )0);
  } else
  if ((unsigned long )(stream->ops)->write == (unsigned long )((void *)0)) {
    return ((size_t __attribute__((__visibility__("default")))  )0);
  } else {

  }
  if (stream->writefilters.head) {
    tmp = _php_stream_write_filtered(stream, buf, count, 0);
    return ((size_t __attribute__((__visibility__("default")))  )tmp);
  } else {
    tmp___0 = _php_stream_write_buffer(stream, buf, count);
    return ((size_t __attribute__((__visibility__("default")))  )tmp___0);
  }
}
}
size_t __attribute__((__visibility__("default")))  _php_stream_printf(php_stream *stream ,
                                                                      char const   *fmt 
                                                                      , ...) 
{ 
  size_t count ;
  char *buf ;
  va_list ap ;
  int __attribute__((__visibility__("default")))  tmp ;
  size_t __attribute__((__visibility__("default")))  tmp___0 ;

  {
  __builtin_va_start(ap, fmt);
  tmp = vspprintf(& buf, (size_t )0, fmt, ap);
  count = (size_t )tmp;
  __builtin_va_end(ap);
  if (! buf) {
    return ((size_t __attribute__((__visibility__("default")))  )0);
  } else {

  }
  tmp___0 = _php_stream_write(stream, (char const   *)buf, count);
  count = (size_t )tmp___0;
  _efree((void *)buf);
  return ((size_t __attribute__((__visibility__("default")))  )count);
}
}
off_t __attribute__((__visibility__("default")))  _php_stream_tell(php_stream *stream ) 
{ 


  {
  return ((off_t __attribute__((__visibility__("default")))  )stream->position);
}
}
int __attribute__((__visibility__("default")))  _php_stream_seek(php_stream *stream ,
                                                                 off_t offset ,
                                                                 int whence ) 
{ 
  int ret ;
  off_t tmp ;
  char tmp___0[1024] ;
  size_t didread ;
  unsigned long tmp___1 ;
  size_t __attribute__((__visibility__("default")))  tmp___2 ;

  {
  if (stream->fclose_stdiocast == 2) {
    fflush(stream->stdiocast);
  } else {

  }
  if ((stream->flags & 2) == 0) {
    switch (whence) {
    case 1: 
    if (offset > 0L) {
      if (offset <= stream->writepos - stream->readpos) {
        stream->readpos += offset;
        stream->position += offset;
        stream->eof = 0;
        return ((int __attribute__((__visibility__("default")))  )0);
      } else {

      }
    } else {

    }
    break;
    case 0: 
    if (offset > stream->position) {
      if (offset <= (stream->position + stream->writepos) - stream->readpos) {
        stream->readpos += offset - stream->position;
        stream->position = offset;
        stream->eof = 0;
        return ((int __attribute__((__visibility__("default")))  )0);
      } else {

      }
    } else {

    }
    break;
    }
  } else {

  }
  if ((stream->ops)->seek) {
    if ((stream->flags & 1) == 0) {
      if (stream->writefilters.head) {
        _php_stream_flush(stream, 0);
      } else {

      }
      switch (whence) {
      case 1: 
      offset = stream->position + offset;
      whence = 0;
      break;
      }
      ret = (*((stream->ops)->seek))(stream, offset, whence, & stream->position);
      if ((stream->flags & 1) == 0) {
        goto _L;
      } else
      if (ret == 0) {
        _L: 
        if (ret == 0) {
          stream->eof = 0;
        } else {

        }
        tmp = (off_t )0;
        stream->writepos = tmp;
        stream->readpos = tmp;
        return ((int __attribute__((__visibility__("default")))  )ret);
      } else {

      }
    } else {

    }
  } else {

  }
  if (whence == 1) {
    if (offset >= 0L) {
      while (offset > 0L) {
        if ((unsigned long )offset < sizeof(tmp___0)) {
          tmp___1 = (unsigned long )offset;
        } else {
          tmp___1 = sizeof(tmp___0);
        }
        tmp___2 = _php_stream_read(stream, tmp___0, tmp___1);
        didread = (size_t )tmp___2;
        if (didread == 0UL) {
          return ((int __attribute__((__visibility__("default")))  )-1);
        } else {

        }
        offset = (off_t )((size_t )offset - didread);
      }
      stream->eof = 0;
      return ((int __attribute__((__visibility__("default")))  )0);
    } else {

    }
  } else {

  }
  php_error_docref0((char const   *)((void *)0), 1 << 1L,
                    "stream does not support seeking");
  return ((int __attribute__((__visibility__("default")))  )-1);
}
}
int __attribute__((__visibility__("default")))  _php_stream_set_option(php_stream *stream ,
                                                                       int option ,
                                                                       int value ,
                                                                       void *ptrparam ) 
{ 
  int ret ;

  {
  ret = -2;
  if ((stream->ops)->set_option) {
    ret = (*((stream->ops)->set_option))(stream, option, value, ptrparam);
  } else {

  }
  if (ret == -2) {
    switch (option) {
    case 5: 
    ret = (int )stream->chunk_size;
    stream->chunk_size = (size_t )value;
    return ((int __attribute__((__visibility__("default")))  )ret);
    case 2: 
    if (value == 0) {
      stream->flags |= 2;
    } else
    if (stream->flags & 2) {
      stream->flags ^= 2;
    } else {

    }
    ret = 0;
    break;
    default: ;
    }
  } else {

  }
  return ((int __attribute__((__visibility__("default")))  )ret);
}
}
int __attribute__((__visibility__("default")))  _php_stream_truncate_set_size(php_stream *stream ,
                                                                              size_t newsize ) 
{ 
  int __attribute__((__visibility__("default")))  tmp ;

  {
  tmp = _php_stream_set_option(stream, 10, 1, (void *)(& newsize));
  return (tmp);
}
}
size_t __attribute__((__visibility__("default")))  _php_stream_passthru(php_stream *stream ) 
{ 
  size_t bcount ;
  char buf[8192] ;
  int b ;
  char *p ;
  size_t mapped ;
  off_t __attribute__((__visibility__("default")))  tmp ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  int tmp___2 ;
  int __attribute__((__visibility__("default")))  tmp___3 ;
  size_t __attribute__((__visibility__("default")))  tmp___4 ;

  {
  bcount = (size_t )0;
  if (! stream->readfilters.head) {
    if (! stream->writefilters.head) {
      tmp___3 = _php_stream_set_option(stream, 9, 0, (void *)0);
      if (tmp___3 == (int __attribute__((__visibility__("default")))  )0) {
        tmp___2 = 1;
      } else {
        tmp___2 = 0;
      }
      if (tmp___2) {
        tmp = _php_stream_tell(stream);
        tmp___0 = _php_stream_mmap_range(stream, (size_t )tmp, (size_t )0,
                                         (php_stream_mmap_operation_t )2,
                                         & mapped);
        p = (char *)tmp___0;
        if (p) {
          php_output_write((char const   *)p, mapped);
          _php_stream_mmap_unmap_ex(stream, (off_t )mapped);
          return ((size_t __attribute__((__visibility__("default")))  )mapped);
        } else {

        }
      } else {

      }
    } else {

    }
  } else {

  }
  while (1) {
    tmp___4 = _php_stream_read(stream, buf, sizeof(buf));
    b = (int )tmp___4;
    if (! (b > 0)) {
      break;
    } else {

    }
    php_output_write((char const   *)(buf), (size_t )b);
    bcount += (size_t )b;
  }
  return ((size_t __attribute__((__visibility__("default")))  )bcount);
}
}
size_t __attribute__((__visibility__("default")))  _php_stream_copy_to_mem(php_stream *src ,
                                                                           char **buf ,
                                                                           size_t maxlen ,
                                                                           int persistent ) 
{ 
  size_t ret ;
  char *ptr ;
  size_t len ;
  size_t max_len ;
  int step ;
  int min_room ;
  php_stream_statbuf ssbuf ;
  char *tmp ;
  void *tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  size_t __attribute__((__visibility__("default")))  tmp___2 ;
  int __attribute__((__visibility__("default")))  tmp___3 ;
  int __attribute__((__visibility__("default")))  tmp___4 ;
  char *tmp___5 ;
  void *tmp___6 ;
  void __attribute__((__visibility__("default")))  *tmp___7 ;
  void *tmp___8 ;
  void __attribute__((__visibility__("default")))  *tmp___9 ;
  size_t __attribute__((__visibility__("default")))  tmp___10 ;
  void *tmp___11 ;
  void __attribute__((__visibility__("default")))  *tmp___12 ;

  {
  ret = (size_t )0;
  len = (size_t )0;
  step = 8192;
  min_room = 2048;
  if (maxlen == 0UL) {
    return ((size_t __attribute__((__visibility__("default")))  )0);
  } else {

  }
  if (maxlen == 0xffffffffffffffffUL) {
    maxlen = (size_t )0;
  } else {

  }
  if (maxlen > 0UL) {
    if (persistent) {
      tmp___0 = __zend_malloc(maxlen + 1UL);
      tmp = (char *)tmp___0;
    } else {
      tmp___1 = _emalloc(maxlen + 1UL);
      tmp = (char *)tmp___1;
    }
    *buf = tmp;
    ptr = tmp;
    while (1) {
      if (len < maxlen) {
        tmp___3 = _php_stream_eof(src);
        if (tmp___3) {
          break;
        } else {

        }
      } else {
        break;
      }
      tmp___2 = _php_stream_read(src, ptr, maxlen - len);
      ret = (size_t )tmp___2;
      if (! ret) {
        break;
      } else {

      }
      len += ret;
      ptr += ret;
    }
    *ptr = (char )'\000';
    return ((size_t __attribute__((__visibility__("default")))  )len);
  } else {

  }
  tmp___4 = _php_stream_stat(src, & ssbuf);
  if (tmp___4 == (int __attribute__((__visibility__("default")))  )0) {
    if (ssbuf.sb.st_size > 0L) {
      max_len = (size_t )(ssbuf.sb.st_size + (__off_t )step);
    } else {
      max_len = (size_t )step;
    }
  } else {
    max_len = (size_t )step;
  }
  if (persistent) {
    tmp___6 = __zend_malloc(max_len);
    tmp___5 = (char *)tmp___6;
  } else {
    tmp___7 = _emalloc(max_len);
    tmp___5 = (char *)tmp___7;
  }
  *buf = tmp___5;
  ptr = tmp___5;
  while (1) {
    tmp___10 = _php_stream_read(src, ptr, max_len - len);
    ret = (size_t )tmp___10;
    if (! ret) {
      break;
    } else {

    }
    len += ret;
    if (len + (size_t )min_room >= max_len) {
      if (persistent) {
        tmp___8 = __zend_realloc((void *)*buf, max_len + (size_t )step);
        *buf = (char *)tmp___8;
      } else {
        tmp___9 = _erealloc((void *)*buf, max_len + (size_t )step, 0);
        *buf = (char *)tmp___9;
      }
      max_len += (size_t )step;
      ptr = *buf + len;
    } else {
      ptr += ret;
    }
  }
  if (len) {
    if (persistent) {
      tmp___11 = __zend_realloc((void *)*buf, len + 1UL);
      *buf = (char *)tmp___11;
    } else {
      tmp___12 = _erealloc((void *)*buf, len + 1UL, 0);
      *buf = (char *)tmp___12;
    }
    *(*buf + len) = (char )'\000';
  } else {
    if (persistent) {
      free((void *)*buf);
    } else {
      _efree((void *)*buf);
    }
    *buf = (char *)((void *)0);
  }
  return ((size_t __attribute__((__visibility__("default")))  )len);
}
}
int __attribute__((__visibility__("default")))  _php_stream_copy_to_stream_ex(php_stream *src ,
                                                                              php_stream *dest ,
                                                                              size_t maxlen ,
                                                                              size_t *len ) 
{ 
  char buf[8192] ;
  size_t readchunk ;
  size_t haveread ;
  size_t didread ;
  size_t dummy ;
  php_stream_statbuf ssbuf ;
  int __attribute__((__visibility__("default")))  tmp ;
  char *p ;
  size_t mapped ;
  off_t __attribute__((__visibility__("default")))  tmp___0 ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  size_t __attribute__((__visibility__("default")))  tmp___2 ;
  int tmp___4 ;
  int __attribute__((__visibility__("default")))  tmp___5 ;
  size_t __attribute__((__visibility__("default")))  tmp___6 ;
  size_t didwrite ;
  size_t towrite ;
  char *writeptr ;
  size_t __attribute__((__visibility__("default")))  tmp___7 ;

  {
  haveread = (size_t )0;
  if (! len) {
    len = & dummy;
  } else {

  }
  if (maxlen == 0UL) {
    *len = (size_t )0;
    return ((int __attribute__((__visibility__("default")))  )0);
  } else {

  }
  if (maxlen == 0xffffffffffffffffUL) {
    maxlen = (size_t )0;
  } else {

  }
  tmp = _php_stream_stat(src, & ssbuf);
  if (tmp == (int __attribute__((__visibility__("default")))  )0) {
    if (ssbuf.sb.st_size == 0L) {
      if ((ssbuf.sb.st_mode & 61440U) == 32768U) {
        *len = (size_t )0;
        return ((int __attribute__((__visibility__("default")))  )0);
      } else {

      }
    } else {

    }
  } else {

  }
  if (! src->readfilters.head) {
    if (! src->writefilters.head) {
      tmp___5 = _php_stream_set_option(src, 9, 0, (void *)0);
      if (tmp___5 == (int __attribute__((__visibility__("default")))  )0) {
        tmp___4 = 1;
      } else {
        tmp___4 = 0;
      }
      if (tmp___4) {
        tmp___0 = _php_stream_tell(src);
        tmp___1 = _php_stream_mmap_range(src, (size_t )tmp___0, maxlen,
                                         (php_stream_mmap_operation_t )2,
                                         & mapped);
        p = (char *)tmp___1;
        if (p) {
          tmp___2 = _php_stream_write(dest, (char const   *)p, mapped);
          mapped = (size_t )tmp___2;
          _php_stream_mmap_unmap_ex(src, (off_t )mapped);
          *len = mapped;
          if (mapped > 0UL) {
            return ((int __attribute__((__visibility__("default")))  )0);
          } else {

          }
          return ((int __attribute__((__visibility__("default")))  )-1);
        } else {

        }
      } else {

      }
    } else {

    }
  } else {

  }
  while (1) {
    readchunk = sizeof(buf);
    if (maxlen) {
      if (maxlen - haveread < readchunk) {
        readchunk = maxlen - haveread;
      } else {

      }
    } else {

    }
    tmp___6 = _php_stream_read(src, buf, readchunk);
    didread = (size_t )tmp___6;
    if (didread) {
      towrite = didread;
      writeptr = buf;
      haveread += didread;
      while (towrite) {
        tmp___7 = _php_stream_write(dest, (char const   *)writeptr, towrite);
        didwrite = (size_t )tmp___7;
        if (didwrite == 0UL) {
          *len = haveread - (didread - towrite);
          return ((int __attribute__((__visibility__("default")))  )-1);
        } else {

        }
        towrite -= didwrite;
        writeptr += didwrite;
      }
    } else {
      break;
    }
    if (maxlen - haveread == 0UL) {
      break;
    } else {

    }
  }
  *len = haveread;
  if (haveread > 0UL) {
    return ((int __attribute__((__visibility__("default")))  )0);
  } else
  if (src->eof) {
    return ((int __attribute__((__visibility__("default")))  )0);
  } else {

  }
  return ((int __attribute__((__visibility__("default")))  )-1);
}
}
size_t __attribute__((__visibility__("default"),
__deprecated__))  _php_stream_copy_to_stream(php_stream *src ,
                                             php_stream *dest , size_t maxlen ) 
{ 
  size_t len ;
  int ret ;
  int __attribute__((__visibility__("default")))  tmp ;

  {
  tmp = _php_stream_copy_to_stream_ex(src, dest, maxlen, & len);
  ret = (int )tmp;
  if (ret == 0) {
    if (len == 0UL) {
      if (maxlen != 0UL) {
        return ((size_t __attribute__((__visibility__("default"),
        __deprecated__))  )1);
      } else {

      }
    } else {

    }
  } else {

  }
  return ((size_t __attribute__((__visibility__("default"),
  __deprecated__))  )len);
}
}
static void stream_resource_regular_dtor(zend_rsrc_list_entry *rsrc ) 
{ 
  php_stream *stream ;
  int __attribute__((__visibility__("default")))  tmp ;

  {
  stream = (php_stream *)rsrc->ptr;
  tmp = _php_stream_free(stream, 11);
  file_globals.pclose_ret = (int )tmp;
  return;
}
}
static void stream_resource_persistent_dtor(zend_rsrc_list_entry *rsrc ) 
{ 
  php_stream *stream ;
  int __attribute__((__visibility__("default")))  tmp ;

  {
  stream = (php_stream *)rsrc->ptr;
  tmp = _php_stream_free(stream, 11);
  file_globals.pclose_ret = (int )tmp;
  return;
}
}
void php_shutdown_stream_hashes(void) 
{ 


  {
  if (file_globals.stream_wrappers) {
    zend_hash_destroy(file_globals.stream_wrappers);
    _efree((void *)file_globals.stream_wrappers);
    file_globals.stream_wrappers = (HashTable *)((void *)0);
  } else {

  }
  if (file_globals.stream_filters) {
    zend_hash_destroy(file_globals.stream_filters);
    _efree((void *)file_globals.stream_filters);
    file_globals.stream_filters = (HashTable *)((void *)0);
  } else {

  }
  if (file_globals.wrapper_errors) {
    zend_hash_destroy(file_globals.wrapper_errors);
    _efree((void *)file_globals.wrapper_errors);
    file_globals.wrapper_errors = (HashTable *)((void *)0);
  } else {

  }
  return;
}
}
int php_init_stream_wrappers(int module_number ) 
{ 
  int __attribute__((__visibility__("default")))  tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;
  int tmp___11 ;
  int __attribute__((__visibility__("default")))  tmp___12 ;
  HashTable __attribute__((__visibility__("default")))  *tmp___13 ;
  int __attribute__((__visibility__("default")))  tmp___14 ;
  HashTable __attribute__((__visibility__("default")))  *tmp___15 ;
  int __attribute__((__visibility__("default")))  tmp___16 ;
  int __attribute__((__visibility__("default")))  tmp___17 ;
  int __attribute__((__visibility__("default")))  tmp___18 ;
  int __attribute__((__visibility__("default")))  tmp___19 ;
  int __attribute__((__visibility__("default")))  tmp___20 ;

  {
  tmp = zend_register_list_destructors_ex(& stream_resource_regular_dtor,
                                          (void (*)(zend_rsrc_list_entry *rsrc ))((void *)0),
                                          "stream", module_number);
  le_stream = (int )tmp;
  tmp___0 = zend_register_list_destructors_ex((void (*)(zend_rsrc_list_entry *rsrc ))((void *)0),
                                              & stream_resource_persistent_dtor,
                                              "persistent stream", module_number);
  le_pstream = (int )tmp___0;
  tmp___1 = zend_register_list_destructors_ex((void (*)(zend_rsrc_list_entry *rsrc ))((void *)0),
                                              (void (*)(zend_rsrc_list_entry *rsrc ))((void *)0),
                                              "stream filter", module_number);
  le_stream_filter = (int )tmp___1;
  tmp___12 = _zend_hash_init(& url_stream_wrappers_hash, (uint )0,
                             (ulong (*)(char const   *arKey , uint nKeyLength ))((void *)0),
                             (void (*)(void *pDest ))((void *)0), (zend_bool )1);
  if (tmp___12 == (int __attribute__((__visibility__("default")))  )0) {
    tmp___13 = php_get_stream_filters_hash_global();
    tmp___14 = _zend_hash_init((HashTable *)tmp___13, (uint )0,
                               (ulong (*)(char const   *arKey , uint nKeyLength ))((void *)0),
                               (void (*)(void *pDest ))((void *)0),
                               (zend_bool )1);
    if (tmp___14 == (int __attribute__((__visibility__("default")))  )0) {
      tmp___15 = php_stream_xport_get_hash();
      tmp___16 = _zend_hash_init((HashTable *)tmp___15, (uint )0,
                                 (ulong (*)(char const   *arKey ,
                                            uint nKeyLength ))((void *)0),
                                 (void (*)(void *pDest ))((void *)0),
                                 (zend_bool )1);
      if (tmp___16 == (int __attribute__((__visibility__("default")))  )0) {
        tmp___17 = php_stream_xport_register((char *)"tcp",
                                             (php_stream_transport_factory )(& php_stream_generic_socket_factory));
        if (tmp___17 == (int __attribute__((__visibility__("default")))  )0) {
          tmp___18 = php_stream_xport_register((char *)"udp",
                                               (php_stream_transport_factory )(& php_stream_generic_socket_factory));
          if (tmp___18 == (int __attribute__((__visibility__("default")))  )0) {
            tmp___19 = php_stream_xport_register((char *)"unix",
                                                 (php_stream_transport_factory )(& php_stream_generic_socket_factory));
            if (tmp___19 == (int __attribute__((__visibility__("default")))  )0) {
              tmp___20 = php_stream_xport_register((char *)"udg",
                                                   (php_stream_transport_factory )(& php_stream_generic_socket_factory));
              if (tmp___20 == (int __attribute__((__visibility__("default")))  )0) {
                tmp___11 = 0;
              } else {
                tmp___11 = -1;
              }
            } else {
              tmp___11 = -1;
            }
          } else {
            tmp___11 = -1;
          }
        } else {
          tmp___11 = -1;
        }
      } else {
        tmp___11 = -1;
      }
    } else {
      tmp___11 = -1;
    }
  } else {
    tmp___11 = -1;
  }
  return (tmp___11);
}
}
int php_shutdown_stream_wrappers(int module_number ) 
{ 
  HashTable __attribute__((__visibility__("default")))  *tmp ;
  HashTable __attribute__((__visibility__("default")))  *tmp___0 ;

  {
  zend_hash_destroy(& url_stream_wrappers_hash);
  tmp = php_get_stream_filters_hash_global();
  zend_hash_destroy((HashTable *)tmp);
  tmp___0 = php_stream_xport_get_hash();
  zend_hash_destroy((HashTable *)tmp___0);
  return (0);
}
}
__inline static int php_stream_wrapper_scheme_validate(char *protocol ,
                                                       int protocol_len ) 
{ 
  int i ;
  unsigned short const   **tmp ;

  {
  i = 0;
  while (i < protocol_len) {
    tmp = __ctype_b_loc();
    if (! ((int const   )*(*tmp + (int )*(protocol + i)) & 8)) {
      if ((int )*(protocol + i) != 43) {
        if ((int )*(protocol + i) != 45) {
          if ((int )*(protocol + i) != 46) {
            return (-1);
          } else {

          }
        } else {

        }
      } else {

      }
    } else {

    }
    i ++;
  }
  return (0);
}
}
int __attribute__((__visibility__("default")))  php_register_url_stream_wrapper(char *protocol ,
                                                                                php_stream_wrapper *wrapper ) 
{ 
  int protocol_len ;
  size_t tmp ;
  int tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;

  {
  tmp = strlen((char const   *)protocol);
  protocol_len = (int )tmp;
  tmp___0 = php_stream_wrapper_scheme_validate(protocol, protocol_len);
  if (tmp___0 == -1) {
    return ((int __attribute__((__visibility__("default")))  )-1);
  } else {

  }
  tmp___1 = _zend_hash_add_or_update(& url_stream_wrappers_hash,
                                     (char const   *)protocol,
                                     (uint )(protocol_len + 1),
                                     (void *)(& wrapper),
                                     (uint )sizeof(wrapper),
                                     (void **)((void *)0), 1 << 1);
  return (tmp___1);
}
}
int __attribute__((__visibility__("default")))  php_unregister_url_stream_wrapper(char *protocol ) 
{ 
  size_t tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = strlen((char const   *)protocol);
  tmp___0 = zend_hash_del_key_or_index(& url_stream_wrappers_hash,
                                       (char const   *)protocol,
                                       (uint )(tmp + 1UL), (ulong )0, 0);
  return (tmp___0);
}
}
static void clone_wrapper_hash(void) 
{ 
  php_stream_wrapper *tmp ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;

  {
  tmp___0 = _emalloc(sizeof(HashTable ));
  file_globals.stream_wrappers = (HashTable *)tmp___0;
  tmp___1 = zend_hash_num_elements((HashTable const   *)(& url_stream_wrappers_hash));
  _zend_hash_init(file_globals.stream_wrappers, (uint )tmp___1,
                  (ulong (*)(char const   *arKey , uint nKeyLength ))((void *)0),
                  (void (*)(void *pDest ))((void *)0), (zend_bool )1);
  zend_hash_copy(file_globals.stream_wrappers, & url_stream_wrappers_hash,
                 (void (*)(void *pElement ))((void *)0), (void *)(& tmp),
                 (uint )sizeof(tmp));
  return;
}
}
int __attribute__((__visibility__("default")))  php_register_url_stream_wrapper_volatile(char *protocol ,
                                                                                         php_stream_wrapper *wrapper ) 
{ 
  int protocol_len ;
  size_t tmp ;
  int tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;

  {
  tmp = strlen((char const   *)protocol);
  protocol_len = (int )tmp;
  tmp___0 = php_stream_wrapper_scheme_validate(protocol, protocol_len);
  if (tmp___0 == -1) {
    return ((int __attribute__((__visibility__("default")))  )-1);
  } else {

  }
  if (! file_globals.stream_wrappers) {
    clone_wrapper_hash();
  } else {

  }
  tmp___1 = _zend_hash_add_or_update(file_globals.stream_wrappers,
                                     (char const   *)protocol,
                                     (uint )(protocol_len + 1),
                                     (void *)(& wrapper),
                                     (uint )sizeof(wrapper),
                                     (void **)((void *)0), 1 << 1);
  return (tmp___1);
}
}
int __attribute__((__visibility__("default")))  php_unregister_url_stream_wrapper_volatile(char *protocol ) 
{ 
  size_t tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  if (! file_globals.stream_wrappers) {
    clone_wrapper_hash();
  } else {

  }
  tmp = strlen((char const   *)protocol);
  tmp___0 = zend_hash_del_key_or_index(file_globals.stream_wrappers,
                                       (char const   *)protocol,
                                       (uint )(tmp + 1UL), (ulong )0, 0);
  return (tmp___0);
}
}
php_stream_wrapper __attribute__((__visibility__("default")))  *php_stream_locate_url_wrapper(char const   *path ,
                                                                                              char **path_for_open ,
                                                                                              int options ) 
{ 
  HashTable *wrapper_hash ;
  HashTable *tmp ;
  php_stream_wrapper **wrapperpp ;
  char const   *p ;
  char const   *protocol ;
  int n ;
  php_stream_wrapper __attribute__((__visibility__("default")))  *tmp___0 ;
  unsigned short const   **tmp___1 ;
  int tmp___2 ;
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp___6 ;
  int tmp___9 ;
  int tmp___10 ;
  int tmp___11 ;
  int tmp___12 ;
  int tmp___13 ;
  int tmp___16 ;
  char *tmp___17 ;
  char __attribute__((__visibility__("default")))  *tmp___18 ;
  char wrapper_name[32] ;
  size_t php_str_len ;
  int __attribute__((__visibility__("default")))  tmp___19 ;
  int __attribute__((__visibility__("default")))  tmp___20 ;
  php_stream_wrapper *plain_files_wrapper ;
  int localhost ;
  int tmp___21 ;
  int __attribute__((__visibility__("default")))  tmp___22 ;
  int tmp___23 ;
  char *protocol_dup ;
  char __attribute__((__visibility__("default")))  *tmp___24 ;

  {
  if (file_globals.stream_wrappers) {
    tmp = file_globals.stream_wrappers;
  } else {
    tmp = & url_stream_wrappers_hash;
  }
  wrapper_hash = tmp;
  wrapperpp = (php_stream_wrapper **)((void *)0);
  protocol = (char const   *)((void *)0);
  n = 0;
  if (path_for_open) {
    *path_for_open = (char *)path;
  } else {

  }
  if (options & 2) {
    if (options & 64) {
      tmp___0 = (php_stream_wrapper __attribute__((__visibility__("default")))  *)((void *)0);
    } else {
      tmp___0 = & php_plain_files_wrapper;
    }
    return (tmp___0);
  } else {

  }
  p = path;
  while (1) {
    tmp___1 = __ctype_b_loc();
    if (! ((int const   )*(*tmp___1 + (int )*p) & 8)) {
      if (! ((int const   )*p == 43)) {
        if (! ((int const   )*p == 45)) {
          if (! ((int const   )*p == 46)) {
            break;
          } else {

          }
        } else {

        }
      } else {

      }
    } else {

    }
    n ++;
    p ++;
  }
  if ((int const   )*p == 58) {
    if (n > 1) {
      if (0) {
        if (0) {
          __s1_len = __builtin_strlen("//");
          __s2_len = __builtin_strlen(p + 1);
          if (! ((size_t )((void const   *)("//" + 1)) - (size_t )((void const   *)"//") == 1UL)) {
            goto _L___0;
          } else
          if (__s1_len >= 4UL) {
            _L___0: 
            if (! ((size_t )((void const   *)((p + 1) + 1)) - (size_t )((void const   *)(p + 1)) == 1UL)) {
              tmp___11 = 1;
            } else
            if (__s2_len >= 4UL) {
              tmp___11 = 1;
            } else {
              tmp___11 = 0;
            }
          } else {
            tmp___11 = 0;
          }
          if (tmp___11) {
            tmp___6 = __builtin_strcmp("//", p + 1);
            tmp___10 = tmp___6;
          } else {
            tmp___9 = __builtin_strcmp("//", p + 1);
            tmp___10 = tmp___9;
          }
        } else {
          tmp___9 = __builtin_strcmp("//", p + 1);
          tmp___10 = tmp___9;
        }
        tmp___13 = tmp___10;
      } else {
        tmp___12 = strncmp("//", p + 1, (size_t )2);
        tmp___13 = tmp___12;
      }
      if (tmp___13) {
        if (n == 4) {
          tmp___16 = memcmp((void const   *)"data:", (void const   *)path,
                            (size_t )5);
          if (tmp___16) {
            goto _L___2;
          } else {
            protocol = path;
          }
        } else {
          goto _L___2;
        }
      } else {
        protocol = path;
      }
    } else {
      goto _L___2;
    }
  } else
  _L___2: 
  if (n == 5) {
    tmp___2 = strncasecmp(path, "zlib:", (size_t )5);
    if (tmp___2 == 0) {
      protocol = "compress.zlib";
      n = 13;
      php_error_docref0((char const   *)((void *)0), 1 << 1L,
                        "Use of \"zlib:\" wrapper is deprecated; please use \"compress.zlib://\" instead");
    } else {

    }
  } else {

  }
  if (protocol) {
    tmp___18 = _estrndup(protocol, (unsigned int )n);
    tmp___17 = (char *)tmp___18;
    tmp___20 = zend_hash_find((HashTable const   *)wrapper_hash,
                              (char const   *)tmp___17, (uint )(n + 1),
                              (void **)(& wrapperpp));
    if (-1 == (int )tmp___20) {
      php_strtolower(tmp___17, (size_t )n);
      tmp___19 = zend_hash_find((HashTable const   *)wrapper_hash,
                                (char const   *)tmp___17, (uint )(n + 1),
                                (void **)(& wrapperpp));
      if (-1 == (int )tmp___19) {
        if ((unsigned long )n >= sizeof(wrapper_name)) {
          n = (int )(sizeof(wrapper_name) - 1UL);
        } else {

        }
        if ((unsigned long )n >= sizeof(wrapper_name)) {
          php_str_len = sizeof(wrapper_name) - 1UL;
        } else {
          php_str_len = (size_t )n;
        }
        memcpy((void */* __restrict  */)(wrapper_name),
               (void const   */* __restrict  */)protocol, php_str_len);
        wrapper_name[php_str_len] = (char )'\000';
        php_error_docref0((char const   *)((void *)0), 1 << 1L,
                          "Unable to find the wrapper \"%s\" - did you forget to enable it when you configured PHP?",
                          wrapper_name);
        wrapperpp = (php_stream_wrapper **)((void *)0);
        protocol = (char const   *)((void *)0);
      } else {

      }
    } else {

    }
    _efree((void *)tmp___17);
  } else {

  }
  if (! protocol) {
    goto _L___3;
  } else {
    tmp___23 = strncasecmp(protocol, "file", (size_t )n);
    if (! tmp___23) {
      _L___3: 
      plain_files_wrapper = (php_stream_wrapper *)(& php_plain_files_wrapper);
      if (protocol) {
        localhost = 0;
        tmp___21 = strncasecmp(path, "file://localhost/", (size_t )17);
        if (! tmp___21) {
          localhost = 1;
        } else {

        }
        if (localhost == 0) {
          if ((int const   )*(path + (n + 3)) != 0) {
            if ((int const   )*(path + (n + 3)) != 47) {
              if (options & 8) {
                php_error_docref0((char const   *)((void *)0), 1 << 1L,
                                  "remote host file access not supported, %s",
                                  path);
              } else {

              }
              return ((php_stream_wrapper __attribute__((__visibility__("default")))  *)((void *)0));
            } else {

            }
          } else {

          }
        } else {

        }
        if (path_for_open) {
          *path_for_open = ((char *)path + n) + 1;
          if (localhost == 1) {
            *path_for_open += 11;
          } else {

          }
          while (1) {
            (*path_for_open) ++;
            if (! ((int )*(*path_for_open) == 47)) {
              break;
            } else {

            }
          }
          (*path_for_open) --;
        } else {

        }
      } else {

      }
      if (options & 64) {
        return ((php_stream_wrapper __attribute__((__visibility__("default")))  *)((void *)0));
      } else {

      }
      if (file_globals.stream_wrappers) {
        if (wrapperpp) {
          return ((php_stream_wrapper __attribute__((__visibility__("default")))  *)*wrapperpp);
        } else {

        }
        tmp___22 = zend_hash_find((HashTable const   *)wrapper_hash, "file",
                                  (uint )sizeof("file"), (void **)(& wrapperpp));
        if (tmp___22 == (int __attribute__((__visibility__("default")))  )0) {
          return ((php_stream_wrapper __attribute__((__visibility__("default")))  *)*wrapperpp);
        } else {

        }
        if (options & 8) {
          php_error_docref0((char const   *)((void *)0), 1 << 1L,
                            "file:// wrapper is disabled in the server configuration");
        } else {

        }
        return ((php_stream_wrapper __attribute__((__visibility__("default")))  *)((void *)0));
      } else {

      }
      return ((php_stream_wrapper __attribute__((__visibility__("default")))  *)plain_files_wrapper);
    } else {

    }
  }
  if (wrapperpp) {
    if ((*wrapperpp)->is_url) {
      if ((options & 8192) == 0) {
        if (! core_globals.allow_url_fopen) {
          goto _L___4;
        } else
        if (options & 128) {
          goto _L___5;
        } else
        if (core_globals.in_user_include) {
          _L___5: 
          if (! core_globals.allow_url_include) {
            _L___4: 
            if (options & 8) {
              tmp___24 = _estrndup(protocol, (unsigned int )n);
              protocol_dup = (char *)tmp___24;
              if (! core_globals.allow_url_fopen) {
                php_error_docref0((char const   *)((void *)0), 1 << 1L,
                                  "%s:// wrapper is disabled in the server configuration by allow_url_fopen=0",
                                  protocol_dup);
              } else {
                php_error_docref0((char const   *)((void *)0), 1 << 1L,
                                  "%s:// wrapper is disabled in the server configuration by allow_url_include=0",
                                  protocol_dup);
              }
              _efree((void *)protocol_dup);
            } else {

            }
            return ((php_stream_wrapper __attribute__((__visibility__("default")))  *)((void *)0));
          } else {

          }
        } else {

        }
      } else {

      }
    } else {

    }
  } else {

  }
  return ((php_stream_wrapper __attribute__((__visibility__("default")))  *)*wrapperpp);
}
}
int __attribute__((__visibility__("default")))  _php_stream_mkdir(char *path ,
                                                                  int mode ,
                                                                  int options ,
                                                                  php_stream_context *context ) 
{ 
  php_stream_wrapper *wrapper ;
  php_stream_wrapper __attribute__((__visibility__("default")))  *tmp ;
  int tmp___0 ;

  {
  wrapper = (php_stream_wrapper *)((void *)0);
  tmp = php_stream_locate_url_wrapper((char const   *)path,
                                      (char **)((void *)0), 0);
  wrapper = (php_stream_wrapper *)tmp;
  if (! wrapper) {
    return ((int __attribute__((__visibility__("default")))  )0);
  } else
  if (! wrapper->wops) {
    return ((int __attribute__((__visibility__("default")))  )0);
  } else
  if (! (wrapper->wops)->stream_mkdir) {
    return ((int __attribute__((__visibility__("default")))  )0);
  } else {

  }
  tmp___0 = (*((wrapper->wops)->stream_mkdir))(wrapper, path, mode, options,
                                               context);
  return ((int __attribute__((__visibility__("default")))  )tmp___0);
}
}
int __attribute__((__visibility__("default")))  _php_stream_rmdir(char *path ,
                                                                  int options ,
                                                                  php_stream_context *context ) 
{ 
  php_stream_wrapper *wrapper ;
  php_stream_wrapper __attribute__((__visibility__("default")))  *tmp ;
  int tmp___0 ;

  {
  wrapper = (php_stream_wrapper *)((void *)0);
  tmp = php_stream_locate_url_wrapper((char const   *)path,
                                      (char **)((void *)0), 0);
  wrapper = (php_stream_wrapper *)tmp;
  if (! wrapper) {
    return ((int __attribute__((__visibility__("default")))  )0);
  } else
  if (! wrapper->wops) {
    return ((int __attribute__((__visibility__("default")))  )0);
  } else
  if (! (wrapper->wops)->stream_rmdir) {
    return ((int __attribute__((__visibility__("default")))  )0);
  } else {

  }
  tmp___0 = (*((wrapper->wops)->stream_rmdir))(wrapper, path, options, context);
  return ((int __attribute__((__visibility__("default")))  )tmp___0);
}
}
int __attribute__((__visibility__("default")))  _php_stream_stat_path(char *path ,
                                                                      int flags ,
                                                                      php_stream_statbuf *ssb ,
                                                                      php_stream_context *context ) 
{ 
  php_stream_wrapper *wrapper ;
  char *path_to_open ;
  int ret ;
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp___0 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  size_t __s1_len___0 ;
  size_t __s2_len___0 ;
  int tmp___7 ;
  int tmp___10 ;
  int tmp___11 ;
  int tmp___12 ;
  php_stream_wrapper __attribute__((__visibility__("default")))  *tmp___13 ;
  char __attribute__((__visibility__("default")))  *tmp___14 ;
  char __attribute__((__visibility__("default")))  *tmp___15 ;

  {
  wrapper = (php_stream_wrapper *)((void *)0);
  path_to_open = path;
  if (flags & 1) {
    if (basic_globals.CurrentLStatFile) {
      if (0) {
        __s1_len = __builtin_strlen((char const   *)path);
        __s2_len = __builtin_strlen((char const   *)basic_globals.CurrentLStatFile);
        if (! ((size_t )((void const   *)(path + 1)) - (size_t )((void const   *)path) == 1UL)) {
          goto _L___0;
        } else
        if (__s1_len >= 4UL) {
          _L___0: 
          if (! ((size_t )((void const   *)(basic_globals.CurrentLStatFile + 1)) - (size_t )((void const   *)basic_globals.CurrentLStatFile) == 1UL)) {
            tmp___5 = 1;
          } else
          if (__s2_len >= 4UL) {
            tmp___5 = 1;
          } else {
            tmp___5 = 0;
          }
        } else {
          tmp___5 = 0;
        }
        if (tmp___5) {
          tmp___0 = __builtin_strcmp((char const   *)path,
                                     (char const   *)basic_globals.CurrentLStatFile);
          tmp___4 = tmp___0;
        } else {
          tmp___3 = __builtin_strcmp((char const   *)path,
                                     (char const   *)basic_globals.CurrentLStatFile);
          tmp___4 = tmp___3;
        }
      } else {
        tmp___3 = __builtin_strcmp((char const   *)path,
                                   (char const   *)basic_globals.CurrentLStatFile);
        tmp___4 = tmp___3;
      }
      if (tmp___4 == 0) {
        memcpy((void */* __restrict  */)ssb,
               (void const   */* __restrict  */)(& basic_globals.lssb),
               sizeof(php_stream_statbuf ));
        return ((int __attribute__((__visibility__("default")))  )0);
      } else {

      }
    } else {

    }
  } else
  if (basic_globals.CurrentStatFile) {
    if (0) {
      __s1_len___0 = __builtin_strlen((char const   *)path);
      __s2_len___0 = __builtin_strlen((char const   *)basic_globals.CurrentStatFile);
      if (! ((size_t )((void const   *)(path + 1)) - (size_t )((void const   *)path) == 1UL)) {
        goto _L___2;
      } else
      if (__s1_len___0 >= 4UL) {
        _L___2: 
        if (! ((size_t )((void const   *)(basic_globals.CurrentStatFile + 1)) - (size_t )((void const   *)basic_globals.CurrentStatFile) == 1UL)) {
          tmp___12 = 1;
        } else
        if (__s2_len___0 >= 4UL) {
          tmp___12 = 1;
        } else {
          tmp___12 = 0;
        }
      } else {
        tmp___12 = 0;
      }
      if (tmp___12) {
        tmp___7 = __builtin_strcmp((char const   *)path,
                                   (char const   *)basic_globals.CurrentStatFile);
        tmp___11 = tmp___7;
      } else {
        tmp___10 = __builtin_strcmp((char const   *)path,
                                    (char const   *)basic_globals.CurrentStatFile);
        tmp___11 = tmp___10;
      }
    } else {
      tmp___10 = __builtin_strcmp((char const   *)path,
                                  (char const   *)basic_globals.CurrentStatFile);
      tmp___11 = tmp___10;
    }
    if (tmp___11 == 0) {
      memcpy((void */* __restrict  */)ssb,
             (void const   */* __restrict  */)(& basic_globals.ssb),
             sizeof(php_stream_statbuf ));
      return ((int __attribute__((__visibility__("default")))  )0);
    } else {

    }
  } else {

  }
  tmp___13 = php_stream_locate_url_wrapper((char const   *)path, & path_to_open,
                                           0);
  wrapper = (php_stream_wrapper *)tmp___13;
  if (wrapper) {
    if ((wrapper->wops)->url_stat) {
      ret = (*((wrapper->wops)->url_stat))(wrapper, path_to_open, flags, ssb,
                                           context);
      if (ret == 0) {
        if (flags & 1) {
          if (basic_globals.CurrentLStatFile) {
            _efree((void *)basic_globals.CurrentLStatFile);
          } else {

          }
          tmp___14 = _estrdup((char const   *)path);
          basic_globals.CurrentLStatFile = (char *)tmp___14;
          memcpy((void */* __restrict  */)(& basic_globals.lssb),
                 (void const   */* __restrict  */)ssb,
                 sizeof(php_stream_statbuf ));
        } else {
          if (basic_globals.CurrentStatFile) {
            _efree((void *)basic_globals.CurrentStatFile);
          } else {

          }
          tmp___15 = _estrdup((char const   *)path);
          basic_globals.CurrentStatFile = (char *)tmp___15;
          memcpy((void */* __restrict  */)(& basic_globals.ssb),
                 (void const   */* __restrict  */)ssb,
                 sizeof(php_stream_statbuf ));
        }
      } else {

      }
      return ((int __attribute__((__visibility__("default")))  )ret);
    } else {

    }
  } else {

  }
  return ((int __attribute__((__visibility__("default")))  )-1);
}
}
php_stream __attribute__((__visibility__("default")))  *_php_stream_opendir(char *path ,
                                                                            int options ,
                                                                            php_stream_context *context ) 
{ 
  php_stream *stream ;
  php_stream_wrapper *wrapper ;
  char *path_to_open ;
  php_stream_wrapper __attribute__((__visibility__("default")))  *tmp ;

  {
  stream = (php_stream *)((void *)0);
  wrapper = (php_stream_wrapper *)((void *)0);
  if (! path) {
    return ((php_stream __attribute__((__visibility__("default")))  *)((void *)0));
  } else
  if (! *path) {
    return ((php_stream __attribute__((__visibility__("default")))  *)((void *)0));
  } else {

  }
  path_to_open = path;
  tmp = php_stream_locate_url_wrapper((char const   *)path, & path_to_open,
                                      options);
  wrapper = (php_stream_wrapper *)tmp;
  if (wrapper) {
    if ((wrapper->wops)->dir_opener) {
      stream = (*((wrapper->wops)->dir_opener))(wrapper, path_to_open,
                                                (char *)"r", options ^ 8,
                                                (char **)((void *)0), context);
      if (stream) {
        stream->wrapper = wrapper;
        stream->flags |= 66;
      } else {

      }
    } else {
      goto _L;
    }
  } else
  _L: 
  if (wrapper) {
    php_stream_wrapper_log_error(wrapper, options ^ 8, "not implemented");
  } else {

  }
  if ((unsigned long )stream == (unsigned long )((void *)0)) {
    if (options & 8) {
      php_stream_display_wrapper_errors(wrapper, (char const   *)path,
                                        "failed to open dir");
    } else {

    }
  } else {

  }
  php_stream_tidy_wrapper_error_log(wrapper);
  return ((php_stream __attribute__((__visibility__("default")))  *)stream);
}
}
php_stream_dirent __attribute__((__visibility__("default")))  *_php_stream_readdir(php_stream *dirstream ,
                                                                                   php_stream_dirent *ent ) 
{ 
  size_t __attribute__((__visibility__("default")))  tmp ;

  {
  tmp = _php_stream_read(dirstream, (char *)ent, sizeof(php_stream_dirent ));
  if (sizeof(php_stream_dirent ) == (unsigned long )tmp) {
    return ((php_stream_dirent __attribute__((__visibility__("default")))  *)ent);
  } else {

  }
  return ((php_stream_dirent __attribute__((__visibility__("default")))  *)((void *)0));
}
}
php_stream __attribute__((__visibility__("default")))  *_php_stream_open_wrapper_ex(char *path ,
                                                                                    char *mode ,
                                                                                    int options ,
                                                                                    char **opened_path ,
                                                                                    php_stream_context *context ) 
{ 
  php_stream *stream ;
  php_stream_wrapper *wrapper ;
  char *path_to_open ;
  int persistent ;
  char *resolved_path ;
  char *copy_of_path ;
  size_t tmp ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  php_stream_wrapper __attribute__((__visibility__("default")))  *tmp___1 ;
  char *tmp___7 ;
  char __attribute__((__visibility__("default")))  *tmp___8 ;
  php_stream *newstream ;
  int tmp___9 ;
  int __attribute__((__visibility__("default")))  tmp___10 ;
  char *tmp___16 ;
  char __attribute__((__visibility__("default")))  *tmp___17 ;
  char *tmp___18 ;
  char __attribute__((__visibility__("default")))  *tmp___19 ;
  off_t newpos ;
  int tmp___20 ;
  char *tmp___22 ;

  {
  stream = (php_stream *)((void *)0);
  wrapper = (php_stream_wrapper *)((void *)0);
  persistent = options & 2048;
  resolved_path = (char *)((void *)0);
  copy_of_path = (char *)((void *)0);
  if (opened_path) {
    *opened_path = (char *)((void *)0);
  } else {

  }
  if (! path) {
    php_error_docref0((char const   *)((void *)0), 1 << 1L,
                      "Filename cannot be empty");
    return ((php_stream __attribute__((__visibility__("default")))  *)((void *)0));
  } else
  if (! *path) {
    php_error_docref0((char const   *)((void *)0), 1 << 1L,
                      "Filename cannot be empty");
    return ((php_stream __attribute__((__visibility__("default")))  *)((void *)0));
  } else {

  }
  if (options & 1) {
    tmp = strlen((char const   *)path);
    tmp___0 = (*zend_resolve_path)((char const   *)path, (int )tmp);
    resolved_path = (char *)tmp___0;
    if (resolved_path) {
      path = resolved_path;
      options |= 16384;
      options &= -2;
    } else {

    }
  } else {

  }
  path_to_open = path;
  tmp___1 = php_stream_locate_url_wrapper((char const   *)path, & path_to_open,
                                          options);
  wrapper = (php_stream_wrapper *)tmp___1;
  if (options & 256) {
    if (! wrapper) {
      goto _L;
    } else
    if (! wrapper->is_url) {
      _L: 
      php_error_docref0((char const   *)((void *)0), 1 << 1L,
                        "This function may only be used against URLs");
      if (resolved_path) {
        _efree((void *)resolved_path);
      } else {

      }
      return ((php_stream __attribute__((__visibility__("default")))  *)((void *)0));
    } else {

    }
  } else {

  }
  if (wrapper) {
    if (! (wrapper->wops)->stream_opener) {
      php_stream_wrapper_log_error(wrapper, options ^ 8,
                                   "wrapper does not support stream open");
    } else {
      stream = (*((wrapper->wops)->stream_opener))(wrapper, path_to_open, mode,
                                                   options ^ 8, opened_path,
                                                   context);
    }
    if (stream) {
      if (options & 2048) {
        if (! stream->is_persistent) {
          php_stream_wrapper_log_error(wrapper, options ^ 8,
                                       "wrapper does not support persistent streams");
          _php_stream_free(stream, 3);
          stream = (php_stream *)((void *)0);
        } else {

        }
      } else {

      }
    } else {

    }
    if (stream) {
      stream->wrapper = wrapper;
    } else {

    }
  } else {

  }
  if (stream) {
    if (opened_path) {
      if (! *opened_path) {
        if (resolved_path) {
          *opened_path = resolved_path;
          resolved_path = (char *)((void *)0);
        } else {

        }
      } else {

      }
    } else {

    }
    if (stream->orig_path) {
      if (persistent) {
        free((void *)stream->orig_path);
      } else {
        _efree((void *)stream->orig_path);
      }
    } else {

    }
    if (persistent) {
      tmp___7 = __strdup((char const   *)path);
      copy_of_path = tmp___7;
    } else {
      tmp___8 = _estrdup((char const   *)path);
      copy_of_path = (char *)tmp___8;
    }
    stream->orig_path = copy_of_path;
  } else {

  }
  if ((unsigned long )stream != (unsigned long )((void *)0)) {
    if (options & 16) {
      if (options & 32) {
        tmp___9 = 1;
      } else {
        tmp___9 = 0;
      }
      tmp___10 = _php_stream_make_seekable(stream, & newstream, tmp___9);
      switch (tmp___10) {
      case (int __attribute__((__visibility__("default")))  )0: 
      if (resolved_path) {
        _efree((void *)resolved_path);
      } else {

      }
      return ((php_stream __attribute__((__visibility__("default")))  *)stream);
      case (int __attribute__((__visibility__("default")))  )1: 
      if (newstream->orig_path) {
        if (persistent) {
          free((void *)newstream->orig_path);
        } else {
          _efree((void *)newstream->orig_path);
        }
      } else {

      }
      if (persistent) {
        tmp___16 = __strdup((char const   *)path);
        newstream->orig_path = tmp___16;
      } else {
        tmp___17 = _estrdup((char const   *)path);
        newstream->orig_path = (char *)tmp___17;
      }
      if (resolved_path) {
        _efree((void *)resolved_path);
      } else {

      }
      return ((php_stream __attribute__((__visibility__("default")))  *)newstream);
      default: 
      _php_stream_free(stream, 3);
      stream = (php_stream *)((void *)0);
      if (options & 8) {
        tmp___19 = _estrdup((char const   *)path);
        tmp___18 = (char *)tmp___19;
        php_strip_url_passwd(tmp___18);
        php_error_docref1((char const   *)((void *)0), (char const   *)tmp___18,
                          1 << 1L, "could not make seekable - %s", tmp___18);
        _efree((void *)tmp___18);
        options ^= 8;
      } else {

      }
      }
    } else {

    }
  } else {

  }
  if (stream) {
    if ((stream->ops)->seek) {
      if ((stream->flags & 1) == 0) {
        tmp___22 = __builtin_strchr(mode, 'a');
        if (tmp___22) {
          if (stream->position == 0L) {
            newpos = (off_t )0;
            tmp___20 = (*((stream->ops)->seek))(stream, (off_t )0, 1, & newpos);
            if (0 == tmp___20) {
              stream->position = newpos;
            } else {

            }
          } else {

          }
        } else {

        }
      } else {

      }
    } else {

    }
  } else {

  }
  if ((unsigned long )stream == (unsigned long )((void *)0)) {
    if (options & 8) {
      php_stream_display_wrapper_errors(wrapper, (char const   *)path,
                                        "failed to open stream");
      if (opened_path) {
        if (*opened_path) {
          _efree((void *)*opened_path);
          *opened_path = (char *)((void *)0);
        } else {

        }
      } else {

      }
    } else {

    }
  } else {

  }
  php_stream_tidy_wrapper_error_log(wrapper);
  if (resolved_path) {
    _efree((void *)resolved_path);
  } else {

  }
  return ((php_stream __attribute__((__visibility__("default")))  *)stream);
}
}
php_stream_context __attribute__((__visibility__("default")))  *php_stream_context_set(php_stream *stream ,
                                                                                       php_stream_context *context ) 
{ 
  php_stream_context *oldcontext ;

  {
  oldcontext = stream->context;
  stream->context = context;
  if (context) {
    _zend_list_addref(context->rsrc_id);
  } else {

  }
  if (oldcontext) {
    _zend_list_delete(oldcontext->rsrc_id);
  } else {

  }
  return ((php_stream_context __attribute__((__visibility__("default")))  *)oldcontext);
}
}
void __attribute__((__visibility__("default")))  php_stream_notification_notify(php_stream_context *context ,
                                                                                int notifycode ,
                                                                                int severity ,
                                                                                char *xmsg ,
                                                                                int xcode ,
                                                                                size_t bytes_sofar ,
                                                                                size_t bytes_max ,
                                                                                void *ptr ) 
{ 


  {
  if (context) {
    if (context->notifier) {
      (*((context->notifier)->func))(context, notifycode, severity, xmsg, xcode,
                                     bytes_sofar, bytes_max, ptr);
    } else {

    }
  } else {

  }
  return;
}
}
void __attribute__((__visibility__("default")))  php_stream_context_free(php_stream_context *context ) 
{ 


  {
  if (context->options) {
    _zval_ptr_dtor(& context->options);
    context->options = (zval *)((void *)0);
  } else {

  }
  if (context->notifier) {
    php_stream_notification_free(context->notifier);
    context->notifier = (php_stream_notifier *)((void *)0);
  } else {

  }
  _efree((void *)context);
  return;
}
}
php_stream_context __attribute__((__visibility__("default")))  *php_stream_context_alloc(void) 
{ 
  php_stream_context *context ;
  void __attribute__((__visibility__("default")))  *tmp ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;
  int __attribute__((__visibility__("default")))  tmp___2 ;

  {
  tmp = _ecalloc((size_t )1, sizeof(php_stream_context ));
  context = (php_stream_context *)tmp;
  context->notifier = (php_stream_notifier *)((void *)0);
  while (1) {
    tmp___0 = _emalloc(sizeof(zval_gc_info ));
    context->options = (zval *)tmp___0;
    ((zval_gc_info *)context->options)->u.buffered = (gc_root_buffer *)((void *)0);
    break;
  }
  (context->options)->refcount__gc = (zend_uint )1;
  (context->options)->is_ref__gc = (zend_uchar )0;
  _array_init(context->options, (uint )0);
  tmp___1 = php_le_stream_context();
  tmp___2 = zend_register_resource((zval *)((void *)0), (void *)context,
                                   (int )tmp___1);
  context->rsrc_id = (int )tmp___2;
  return ((php_stream_context __attribute__((__visibility__("default")))  *)context);
}
}
php_stream_notifier __attribute__((__visibility__("default")))  *php_stream_notification_alloc(void) 
{ 
  void __attribute__((__visibility__("default")))  *tmp ;

  {
  tmp = _ecalloc((size_t )1, sizeof(php_stream_notifier ));
  return ((php_stream_notifier __attribute__((__visibility__("default")))  *)tmp);
}
}
void __attribute__((__visibility__("default")))  php_stream_notification_free(php_stream_notifier *notifier ) 
{ 


  {
  if (notifier->dtor) {
    (*(notifier->dtor))(notifier);
  } else {

  }
  _efree((void *)notifier);
  return;
}
}
int __attribute__((__visibility__("default")))  php_stream_context_get_option(php_stream_context *context ,
                                                                              char const   *wrappername ,
                                                                              char const   *optionname ,
                                                                              zval ***optionvalue ) 
{ 
  zval **wrapperhash ;
  size_t tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  size_t tmp___1 ;
  int __attribute__((__visibility__("default")))  tmp___2 ;

  {
  tmp = strlen(wrappername);
  tmp___0 = zend_hash_find((HashTable const   *)(context->options)->value.ht,
                           (char const   *)((char *)wrappername),
                           (uint )(tmp + 1UL), (void **)(& wrapperhash));
  if (-1 == (int )tmp___0) {
    return ((int __attribute__((__visibility__("default")))  )-1);
  } else {

  }
  tmp___1 = strlen(optionname);
  tmp___2 = zend_hash_find((HashTable const   *)(*wrapperhash)->value.ht,
                           (char const   *)((char *)optionname),
                           (uint )(tmp___1 + 1UL), (void **)optionvalue);
  return (tmp___2);
}
}
int __attribute__((__visibility__("default")))  php_stream_context_set_option(php_stream_context *context ,
                                                                              char const   *wrappername ,
                                                                              char const   *optionname ,
                                                                              zval *optionvalue ) 
{ 
  zval **wrapperhash ;
  zval *category ;
  zval *copied_val ;
  void __attribute__((__visibility__("default")))  *tmp ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  size_t tmp___1 ;
  int __attribute__((__visibility__("default")))  tmp___2 ;
  size_t tmp___3 ;
  int __attribute__((__visibility__("default")))  tmp___4 ;
  size_t tmp___5 ;
  int __attribute__((__visibility__("default")))  tmp___6 ;

  {
  while (1) {
    tmp = _emalloc(sizeof(zval_gc_info ));
    copied_val = (zval *)tmp;
    ((zval_gc_info *)copied_val)->u.buffered = (gc_root_buffer *)((void *)0);
    break;
  }
  *copied_val = (zval )zval_used_for_init;
  *copied_val = *optionvalue;
  _zval_copy_ctor(copied_val);
  copied_val->refcount__gc = (zend_uint )1;
  copied_val->is_ref__gc = (zend_uchar )0;
  tmp___3 = strlen(wrappername);
  tmp___4 = zend_hash_find((HashTable const   *)(context->options)->value.ht,
                           (char const   *)((char *)wrappername),
                           (uint )(tmp___3 + 1UL), (void **)(& wrapperhash));
  if (-1 == (int )tmp___4) {
    while (1) {
      tmp___0 = _emalloc(sizeof(zval_gc_info ));
      category = (zval *)tmp___0;
      ((zval_gc_info *)category)->u.buffered = (gc_root_buffer *)((void *)0);
      break;
    }
    category->refcount__gc = (zend_uint )1;
    category->is_ref__gc = (zend_uchar )0;
    _array_init(category, (uint )0);
    tmp___1 = strlen(wrappername);
    tmp___2 = _zend_hash_add_or_update((context->options)->value.ht,
                                       (char const   *)((char *)wrappername),
                                       (uint )(tmp___1 + 1UL),
                                       (void *)((void **)(& category)),
                                       (uint )sizeof(zval *),
                                       (void **)((void *)0), 1);
    if (-1 == (int )tmp___2) {
      return ((int __attribute__((__visibility__("default")))  )-1);
    } else {

    }
    wrapperhash = & category;
  } else {

  }
  tmp___5 = strlen(optionname);
  tmp___6 = _zend_hash_add_or_update((*wrapperhash)->value.ht,
                                     (char const   *)((char *)optionname),
                                     (uint )(tmp___5 + 1UL),
                                     (void *)((void **)(& copied_val)),
                                     (uint )sizeof(zval *),
                                     (void **)((void *)0), 1);
  return (tmp___6);
}
}
int __attribute__((__visibility__("default")))  php_stream_dirent_alphasort(char const   **a ,
                                                                            char const   **b ) 
{ 
  int tmp ;

  {
  tmp = strcoll(*a, *b);
  return ((int __attribute__((__visibility__("default")))  )tmp);
}
}
int __attribute__((__visibility__("default")))  php_stream_dirent_alphasortr(char const   **a ,
                                                                             char const   **b ) 
{ 
  int tmp ;

  {
  tmp = strcoll(*b, *a);
  return ((int __attribute__((__visibility__("default")))  )tmp);
}
}
int __attribute__((__visibility__("default")))  _php_stream_scandir(char *dirname ,
                                                                    char ***namelist ,
                                                                    int flags ,
                                                                    php_stream_context *context ,
                                                                    int (*compare)(char const   **a ,
                                                                                   char const   **b ) ) 
{ 
  php_stream *stream ;
  php_stream_dirent sdp ;
  char **vector ;
  int vector_size ;
  int nfiles ;
  php_stream __attribute__((__visibility__("default")))  *tmp ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  php_stream_dirent __attribute__((__visibility__("default")))  *tmp___2 ;

  {
  vector = (char **)((void *)0);
  vector_size = 0;
  nfiles = 0;
  if (! namelist) {
    return ((int __attribute__((__visibility__("default")))  )-1);
  } else {

  }
  tmp = _php_stream_opendir(dirname, 8, context);
  stream = (php_stream *)tmp;
  if (! stream) {
    return ((int __attribute__((__visibility__("default")))  )-1);
  } else {

  }
  while (1) {
    tmp___2 = _php_stream_readdir(stream, & sdp);
    if (! tmp___2) {
      break;
    } else {

    }
    if (nfiles == vector_size) {
      if (vector_size == 0) {
        vector_size = 10;
      } else {
        vector_size *= 2;
      }
      tmp___0 = _erealloc((void *)vector,
                          (unsigned long )vector_size * sizeof(char *), 0);
      vector = (char **)tmp___0;
    } else {

    }
    tmp___1 = _estrdup((char const   *)(sdp.d_name));
    *(vector + nfiles) = (char *)tmp___1;
    nfiles ++;
  }
  _php_stream_free(stream, 3);
  *namelist = vector;
  if (compare) {
    qsort((void *)*namelist, (size_t )nfiles, sizeof(char *),
          (int (*)(void const   * , void const   * ))compare);
  } else {

  }
  return ((int __attribute__((__visibility__("default")))  )nfiles);
}
}
