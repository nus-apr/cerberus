typedef unsigned long size_t;
typedef int wchar_t;
typedef int __int32_t;
typedef unsigned long __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long __ino_t;
typedef unsigned long __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long __nlink_t;
typedef long __off_t;
typedef long __off64_t;
typedef long __time_t;
typedef long __blksize_t;
typedef long __blkcnt_t;
typedef long __blkcnt64_t;
typedef long __ssize_t;
typedef long __syscall_slong_t;
typedef __ssize_t ssize_t;
typedef unsigned long ulong;
typedef unsigned int uint;
struct __anonstruct___sigset_t_9 {
   unsigned long __val[1024UL / (8UL * sizeof(unsigned long ))] ;
};
typedef struct __anonstruct___sigset_t_9 __sigset_t;
struct timespec {
   __time_t tv_sec ;
   __syscall_slong_t tv_nsec ;
};
union __anonunion___u_23 {
   long double __l ;
   int __i[3] ;
};
struct _IO_FILE;
struct _IO_FILE;
struct _IO_FILE;
typedef struct _IO_FILE FILE;
typedef __builtin_va_list __gnuc_va_list;
struct _IO_FILE;
typedef void _IO_lock_t;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
struct _IO_FILE {
   int _flags ;
   char *_IO_read_ptr ;
   char *_IO_read_end ;
   char *_IO_read_base ;
   char *_IO_write_base ;
   char *_IO_write_ptr ;
   char *_IO_write_end ;
   char *_IO_buf_base ;
   char *_IO_buf_end ;
   char *_IO_save_base ;
   char *_IO_backup_base ;
   char *_IO_save_end ;
   struct _IO_marker *_markers ;
   struct _IO_FILE *_chain ;
   int _fileno ;
   int _flags2 ;
   __off_t _old_offset ;
   unsigned short _cur_column ;
   signed char _vtable_offset ;
   char _shortbuf[1] ;
   _IO_lock_t *_lock ;
   __off64_t _offset ;
   void *__pad1 ;
   void *__pad2 ;
   void *__pad3 ;
   void *__pad4 ;
   size_t __pad5 ;
   int _mode ;
   char _unused2[(15UL * sizeof(int ) - 4UL * sizeof(void *)) - sizeof(size_t )] ;
};
typedef struct _IO_FILE _IO_FILE;
typedef __gnuc_va_list va_list;
struct obstack;
struct obstack;
struct obstack;
typedef unsigned char zend_bool;
typedef unsigned char zend_uchar;
typedef unsigned int zend_uint;
typedef unsigned long zend_ulong;
typedef unsigned long zend_uintptr_t;
typedef unsigned int zend_object_handle;
struct _zend_object_handlers;
struct _zend_object_handlers;
typedef struct _zend_object_handlers zend_object_handlers;
struct _zend_object_value {
   zend_object_handle handle ;
   zend_object_handlers const   *handlers ;
};
typedef struct _zend_object_value zend_object_value;
struct _hashtable;
struct _hashtable;
struct _hashtable;
struct bucket {
   ulong h ;
   uint nKeyLength ;
   void *pData ;
   void *pDataPtr ;
   struct bucket *pListNext ;
   struct bucket *pListLast ;
   struct bucket *pNext ;
   struct bucket *pLast ;
   char const   *arKey ;
};
typedef struct bucket Bucket;
struct _hashtable {
   uint nTableSize ;
   uint nTableMask ;
   uint nNumOfElements ;
   ulong nNextFreeElement ;
   Bucket *pInternalPointer ;
   Bucket *pListHead ;
   Bucket *pListTail ;
   Bucket **arBuckets ;
   void (*pDestructor)(void *pDest ) ;
   zend_bool persistent ;
   unsigned char nApplyCount ;
   zend_bool bApplyProtection ;
};
typedef struct _hashtable HashTable;
struct _zend_hash_key {
   char const   *arKey ;
   uint nKeyLength ;
   ulong h ;
};
typedef struct _zend_hash_key zend_hash_key;
typedef Bucket *HashPosition;
struct _HashPointer {
   HashPosition pos ;
   ulong h ;
};
typedef struct _HashPointer HashPointer;
struct _zend_llist_element {
   struct _zend_llist_element *next ;
   struct _zend_llist_element *prev ;
   char data[1] ;
};
typedef struct _zend_llist_element zend_llist_element;
struct _zend_llist {
   zend_llist_element *head ;
   zend_llist_element *tail ;
   size_t count ;
   size_t size ;
   void (*dtor)(void * ) ;
   unsigned char persistent ;
   zend_llist_element *traverse_ptr ;
};
typedef struct _zend_llist zend_llist;
struct _zval_struct;
struct _zval_struct;
typedef struct _zval_struct zval;
struct _zend_class_entry;
struct _zend_class_entry;
typedef struct _zend_class_entry zend_class_entry;
union _zend_function;
union _zend_function;
union _zend_function;
struct _zend_property_info;
struct _zend_property_info;
struct _zend_property_info;
struct _zend_literal;
struct _zend_literal;
struct _zend_literal;
struct _zend_object_handlers {
   void (*add_ref)(zval *object ) ;
   void (*del_ref)(zval *object ) ;
   zend_object_value (*clone_obj)(zval *object ) ;
   zval *(*read_property)(zval *object , zval *member , int type ,
                          struct _zend_literal  const  *key ) ;
   void (*write_property)(zval *object , zval *member , zval *value ,
                          struct _zend_literal  const  *key ) ;
   zval *(*read_dimension)(zval *object , zval *offset , int type ) ;
   void (*write_dimension)(zval *object , zval *offset , zval *value ) ;
   zval **(*get_property_ptr_ptr)(zval *object , zval *member ,
                                  struct _zend_literal  const  *key ) ;
   zval *(*get)(zval *object ) ;
   void (*set)(zval **object , zval *value ) ;
   int (*has_property)(zval *object , zval *member , int has_set_exists ,
                       struct _zend_literal  const  *key ) ;
   void (*unset_property)(zval *object , zval *member ,
                          struct _zend_literal  const  *key ) ;
   int (*has_dimension)(zval *object , zval *member , int check_empty ) ;
   void (*unset_dimension)(zval *object , zval *offset ) ;
   HashTable *(*get_properties)(zval *object ) ;
   union _zend_function *(*get_method)(zval **object_ptr , char *method ,
                                       int method_len ,
                                       struct _zend_literal  const  *key ) ;
   int (*call_method)(char const   *method , int ht , zval *return_value ,
                      zval **return_value_ptr , zval *this_ptr ,
                      int return_value_used ) ;
   union _zend_function *(*get_constructor)(zval *object ) ;
   zend_class_entry *(*get_class_entry)(zval const   *object ) ;
   int (*get_class_name)(zval const   *object , char const   **class_name ,
                         zend_uint *class_name_len , int parent ) ;
   int (*compare_objects)(zval *object1 , zval *object2 ) ;
   int (*cast_object)(zval *readobj , zval *retval , int type ) ;
   int (*count_elements)(zval *object , long *count ) ;
   HashTable *(*get_debug_info)(zval *object , int *is_temp ) ;
   int (*get_closure)(zval *obj , zend_class_entry **ce_ptr ,
                      union _zend_function **fptr_ptr , zval **zobj_ptr ) ;
   HashTable *(*get_gc)(zval *object , zval ***table , int *n ) ;
};
struct __anonstruct_str_34 {
   char *val ;
   int len ;
};
union _zvalue_value {
   long lval ;
   double dval ;
   struct __anonstruct_str_34 str ;
   HashTable *ht ;
   zend_object_value obj ;
};
typedef union _zvalue_value zvalue_value;
struct _zval_struct {
   zvalue_value value ;
   zend_uint refcount__gc ;
   zend_uchar type ;
   zend_uchar is_ref__gc ;
};
union _zend_function;
struct _zend_object_iterator;
struct _zend_object_iterator;
typedef struct _zend_object_iterator zend_object_iterator;
struct _zend_object_iterator_funcs {
   void (*dtor)(zend_object_iterator *iter ) ;
   int (*valid)(zend_object_iterator *iter ) ;
   void (*get_current_data)(zend_object_iterator *iter , zval ***data ) ;
   int (*get_current_key)(zend_object_iterator *iter , char **str_key ,
                          uint *str_key_len , ulong *int_key ) ;
   void (*move_forward)(zend_object_iterator *iter ) ;
   void (*rewind)(zend_object_iterator *iter ) ;
   void (*invalidate_current)(zend_object_iterator *iter ) ;
};
typedef struct _zend_object_iterator_funcs zend_object_iterator_funcs;
struct _zend_object_iterator {
   void *data ;
   zend_object_iterator_funcs *funcs ;
   ulong index ;
};
struct _zend_class_iterator_funcs {
   zend_object_iterator_funcs *funcs ;
   union _zend_function *zf_new_iterator ;
   union _zend_function *zf_valid ;
   union _zend_function *zf_current ;
   union _zend_function *zf_key ;
   union _zend_function *zf_next ;
   union _zend_function *zf_rewind ;
};
typedef struct _zend_class_iterator_funcs zend_class_iterator_funcs;
struct _zend_serialize_data;
struct _zend_serialize_data;
struct _zend_serialize_data;
struct _zend_unserialize_data;
struct _zend_unserialize_data;
struct _zend_unserialize_data;
typedef struct _zend_serialize_data zend_serialize_data;
typedef struct _zend_unserialize_data zend_unserialize_data;
struct _zend_trait_method_reference {
   char const   *method_name ;
   unsigned int mname_len ;
   zend_class_entry *ce ;
   char const   *class_name ;
   unsigned int cname_len ;
};
typedef struct _zend_trait_method_reference zend_trait_method_reference;
struct _zend_trait_precedence {
   zend_trait_method_reference *trait_method ;
   zend_class_entry **exclude_from_classes ;
   union _zend_function *function ;
};
typedef struct _zend_trait_precedence zend_trait_precedence;
struct _zend_trait_alias {
   zend_trait_method_reference *trait_method ;
   char const   *alias ;
   unsigned int alias_len ;
   zend_uint modifiers ;
   union _zend_function *function ;
};
typedef struct _zend_trait_alias zend_trait_alias;
struct __anonstruct_user_36 {
   char const   *filename ;
   zend_uint line_start ;
   zend_uint line_end ;
   char const   *doc_comment ;
   zend_uint doc_comment_len ;
};
struct _zend_function_entry;
struct _zend_function_entry;
struct _zend_module_entry;
struct _zend_module_entry;
struct __anonstruct_internal_37 {
   struct _zend_function_entry  const  *builtin_functions ;
   struct _zend_module_entry *module ;
};
union __anonunion_info_35 {
   struct __anonstruct_user_36 user ;
   struct __anonstruct_internal_37 internal ;
};
struct _zend_class_entry {
   char type ;
   char const   *name ;
   zend_uint name_length ;
   struct _zend_class_entry *parent ;
   int refcount ;
   zend_uint ce_flags ;
   HashTable function_table ;
   HashTable properties_info ;
   zval **default_properties_table ;
   zval **default_static_members_table ;
   zval **static_members_table ;
   HashTable constants_table ;
   int default_properties_count ;
   int default_static_members_count ;
   union _zend_function *constructor ;
   union _zend_function *destructor ;
   union _zend_function *clone ;
   union _zend_function *__get ;
   union _zend_function *__set ;
   union _zend_function *__unset ;
   union _zend_function *__isset ;
   union _zend_function *__call ;
   union _zend_function *__callstatic ;
   union _zend_function *__tostring ;
   union _zend_function *serialize_func ;
   union _zend_function *unserialize_func ;
   zend_class_iterator_funcs iterator_funcs ;
   zend_object_value (*create_object)(zend_class_entry *class_type ) ;
   zend_object_iterator *(*get_iterator)(zend_class_entry *ce , zval *object ,
                                         int by_ref ) ;
   int (*interface_gets_implemented)(zend_class_entry *iface ,
                                     zend_class_entry *class_type ) ;
   union _zend_function *(*get_static_method)(zend_class_entry *ce ,
                                              char *method , int method_len ) ;
   int (*serialize)(zval *object , unsigned char **buffer , zend_uint *buf_len ,
                    zend_serialize_data *data ) ;
   int (*unserialize)(zval **object , zend_class_entry *ce ,
                      unsigned char const   *buf , zend_uint buf_len ,
                      zend_unserialize_data *data ) ;
   zend_class_entry **interfaces ;
   zend_uint num_interfaces ;
   zend_class_entry **traits ;
   zend_uint num_traits ;
   zend_trait_alias **trait_aliases ;
   zend_trait_precedence **trait_precedences ;
   union __anonunion_info_35 info ;
};
enum __anonenum_zend_stream_type_38 {
    ZEND_HANDLE_FILENAME = 0,
    ZEND_HANDLE_FD = 1,
    ZEND_HANDLE_FP = 2,
    ZEND_HANDLE_STREAM = 3,
    ZEND_HANDLE_MAPPED = 4
} ;
typedef enum __anonenum_zend_stream_type_38 zend_stream_type;
struct _zend_mmap {
   size_t len ;
   size_t pos ;
   void *map ;
   char *buf ;
   void *old_handle ;
   void (*old_closer)(void *handle ) ;
};
typedef struct _zend_mmap zend_mmap;
struct _zend_stream {
   void *handle ;
   int isatty ;
   zend_mmap mmap ;
   size_t (*reader)(void *handle , char *buf , size_t len ) ;
   size_t (*fsizer)(void *handle ) ;
   void (*closer)(void *handle ) ;
};
typedef struct _zend_stream zend_stream;
union __anonunion_handle_39 {
   int fd ;
   FILE *fp ;
   zend_stream stream ;
};
struct _zend_file_handle {
   zend_stream_type type ;
   char const   *filename ;
   char *opened_path ;
   union __anonunion_handle_39 handle ;
   zend_bool free_filename ;
};
typedef struct _zend_file_handle zend_file_handle;
union __anonunion_u_66 {
   zval *pz ;
   zend_object_handlers const   *handlers ;
};
struct _gc_root_buffer {
   struct _gc_root_buffer *prev ;
   struct _gc_root_buffer *next ;
   zend_object_handle handle ;
   union __anonunion_u_66 u ;
};
typedef struct _gc_root_buffer gc_root_buffer;
struct _zval_gc_info;
union __anonunion_u_67 {
   gc_root_buffer *buffered ;
   struct _zval_gc_info *next ;
};
struct _zval_gc_info {
   zval z ;
   union __anonunion_u_67 u ;
};
typedef struct _zval_gc_info zval_gc_info;
enum __anonenum_zend_error_handling_t_68 {
    EH_NORMAL = 0,
    EH_SUPPRESS = 1,
    EH_THROW = 2
} ;
typedef enum __anonenum_zend_error_handling_t_68 zend_error_handling_t;
struct _zend_op_array;
struct _zend_op_array;
typedef struct _zend_op_array zend_op_array;
struct _zend_op;
struct _zend_op;
typedef struct _zend_op zend_op;
struct _zend_compiler_context {
   zend_uint opcodes_size ;
   int vars_size ;
   int literals_size ;
   int current_brk_cont ;
   int backpatch_count ;
   HashTable *labels ;
};
typedef struct _zend_compiler_context zend_compiler_context;
struct _zend_literal {
   zval constant ;
   zend_ulong hash_value ;
   zend_uint cache_slot ;
};
typedef struct _zend_literal zend_literal;
union _znode_op {
   zend_uint constant ;
   zend_uint var ;
   zend_uint num ;
   zend_ulong hash ;
   zend_uint opline_num ;
   zend_op *jmp_addr ;
   zval *zv ;
   zend_literal *literal ;
   void *ptr ;
};
typedef union _znode_op znode_op;
union __anonunion_u_70 {
   znode_op op ;
   zval constant ;
   zend_op_array *op_array ;
};
struct _znode {
   int op_type ;
   union __anonunion_u_70 u ;
   zend_uint EA ;
};
typedef struct _znode znode;
struct _zend_execute_data;
struct _zend_execute_data;
typedef struct _zend_execute_data zend_execute_data;
struct _zend_op {
   int (*handler)(zend_execute_data *execute_data ) ;
   znode_op op1 ;
   znode_op op2 ;
   znode_op result ;
   ulong extended_value ;
   uint lineno ;
   zend_uchar opcode ;
   zend_uchar op1_type ;
   zend_uchar op2_type ;
   zend_uchar result_type ;
};
struct _zend_brk_cont_element {
   int start ;
   int cont ;
   int brk ;
   int parent ;
};
typedef struct _zend_brk_cont_element zend_brk_cont_element;
struct _zend_label {
   int brk_cont ;
   zend_uint opline_num ;
};
typedef struct _zend_label zend_label;
struct _zend_try_catch_element {
   zend_uint try_op ;
   zend_uint catch_op ;
};
typedef struct _zend_try_catch_element zend_try_catch_element;
struct _zend_property_info {
   zend_uint flags ;
   char const   *name ;
   int name_length ;
   ulong h ;
   int offset ;
   char const   *doc_comment ;
   int doc_comment_len ;
   zend_class_entry *ce ;
};
typedef struct _zend_property_info zend_property_info;
struct _zend_arg_info {
   char const   *name ;
   zend_uint name_len ;
   char const   *class_name ;
   zend_uint class_name_len ;
   zend_uchar type_hint ;
   zend_bool allow_null ;
   zend_bool pass_by_reference ;
};
typedef struct _zend_arg_info zend_arg_info;
struct _zend_compiled_variable {
   char const   *name ;
   int name_len ;
   ulong hash_value ;
};
typedef struct _zend_compiled_variable zend_compiled_variable;
struct _zend_op_array {
   zend_uchar type ;
   char const   *function_name ;
   zend_class_entry *scope ;
   zend_uint fn_flags ;
   union _zend_function *prototype ;
   zend_uint num_args ;
   zend_uint required_num_args ;
   zend_arg_info *arg_info ;
   zend_uint *refcount ;
   zend_op *opcodes ;
   zend_uint last ;
   zend_compiled_variable *vars ;
   int last_var ;
   zend_uint T ;
   zend_brk_cont_element *brk_cont_array ;
   int last_brk_cont ;
   zend_try_catch_element *try_catch_array ;
   int last_try_catch ;
   HashTable *static_variables ;
   zend_uint this_var ;
   char const   *filename ;
   zend_uint line_start ;
   zend_uint line_end ;
   char const   *doc_comment ;
   zend_uint doc_comment_len ;
   zend_uint early_binding ;
   zend_literal *literals ;
   int last_literal ;
   void **run_time_cache ;
   int last_cache_slot ;
   void *reserved[4] ;
};
struct _zend_internal_function {
   zend_uchar type ;
   char const   *function_name ;
   zend_class_entry *scope ;
   zend_uint fn_flags ;
   union _zend_function *prototype ;
   zend_uint num_args ;
   zend_uint required_num_args ;
   zend_arg_info *arg_info ;
   void (*handler)(int ht , zval *return_value , zval **return_value_ptr ,
                   zval *this_ptr , int return_value_used ) ;
   struct _zend_module_entry *module ;
};
typedef struct _zend_internal_function zend_internal_function;
struct __anonstruct_common_71 {
   zend_uchar type ;
   char const   *function_name ;
   zend_class_entry *scope ;
   zend_uint fn_flags ;
   union _zend_function *prototype ;
   zend_uint num_args ;
   zend_uint required_num_args ;
   zend_arg_info *arg_info ;
};
union _zend_function {
   zend_uchar type ;
   struct __anonstruct_common_71 common ;
   zend_op_array op_array ;
   zend_internal_function internal_function ;
};
typedef union _zend_function zend_function;
struct _zend_function_state {
   zend_function *function ;
   void **arguments ;
};
typedef struct _zend_function_state zend_function_state;
struct _zend_switch_entry {
   znode cond ;
   int default_case ;
   int control_var ;
};
typedef struct _zend_switch_entry zend_switch_entry;
struct _list_llist_element {
   znode var ;
   zend_llist dimensions ;
   znode value ;
};
typedef struct _list_llist_element list_llist_element;
union _temp_variable;
union _temp_variable;
union _temp_variable;
struct _zend_execute_data {
   struct _zend_op *opline ;
   zend_function_state function_state ;
   zend_function *fbc ;
   zend_class_entry *called_scope ;
   zend_op_array *op_array ;
   zval *object ;
   union _temp_variable *Ts ;
   zval ***CVs ;
   HashTable *symbol_table ;
   struct _zend_execute_data *prev_execute_data ;
   zval *old_error_reporting ;
   zend_bool nested ;
   zval **original_return_value ;
   zend_class_entry *current_scope ;
   zend_class_entry *current_called_scope ;
   zval *current_this ;
   zval *current_object ;
};
typedef long __jmp_buf[8];
struct __jmp_buf_tag {
   __jmp_buf __jmpbuf ;
   int __mask_was_saved ;
   __sigset_t __saved_mask ;
};
typedef struct __jmp_buf_tag jmp_buf[1];
struct _zend_compiler_globals;
struct _zend_compiler_globals;
struct _zend_executor_globals;
struct _zend_executor_globals;
typedef struct _zend_executor_globals zend_executor_globals;
struct _zend_php_scanner_globals;
struct _zend_php_scanner_globals;
typedef struct _zend_php_scanner_globals zend_php_scanner_globals;
struct _zend_stack {
   int top ;
   int max ;
   void **elements ;
};
typedef struct _zend_stack zend_stack;
struct _zend_ptr_stack {
   int top ;
   int max ;
   void **elements ;
   void **top_element ;
   zend_bool persistent ;
};
typedef struct _zend_ptr_stack zend_ptr_stack;
struct _store_object {
   void *object ;
   void (*dtor)(void *object , zend_object_handle handle ) ;
   void (*free_storage)(void *object ) ;
   void (*clone)(void *object , void **object_clone ) ;
   zend_object_handlers const   *handlers ;
   zend_uint refcount ;
   gc_root_buffer *buffered ;
};
struct __anonstruct_free_list_72 {
   int next ;
};
union _store_bucket {
   struct _store_object obj ;
   struct __anonstruct_free_list_72 free_list ;
};
struct _zend_object_store_bucket {
   zend_bool destructor_called ;
   zend_bool valid ;
   union _store_bucket bucket ;
};
typedef struct _zend_object_store_bucket zend_object_store_bucket;
struct _zend_objects_store {
   zend_object_store_bucket *object_buckets ;
   zend_uint top ;
   zend_uint size ;
   int free_list_head ;
};
typedef struct _zend_objects_store zend_objects_store;
struct _zend_ini_entry;
struct _zend_ini_entry;
struct _zend_ini_entry;
typedef struct _zend_module_entry zend_module_entry;
struct _zend_module_dep;
struct _zend_module_dep;
struct _zend_module_entry {
   unsigned short size ;
   unsigned int zend_api ;
   unsigned char zend_debug ;
   unsigned char zts ;
   struct _zend_ini_entry  const  *ini_entry ;
   struct _zend_module_dep  const  *deps ;
   char const   *name ;
   struct _zend_function_entry  const  *functions ;
   int (*module_startup_func)(int type , int module_number ) ;
   int (*module_shutdown_func)(int type , int module_number ) ;
   int (*request_startup_func)(int type , int module_number ) ;
   int (*request_shutdown_func)(int type , int module_number ) ;
   void (*info_func)(zend_module_entry *zend_module ) ;
   char const   *version ;
   size_t globals_size ;
   void *globals_ptr ;
   void (*globals_ctor)(void *global ) ;
   void (*globals_dtor)(void *global ) ;
   int (*post_deactivate_func)(void) ;
   int module_started ;
   unsigned char type ;
   void *handle ;
   int module_number ;
   char const   *build_id ;
};
struct _zend_module_dep {
   char const   *name ;
   char const   *rel ;
   char const   *version ;
   unsigned char type ;
};
typedef unsigned short fpu_control_t;
struct _zend_encoding;
struct _zend_encoding;
typedef struct _zend_encoding zend_encoding;
struct _zend_declarables {
   zval ticks ;
};
typedef struct _zend_declarables zend_declarables;
struct _zend_vm_stack;
struct _zend_vm_stack;
typedef struct _zend_vm_stack *zend_vm_stack;
typedef struct _zend_ini_entry zend_ini_entry;
struct _zend_ini_parser_param;
struct _zend_ini_parser_param;
struct _zend_compiler_globals {
   zend_stack bp_stack ;
   zend_stack switch_cond_stack ;
   zend_stack foreach_copy_stack ;
   zend_stack object_stack ;
   zend_stack declare_stack ;
   zend_class_entry *active_class_entry ;
   zend_llist list_llist ;
   zend_llist dimension_llist ;
   zend_stack list_stack ;
   zend_stack function_call_stack ;
   char *compiled_filename ;
   int zend_lineno ;
   char *heredoc ;
   int heredoc_len ;
   zend_op_array *active_op_array ;
   HashTable *function_table ;
   HashTable *class_table ;
   HashTable filenames_table ;
   HashTable *auto_globals ;
   zend_bool parse_error ;
   zend_bool in_compilation ;
   zend_bool short_tags ;
   zend_bool asp_tags ;
   zend_declarables declarables ;
   zend_bool unclean_shutdown ;
   zend_bool ini_parser_unbuffered_errors ;
   zend_llist open_files ;
   long catch_begin ;
   struct _zend_ini_parser_param *ini_parser_param ;
   int interactive ;
   zend_uint start_lineno ;
   zend_bool increment_lineno ;
   znode implementing_class ;
   zend_uint access_type ;
   char *doc_comment ;
   zend_uint doc_comment_len ;
   zend_uint compiler_options ;
   zval *current_namespace ;
   HashTable *current_import ;
   zend_bool in_namespace ;
   zend_bool has_bracketed_namespaces ;
   zend_compiler_context context ;
   zend_stack context_stack ;
   char *interned_strings_start ;
   char *interned_strings_end ;
   char *interned_strings_top ;
   char *interned_strings_snapshot_top ;
   HashTable interned_strings ;
   zend_encoding const   **script_encoding_list ;
   size_t script_encoding_list_size ;
   zend_bool multibyte ;
   zend_bool detect_unicode ;
   zend_bool encoding_declared ;
};
struct _zend_executor_globals {
   zval **return_value_ptr_ptr ;
   zval uninitialized_zval ;
   zval *uninitialized_zval_ptr ;
   zval error_zval ;
   zval *error_zval_ptr ;
   zend_ptr_stack arg_types_stack ;
   HashTable *symtable_cache[32] ;
   HashTable **symtable_cache_limit ;
   HashTable **symtable_cache_ptr ;
   zend_op **opline_ptr ;
   HashTable *active_symbol_table ;
   HashTable symbol_table ;
   HashTable included_files ;
   jmp_buf *bailout ;
   int error_reporting ;
   int orig_error_reporting ;
   int exit_status ;
   zend_op_array *active_op_array ;
   HashTable *function_table ;
   HashTable *class_table ;
   HashTable *zend_constants ;
   zend_class_entry *scope ;
   zend_class_entry *called_scope ;
   zval *This ;
   long precision ;
   int ticks_count ;
   zend_bool in_execution ;
   HashTable *in_autoload ;
   zend_function *autoload_func ;
   zend_bool full_tables_cleanup ;
   zend_bool no_extensions ;
   HashTable regular_list ;
   HashTable persistent_list ;
   zend_vm_stack argument_stack ;
   int user_error_handler_error_reporting ;
   zval *user_error_handler ;
   zval *user_exception_handler ;
   zend_stack user_error_handlers_error_reporting ;
   zend_ptr_stack user_error_handlers ;
   zend_ptr_stack user_exception_handlers ;
   zend_error_handling_t error_handling ;
   zend_class_entry *exception_class ;
   int timeout_seconds ;
   int lambda_count ;
   HashTable *ini_directives ;
   HashTable *modified_ini_directives ;
   zend_ini_entry *error_reporting_ini_entry ;
   zend_objects_store objects_store ;
   zval *exception ;
   zval *prev_exception ;
   zend_op *opline_before_exception ;
   zend_op exception_op[3] ;
   struct _zend_execute_data *current_execute_data ;
   struct _zend_module_entry *current_module ;
   zend_property_info std_property_info ;
   zend_bool active ;
   zend_op *start_op ;
   void *saved_fpu_cw_ptr ;
   fpu_control_t saved_fpu_cw ;
   void *reserved[4] ;
};
struct _zend_php_scanner_globals {
   zend_file_handle *yy_in ;
   zend_file_handle *yy_out ;
   unsigned int yy_leng ;
   unsigned char *yy_start ;
   unsigned char *yy_text ;
   unsigned char *yy_cursor ;
   unsigned char *yy_marker ;
   unsigned char *yy_limit ;
   int yy_state ;
   zend_stack state_stack ;
   unsigned char *script_org ;
   size_t script_org_size ;
   unsigned char *script_filtered ;
   size_t script_filtered_size ;
   size_t (*input_filter)(unsigned char **str , size_t *str_length ,
                          unsigned char const   *buf , size_t length ) ;
   size_t (*output_filter)(unsigned char **str , size_t *str_length ,
                           unsigned char const   *buf , size_t length ) ;
   zend_encoding const   *script_encoding ;
};
struct _zend_auto_global {
   char const   *name ;
   uint name_len ;
   zend_bool (*auto_global_callback)(char const   *name , uint name_len ) ;
   zend_bool jit ;
   zend_bool armed ;
};
typedef struct _zend_auto_global zend_auto_global;
struct _zend_constant {
   zval value ;
   int flags ;
   char *name ;
   uint name_len ;
   int module_number ;
};
typedef struct _zend_constant zend_constant;
struct __anonstruct_var_73 {
   zval **ptr_ptr ;
   zval *ptr ;
   zend_bool fcall_returned_reference ;
};
struct __anonstruct_str_offset_74 {
   zval **ptr_ptr ;
   zval *str ;
   zend_uint offset ;
};
struct __anonstruct_fe_75 {
   zval **ptr_ptr ;
   zval *ptr ;
   HashPointer fe_pos ;
};
union _temp_variable {
   zval tmp_var ;
   struct __anonstruct_var_73 var ;
   struct __anonstruct_str_offset_74 str_offset ;
   struct __anonstruct_fe_75 fe ;
   zend_class_entry *class_entry ;
};
typedef union _temp_variable temp_variable;
struct _zend_vm_stack {
   void **top ;
   void **end ;
   zend_vm_stack prev ;
};
struct _zend_function_entry {
   char const   *fname ;
   void (*handler)(int ht , zval *return_value , zval **return_value_ptr ,
                   zval *this_ptr , int return_value_used ) ;
   struct _zend_arg_info  const  *arg_info ;
   zend_uint num_args ;
   zend_uint flags ;
};
struct stat {
   __dev_t st_dev ;
   __ino_t st_ino ;
   __nlink_t st_nlink ;
   __mode_t st_mode ;
   __uid_t st_uid ;
   __gid_t st_gid ;
   int __pad0 ;
   __dev_t st_rdev ;
   __off_t st_size ;
   __blksize_t st_blksize ;
   __blkcnt_t st_blocks ;
   struct timespec st_atim ;
   struct timespec st_mtim ;
   struct timespec st_ctim ;
   __syscall_slong_t __glibc_reserved[3] ;
};
struct stat64 {
   __dev_t st_dev ;
   __ino64_t st_ino ;
   __nlink_t st_nlink ;
   __mode_t st_mode ;
   __uid_t st_uid ;
   __gid_t st_gid ;
   int __pad0 ;
   __dev_t st_rdev ;
   __off_t st_size ;
   __blksize_t st_blksize ;
   __blkcnt64_t st_blocks ;
   struct timespec st_atim ;
   struct timespec st_mtim ;
   struct timespec st_ctim ;
   __syscall_slong_t __glibc_reserved[3] ;
};
__inline extern  __attribute__((__nothrow__)) double __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atof)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atoi)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atol)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) long long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atoll)(char const   *__nptr )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) double ( __attribute__((__nonnull__(1),
__leaf__)) strtod)(char const   * __restrict  __nptr ,
                   char ** __restrict  __endptr ) ;
extern  __attribute__((__nothrow__)) long ( __attribute__((__nonnull__(1),
__leaf__)) strtol)(char const   * __restrict  __nptr ,
                   char ** __restrict  __endptr , int __base ) ;
extern  __attribute__((__nothrow__)) long long ( __attribute__((__nonnull__(1),
__leaf__)) strtoll)(char const   * __restrict  __nptr ,
                    char ** __restrict  __endptr , int __base ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atoi)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) atoi)(char const   *__nptr ) 
{ 
  long tmp ;

  {
  tmp = strtol((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)), 10);
  return ((int __attribute__((__gnu_inline__))  )((int )tmp));
}
}
__inline extern  __attribute__((__nothrow__)) long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atol)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) atol)(char const   *__nptr ) 
{ 
  long tmp ;

  {
  tmp = strtol((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)), 10);
  return ((long __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) long long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atoll)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern long long __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) atoll)(char const   *__nptr ) 
{ 
  long long tmp ;

  {
  tmp = strtoll((char const   */* __restrict  */)__nptr,
                (char **/* __restrict  */)((char **)((void *)0)), 10);
  return ((long long __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_major)(unsigned long long __dev )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_minor)(unsigned long long __dev )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) unsigned long long __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_makedev)(unsigned int __major ,
                                                                                                                                               unsigned int __minor )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_major)(unsigned long long __dev )  __attribute__((__const__)) ;
__inline extern unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_major)(unsigned long long __dev ) 
{ 


  {
  return ((unsigned int __attribute__((__gnu_inline__))  )(((__dev >> 8) & 4095ULL) | (unsigned long long )((unsigned int )(__dev >> 32) & 4294963200U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_minor)(unsigned long long __dev )  __attribute__((__const__)) ;
__inline extern unsigned int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_minor)(unsigned long long __dev ) 
{ 


  {
  return ((unsigned int __attribute__((__gnu_inline__))  )((__dev & 255ULL) | (unsigned long long )((unsigned int )(__dev >> 12) & 4294967040U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned long long __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_makedev)(unsigned int __major ,
                                                                                                                                               unsigned int __minor )  __attribute__((__const__)) ;
__inline extern unsigned long long __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) gnu_dev_makedev)(unsigned int __major ,
                                                                                                                 unsigned int __minor ) 
{ 


  {
  return ((unsigned long long __attribute__((__gnu_inline__))  )(((unsigned long long )((__minor & 255U) | ((__major & 4095U) << 8)) | ((unsigned long long )(__minor & 4294967040U) << 12)) | ((unsigned long long )(__major & 4294963200U) << 32)));
}
}
extern  __attribute__((__nothrow__)) void *( __attribute__((__warn_unused_result__,
__leaf__)) malloc)(size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__warn_unused_result__,
__leaf__)) realloc)(void *__ptr , size_t __size ) ;
extern  __attribute__((__nothrow__)) void ( __attribute__((__leaf__)) free)(void *__ptr ) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void ( __attribute__((__leaf__)) exit)(int __status ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) realpath)(char const   * __restrict  __name ,
                              char * __restrict  __resolved ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__nonnull__(1,2,5))) bsearch)(void const   *__key , void const   *__base ,
                              size_t __nmemb , size_t __size ,
                              int (*__compar)(void const   * , void const   * ) ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__nonnull__(1,2,5))) bsearch)(void const   *__key , void const   *__base ,
                              size_t __nmemb , size_t __size ,
                              int (*__compar)(void const   * , void const   * ) ) 
{ 
  size_t __l ;
  size_t __u ;
  size_t __idx ;
  void const   *__p ;
  int __comparison ;

  {
  __l = (size_t )0;
  __u = __nmemb;
  while (__l < __u) {
    __idx = (__l + __u) / 2UL;
    __p = (void const   *)((void *)((char const   *)__base + __idx * __size));
    __comparison = (*__compar)(__key, __p);
    if (__comparison < 0) {
      __u = __idx;
    } else
    if (__comparison > 0) {
      __l = __idx + 1UL;
    } else {
      return ((void __attribute__((__gnu_inline__))  *)((void *)__p));
    }
  }
  return ((void __attribute__((__gnu_inline__))  *)((void *)0));
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) wctomb)(char *__s , wchar_t __wchar ) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) mbstowcs)(wchar_t * __restrict  __dst ,
                                              char const   * __restrict  __src ,
                                              size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcstombs)(char * __restrict  __dst ,
                              wchar_t const   * __restrict  __src ,
                              size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__, __artificial__,
__always_inline__)) ptsname_r)(int __fd , char *__buf , size_t __buflen ) ;
__inline extern  __attribute__((__nothrow__)) double __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) atof)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern double __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) atof)(char const   *__nptr ) 
{ 
  double tmp ;

  {
  tmp = strtod((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)));
  return ((double __attribute__((__gnu_inline__))  )tmp);
}
}
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__leaf__)) __realpath_chk)(char const   * __restrict  __name ,
                           char * __restrict  __resolved , size_t __resolvedlen ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__leaf__)) __realpath_alias)(char const   * __restrict  __name ,
                             char * __restrict  __resolved )  __asm__("realpath")  ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) realpath)(char const   * __restrict  __name ,
                              char * __restrict  __resolved ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) realpath)(char const   * __restrict  __name ,
                              char * __restrict  __resolved ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__resolved, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__resolved, 1);
    tmp___0 = __realpath_chk(__name, __resolved, tmp);
    return ((char __attribute__((__gnu_inline__))  *)tmp___0);
  } else {

  }
  tmp___2 = __realpath_alias(__name, __resolved);
  return ((char __attribute__((__gnu_inline__))  *)tmp___2);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ptsname_r_chk)(int __fd , char *__buf , size_t __buflen ,
                            size_t __nreal ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ptsname_r_alias)(int __fd , char *__buf , size_t __buflen )  __asm__("ptsname_r")  ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ptsname_r_chk_warn)(int __fd , char *__buf , size_t __buflen ,
                                 size_t __nreal )  __asm__("__ptsname_r_chk") __attribute__((__warning__("ptsname_r called with buflen bigger than size of buf"))) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__, __artificial__,
__always_inline__)) ptsname_r)(int __fd , char *__buf , size_t __buflen ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__, __artificial__,
__always_inline__)) ptsname_r)(int __fd , char *__buf , size_t __buflen ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __ptsname_r_chk(__fd, __buf, __buflen, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__buflen > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __ptsname_r_chk_warn(__fd, __buf, __buflen, tmp___1);
      return ((int __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __ptsname_r_alias(__fd, __buf, __buflen);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __wctomb_chk)(char *__s , wchar_t __wchar , size_t __buflen ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __wctomb_alias)(char *__s , wchar_t __wchar )  __asm__("wctomb")  ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) wctomb)(char *__s , wchar_t __wchar ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) wctomb)(char *__s , wchar_t __wchar ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  unsigned long tmp___2 ;
  int tmp___3 ;

  {
  tmp___1 = __builtin_object_size((void *)__s, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp___2 = __builtin_object_size((void *)__s, 1);
    if (16UL > tmp___2) {
      tmp = __builtin_object_size((void *)__s, 1);
      tmp___0 = __wctomb_chk(__s, __wchar, tmp);
      return ((int __attribute__((__gnu_inline__))  )tmp___0);
    } else {

    }
  } else {

  }
  tmp___3 = __wctomb_alias(__s, __wchar);
  return ((int __attribute__((__gnu_inline__))  )tmp___3);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbstowcs_chk)(wchar_t * __restrict  __dst ,
                                                                                        char const   * __restrict  __src ,
                                                                                        size_t __len ,
                                                                                        size_t __dstlen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbstowcs_alias)(wchar_t * __restrict  __dst ,
                                                                                          char const   * __restrict  __src ,
                                                                                          size_t __len )  __asm__("mbstowcs")  ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __mbstowcs_chk_warn)(wchar_t * __restrict  __dst ,
                                                                                             char const   * __restrict  __src ,
                                                                                             size_t __len ,
                                                                                             size_t __dstlen )  __asm__("__mbstowcs_chk") __attribute__((__warning__("mbstowcs called with dst buffer smaller than len * sizeof (wchar_t)"))) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) mbstowcs)(wchar_t * __restrict  __dst ,
                                              char const   * __restrict  __src ,
                                              size_t __len ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) mbstowcs)(wchar_t * __restrict  __dst ,
                                              char const   * __restrict  __src ,
                                              size_t __len ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__dst, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dst, 1);
    tmp___0 = __mbstowcs_chk(__dst, __src, __len, tmp / sizeof(wchar_t ));
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__dst, 1);
    if (__len > tmp___3 / sizeof(wchar_t )) {
      tmp___1 = __builtin_object_size((void *)__dst, 1);
      tmp___2 = __mbstowcs_chk_warn(__dst, __src, __len,
                                    tmp___1 / sizeof(wchar_t ));
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __mbstowcs_alias(__dst, __src, __len);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcstombs_chk)(char * __restrict  __dst ,
                                                                                        wchar_t const   * __restrict  __src ,
                                                                                        size_t __len ,
                                                                                        size_t __dstlen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcstombs_alias)(char * __restrict  __dst ,
                                                                                          wchar_t const   * __restrict  __src ,
                                                                                          size_t __len )  __asm__("wcstombs")  ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __wcstombs_chk_warn)(char * __restrict  __dst ,
                                                                                             wchar_t const   * __restrict  __src ,
                                                                                             size_t __len ,
                                                                                             size_t __dstlen )  __asm__("__wcstombs_chk") __attribute__((__warning__("wcstombs called with dst buffer smaller than len"))) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcstombs)(char * __restrict  __dst ,
                              wchar_t const   * __restrict  __src ,
                              size_t __len ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) wcstombs)(char * __restrict  __dst ,
                              wchar_t const   * __restrict  __src ,
                              size_t __len ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__dst, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dst, 1);
    tmp___0 = __wcstombs_chk(__dst, __src, __len, tmp);
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__dst, 1);
    if (__len > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__dst, 1);
      tmp___2 = __wcstombs_chk_warn(__dst, __src, __len, tmp___1);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __wcstombs_alias(__dst, __src, __len);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memcpy)(void * __restrict  __dest ,
                            void const   * __restrict  __src , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memmove)(void *__dest , void const   *__src , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1),
__leaf__, __artificial__, __always_inline__)) memset)(void *__dest , int __ch ,
                                                      size_t __len ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2),
__leaf__)) memcmp)(void const   *__s1 , void const   *__s2 , size_t __n )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1),
__leaf__)) memchr)(void const   *__s , int __c , size_t __n )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcat)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncat)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2),
__leaf__)) strncmp)(char const   *__s1 , char const   *__s2 , size_t __n )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) mempcpy)(void * __restrict  __dest ,
                             void const   * __restrict  __src , size_t __len ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__nonnull__(1),
__leaf__)) strlen)(char const   *__s )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) bcopy)(void const   *__src , void *__dest , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) bzero)(void *__dest , size_t __len ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2),
__leaf__)) strcasecmp)(char const   *__s1 , char const   *__s2 )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __n ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c1(char const   *__s ,
                                                                     int __reject ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c1(char const   *__s ,
                                                                     int __reject ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if ((int const   )*(__s + __result) != 0) {
      if (! ((int const   )*(__s + __result) != (int const   )__reject)) {
        break;
      } else {

      }
    } else {
      break;
    }
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c2(char const   *__s ,
                                                                     int __reject1 ,
                                                                     int __reject2 ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c2(char const   *__s ,
                                                                     int __reject1 ,
                                                                     int __reject2 ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if ((int const   )*(__s + __result) != 0) {
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        if (! ((int const   )*(__s + __result) != (int const   )__reject2)) {
          break;
        } else {

        }
      } else {
        break;
      }
    } else {
      break;
    }
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c3(char const   *__s ,
                                                                     int __reject1 ,
                                                                     int __reject2 ,
                                                                     int __reject3 ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c3(char const   *__s ,
                                                                     int __reject1 ,
                                                                     int __reject2 ,
                                                                     int __reject3 ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if ((int const   )*(__s + __result) != 0) {
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          if (! ((int const   )*(__s + __result) != (int const   )__reject3)) {
            break;
          } else {

          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c1(char const   *__s ,
                                                                    int __accept ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c1(char const   *__s ,
                                                                    int __accept ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while ((int const   )*(__s + __result) == (int const   )__accept) {
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c2(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c2(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if (! ((int const   )*(__s + __result) == (int const   )__accept1)) {
      if (! ((int const   )*(__s + __result) == (int const   )__accept2)) {
        break;
      } else {

      }
    } else {

    }
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c3(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ,
                                                                    int __accept3 ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c3(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ,
                                                                    int __accept3 ) 
{ 
  size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if (! ((int const   )*(__s + __result) == (int const   )__accept1)) {
      if (! ((int const   )*(__s + __result) == (int const   )__accept2)) {
        if (! ((int const   )*(__s + __result) == (int const   )__accept3)) {
          break;
        } else {

        }
      } else {

      }
    } else {

    }
    __result ++;
  }
  return ((size_t __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strpbrk_c2(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strpbrk_c2(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ) 
{ 
  char *tmp ;

  {
  while (1) {
    if ((int const   )*__s != 0) {
      if ((int const   )*__s != (int const   )__accept1) {
        if (! ((int const   )*__s != (int const   )__accept2)) {
          break;
        } else {

        }
      } else {
        break;
      }
    } else {
      break;
    }
    __s ++;
  }
  if ((int const   )*__s == 0) {
    tmp = (char *)((void *)0);
  } else {
    tmp = (char *)((size_t )__s);
  }
  return ((char __attribute__((__gnu_inline__))  *)tmp);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strpbrk_c3(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ,
                                                                    int __accept3 ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strpbrk_c3(char const   *__s ,
                                                                    int __accept1 ,
                                                                    int __accept2 ,
                                                                    int __accept3 ) 
{ 
  char *tmp ;

  {
  while (1) {
    if ((int const   )*__s != 0) {
      if ((int const   )*__s != (int const   )__accept1) {
        if ((int const   )*__s != (int const   )__accept2) {
          if (! ((int const   )*__s != (int const   )__accept3)) {
            break;
          } else {

          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    __s ++;
  }
  if ((int const   )*__s == 0) {
    tmp = (char *)((void *)0);
  } else {
    tmp = (char *)((size_t )__s);
  }
  return ((char __attribute__((__gnu_inline__))  *)tmp);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strtok_r_1c(char *__s ,
                                                                     char __sep ,
                                                                     char **__nextp ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strtok_r_1c(char *__s ,
                                                                     char __sep ,
                                                                     char **__nextp ) 
{ 
  char *__result ;
  char *tmp ;
  char *tmp___0 ;

  {
  if ((unsigned long )__s == (unsigned long )((void *)0)) {
    __s = *__nextp;
  } else {

  }
  while ((int )*__s == (int )__sep) {
    __s ++;
  }
  __result = (char *)((void *)0);
  if ((int )*__s != 0) {
    tmp = __s;
    __s ++;
    __result = tmp;
    while ((int )*__s != 0) {
      tmp___0 = __s;
      __s ++;
      if ((int )*tmp___0 == (int )__sep) {
        *(__s + -1) = (char )'\000';
        break;
      } else {

      }
    }
  } else {

  }
  *__nextp = __s;
  return ((char __attribute__((__gnu_inline__))  *)__result);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strsep_1c(char **__s ,
                                                                   char __reject ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strsep_1c(char **__s ,
                                                                   char __reject ) 
{ 
  char *__retval ;
  char *tmp ;
  char *tmp___0 ;
  char *tmp___2 ;

  {
  __retval = *__s;
  if ((unsigned long )__retval != (unsigned long )((void *)0)) {
    tmp___2 = __builtin_strchr(__retval, (int )__reject);
    tmp___0 = tmp___2;
    *__s = tmp___0;
    if ((unsigned long )tmp___0 != (unsigned long )((void *)0)) {
      tmp = *__s;
      (*__s) ++;
      *tmp = (char )'\000';
    } else {

    }
  } else {

  }
  return ((char __attribute__((__gnu_inline__))  *)__retval);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strsep_2c(char **__s ,
                                                                   char __reject1 ,
                                                                   char __reject2 ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strsep_2c(char **__s ,
                                                                   char __reject1 ,
                                                                   char __reject2 ) 
{ 
  char *__retval ;
  char *__cp ;
  char *tmp ;

  {
  __retval = *__s;
  if ((unsigned long )__retval != (unsigned long )((void *)0)) {
    __cp = __retval;
    while (1) {
      if ((int )*__cp == 0) {
        __cp = (char *)((void *)0);
        break;
      } else {

      }
      if ((int )*__cp == (int )__reject1) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else
      if ((int )*__cp == (int )__reject2) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else {

      }
      __cp ++;
    }
    *__s = __cp;
  } else {

  }
  return ((char __attribute__((__gnu_inline__))  *)__retval);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strsep_3c(char **__s ,
                                                                   char __reject1 ,
                                                                   char __reject2 ,
                                                                   char __reject3 ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strsep_3c(char **__s ,
                                                                   char __reject1 ,
                                                                   char __reject2 ,
                                                                   char __reject3 ) 
{ 
  char *__retval ;
  char *__cp ;
  char *tmp ;

  {
  __retval = *__s;
  if ((unsigned long )__retval != (unsigned long )((void *)0)) {
    __cp = __retval;
    while (1) {
      if ((int )*__cp == 0) {
        __cp = (char *)((void *)0);
        break;
      } else {

      }
      if ((int )*__cp == (int )__reject1) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else
      if ((int )*__cp == (int )__reject2) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else
      if ((int )*__cp == (int )__reject3) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else {

      }
      __cp ++;
    }
    *__s = __cp;
  } else {

  }
  return ((char __attribute__((__gnu_inline__))  *)__retval);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memcpy)(void * __restrict  __dest ,
                            void const   * __restrict  __src , size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memcpy)(void * __restrict  __dest ,
                            void const   * __restrict  __src , size_t __len ) 
{ 
  unsigned long tmp ;
  void *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 0);
  tmp___0 = __builtin___memcpy_chk((void *)__dest, (void const   *)__src, __len,
                                   tmp);
  return ((void __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memmove)(void *__dest , void const   *__src , size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) memmove)(void *__dest , void const   *__src , size_t __len ) 
{ 
  unsigned long tmp ;
  void *tmp___0 ;

  {
  tmp = __builtin_object_size(__dest, 0);
  tmp___0 = __builtin___memmove_chk(__dest, __src, __len, tmp);
  return ((void __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) mempcpy)(void * __restrict  __dest ,
                             void const   * __restrict  __src , size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) mempcpy)(void * __restrict  __dest ,
                             void const   * __restrict  __src , size_t __len ) 
{ 
  unsigned long tmp ;
  void *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 0);
  tmp___0 = __builtin___mempcpy_chk((void *)__dest, (void const   *)__src,
                                    __len, tmp);
  return ((void __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1),
__leaf__, __artificial__, __always_inline__)) memset)(void *__dest , int __ch ,
                                                      size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1),
__leaf__, __artificial__, __always_inline__)) memset)(void *__dest , int __ch ,
                                                      size_t __len ) 
{ 
  unsigned long tmp ;
  void *tmp___0 ;

  {
  tmp = __builtin_object_size(__dest, 0);
  tmp___0 = __builtin___memset_chk(__dest, __ch, __len, tmp);
  return ((void __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) bcopy)(void const   *__src , void *__dest , size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) bcopy)(void const   *__src , void *__dest , size_t __len ) 
{ 
  unsigned long tmp ;

  {
  tmp = __builtin_object_size(__dest, 0);
  __builtin___memmove_chk(__dest, __src, __len, tmp);
  return;
}
}
__inline extern  __attribute__((__nothrow__)) void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) bzero)(void *__dest , size_t __len ) ;
__inline extern void __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) bzero)(void *__dest , size_t __len ) 
{ 
  unsigned long tmp ;

  {
  tmp = __builtin_object_size(__dest, 0);
  __builtin___memset_chk(__dest, '\000', __len, tmp);
  return;
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 1);
  tmp___0 = __builtin___strcpy_chk((char *)__dest, (char const   *)__src, tmp);
  return ((char __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpcpy)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 1);
  tmp___0 = __builtin___stpcpy_chk((char *)__dest, (char const   *)__src, tmp);
  return ((char __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 1);
  tmp___0 = __builtin___strncpy_chk((char *)__dest, (char const   *)__src,
                                    __len, tmp);
  return ((char __attribute__((__gnu_inline__))  *)tmp___0);
}
}
extern  __attribute__((__nothrow__)) char *( __attribute__((__leaf__)) __stpncpy_chk)(char *__dest ,
                                                                                      char const   *__src ,
                                                                                      size_t __n ,
                                                                                      size_t __destlen ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__leaf__)) __stpncpy_alias)(char *__dest ,
                                                                                        char const   *__src ,
                                                                                        size_t __n )  __asm__("stpncpy")  ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __n ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) stpncpy)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __n ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___3 ;

  {
  tmp___1 = __builtin_object_size((void *)__dest, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__dest, 1);
    tmp___0 = __stpncpy_chk((char *)__dest, (char const   *)__src, __n, tmp);
    return ((char __attribute__((__gnu_inline__))  *)tmp___0);
  } else {

  }
  tmp___3 = __stpncpy_alias((char *)__dest, (char const   *)__src, __n);
  return ((char __attribute__((__gnu_inline__))  *)tmp___3);
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcat)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strcat)(char * __restrict  __dest ,
                            char const   * __restrict  __src ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 1);
  tmp___0 = __builtin___strcat_chk((char *)__dest, (char const   *)__src, tmp);
  return ((char __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncat)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__nonnull__(1,2),
__leaf__, __artificial__,
__always_inline__)) strncat)(char * __restrict  __dest ,
                             char const   * __restrict  __src , size_t __len ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__dest, 1);
  tmp___0 = __builtin___strncat_chk((char *)__dest, (char const   *)__src,
                                    __len, tmp);
  return ((char __attribute__((__gnu_inline__))  *)tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbit)(double __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitf)(float __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitl)(long double __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitf)(float __x )  __attribute__((__const__)) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitf)(float __x ) 
{ 
  int __m ;

  {
  __asm__  ("pmovmskb %1, %0": "=r" (__m): "x" (__x));
  return ((int __attribute__((__gnu_inline__))  )((__m & 8) != 0));
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbit)(double __x )  __attribute__((__const__)) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbit)(double __x ) 
{ 
  int __m ;

  {
  __asm__  ("pmovmskb %1, %0": "=r" (__m): "x" (__x));
  return ((int __attribute__((__gnu_inline__))  )((__m & 128) != 0));
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitl)(long double __x )  __attribute__((__const__)) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__always_inline__)) __signbitl)(long double __x ) 
{ 
  union __anonunion___u_23 __u ;

  {
  __u.__l = __x;
  return ((int __attribute__((__gnu_inline__))  )((__u.__i[2] & 32768) != 0));
}
}
extern int __uflow(_IO_FILE * ) ;
extern int __overflow(_IO_FILE * , int  ) ;
extern int _IO_getc(_IO_FILE *__fp ) ;
extern int _IO_putc(int __c , _IO_FILE *__fp ) ;
extern struct _IO_FILE *stdin ;
extern struct _IO_FILE *stdout ;
extern struct _IO_FILE *stderr ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) fprintf)(FILE * __restrict  __stream ,
                             char const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) printf)(char const   * __restrict  __fmt  , ...) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) sprintf)(char * __restrict  __s ,
                                             char const   * __restrict  __fmt 
                                             , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vfprintf)(FILE * __restrict  __stream ,
                              char const   * __restrict  __fmt ,
                              __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vprintf)(char const   * __restrict  __fmt ,
                             __gnuc_va_list __ap ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) vsprintf)(char * __restrict  __s ,
                                              char const   * __restrict  __fmt ,
                                              __gnuc_va_list __ap ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) snprintf)(char * __restrict  __s ,
                              size_t __n , char const   * __restrict  __fmt 
                              , ...) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) vsnprintf)(char * __restrict  __s ,
                               size_t __n , char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) vasprintf)(char ** __restrict  __ptr ,
                               char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) __asprintf)(char ** __restrict  __ptr ,
                                char const   * __restrict  __fmt  , ...) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) asprintf)(char ** __restrict  __ptr ,
                              char const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vdprintf)(int __fd , char const   * __restrict  __fmt ,
                              __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) dprintf)(int __fd , char const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  getchar(void) ;
__inline extern int __attribute__((__gnu_inline__))  getc_unlocked(FILE *__fp ) ;
__inline extern int __attribute__((__gnu_inline__))  getchar_unlocked(void) ;
__inline extern int __attribute__((__gnu_inline__))  fgetc_unlocked(FILE *__fp ) ;
__inline extern int __attribute__((__gnu_inline__))  putchar(int __c ) ;
__inline extern int __attribute__((__gnu_inline__))  fputc_unlocked(int __c ,
                                                                    FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  putc_unlocked(int __c ,
                                                                   FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  putchar_unlocked(int __c ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) fgets)(char * __restrict  __s , int __n ,
                                           FILE * __restrict  __stream ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fgets_unlocked)(char * __restrict  __s ,
                                    int __n , FILE * __restrict  __stream ) ;
extern __ssize_t ( __attribute__((__warn_unused_result__)) __getdelim)(char ** __restrict  __lineptr ,
                                                                       size_t * __restrict  __n ,
                                                                       int __delimiter ,
                                                                       FILE * __restrict  __stream ) ;
__inline extern __ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__)) getline)(char ** __restrict  __lineptr ,
                                                                                                              size_t * __restrict  __n ,
                                                                                                              FILE * __restrict  __stream ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) fread)(void * __restrict  __ptr ,
                                           size_t __size , size_t __n ,
                                           FILE * __restrict  __stream ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fread_unlocked)(void * __restrict  __ptr ,
                                    size_t __size , size_t __n ,
                                    FILE * __restrict  __stream ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) feof_unlocked)(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) ferror_unlocked)(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) obstack_printf)(struct obstack * __restrict  __obstack ,
                                    char const   * __restrict  __fmt  , ...) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) obstack_vprintf)(struct obstack * __restrict  __obstack ,
                                     char const   * __restrict  __fmt ,
                                     __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  getchar(void) 
{ 
  int tmp ;

  {
  tmp = _IO_getc(stdin);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  fgetc_unlocked(FILE *__fp ) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  tmp___3 = __builtin_expect((long )((unsigned long )__fp->_IO_read_ptr >= (unsigned long )__fp->_IO_read_end),
                             0L);
  if (tmp___3) {
    tmp___0 = __uflow(__fp);
    tmp___2 = tmp___0;
  } else {
    tmp___1 = __fp->_IO_read_ptr;
    (__fp->_IO_read_ptr) ++;
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
__inline extern int __attribute__((__gnu_inline__))  getc_unlocked(FILE *__fp ) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  tmp___3 = __builtin_expect((long )((unsigned long )__fp->_IO_read_ptr >= (unsigned long )__fp->_IO_read_end),
                             0L);
  if (tmp___3) {
    tmp___0 = __uflow(__fp);
    tmp___2 = tmp___0;
  } else {
    tmp___1 = __fp->_IO_read_ptr;
    (__fp->_IO_read_ptr) ++;
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
__inline extern int __attribute__((__gnu_inline__))  getchar_unlocked(void) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  tmp___3 = __builtin_expect((long )((unsigned long )stdin->_IO_read_ptr >= (unsigned long )stdin->_IO_read_end),
                             0L);
  if (tmp___3) {
    tmp___0 = __uflow(stdin);
    tmp___2 = tmp___0;
  } else {
    tmp___1 = stdin->_IO_read_ptr;
    (stdin->_IO_read_ptr) ++;
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
__inline extern int __attribute__((__gnu_inline__))  putchar(int __c ) 
{ 
  int tmp ;

  {
  tmp = _IO_putc(__c, stdout);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  fputc_unlocked(int __c ,
                                                                    FILE *__stream ) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  tmp___4 = __builtin_expect((long )((unsigned long )__stream->_IO_write_ptr >= (unsigned long )__stream->_IO_write_end),
                             0L);
  if (tmp___4) {
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    tmp___3 = tmp___0;
  } else {
    tmp___1 = __stream->_IO_write_ptr;
    (__stream->_IO_write_ptr) ++;
    tmp___2 = (char )__c;
    *tmp___1 = tmp___2;
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___3);
}
}
__inline extern int __attribute__((__gnu_inline__))  putc_unlocked(int __c ,
                                                                   FILE *__stream ) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  tmp___4 = __builtin_expect((long )((unsigned long )__stream->_IO_write_ptr >= (unsigned long )__stream->_IO_write_end),
                             0L);
  if (tmp___4) {
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    tmp___3 = tmp___0;
  } else {
    tmp___1 = __stream->_IO_write_ptr;
    (__stream->_IO_write_ptr) ++;
    tmp___2 = (char )__c;
    *tmp___1 = tmp___2;
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___3);
}
}
__inline extern int __attribute__((__gnu_inline__))  putchar_unlocked(int __c ) 
{ 
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  tmp___4 = __builtin_expect((long )((unsigned long )stdout->_IO_write_ptr >= (unsigned long )stdout->_IO_write_end),
                             0L);
  if (tmp___4) {
    tmp___0 = __overflow(stdout, (int )((unsigned char )__c));
    tmp___3 = tmp___0;
  } else {
    tmp___1 = stdout->_IO_write_ptr;
    (stdout->_IO_write_ptr) ++;
    tmp___2 = (char )__c;
    *tmp___1 = tmp___2;
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___3);
}
}
__inline extern __ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__)) getline)(char ** __restrict  __lineptr ,
                                                                                                              size_t * __restrict  __n ,
                                                                                                              FILE * __restrict  __stream ) 
{ 
  __ssize_t tmp ;

  {
  tmp = __getdelim(__lineptr, __n, '\n', __stream);
  return ((__ssize_t __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) feof_unlocked)(FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) feof_unlocked)(FILE *__stream ) 
{ 


  {
  return ((int __attribute__((__gnu_inline__))  )((__stream->_flags & 16) != 0));
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) ferror_unlocked)(FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__)) ferror_unlocked)(FILE *__stream ) 
{ 


  {
  return ((int __attribute__((__gnu_inline__))  )((__stream->_flags & 32) != 0));
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) sprintf)(char * __restrict  __s ,
                                             char const   * __restrict  __fmt 
                                             , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) sprintf)(char * __restrict  __s ,
                                             char const   * __restrict  __fmt 
                                             , ...) 
{ 
  unsigned long tmp ;
  int tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__s, 1);
  tmp___0 = __builtin___sprintf_chk((char *)__s, 1, tmp, (char const   *)__fmt,
                                    __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) vsprintf)(char * __restrict  __s ,
                                              char const   * __restrict  __fmt ,
                                              __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) vsprintf)(char * __restrict  __s ,
                                              char const   * __restrict  __fmt ,
                                              __gnuc_va_list __ap ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__s, 1);
  tmp___0 = __builtin___vsprintf_chk((char *)__s, 1, tmp, (char const   *)__fmt,
                                     __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) snprintf)(char * __restrict  __s ,
                              size_t __n , char const   * __restrict  __fmt 
                              , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) snprintf)(char * __restrict  __s ,
                              size_t __n , char const   * __restrict  __fmt 
                              , ...) 
{ 
  unsigned long tmp ;
  int tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__s, 1);
  tmp___0 = __builtin___snprintf_chk((char *)__s, __n, 1, tmp,
                                     (char const   *)__fmt,
                                     __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) vsnprintf)(char * __restrict  __s ,
                               size_t __n , char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) vsnprintf)(char * __restrict  __s ,
                               size_t __n , char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;

  {
  tmp = __builtin_object_size((void *)__s, 1);
  tmp___0 = __builtin___vsnprintf_chk((char *)__s, __n, 1, tmp,
                                      (char const   *)__fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
extern int __fprintf_chk(FILE * __restrict  __stream , int __flag ,
                         char const   * __restrict  __format  , ...) ;
extern int __printf_chk(int __flag , char const   * __restrict  __format  , ...) ;
extern int __vfprintf_chk(FILE * __restrict  __stream , int __flag ,
                          char const   * __restrict  __format ,
                          __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) fprintf)(FILE * __restrict  __stream ,
                             char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __fprintf_chk(__stream, 1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) printf)(char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __printf_chk(1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vprintf)(char const   * __restrict  __fmt ,
                             __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __vfprintf_chk((FILE */* __restrict  */)stdout, 1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vfprintf)(FILE * __restrict  __stream ,
                              char const   * __restrict  __fmt ,
                              __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __vfprintf_chk(__stream, 1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
extern int __dprintf_chk(int __fd , int __flag ,
                         char const   * __restrict  __fmt  , ...) ;
extern int __vdprintf_chk(int __fd , int __flag ,
                          char const   * __restrict  __fmt ,
                          __gnuc_va_list __arg ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) dprintf)(int __fd , char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __dprintf_chk(__fd, 1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__artificial__,
__always_inline__)) vdprintf)(int __fd , char const   * __restrict  __fmt ,
                              __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __vdprintf_chk(__fd, 1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __asprintf_chk)(char ** __restrict  __ptr , int __flag ,
                           char const   * __restrict  __fmt  , ...) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __vasprintf_chk)(char ** __restrict  __ptr , int __flag ,
                            char const   * __restrict  __fmt ,
                            __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__leaf__)) __obstack_printf_chk)(struct obstack * __restrict  __obstack ,
                                                                                           int __flag ,
                                                                                           char const   * __restrict  __format 
                                                                                           , ...) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__leaf__)) __obstack_vprintf_chk)(struct obstack * __restrict  __obstack ,
                                                                                            int __flag ,
                                                                                            char const   * __restrict  __format ,
                                                                                            __gnuc_va_list __args ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) asprintf)(char ** __restrict  __ptr ,
                              char const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) asprintf)(char ** __restrict  __ptr ,
                              char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __asprintf_chk(__ptr, 1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) __asprintf)(char ** __restrict  __ptr ,
                                char const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) __asprintf)(char ** __restrict  __ptr ,
                                char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __asprintf_chk(__ptr, 1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) obstack_printf)(struct obstack * __restrict  __obstack ,
                                    char const   * __restrict  __fmt  , ...) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) obstack_printf)(struct obstack * __restrict  __obstack ,
                                    char const   * __restrict  __fmt  , ...) 
{ 
  int tmp ;

  {
  tmp = __obstack_printf_chk(__obstack, 1, __fmt, __builtin_va_arg_pack());
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) vasprintf)(char ** __restrict  __ptr ,
                               char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) vasprintf)(char ** __restrict  __ptr ,
                               char const   * __restrict  __fmt ,
                               __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __vasprintf_chk(__ptr, 1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) obstack_vprintf)(struct obstack * __restrict  __obstack ,
                                     char const   * __restrict  __fmt ,
                                     __gnuc_va_list __ap ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__,
__always_inline__)) obstack_vprintf)(struct obstack * __restrict  __obstack ,
                                     char const   * __restrict  __fmt ,
                                     __gnuc_va_list __ap ) 
{ 
  int tmp ;

  {
  tmp = __obstack_vprintf_chk(__obstack, 1, __fmt, __ap);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
extern char *( __attribute__((__warn_unused_result__)) __fgets_chk)(char * __restrict  __s ,
                                                                    size_t __size ,
                                                                    int __n ,
                                                                    FILE * __restrict  __stream ) ;
extern char *( __attribute__((__warn_unused_result__)) __fgets_alias)(char * __restrict  __s ,
                                                                      int __n ,
                                                                      FILE * __restrict  __stream )  __asm__("fgets")  ;
extern char *( __attribute__((__warn_unused_result__)) __fgets_chk_warn)(char * __restrict  __s ,
                                                                         size_t __size ,
                                                                         int __n ,
                                                                         FILE * __restrict  __stream )  __asm__("__fgets_chk") __attribute__((__warning__("fgets called with bigger size than length of destination buffer"))) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) fgets)(char * __restrict  __s , int __n ,
                                           FILE * __restrict  __stream ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  char *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__s, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s, 1);
    tmp___0 = __fgets_chk(__s, tmp, __n, __stream);
    return ((char __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__s, 1);
    if ((size_t )__n > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__s, 1);
      tmp___2 = __fgets_chk_warn(__s, tmp___1, __n, __stream);
      return ((char __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __fgets_alias(__s, __n, __stream);
  return ((char __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern size_t ( __attribute__((__warn_unused_result__)) __fread_chk)(void * __restrict  __ptr ,
                                                                     size_t __ptrlen ,
                                                                     size_t __size ,
                                                                     size_t __n ,
                                                                     FILE * __restrict  __stream ) ;
extern size_t ( __attribute__((__warn_unused_result__)) __fread_alias)(void * __restrict  __ptr ,
                                                                       size_t __size ,
                                                                       size_t __n ,
                                                                       FILE * __restrict  __stream )  __asm__("fread")  ;
extern size_t ( __attribute__((__warn_unused_result__)) __fread_chk_warn)(void * __restrict  __ptr ,
                                                                          size_t __ptrlen ,
                                                                          size_t __size ,
                                                                          size_t __n ,
                                                                          FILE * __restrict  __stream )  __asm__("__fread_chk") __attribute__((__warning__("fread called with bigger size * nmemb than length of destination buffer"))) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) fread)(void * __restrict  __ptr ,
                                           size_t __size , size_t __n ,
                                           FILE * __restrict  __stream ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__ptr, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__ptr, 0);
    tmp___0 = __fread_chk(__ptr, tmp, __size, __n, __stream);
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__ptr, 0);
    if (__size * __n > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__ptr, 0);
      tmp___2 = __fread_chk_warn(__ptr, tmp___1, __size, __n, __stream);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __fread_alias(__ptr, __size, __n, __stream);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern char *( __attribute__((__warn_unused_result__)) __fgets_unlocked_chk)(char * __restrict  __s ,
                                                                             size_t __size ,
                                                                             int __n ,
                                                                             FILE * __restrict  __stream ) ;
extern char *( __attribute__((__warn_unused_result__)) __fgets_unlocked_alias)(char * __restrict  __s ,
                                                                               int __n ,
                                                                               FILE * __restrict  __stream )  __asm__("fgets_unlocked")  ;
extern char *( __attribute__((__warn_unused_result__)) __fgets_unlocked_chk_warn)(char * __restrict  __s ,
                                                                                  size_t __size ,
                                                                                  int __n ,
                                                                                  FILE * __restrict  __stream )  __asm__("__fgets_unlocked_chk") __attribute__((__warning__("fgets_unlocked called with bigger size than length of destination buffer"))) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fgets_unlocked)(char * __restrict  __s ,
                                    int __n , FILE * __restrict  __stream ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  char *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__s, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__s, 1);
    tmp___0 = __fgets_unlocked_chk(__s, tmp, __n, __stream);
    return ((char __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__s, 1);
    if ((size_t )__n > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__s, 1);
      tmp___2 = __fgets_unlocked_chk_warn(__s, tmp___1, __n, __stream);
      return ((char __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __fgets_unlocked_alias(__s, __n, __stream);
  return ((char __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern size_t ( __attribute__((__warn_unused_result__)) __fread_unlocked_chk)(void * __restrict  __ptr ,
                                                                              size_t __ptrlen ,
                                                                              size_t __size ,
                                                                              size_t __n ,
                                                                              FILE * __restrict  __stream ) ;
extern size_t ( __attribute__((__warn_unused_result__)) __fread_unlocked_alias)(void * __restrict  __ptr ,
                                                                                size_t __size ,
                                                                                size_t __n ,
                                                                                FILE * __restrict  __stream )  __asm__("fread_unlocked")  ;
extern size_t ( __attribute__((__warn_unused_result__)) __fread_unlocked_chk_warn)(void * __restrict  __ptr ,
                                                                                   size_t __ptrlen ,
                                                                                   size_t __size ,
                                                                                   size_t __n ,
                                                                                   FILE * __restrict  __stream )  __asm__("__fread_unlocked_chk") __attribute__((__warning__("fread_unlocked called with bigger size * nmemb than length of destination buffer"))) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) fread_unlocked)(void * __restrict  __ptr ,
                                    size_t __size , size_t __n ,
                                    FILE * __restrict  __stream ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___11 ;

  {
  tmp___4 = __builtin_object_size((void *)__ptr, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__ptr, 0);
    tmp___0 = __fread_unlocked_chk(__ptr, tmp, __size, __n, __stream);
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__ptr, 0);
    if (__size * __n > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__ptr, 0);
      tmp___2 = __fread_unlocked_chk_warn(__ptr, tmp___1, __size, __n, __stream);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___11 = __fread_unlocked_alias(__ptr, __size, __n, __stream);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___11);
}
}
extern char __attribute__((__visibility__("default")))  *zend_strndup(char const   *s ,
                                                                      unsigned int length )  __attribute__((__malloc__)) ;
extern void __attribute__((__visibility__("default")))  *_emalloc(size_t size )  __attribute__((__malloc__)) ;
extern void __attribute__((__visibility__("default")))  *_safe_emalloc(size_t nmemb ,
                                                                       size_t size ,
                                                                       size_t offset )  __attribute__((__malloc__)) ;
extern void __attribute__((__visibility__("default")))  _efree(void *ptr ) ;
extern void __attribute__((__visibility__("default")))  *_erealloc(void *ptr ,
                                                                   size_t size ,
                                                                   int allow_failure ) ;
extern char __attribute__((__visibility__("default")))  *_estrdup(char const   *s )  __attribute__((__malloc__)) ;
extern char __attribute__((__visibility__("default")))  *_estrndup(char const   *s ,
                                                                   unsigned int length )  __attribute__((__malloc__)) ;
__inline static void *__zend_malloc(size_t len ) 
{ 
  void *tmp ;
  void *tmp___0 ;

  {
  tmp___0 = malloc(len);
  tmp = tmp___0;
  if (tmp) {
    return (tmp);
  } else {

  }
  fprintf((FILE */* __restrict  */)stderr,
          (char const   */* __restrict  */)"Out of memory\n");
  exit(1);
}
}
__inline static void *__zend_realloc(void *p , size_t len ) 
{ 


  {
  p = realloc(p, len);
  if (p) {
    return (p);
  } else {

  }
  fprintf((FILE */* __restrict  */)stderr,
          (char const   */* __restrict  */)"Out of memory\n");
  exit(1);
}
}
extern char const __attribute__((__visibility__("default")))  *(*zend_new_interned_string)(char const   *str ,
                                                                                           int len ,
                                                                                           int free_src ) ;
extern int __attribute__((__visibility__("default")))  _zend_hash_init(HashTable *ht ,
                                                                       uint nSize ,
                                                                       ulong (*pHashFunction)(char const   *arKey ,
                                                                                              uint nKeyLength ) ,
                                                                       void (*pDestructor)(void *pDest ) ,
                                                                       zend_bool persistent ) ;
extern int __attribute__((__visibility__("default")))  _zend_hash_init_ex(HashTable *ht ,
                                                                          uint nSize ,
                                                                          ulong (*pHashFunction)(char const   *arKey ,
                                                                                                 uint nKeyLength ) ,
                                                                          void (*pDestructor)(void *pDest ) ,
                                                                          zend_bool persistent ,
                                                                          zend_bool bApplyProtection ) ;
extern void __attribute__((__visibility__("default")))  zend_hash_destroy(HashTable *ht ) ;
extern int __attribute__((__visibility__("default")))  _zend_hash_add_or_update(HashTable *ht ,
                                                                                char const   *arKey ,
                                                                                uint nKeyLength ,
                                                                                void *pData ,
                                                                                uint nDataSize ,
                                                                                void **pDest ,
                                                                                int flag ) ;
extern int __attribute__((__visibility__("default")))  _zend_hash_quick_add_or_update(HashTable *ht ,
                                                                                      char const   *arKey ,
                                                                                      uint nKeyLength ,
                                                                                      ulong h ,
                                                                                      void *pData ,
                                                                                      uint nDataSize ,
                                                                                      void **pDest ,
                                                                                      int flag ) ;
extern int __attribute__((__visibility__("default")))  _zend_hash_index_update_or_next_insert(HashTable *ht ,
                                                                                              ulong h ,
                                                                                              void *pData ,
                                                                                              uint nDataSize ,
                                                                                              void **pDest ,
                                                                                              int flag ) ;
extern void __attribute__((__visibility__("default")))  zend_hash_graceful_destroy(HashTable *ht ) ;
extern void __attribute__((__visibility__("default")))  zend_hash_apply(HashTable *ht ,
                                                                        int (*apply_func)(void *pDest ) ) ;
extern void __attribute__((__visibility__("default")))  zend_hash_apply_with_arguments(HashTable *ht ,
                                                                                       int (*apply_func)(void *pDest ,
                                                                                                         int num_args ,
                                                                                                         va_list args ,
                                                                                                         zend_hash_key *hash_key ) ,
                                                                                       int  
                                                                                       , ...) ;
extern int __attribute__((__visibility__("default")))  zend_hash_del_key_or_index(HashTable *ht ,
                                                                                  char const   *arKey ,
                                                                                  uint nKeyLength ,
                                                                                  ulong h ,
                                                                                  int flag ) ;
extern ulong __attribute__((__visibility__("default")))  zend_get_hash_value(char const   *arKey ,
                                                                             uint nKeyLength ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_find(HashTable const   *ht ,
                                                                      char const   *arKey ,
                                                                      uint nKeyLength ,
                                                                      void **pData ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_quick_find(HashTable const   *ht ,
                                                                            char const   *arKey ,
                                                                            uint nKeyLength ,
                                                                            ulong h ,
                                                                            void **pData ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_exists(HashTable const   *ht ,
                                                                        char const   *arKey ,
                                                                        uint nKeyLength ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_move_forward_ex(HashTable *ht ,
                                                                                 HashPosition *pos ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_get_current_data_ex(HashTable *ht ,
                                                                                     void **pData ,
                                                                                     HashPosition *pos ) ;
extern void __attribute__((__visibility__("default")))  zend_hash_internal_pointer_reset_ex(HashTable *ht ,
                                                                                            HashPosition *pos ) ;
extern void __attribute__((__visibility__("default")))  zend_hash_copy(HashTable *target ,
                                                                       HashTable *source ,
                                                                       void (*pCopyConstructor)(void *pElement ) ,
                                                                       void *tmp ,
                                                                       uint size ) ;
extern void __attribute__((__visibility__("default")))  _zend_hash_merge(HashTable *target ,
                                                                         HashTable *source ,
                                                                         void (*pCopyConstructor)(void *pElement ) ,
                                                                         void *tmp ,
                                                                         uint size ,
                                                                         int overwrite ) ;
extern void __attribute__((__visibility__("default")))  zend_hash_merge_ex(HashTable *target ,
                                                                           HashTable *source ,
                                                                           void (*pCopyConstructor)(void *pElement ) ,
                                                                           uint size ,
                                                                           zend_bool (*pMergeSource)(HashTable *target_ht ,
                                                                                                     void *source_data ,
                                                                                                     zend_hash_key *hash_key ,
                                                                                                     void *pParam ) ,
                                                                           void *pParam ) ;
extern int __attribute__((__visibility__("default")))  zend_hash_num_elements(HashTable const   *ht ) ;
__inline static ulong zend_inline_hash_func(char const   *arKey ,
                                            uint nKeyLength ) 
{ 
  register ulong hash ;
  char const   *tmp ;
  char const   *tmp___0 ;
  char const   *tmp___1 ;
  char const   *tmp___2 ;
  char const   *tmp___3 ;
  char const   *tmp___4 ;
  char const   *tmp___5 ;
  char const   *tmp___6 ;
  char const   *tmp___7 ;
  char const   *tmp___8 ;
  char const   *tmp___9 ;
  char const   *tmp___10 ;
  char const   *tmp___11 ;
  char const   *tmp___12 ;
  char const   *tmp___13 ;

  {
  hash = (ulong )5381;
  while (nKeyLength >= 8U) {
    tmp = arKey;
    arKey ++;
    hash = ((hash << 5) + hash) + (ulong )*tmp;
    tmp___0 = arKey;
    arKey ++;
    hash = ((hash << 5) + hash) + (ulong )*tmp___0;
    tmp___1 = arKey;
    arKey ++;
    hash = ((hash << 5) + hash) + (ulong )*tmp___1;
    tmp___2 = arKey;
    arKey ++;
    hash = ((hash << 5) + hash) + (ulong )*tmp___2;
    tmp___3 = arKey;
    arKey ++;
    hash = ((hash << 5) + hash) + (ulong )*tmp___3;
    tmp___4 = arKey;
    arKey ++;
    hash = ((hash << 5) + hash) + (ulong )*tmp___4;
    tmp___5 = arKey;
    arKey ++;
    hash = ((hash << 5) + hash) + (ulong )*tmp___5;
    tmp___6 = arKey;
    arKey ++;
    hash = ((hash << 5) + hash) + (ulong )*tmp___6;
    nKeyLength -= 8U;
  }
  switch (nKeyLength) {
  case 7U: 
  tmp___7 = arKey;
  arKey ++;
  hash = ((hash << 5) + hash) + (ulong )*tmp___7;
  case 6U: 
  tmp___8 = arKey;
  arKey ++;
  hash = ((hash << 5) + hash) + (ulong )*tmp___8;
  case 5U: 
  tmp___9 = arKey;
  arKey ++;
  hash = ((hash << 5) + hash) + (ulong )*tmp___9;
  case 4U: 
  tmp___10 = arKey;
  arKey ++;
  hash = ((hash << 5) + hash) + (ulong )*tmp___10;
  case 3U: 
  tmp___11 = arKey;
  arKey ++;
  hash = ((hash << 5) + hash) + (ulong )*tmp___11;
  case 2U: 
  tmp___12 = arKey;
  arKey ++;
  hash = ((hash << 5) + hash) + (ulong )*tmp___12;
  case 1U: 
  tmp___13 = arKey;
  arKey ++;
  hash = ((hash << 5) + hash) + (ulong )*tmp___13;
  break;
  case 0U: 
  break;
  }
  return (hash);
}
}
extern ulong __attribute__((__visibility__("default")))  zend_hash_func(char const   *arKey ,
                                                                        uint nKeyLength ) ;
__inline static int zend_symtable_update(HashTable *ht , char const   *arKey ,
                                         uint nKeyLength , void *pData ,
                                         uint nDataSize , void **pDest ) 
{ 
  ulong idx ;
  register char const   *tmp ;
  char const   *end ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;

  {
  while (1) {
    while (1) {
      tmp = arKey;
      if ((int const   )*tmp == 45) {
        tmp ++;
      } else {

      }
      if ((int const   )*tmp >= 48) {
        if ((int const   )*tmp <= 57) {
          end = (arKey + nKeyLength) - 1;
          if ((int const   )*end != 0) {
            break;
          } else
          if ((int const   )*tmp == 48) {
            if (nKeyLength > 2U) {
              break;
            } else {
              goto _L;
            }
          } else
          _L: 
          if (end - tmp > 19L) {
            break;
          } else {

          }
          idx = (ulong )((int const   )*tmp - 48);
          while (1) {
            tmp ++;
            if ((unsigned long )tmp != (unsigned long )end) {
              if ((int const   )*tmp >= 48) {
                if (! ((int const   )*tmp <= 57)) {
                  break;
                } else {

                }
              } else {
                break;
              }
            } else {
              break;
            }
            idx = idx * 10UL + (ulong )((int const   )*tmp - 48);
          }
          if ((unsigned long )tmp == (unsigned long )end) {
            if ((int const   )*arKey == 45) {
              if (idx - 1UL > 9223372036854775807UL) {
                break;
              } else {

              }
              idx = (ulong )(- ((long )idx));
            } else
            if (idx > 9223372036854775807UL) {
              break;
            } else {

            }
            tmp___0 = _zend_hash_index_update_or_next_insert(ht, idx, pData,
                                                             nDataSize, pDest, 1);
            return ((int )tmp___0);
          } else {

          }
        } else {

        }
      } else {

      }
      break;
    }
    break;
  }
  tmp___1 = _zend_hash_add_or_update(ht, arKey, nKeyLength, pData, nDataSize,
                                     pDest, 1);
  return ((int )tmp___1);
}
}
extern void __attribute__((__visibility__("default")))  zend_llist_init(zend_llist *l ,
                                                                        size_t size ,
                                                                        void (*dtor)(void * ) ,
                                                                        unsigned char persistent ) ;
extern void __attribute__((__visibility__("default")))  zend_llist_add_element(zend_llist *l ,
                                                                               void *element ) ;
extern void __attribute__((__visibility__("default")))  zend_llist_prepend_element(zend_llist *l ,
                                                                                   void *element ) ;
extern void __attribute__((__visibility__("default")))  zend_llist_destroy(zend_llist *l ) ;
extern void __attribute__((__visibility__("default")))  *zend_llist_remove_tail(zend_llist *l ) ;
extern void __attribute__((__visibility__("default")))  zend_llist_copy(zend_llist *dst ,
                                                                        zend_llist *src ) ;
__inline static zend_uint ( __attribute__((__always_inline__)) zval_refcount_p)(zval *pz ) 
{ 


  {
  return (pz->refcount__gc);
}
}
__inline static zend_uint ( __attribute__((__always_inline__)) zval_set_refcount_p)(zval *pz ,
                                                                                    zend_uint rc ) 
{ 
  zend_uint tmp ;

  {
  tmp = rc;
  pz->refcount__gc = tmp;
  return (tmp);
}
}
__inline static zend_uint ( __attribute__((__always_inline__)) zval_addref_p)(zval *pz ) 
{ 


  {
  (pz->refcount__gc) ++;
  return (pz->refcount__gc);
}
}
__inline static zend_uint ( __attribute__((__always_inline__)) zval_delref_p)(zval *pz ) 
{ 


  {
  (pz->refcount__gc) --;
  return (pz->refcount__gc);
}
}
__inline static zend_bool ( __attribute__((__always_inline__)) zval_isref_p)(zval *pz ) 
{ 


  {
  return (pz->is_ref__gc);
}
}
__inline static zend_bool ( __attribute__((__always_inline__)) zval_set_isref_p)(zval *pz ) 
{ 
  zend_uchar tmp ;

  {
  tmp = (zend_uchar )1;
  pz->is_ref__gc = tmp;
  return (tmp);
}
}
__inline static zend_bool ( __attribute__((__always_inline__)) zval_unset_isref_p)(zval *pz ) 
{ 
  zend_uchar tmp ;

  {
  tmp = (zend_uchar )0;
  pz->is_ref__gc = tmp;
  return (tmp);
}
}
extern void __attribute__((__visibility__("default")))  zend_file_handle_dtor(zend_file_handle *fh ) ;
extern void __attribute__((__visibility__("default")))  zend_make_printable_zval(zval *expr ,
                                                                                 zval *expr_copy ,
                                                                                 int *use_copy ) ;
extern void __attribute__((__visibility__("default")))  free_estring(char **str_p ) ;
extern void __attribute__((__visibility__("default")))  zend_error(int type ,
                                                                   char const   *format 
                                                                   , ...) ;
extern zval __attribute__((__visibility__("default")))  zval_used_for_init ;
__inline extern int __attribute__((__gnu_inline__))  __sigismember(__sigset_t const   *__set ,
                                                                   int __sig ) ;
__inline extern int __attribute__((__gnu_inline__))  __sigaddset(__sigset_t *__set ,
                                                                 int __sig ) ;
__inline extern int __attribute__((__gnu_inline__))  __sigdelset(__sigset_t *__set ,
                                                                 int __sig ) ;
__inline extern int __attribute__((__gnu_inline__))  __sigismember(__sigset_t const   *__set ,
                                                                   int __sig ) 
{ 
  unsigned long __mask ;
  unsigned long __word ;
  int tmp ;

  {
  __mask = 1UL << (unsigned long )(__sig - 1) % (8UL * sizeof(unsigned long ));
  __word = (unsigned long )(__sig - 1) / (8UL * sizeof(unsigned long ));
  if (__set->__val[__word] & __mask) {
    tmp = 1;
  } else {
    tmp = 0;
  }
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  __sigaddset(__sigset_t *__set ,
                                                                 int __sig ) 
{ 
  unsigned long __mask ;
  unsigned long __word ;

  {
  __mask = 1UL << (unsigned long )(__sig - 1) % (8UL * sizeof(unsigned long ));
  __word = (unsigned long )(__sig - 1) / (8UL * sizeof(unsigned long ));
  __set->__val[__word] |= __mask;
  return ((int __attribute__((__gnu_inline__))  )0);
}
}
__inline extern int __attribute__((__gnu_inline__))  __sigdelset(__sigset_t *__set ,
                                                                 int __sig ) 
{ 
  unsigned long __mask ;
  unsigned long __word ;

  {
  __mask = 1UL << (unsigned long )(__sig - 1) % (8UL * sizeof(unsigned long ));
  __word = (unsigned long )(__sig - 1) / (8UL * sizeof(unsigned long ));
  __set->__val[__word] &= ~ __mask;
  return ((int __attribute__((__gnu_inline__))  )0);
}
}
extern void __attribute__((__visibility__("default")))  gc_remove_zval_from_buffer(zval *zv ) ;
__inline static long ( __attribute__((__always_inline__)) zend_dval_to_lval)(double d ) 
{ 


  {
  if (d > (double )9223372036854775807L) {
    return ((long )((unsigned long )d));
  } else {

  }
  return ((long )d);
}
}
__inline static void const   *zend_memrchr(void const   *s , int c , size_t n ) 
{ 
  register unsigned char const   *e ;

  {
  if (n <= 0UL) {
    return ((void const   *)((void *)0));
  } else {

  }
  e = ((unsigned char const   *)s + n) - 1;
  while ((unsigned long )e >= (unsigned long )((unsigned char const   *)s)) {
    if ((int const   )*e == (int const   )((unsigned char const   )c)) {
      return ((void const   *)e);
    } else {

    }
    e --;
  }
  return ((void const   *)((void *)0));
}
}
extern void __attribute__((__visibility__("default")))  _convert_to_string(zval *op ) ;
extern void __attribute__((__visibility__("default")))  convert_to_long(zval *op ) ;
extern int __attribute__((__visibility__("default")))  compare_function(zval *result ,
                                                                        zval *op1 ,
                                                                        zval *op2 ) ;
extern void __attribute__((__visibility__("default")))  zend_str_tolower(char *str ,
                                                                         unsigned int length ) ;
extern char __attribute__((__visibility__("default")))  *zend_str_tolower_copy(char *dest ,
                                                                               char const   *source ,
                                                                               unsigned int length ) ;
extern char __attribute__((__visibility__("default")))  *zend_str_tolower_dup(char const   *source ,
                                                                              unsigned int length ) ;
extern int __attribute__((__visibility__("default")))  zend_binary_strcasecmp(char const   *s1 ,
                                                                              uint len1 ,
                                                                              char const   *s2 ,
                                                                              uint len2 ) ;
extern void __attribute__((__visibility__("default")))  _zval_dtor_func(zval *zvalue ) ;
__inline static void ( __attribute__((__always_inline__)) _zval_dtor)(zval *zvalue ) 
{ 


  {
  if ((int )zvalue->type <= 3) {
    return;
  } else {

  }
  _zval_dtor_func(zvalue);
  return;
}
}
extern void __attribute__((__visibility__("default")))  _zval_copy_ctor_func(zval *zvalue ) ;
__inline static void ( __attribute__((__always_inline__)) _zval_copy_ctor)(zval *zvalue ) 
{ 


  {
  if ((int )zvalue->type <= 3) {
    return;
  } else {

  }
  _zval_copy_ctor_func(zvalue);
  return;
}
}
extern int __attribute__((__visibility__("default")))  zval_copy_static_var(zval **p ,
                                                                            int num_args ,
                                                                            va_list args ,
                                                                            zend_hash_key *key ) ;
extern void __attribute__((__visibility__("default")))  _zval_ptr_dtor(zval **zval_ptr ) ;
extern void __attribute__((__visibility__("default")))  _zval_internal_ptr_dtor(zval **zvalue ) ;
extern void __attribute__((__visibility__("default")))  zval_add_ref(zval **p ) ;
char *zend_visibility_string(zend_uint fn_flags ) ;
struct _zend_compiler_globals  __attribute__((__visibility__("default"))) compiler_globals  ;
zend_executor_globals __attribute__((__visibility__("default")))  executor_globals  ;
extern zend_php_scanner_globals __attribute__((__visibility__("default")))  language_scanner_globals ;
extern int __attribute__((__visibility__("default")))  zend_stack_init(zend_stack *stack ) ;
extern int __attribute__((__visibility__("default")))  zend_stack_push(zend_stack *stack ,
                                                                       void const   *element ,
                                                                       int size ) ;
extern int __attribute__((__visibility__("default")))  zend_stack_top(zend_stack const   *stack ,
                                                                      void **element ) ;
extern int __attribute__((__visibility__("default")))  zend_stack_del_top(zend_stack *stack ) ;
extern int __attribute__((__visibility__("default")))  zend_stack_is_empty(zend_stack const   *stack ) ;
extern int __attribute__((__visibility__("default")))  zend_stack_destroy(zend_stack *stack ) ;
extern void __attribute__((__visibility__("default")))  zend_stack_apply(zend_stack *stack ,
                                                                         int type ,
                                                                         int (*apply_function)(void *element ) ) ;
extern zend_encoding const __attribute__((__visibility__("default")))  *zend_multibyte_fetch_encoding(char const   *name ) ;
void init_compiler(void) ;
void shutdown_compiler(void) ;
void zend_init_compiler_data_structures(void) ;
void zend_init_compiler_context(void) ;
zend_op_array __attribute__((__visibility__("default")))  *(*zend_compile_file)(zend_file_handle *file_handle ,
                                                                                int type )  ;
zend_op_array __attribute__((__visibility__("default")))  *(*zend_compile_string)(zval *source_string ,
                                                                                  char *filename )  ;
extern int __attribute__((__visibility__("default")))  lex_scan(zval *zendlval ) ;
char __attribute__((__visibility__("default")))  *zend_set_compiled_filename(char const   *new_compiled_filename ) ;
void __attribute__((__visibility__("default")))  zend_restore_compiled_filename(char *original_compiled_filename ) ;
char __attribute__((__visibility__("default")))  *zend_get_compiled_filename(void) ;
int __attribute__((__visibility__("default")))  zend_get_compiled_lineno(void) ;
extern size_t __attribute__((__visibility__("default")))  zend_get_scanned_file_offset(void) ;
void zend_resolve_non_class_name(znode *element_name ,
                                 zend_bool check_namespace ) ;
void zend_resolve_class_name(znode *class_name , ulong fetch_type ,
                             int check_ns_name ) ;
char const __attribute__((__visibility__("default")))  *zend_get_compiled_variable_name(zend_op_array const   *op_array ,
                                                                                        zend_uint var ,
                                                                                        int *name_len ) ;
void zend_do_binary_op(zend_uchar op , znode *result , znode const   *op1 ,
                       znode const   *op2 ) ;
void zend_do_unary_op(zend_uchar op , znode *result , znode const   *op1 ) ;
void zend_do_binary_assign_op(zend_uchar op , znode *result ,
                              znode const   *op1 , znode const   *op2 ) ;
void zend_do_assign(znode *result , znode *variable , znode *value ) ;
void zend_do_assign_ref(znode *result , znode const   *lvar ,
                        znode const   *rvar ) ;
void fetch_simple_variable(znode *result , znode *varname , int bp ) ;
void fetch_simple_variable_ex(znode *result , znode *varname , int bp ,
                              zend_uchar op ) ;
void zend_do_indirect_references(znode *result , znode const   *num_references ,
                                 znode *variable ) ;
void zend_do_fetch_static_variable(znode *varname ,
                                   znode const   *static_assignment ,
                                   int fetch_type ) ;
void zend_do_fetch_global_variable(znode *varname ,
                                   znode const   *static_assignment ,
                                   int fetch_type ) ;
void fetch_array_begin(znode *result , znode *varname , znode *first_dim ) ;
void fetch_array_dim(znode *result , znode const   *parent , znode const   *dim ) ;
void fetch_string_offset(znode *result , znode const   *parent ,
                         znode const   *offset ) ;
void zend_do_fetch_static_member(znode *result , znode *class_name ) ;
void zend_do_print(znode *result , znode const   *arg ) ;
void zend_do_echo(znode const   *arg ) ;
void zend_do_while_cond(znode const   *expr , znode *close_bracket_token ) ;
void zend_do_while_end(znode const   *while_token ,
                       znode const   *close_bracket_token ) ;
void zend_do_do_while_begin(void) ;
void zend_do_do_while_end(znode const   *do_token ,
                          znode const   *expr_open_bracket ,
                          znode const   *expr ) ;
void zend_do_if_cond(znode const   *cond , znode *closing_bracket_token ) ;
void zend_do_if_after_statement(znode const   *closing_bracket_token ,
                                unsigned char initialize ) ;
void zend_do_if_end(void) ;
void zend_do_for_cond(znode const   *expr , znode *second_semicolon_token ) ;
void zend_do_for_before_statement(znode const   *cond_start ,
                                  znode const   *second_semicolon_token ) ;
void zend_do_for_end(znode const   *second_semicolon_token ) ;
void zend_do_pre_incdec(znode *result , znode const   *op1 , zend_uchar op ) ;
void zend_do_post_incdec(znode *result , znode const   *op1 , zend_uchar op ) ;
void zend_do_begin_variable_parse(void) ;
void zend_do_end_variable_parse(znode *variable , int type , int arg_offset ) ;
void zend_check_writable_variable(znode const   *variable ) ;
void zend_do_free(znode *op1 ) ;
void zend_do_add_string(znode *result , znode const   *op1 , znode *op2 ) ;
void zend_do_add_variable(znode *result , znode const   *op1 ,
                          znode const   *op2 ) ;
int zend_do_verify_access_types(znode const   *current_access_type ,
                                znode const   *new_modifier ) ;
void zend_do_begin_function_declaration(znode *function_token ,
                                        znode *function_name , int is_method ,
                                        int return_reference ,
                                        znode *fn_flags_znode ) ;
void zend_do_end_function_declaration(znode const   *function_token ) ;
void zend_do_receive_arg(zend_uchar op , znode *varname ,
                         znode const   *offset , znode const   *initialization ,
                         znode *class_type , unsigned char pass_by_reference ) ;
int zend_do_begin_function_call(znode *function_name ,
                                zend_bool check_namespace ) ;
void zend_do_begin_method_call(znode *left_bracket ) ;
void zend_do_clone(znode *result , znode const   *expr ) ;
void zend_do_begin_dynamic_function_call(znode *function_name , int ns_call ) ;
void zend_do_fetch_class(znode *result , znode *class_name ) ;
void zend_do_build_full_name(znode *result , znode *prefix , znode *name ,
                             int is_class_member ) ;
int zend_do_begin_class_member_function_call(znode *class_name ,
                                             znode *method_name ) ;
void zend_do_end_function_call(znode *function_name , znode *result ,
                               znode const   *argument_list , int is_method ,
                               int is_dynamic_fcall ) ;
void zend_do_return(znode *expr , int do_end_vparse ) ;
void zend_do_handle_exception(void) ;
void zend_do_begin_lambda_function_declaration(znode *result ,
                                               znode *function_token ,
                                               int return_reference ,
                                               int is_static ) ;
void zend_do_fetch_lexical_variable(znode *varname , zend_bool is_ref ) ;
void zend_do_try(znode *try_token ) ;
void zend_do_begin_catch(znode *try_token , znode *class_name ,
                         znode *catch_var , znode *first_catch ) ;
void zend_do_end_catch(znode const   *try_token ) ;
void zend_do_throw(znode const   *expr ) ;
int __attribute__((__visibility__("default")))  do_bind_function(zend_op_array const   *op_array ,
                                                                 zend_op *opline ,
                                                                 HashTable *function_table ,
                                                                 zend_bool compile_time ) ;
zend_class_entry __attribute__((__visibility__("default")))  *do_bind_class(zend_op_array const   *op_array ,
                                                                            zend_op const   *opline ,
                                                                            HashTable *class_table ,
                                                                            zend_bool compile_time ) ;
zend_class_entry __attribute__((__visibility__("default")))  *do_bind_inherited_class(zend_op_array const   *op_array ,
                                                                                      zend_op const   *opline ,
                                                                                      HashTable *class_table ,
                                                                                      zend_class_entry *parent_ce ,
                                                                                      zend_bool compile_time ) ;
void __attribute__((__visibility__("default")))  zend_do_inherit_interfaces(zend_class_entry *ce ,
                                                                            zend_class_entry const   *iface ) ;
void __attribute__((__visibility__("default")))  zend_do_implement_interface(zend_class_entry *ce ,
                                                                             zend_class_entry *iface ) ;
void zend_do_implements_interface(znode *interface_name ) ;
void zend_add_trait_precedence(znode *precedence_znode ) ;
void zend_add_trait_alias(znode *alias_znode ) ;
void zend_do_implements_trait(znode *trait_name ) ;
void __attribute__((__visibility__("default")))  zend_do_implement_trait(zend_class_entry *ce ,
                                                                         zend_class_entry *trait ) ;
void __attribute__((__visibility__("default")))  zend_do_bind_traits(zend_class_entry *ce ) ;
void zend_prepare_trait_precedence(znode *result , znode *method_reference ,
                                   znode *trait_list ) ;
void zend_prepare_reference(znode *result , znode *class_name ,
                            znode *method_name ) ;
void zend_prepare_trait_alias(znode *result , znode *method_reference ,
                              znode *modifiers , znode *alias ) ;
void __attribute__((__visibility__("default")))  zend_do_inheritance(zend_class_entry *ce ,
                                                                     zend_class_entry *parent_ce ) ;
void zend_do_early_binding(void) ;
void __attribute__((__visibility__("default")))  zend_do_delayed_early_binding(zend_op_array const   *op_array ) ;
void zend_do_pass_param(znode *param , zend_uchar op , int offset ) ;
void zend_do_boolean_or_begin(znode *expr1 , znode *op_token ) ;
void zend_do_boolean_or_end(znode *result , znode const   *expr1 ,
                            znode const   *expr2 , znode *op_token ) ;
void zend_do_boolean_and_begin(znode *expr1 , znode *op_token ) ;
void zend_do_boolean_and_end(znode *result , znode const   *expr1 ,
                             znode const   *expr2 , znode const   *op_token ) ;
void zend_do_brk_cont(zend_uchar op , znode const   *expr ) ;
void zend_do_switch_cond(znode const   *cond ) ;
void zend_do_switch_end(znode const   *case_list ) ;
void zend_do_case_before_statement(znode const   *case_list ,
                                   znode *case_token , znode const   *case_expr ) ;
void zend_do_case_after_statement(znode *result , znode const   *case_token ) ;
void zend_do_default_before_statement(znode const   *case_list ,
                                      znode *default_token ) ;
void zend_do_begin_class_declaration(znode const   *class_token ,
                                     znode *class_name ,
                                     znode const   *parent_class_name ) ;
void zend_do_end_class_declaration(znode const   *class_token ,
                                   znode const   *parent_token ) ;
void zend_do_declare_property(znode const   *var_name , znode const   *value ,
                              zend_uint access_type ) ;
void zend_do_declare_class_constant(znode *var_name , znode const   *value ) ;
void zend_do_fetch_property(znode *result , znode *object ,
                            znode const   *property ) ;
void zend_do_halt_compiler_register(void) ;
void zend_do_push_object(znode const   *object ) ;
void zend_do_pop_object(znode *object ) ;
void zend_do_begin_new_object(znode *new_token , znode *class_type ) ;
void zend_do_end_new_object(znode *result , znode const   *new_token ,
                            znode const   *argument_list ) ;
void zend_do_fetch_constant(znode *result , znode *constant_container ,
                            znode *constant_name , int mode ,
                            zend_bool check_namespace ) ;
void zend_do_shell_exec(znode *result , znode const   *cmd ) ;
void zend_do_init_array(znode *result , znode const   *expr ,
                        znode const   *offset , zend_bool is_ref ) ;
void zend_do_add_array_element(znode *result , znode const   *expr ,
                               znode const   *offset , zend_bool is_ref ) ;
void zend_do_add_static_array_element(znode *result , znode *offset ,
                                      znode const   *expr ) ;
void zend_do_list_init(void) ;
void zend_do_list_end(znode *result , znode *expr ) ;
void zend_do_add_list_element(znode const   *element ) ;
void zend_do_new_list_begin(void) ;
void zend_do_new_list_end(void) ;
void zend_init_list(void *result , void *item ) ;
void zend_add_to_list(void *result , void *item ) ;
void zend_do_cast(znode *result , znode const   *expr , int type ) ;
void zend_do_include_or_eval(int type , znode *result , znode const   *op1 ) ;
void zend_do_unset(znode const   *variable ) ;
void zend_do_isset_or_isempty(int type , znode *result , znode *variable ) ;
void zend_do_instanceof(znode *result , znode const   *expr ,
                        znode const   *class_znode , int type ) ;
void zend_do_foreach_begin(znode *foreach_token , znode *open_brackets_token ,
                           znode *array , znode *as_token , int variable ) ;
void zend_do_foreach_cont(znode *foreach_token ,
                          znode const   *open_brackets_token ,
                          znode const   *as_token , znode *value , znode *key ) ;
void zend_do_foreach_end(znode const   *foreach_token , znode const   *as_token ) ;
void zend_do_declare_begin(void) ;
void zend_do_declare_stmt(znode *var , znode *val ) ;
void zend_do_declare_end(znode const   *declare_token ) ;
void zend_do_exit(znode *result , znode const   *message ) ;
void zend_do_begin_silence(znode *strudel_token ) ;
void zend_do_end_silence(znode const   *strudel_token ) ;
void zend_do_jmp_set(znode const   *value , znode *jmp_token ,
                     znode *colon_token ) ;
void zend_do_jmp_set_else(znode *result , znode const   *false_value ,
                          znode const   *jmp_token , znode const   *colon_token ) ;
void zend_do_begin_qm_op(znode const   *cond , znode *qm_token ) ;
void zend_do_qm_true(znode const   *true_value , znode *qm_token ,
                     znode *colon_token ) ;
void zend_do_qm_false(znode *result , znode const   *false_value ,
                      znode const   *qm_token , znode const   *colon_token ) ;
void zend_do_extended_info(void) ;
void zend_do_extended_fcall_begin(void) ;
void zend_do_extended_fcall_end(void) ;
void zend_do_ticks(void) ;
void zend_do_abstract_method(znode const   *function_name , znode *modifiers ,
                             znode const   *body ) ;
void zend_do_declare_constant(znode *name , znode *value ) ;
void zend_do_build_namespace_name(znode *result , znode *prefix , znode *name ) ;
void zend_do_begin_namespace(znode const   *name , zend_bool with_bracket ) ;
void zend_do_end_namespace(void) ;
void zend_verify_namespace(void) ;
void zend_do_use(znode *ns_name , znode *new_name , int is_global ) ;
void zend_do_end_compilation(void) ;
void zend_do_label(znode *label ) ;
void zend_do_goto(znode const   *label ) ;
void zend_resolve_goto_label(zend_op_array *op_array , zend_op *opline ,
                             int pass2 ) ;
void zend_release_labels(void) ;
void __attribute__((__visibility__("default")))  function_add_ref(zend_function *function ) ;
extern void __attribute__((__visibility__("default")))  init_op_array(zend_op_array *op_array ,
                                                                      zend_uchar type ,
                                                                      int initial_ops_size ) ;
extern void __attribute__((__visibility__("default")))  zend_function_dtor(zend_function *function ) ;
void __attribute__((__visibility__("default")))  zend_mangle_property_name(char **dest ,
                                                                           int *dest_length ,
                                                                           char const   *src1 ,
                                                                           int src1_length ,
                                                                           char const   *src2 ,
                                                                           int src2_length ,
                                                                           int internal ) ;
int __attribute__((__visibility__("default")))  zend_unmangle_property_name(char const   *mangled_property ,
                                                                            int len ,
                                                                            char const   **class_name ,
                                                                            char const   **prop_name ) ;
extern zend_op *get_next_op(zend_op_array *op_array ) ;
extern void init_op(zend_op *op ) ;
extern int get_next_op_number(zend_op_array *op_array ) ;
extern int __attribute__((__visibility__("default")))  pass_two(zend_op_array *op_array ) ;
extern zend_brk_cont_element *get_next_brk_cont_element(zend_op_array *op_array ) ;
void zend_do_first_catch(znode *open_parentheses ) ;
void zend_initialize_try_catch_element(znode const   *try_token ) ;
void zend_do_mark_last_catch(znode const   *first_catch ,
                             znode const   *last_additional_catch ) ;
zend_bool __attribute__((__visibility__("default")))  zend_is_compiling(void) ;
void __attribute__((__visibility__("default")))  zend_initialize_class_data(zend_class_entry *ce ,
                                                                            zend_bool nullify_handlers ) ;
int zend_get_class_fetch_type(char const   *class_name , uint class_name_len ) ;
int __attribute__((__visibility__("default")))  zend_register_auto_global(char const   *name ,
                                                                          uint name_len ,
                                                                          zend_bool jit ,
                                                                          zend_bool (*auto_global_callback)(char const   *name ,
                                                                                                            uint name_len ) ) ;
void __attribute__((__visibility__("default")))  zend_activate_auto_globals(void) ;
zend_bool __attribute__((__visibility__("default")))  zend_is_auto_global(char const   *name ,
                                                                          uint name_len ) ;
zend_bool __attribute__((__visibility__("default")))  zend_is_auto_global_quick(char const   *name ,
                                                                                uint name_len ,
                                                                                ulong hashval ) ;
size_t __attribute__((__visibility__("default")))  zend_dirname(char *path ,
                                                                size_t len ) ;
int zendlex(znode *zendlval ) ;
int zend_add_literal(zend_op_array *op_array , zval const   *zv ) ;
extern void __attribute__((__visibility__("default")))  zend_register_long_constant(char const   *name ,
                                                                                    uint name_len ,
                                                                                    long lval ,
                                                                                    int flags ,
                                                                                    int module_number ) ;
extern int zend_init_rsrc_list(void) ;
extern int __attribute__((__visibility__("default")))  zend_lookup_class(char const   *name ,
                                                                         int name_length ,
                                                                         zend_class_entry ***ce ) ;
extern int __attribute__((__visibility__("default")))  zval_update_constant_ex(zval **pp ,
                                                                               void *arg ,
                                                                               zend_class_entry *scope ) ;
extern zend_class_entry __attribute__((__visibility__("default")))  *zend_fetch_class(char const   *class_name ,
                                                                                      uint class_name_len ,
                                                                                      int fetch_type ) ;
extern void zend_verify_abstract_class(zend_class_entry *ce ) ;
extern void __attribute__((__visibility__("default")))  zend_check_magic_method_implementation(zend_class_entry const   *ce ,
                                                                                               zend_function const   *fptr ,
                                                                                               int error_type ) ;
extern int __attribute__((__visibility__("default")))  zend_declare_property_ex(zend_class_entry *ce ,
                                                                                char const   *name ,
                                                                                int name_length ,
                                                                                zval *property ,
                                                                                int access_type ,
                                                                                char const   *doc_comment ,
                                                                                int doc_comment_len ) ;
extern void __attribute__((__visibility__("default")))  zend_update_class_constants(zend_class_entry *class_type ) ;
extern char __attribute__((__visibility__("default")))  *zend_get_type_by_const(int type ) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) read)(int __fd , void *__buf ,
                                          size_t __nbytes ) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__,
__always_inline__)) pread)(int __fd , void *__buf ,
                           size_t __nbytes , __off_t __offset ) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) pread64)(int __fd , void *__buf ,
                                             size_t __nbytes ,
                                             __off64_t __offset ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) getcwd)(char *__buf , size_t __size ) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__,
__deprecated__))  *( __attribute__((__warn_unused_result__, __nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) getwd)(char *__buf )  __attribute__((__deprecated__)) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) confstr)(int __name , char *__buf ,
                                             size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) getgroups)(int __size , __gid_t *__list ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(2), __leaf__, __artificial__,
__always_inline__)) ttyname_r)(int __fd , char *__buf , size_t __buflen ) ;
__inline extern  __attribute__((__nothrow__)) ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1,2), __leaf__, __artificial__,
__always_inline__)) readlink)(char const   * __restrict  __path ,
                              char * __restrict  __buf , size_t __len ) ;
__inline extern  __attribute__((__nothrow__)) ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(2,3), __leaf__, __artificial__,
__always_inline__)) readlinkat)(int __fd , char const   * __restrict  __path ,
                                char * __restrict  __buf , size_t __len ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__artificial__,
__always_inline__)) getlogin_r)(char *__buf , size_t __buflen ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) gethostname)(char *__buf , size_t __buflen ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__, __artificial__,
__always_inline__)) getdomainname)(char *__buf , size_t __buflen ) ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __read_chk)(int __fd ,
                                                                     void *__buf ,
                                                                     size_t __nbytes ,
                                                                     size_t __buflen ) ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __read_alias)(int __fd ,
                                                                       void *__buf ,
                                                                       size_t __nbytes )  __asm__("read")  ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __read_chk_warn)(int __fd ,
                                                                          void *__buf ,
                                                                          size_t __nbytes ,
                                                                          size_t __buflen )  __asm__("__read_chk") __attribute__((__warning__("read called with bigger length than size of the destination buffer"))) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) read)(int __fd , void *__buf ,
                                          size_t __nbytes ) 
{ 
  unsigned long tmp ;
  ssize_t tmp___0 ;
  unsigned long tmp___1 ;
  ssize_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  ssize_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size(__buf, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size(__buf, 0);
    tmp___0 = __read_chk(__fd, __buf, __nbytes, tmp);
    return ((ssize_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size(__buf, 0);
    if (__nbytes > tmp___3) {
      tmp___1 = __builtin_object_size(__buf, 0);
      tmp___2 = __read_chk_warn(__fd, __buf, __nbytes, tmp___1);
      return ((ssize_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __read_alias(__fd, __buf, __nbytes);
  return ((ssize_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern ssize_t ( __attribute__((__warn_unused_result__)) __pread_chk)(int __fd ,
                                                                      void *__buf ,
                                                                      size_t __nbytes ,
                                                                      __off_t __offset ,
                                                                      size_t __bufsize ) ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __pread64_chk)(int __fd ,
                                                                        void *__buf ,
                                                                        size_t __nbytes ,
                                                                        __off64_t __offset ,
                                                                        size_t __bufsize ) ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __pread_alias)(int __fd ,
                                                                        void *__buf ,
                                                                        size_t __nbytes ,
                                                                        __off_t __offset )  __asm__("pread")  ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __pread64_alias)(int __fd ,
                                                                          void *__buf ,
                                                                          size_t __nbytes ,
                                                                          __off64_t __offset )  __asm__("pread64")  ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __pread_chk_warn)(int __fd ,
                                                                           void *__buf ,
                                                                           size_t __nbytes ,
                                                                           __off_t __offset ,
                                                                           size_t __bufsize )  __asm__("__pread_chk") __attribute__((__warning__("pread called with bigger length than size of the destination buffer"))) ;
extern ssize_t ( __attribute__((__warn_unused_result__)) __pread64_chk_warn)(int __fd ,
                                                                             void *__buf ,
                                                                             size_t __nbytes ,
                                                                             __off64_t __offset ,
                                                                             size_t __bufsize )  __asm__("__pread64_chk") __attribute__((__warning__("pread64 called with bigger length than size of the destination buffer"))) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) pread)(int __fd , void *__buf ,
                                           size_t __nbytes , __off_t __offset ) 
{ 
  unsigned long tmp ;
  ssize_t tmp___0 ;
  unsigned long tmp___1 ;
  ssize_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  ssize_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size(__buf, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size(__buf, 0);
    tmp___0 = __pread_chk(__fd, __buf, __nbytes, __offset, tmp);
    return ((ssize_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size(__buf, 0);
    if (__nbytes > tmp___3) {
      tmp___1 = __builtin_object_size(__buf, 0);
      tmp___2 = __pread_chk_warn(__fd, __buf, __nbytes, __offset, tmp___1);
      return ((ssize_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __pread_alias(__fd, __buf, __nbytes, __offset);
  return ((ssize_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__artificial__, __always_inline__)) pread64)(int __fd , void *__buf ,
                                             size_t __nbytes ,
                                             __off64_t __offset ) 
{ 
  unsigned long tmp ;
  ssize_t tmp___0 ;
  unsigned long tmp___1 ;
  ssize_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  ssize_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size(__buf, 0);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size(__buf, 0);
    tmp___0 = __pread64_chk(__fd, __buf, __nbytes, __offset, tmp);
    return ((ssize_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size(__buf, 0);
    if (__nbytes > tmp___3) {
      tmp___1 = __builtin_object_size(__buf, 0);
      tmp___2 = __pread64_chk_warn(__fd, __buf, __nbytes, __offset, tmp___1);
      return ((ssize_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __pread64_alias(__fd, __buf, __nbytes, __offset);
  return ((ssize_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__warn_unused_result__,
__nonnull__(1,2), __leaf__)) __readlink_chk)(char const   * __restrict  __path ,
                                             char * __restrict  __buf ,
                                             size_t __len , size_t __buflen ) ;
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__warn_unused_result__,
__nonnull__(1,2),
__leaf__)) __readlink_alias)(char const   * __restrict  __path ,
                             char * __restrict  __buf , size_t __len )  __asm__("readlink")  ;
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__warn_unused_result__,
__nonnull__(1,2),
__leaf__)) __readlink_chk_warn)(char const   * __restrict  __path ,
                                char * __restrict  __buf , size_t __len ,
                                size_t __buflen )  __asm__("__readlink_chk") __attribute__((__warning__("readlink called with bigger length than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1,2), __leaf__, __artificial__,
__always_inline__)) readlink)(char const   * __restrict  __path ,
                              char * __restrict  __buf , size_t __len ) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1,2), __leaf__, __artificial__,
__always_inline__)) readlink)(char const   * __restrict  __path ,
                              char * __restrict  __buf , size_t __len ) 
{ 
  unsigned long tmp ;
  ssize_t tmp___0 ;
  unsigned long tmp___1 ;
  ssize_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  ssize_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __readlink_chk(__path, __buf, __len, tmp);
    return ((ssize_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__len > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __readlink_chk_warn(__path, __buf, __len, tmp___1);
      return ((ssize_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __readlink_alias(__path, __buf, __len);
  return ((ssize_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__warn_unused_result__,
__nonnull__(2,3),
__leaf__)) __readlinkat_chk)(int __fd , char const   * __restrict  __path ,
                             char * __restrict  __buf , size_t __len ,
                             size_t __buflen ) ;
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__warn_unused_result__,
__nonnull__(2,3),
__leaf__)) __readlinkat_alias)(int __fd , char const   * __restrict  __path ,
                               char * __restrict  __buf , size_t __len )  __asm__("readlinkat")  ;
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__warn_unused_result__,
__nonnull__(2,3),
__leaf__)) __readlinkat_chk_warn)(int __fd , char const   * __restrict  __path ,
                                  char * __restrict  __buf , size_t __len ,
                                  size_t __buflen )  __asm__("__readlinkat_chk") __attribute__((__warning__("readlinkat called with bigger length than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(2,3), __leaf__, __artificial__,
__always_inline__)) readlinkat)(int __fd , char const   * __restrict  __path ,
                                char * __restrict  __buf , size_t __len ) ;
__inline extern ssize_t __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(2,3), __leaf__, __artificial__,
__always_inline__)) readlinkat)(int __fd , char const   * __restrict  __path ,
                                char * __restrict  __buf , size_t __len ) 
{ 
  unsigned long tmp ;
  ssize_t tmp___0 ;
  unsigned long tmp___1 ;
  ssize_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  ssize_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __readlinkat_chk(__fd, __path, __buf, __len, tmp);
    return ((ssize_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__len > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __readlinkat_chk_warn(__fd, __path, __buf, __len, tmp___1);
      return ((ssize_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __readlinkat_alias(__fd, __path, __buf, __len);
  return ((ssize_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__leaf__)) __getcwd_chk)(char *__buf , size_t __size , size_t __buflen ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__leaf__)) __getcwd_alias)(char *__buf , size_t __size )  __asm__("getcwd")  ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__leaf__)) __getcwd_chk_warn)(char *__buf , size_t __size , size_t __buflen )  __asm__("__getcwd_chk") __attribute__((__warning__("getcwd caller with bigger length than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) getcwd)(char *__buf , size_t __size ) ;
__inline extern char __attribute__((__gnu_inline__))  *( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) getcwd)(char *__buf , size_t __size ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  char *tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __getcwd_chk(__buf, __size, tmp);
    return ((char __attribute__((__gnu_inline__))  *)tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__size > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __getcwd_chk_warn(__buf, __size, tmp___1);
      return ((char __attribute__((__gnu_inline__))  *)tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __getcwd_alias(__buf, __size);
  return ((char __attribute__((__gnu_inline__))  *)tmp___5);
}
}
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) __getwd_chk)(char *__buf , size_t buflen ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) __getwd_warn)(char *__buf )  __asm__("getwd") __attribute__((__warning__("please use getcwd instead, as getwd doesn\'t specify buffer size"))) ;
__inline extern  __attribute__((__nothrow__)) char __attribute__((__gnu_inline__,
__deprecated__))  *( __attribute__((__warn_unused_result__, __nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) getwd)(char *__buf )  __attribute__((__deprecated__)) ;
__inline extern char __attribute__((__gnu_inline__,
__deprecated__))  *( __attribute__((__warn_unused_result__, __nonnull__(1),
__leaf__, __artificial__, __always_inline__)) getwd)(char *__buf ) 
{ 
  unsigned long tmp ;
  char *tmp___0 ;
  unsigned long tmp___1 ;
  char *tmp___2 ;

  {
  tmp___1 = __builtin_object_size((void *)__buf, 1);
  if (tmp___1 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __getwd_chk(__buf, tmp);
    return ((char __attribute__((__gnu_inline__, __deprecated__))  *)tmp___0);
  } else {

  }
  tmp___2 = __getwd_warn(__buf);
  return ((char __attribute__((__gnu_inline__, __deprecated__))  *)tmp___2);
}
}
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __confstr_chk)(int __name ,
                                                                                       char *__buf ,
                                                                                       size_t __len ,
                                                                                       size_t __buflen ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __confstr_alias)(int __name ,
                                                                                         char *__buf ,
                                                                                         size_t __len )  __asm__("confstr")  ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) __confstr_chk_warn)(int __name ,
                                                                                            char *__buf ,
                                                                                            size_t __len ,
                                                                                            size_t __buflen )  __asm__("__confstr_chk") __attribute__((__warning__("confstr called with bigger length than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) confstr)(int __name , char *__buf ,
                                             size_t __len ) ;
__inline extern size_t __attribute__((__gnu_inline__))  ( __attribute__((__leaf__,
__artificial__, __always_inline__)) confstr)(int __name , char *__buf ,
                                             size_t __len ) 
{ 
  unsigned long tmp ;
  size_t tmp___0 ;
  unsigned long tmp___1 ;
  size_t tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  size_t tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __confstr_chk(__name, __buf, __len, tmp);
    return ((size_t __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (tmp___3 < __len) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __confstr_chk_warn(__name, __buf, __len, tmp___1);
      return ((size_t __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __confstr_alias(__name, __buf, __len);
  return ((size_t __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __getgroups_chk)(int __size , __gid_t *__list , size_t __listlen ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __getgroups_alias)(int __size , __gid_t *__list )  __asm__("getgroups")  ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__leaf__)) __getgroups_chk_warn)(int __size , __gid_t *__list ,
                                 size_t __listlen )  __asm__("__getgroups_chk") __attribute__((__warning__("getgroups called with bigger group count than what can fit into destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) getgroups)(int __size , __gid_t *__list ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__leaf__, __artificial__,
__always_inline__)) getgroups)(int __size , __gid_t *__list ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__list, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__list, 1);
    tmp___0 = __getgroups_chk(__size, __list, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__list, 1);
    if ((unsigned long )__size * sizeof(__gid_t ) > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__list, 1);
      tmp___2 = __getgroups_chk_warn(__size, __list, tmp___1);
      return ((int __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __getgroups_alias(__size, __list);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ttyname_r_chk)(int __fd , char *__buf , size_t __buflen ,
                            size_t __nreal ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ttyname_r_alias)(int __fd , char *__buf , size_t __buflen )  __asm__("ttyname_r")  ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2),
__leaf__)) __ttyname_r_chk_warn)(int __fd , char *__buf , size_t __buflen ,
                                 size_t __nreal )  __asm__("__ttyname_r_chk") __attribute__((__warning__("ttyname_r called with bigger buflen than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(2), __leaf__, __artificial__,
__always_inline__)) ttyname_r)(int __fd , char *__buf , size_t __buflen ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(2), __leaf__, __artificial__,
__always_inline__)) ttyname_r)(int __fd , char *__buf , size_t __buflen ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __ttyname_r_chk(__fd, __buf, __buflen, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__buflen > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __ttyname_r_chk_warn(__fd, __buf, __buflen, tmp___1);
      return ((int __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __ttyname_r_alias(__fd, __buf, __buflen);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern int ( __attribute__((__nonnull__(1))) __getlogin_r_chk)(char *__buf ,
                                                               size_t __buflen ,
                                                               size_t __nreal ) ;
extern int ( __attribute__((__nonnull__(1))) __getlogin_r_alias)(char *__buf ,
                                                                 size_t __buflen )  __asm__("getlogin_r")  ;
extern int ( __attribute__((__nonnull__(1))) __getlogin_r_chk_warn)(char *__buf ,
                                                                    size_t __buflen ,
                                                                    size_t __nreal )  __asm__("__getlogin_r_chk") __attribute__((__warning__("getlogin_r called with bigger buflen than size of destination buffer"))) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__artificial__, __always_inline__)) getlogin_r)(char *__buf , size_t __buflen ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __getlogin_r_chk(__buf, __buflen, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__buflen > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __getlogin_r_chk_warn(__buf, __buflen, tmp___1);
      return ((int __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __getlogin_r_alias(__buf, __buflen);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1),
__leaf__)) __gethostname_chk)(char *__buf , size_t __buflen , size_t __nreal ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1),
__leaf__)) __gethostname_alias)(char *__buf , size_t __buflen )  __asm__("gethostname")  ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1),
__leaf__)) __gethostname_chk_warn)(char *__buf , size_t __buflen ,
                                   size_t __nreal )  __asm__("__gethostname_chk") __attribute__((__warning__("gethostname called with bigger buflen than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) gethostname)(char *__buf , size_t __buflen ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__, __artificial__,
__always_inline__)) gethostname)(char *__buf , size_t __buflen ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __gethostname_chk(__buf, __buflen, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__buflen > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __gethostname_chk_warn(__buf, __buflen, tmp___1);
      return ((int __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __gethostname_alias(__buf, __buflen);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__)) __getdomainname_chk)(char *__buf , size_t __buflen ,
                                                size_t __nreal ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) __getdomainname_alias)(char *__buf , size_t __buflen )  __asm__("getdomainname")  ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__warn_unused_result__,
__nonnull__(1),
__leaf__)) __getdomainname_chk_warn)(char *__buf , size_t __buflen ,
                                     size_t __nreal )  __asm__("__getdomainname_chk") __attribute__((__warning__("getdomainname called with bigger buflen than size of destination buffer"))) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__, __artificial__,
__always_inline__)) getdomainname)(char *__buf , size_t __buflen ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__warn_unused_result__,
__nonnull__(1), __leaf__, __artificial__,
__always_inline__)) getdomainname)(char *__buf , size_t __buflen ) 
{ 
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;
  unsigned long tmp___3 ;
  unsigned long tmp___4 ;
  int tmp___5 ;

  {
  tmp___4 = __builtin_object_size((void *)__buf, 1);
  if (tmp___4 != 0xffffffffffffffffUL) {
    tmp = __builtin_object_size((void *)__buf, 1);
    tmp___0 = __getdomainname_chk(__buf, __buflen, tmp);
    return ((int __attribute__((__gnu_inline__))  )tmp___0);
    tmp___3 = __builtin_object_size((void *)__buf, 1);
    if (__buflen > tmp___3) {
      tmp___1 = __builtin_object_size((void *)__buf, 1);
      tmp___2 = __getdomainname_chk_warn(__buf, __buflen, tmp___1);
      return ((int __attribute__((__gnu_inline__))  )tmp___2);
    } else {

    }
  } else {

  }
  tmp___5 = __getdomainname_alias(__buf, __buflen);
  return ((int __attribute__((__gnu_inline__))  )tmp___5);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) stat)(char const   * __restrict  __path ,
                 struct stat * __restrict  __statbuf ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) fstat)(int __fd , struct stat *__statbuf ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) stat64)(char const   * __restrict  __path ,
                   struct stat64 * __restrict  __statbuf ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) fstat64)(int __fd , struct stat64 *__statbuf ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2,3),
__leaf__)) fstatat)(int __fd , char const   * __restrict  __filename ,
                    struct stat * __restrict  __statbuf , int __flag ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2,3),
__leaf__)) fstatat64)(int __fd , char const   * __restrict  __filename ,
                      struct stat64 * __restrict  __statbuf , int __flag ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) lstat)(char const   * __restrict  __path ,
                  struct stat * __restrict  __statbuf ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) lstat64)(char const   * __restrict  __path ,
                    struct stat64 * __restrict  __statbuf ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__)) mknod)(char const   *__path , __mode_t __mode , __dev_t __dev ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) mknodat)(int __fd , char const   *__path , __mode_t __mode ,
                    __dev_t __dev ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3),
__leaf__)) __fxstat)(int __ver , int __fildes , struct stat *__stat_buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,3),
__leaf__)) __xstat)(int __ver , char const   *__filename ,
                    struct stat *__stat_buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,3),
__leaf__)) __lxstat)(int __ver , char const   *__filename ,
                     struct stat *__stat_buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3,4),
__leaf__)) __fxstatat)(int __ver , int __fildes , char const   *__filename ,
                       struct stat *__stat_buf , int __flag ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3),
__leaf__)) __fxstat64)(int __ver , int __fildes , struct stat64 *__stat_buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,3),
__leaf__)) __xstat64)(int __ver , char const   *__filename ,
                      struct stat64 *__stat_buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,3),
__leaf__)) __lxstat64)(int __ver , char const   *__filename ,
                       struct stat64 *__stat_buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3,4),
__leaf__)) __fxstatat64)(int __ver , int __fildes , char const   *__filename ,
                         struct stat64 *__stat_buf , int __flag ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,4),
__leaf__)) __xmknod)(int __ver , char const   *__path , __mode_t __mode ,
                     __dev_t *__dev ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3,5),
__leaf__)) __xmknodat)(int __ver , int __fd , char const   *__path ,
                       __mode_t __mode , __dev_t *__dev ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) stat)(char const   * __restrict  __path ,
                 struct stat * __restrict  __statbuf ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) stat)(char const   * __restrict  __path ,
                 struct stat * __restrict  __statbuf ) 
{ 
  int tmp ;

  {
  tmp = __xstat(1, (char const   *)__path, (struct stat *)__statbuf);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) lstat)(char const   * __restrict  __path ,
                  struct stat * __restrict  __statbuf ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) lstat)(char const   * __restrict  __path ,
                  struct stat * __restrict  __statbuf ) 
{ 
  int tmp ;

  {
  tmp = __lxstat(1, (char const   *)__path, (struct stat *)__statbuf);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) fstat)(int __fd , struct stat *__statbuf ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) fstat)(int __fd , struct stat *__statbuf ) 
{ 
  int tmp ;

  {
  tmp = __fxstat(1, __fd, __statbuf);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2,3),
__leaf__)) fstatat)(int __fd , char const   * __restrict  __filename ,
                    struct stat * __restrict  __statbuf , int __flag ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2,3),
__leaf__)) fstatat)(int __fd , char const   * __restrict  __filename ,
                    struct stat * __restrict  __statbuf , int __flag ) 
{ 
  int tmp ;

  {
  tmp = __fxstatat(1, __fd, (char const   *)__filename,
                   (struct stat *)__statbuf, __flag);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__)) mknod)(char const   *__path , __mode_t __mode , __dev_t __dev ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1),
__leaf__)) mknod)(char const   *__path , __mode_t __mode , __dev_t __dev ) 
{ 
  int tmp ;

  {
  tmp = __xmknod(0, __path, __mode, & __dev);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) mknodat)(int __fd , char const   *__path , __mode_t __mode ,
                    __dev_t __dev ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) mknodat)(int __fd , char const   *__path , __mode_t __mode ,
                    __dev_t __dev ) 
{ 
  int tmp ;

  {
  tmp = __xmknodat(0, __fd, __path, __mode, & __dev);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) stat64)(char const   * __restrict  __path ,
                   struct stat64 * __restrict  __statbuf ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) stat64)(char const   * __restrict  __path ,
                   struct stat64 * __restrict  __statbuf ) 
{ 
  int tmp ;

  {
  tmp = __xstat64(1, (char const   *)__path, (struct stat64 *)__statbuf);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) lstat64)(char const   * __restrict  __path ,
                    struct stat64 * __restrict  __statbuf ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(1,2),
__leaf__)) lstat64)(char const   * __restrict  __path ,
                    struct stat64 * __restrict  __statbuf ) 
{ 
  int tmp ;

  {
  tmp = __lxstat64(1, (char const   *)__path, (struct stat64 *)__statbuf);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) fstat64)(int __fd , struct stat64 *__statbuf ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2),
__leaf__)) fstat64)(int __fd , struct stat64 *__statbuf ) 
{ 
  int tmp ;

  {
  tmp = __fxstat64(1, __fd, __statbuf);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2,3),
__leaf__)) fstatat64)(int __fd , char const   * __restrict  __filename ,
                      struct stat64 * __restrict  __statbuf , int __flag ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__nonnull__(2,3),
__leaf__)) fstatat64)(int __fd , char const   * __restrict  __filename ,
                      struct stat64 * __restrict  __statbuf , int __flag ) 
{ 
  int tmp ;

  {
  tmp = __fxstatat64(1, __fd, (char const   *)__filename,
                     (struct stat64 *)__statbuf, __flag);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
extern  __attribute__((__nothrow__)) __int32_t const   **( __attribute__((__leaf__)) __ctype_tolower_loc)(void)  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) __int32_t const   **( __attribute__((__leaf__)) __ctype_toupper_loc)(void)  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) tolower)(int __c ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) toupper)(int __c ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) tolower)(int __c ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) tolower)(int __c ) 
{ 
  __int32_t const   **tmp ;
  __int32_t tmp___0 ;

  {
  if (__c >= -128) {
    if (__c < 256) {
      tmp = __ctype_tolower_loc();
      tmp___0 = (__int32_t )*(*tmp + __c);
    } else {
      tmp___0 = (__int32_t )((__int32_t const   )__c);
    }
  } else {
    tmp___0 = (__int32_t )((__int32_t const   )__c);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) toupper)(int __c ) ;
__inline extern int __attribute__((__gnu_inline__))  ( __attribute__((__leaf__)) toupper)(int __c ) 
{ 
  __int32_t const   **tmp ;
  __int32_t tmp___0 ;

  {
  if (__c >= -128) {
    if (__c < 256) {
      tmp = __ctype_toupper_loc();
      tmp___0 = (__int32_t )*(*tmp + __c);
    } else {
      tmp___0 = (__int32_t )((__int32_t const   )__c);
    }
  } else {
    tmp___0 = (__int32_t )((__int32_t const   )__c);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___0);
}
}
extern void __attribute__((__visibility__("default")))  zend_multibyte_yyinput_again(size_t (*old_input_filter)(unsigned char **str ,
                                                                                                                size_t *str_length ,
                                                                                                                unsigned char const   *buf ,
                                                                                                                size_t length ) ,
                                                                                     zend_encoding const   *old_encoding ) ;
extern int __attribute__((__visibility__("default")))  zend_multibyte_set_filter(zend_encoding const   *onetime_encoding ) ;
static void zend_duplicate_property_info(zend_property_info *property_info ) 
{ 
  char __attribute__((__visibility__("default")))  *tmp ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;

  {
  if ((unsigned long )property_info->name >= (unsigned long )compiler_globals.interned_strings_start) {
    if (! ((unsigned long )property_info->name < (unsigned long )compiler_globals.interned_strings_end)) {
      tmp = _estrndup(property_info->name,
                      (unsigned int )property_info->name_length);
      property_info->name = (char const   *)tmp;
    } else {

    }
  } else {
    tmp = _estrndup(property_info->name,
                    (unsigned int )property_info->name_length);
    property_info->name = (char const   *)tmp;
  }
  if (property_info->doc_comment) {
    tmp___0 = _estrndup(property_info->doc_comment,
                        (unsigned int )property_info->doc_comment_len);
    property_info->doc_comment = (char const   *)tmp___0;
  } else {

  }
  return;
}
}
static void zend_duplicate_property_info_internal(zend_property_info *property_info ) 
{ 
  char __attribute__((__visibility__("default")))  *tmp ;

  {
  if ((unsigned long )property_info->name >= (unsigned long )compiler_globals.interned_strings_start) {
    if (! ((unsigned long )property_info->name < (unsigned long )compiler_globals.interned_strings_end)) {
      tmp = zend_strndup(property_info->name,
                         (unsigned int )property_info->name_length);
      property_info->name = (char const   *)tmp;
    } else {

    }
  } else {
    tmp = zend_strndup(property_info->name,
                       (unsigned int )property_info->name_length);
    property_info->name = (char const   *)tmp;
  }
  return;
}
}
static void zend_destroy_property_info(zend_property_info *property_info ) 
{ 


  {
  while (1) {
    if ((unsigned long )property_info->name >= (unsigned long )compiler_globals.interned_strings_start) {
      if (! ((unsigned long )property_info->name < (unsigned long )compiler_globals.interned_strings_end)) {
        _efree((void *)((char *)property_info->name));
      } else {

      }
    } else {
      _efree((void *)((char *)property_info->name));
    }
    break;
  }
  if (property_info->doc_comment) {
    _efree((void *)((char *)property_info->doc_comment));
  } else {

  }
  return;
}
}
static void zend_destroy_property_info_internal(zend_property_info *property_info ) 
{ 


  {
  while (1) {
    if ((unsigned long )((char *)property_info->name) >= (unsigned long )compiler_globals.interned_strings_start) {
      if (! ((unsigned long )((char *)property_info->name) < (unsigned long )compiler_globals.interned_strings_end)) {
        free((void *)((char *)property_info->name));
      } else {

      }
    } else {
      free((void *)((char *)property_info->name));
    }
    break;
  }
  return;
}
}
static void build_runtime_defined_function_key(zval *result ,
                                               char const   *name ,
                                               int name_length ) 
{ 
  char char_pos_buf[32] ;
  uint char_pos_len ;
  char const   *filename ;
  int __attribute__((__gnu_inline__))  tmp ;
  size_t tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;

  {
  tmp = sprintf((char */* __restrict  */)(char_pos_buf),
                (char const   */* __restrict  */)"%p",
                language_scanner_globals.yy_text);
  char_pos_len = (uint )tmp;
  if ((compiler_globals.active_op_array)->filename) {
    filename = (compiler_globals.active_op_array)->filename;
  } else {
    filename = "-";
  }
  tmp___0 = strlen(filename);
  result->value.str.len = (int )(((size_t )(1 + name_length) + tmp___0) + (size_t )char_pos_len);
  tmp___1 = _safe_emalloc((size_t )result->value.str.len, (size_t )1, (size_t )1);
  result->value.str.val = (char *)tmp___1;
  *(result->value.str.val + 0) = (char )'\000';
  sprintf((char */* __restrict  */)(result->value.str.val + 1),
          (char const   */* __restrict  */)"%s%s%s", name, filename,
          char_pos_buf);
  result->type = (zend_uchar )6;
  zval_set_refcount_p(result, (zend_uint )1);
  return;
}
}
static void init_compiler_declarables(void) 
{ 


  {
  compiler_globals.declarables.ticks.type = (zend_uchar )1;
  compiler_globals.declarables.ticks.value.lval = 0L;
  return;
}
}
void zend_init_compiler_context(void) 
{ 


  {
  if ((compiler_globals.active_op_array)->fn_flags & 16U) {
    compiler_globals.context.opcodes_size = (zend_uint )8192;
  } else {
    compiler_globals.context.opcodes_size = (zend_uint )64;
  }
  compiler_globals.context.vars_size = 0;
  compiler_globals.context.literals_size = 0;
  compiler_globals.context.current_brk_cont = -1;
  compiler_globals.context.backpatch_count = 0;
  compiler_globals.context.labels = (HashTable *)((void *)0);
  return;
}
}
void zend_init_compiler_data_structures(void) 
{ 


  {
  zend_stack_init(& compiler_globals.bp_stack);
  zend_stack_init(& compiler_globals.function_call_stack);
  zend_stack_init(& compiler_globals.switch_cond_stack);
  zend_stack_init(& compiler_globals.foreach_copy_stack);
  zend_stack_init(& compiler_globals.object_stack);
  zend_stack_init(& compiler_globals.declare_stack);
  compiler_globals.active_class_entry = (zend_class_entry *)((void *)0);
  zend_llist_init(& compiler_globals.list_llist, sizeof(list_llist_element ),
                  (void (*)(void * ))((void *)0), (unsigned char)0);
  zend_llist_init(& compiler_globals.dimension_llist, sizeof(int ),
                  (void (*)(void * ))((void *)0), (unsigned char)0);
  zend_stack_init(& compiler_globals.list_stack);
  compiler_globals.in_compilation = (zend_bool )0;
  compiler_globals.start_lineno = (zend_uint )0;
  compiler_globals.current_namespace = (zval *)((void *)0);
  compiler_globals.in_namespace = (zend_bool )0;
  compiler_globals.has_bracketed_namespaces = (zend_bool )0;
  compiler_globals.current_import = (HashTable *)((void *)0);
  init_compiler_declarables();
  zend_stack_init(& compiler_globals.context_stack);
  compiler_globals.encoding_declared = (zend_bool )0;
  return;
}
}
void __attribute__((__visibility__("default")))  file_handle_dtor(zend_file_handle *fh ) 
{ 


  {
  zend_file_handle_dtor(fh);
  return;
}
}
void init_compiler(void) 
{ 


  {
  compiler_globals.active_op_array = (zend_op_array *)((void *)0);
  zend_init_compiler_data_structures();
  zend_init_rsrc_list();
  _zend_hash_init(& compiler_globals.filenames_table, (uint )5,
                  (ulong (*)(char const   *arKey , uint nKeyLength ))((void *)0),
                  (void (*)(void *pDest ))(& free_estring), (zend_bool )0);
  zend_llist_init(& compiler_globals.open_files, sizeof(zend_file_handle ),
                  (void (*)(void * ))(& file_handle_dtor), (unsigned char)0);
  compiler_globals.unclean_shutdown = (zend_bool )0;
  return;
}
}
void shutdown_compiler(void) 
{ 


  {
  zend_stack_destroy(& compiler_globals.bp_stack);
  zend_stack_destroy(& compiler_globals.function_call_stack);
  zend_stack_destroy(& compiler_globals.switch_cond_stack);
  zend_stack_destroy(& compiler_globals.foreach_copy_stack);
  zend_stack_destroy(& compiler_globals.object_stack);
  zend_stack_destroy(& compiler_globals.declare_stack);
  zend_stack_destroy(& compiler_globals.list_stack);
  zend_hash_destroy(& compiler_globals.filenames_table);
  zend_llist_destroy(& compiler_globals.open_files);
  zend_stack_destroy(& compiler_globals.context_stack);
  return;
}
}
char __attribute__((__visibility__("default")))  *zend_set_compiled_filename(char const   *new_compiled_filename ) 
{ 
  char **pp ;
  char *p ;
  int length ;
  size_t tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;

  {
  tmp = strlen(new_compiled_filename);
  length = (int )tmp;
  tmp___0 = zend_hash_find((HashTable const   *)(& compiler_globals.filenames_table),
                           new_compiled_filename, (uint )(length + 1),
                           (void **)(& pp));
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )0) {
    compiler_globals.compiled_filename = *pp;
    return ((char __attribute__((__visibility__("default")))  *)*pp);
  } else {

  }
  tmp___1 = _estrndup(new_compiled_filename, (unsigned int )length);
  p = (char *)tmp___1;
  _zend_hash_add_or_update(& compiler_globals.filenames_table,
                           new_compiled_filename, (uint )(length + 1),
                           (void *)(& p), (uint )sizeof(char *),
                           (void **)(& pp), 1);
  compiler_globals.compiled_filename = p;
  return ((char __attribute__((__visibility__("default")))  *)p);
}
}
void __attribute__((__visibility__("default")))  zend_restore_compiled_filename(char *original_compiled_filename ) 
{ 


  {
  compiler_globals.compiled_filename = original_compiled_filename;
  return;
}
}
char __attribute__((__visibility__("default")))  *zend_get_compiled_filename(void) 
{ 


  {
  return ((char __attribute__((__visibility__("default")))  *)compiler_globals.compiled_filename);
}
}
int __attribute__((__visibility__("default")))  zend_get_compiled_lineno(void) 
{ 


  {
  return ((int __attribute__((__visibility__("default")))  )compiler_globals.zend_lineno);
}
}
zend_bool __attribute__((__visibility__("default")))  zend_is_compiling(void) 
{ 


  {
  return ((zend_bool __attribute__((__visibility__("default")))  )compiler_globals.in_compilation);
}
}
static zend_uint get_temporary_variable(zend_op_array *op_array ) 
{ 
  zend_uint tmp ;

  {
  tmp = op_array->T;
  (op_array->T) ++;
  return ((zend_uint )((unsigned long )tmp * (((sizeof(temp_variable ) + 8UL) - 1UL) & 0xfffffffffffffff8UL)));
}
}
static int lookup_cv(zend_op_array *op_array , char *name , int name_len ,
                     ulong hash ) 
{ 
  int i ;
  ulong hash_value ;
  ulong tmp ;
  ulong tmp___0 ;
  int tmp___1 ;
  void __attribute__((__visibility__("default")))  *tmp___2 ;
  char const __attribute__((__visibility__("default")))  *tmp___3 ;

  {
  i = 0;
  if (hash) {
    tmp___0 = hash;
  } else {
    tmp = zend_inline_hash_func((char const   *)name, (uint )(name_len + 1));
    tmp___0 = tmp;
  }
  hash_value = tmp___0;
  while (i < op_array->last_var) {
    if ((unsigned long )(op_array->vars + i)->name == (unsigned long )name) {
      goto _L;
    } else
    if ((op_array->vars + i)->hash_value == hash_value) {
      if ((op_array->vars + i)->name_len == name_len) {
        tmp___1 = memcmp((void const   *)(op_array->vars + i)->name,
                         (void const   *)name, (size_t )name_len);
        if (tmp___1 == 0) {
          _L: 
          while (1) {
            if ((unsigned long )name >= (unsigned long )compiler_globals.interned_strings_start) {
              if (! ((unsigned long )name < (unsigned long )compiler_globals.interned_strings_end)) {
                _efree((void *)name);
              } else {

              }
            } else {
              _efree((void *)name);
            }
            break;
          }
          return (i);
        } else {

        }
      } else {

      }
    } else {

    }
    i ++;
  }
  i = op_array->last_var;
  (op_array->last_var) ++;
  if (op_array->last_var > compiler_globals.context.vars_size) {
    compiler_globals.context.vars_size += 16;
    tmp___2 = _erealloc((void *)op_array->vars,
                        (unsigned long )compiler_globals.context.vars_size * sizeof(zend_compiled_variable ),
                        0);
    op_array->vars = (zend_compiled_variable *)tmp___2;
  } else {

  }
  tmp___3 = (*zend_new_interned_string)((char const   *)name, name_len + 1, 1);
  (op_array->vars + i)->name = (char const   *)tmp___3;
  (op_array->vars + i)->name_len = name_len;
  (op_array->vars + i)->hash_value = hash_value;
  return (i);
}
}
void zend_del_literal(zend_op_array *op_array , int n ) 
{ 


  {
  _zval_dtor(& (op_array->literals + n)->constant);
  if (n + 1 == op_array->last_literal) {
    (op_array->last_literal) --;
  } else {
    (op_array->literals + n)->constant.type = (zend_uchar )0;
  }
  return;
}
}
__inline static void zend_insert_literal(zend_op_array *op_array ,
                                         zval const   *zv ,
                                         int literal_position ) 
{ 
  zval *z ;
  char const __attribute__((__visibility__("default")))  *tmp ;

  {
  if ((int const   )zv->type == 6) {
    z = (zval *)zv;
    tmp = (*zend_new_interned_string)((char const   *)zv->value.str.val,
                                      (int )(zv->value.str.len + 1), 1);
    z->value.str.val = (char *)tmp;
  } else
  if ((int const   )zv->type == 8) {
    z = (zval *)zv;
    tmp = (*zend_new_interned_string)((char const   *)zv->value.str.val,
                                      (int )(zv->value.str.len + 1), 1);
    z->value.str.val = (char *)tmp;
  } else {

  }
  (op_array->literals + literal_position)->constant = (zval )*zv;
  zval_set_refcount_p(& (op_array->literals + literal_position)->constant,
                      (zend_uint )2);
  zval_set_isref_p(& (op_array->literals + literal_position)->constant);
  (op_array->literals + literal_position)->hash_value = (zend_ulong )0;
  (op_array->literals + literal_position)->cache_slot = (zend_uint )-1;
  return;
}
}
int zend_add_literal(zend_op_array *op_array , zval const   *zv ) 
{ 
  int i ;
  void __attribute__((__visibility__("default")))  *tmp ;

  {
  i = op_array->last_literal;
  (op_array->last_literal) ++;
  if (i >= compiler_globals.context.literals_size) {
    while (i >= compiler_globals.context.literals_size) {
      compiler_globals.context.literals_size += 16;
    }
    tmp = _erealloc((void *)op_array->literals,
                    (unsigned long )compiler_globals.context.literals_size * sizeof(zend_literal ),
                    0);
    op_array->literals = (zend_literal *)tmp;
  } else {

  }
  zend_insert_literal(op_array, zv, i);
  return (i);
}
}
int zend_append_individual_literal(zend_op_array *op_array , zval const   *zv ) 
{ 
  int i ;
  void __attribute__((__visibility__("default")))  *tmp ;

  {
  i = op_array->last_literal;
  (op_array->last_literal) ++;
  tmp = _erealloc((void *)op_array->literals,
                  (unsigned long )(i + 1) * sizeof(zend_literal ), 0);
  op_array->literals = (zend_literal *)tmp;
  zend_insert_literal(op_array, zv, i);
  return (i);
}
}
int zend_add_func_name_literal(zend_op_array *op_array , zval const   *zv ) 
{ 
  int ret ;
  char *lc_name ;
  zval c ;
  int lc_literal ;
  char __attribute__((__visibility__("default")))  *tmp ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  ulong __attribute__((__visibility__("default")))  tmp___1 ;

  {
  if (op_array->last_literal > 0) {
    if ((unsigned long )(& (op_array->literals + (op_array->last_literal - 1))->constant) == (unsigned long )zv) {
      if ((op_array->literals + (op_array->last_literal - 1))->cache_slot == 4294967295U) {
        ret = op_array->last_literal - 1;
      } else {
        ret = zend_add_literal(op_array, zv);
      }
    } else {
      ret = zend_add_literal(op_array, zv);
    }
  } else {
    ret = zend_add_literal(op_array, zv);
  }
  tmp = zend_str_tolower_dup((char const   *)zv->value.str.val,
                             (unsigned int )zv->value.str.len);
  lc_name = (char *)tmp;
  while (1) {
    __s = (char const   *)lc_name;
    __l = (int )zv->value.str.len;
    __z = & c;
    __z->value.str.len = __l;
    __z->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z->type = (zend_uchar )6;
    break;
  }
  lc_literal = zend_add_literal(compiler_globals.active_op_array,
                                (zval const   *)(& c));
  while (1) {
    if ((unsigned long )((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
      if ((unsigned long )((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end) {
        ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + lc_literal)->constant))->hash_value = ((Bucket *)(((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.val - sizeof(Bucket )))->h;
      } else {
        tmp___1 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.val,
                                 (uint )(((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.len + 1));
        ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + lc_literal)->constant))->hash_value = (zend_ulong )tmp___1;
      }
    } else {
      tmp___1 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.val,
                               (uint )(((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.len + 1));
      ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + lc_literal)->constant))->hash_value = (zend_ulong )tmp___1;
    }
    break;
  }
  return (ret);
}
}
int zend_add_ns_func_name_literal(zend_op_array *op_array , zval const   *zv ) 
{ 
  int ret ;
  char *lc_name ;
  char const   *ns_separator ;
  int lc_len ;
  zval c ;
  int lc_literal ;
  char __attribute__((__visibility__("default")))  *tmp ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  ulong __attribute__((__visibility__("default")))  tmp___1 ;
  void const   *tmp___2 ;
  char __attribute__((__visibility__("default")))  *tmp___3 ;
  char const   *__s___0 ;
  int __l___0 ;
  zval *__z___0 ;
  ulong __attribute__((__visibility__("default")))  tmp___5 ;

  {
  if (op_array->last_literal > 0) {
    if ((unsigned long )(& (op_array->literals + (op_array->last_literal - 1))->constant) == (unsigned long )zv) {
      if ((op_array->literals + (op_array->last_literal - 1))->cache_slot == 4294967295U) {
        ret = op_array->last_literal - 1;
      } else {
        ret = zend_add_literal(op_array, zv);
      }
    } else {
      ret = zend_add_literal(op_array, zv);
    }
  } else {
    ret = zend_add_literal(op_array, zv);
  }
  tmp = zend_str_tolower_dup((char const   *)zv->value.str.val,
                             (unsigned int )zv->value.str.len);
  lc_name = (char *)tmp;
  while (1) {
    __s = (char const   *)lc_name;
    __l = (int )zv->value.str.len;
    __z = & c;
    __z->value.str.len = __l;
    __z->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z->type = (zend_uchar )6;
    break;
  }
  lc_literal = zend_add_literal(compiler_globals.active_op_array,
                                (zval const   *)(& c));
  while (1) {
    if ((unsigned long )((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
      if ((unsigned long )((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end) {
        ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + lc_literal)->constant))->hash_value = ((Bucket *)(((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.val - sizeof(Bucket )))->h;
      } else {
        tmp___1 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.val,
                                 (uint )(((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.len + 1));
        ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + lc_literal)->constant))->hash_value = (zend_ulong )tmp___1;
      }
    } else {
      tmp___1 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.val,
                               (uint )(((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.len + 1));
      ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + lc_literal)->constant))->hash_value = (zend_ulong )tmp___1;
    }
    break;
  }
  tmp___2 = zend_memrchr((void const   *)zv->value.str.val, '\\',
                         (size_t )zv->value.str.len);
  ns_separator = (char const   *)tmp___2 + 1;
  lc_len = (int )((long )zv->value.str.len - (ns_separator - (char const   *)zv->value.str.val));
  tmp___3 = zend_str_tolower_dup(ns_separator, (unsigned int )lc_len);
  lc_name = (char *)tmp___3;
  while (1) {
    __s___0 = (char const   *)lc_name;
    __l___0 = lc_len;
    __z___0 = & c;
    __z___0->value.str.len = __l___0;
    __z___0->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s___0));
    __z___0->type = (zend_uchar )6;
    break;
  }
  lc_literal = zend_add_literal(compiler_globals.active_op_array,
                                (zval const   *)(& c));
  while (1) {
    if ((unsigned long )((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
      if ((unsigned long )((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end) {
        ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + lc_literal)->constant))->hash_value = ((Bucket *)(((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.val - sizeof(Bucket )))->h;
      } else {
        tmp___5 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.val,
                                 (uint )(((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.len + 1));
        ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + lc_literal)->constant))->hash_value = (zend_ulong )tmp___5;
      }
    } else {
      tmp___5 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.val,
                               (uint )(((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.len + 1));
      ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + lc_literal)->constant))->hash_value = (zend_ulong )tmp___5;
    }
    break;
  }
  return (ret);
}
}
int zend_add_class_name_literal(zend_op_array *op_array , zval const   *zv ) 
{ 
  int ret ;
  char *lc_name ;
  int lc_len ;
  zval c ;
  int lc_literal ;
  char __attribute__((__visibility__("default")))  *tmp ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  ulong __attribute__((__visibility__("default")))  tmp___2 ;
  int tmp___3 ;
  void __attribute__((__visibility__("default")))  *tmp___4 ;

  {
  if (op_array->last_literal > 0) {
    if ((unsigned long )(& (op_array->literals + (op_array->last_literal - 1))->constant) == (unsigned long )zv) {
      if ((op_array->literals + (op_array->last_literal - 1))->cache_slot == 4294967295U) {
        ret = op_array->last_literal - 1;
      } else {
        ret = zend_add_literal(op_array, zv);
      }
    } else {
      ret = zend_add_literal(op_array, zv);
    }
  } else {
    ret = zend_add_literal(op_array, zv);
  }
  if ((int )*(zv->value.str.val + 0) == 92) {
    lc_len = (int )(zv->value.str.len - 1);
    tmp = zend_str_tolower_dup((char const   *)(zv->value.str.val + 1),
                               (unsigned int )lc_len);
    lc_name = (char *)tmp;
  } else {
    lc_len = (int )zv->value.str.len;
    tmp___0 = zend_str_tolower_dup((char const   *)zv->value.str.val,
                                   (unsigned int )lc_len);
    lc_name = (char *)tmp___0;
  }
  while (1) {
    __s = (char const   *)lc_name;
    __l = lc_len;
    __z = & c;
    __z->value.str.len = __l;
    __z->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
    __z->type = (zend_uchar )6;
    break;
  }
  lc_literal = zend_add_literal(compiler_globals.active_op_array,
                                (zval const   *)(& c));
  while (1) {
    if ((unsigned long )((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
      if ((unsigned long )((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end) {
        ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + lc_literal)->constant))->hash_value = ((Bucket *)(((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.val - sizeof(Bucket )))->h;
      } else {
        tmp___2 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.val,
                                 (uint )(((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.len + 1));
        ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + lc_literal)->constant))->hash_value = (zend_ulong )tmp___2;
      }
    } else {
      tmp___2 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.val,
                               (uint )(((compiler_globals.active_op_array)->literals + lc_literal)->constant.value.str.len + 1));
      ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + lc_literal)->constant))->hash_value = (zend_ulong )tmp___2;
    }
    break;
  }
  while (1) {
    tmp___3 = (compiler_globals.active_op_array)->last_cache_slot;
    ((compiler_globals.active_op_array)->last_cache_slot) ++;
    ((compiler_globals.active_op_array)->literals + ret)->cache_slot = (zend_uint )tmp___3;
    if ((compiler_globals.active_op_array)->fn_flags & 16U) {
      if ((compiler_globals.active_op_array)->run_time_cache) {
        tmp___4 = _erealloc((void *)(compiler_globals.active_op_array)->run_time_cache,
                            (unsigned long )(compiler_globals.active_op_array)->last_cache_slot * sizeof(void *),
                            0);
        (compiler_globals.active_op_array)->run_time_cache = (void **)tmp___4;
        *((compiler_globals.active_op_array)->run_time_cache + ((compiler_globals.active_op_array)->last_cache_slot - 1)) = (void *)0;
      } else {

      }
    } else {

    }
    break;
  }
  return (ret);
}
}
int zend_add_const_name_literal(zend_op_array *op_array , zval const   *zv ,
                                int unqualified ) 
{ 
  int ret ;
  int tmp_literal ;
  char *name ;
  char *tmp_name ;
  char const   *ns_separator ;
  int name_len ;
  int ns_len ;
  zval c ;
  void const   *tmp ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  ulong __attribute__((__visibility__("default")))  tmp___2 ;
  char __attribute__((__visibility__("default")))  *tmp___3 ;
  char const   *__s___0 ;
  int __l___0 ;
  zval *__z___0 ;
  ulong __attribute__((__visibility__("default")))  tmp___5 ;
  char __attribute__((__visibility__("default")))  *tmp___6 ;
  char const   *__s___1 ;
  int __l___1 ;
  zval *__z___1 ;
  ulong __attribute__((__visibility__("default")))  tmp___8 ;
  char __attribute__((__visibility__("default")))  *tmp___9 ;
  char const   *__s___2 ;
  int __l___2 ;
  zval *__z___2 ;
  ulong __attribute__((__visibility__("default")))  tmp___11 ;

  {
  if (op_array->last_literal > 0) {
    if ((unsigned long )(& (op_array->literals + (op_array->last_literal - 1))->constant) == (unsigned long )zv) {
      if ((op_array->literals + (op_array->last_literal - 1))->cache_slot == 4294967295U) {
        ret = op_array->last_literal - 1;
      } else {
        ret = zend_add_literal(op_array, zv);
      }
    } else {
      ret = zend_add_literal(op_array, zv);
    }
  } else {
    ret = zend_add_literal(op_array, zv);
  }
  if ((int )*(zv->value.str.val + 0) == 92) {
    name_len = (int )(zv->value.str.len - 1);
    name = (char *)(zv->value.str.val + 1);
  } else {
    name_len = (int )zv->value.str.len;
    name = (char *)zv->value.str.val;
  }
  tmp = zend_memrchr((void const   *)name, '\\', (size_t )name_len);
  ns_separator = (char const   *)tmp;
  if (ns_separator) {
    ns_len = (int )(ns_separator - (char const   *)name);
  } else {
    ns_len = 0;
  }
  if (ns_len) {
    tmp___0 = _estrndup((char const   *)name, (unsigned int )name_len);
    tmp_name = (char *)tmp___0;
    zend_str_tolower(tmp_name, (unsigned int )ns_len);
    while (1) {
      __s = (char const   *)tmp_name;
      __l = name_len;
      __z = & c;
      __z->value.str.len = __l;
      __z->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
      __z->type = (zend_uchar )6;
      break;
    }
    tmp_literal = zend_add_literal(compiler_globals.active_op_array,
                                   (zval const   *)(& c));
    while (1) {
      if ((unsigned long )((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
        if ((unsigned long )((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end) {
          ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + tmp_literal)->constant))->hash_value = ((Bucket *)(((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.val - sizeof(Bucket )))->h;
        } else {
          tmp___2 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.val,
                                   (uint )(((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.len + 1));
          ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + tmp_literal)->constant))->hash_value = (zend_ulong )tmp___2;
        }
      } else {
        tmp___2 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.val,
                                 (uint )(((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.len + 1));
        ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + tmp_literal)->constant))->hash_value = (zend_ulong )tmp___2;
      }
      break;
    }
    tmp___3 = zend_str_tolower_dup((char const   *)name, (unsigned int )name_len);
    tmp_name = (char *)tmp___3;
    while (1) {
      __s___0 = (char const   *)tmp_name;
      __l___0 = name_len;
      __z___0 = & c;
      __z___0->value.str.len = __l___0;
      __z___0->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s___0));
      __z___0->type = (zend_uchar )6;
      break;
    }
    tmp_literal = zend_add_literal(compiler_globals.active_op_array,
                                   (zval const   *)(& c));
    while (1) {
      if ((unsigned long )((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
        if ((unsigned long )((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end) {
          ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + tmp_literal)->constant))->hash_value = ((Bucket *)(((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.val - sizeof(Bucket )))->h;
        } else {
          tmp___5 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.val,
                                   (uint )(((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.len + 1));
          ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + tmp_literal)->constant))->hash_value = (zend_ulong )tmp___5;
        }
      } else {
        tmp___5 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.val,
                                 (uint )(((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.len + 1));
        ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + tmp_literal)->constant))->hash_value = (zend_ulong )tmp___5;
      }
      break;
    }
  } else {

  }
  if (ns_len) {
    if (! unqualified) {
      return (ret);
    } else {

    }
    ns_len ++;
    name += ns_len;
    name_len -= ns_len;
  } else {

  }
  tmp___6 = _estrndup((char const   *)name, (unsigned int )name_len);
  tmp_name = (char *)tmp___6;
  while (1) {
    __s___1 = (char const   *)tmp_name;
    __l___1 = name_len;
    __z___1 = & c;
    __z___1->value.str.len = __l___1;
    __z___1->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s___1));
    __z___1->type = (zend_uchar )6;
    break;
  }
  tmp_literal = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& c));
  while (1) {
    if ((unsigned long )((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
      if ((unsigned long )((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end) {
        ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + tmp_literal)->constant))->hash_value = ((Bucket *)(((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.val - sizeof(Bucket )))->h;
      } else {
        tmp___8 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.val,
                                 (uint )(((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.len + 1));
        ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + tmp_literal)->constant))->hash_value = (zend_ulong )tmp___8;
      }
    } else {
      tmp___8 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.val,
                               (uint )(((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.len + 1));
      ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + tmp_literal)->constant))->hash_value = (zend_ulong )tmp___8;
    }
    break;
  }
  tmp___9 = zend_str_tolower_dup((char const   *)name, (unsigned int )name_len);
  tmp_name = (char *)tmp___9;
  while (1) {
    __s___2 = (char const   *)tmp_name;
    __l___2 = name_len;
    __z___2 = & c;
    __z___2->value.str.len = __l___2;
    __z___2->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s___2));
    __z___2->type = (zend_uchar )6;
    break;
  }
  tmp_literal = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& c));
  while (1) {
    if ((unsigned long )((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
      if ((unsigned long )((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end) {
        ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + tmp_literal)->constant))->hash_value = ((Bucket *)(((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.val - sizeof(Bucket )))->h;
      } else {
        tmp___11 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.val,
                                  (uint )(((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.len + 1));
        ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + tmp_literal)->constant))->hash_value = (zend_ulong )tmp___11;
      }
    } else {
      tmp___11 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.val,
                                (uint )(((compiler_globals.active_op_array)->literals + tmp_literal)->constant.value.str.len + 1));
      ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + tmp_literal)->constant))->hash_value = (zend_ulong )tmp___11;
    }
    break;
  }
  return (ret);
}
}
__inline static zend_bool zend_is_function_or_method_call(znode const   *variable ) 
{ 
  zend_uint type ;
  int tmp ;

  {
  type = (zend_uint )variable->EA;
  if (type & (unsigned int )(1 << 1)) {
    tmp = 1;
  } else
  if (type == (zend_uint )(1 << 3)) {
    tmp = 1;
  } else {
    tmp = 0;
  }
  return ((zend_bool )tmp);
}
}
void zend_do_binary_op(zend_uchar op , znode *result , znode const   *op1 ,
                       znode const   *op2 ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;
  int tmp___1 ;
  znode_op __constr_expr_0 ;
  znode_op __constr_expr_1 ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  opline->opcode = op;
  opline->result_type = (zend_uchar )(1 << 1);
  opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  while (1) {
    opline->op1_type = (zend_uchar )op1->op_type;
    if (op1->op_type == 1) {
      tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                 & op1->u.constant);
      opline->op1.constant = (zend_uint )tmp___0;
    } else {
      __constr_expr_0 = op1->u.op;
      opline->op1 = __constr_expr_0;
    }
    break;
  }
  while (1) {
    opline->op2_type = (zend_uchar )op2->op_type;
    if (op2->op_type == 1) {
      tmp___1 = zend_add_literal(compiler_globals.active_op_array,
                                 & op2->u.constant);
      opline->op2.constant = (zend_uint )tmp___1;
    } else {
      __constr_expr_1 = op2->u.op;
      opline->op2 = __constr_expr_1;
    }
    break;
  }
  while (1) {
    result->op_type = (int )opline->result_type;
    if (result->op_type == 1) {
      result->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      result->u.op = opline->result;
      result->EA = (zend_uint )0;
    }
    break;
  }
  return;
}
}
void zend_do_unary_op(zend_uchar op , znode *result , znode const   *op1 ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;
  znode_op __constr_expr_2 ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  opline->opcode = op;
  opline->result_type = (zend_uchar )(1 << 1);
  opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  while (1) {
    opline->op1_type = (zend_uchar )op1->op_type;
    if (op1->op_type == 1) {
      tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                 & op1->u.constant);
      opline->op1.constant = (zend_uint )tmp___0;
    } else {
      __constr_expr_2 = op1->u.op;
      opline->op1 = __constr_expr_2;
    }
    break;
  }
  while (1) {
    result->op_type = (int )opline->result_type;
    if (result->op_type == 1) {
      result->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      result->u.op = opline->result;
      result->EA = (zend_uint )0;
    }
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  return;
}
}
static void zend_do_op_data(zend_op *data_op , znode const   *value ) 
{ 
  int tmp ;
  znode_op __constr_expr_3 ;

  {
  data_op->opcode = (zend_uchar )137;
  while (1) {
    data_op->op1_type = (zend_uchar )value->op_type;
    if (value->op_type == 1) {
      tmp = zend_add_literal(compiler_globals.active_op_array,
                             & value->u.constant);
      data_op->op1.constant = (zend_uint )tmp;
    } else {
      __constr_expr_3 = value->u.op;
      data_op->op1 = __constr_expr_3;
    }
    break;
  }
  data_op->op2_type = (zend_uchar )(1 << 3);
  return;
}
}
void zend_do_binary_assign_op(zend_uchar op , znode *result ,
                              znode const   *op1 , znode const   *op2 ) 
{ 
  int last_op_number ;
  int tmp ;
  zend_op *opline ;
  zend_op *tmp___0 ;
  zend_op *last_op ;
  int tmp___1 ;
  int tmp___2 ;
  znode_op __constr_expr_4 ;
  znode_op __constr_expr_5 ;

  {
  tmp = get_next_op_number(compiler_globals.active_op_array);
  last_op_number = tmp;
  tmp___0 = get_next_op(compiler_globals.active_op_array);
  opline = tmp___0;
  if (last_op_number > 0) {
    last_op = (compiler_globals.active_op_array)->opcodes + (last_op_number - 1);
    switch ((int )last_op->opcode) {
    case 88: 
    last_op->opcode = op;
    last_op->extended_value = (ulong )136;
    zend_do_op_data(opline, op2);
    opline->result_type = (zend_uchar )(1 << 3);
    while (1) {
      result->op_type = (int )last_op->result_type;
      if (result->op_type == 1) {
        result->u.constant = ((compiler_globals.active_op_array)->literals + last_op->result.constant)->constant;
      } else {
        result->u.op = last_op->result;
        result->EA = (zend_uint )0;
      }
      break;
    }
    return;
    case 87: 
    last_op->opcode = op;
    last_op->extended_value = (ulong )147;
    zend_do_op_data(opline, op2);
    opline->op2.var = get_temporary_variable(compiler_globals.active_op_array);
    opline->op2_type = (zend_uchar )(1 << 2);
    opline->result_type = (zend_uchar )(1 << 3);
    while (1) {
      result->op_type = (int )last_op->result_type;
      if (result->op_type == 1) {
        result->u.constant = ((compiler_globals.active_op_array)->literals + last_op->result.constant)->constant;
      } else {
        result->u.op = last_op->result;
        result->EA = (zend_uint )0;
      }
      break;
    }
    return;
    default: 
    break;
    }
  } else {

  }
  opline->opcode = op;
  while (1) {
    opline->op1_type = (zend_uchar )op1->op_type;
    if (op1->op_type == 1) {
      tmp___1 = zend_add_literal(compiler_globals.active_op_array,
                                 & op1->u.constant);
      opline->op1.constant = (zend_uint )tmp___1;
    } else {
      __constr_expr_4 = op1->u.op;
      opline->op1 = __constr_expr_4;
    }
    break;
  }
  while (1) {
    opline->op2_type = (zend_uchar )op2->op_type;
    if (op2->op_type == 1) {
      tmp___2 = zend_add_literal(compiler_globals.active_op_array,
                                 & op2->u.constant);
      opline->op2.constant = (zend_uint )tmp___2;
    } else {
      __constr_expr_5 = op2->u.op;
      opline->op2 = __constr_expr_5;
    }
    break;
  }
  opline->result_type = (zend_uchar )(1 << 2);
  opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  while (1) {
    result->op_type = (int )opline->result_type;
    if (result->op_type == 1) {
      result->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      result->u.op = opline->result;
      result->EA = (zend_uint )0;
    }
    break;
  }
  return;
}
}
void fetch_simple_variable_ex(znode *result , znode *varname , int bp ,
                              zend_uchar op ) 
{ 
  zend_op opline ;
  zend_op *opline_ptr ;
  zend_llist *fetch_list_ptr ;
  ulong hash ;
  int tmp ;
  zend_bool __attribute__((__visibility__("default")))  tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  ulong __attribute__((__visibility__("default")))  tmp___3 ;
  zend_bool __attribute__((__visibility__("default")))  tmp___4 ;

  {
  if (varname->op_type == 1) {
    hash = (ulong )0;
    if ((int )varname->u.constant.type != 6) {
      if ((int )varname->u.constant.type != 6) {
        _convert_to_string(& varname->u.constant);
      } else {

      }
    } else
    if ((unsigned long )varname->u.constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
      if ((unsigned long )varname->u.constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end) {
        hash = ((Bucket *)(varname->u.constant.value.str.val - sizeof(Bucket )))->h;
      } else {

      }
    } else {

    }
    tmp___0 = zend_is_auto_global_quick((char const   *)varname->u.constant.value.str.val,
                                        (uint )varname->u.constant.value.str.len,
                                        hash);
    if (! tmp___0) {
      if ((unsigned long )varname->u.constant.value.str.len == sizeof("this") - 1UL) {
        tmp___1 = memcmp((void const   *)varname->u.constant.value.str.val,
                         (void const   *)"this", sizeof("this"));
        if (tmp___1) {
          goto _L___0;
        } else {

        }
      } else
      _L___0: 
      if ((compiler_globals.active_op_array)->last == 0U) {
        goto _L;
      } else
      if ((int )((compiler_globals.active_op_array)->opcodes + ((compiler_globals.active_op_array)->last - 1U))->opcode != 57) {
        _L: 
        result->op_type = 1 << 4;
        tmp = lookup_cv(compiler_globals.active_op_array,
                        varname->u.constant.value.str.val,
                        varname->u.constant.value.str.len, hash);
        result->u.op.var = (zend_uint )tmp;
        varname->u.constant.value.str.val = (char *)((compiler_globals.active_op_array)->vars + result->u.op.var)->name;
        result->EA = (zend_uint )0;
        return;
      } else {

      }
    } else {

    }
  } else {

  }
  if (bp) {
    opline_ptr = & opline;
    init_op(opline_ptr);
  } else {
    opline_ptr = get_next_op(compiler_globals.active_op_array);
  }
  opline_ptr->opcode = op;
  opline_ptr->result_type = (zend_uchar )(1 << 2);
  opline_ptr->result.var = get_temporary_variable(compiler_globals.active_op_array);
  while (1) {
    opline_ptr->op1_type = (zend_uchar )varname->op_type;
    if (varname->op_type == 1) {
      tmp___2 = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& varname->u.constant));
      opline_ptr->op1.constant = (zend_uint )tmp___2;
    } else {
      opline_ptr->op1 = varname->u.op;
    }
    break;
  }
  while (1) {
    result->op_type = (int )opline_ptr->result_type;
    if (result->op_type == 1) {
      result->u.constant = ((compiler_globals.active_op_array)->literals + opline_ptr->result.constant)->constant;
    } else {
      result->u.op = opline_ptr->result;
      result->EA = (zend_uint )0;
    }
    break;
  }
  opline_ptr->op2_type = (zend_uchar )(1 << 3);
  opline_ptr->extended_value = (ulong )268435456;
  if (varname->op_type == 1) {
    while (1) {
      if ((unsigned long )((compiler_globals.active_op_array)->literals + opline_ptr->op1.constant)->constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
        if ((unsigned long )((compiler_globals.active_op_array)->literals + opline_ptr->op1.constant)->constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end) {
          ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline_ptr->op1.constant)->constant))->hash_value = ((Bucket *)(((compiler_globals.active_op_array)->literals + opline_ptr->op1.constant)->constant.value.str.val - sizeof(Bucket )))->h;
        } else {
          tmp___3 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline_ptr->op1.constant)->constant.value.str.val,
                                   (uint )(((compiler_globals.active_op_array)->literals + opline_ptr->op1.constant)->constant.value.str.len + 1));
          ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline_ptr->op1.constant)->constant))->hash_value = (zend_ulong )tmp___3;
        }
      } else {
        tmp___3 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline_ptr->op1.constant)->constant.value.str.val,
                                 (uint )(((compiler_globals.active_op_array)->literals + opline_ptr->op1.constant)->constant.value.str.len + 1));
        ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline_ptr->op1.constant)->constant))->hash_value = (zend_ulong )tmp___3;
      }
      break;
    }
    tmp___4 = zend_is_auto_global_quick((char const   *)varname->u.constant.value.str.val,
                                        (uint )varname->u.constant.value.str.len,
                                        ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline_ptr->op1.constant)->constant))->hash_value);
    if (tmp___4) {
      opline_ptr->extended_value = (ulong )0;
    } else {

    }
  } else {

  }
  if (bp) {
    zend_stack_top((zend_stack const   *)(& compiler_globals.bp_stack),
                   (void **)(& fetch_list_ptr));
    zend_llist_add_element(fetch_list_ptr, (void *)opline_ptr);
  } else {

  }
  return;
}
}
void fetch_simple_variable(znode *result , znode *varname , int bp ) 
{ 


  {
  fetch_simple_variable_ex(result, varname, bp, (zend_uchar )83);
  return;
}
}
void zend_do_fetch_static_member(znode *result , znode *class_name ) 
{ 
  znode class_node ;
  zend_llist *fetch_list_ptr ;
  zend_llist_element *le ;
  zend_op *opline_ptr ;
  zend_op opline ;
  int tmp ;
  zval _c ;
  char const   *__s ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  int __l ;
  zval *__z ;
  int tmp___2 ;
  ulong __attribute__((__visibility__("default")))  tmp___3 ;
  void __attribute__((__visibility__("default")))  *tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;
  zval _c___0 ;
  char const   *__s___0 ;
  char __attribute__((__visibility__("default")))  *tmp___7 ;
  int __l___0 ;
  zval *__z___0 ;
  int tmp___9 ;
  ulong __attribute__((__visibility__("default")))  tmp___10 ;
  void __attribute__((__visibility__("default")))  *tmp___11 ;
  int tmp___12 ;
  int tmp___13 ;
  void __attribute__((__visibility__("default")))  *tmp___14 ;
  int tmp___15 ;
  int tmp___16 ;

  {
  if (class_name->op_type == 1) {
    tmp = zend_get_class_fetch_type((char const   *)class_name->u.constant.value.str.val,
                                    (uint )class_name->u.constant.value.str.len);
    if (0 == tmp) {
      zend_resolve_class_name(class_name, (ulong )4, 1);
      class_node = *class_name;
    } else {
      zend_do_fetch_class(& class_node, class_name);
    }
  } else {
    zend_do_fetch_class(& class_node, class_name);
  }
  zend_stack_top((zend_stack const   *)(& compiler_globals.bp_stack),
                 (void **)(& fetch_list_ptr));
  if (result->op_type == 1 << 4) {
    init_op(& opline);
    opline.opcode = (zend_uchar )83;
    opline.result_type = (zend_uchar )(1 << 2);
    opline.result.var = get_temporary_variable(compiler_globals.active_op_array);
    opline.op1_type = (zend_uchar )1;
    while (1) {
      while (1) {
        tmp___0 = _estrdup(((compiler_globals.active_op_array)->vars + result->u.op.var)->name);
        __s = (char const   *)tmp___0;
        __l = ((compiler_globals.active_op_array)->vars + result->u.op.var)->name_len;
        __z = & _c;
        __z->value.str.len = __l;
        __z->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
        __z->type = (zend_uchar )6;
        break;
      }
      tmp___2 = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& _c));
      opline.op1.constant = (zend_uint )tmp___2;
      break;
    }
    while (1) {
      if ((unsigned long )((compiler_globals.active_op_array)->literals + opline.op1.constant)->constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
        if ((unsigned long )((compiler_globals.active_op_array)->literals + opline.op1.constant)->constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end) {
          ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline.op1.constant)->constant))->hash_value = ((Bucket *)(((compiler_globals.active_op_array)->literals + opline.op1.constant)->constant.value.str.val - sizeof(Bucket )))->h;
        } else {
          tmp___3 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline.op1.constant)->constant.value.str.val,
                                   (uint )(((compiler_globals.active_op_array)->literals + opline.op1.constant)->constant.value.str.len + 1));
          ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline.op1.constant)->constant))->hash_value = (zend_ulong )tmp___3;
        }
      } else {
        tmp___3 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline.op1.constant)->constant.value.str.val,
                                 (uint )(((compiler_globals.active_op_array)->literals + opline.op1.constant)->constant.value.str.len + 1));
        ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline.op1.constant)->constant))->hash_value = (zend_ulong )tmp___3;
      }
      break;
    }
    while (1) {
      ((compiler_globals.active_op_array)->literals + opline.op1.constant)->cache_slot = (zend_uint )(compiler_globals.active_op_array)->last_cache_slot;
      (compiler_globals.active_op_array)->last_cache_slot += 2;
      if ((compiler_globals.active_op_array)->fn_flags & 16U) {
        if ((compiler_globals.active_op_array)->run_time_cache) {
          tmp___4 = _erealloc((void *)(compiler_globals.active_op_array)->run_time_cache,
                              (unsigned long )(compiler_globals.active_op_array)->last_cache_slot * sizeof(void *),
                              0);
          (compiler_globals.active_op_array)->run_time_cache = (void **)tmp___4;
          *((compiler_globals.active_op_array)->run_time_cache + ((compiler_globals.active_op_array)->last_cache_slot - 1)) = (void *)0;
          *((compiler_globals.active_op_array)->run_time_cache + ((compiler_globals.active_op_array)->last_cache_slot - 2)) = (void *)0;
        } else {

        }
      } else {

      }
      break;
    }
    if (class_node.op_type == 1) {
      opline.op2_type = (zend_uchar )1;
      tmp___5 = zend_add_class_name_literal(compiler_globals.active_op_array,
                                            (zval const   *)(& class_node.u.constant));
      opline.op2.constant = (zend_uint )tmp___5;
    } else {
      while (1) {
        opline.op2_type = (zend_uchar )class_node.op_type;
        if (class_node.op_type == 1) {
          tmp___6 = zend_add_literal(compiler_globals.active_op_array,
                                     (zval const   *)(& class_node.u.constant));
          opline.op2.constant = (zend_uint )tmp___6;
        } else {
          opline.op2 = class_node.u.op;
        }
        break;
      }
    }
    while (1) {
      result->op_type = (int )opline.result_type;
      if (result->op_type == 1) {
        result->u.constant = ((compiler_globals.active_op_array)->literals + opline.result.constant)->constant;
      } else {
        result->u.op = opline.result;
        result->EA = (zend_uint )0;
      }
      break;
    }
    opline.extended_value |= 805306368UL;
    opline_ptr = & opline;
    zend_llist_add_element(fetch_list_ptr, (void *)(& opline));
  } else {
    le = fetch_list_ptr->head;
    opline_ptr = (zend_op *)(le->data);
    if ((int )opline_ptr->opcode != 83) {
      if ((int )opline_ptr->op1_type == 1 << 4) {
        init_op(& opline);
        opline.opcode = (zend_uchar )83;
        opline.result_type = (zend_uchar )(1 << 2);
        opline.result.var = get_temporary_variable(compiler_globals.active_op_array);
        opline.op1_type = (zend_uchar )1;
        while (1) {
          while (1) {
            tmp___7 = _estrdup(((compiler_globals.active_op_array)->vars + opline_ptr->op1.var)->name);
            __s___0 = (char const   *)tmp___7;
            __l___0 = ((compiler_globals.active_op_array)->vars + opline_ptr->op1.var)->name_len;
            __z___0 = & _c___0;
            __z___0->value.str.len = __l___0;
            __z___0->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s___0));
            __z___0->type = (zend_uchar )6;
            break;
          }
          tmp___9 = zend_add_literal(compiler_globals.active_op_array,
                                     (zval const   *)(& _c___0));
          opline.op1.constant = (zend_uint )tmp___9;
          break;
        }
        while (1) {
          if ((unsigned long )((compiler_globals.active_op_array)->literals + opline.op1.constant)->constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
            if ((unsigned long )((compiler_globals.active_op_array)->literals + opline.op1.constant)->constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end) {
              ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline.op1.constant)->constant))->hash_value = ((Bucket *)(((compiler_globals.active_op_array)->literals + opline.op1.constant)->constant.value.str.val - sizeof(Bucket )))->h;
            } else {
              tmp___10 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline.op1.constant)->constant.value.str.val,
                                        (uint )(((compiler_globals.active_op_array)->literals + opline.op1.constant)->constant.value.str.len + 1));
              ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline.op1.constant)->constant))->hash_value = (zend_ulong )tmp___10;
            }
          } else {
            tmp___10 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline.op1.constant)->constant.value.str.val,
                                      (uint )(((compiler_globals.active_op_array)->literals + opline.op1.constant)->constant.value.str.len + 1));
            ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline.op1.constant)->constant))->hash_value = (zend_ulong )tmp___10;
          }
          break;
        }
        while (1) {
          ((compiler_globals.active_op_array)->literals + opline.op1.constant)->cache_slot = (zend_uint )(compiler_globals.active_op_array)->last_cache_slot;
          (compiler_globals.active_op_array)->last_cache_slot += 2;
          if ((compiler_globals.active_op_array)->fn_flags & 16U) {
            if ((compiler_globals.active_op_array)->run_time_cache) {
              tmp___11 = _erealloc((void *)(compiler_globals.active_op_array)->run_time_cache,
                                   (unsigned long )(compiler_globals.active_op_array)->last_cache_slot * sizeof(void *),
                                   0);
              (compiler_globals.active_op_array)->run_time_cache = (void **)tmp___11;
              *((compiler_globals.active_op_array)->run_time_cache + ((compiler_globals.active_op_array)->last_cache_slot - 1)) = (void *)0;
              *((compiler_globals.active_op_array)->run_time_cache + ((compiler_globals.active_op_array)->last_cache_slot - 2)) = (void *)0;
            } else {

            }
          } else {

          }
          break;
        }
        if (class_node.op_type == 1) {
          opline.op2_type = (zend_uchar )1;
          tmp___12 = zend_add_class_name_literal(compiler_globals.active_op_array,
                                                 (zval const   *)(& class_node.u.constant));
          opline.op2.constant = (zend_uint )tmp___12;
        } else {
          while (1) {
            opline.op2_type = (zend_uchar )class_node.op_type;
            if (class_node.op_type == 1) {
              tmp___13 = zend_add_literal(compiler_globals.active_op_array,
                                          (zval const   *)(& class_node.u.constant));
              opline.op2.constant = (zend_uint )tmp___13;
            } else {
              opline.op2 = class_node.u.op;
            }
            break;
          }
        }
        opline.extended_value |= 805306368UL;
        while (1) {
          opline_ptr->op1_type = opline.result_type;
          opline_ptr->op1 = opline.result;
          break;
        }
        zend_llist_prepend_element(fetch_list_ptr, (void *)(& opline));
      } else {
        goto _L;
      }
    } else {
      _L: 
      if ((int )opline_ptr->op1_type == 1) {
        while (1) {
          ((compiler_globals.active_op_array)->literals + opline_ptr->op1.constant)->cache_slot = (zend_uint )(compiler_globals.active_op_array)->last_cache_slot;
          (compiler_globals.active_op_array)->last_cache_slot += 2;
          if ((compiler_globals.active_op_array)->fn_flags & 16U) {
            if ((compiler_globals.active_op_array)->run_time_cache) {
              tmp___14 = _erealloc((void *)(compiler_globals.active_op_array)->run_time_cache,
                                   (unsigned long )(compiler_globals.active_op_array)->last_cache_slot * sizeof(void *),
                                   0);
              (compiler_globals.active_op_array)->run_time_cache = (void **)tmp___14;
              *((compiler_globals.active_op_array)->run_time_cache + ((compiler_globals.active_op_array)->last_cache_slot - 1)) = (void *)0;
              *((compiler_globals.active_op_array)->run_time_cache + ((compiler_globals.active_op_array)->last_cache_slot - 2)) = (void *)0;
            } else {

            }
          } else {

          }
          break;
        }
      } else {

      }
      if (class_node.op_type == 1) {
        opline_ptr->op2_type = (zend_uchar )1;
        tmp___15 = zend_add_class_name_literal(compiler_globals.active_op_array,
                                               (zval const   *)(& class_node.u.constant));
        opline_ptr->op2.constant = (zend_uint )tmp___15;
      } else {
        while (1) {
          opline_ptr->op2_type = (zend_uchar )class_node.op_type;
          if (class_node.op_type == 1) {
            tmp___16 = zend_add_literal(compiler_globals.active_op_array,
                                        (zval const   *)(& class_node.u.constant));
            opline_ptr->op2.constant = (zend_uint )tmp___16;
          } else {
            opline_ptr->op2 = class_node.u.op;
          }
          break;
        }
      }
      opline_ptr->extended_value |= 805306368UL;
    }
  }
  return;
}
}
void fetch_array_begin(znode *result , znode *varname , znode *first_dim ) 
{ 


  {
  fetch_simple_variable(result, varname, 1);
  fetch_array_dim(result, (znode const   *)result, (znode const   *)first_dim);
  return;
}
}
void fetch_array_dim(znode *result , znode const   *parent , znode const   *dim ) 
{ 
  zend_op opline ;
  zend_llist *fetch_list_ptr ;
  int tmp ;
  zend_bool tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  ulong index___0 ;
  int numeric ;
  register char const   *tmp___3 ;
  char const   *end ;
  zval *__z ;
  ulong __attribute__((__visibility__("default")))  tmp___4 ;
  znode_op __constr_expr_6 ;
  znode_op __constr_expr_7 ;
  znode_op __constr_expr_8 ;

  {
  zend_stack_top((zend_stack const   *)(& compiler_globals.bp_stack),
                 (void **)(& fetch_list_ptr));
  tmp___0 = zend_is_function_or_method_call(parent);
  if (tmp___0) {
    init_op(& opline);
    opline.opcode = (zend_uchar )156;
    while (1) {
      opline.op1_type = (zend_uchar )parent->op_type;
      if (parent->op_type == 1) {
        tmp = zend_add_literal(compiler_globals.active_op_array,
                               & parent->u.constant);
        opline.op1.constant = (zend_uint )tmp;
      } else {
        __constr_expr_6 = parent->u.op;
        opline.op1 = __constr_expr_6;
      }
      break;
    }
    opline.op2_type = (zend_uchar )(1 << 3);
    opline.result_type = (zend_uchar )(1 << 2);
    opline.result.var = opline.op1.var;
    zend_llist_add_element(fetch_list_ptr, (void *)(& opline));
  } else {

  }
  init_op(& opline);
  opline.opcode = (zend_uchar )84;
  opline.result_type = (zend_uchar )(1 << 2);
  opline.result.var = get_temporary_variable(compiler_globals.active_op_array);
  while (1) {
    opline.op1_type = (zend_uchar )parent->op_type;
    if (parent->op_type == 1) {
      tmp___1 = zend_add_literal(compiler_globals.active_op_array,
                                 & parent->u.constant);
      opline.op1.constant = (zend_uint )tmp___1;
    } else {
      __constr_expr_7 = parent->u.op;
      opline.op1 = __constr_expr_7;
    }
    break;
  }
  while (1) {
    opline.op2_type = (zend_uchar )dim->op_type;
    if (dim->op_type == 1) {
      tmp___2 = zend_add_literal(compiler_globals.active_op_array,
                                 & dim->u.constant);
      opline.op2.constant = (zend_uint )tmp___2;
    } else {
      __constr_expr_8 = dim->u.op;
      opline.op2 = __constr_expr_8;
    }
    break;
  }
  if ((int )opline.op2_type == 1) {
    if ((int )((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant.type == 6) {
      numeric = 0;
      while (1) {
        tmp___3 = (char const   *)((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant.value.str.val;
        if ((int const   )*tmp___3 == 45) {
          tmp___3 ++;
        } else {

        }
        if ((int const   )*tmp___3 >= 48) {
          if ((int const   )*tmp___3 <= 57) {
            end = (char const   *)(((((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant.value.str.val + ((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant.value.str.len) + 1) - 1);
            if ((int const   )*end != 0) {
              break;
            } else
            if ((int const   )*tmp___3 == 48) {
              if (((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant.value.str.len + 1 > 2) {
                break;
              } else {
                goto _L;
              }
            } else
            _L: 
            if (end - tmp___3 > 19L) {
              break;
            } else {

            }
            index___0 = (ulong )((int const   )*tmp___3 - 48);
            while (1) {
              tmp___3 ++;
              if ((unsigned long )tmp___3 != (unsigned long )end) {
                if ((int const   )*tmp___3 >= 48) {
                  if (! ((int const   )*tmp___3 <= 57)) {
                    break;
                  } else {

                  }
                } else {
                  break;
                }
              } else {
                break;
              }
              index___0 = index___0 * 10UL + (ulong )((int const   )*tmp___3 - 48);
            }
            if ((unsigned long )tmp___3 == (unsigned long )end) {
              if ((int )*(((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant.value.str.val) == 45) {
                if (index___0 - 1UL > 9223372036854775807UL) {
                  break;
                } else {

                }
                index___0 = (ulong )(- ((long )index___0));
              } else
              if (index___0 > 9223372036854775807UL) {
                break;
              } else {

              }
              numeric = 1;
            } else {

            }
          } else {

          }
        } else {

        }
        break;
      }
      if (numeric) {
        _zval_dtor(& ((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant);
        __z = & ((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant;
        __z->value.lval = (long )index___0;
        __z->type = (zend_uchar )1;
      } else {
        while (1) {
          if ((unsigned long )((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
            if ((unsigned long )((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end) {
              ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant))->hash_value = ((Bucket *)(((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant.value.str.val - sizeof(Bucket )))->h;
            } else {
              tmp___4 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant.value.str.val,
                                       (uint )(((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant.value.str.len + 1));
              ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant))->hash_value = (zend_ulong )tmp___4;
            }
          } else {
            tmp___4 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant.value.str.val,
                                     (uint )(((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant.value.str.len + 1));
            ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant))->hash_value = (zend_ulong )tmp___4;
          }
          break;
        }
      }
    } else {

    }
  } else {

  }
  while (1) {
    result->op_type = (int )opline.result_type;
    if (result->op_type == 1) {
      result->u.constant = ((compiler_globals.active_op_array)->literals + opline.result.constant)->constant;
    } else {
      result->u.op = opline.result;
      result->EA = (zend_uint )0;
    }
    break;
  }
  zend_llist_add_element(fetch_list_ptr, (void *)(& opline));
  return;
}
}
void fetch_string_offset(znode *result , znode const   *parent ,
                         znode const   *offset ) 
{ 


  {
  fetch_array_dim(result, parent, offset);
  return;
}
}
void zend_do_print(znode *result , znode const   *arg ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;
  znode_op __constr_expr_9 ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  opline->result_type = (zend_uchar )(1 << 1);
  opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  opline->opcode = (zend_uchar )41;
  while (1) {
    opline->op1_type = (zend_uchar )arg->op_type;
    if (arg->op_type == 1) {
      tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                 & arg->u.constant);
      opline->op1.constant = (zend_uint )tmp___0;
    } else {
      __constr_expr_9 = arg->u.op;
      opline->op1 = __constr_expr_9;
    }
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  while (1) {
    result->op_type = (int )opline->result_type;
    if (result->op_type == 1) {
      result->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      result->u.op = opline->result;
      result->EA = (zend_uint )0;
    }
    break;
  }
  return;
}
}
void zend_do_echo(znode const   *arg ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;
  znode_op __constr_expr_10 ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  opline->opcode = (zend_uchar )40;
  while (1) {
    opline->op1_type = (zend_uchar )arg->op_type;
    if (arg->op_type == 1) {
      tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                 & arg->u.constant);
      opline->op1.constant = (zend_uint )tmp___0;
    } else {
      __constr_expr_10 = arg->u.op;
      opline->op1 = __constr_expr_10;
    }
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  return;
}
}
void zend_do_abstract_method(znode const   *function_name , znode *modifiers ,
                             znode const   *body ) 
{ 
  char *method_type ;
  zend_op *opline ;
  zend_op *tmp ;

  {
  if ((compiler_globals.active_class_entry)->ce_flags & 128U) {
    modifiers->u.constant.value.lval |= 2L;
    method_type = (char *)"Interface";
  } else {
    method_type = (char *)"Abstract";
  }
  if (modifiers->u.constant.value.lval & 2L) {
    if (modifiers->u.constant.value.lval & 1024L) {
      zend_error(1 << 6L, "%s function %s::%s() cannot be declared private",
                 method_type, (compiler_globals.active_class_entry)->name,
                 function_name->u.constant.value.str.val);
    } else {

    }
    if (body->u.constant.value.lval == 2L) {
      tmp = get_next_op(compiler_globals.active_op_array);
      opline = tmp;
      opline->opcode = (zend_uchar )142;
      opline->op1_type = (zend_uchar )(1 << 3);
      opline->op2_type = (zend_uchar )(1 << 3);
    } else {
      zend_error(1 << 6L, "%s function %s::%s() cannot contain body",
                 method_type, (compiler_globals.active_class_entry)->name,
                 function_name->u.constant.value.str.val);
    }
  } else
  if (body->u.constant.value.lval == 2L) {
    zend_error(1 << 6L, "Non-abstract method %s::%s() must contain body",
               (compiler_globals.active_class_entry)->name,
               function_name->u.constant.value.str.val);
  } else {

  }
  return;
}
}
static zend_bool opline_is_fetch_this(zend_op const   *opline ) 
{ 
  int tmp ;

  {
  if ((int const   )opline->opcode == 83) {
    if ((int const   )opline->op1_type == 1) {
      if ((int )((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.type == 6) {
        if (((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant))->hash_value == 210728972157UL) {
          if ((unsigned long )((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.len == sizeof("this") - 1UL) {
            tmp = memcmp((void const   *)((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val,
                         (void const   *)"this", sizeof("this"));
            if (tmp) {
              return ((zend_bool )0);
            } else {
              return ((zend_bool )1);
            }
          } else {
            return ((zend_bool )0);
          }
        } else {
          return ((zend_bool )0);
        }
      } else {
        return ((zend_bool )0);
      }
    } else {
      return ((zend_bool )0);
    }
  } else {
    return ((zend_bool )0);
  }
}
}
void zend_do_assign(znode *result , znode *variable , znode *value ) 
{ 
  int last_op_number ;
  zend_op *opline ;
  zend_llist *fetch_list_ptr ;
  zval _c ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp ;
  int tmp___0 ;
  ulong __attribute__((__visibility__("default")))  tmp___1 ;
  int n ;
  zend_op *last_op ;
  int opline_no ;
  zend_uchar tmp___2 ;
  zend_uchar tmp___3 ;
  int opline_no___0 ;
  zend_uchar tmp___4 ;
  zend_uchar tmp___5 ;
  zend_bool tmp___6 ;
  int tmp___7 ;
  int tmp___8 ;

  {
  if (value->op_type == 1 << 4) {
    zend_stack_top((zend_stack const   *)(& compiler_globals.bp_stack),
                   (void **)(& fetch_list_ptr));
    if (fetch_list_ptr) {
      if (fetch_list_ptr->head) {
        opline = (zend_op *)((fetch_list_ptr->head)->data);
        if ((int )opline->opcode == 84) {
          if ((int )opline->op1_type == 1 << 4) {
            if (opline->op1.var == value->u.op.var) {
              opline = get_next_op(compiler_globals.active_op_array);
              opline->opcode = (zend_uchar )80;
              opline->result_type = (zend_uchar )(1 << 2);
              opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
              opline->op1_type = (zend_uchar )1;
              while (1) {
                while (1) {
                  __s = ((compiler_globals.active_op_array)->vars + value->u.op.var)->name;
                  __l = ((compiler_globals.active_op_array)->vars + value->u.op.var)->name_len;
                  __z = & _c;
                  __z->value.str.len = __l;
                  tmp = _estrndup(__s, (unsigned int )__l);
                  __z->value.str.val = (char *)tmp;
                  __z->type = (zend_uchar )6;
                  break;
                }
                tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                           (zval const   *)(& _c));
                opline->op1.constant = (zend_uint )tmp___0;
                break;
              }
              while (1) {
                if ((unsigned long )((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
                  if ((unsigned long )((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end) {
                    ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant))->hash_value = ((Bucket *)(((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val - sizeof(Bucket )))->h;
                  } else {
                    tmp___1 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val,
                                             (uint )(((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.len + 1));
                    ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant))->hash_value = (zend_ulong )tmp___1;
                  }
                } else {
                  tmp___1 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val,
                                           (uint )(((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.len + 1));
                  ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant))->hash_value = (zend_ulong )tmp___1;
                }
                break;
              }
              opline->op2_type = (zend_uchar )(1 << 3);
              opline->extended_value = (ulong )268435456;
              while (1) {
                value->op_type = (int )opline->result_type;
                if (value->op_type == 1) {
                  value->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
                } else {
                  value->u.op = opline->result;
                  value->EA = (zend_uint )0;
                }
                break;
              }
            } else {

            }
          } else {

          }
        } else {

        }
      } else {

      }
    } else {

    }
  } else {

  }
  zend_do_end_variable_parse(variable, 1, 0);
  last_op_number = get_next_op_number(compiler_globals.active_op_array);
  opline = get_next_op(compiler_globals.active_op_array);
  if (variable->op_type == 1 << 4) {
    if (variable->u.op.var == (compiler_globals.active_op_array)->this_var) {
      zend_error(1 << 6L, "Cannot re-assign $this");
    } else {

    }
  } else
  if (variable->op_type == 1 << 2) {
    n = 0;
    while (last_op_number - n > 0) {
      last_op = (compiler_globals.active_op_array)->opcodes + ((last_op_number - n) - 1);
      if ((int )last_op->result_type == 1 << 2) {
        if (last_op->result.var == variable->u.op.var) {
          if ((int )last_op->opcode == 85) {
            if (n > 0) {
              opline_no = (int )((unsigned long )(opline - (compiler_globals.active_op_array)->opcodes) / sizeof(*opline));
              *opline = *last_op;
              last_op->opcode = (zend_uchar )0;
              memset((void *)(& last_op->result), 0, sizeof(last_op->result));
              memset((void *)(& last_op->op1), 0, sizeof(last_op->op1));
              memset((void *)(& last_op->op2), 0, sizeof(last_op->op2));
              tmp___3 = (zend_uchar )(1 << 3);
              last_op->op2_type = tmp___3;
              tmp___2 = tmp___3;
              last_op->op1_type = tmp___2;
              last_op->result_type = tmp___2;
              opline = get_next_op(compiler_globals.active_op_array);
              last_op = (compiler_globals.active_op_array)->opcodes + opline_no;
            } else {

            }
            last_op->opcode = (zend_uchar )136;
            zend_do_op_data(opline, (znode const   *)value);
            opline->result_type = (zend_uchar )(1 << 3);
            while (1) {
              result->op_type = (int )last_op->result_type;
              if (result->op_type == 1) {
                result->u.constant = ((compiler_globals.active_op_array)->literals + last_op->result.constant)->constant;
              } else {
                result->u.op = last_op->result;
                result->EA = (zend_uint )0;
              }
              break;
            }
            return;
          } else
          if ((int )last_op->opcode == 84) {
            if (n > 0) {
              opline_no___0 = (int )((unsigned long )(opline - (compiler_globals.active_op_array)->opcodes) / sizeof(*opline));
              *opline = *last_op;
              last_op->opcode = (zend_uchar )0;
              memset((void *)(& last_op->result), 0, sizeof(last_op->result));
              memset((void *)(& last_op->op1), 0, sizeof(last_op->op1));
              memset((void *)(& last_op->op2), 0, sizeof(last_op->op2));
              tmp___5 = (zend_uchar )(1 << 3);
              last_op->op2_type = tmp___5;
              tmp___4 = tmp___5;
              last_op->op1_type = tmp___4;
              last_op->result_type = tmp___4;
              opline = get_next_op(compiler_globals.active_op_array);
              last_op = (compiler_globals.active_op_array)->opcodes + opline_no___0;
            } else {

            }
            last_op->opcode = (zend_uchar )147;
            zend_do_op_data(opline, (znode const   *)value);
            opline->op2.var = get_temporary_variable(compiler_globals.active_op_array);
            opline->op2_type = (zend_uchar )(1 << 2);
            opline->result_type = (zend_uchar )(1 << 3);
            while (1) {
              result->op_type = (int )last_op->result_type;
              if (result->op_type == 1) {
                result->u.constant = ((compiler_globals.active_op_array)->literals + last_op->result.constant)->constant;
              } else {
                result->u.op = last_op->result;
                result->EA = (zend_uint )0;
              }
              break;
            }
            return;
          } else {
            tmp___6 = opline_is_fetch_this((zend_op const   *)last_op);
            if (tmp___6) {
              zend_error(1 << 6L, "Cannot re-assign $this");
            } else {
              break;
            }
          }
        } else {

        }
      } else {

      }
      n ++;
    }
  } else {

  }
  opline->opcode = (zend_uchar )38;
  while (1) {
    opline->op1_type = (zend_uchar )variable->op_type;
    if (variable->op_type == 1) {
      tmp___7 = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& variable->u.constant));
      opline->op1.constant = (zend_uint )tmp___7;
    } else {
      opline->op1 = variable->u.op;
    }
    break;
  }
  while (1) {
    opline->op2_type = (zend_uchar )value->op_type;
    if (value->op_type == 1) {
      tmp___8 = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& value->u.constant));
      opline->op2.constant = (zend_uint )tmp___8;
    } else {
      opline->op2 = value->u.op;
    }
    break;
  }
  opline->result_type = (zend_uchar )(1 << 2);
  opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  while (1) {
    result->op_type = (int )opline->result_type;
    if (result->op_type == 1) {
      result->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      result->u.op = opline->result;
      result->EA = (zend_uint )0;
    }
    break;
  }
  return;
}
}
void zend_do_assign_ref(znode *result , znode const   *lvar ,
                        znode const   *rvar ) 
{ 
  zend_op *opline ;
  int last_op_number ;
  int tmp ;
  zend_bool tmp___0 ;
  zend_bool tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  znode_op __constr_expr_11 ;
  znode_op __constr_expr_12 ;

  {
  if (lvar->op_type == (int const   )(1 << 4)) {
    if (lvar->u.op.var == (zend_uint const   )(compiler_globals.active_op_array)->this_var) {
      zend_error(1 << 6L, "Cannot re-assign $this");
    } else {

    }
  } else
  if (lvar->op_type == (int const   )(1 << 2)) {
    tmp = get_next_op_number(compiler_globals.active_op_array);
    last_op_number = tmp;
    if (last_op_number > 0) {
      opline = (compiler_globals.active_op_array)->opcodes + (last_op_number - 1);
      tmp___0 = opline_is_fetch_this((zend_op const   *)opline);
      if (tmp___0) {
        zend_error(1 << 6L, "Cannot re-assign $this");
      } else {

      }
    } else {

    }
  } else {

  }
  opline = get_next_op(compiler_globals.active_op_array);
  opline->opcode = (zend_uchar )39;
  tmp___1 = zend_is_function_or_method_call(rvar);
  if (tmp___1) {
    opline->extended_value = (ulong )1;
  } else
  if (rvar->EA & (unsigned int const   )(1 << 6)) {
    opline->extended_value = (ulong )(1 << 1);
  } else {
    opline->extended_value = (ulong )0;
  }
  if (result) {
    opline->result_type = (zend_uchar )(1 << 2);
    opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
    while (1) {
      result->op_type = (int )opline->result_type;
      if (result->op_type == 1) {
        result->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
      } else {
        result->u.op = opline->result;
        result->EA = (zend_uint )0;
      }
      break;
    }
  } else {
    opline->result_type = (zend_uchar )((1 << 3) | (1 << 5));
  }
  while (1) {
    opline->op1_type = (zend_uchar )lvar->op_type;
    if (lvar->op_type == 1) {
      tmp___2 = zend_add_literal(compiler_globals.active_op_array,
                                 & lvar->u.constant);
      opline->op1.constant = (zend_uint )tmp___2;
    } else {
      __constr_expr_11 = lvar->u.op;
      opline->op1 = __constr_expr_11;
    }
    break;
  }
  while (1) {
    opline->op2_type = (zend_uchar )rvar->op_type;
    if (rvar->op_type == 1) {
      tmp___3 = zend_add_literal(compiler_globals.active_op_array,
                                 & rvar->u.constant);
      opline->op2.constant = (zend_uint )tmp___3;
    } else {
      __constr_expr_12 = rvar->u.op;
      opline->op2 = __constr_expr_12;
    }
    break;
  }
  return;
}
}
__inline static void do_begin_loop(void) 
{ 
  zend_brk_cont_element *brk_cont_element ;
  int parent ;

  {
  parent = compiler_globals.context.current_brk_cont;
  compiler_globals.context.current_brk_cont = (compiler_globals.active_op_array)->last_brk_cont;
  brk_cont_element = get_next_brk_cont_element(compiler_globals.active_op_array);
  brk_cont_element->start = get_next_op_number(compiler_globals.active_op_array);
  brk_cont_element->parent = parent;
  return;
}
}
__inline static void do_end_loop(int cont_addr , int has_loop_var ) 
{ 


  {
  if (! has_loop_var) {
    ((compiler_globals.active_op_array)->brk_cont_array + compiler_globals.context.current_brk_cont)->start = -1;
  } else {

  }
  ((compiler_globals.active_op_array)->brk_cont_array + compiler_globals.context.current_brk_cont)->cont = cont_addr;
  ((compiler_globals.active_op_array)->brk_cont_array + compiler_globals.context.current_brk_cont)->brk = get_next_op_number(compiler_globals.active_op_array);
  compiler_globals.context.current_brk_cont = ((compiler_globals.active_op_array)->brk_cont_array + compiler_globals.context.current_brk_cont)->parent;
  return;
}
}
void zend_do_while_cond(znode const   *expr , znode *close_bracket_token ) 
{ 
  int while_cond_op_number ;
  int tmp ;
  zend_op *opline ;
  zend_op *tmp___0 ;
  int tmp___1 ;
  znode_op __constr_expr_13 ;

  {
  tmp = get_next_op_number(compiler_globals.active_op_array);
  while_cond_op_number = tmp;
  tmp___0 = get_next_op(compiler_globals.active_op_array);
  opline = tmp___0;
  opline->opcode = (zend_uchar )43;
  while (1) {
    opline->op1_type = (zend_uchar )expr->op_type;
    if (expr->op_type == 1) {
      tmp___1 = zend_add_literal(compiler_globals.active_op_array,
                                 & expr->u.constant);
      opline->op1.constant = (zend_uint )tmp___1;
    } else {
      __constr_expr_13 = expr->u.op;
      opline->op1 = __constr_expr_13;
    }
    break;
  }
  close_bracket_token->u.op.opline_num = (zend_uint )while_cond_op_number;
  opline->op2_type = (zend_uchar )(1 << 3);
  do_begin_loop();
  if ((compiler_globals.active_op_array)->fn_flags & 16U) {
    (compiler_globals.context.backpatch_count) ++;
  } else {

  }
  return;
}
}
void zend_do_while_end(znode const   *while_token ,
                       znode const   *close_bracket_token ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  opline->opcode = (zend_uchar )42;
  opline->op1.opline_num = (zend_uint )while_token->u.op.opline_num;
  opline->op1_type = (zend_uchar )(1 << 3);
  opline->op2_type = (zend_uchar )(1 << 3);
  tmp___0 = get_next_op_number(compiler_globals.active_op_array);
  ((compiler_globals.active_op_array)->opcodes + close_bracket_token->u.op.opline_num)->op2.opline_num = (zend_uint )tmp___0;
  do_end_loop((int )while_token->u.op.opline_num, 0);
  if ((compiler_globals.active_op_array)->fn_flags & 16U) {
    (compiler_globals.context.backpatch_count) --;
  } else {

  }
  return;
}
}
void zend_do_for_cond(znode const   *expr , znode *second_semicolon_token ) 
{ 
  int for_cond_op_number ;
  int tmp ;
  zend_op *opline ;
  zend_op *tmp___0 ;
  int tmp___1 ;
  znode_op __constr_expr_14 ;

  {
  tmp = get_next_op_number(compiler_globals.active_op_array);
  for_cond_op_number = tmp;
  tmp___0 = get_next_op(compiler_globals.active_op_array);
  opline = tmp___0;
  opline->opcode = (zend_uchar )45;
  while (1) {
    opline->op1_type = (zend_uchar )expr->op_type;
    if (expr->op_type == 1) {
      tmp___1 = zend_add_literal(compiler_globals.active_op_array,
                                 & expr->u.constant);
      opline->op1.constant = (zend_uint )tmp___1;
    } else {
      __constr_expr_14 = expr->u.op;
      opline->op1 = __constr_expr_14;
    }
    break;
  }
  second_semicolon_token->u.op.opline_num = (zend_uint )for_cond_op_number;
  opline->op2_type = (zend_uchar )(1 << 3);
  return;
}
}
void zend_do_for_before_statement(znode const   *cond_start ,
                                  znode const   *second_semicolon_token ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  opline->opcode = (zend_uchar )42;
  opline->op1.opline_num = (zend_uint )cond_start->u.op.opline_num;
  tmp___0 = get_next_op_number(compiler_globals.active_op_array);
  ((compiler_globals.active_op_array)->opcodes + second_semicolon_token->u.op.opline_num)->extended_value = (ulong )tmp___0;
  opline->op1_type = (zend_uchar )(1 << 3);
  opline->op2_type = (zend_uchar )(1 << 3);
  do_begin_loop();
  if ((compiler_globals.active_op_array)->fn_flags & 16U) {
    (compiler_globals.context.backpatch_count) ++;
  } else {

  }
  return;
}
}
void zend_do_for_end(znode const   *second_semicolon_token ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  opline->opcode = (zend_uchar )42;
  opline->op1.opline_num = (zend_uint )(second_semicolon_token->u.op.opline_num + 1U);
  tmp___0 = get_next_op_number(compiler_globals.active_op_array);
  ((compiler_globals.active_op_array)->opcodes + second_semicolon_token->u.op.opline_num)->op2.opline_num = (zend_uint )tmp___0;
  opline->op1_type = (zend_uchar )(1 << 3);
  opline->op2_type = (zend_uchar )(1 << 3);
  do_end_loop((int )(second_semicolon_token->u.op.opline_num + 1U), 0);
  if ((compiler_globals.active_op_array)->fn_flags & 16U) {
    (compiler_globals.context.backpatch_count) --;
  } else {

  }
  return;
}
}
void zend_do_pre_incdec(znode *result , znode const   *op1 , zend_uchar op ) 
{ 
  int last_op_number ;
  int tmp ;
  zend_op *opline ;
  zend_op *last_op ;
  int tmp___0 ;
  znode_op __constr_expr_15 ;

  {
  tmp = get_next_op_number(compiler_globals.active_op_array);
  last_op_number = tmp;
  if (last_op_number > 0) {
    last_op = (compiler_globals.active_op_array)->opcodes + (last_op_number - 1);
    if ((int )last_op->opcode == 88) {
      if ((int )op == 34) {
        last_op->opcode = (zend_uchar )132;
      } else {
        last_op->opcode = (zend_uchar )133;
      }
      last_op->result_type = (zend_uchar )(1 << 2);
      last_op->result.var = get_temporary_variable(compiler_globals.active_op_array);
      while (1) {
        result->op_type = (int )last_op->result_type;
        if (result->op_type == 1) {
          result->u.constant = ((compiler_globals.active_op_array)->literals + last_op->result.constant)->constant;
        } else {
          result->u.op = last_op->result;
          result->EA = (zend_uint )0;
        }
        break;
      }
      return;
    } else {

    }
  } else {

  }
  opline = get_next_op(compiler_globals.active_op_array);
  opline->opcode = op;
  while (1) {
    opline->op1_type = (zend_uchar )op1->op_type;
    if (op1->op_type == 1) {
      tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                 & op1->u.constant);
      opline->op1.constant = (zend_uint )tmp___0;
    } else {
      __constr_expr_15 = op1->u.op;
      opline->op1 = __constr_expr_15;
    }
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  opline->result_type = (zend_uchar )(1 << 2);
  opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  while (1) {
    result->op_type = (int )opline->result_type;
    if (result->op_type == 1) {
      result->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      result->u.op = opline->result;
      result->EA = (zend_uint )0;
    }
    break;
  }
  return;
}
}
void zend_do_post_incdec(znode *result , znode const   *op1 , zend_uchar op ) 
{ 
  int last_op_number ;
  int tmp ;
  zend_op *opline ;
  zend_op *last_op ;
  int tmp___0 ;
  znode_op __constr_expr_16 ;

  {
  tmp = get_next_op_number(compiler_globals.active_op_array);
  last_op_number = tmp;
  if (last_op_number > 0) {
    last_op = (compiler_globals.active_op_array)->opcodes + (last_op_number - 1);
    if ((int )last_op->opcode == 88) {
      if ((int )op == 36) {
        last_op->opcode = (zend_uchar )134;
      } else {
        last_op->opcode = (zend_uchar )135;
      }
      last_op->result_type = (zend_uchar )(1 << 1);
      last_op->result.var = get_temporary_variable(compiler_globals.active_op_array);
      while (1) {
        result->op_type = (int )last_op->result_type;
        if (result->op_type == 1) {
          result->u.constant = ((compiler_globals.active_op_array)->literals + last_op->result.constant)->constant;
        } else {
          result->u.op = last_op->result;
          result->EA = (zend_uint )0;
        }
        break;
      }
      return;
    } else {

    }
  } else {

  }
  opline = get_next_op(compiler_globals.active_op_array);
  opline->opcode = op;
  while (1) {
    opline->op1_type = (zend_uchar )op1->op_type;
    if (op1->op_type == 1) {
      tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                 & op1->u.constant);
      opline->op1.constant = (zend_uint )tmp___0;
    } else {
      __constr_expr_16 = op1->u.op;
      opline->op1 = __constr_expr_16;
    }
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  opline->result_type = (zend_uchar )(1 << 1);
  opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  while (1) {
    result->op_type = (int )opline->result_type;
    if (result->op_type == 1) {
      result->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      result->u.op = opline->result;
      result->EA = (zend_uint )0;
    }
    break;
  }
  return;
}
}
void zend_do_if_cond(znode const   *cond , znode *closing_bracket_token ) 
{ 
  int if_cond_op_number ;
  int tmp ;
  zend_op *opline ;
  zend_op *tmp___0 ;
  int tmp___1 ;
  znode_op __constr_expr_17 ;

  {
  tmp = get_next_op_number(compiler_globals.active_op_array);
  if_cond_op_number = tmp;
  tmp___0 = get_next_op(compiler_globals.active_op_array);
  opline = tmp___0;
  opline->opcode = (zend_uchar )43;
  while (1) {
    opline->op1_type = (zend_uchar )cond->op_type;
    if (cond->op_type == 1) {
      tmp___1 = zend_add_literal(compiler_globals.active_op_array,
                                 & cond->u.constant);
      opline->op1.constant = (zend_uint )tmp___1;
    } else {
      __constr_expr_17 = cond->u.op;
      opline->op1 = __constr_expr_17;
    }
    break;
  }
  closing_bracket_token->u.op.opline_num = (zend_uint )if_cond_op_number;
  opline->op2_type = (zend_uchar )(1 << 3);
  if ((compiler_globals.active_op_array)->fn_flags & 16U) {
    (compiler_globals.context.backpatch_count) ++;
  } else {

  }
  return;
}
}
void zend_do_if_after_statement(znode const   *closing_bracket_token ,
                                unsigned char initialize ) 
{ 
  int if_end_op_number ;
  int tmp ;
  zend_op *opline ;
  zend_op *tmp___0 ;
  zend_llist *jmp_list_ptr ;
  zend_llist jmp_list ;

  {
  tmp = get_next_op_number(compiler_globals.active_op_array);
  if_end_op_number = tmp;
  tmp___0 = get_next_op(compiler_globals.active_op_array);
  opline = tmp___0;
  opline->opcode = (zend_uchar )42;
  if (initialize) {
    zend_llist_init(& jmp_list, sizeof(int ), (void (*)(void * ))((void *)0),
                    (unsigned char)0);
    zend_stack_push(& compiler_globals.bp_stack,
                    (void const   *)((void *)(& jmp_list)),
                    (int )sizeof(zend_llist ));
  } else {

  }
  zend_stack_top((zend_stack const   *)(& compiler_globals.bp_stack),
                 (void **)(& jmp_list_ptr));
  zend_llist_add_element(jmp_list_ptr, (void *)(& if_end_op_number));
  ((compiler_globals.active_op_array)->opcodes + closing_bracket_token->u.op.opline_num)->op2.opline_num = (zend_uint )(if_end_op_number + 1);
  opline->op1_type = (zend_uchar )(1 << 3);
  opline->op2_type = (zend_uchar )(1 << 3);
  return;
}
}
void zend_do_if_end(void) 
{ 
  int next_op_number ;
  int tmp ;
  zend_llist *jmp_list_ptr ;
  zend_llist_element *le ;

  {
  tmp = get_next_op_number(compiler_globals.active_op_array);
  next_op_number = tmp;
  zend_stack_top((zend_stack const   *)(& compiler_globals.bp_stack),
                 (void **)(& jmp_list_ptr));
  le = jmp_list_ptr->head;
  while (le) {
    ((compiler_globals.active_op_array)->opcodes + *((int *)(le->data)))->op1.opline_num = (zend_uint )next_op_number;
    le = le->next;
  }
  zend_llist_destroy(jmp_list_ptr);
  zend_stack_del_top(& compiler_globals.bp_stack);
  if ((compiler_globals.active_op_array)->fn_flags & 16U) {
    (compiler_globals.context.backpatch_count) --;
  } else {

  }
  return;
}
}
void zend_check_writable_variable(znode const   *variable ) 
{ 
  zend_uint type ;

  {
  type = (zend_uint )variable->EA;
  if (type & (unsigned int )(1 << 1)) {
    zend_error(1 << 6L, "Can\'t use method return value in write context");
  } else {

  }
  if (type == (zend_uint )(1 << 3)) {
    zend_error(1 << 6L, "Can\'t use function return value in write context");
  } else {

  }
  return;
}
}
void zend_do_begin_variable_parse(void) 
{ 
  zend_llist fetch_list ;

  {
  zend_llist_init(& fetch_list, sizeof(zend_op ),
                  (void (*)(void * ))((void *)0), (unsigned char)0);
  zend_stack_push(& compiler_globals.bp_stack,
                  (void const   *)((void *)(& fetch_list)),
                  (int )sizeof(zend_llist ));
  return;
}
}
void zend_do_end_variable_parse(znode *variable , int type , int arg_offset ) 
{ 
  zend_llist *fetch_list_ptr ;
  zend_llist_element *le ;
  zend_op *opline ;
  zend_op *opline_ptr ;
  zend_uint this_var ;
  int tmp ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  int tmp___1 ;
  zend_bool tmp___2 ;

  {
  opline = (zend_op *)((void *)0);
  this_var = (zend_uint )-1;
  zend_stack_top((zend_stack const   *)(& compiler_globals.bp_stack),
                 (void **)(& fetch_list_ptr));
  le = fetch_list_ptr->head;
  if (le) {
    opline_ptr = (zend_op *)(le->data);
    tmp___2 = opline_is_fetch_this((zend_op const   *)opline_ptr);
    if (tmp___2) {
      if ((compiler_globals.active_op_array)->last == 0U) {
        goto _L;
      } else
      if ((int )((compiler_globals.active_op_array)->opcodes + ((compiler_globals.active_op_array)->last - 1U))->opcode != 57) {
        _L: 
        this_var = opline_ptr->result.var;
        if ((compiler_globals.active_op_array)->this_var == 4294967295U) {
          tmp = lookup_cv(compiler_globals.active_op_array,
                          ((compiler_globals.active_op_array)->literals + opline_ptr->op1.constant)->constant.value.str.val,
                          ((compiler_globals.active_op_array)->literals + opline_ptr->op1.constant)->constant.value.str.len,
                          ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline_ptr->op1.constant)->constant))->hash_value);
          (compiler_globals.active_op_array)->this_var = (zend_uint )tmp;
          ((compiler_globals.active_op_array)->literals + opline_ptr->op1.constant)->constant.type = (zend_uchar )0;
        } else {
          zend_del_literal(compiler_globals.active_op_array,
                           (int )opline_ptr->op1.constant);
        }
        le = le->next;
        if (variable->op_type == 1 << 2) {
          if (variable->u.op.var == this_var) {
            variable->op_type = 1 << 4;
            variable->u.op.var = (compiler_globals.active_op_array)->this_var;
          } else {

          }
        } else {

        }
      } else
      if ((compiler_globals.active_op_array)->this_var == 4294967295U) {
        tmp___0 = _estrndup("this", (unsigned int )(sizeof("this") - 1UL));
        tmp___1 = lookup_cv(compiler_globals.active_op_array, (char *)tmp___0,
                            (int )(sizeof("this") - 1UL), 210728972157UL);
        (compiler_globals.active_op_array)->this_var = (zend_uint )tmp___1;
      } else {

      }
    } else {

    }
    while (le) {
      opline_ptr = (zend_op *)(le->data);
      if ((int )opline_ptr->opcode == 156) {
        if (type != 0) {
          if (type != 3) {
            opline = get_next_op(compiler_globals.active_op_array);
            memcpy((void */* __restrict  */)opline,
                   (void const   */* __restrict  */)opline_ptr, sizeof(zend_op ));
          } else {

          }
        } else {

        }
        le = le->next;
        continue;
      } else {

      }
      opline = get_next_op(compiler_globals.active_op_array);
      memcpy((void */* __restrict  */)opline,
             (void const   */* __restrict  */)opline_ptr, sizeof(zend_op ));
      if ((int )opline->op1_type == 1 << 2) {
        if (opline->op1.var == this_var) {
          opline->op1_type = (zend_uchar )(1 << 4);
          opline->op1.var = (compiler_globals.active_op_array)->this_var;
        } else {

        }
      } else {

      }
      switch (type) {
      case 0: 
      if ((int )opline->opcode == 84) {
        if ((int )opline->op2_type == 1 << 3) {
          zend_error(1 << 6L, "Cannot use [] for reading");
        } else {

        }
      } else {

      }
      opline->opcode = (zend_uchar )((int )opline->opcode - 3);
      break;
      case 1: 
      break;
      case 2: 
      opline->opcode = (zend_uchar )((int )opline->opcode + 3);
      break;
      case 3: 
      if ((int )opline->opcode == 84) {
        if ((int )opline->op2_type == 1 << 3) {
          zend_error(1 << 6L, "Cannot use [] for reading");
        } else {

        }
      } else {

      }
      opline->opcode = (zend_uchar )((int )opline->opcode + 6);
      break;
      case 5: 
      opline->opcode = (zend_uchar )((int )opline->opcode + 9);
      opline->extended_value |= (unsigned long )arg_offset;
      break;
      case 6: 
      if ((int )opline->opcode == 84) {
        if ((int )opline->op2_type == 1 << 3) {
          zend_error(1 << 6L, "Cannot use [] for unsetting");
        } else {

        }
      } else {

      }
      opline->opcode = (zend_uchar )((int )opline->opcode + 12);
      break;
      }
      le = le->next;
    }
    if (opline) {
      if (type == 1) {
        if (arg_offset) {
          opline->extended_value |= 67108864UL;
        } else {

        }
      } else {

      }
    } else {

    }
  } else {

  }
  zend_llist_destroy(fetch_list_ptr);
  zend_stack_del_top(& compiler_globals.bp_stack);
  return;
}
}
void zend_do_add_string(znode *result , znode const   *op1 , znode *op2 ) 
{ 
  zend_op *opline ;
  int ch ;
  zval *__z ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  znode_op __constr_expr_18 ;
  znode_op __constr_expr_19 ;

  {
  if (op2->u.constant.value.str.len > 1) {
    opline = get_next_op(compiler_globals.active_op_array);
    opline->opcode = (zend_uchar )55;
  } else
  if (op2->u.constant.value.str.len == 1) {
    ch = (int )*(op2->u.constant.value.str.val);
    _efree((void *)op2->u.constant.value.str.val);
    __z = & op2->u.constant;
    __z->value.lval = (long )ch;
    __z->type = (zend_uchar )1;
    opline = get_next_op(compiler_globals.active_op_array);
    opline->opcode = (zend_uchar )54;
  } else {
    _efree((void *)op2->u.constant.value.str.val);
    return;
  }
  if (op1) {
    while (1) {
      opline->op1_type = (zend_uchar )op1->op_type;
      if (op1->op_type == 1) {
        tmp = zend_add_literal(compiler_globals.active_op_array,
                               & op1->u.constant);
        opline->op1.constant = (zend_uint )tmp;
      } else {
        __constr_expr_18 = op1->u.op;
        opline->op1 = __constr_expr_18;
      }
      break;
    }
    while (1) {
      opline->result_type = (zend_uchar )op1->op_type;
      if (op1->op_type == 1) {
        tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                   & op1->u.constant);
        opline->result.constant = (zend_uint )tmp___0;
      } else {
        __constr_expr_19 = op1->u.op;
        opline->result = __constr_expr_19;
      }
      break;
    }
  } else {
    opline->op1_type = (zend_uchar )(1 << 3);
    opline->result_type = (zend_uchar )(1 << 1);
    opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  }
  while (1) {
    opline->op2_type = (zend_uchar )op2->op_type;
    if (op2->op_type == 1) {
      tmp___1 = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& op2->u.constant));
      opline->op2.constant = (zend_uint )tmp___1;
    } else {
      opline->op2 = op2->u.op;
    }
    break;
  }
  while (1) {
    result->op_type = (int )opline->result_type;
    if (result->op_type == 1) {
      result->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      result->u.op = opline->result;
      result->EA = (zend_uint )0;
    }
    break;
  }
  return;
}
}
void zend_do_add_variable(znode *result , znode const   *op1 ,
                          znode const   *op2 ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  znode_op __constr_expr_20 ;
  znode_op __constr_expr_21 ;
  znode_op __constr_expr_22 ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  opline->opcode = (zend_uchar )56;
  if (op1) {
    while (1) {
      opline->op1_type = (zend_uchar )op1->op_type;
      if (op1->op_type == 1) {
        tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                   & op1->u.constant);
        opline->op1.constant = (zend_uint )tmp___0;
      } else {
        __constr_expr_20 = op1->u.op;
        opline->op1 = __constr_expr_20;
      }
      break;
    }
    while (1) {
      opline->result_type = (zend_uchar )op1->op_type;
      if (op1->op_type == 1) {
        tmp___1 = zend_add_literal(compiler_globals.active_op_array,
                                   & op1->u.constant);
        opline->result.constant = (zend_uint )tmp___1;
      } else {
        __constr_expr_21 = op1->u.op;
        opline->result = __constr_expr_21;
      }
      break;
    }
  } else {
    opline->op1_type = (zend_uchar )(1 << 3);
    opline->result_type = (zend_uchar )(1 << 1);
    opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  }
  while (1) {
    opline->op2_type = (zend_uchar )op2->op_type;
    if (op2->op_type == 1) {
      tmp___2 = zend_add_literal(compiler_globals.active_op_array,
                                 & op2->u.constant);
      opline->op2.constant = (zend_uint )tmp___2;
    } else {
      __constr_expr_22 = op2->u.op;
      opline->op2 = __constr_expr_22;
    }
    break;
  }
  while (1) {
    result->op_type = (int )opline->result_type;
    if (result->op_type == 1) {
      result->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      result->u.op = opline->result;
      result->EA = (zend_uint )0;
    }
    break;
  }
  return;
}
}
void zend_do_free(znode *op1 ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;
  zend_op *opline___0 ;
  int tmp___1 ;

  {
  if (op1->op_type == 1 << 1) {
    tmp = get_next_op(compiler_globals.active_op_array);
    opline = tmp;
    opline->opcode = (zend_uchar )70;
    while (1) {
      opline->op1_type = (zend_uchar )op1->op_type;
      if (op1->op_type == 1) {
        tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                   (zval const   *)(& op1->u.constant));
        opline->op1.constant = (zend_uint )tmp___0;
      } else {
        opline->op1 = op1->u.op;
      }
      break;
    }
    opline->op2_type = (zend_uchar )(1 << 3);
  } else
  if (op1->op_type == 1 << 2) {
    opline___0 = (compiler_globals.active_op_array)->opcodes + ((compiler_globals.active_op_array)->last - 1U);
    while (1) {
      if (! ((int )opline___0->opcode == 58)) {
        if (! ((int )opline___0->opcode == 103)) {
          if (! ((int )opline___0->opcode == 137)) {
            break;
          } else {

          }
        } else {

        }
      } else {

      }
      opline___0 --;
    }
    if ((int )opline___0->result_type == 1 << 2) {
      if (opline___0->result.var == op1->u.op.var) {
        if ((int )opline___0->opcode == 80) {
          goto _L;
        } else
        if ((int )opline___0->opcode == 81) {
          goto _L;
        } else
        if ((int )opline___0->opcode == 82) {
          goto _L;
        } else
        if ((int )opline___0->opcode == 157) {
          _L: 
          opline___0 = get_next_op(compiler_globals.active_op_array);
          opline___0->opcode = (zend_uchar )70;
          while (1) {
            opline___0->op1_type = (zend_uchar )op1->op_type;
            if (op1->op_type == 1) {
              tmp___1 = zend_add_literal(compiler_globals.active_op_array,
                                         (zval const   *)(& op1->u.constant));
              opline___0->op1.constant = (zend_uint )tmp___1;
            } else {
              opline___0->op1 = op1->u.op;
            }
            break;
          }
          opline___0->op2_type = (zend_uchar )(1 << 3);
        } else {
          opline___0->result_type = (zend_uchar )((int )opline___0->result_type | (1 << 5));
        }
      } else {
        goto _L___2;
      }
    } else {
      _L___2: 
      while ((unsigned long )opline___0 > (unsigned long )(compiler_globals.active_op_array)->opcodes) {
        if ((int )opline___0->opcode == 81) {
          if ((int )opline___0->op1_type == 1 << 2) {
            if (opline___0->op1.var == op1->u.op.var) {
              opline___0->extended_value = (ulong )0;
              break;
            } else {
              goto _L___1;
            }
          } else {
            goto _L___1;
          }
        } else
        _L___1: 
        if ((int )opline___0->result_type == 1 << 2) {
          if (opline___0->result.var == op1->u.op.var) {
            if ((int )opline___0->opcode == 68) {
              opline___0->result_type = (zend_uchar )((int )opline___0->result_type | (1 << 5));
            } else {

            }
            break;
          } else {

          }
        } else {

        }
        opline___0 --;
      }
    }
  } else
  if (op1->op_type == 1) {
    _zval_dtor(& op1->u.constant);
  } else {

  }
  return;
}
}
int zend_do_verify_access_types(znode const   *current_access_type ,
                                znode const   *new_modifier ) 
{ 


  {
  if (current_access_type->u.constant.value.lval & 1792L) {
    if (new_modifier->u.constant.value.lval & 1792L) {
      zend_error(1 << 6L, "Multiple access type modifiers are not allowed");
    } else {

    }
  } else {

  }
  if (current_access_type->u.constant.value.lval & 2L) {
    if (new_modifier->u.constant.value.lval & 2L) {
      zend_error(1 << 6L, "Multiple abstract modifiers are not allowed");
    } else {

    }
  } else {

  }
  if (current_access_type->u.constant.value.lval & 1L) {
    if (new_modifier->u.constant.value.lval & 1L) {
      zend_error(1 << 6L, "Multiple static modifiers are not allowed");
    } else {

    }
  } else {

  }
  if (current_access_type->u.constant.value.lval & 4L) {
    if (new_modifier->u.constant.value.lval & 4L) {
      zend_error(1 << 6L, "Multiple final modifiers are not allowed");
    } else {

    }
  } else {

  }
  if (((current_access_type->u.constant.value.lval | new_modifier->u.constant.value.lval) & 6L) == 6L) {
    zend_error(1 << 6L,
               "Cannot use the final modifier on an abstract class member");
  } else {

  }
  return ((int )(current_access_type->u.constant.value.lval | new_modifier->u.constant.value.lval));
}
}
void zend_do_begin_function_declaration(znode *function_token ,
                                        znode *function_name , int is_method ,
                                        int return_reference ,
                                        znode *fn_flags_znode ) 
{ 
  zend_op_array op_array ;
  char *name ;
  int name_len ;
  int function_begin_line ;
  zend_uint fn_flags ;
  char const   *lcname ;
  zend_bool orig_interactive ;
  zend_bool use_heap ;
  char const   *tmp ;
  char const   *tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;
  int result ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;
  char const __attribute__((__visibility__("default")))  *tmp___3 ;
  int __attribute__((__visibility__("default")))  tmp___4 ;
  int __attribute__((__visibility__("default")))  tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;
  int tmp___8 ;
  int tmp___9 ;
  int tmp___10 ;
  int tmp___11 ;
  int tmp___12 ;
  char *class_lcname ;
  void __attribute__((__visibility__("default")))  *tmp___14 ;
  void *tmp___15 ;
  long tmp___16 ;
  int tmp___17 ;
  int tmp___18 ;
  int tmp___19 ;
  int tmp___20 ;
  int tmp___21 ;
  int tmp___22 ;
  int tmp___23 ;
  int tmp___24 ;
  int tmp___25 ;
  int tmp___26 ;
  int tmp___27 ;
  long tmp___28 ;
  zend_op *opline ;
  zend_op *tmp___29 ;
  zval key ;
  znode tmp___30 ;
  char __attribute__((__visibility__("default")))  *tmp___31 ;
  char __attribute__((__visibility__("default")))  *tmp___32 ;
  int tmp___33 ;
  ulong __attribute__((__visibility__("default")))  tmp___34 ;
  zval _c ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  int tmp___36 ;
  ulong __attribute__((__visibility__("default")))  tmp___37 ;
  zend_op *opline___0 ;
  zend_op *tmp___38 ;
  zend_switch_entry switch_entry ;
  zend_op dummy_opline ;

  {
  name = function_name->u.constant.value.str.val;
  name_len = function_name->u.constant.value.str.len;
  function_begin_line = (int )function_token->u.op.opline_num;
  if (is_method) {
    if ((compiler_globals.active_class_entry)->ce_flags & 128U) {
      if (fn_flags_znode->u.constant.value.lval & -258L) {
        zend_error(1 << 6L,
                   "Access type for interface method %s::%s() must be omitted",
                   (compiler_globals.active_class_entry)->name,
                   function_name->u.constant.value.str.val);
      } else {

      }
      fn_flags_znode->u.constant.value.lval |= 2L;
    } else {

    }
    fn_flags = (zend_uint )fn_flags_znode->u.constant.value.lval;
  } else {
    fn_flags = (zend_uint )0;
  }
  if (fn_flags & 1U) {
    if (fn_flags & 2U) {
      if (! ((compiler_globals.active_class_entry)->ce_flags & 128U)) {
        if (is_method) {
          tmp = "::";
        } else {
          tmp = "";
        }
        if (is_method) {
          tmp___0 = (compiler_globals.active_class_entry)->name;
        } else {
          tmp___0 = "";
        }
        zend_error(1 << 11L, "Static function %s%s%s() should not be abstract",
                   tmp___0, tmp, function_name->u.constant.value.str.val);
      } else {

      }
    } else {

    }
  } else {

  }
  function_token->u.op_array = compiler_globals.active_op_array;
  orig_interactive = (zend_bool )compiler_globals.interactive;
  compiler_globals.interactive = 0;
  init_op_array(& op_array, (zend_uchar )2, 64);
  compiler_globals.interactive = (int )orig_interactive;
  op_array.function_name = (char const   *)name;
  if (return_reference) {
    op_array.fn_flags |= 67108864U;
  } else {

  }
  op_array.fn_flags |= fn_flags;
  if (is_method) {
    op_array.scope = compiler_globals.active_class_entry;
  } else {
    op_array.scope = (zend_class_entry *)((void *)0);
  }
  op_array.prototype = (union _zend_function *)((void *)0);
  tmp___1 = zend_get_compiled_lineno();
  op_array.line_start = (zend_uint )tmp___1;
  if (is_method) {
    tmp___2 = zend_str_tolower_dup((char const   *)name, (unsigned int )name_len);
    tmp___3 = (*zend_new_interned_string)((char const   *)tmp___2, name_len + 1,
                                          1);
    lcname = (char const   *)tmp___3;
    if ((unsigned long )lcname >= (unsigned long )compiler_globals.interned_strings_start) {
      if ((unsigned long )lcname < (unsigned long )compiler_globals.interned_strings_end) {
        tmp___4 = _zend_hash_quick_add_or_update(& (compiler_globals.active_class_entry)->function_table,
                                                 lcname, (uint )(name_len + 1),
                                                 ((Bucket *)((char *)lcname - sizeof(Bucket )))->h,
                                                 (void *)(& op_array),
                                                 (uint )sizeof(zend_op_array ),
                                                 (void **)(& compiler_globals.active_op_array),
                                                 1 << 1);
        result = (int )tmp___4;
      } else {
        tmp___5 = _zend_hash_add_or_update(& (compiler_globals.active_class_entry)->function_table,
                                           lcname, (uint )(name_len + 1),
                                           (void *)(& op_array),
                                           (uint )sizeof(zend_op_array ),
                                           (void **)(& compiler_globals.active_op_array),
                                           1 << 1);
        result = (int )tmp___5;
      }
    } else {
      tmp___5 = _zend_hash_add_or_update(& (compiler_globals.active_class_entry)->function_table,
                                         lcname, (uint )(name_len + 1),
                                         (void *)(& op_array),
                                         (uint )sizeof(zend_op_array ),
                                         (void **)(& compiler_globals.active_op_array),
                                         1 << 1);
      result = (int )tmp___5;
    }
    if (result == -1) {
      zend_error(1 << 6L, "Cannot redeclare %s::%s()",
                 (compiler_globals.active_class_entry)->name, name);
    } else {

    }
    zend_stack_push(& compiler_globals.context_stack,
                    (void const   *)((void *)(& compiler_globals.context)),
                    (int )sizeof(compiler_globals.context));
    zend_init_compiler_context();
    if (fn_flags & 2U) {
      (compiler_globals.active_class_entry)->ce_flags |= 16U;
    } else {

    }
    if (! (fn_flags & 1792U)) {
      fn_flags |= 256U;
    } else {

    }
    if ((compiler_globals.active_class_entry)->ce_flags & 128U) {
      if ((unsigned long )name_len == sizeof("__call") - 1UL) {
        tmp___12 = memcmp((void const   *)lcname, (void const   *)"__call",
                          sizeof("__call") - 1UL);
        if (tmp___12) {
          goto _L___4;
        } else
        if (fn_flags & 1537U) {
          zend_error(1 << 1L,
                     "The magic method __call() must have public visibility and cannot be static");
        } else {

        }
      } else
      _L___4: 
      if ((unsigned long )name_len == sizeof("__callstatic") - 1UL) {
        tmp___11 = memcmp((void const   *)lcname,
                          (void const   *)"__callstatic",
                          sizeof("__callstatic") - 1UL);
        if (tmp___11) {
          goto _L___3;
        } else
        if (fn_flags & 1536U) {
          zend_error(1 << 1L,
                     "The magic method __callStatic() must have public visibility and be static");
        } else
        if ((fn_flags & 1U) == 0U) {
          zend_error(1 << 1L,
                     "The magic method __callStatic() must have public visibility and be static");
        } else {

        }
      } else
      _L___3: 
      if ((unsigned long )name_len == sizeof("__get") - 1UL) {
        tmp___10 = memcmp((void const   *)lcname, (void const   *)"__get",
                          sizeof("__get") - 1UL);
        if (tmp___10) {
          goto _L___2;
        } else
        if (fn_flags & 1537U) {
          zend_error(1 << 1L,
                     "The magic method __get() must have public visibility and cannot be static");
        } else {

        }
      } else
      _L___2: 
      if ((unsigned long )name_len == sizeof("__set") - 1UL) {
        tmp___9 = memcmp((void const   *)lcname, (void const   *)"__set",
                         sizeof("__set") - 1UL);
        if (tmp___9) {
          goto _L___1;
        } else
        if (fn_flags & 1537U) {
          zend_error(1 << 1L,
                     "The magic method __set() must have public visibility and cannot be static");
        } else {

        }
      } else
      _L___1: 
      if ((unsigned long )name_len == sizeof("__unset") - 1UL) {
        tmp___8 = memcmp((void const   *)lcname, (void const   *)"__unset",
                         sizeof("__unset") - 1UL);
        if (tmp___8) {
          goto _L___0;
        } else
        if (fn_flags & 1537U) {
          zend_error(1 << 1L,
                     "The magic method __unset() must have public visibility and cannot be static");
        } else {

        }
      } else
      _L___0: 
      if ((unsigned long )name_len == sizeof("__isset") - 1UL) {
        tmp___7 = memcmp((void const   *)lcname, (void const   *)"__isset",
                         sizeof("__isset") - 1UL);
        if (tmp___7) {
          goto _L;
        } else
        if (fn_flags & 1537U) {
          zend_error(1 << 1L,
                     "The magic method __isset() must have public visibility and cannot be static");
        } else {

        }
      } else
      _L: 
      if ((unsigned long )name_len == sizeof("__tostring") - 1UL) {
        tmp___6 = memcmp((void const   *)lcname, (void const   *)"__tostring",
                         sizeof("__tostring") - 1UL);
        if (! tmp___6) {
          if (fn_flags & 1537U) {
            zend_error(1 << 1L,
                       "The magic method __toString() must have public visibility and cannot be static");
          } else {

          }
        } else {

        }
      } else {

      }
    } else {
      tmp___16 = __builtin_expect((long )((compiler_globals.active_class_entry)->name_length + 1U > 32768U),
                                  0L);
      use_heap = (zend_bool )tmp___16;
      if (use_heap) {
        tmp___14 = _emalloc((size_t )((compiler_globals.active_class_entry)->name_length + 1U));
        class_lcname = (char *)tmp___14;
      } else {
        tmp___15 = __builtin_alloca((unsigned long )((compiler_globals.active_class_entry)->name_length + 1U));
        class_lcname = (char *)tmp___15;
      }
      zend_str_tolower_copy(class_lcname,
                            (compiler_globals.active_class_entry)->name,
                            (compiler_globals.active_class_entry)->name_length);
      if ((compiler_globals.active_class_entry)->name_length == (zend_uint )name_len) {
        if (((compiler_globals.active_class_entry)->ce_flags & 288U) != 288U) {
          tmp___27 = memcmp((void const   *)class_lcname,
                            (void const   *)lcname, (size_t )name_len);
          if (tmp___27) {
            goto _L___16;
          } else
          if (! (compiler_globals.active_class_entry)->constructor) {
            (compiler_globals.active_class_entry)->constructor = (zend_function *)compiler_globals.active_op_array;
          } else {

          }
        } else {
          goto _L___16;
        }
      } else
      _L___16: 
      if ((unsigned long )name_len == sizeof("__construct") - 1UL) {
        tmp___26 = memcmp((void const   *)lcname, (void const   *)"__construct",
                          sizeof("__construct"));
        if (tmp___26) {
          goto _L___14;
        } else {
          if ((compiler_globals.active_class_entry)->constructor) {
            zend_error(1 << 11L,
                       "Redefining already defined constructor for class %s",
                       (compiler_globals.active_class_entry)->name);
          } else {

          }
          (compiler_globals.active_class_entry)->constructor = (zend_function *)compiler_globals.active_op_array;
        }
      } else
      _L___14: 
      if ((unsigned long )name_len == sizeof("__destruct") - 1UL) {
        tmp___25 = memcmp((void const   *)lcname, (void const   *)"__destruct",
                          sizeof("__destruct") - 1UL);
        if (tmp___25) {
          goto _L___13;
        } else {
          (compiler_globals.active_class_entry)->destructor = (zend_function *)compiler_globals.active_op_array;
        }
      } else
      _L___13: 
      if ((unsigned long )name_len == sizeof("__clone") - 1UL) {
        tmp___24 = memcmp((void const   *)lcname, (void const   *)"__clone",
                          sizeof("__clone") - 1UL);
        if (tmp___24) {
          goto _L___12;
        } else {
          (compiler_globals.active_class_entry)->clone = (zend_function *)compiler_globals.active_op_array;
        }
      } else
      _L___12: 
      if ((unsigned long )name_len == sizeof("__call") - 1UL) {
        tmp___23 = memcmp((void const   *)lcname, (void const   *)"__call",
                          sizeof("__call") - 1UL);
        if (tmp___23) {
          goto _L___11;
        } else {
          if (fn_flags & 1537U) {
            zend_error(1 << 1L,
                       "The magic method __call() must have public visibility and cannot be static");
          } else {

          }
          (compiler_globals.active_class_entry)->__call = (zend_function *)compiler_globals.active_op_array;
        }
      } else
      _L___11: 
      if ((unsigned long )name_len == sizeof("__callstatic") - 1UL) {
        tmp___22 = memcmp((void const   *)lcname,
                          (void const   *)"__callstatic",
                          sizeof("__callstatic") - 1UL);
        if (tmp___22) {
          goto _L___10;
        } else {
          if (fn_flags & 1536U) {
            zend_error(1 << 1L,
                       "The magic method __callStatic() must have public visibility and be static");
          } else
          if ((fn_flags & 1U) == 0U) {
            zend_error(1 << 1L,
                       "The magic method __callStatic() must have public visibility and be static");
          } else {

          }
          (compiler_globals.active_class_entry)->__callstatic = (zend_function *)compiler_globals.active_op_array;
        }
      } else
      _L___10: 
      if ((unsigned long )name_len == sizeof("__get") - 1UL) {
        tmp___21 = memcmp((void const   *)lcname, (void const   *)"__get",
                          sizeof("__get") - 1UL);
        if (tmp___21) {
          goto _L___9;
        } else {
          if (fn_flags & 1537U) {
            zend_error(1 << 1L,
                       "The magic method __get() must have public visibility and cannot be static");
          } else {

          }
          (compiler_globals.active_class_entry)->__get = (zend_function *)compiler_globals.active_op_array;
        }
      } else
      _L___9: 
      if ((unsigned long )name_len == sizeof("__set") - 1UL) {
        tmp___20 = memcmp((void const   *)lcname, (void const   *)"__set",
                          sizeof("__set") - 1UL);
        if (tmp___20) {
          goto _L___8;
        } else {
          if (fn_flags & 1537U) {
            zend_error(1 << 1L,
                       "The magic method __set() must have public visibility and cannot be static");
          } else {

          }
          (compiler_globals.active_class_entry)->__set = (zend_function *)compiler_globals.active_op_array;
        }
      } else
      _L___8: 
      if ((unsigned long )name_len == sizeof("__unset") - 1UL) {
        tmp___19 = memcmp((void const   *)lcname, (void const   *)"__unset",
                          sizeof("__unset") - 1UL);
        if (tmp___19) {
          goto _L___7;
        } else {
          if (fn_flags & 1537U) {
            zend_error(1 << 1L,
                       "The magic method __unset() must have public visibility and cannot be static");
          } else {

          }
          (compiler_globals.active_class_entry)->__unset = (zend_function *)compiler_globals.active_op_array;
        }
      } else
      _L___7: 
      if ((unsigned long )name_len == sizeof("__isset") - 1UL) {
        tmp___18 = memcmp((void const   *)lcname, (void const   *)"__isset",
                          sizeof("__isset") - 1UL);
        if (tmp___18) {
          goto _L___6;
        } else {
          if (fn_flags & 1537U) {
            zend_error(1 << 1L,
                       "The magic method __isset() must have public visibility and cannot be static");
          } else {

          }
          (compiler_globals.active_class_entry)->__isset = (zend_function *)compiler_globals.active_op_array;
        }
      } else
      _L___6: 
      if ((unsigned long )name_len == sizeof("__tostring") - 1UL) {
        tmp___17 = memcmp((void const   *)lcname, (void const   *)"__tostring",
                          sizeof("__tostring") - 1UL);
        if (tmp___17) {
          goto _L___5;
        } else {
          if (fn_flags & 1537U) {
            zend_error(1 << 1L,
                       "The magic method __toString() must have public visibility and cannot be static");
          } else {

          }
          (compiler_globals.active_class_entry)->__tostring = (zend_function *)compiler_globals.active_op_array;
        }
      } else
      _L___5: 
      if (! (fn_flags & 1U)) {
        (compiler_globals.active_op_array)->fn_flags |= 65536U;
      } else {

      }
      while (1) {
        tmp___28 = __builtin_expect((long )use_heap, 0L);
        if (tmp___28) {
          _efree((void *)class_lcname);
        } else {

        }
        break;
      }
    }
    while (1) {
      if ((unsigned long )lcname >= (unsigned long )compiler_globals.interned_strings_start) {
        if (! ((unsigned long )lcname < (unsigned long )compiler_globals.interned_strings_end)) {
          _efree((void *)((char *)lcname));
        } else {

        }
      } else {
        _efree((void *)((char *)lcname));
      }
      break;
    }
  } else {
    tmp___29 = get_next_op(compiler_globals.active_op_array);
    opline = tmp___29;
    if (compiler_globals.current_namespace) {
      tmp___30.u.constant = *(compiler_globals.current_namespace);
      _zval_copy_ctor(& tmp___30.u.constant);
      zend_do_build_namespace_name(& tmp___30, & tmp___30, function_name);
      op_array.function_name = (char const   *)tmp___30.u.constant.value.str.val;
      name_len = tmp___30.u.constant.value.str.len;
      tmp___31 = zend_str_tolower_dup((char const   *)tmp___30.u.constant.value.str.val,
                                      (unsigned int )name_len);
      lcname = (char const   *)tmp___31;
    } else {
      tmp___32 = zend_str_tolower_dup((char const   *)name,
                                      (unsigned int )name_len);
      lcname = (char const   *)tmp___32;
    }
    opline->opcode = (zend_uchar )141;
    opline->op1_type = (zend_uchar )1;
    build_runtime_defined_function_key(& key, lcname, name_len);
    tmp___33 = zend_add_literal(compiler_globals.active_op_array,
                                (zval const   *)(& key));
    opline->op1.constant = (zend_uint )tmp___33;
    tmp___34 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val,
                              (uint )((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.len);
    ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant))->hash_value = (zend_ulong )tmp___34;
    opline->op2_type = (zend_uchar )1;
    while (1) {
      while (1) {
        __s = lcname;
        __l = name_len;
        __z = & _c;
        __z->value.str.len = __l;
        __z->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
        __z->type = (zend_uchar )6;
        break;
      }
      tmp___36 = zend_add_literal(compiler_globals.active_op_array,
                                  (zval const   *)(& _c));
      opline->op2.constant = (zend_uint )tmp___36;
      break;
    }
    while (1) {
      if ((unsigned long )((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
        if ((unsigned long )((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end) {
          ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant))->hash_value = ((Bucket *)(((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val - sizeof(Bucket )))->h;
        } else {
          tmp___37 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val,
                                    (uint )(((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.len + 1));
          ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant))->hash_value = (zend_ulong )tmp___37;
        }
      } else {
        tmp___37 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val,
                                  (uint )(((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.len + 1));
        ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant))->hash_value = (zend_ulong )tmp___37;
      }
      break;
    }
    opline->extended_value = (ulong )141;
    _zend_hash_quick_add_or_update(compiler_globals.function_table,
                                   (char const   *)key.value.str.val,
                                   (uint )key.value.str.len,
                                   ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant))->hash_value,
                                   (void *)(& op_array),
                                   (uint )sizeof(zend_op_array ),
                                   (void **)(& compiler_globals.active_op_array),
                                   1);
    zend_stack_push(& compiler_globals.context_stack,
                    (void const   *)((void *)(& compiler_globals.context)),
                    (int )sizeof(compiler_globals.context));
    zend_init_compiler_context();
  }
  if (compiler_globals.compiler_options & 1U) {
    tmp___38 = get_next_op(compiler_globals.active_op_array);
    opline___0 = tmp___38;
    opline___0->opcode = (zend_uchar )104;
    opline___0->lineno = (uint )function_begin_line;
    opline___0->op1_type = (zend_uchar )(1 << 3);
    opline___0->op2_type = (zend_uchar )(1 << 3);
  } else {

  }
  switch_entry.cond.op_type = 1 << 3;
  switch_entry.default_case = 0;
  switch_entry.control_var = 0;
  zend_stack_push(& compiler_globals.switch_cond_stack,
                  (void const   *)((void *)(& switch_entry)),
                  (int )sizeof(switch_entry));
  dummy_opline.result_type = (zend_uchar )(1 << 3);
  dummy_opline.op1_type = (zend_uchar )(1 << 3);
  zend_stack_push(& compiler_globals.foreach_copy_stack,
                  (void const   *)((void *)(& dummy_opline)),
                  (int )sizeof(zend_op ));
  if (compiler_globals.doc_comment) {
    (compiler_globals.active_op_array)->doc_comment = (char const   *)compiler_globals.doc_comment;
    (compiler_globals.active_op_array)->doc_comment_len = compiler_globals.doc_comment_len;
    compiler_globals.doc_comment = (char *)((void *)0);
    compiler_globals.doc_comment_len = (zend_uint )0;
  } else {

  }
  return;
}
}
void zend_do_begin_lambda_function_declaration(znode *result ,
                                               znode *function_token ,
                                               int return_reference ,
                                               int is_static ) 
{ 
  znode function_name ;
  zend_op_array *current_op_array ;
  int current_op_number ;
  int tmp ;
  zend_op *current_op ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  int tmp___1 ;

  {
  current_op_array = compiler_globals.active_op_array;
  tmp = get_next_op_number(compiler_globals.active_op_array);
  current_op_number = tmp;
  function_name.op_type = 1;
  while (1) {
    __s = "{closure}";
    __l = (int )(sizeof("{closure}") - 1UL);
    __z = & function_name.u.constant;
    __z->value.str.len = __l;
    tmp___0 = _estrndup(__s, (unsigned int )__l);
    __z->value.str.val = (char *)tmp___0;
    __z->type = (zend_uchar )6;
    break;
  }
  zend_do_begin_function_declaration(function_token, & function_name, 0,
                                     return_reference, (znode *)((void *)0));
  result->op_type = 1 << 1;
  result->u.op.var = get_temporary_variable(current_op_array);
  current_op = current_op_array->opcodes + current_op_number;
  current_op->opcode = (zend_uchar )153;
  zend_del_literal(current_op_array, (int )current_op->op2.constant);
  current_op->op2_type = (zend_uchar )(1 << 3);
  while (1) {
    current_op->result_type = (zend_uchar )result->op_type;
    if (result->op_type == 1) {
      tmp___1 = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& result->u.constant));
      current_op->result.constant = (zend_uint )tmp___1;
    } else {
      current_op->result = result->u.op;
    }
    break;
  }
  if (is_static) {
    (compiler_globals.active_op_array)->fn_flags |= 1U;
  } else {

  }
  (compiler_globals.active_op_array)->fn_flags |= 1048576U;
  return;
}
}
void zend_do_handle_exception(void) 
{ 
  zend_op *opline ;
  zend_op *tmp ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  opline->opcode = (zend_uchar )149;
  opline->op1_type = (zend_uchar )(1 << 3);
  opline->op2_type = (zend_uchar )(1 << 3);
  return;
}
}
void zend_do_end_function_declaration(znode const   *function_token ) 
{ 
  char lcname[16] ;
  int name_len ;
  size_t tmp ;
  unsigned long tmp___0 ;
  int tmp___1 ;
  int __attribute__((__visibility__("default")))  tmp___2 ;

  {
  zend_do_extended_info();
  zend_do_return((znode *)((void *)0), 0);
  pass_two(compiler_globals.active_op_array);
  zend_release_labels();
  if (compiler_globals.active_class_entry) {
    zend_check_magic_method_implementation((zend_class_entry const   *)compiler_globals.active_class_entry,
                                           (zend_function const   *)((zend_function *)compiler_globals.active_op_array),
                                           1 << 6L);
  } else {
    tmp = strlen((compiler_globals.active_op_array)->function_name);
    name_len = (int )tmp;
    if ((unsigned long )name_len < sizeof(lcname) - 1UL) {
      tmp___0 = (unsigned long )name_len;
    } else {
      tmp___0 = sizeof(lcname) - 1UL;
    }
    zend_str_tolower_copy(lcname,
                          (compiler_globals.active_op_array)->function_name,
                          (unsigned int )tmp___0);
    lcname[sizeof(lcname) - 1UL] = (char )'\000';
    if ((unsigned long )name_len == sizeof("__autoload") - 1UL) {
      tmp___1 = memcmp((void const   *)(lcname), (void const   *)"__autoload",
                       sizeof("__autoload"));
      if (! tmp___1) {
        if ((compiler_globals.active_op_array)->num_args != 1U) {
          zend_error(1 << 6L, "%s() must take exactly 1 argument", "__autoload");
        } else {

        }
      } else {

      }
    } else {

    }
  }
  tmp___2 = zend_get_compiled_lineno();
  (compiler_globals.active_op_array)->line_end = (zend_uint )tmp___2;
  compiler_globals.active_op_array = (zend_op_array *)function_token->u.op_array;
  zend_stack_del_top(& compiler_globals.switch_cond_stack);
  zend_stack_del_top(& compiler_globals.foreach_copy_stack);
  return;
}
}
void zend_do_receive_arg(zend_uchar op , znode *varname ,
                         znode const   *offset , znode const   *initialization ,
                         znode *class_type , unsigned char pass_by_reference ) 
{ 
  zend_op *opline ;
  zend_arg_info *cur_arg_info ;
  znode var ;
  int tmp ;
  int tmp___0 ;
  zend_bool __attribute__((__visibility__("default")))  tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  void __attribute__((__visibility__("default")))  *tmp___5 ;
  char __attribute__((__visibility__("default")))  *tmp___6 ;
  char const __attribute__((__visibility__("default")))  *tmp___7 ;
  int tmp___8 ;
  int tmp___9 ;
  int tmp___10 ;
  char const __attribute__((__visibility__("default")))  *tmp___11 ;
  int tmp___12 ;
  znode_op __constr_expr_23 ;
  znode_op __constr_expr_24 ;

  {
  if (class_type->op_type == 1) {
    if ((int )class_type->u.constant.type == 6) {
      if (class_type->u.constant.value.str.len == 0) {
        _zval_dtor(& class_type->u.constant);
        zend_error(1 << 6L, "Cannot use \'namespace\' as a class name");
        return;
      } else {

      }
    } else {

    }
  } else {

  }
  tmp___1 = zend_is_auto_global_quick((char const   *)varname->u.constant.value.str.val,
                                      (uint )varname->u.constant.value.str.len,
                                      (ulong )0);
  if (tmp___1) {
    zend_error(1 << 6L, "Cannot re-assign auto-global variable %s",
               varname->u.constant.value.str.val);
  } else {
    var.op_type = 1 << 4;
    tmp = lookup_cv(compiler_globals.active_op_array,
                    varname->u.constant.value.str.val,
                    varname->u.constant.value.str.len, (ulong )0);
    var.u.op.var = (zend_uint )tmp;
    varname->u.constant.value.str.val = (char *)((compiler_globals.active_op_array)->vars + var.u.op.var)->name;
    var.EA = (zend_uint )0;
    if (((compiler_globals.active_op_array)->vars + var.u.op.var)->hash_value == 210728972157UL) {
      if ((unsigned long )varname->u.constant.value.str.len == sizeof("this") - 1UL) {
        tmp___0 = memcmp((void const   *)varname->u.constant.value.str.val,
                         (void const   *)"this", sizeof("this") - 1UL);
        if (! tmp___0) {
          if ((compiler_globals.active_op_array)->scope) {
            if (((compiler_globals.active_op_array)->fn_flags & 1U) == 0U) {
              zend_error(1 << 6L, "Cannot re-assign $this");
            } else {

            }
          } else {

          }
          (compiler_globals.active_op_array)->this_var = var.u.op.var;
        } else {

        }
      } else {

      }
    } else {

    }
  }
  opline = get_next_op(compiler_globals.active_op_array);
  ((compiler_globals.active_op_array)->num_args) ++;
  opline->opcode = op;
  while (1) {
    opline->result_type = (zend_uchar )var.op_type;
    if (var.op_type == 1) {
      tmp___2 = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& var.u.constant));
      opline->result.constant = (zend_uint )tmp___2;
    } else {
      opline->result = var.u.op;
    }
    break;
  }
  while (1) {
    opline->op1_type = (zend_uchar )offset->op_type;
    if (offset->op_type == 1) {
      tmp___3 = zend_add_literal(compiler_globals.active_op_array,
                                 & offset->u.constant);
      opline->op1.constant = (zend_uint )tmp___3;
    } else {
      __constr_expr_23 = offset->u.op;
      opline->op1 = __constr_expr_23;
    }
    break;
  }
  if ((int )op == 64) {
    while (1) {
      opline->op2_type = (zend_uchar )initialization->op_type;
      if (initialization->op_type == 1) {
        tmp___4 = zend_add_literal(compiler_globals.active_op_array,
                                   & initialization->u.constant);
        opline->op2.constant = (zend_uint )tmp___4;
      } else {
        __constr_expr_24 = initialization->u.op;
        opline->op2 = __constr_expr_24;
      }
      break;
    }
  } else {
    (compiler_globals.active_op_array)->required_num_args = (compiler_globals.active_op_array)->num_args;
    opline->op2_type = (zend_uchar )(1 << 3);
  }
  tmp___5 = _erealloc((void *)(compiler_globals.active_op_array)->arg_info,
                      sizeof(zend_arg_info ) * (unsigned long )(compiler_globals.active_op_array)->num_args,
                      0);
  (compiler_globals.active_op_array)->arg_info = (zend_arg_info *)tmp___5;
  cur_arg_info = (compiler_globals.active_op_array)->arg_info + ((compiler_globals.active_op_array)->num_args - 1U);
  tmp___6 = _estrndup((char const   *)varname->u.constant.value.str.val,
                      (unsigned int )varname->u.constant.value.str.len);
  tmp___7 = (*zend_new_interned_string)((char const   *)tmp___6,
                                        varname->u.constant.value.str.len + 1, 1);
  cur_arg_info->name = (char const   *)tmp___7;
  cur_arg_info->name_len = (zend_uint )varname->u.constant.value.str.len;
  cur_arg_info->type_hint = (zend_uchar )0;
  cur_arg_info->allow_null = (zend_bool )1;
  cur_arg_info->pass_by_reference = pass_by_reference;
  cur_arg_info->class_name = (char const   *)((void *)0);
  cur_arg_info->class_name_len = (zend_uint )0;
  if (class_type->op_type != 1 << 3) {
    cur_arg_info->allow_null = (zend_bool )0;
    if ((int )class_type->u.constant.type != 0) {
      if ((int )class_type->u.constant.type == 4) {
        cur_arg_info->type_hint = (zend_uchar )4;
        if ((int )op == 64) {
          if ((int const   )initialization->u.constant.type == 0) {
            cur_arg_info->allow_null = (zend_bool )1;
          } else
          if ((int const   )initialization->u.constant.type == 8) {
            tmp___8 = strcasecmp((char const   *)initialization->u.constant.value.str.val,
                                 "NULL");
            if (tmp___8) {
              goto _L;
            } else {
              cur_arg_info->allow_null = (zend_bool )1;
            }
          } else
          _L: 
          if ((int const   )initialization->u.constant.type != 4) {
            if ((int const   )initialization->u.constant.type != 9) {
              zend_error(1 << 6L,
                         "Default value for parameters with array type hint can only be an array or NULL");
            } else {

            }
          } else {

          }
        } else {

        }
      } else
      if ((int )class_type->u.constant.type == 10) {
        cur_arg_info->type_hint = (zend_uchar )10;
        if ((int )op == 64) {
          if ((int const   )initialization->u.constant.type == 0) {
            cur_arg_info->allow_null = (zend_bool )1;
          } else
          if ((int const   )initialization->u.constant.type == 8) {
            tmp___9 = strcasecmp((char const   *)initialization->u.constant.value.str.val,
                                 "NULL");
            if (tmp___9) {
              zend_error(1 << 6L,
                         "Default value for parameters with callable type hint can only be NULL");
            } else {
              cur_arg_info->allow_null = (zend_bool )1;
            }
          } else {
            zend_error(1 << 6L,
                       "Default value for parameters with callable type hint can only be NULL");
          }
        } else {

        }
      } else {
        cur_arg_info->type_hint = (zend_uchar )5;
        tmp___10 = zend_get_class_fetch_type((char const   *)class_type->u.constant.value.str.val,
                                             (uint )class_type->u.constant.value.str.len);
        if (0 == tmp___10) {
          zend_resolve_class_name(class_type, opline->extended_value, 1);
        } else {

        }
        tmp___11 = (*zend_new_interned_string)((char const   *)class_type->u.constant.value.str.val,
                                               class_type->u.constant.value.str.len + 1,
                                               1);
        class_type->u.constant.value.str.val = (char *)tmp___11;
        cur_arg_info->class_name = (char const   *)class_type->u.constant.value.str.val;
        cur_arg_info->class_name_len = (zend_uint )class_type->u.constant.value.str.len;
        if ((int )op == 64) {
          if ((int const   )initialization->u.constant.type == 0) {
            cur_arg_info->allow_null = (zend_bool )1;
          } else
          if ((int const   )initialization->u.constant.type == 8) {
            tmp___12 = strcasecmp((char const   *)initialization->u.constant.value.str.val,
                                  "NULL");
            if (tmp___12) {
              zend_error(1 << 6L,
                         "Default value for parameters with a class type hint can only be NULL");
            } else {
              cur_arg_info->allow_null = (zend_bool )1;
            }
          } else {
            zend_error(1 << 6L,
                       "Default value for parameters with a class type hint can only be NULL");
          }
        } else {

        }
      }
    } else {

    }
  } else {

  }
  return;
}
}
int zend_do_begin_function_call(znode *function_name ,
                                zend_bool check_namespace ) 
{ 
  zend_function *function ;
  char *lcname ;
  char *is_compound ;
  void *tmp ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;

  {
  tmp = memchr((void const   *)function_name->u.constant.value.str.val, '\\',
               (size_t )function_name->u.constant.value.str.len);
  is_compound = (char *)tmp;
  zend_resolve_non_class_name(function_name, check_namespace);
  if (check_namespace) {
    if (compiler_globals.current_namespace) {
      if (! is_compound) {
        zend_do_begin_dynamic_function_call(function_name, 1);
        return (1);
      } else {

      }
    } else {

    }
  } else {

  }
  tmp___0 = zend_str_tolower_dup((char const   *)function_name->u.constant.value.str.val,
                                 (unsigned int )function_name->u.constant.value.str.len);
  lcname = (char *)tmp___0;
  tmp___1 = zend_hash_find((HashTable const   *)compiler_globals.function_table,
                           (char const   *)lcname,
                           (uint )(function_name->u.constant.value.str.len + 1),
                           (void **)(& function));
  if (tmp___1 == (int __attribute__((__visibility__("default")))  )-1) {
    zend_do_begin_dynamic_function_call(function_name, 0);
    _efree((void *)lcname);
    return (1);
  } else
  if (compiler_globals.compiler_options & (unsigned int )(1 << 2)) {
    if ((int )function->type == 1) {
      zend_do_begin_dynamic_function_call(function_name, 0);
      _efree((void *)lcname);
      return (1);
    } else {

    }
  } else {

  }
  _efree((void *)function_name->u.constant.value.str.val);
  function_name->u.constant.value.str.val = lcname;
  zend_stack_push(& compiler_globals.function_call_stack,
                  (void const   *)((void *)(& function)),
                  (int )sizeof(zend_function *));
  zend_do_extended_fcall_begin();
  return (0);
}
}
void zend_do_begin_method_call(znode *left_bracket ) 
{ 
  zend_op *last_op ;
  int last_op_number ;
  unsigned char *ptr ;
  int tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  zval name ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  int tmp___2 ;
  void __attribute__((__visibility__("default")))  *tmp___3 ;
  zend_op *opline ;
  zend_op *tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;
  void __attribute__((__visibility__("default")))  *tmp___7 ;
  int tmp___8 ;

  {
  ptr = (unsigned char *)((void *)0);
  zend_do_end_variable_parse(left_bracket, 0, 0);
  zend_do_begin_variable_parse();
  tmp = get_next_op_number(compiler_globals.active_op_array);
  last_op_number = tmp - 1;
  last_op = (compiler_globals.active_op_array)->opcodes + last_op_number;
  if ((int )last_op->op2_type == 1) {
    if ((int )((compiler_globals.active_op_array)->literals + last_op->op2.constant)->constant.type == 6) {
      if ((unsigned long )((compiler_globals.active_op_array)->literals + last_op->op2.constant)->constant.value.str.len == sizeof("__clone") - 1UL) {
        tmp___0 = zend_binary_strcasecmp((char const   *)((compiler_globals.active_op_array)->literals + last_op->op2.constant)->constant.value.str.val,
                                         (uint )((compiler_globals.active_op_array)->literals + last_op->op2.constant)->constant.value.str.len,
                                         "__clone",
                                         (uint )(sizeof("__clone") - 1UL));
        if (! tmp___0) {
          zend_error(1 << 6L,
                     "Cannot call __clone() method on objects - use \'clone $obj\' instead");
        } else {

        }
      } else {

      }
    } else {

    }
  } else {

  }
  if ((int )last_op->opcode == 82) {
    if ((int )last_op->op2_type == 1) {
      name = ((compiler_globals.active_op_array)->literals + last_op->op2.constant)->constant;
      if ((unsigned long )name.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
        if (! ((unsigned long )name.value.str.val < (unsigned long )compiler_globals.interned_strings_end)) {
          tmp___1 = _estrndup((char const   *)name.value.str.val,
                              (unsigned int )name.value.str.len);
          name.value.str.val = (char *)tmp___1;
        } else {

        }
      } else {
        tmp___1 = _estrndup((char const   *)name.value.str.val,
                            (unsigned int )name.value.str.len);
        name.value.str.val = (char *)tmp___1;
      }
      while (1) {
        if (((compiler_globals.active_op_array)->literals + last_op->op2.constant)->cache_slot == (zend_uint )((compiler_globals.active_op_array)->last_cache_slot - 2)) {
          ((compiler_globals.active_op_array)->literals + last_op->op2.constant)->cache_slot = (zend_uint )-1;
          (compiler_globals.active_op_array)->last_cache_slot -= 2;
        } else {

        }
        break;
      }
      tmp___2 = zend_add_func_name_literal(compiler_globals.active_op_array,
                                           (zval const   *)(& name));
      last_op->op2.constant = (zend_uint )tmp___2;
      while (1) {
        ((compiler_globals.active_op_array)->literals + last_op->op2.constant)->cache_slot = (zend_uint )(compiler_globals.active_op_array)->last_cache_slot;
        (compiler_globals.active_op_array)->last_cache_slot += 2;
        if ((compiler_globals.active_op_array)->fn_flags & 16U) {
          if ((compiler_globals.active_op_array)->run_time_cache) {
            tmp___3 = _erealloc((void *)(compiler_globals.active_op_array)->run_time_cache,
                                (unsigned long )(compiler_globals.active_op_array)->last_cache_slot * sizeof(void *),
                                0);
            (compiler_globals.active_op_array)->run_time_cache = (void **)tmp___3;
            *((compiler_globals.active_op_array)->run_time_cache + ((compiler_globals.active_op_array)->last_cache_slot - 1)) = (void *)0;
            *((compiler_globals.active_op_array)->run_time_cache + ((compiler_globals.active_op_array)->last_cache_slot - 2)) = (void *)0;
          } else {

          }
        } else {

        }
        break;
      }
    } else {

    }
    last_op->opcode = (zend_uchar )112;
    last_op->result_type = (zend_uchar )(1 << 3);
    left_bracket->u.constant.value.lval = 59L;
  } else {
    tmp___4 = get_next_op(compiler_globals.active_op_array);
    opline = tmp___4;
    opline->opcode = (zend_uchar )59;
    opline->op1_type = (zend_uchar )(1 << 3);
    if (left_bracket->op_type == 1) {
      opline->op2_type = (zend_uchar )1;
      tmp___5 = zend_add_func_name_literal(compiler_globals.active_op_array,
                                           (zval const   *)(& left_bracket->u.constant));
      opline->op2.constant = (zend_uint )tmp___5;
      while (1) {
        tmp___6 = (compiler_globals.active_op_array)->last_cache_slot;
        ((compiler_globals.active_op_array)->last_cache_slot) ++;
        ((compiler_globals.active_op_array)->literals + opline->op2.constant)->cache_slot = (zend_uint )tmp___6;
        if ((compiler_globals.active_op_array)->fn_flags & 16U) {
          if ((compiler_globals.active_op_array)->run_time_cache) {
            tmp___7 = _erealloc((void *)(compiler_globals.active_op_array)->run_time_cache,
                                (unsigned long )(compiler_globals.active_op_array)->last_cache_slot * sizeof(void *),
                                0);
            (compiler_globals.active_op_array)->run_time_cache = (void **)tmp___7;
            *((compiler_globals.active_op_array)->run_time_cache + ((compiler_globals.active_op_array)->last_cache_slot - 1)) = (void *)0;
          } else {

          }
        } else {

        }
        break;
      }
    } else {
      while (1) {
        opline->op2_type = (zend_uchar )left_bracket->op_type;
        if (left_bracket->op_type == 1) {
          tmp___8 = zend_add_literal(compiler_globals.active_op_array,
                                     (zval const   *)(& left_bracket->u.constant));
          opline->op2.constant = (zend_uint )tmp___8;
        } else {
          opline->op2 = left_bracket->u.op;
        }
        break;
      }
    }
  }
  zend_stack_push(& compiler_globals.function_call_stack,
                  (void const   *)((void *)(& ptr)),
                  (int )sizeof(zend_function *));
  zend_do_extended_fcall_begin();
  return;
}
}
void zend_do_clone(znode *result , znode const   *expr ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;
  znode_op __constr_expr_25 ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  opline->opcode = (zend_uchar )110;
  while (1) {
    opline->op1_type = (zend_uchar )expr->op_type;
    if (expr->op_type == 1) {
      tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                 & expr->u.constant);
      opline->op1.constant = (zend_uint )tmp___0;
    } else {
      __constr_expr_25 = expr->u.op;
      opline->op1 = __constr_expr_25;
    }
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  opline->result_type = (zend_uchar )(1 << 2);
  opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  while (1) {
    result->op_type = (int )opline->result_type;
    if (result->op_type == 1) {
      result->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      result->u.op = opline->result;
      result->EA = (zend_uint )0;
    }
    break;
  }
  return;
}
}
void zend_do_begin_dynamic_function_call(znode *function_name , int ns_call ) 
{ 
  unsigned char *ptr ;
  zend_op *opline ;
  int tmp ;
  int tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  void __attribute__((__visibility__("default")))  *tmp___4 ;
  int tmp___5 ;

  {
  ptr = (unsigned char *)((void *)0);
  opline = get_next_op(compiler_globals.active_op_array);
  if (ns_call) {
    opline->opcode = (zend_uchar )69;
    opline->op1_type = (zend_uchar )(1 << 3);
    opline->op2_type = (zend_uchar )1;
    tmp = zend_add_ns_func_name_literal(compiler_globals.active_op_array,
                                        (zval const   *)(& function_name->u.constant));
    opline->op2.constant = (zend_uint )tmp;
    while (1) {
      tmp___0 = (compiler_globals.active_op_array)->last_cache_slot;
      ((compiler_globals.active_op_array)->last_cache_slot) ++;
      ((compiler_globals.active_op_array)->literals + opline->op2.constant)->cache_slot = (zend_uint )tmp___0;
      if ((compiler_globals.active_op_array)->fn_flags & 16U) {
        if ((compiler_globals.active_op_array)->run_time_cache) {
          tmp___1 = _erealloc((void *)(compiler_globals.active_op_array)->run_time_cache,
                              (unsigned long )(compiler_globals.active_op_array)->last_cache_slot * sizeof(void *),
                              0);
          (compiler_globals.active_op_array)->run_time_cache = (void **)tmp___1;
          *((compiler_globals.active_op_array)->run_time_cache + ((compiler_globals.active_op_array)->last_cache_slot - 1)) = (void *)0;
        } else {

        }
      } else {

      }
      break;
    }
  } else {
    opline->opcode = (zend_uchar )59;
    opline->op1_type = (zend_uchar )(1 << 3);
    if (function_name->op_type == 1) {
      opline->op2_type = (zend_uchar )1;
      tmp___2 = zend_add_func_name_literal(compiler_globals.active_op_array,
                                           (zval const   *)(& function_name->u.constant));
      opline->op2.constant = (zend_uint )tmp___2;
      while (1) {
        tmp___3 = (compiler_globals.active_op_array)->last_cache_slot;
        ((compiler_globals.active_op_array)->last_cache_slot) ++;
        ((compiler_globals.active_op_array)->literals + opline->op2.constant)->cache_slot = (zend_uint )tmp___3;
        if ((compiler_globals.active_op_array)->fn_flags & 16U) {
          if ((compiler_globals.active_op_array)->run_time_cache) {
            tmp___4 = _erealloc((void *)(compiler_globals.active_op_array)->run_time_cache,
                                (unsigned long )(compiler_globals.active_op_array)->last_cache_slot * sizeof(void *),
                                0);
            (compiler_globals.active_op_array)->run_time_cache = (void **)tmp___4;
            *((compiler_globals.active_op_array)->run_time_cache + ((compiler_globals.active_op_array)->last_cache_slot - 1)) = (void *)0;
          } else {

          }
        } else {

        }
        break;
      }
    } else {
      while (1) {
        opline->op2_type = (zend_uchar )function_name->op_type;
        if (function_name->op_type == 1) {
          tmp___5 = zend_add_literal(compiler_globals.active_op_array,
                                     (zval const   *)(& function_name->u.constant));
          opline->op2.constant = (zend_uint )tmp___5;
        } else {
          opline->op2 = function_name->u.op;
        }
        break;
      }
    }
  }
  zend_stack_push(& compiler_globals.function_call_stack,
                  (void const   *)((void *)(& ptr)),
                  (int )sizeof(zend_function *));
  zend_do_extended_fcall_begin();
  return;
}
}
void zend_resolve_non_class_name(znode *element_name ,
                                 zend_bool check_namespace ) 
{ 
  znode tmp ;
  int len ;
  zval **ns ;
  char *lcname ;
  char *compound ;
  void *tmp___0 ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  int __attribute__((__visibility__("default")))  tmp___2 ;
  void __attribute__((__visibility__("default")))  *tmp___3 ;

  {
  tmp___0 = memchr((void const   *)element_name->u.constant.value.str.val, '\\',
                   (size_t )element_name->u.constant.value.str.len);
  compound = (char *)tmp___0;
  if ((int )*(element_name->u.constant.value.str.val + 0) == 92) {
    memmove((void *)element_name->u.constant.value.str.val,
            (void const   *)(element_name->u.constant.value.str.val + 1),
            (size_t )element_name->u.constant.value.str.len);
    (element_name->u.constant.value.str.len) --;
    return;
  } else {

  }
  if (! check_namespace) {
    return;
  } else {

  }
  if (compound) {
    if (compiler_globals.current_import) {
      len = (int )(compound - element_name->u.constant.value.str.val);
      tmp___1 = zend_str_tolower_dup((char const   *)element_name->u.constant.value.str.val,
                                     (unsigned int )len);
      lcname = (char *)tmp___1;
      tmp___2 = zend_hash_find((HashTable const   *)compiler_globals.current_import,
                               (char const   *)lcname, (uint )(len + 1),
                               (void **)(& ns));
      if (tmp___2 == (int __attribute__((__visibility__("default")))  )0) {
        tmp.op_type = 1;
        tmp.u.constant = *(*ns);
        _zval_copy_ctor(& tmp.u.constant);
        len ++;
        element_name->u.constant.value.str.len -= len;
        memmove((void *)element_name->u.constant.value.str.val,
                (void const   *)(element_name->u.constant.value.str.val + len),
                (size_t )(element_name->u.constant.value.str.len + 1));
        zend_do_build_namespace_name(& tmp, & tmp, element_name);
        *element_name = tmp;
        _efree((void *)lcname);
        return;
      } else {

      }
      _efree((void *)lcname);
    } else {

    }
  } else {

  }
  if (compiler_globals.current_namespace) {
    tmp = *element_name;
    tmp.u.constant.value.str.len = (int )(((sizeof("\\") - 1UL) + (unsigned long )element_name->u.constant.value.str.len) + (unsigned long )(compiler_globals.current_namespace)->value.str.len);
    tmp___3 = _emalloc((size_t )(tmp.u.constant.value.str.len + 1));
    tmp.u.constant.value.str.val = (char *)tmp___3;
    memcpy((void */* __restrict  */)tmp.u.constant.value.str.val,
           (void const   */* __restrict  */)(compiler_globals.current_namespace)->value.str.val,
           (size_t )(compiler_globals.current_namespace)->value.str.len);
    memcpy((void */* __restrict  */)(tmp.u.constant.value.str.val + (compiler_globals.current_namespace)->value.str.len),
           (void const   */* __restrict  */)"\\", sizeof("\\") - 1UL);
    memcpy((void */* __restrict  */)(tmp.u.constant.value.str.val + (((unsigned long )(compiler_globals.current_namespace)->value.str.len + sizeof("\\")) - 1UL)),
           (void const   */* __restrict  */)element_name->u.constant.value.str.val,
           (size_t )(element_name->u.constant.value.str.len + 1));
    if (element_name->u.constant.value.str.val) {
      if ((unsigned long )element_name->u.constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
        if (! ((unsigned long )element_name->u.constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end)) {
          _efree((void *)element_name->u.constant.value.str.val);
        } else {

        }
      } else {
        _efree((void *)element_name->u.constant.value.str.val);
      }
    } else {

    }
    *element_name = tmp;
  } else {

  }
  return;
}
}
void zend_resolve_class_name(znode *class_name , ulong fetch_type ,
                             int check_ns_name ) 
{ 
  char *compound ;
  char *lcname ;
  zval **ns ;
  znode tmp ;
  int len ;
  void *tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  int tmp___2 ;
  char __attribute__((__visibility__("default")))  *tmp___3 ;
  int __attribute__((__visibility__("default")))  tmp___4 ;
  char __attribute__((__visibility__("default")))  *tmp___5 ;
  int __attribute__((__visibility__("default")))  tmp___6 ;

  {
  tmp___0 = memchr((void const   *)class_name->u.constant.value.str.val, '\\',
                   (size_t )class_name->u.constant.value.str.len);
  compound = (char *)tmp___0;
  if (compound) {
    if ((int )*(class_name->u.constant.value.str.val + 0) == 92) {
      (class_name->u.constant.value.str.len) --;
      memmove((void *)class_name->u.constant.value.str.val,
              (void const   *)(class_name->u.constant.value.str.val + 1),
              (size_t )(class_name->u.constant.value.str.len + 1));
      tmp___1 = _erealloc((void *)class_name->u.constant.value.str.val,
                          (size_t )(class_name->u.constant.value.str.len + 1), 0);
      class_name->u.constant.value.str.val = (char *)tmp___1;
      tmp___2 = zend_get_class_fetch_type((char const   *)class_name->u.constant.value.str.val,
                                          (uint )class_name->u.constant.value.str.len);
      if (0 != tmp___2) {
        zend_error(1 << 6L, "\'\\%s\' is an invalid class name",
                   class_name->u.constant.value.str.val);
      } else {

      }
    } else {
      if (compiler_globals.current_import) {
        len = (int )(compound - class_name->u.constant.value.str.val);
        tmp___3 = zend_str_tolower_dup((char const   *)class_name->u.constant.value.str.val,
                                       (unsigned int )len);
        lcname = (char *)tmp___3;
        tmp___4 = zend_hash_find((HashTable const   *)compiler_globals.current_import,
                                 (char const   *)lcname, (uint )(len + 1),
                                 (void **)(& ns));
        if (tmp___4 == (int __attribute__((__visibility__("default")))  )0) {
          tmp.op_type = 1;
          tmp.u.constant = *(*ns);
          _zval_copy_ctor(& tmp.u.constant);
          len ++;
          class_name->u.constant.value.str.len -= len;
          memmove((void *)class_name->u.constant.value.str.val,
                  (void const   *)(class_name->u.constant.value.str.val + len),
                  (size_t )(class_name->u.constant.value.str.len + 1));
          zend_do_build_namespace_name(& tmp, & tmp, class_name);
          *class_name = tmp;
          _efree((void *)lcname);
          return;
        } else {

        }
        _efree((void *)lcname);
      } else {

      }
      if (compiler_globals.current_namespace) {
        tmp.op_type = 1;
        tmp.u.constant = *(compiler_globals.current_namespace);
        _zval_copy_ctor(& tmp.u.constant);
        zend_do_build_namespace_name(& tmp, & tmp, class_name);
        *class_name = tmp;
      } else {

      }
    }
  } else
  if (compiler_globals.current_import) {
    goto _L___0;
  } else
  if (compiler_globals.current_namespace) {
    _L___0: 
    tmp___5 = zend_str_tolower_dup((char const   *)class_name->u.constant.value.str.val,
                                   (unsigned int )class_name->u.constant.value.str.len);
    lcname = (char *)tmp___5;
    if (compiler_globals.current_import) {
      tmp___6 = zend_hash_find((HashTable const   *)compiler_globals.current_import,
                               (char const   *)lcname,
                               (uint )(class_name->u.constant.value.str.len + 1),
                               (void **)(& ns));
      if (tmp___6 == (int __attribute__((__visibility__("default")))  )0) {
        _zval_dtor(& class_name->u.constant);
        class_name->u.constant = *(*ns);
        _zval_copy_ctor(& class_name->u.constant);
      } else {
        goto _L;
      }
    } else
    _L: 
    if (compiler_globals.current_namespace) {
      tmp.op_type = 1;
      tmp.u.constant = *(compiler_globals.current_namespace);
      _zval_copy_ctor(& tmp.u.constant);
      zend_do_build_namespace_name(& tmp, & tmp, class_name);
      *class_name = tmp;
    } else {

    }
    _efree((void *)lcname);
  } else {

  }
  return;
}
}
void zend_do_fetch_class(znode *result , znode *class_name ) 
{ 
  long fetch_class_op_number ;
  zend_op *opline ;
  int tmp ;
  int fetch_type ;
  int tmp___0 ;
  int tmp___1 ;

  {
  if (class_name->op_type == 1) {
    if ((int )class_name->u.constant.type == 6) {
      if (class_name->u.constant.value.str.len == 0) {
        _zval_dtor(& class_name->u.constant);
        zend_error(1 << 6L, "Cannot use \'namespace\' as a class name");
        return;
      } else {

      }
    } else {

    }
  } else {

  }
  tmp = get_next_op_number(compiler_globals.active_op_array);
  fetch_class_op_number = (long )tmp;
  opline = get_next_op(compiler_globals.active_op_array);
  opline->opcode = (zend_uchar )109;
  opline->op1_type = (zend_uchar )(1 << 3);
  opline->extended_value = (ulong )4;
  compiler_globals.catch_begin = fetch_class_op_number;
  if (class_name->op_type == 1) {
    fetch_type = zend_get_class_fetch_type((char const   *)class_name->u.constant.value.str.val,
                                           (uint )class_name->u.constant.value.str.len);
    switch (fetch_type) {
    case 1: 
    case 2: 
    case 7: 
    opline->op2_type = (zend_uchar )(1 << 3);
    opline->extended_value = (ulong )fetch_type;
    _zval_dtor(& class_name->u.constant);
    break;
    default: 
    zend_resolve_class_name(class_name, opline->extended_value, 0);
    opline->op2_type = (zend_uchar )1;
    tmp___0 = zend_add_class_name_literal(compiler_globals.active_op_array,
                                          (zval const   *)(& class_name->u.constant));
    opline->op2.constant = (zend_uint )tmp___0;
    break;
    }
  } else {
    while (1) {
      opline->op2_type = (zend_uchar )class_name->op_type;
      if (class_name->op_type == 1) {
        tmp___1 = zend_add_literal(compiler_globals.active_op_array,
                                   (zval const   *)(& class_name->u.constant));
        opline->op2.constant = (zend_uint )tmp___1;
      } else {
        opline->op2 = class_name->u.op;
      }
      break;
    }
  }
  opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  opline->result_type = (zend_uchar )(1 << 2);
  while (1) {
    result->op_type = (int )opline->result_type;
    if (result->op_type == 1) {
      result->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      result->u.op = opline->result;
      result->EA = (zend_uint )0;
    }
    break;
  }
  result->EA = (zend_uint )opline->extended_value;
  return;
}
}
void zend_do_label(znode *label ) 
{ 
  zend_label dest ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;

  {
  if (! compiler_globals.context.labels) {
    tmp = _emalloc(sizeof(HashTable ));
    compiler_globals.context.labels = (HashTable *)tmp;
    _zend_hash_init(compiler_globals.context.labels, (uint )4,
                    (ulong (*)(char const   *arKey , uint nKeyLength ))((void *)0),
                    (void (*)(void *pDest ))((void *)0), (zend_bool )0);
  } else {

  }
  dest.brk_cont = compiler_globals.context.current_brk_cont;
  tmp___0 = get_next_op_number(compiler_globals.active_op_array);
  dest.opline_num = (zend_uint )tmp___0;
  tmp___1 = _zend_hash_add_or_update(compiler_globals.context.labels,
                                     (char const   *)label->u.constant.value.str.val,
                                     (uint )(label->u.constant.value.str.len + 1),
                                     (void *)((void **)(& dest)),
                                     (uint )sizeof(zend_label ),
                                     (void **)((void *)0), 1 << 1);
  if (tmp___1 == (int __attribute__((__visibility__("default")))  )-1) {
    zend_error(1 << 6L, "Label \'%s\' already defined",
               label->u.constant.value.str.val);
  } else {

  }
  _zval_dtor(& label->u.constant);
  return;
}
}
void zend_resolve_goto_label(zend_op_array *op_array , zend_op *opline ,
                             int pass2 ) 
{ 
  zend_label *dest ;
  long current ;
  long distance ;
  zval *label ;
  int __attribute__((__visibility__("default")))  tmp ;
  zval *__z ;

  {
  if (pass2) {
    label = opline->op2.zv;
  } else {
    label = & (op_array->literals + opline->op2.constant)->constant;
  }
  if ((unsigned long )compiler_globals.context.labels == (unsigned long )((void *)0)) {
    goto _L;
  } else {
    tmp = zend_hash_find((HashTable const   *)compiler_globals.context.labels,
                         (char const   *)label->value.str.val,
                         (uint )(label->value.str.len + 1), (void **)(& dest));
    if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
      _L: 
      if (pass2) {
        compiler_globals.in_compilation = (zend_bool )1;
        compiler_globals.active_op_array = op_array;
        compiler_globals.zend_lineno = (int )opline->lineno;
        zend_error(1 << 6L, "\'goto\' to undefined label \'%s\'",
                   label->value.str.val);
      } else {
        if (op_array->fn_flags & 16U) {
          (compiler_globals.context.backpatch_count) ++;
        } else {

        }
        return;
      }
    } else {

    }
  }
  opline->op1.opline_num = dest->opline_num;
  _zval_dtor(label);
  label->type = (zend_uchar )0;
  current = (long )opline->extended_value;
  distance = 0L;
  while (current != (long )dest->brk_cont) {
    if (current == -1L) {
      if (pass2) {
        compiler_globals.in_compilation = (zend_bool )1;
        compiler_globals.active_op_array = op_array;
        compiler_globals.zend_lineno = (int )opline->lineno;
      } else {

      }
      zend_error(1 << 6L, "\'goto\' into loop or switch statement is disallowed");
    } else {

    }
    current = (long )(op_array->brk_cont_array + current)->parent;
    distance ++;
  }
  if (distance == 0L) {
    opline->opcode = (zend_uchar )42;
    opline->extended_value = (ulong )0;
    opline->op2_type = (zend_uchar )(1 << 3);
  } else {
    __z = label;
    __z->value.lval = distance;
    __z->type = (zend_uchar )1;
  }
  if (pass2) {
    if (op_array->fn_flags & 16U) {
      (compiler_globals.context.backpatch_count) --;
    } else {

    }
  } else {

  }
  return;
}
}
void zend_do_goto(znode const   *label ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;
  znode_op __constr_expr_26 ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  opline->opcode = (zend_uchar )100;
  opline->extended_value = (ulong )compiler_globals.context.current_brk_cont;
  opline->op1_type = (zend_uchar )(1 << 3);
  while (1) {
    opline->op2_type = (zend_uchar )label->op_type;
    if (label->op_type == 1) {
      tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                 & label->u.constant);
      opline->op2.constant = (zend_uint )tmp___0;
    } else {
      __constr_expr_26 = label->u.op;
      opline->op2 = __constr_expr_26;
    }
    break;
  }
  zend_resolve_goto_label(compiler_globals.active_op_array, opline, 0);
  return;
}
}
void zend_release_labels(void) 
{ 
  zend_compiler_context *ctx ;
  int __attribute__((__visibility__("default")))  tmp ;

  {
  if (compiler_globals.context.labels) {
    zend_hash_destroy(compiler_globals.context.labels);
    _efree((void *)compiler_globals.context.labels);
  } else {

  }
  tmp = zend_stack_is_empty((zend_stack const   *)(& compiler_globals.context_stack));
  if (! tmp) {
    zend_stack_top((zend_stack const   *)(& compiler_globals.context_stack),
                   (void **)(& ctx));
    compiler_globals.context = *ctx;
    zend_stack_del_top(& compiler_globals.context_stack);
  } else {

  }
  return;
}
}
void zend_do_build_full_name(znode *result , znode *prefix , znode *name ,
                             int is_class_member ) 
{ 
  zend_uint length ;
  void __attribute__((__visibility__("default")))  *tmp ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;

  {
  if (! result) {
    result = prefix;
  } else {
    *result = *prefix;
  }
  if (is_class_member) {
    length = (zend_uint )(((sizeof("::") - 1UL) + (unsigned long )result->u.constant.value.str.len) + (unsigned long )name->u.constant.value.str.len);
    tmp = _erealloc((void *)result->u.constant.value.str.val,
                    (size_t )(length + 1U), 0);
    result->u.constant.value.str.val = (char *)tmp;
    memcpy((void */* __restrict  */)(result->u.constant.value.str.val + result->u.constant.value.str.len),
           (void const   */* __restrict  */)"::", sizeof("::") - 1UL);
    memcpy((void */* __restrict  */)(result->u.constant.value.str.val + (((unsigned long )result->u.constant.value.str.len + sizeof("::")) - 1UL)),
           (void const   */* __restrict  */)name->u.constant.value.str.val,
           (size_t )(name->u.constant.value.str.len + 1));
    if (name->u.constant.value.str.val) {
      if ((unsigned long )name->u.constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
        if (! ((unsigned long )name->u.constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end)) {
          _efree((void *)name->u.constant.value.str.val);
        } else {

        }
      } else {
        _efree((void *)name->u.constant.value.str.val);
      }
    } else {

    }
    result->u.constant.value.str.len = (int )length;
  } else {
    length = (zend_uint )(((sizeof("\\") - 1UL) + (unsigned long )result->u.constant.value.str.len) + (unsigned long )name->u.constant.value.str.len);
    tmp___0 = _erealloc((void *)result->u.constant.value.str.val,
                        (size_t )(length + 1U), 0);
    result->u.constant.value.str.val = (char *)tmp___0;
    memcpy((void */* __restrict  */)(result->u.constant.value.str.val + result->u.constant.value.str.len),
           (void const   */* __restrict  */)"\\", sizeof("\\") - 1UL);
    memcpy((void */* __restrict  */)(result->u.constant.value.str.val + (((unsigned long )result->u.constant.value.str.len + sizeof("\\")) - 1UL)),
           (void const   */* __restrict  */)name->u.constant.value.str.val,
           (size_t )(name->u.constant.value.str.len + 1));
    if (name->u.constant.value.str.val) {
      if ((unsigned long )name->u.constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
        if (! ((unsigned long )name->u.constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end)) {
          _efree((void *)name->u.constant.value.str.val);
        } else {

        }
      } else {
        _efree((void *)name->u.constant.value.str.val);
      }
    } else {

    }
    result->u.constant.value.str.len = (int )length;
  }
  return;
}
}
int zend_do_begin_class_member_function_call(znode *class_name ,
                                             znode *method_name ) 
{ 
  znode class_node ;
  unsigned char *ptr ;
  zend_op *opline ;
  char *lcname ;
  char __attribute__((__visibility__("default")))  *tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  void __attribute__((__visibility__("default")))  *tmp___6 ;
  void __attribute__((__visibility__("default")))  *tmp___7 ;
  int tmp___8 ;

  {
  ptr = (unsigned char *)((void *)0);
  if (method_name->op_type == 1) {
    tmp = zend_str_tolower_dup((char const   *)method_name->u.constant.value.str.val,
                               (unsigned int )method_name->u.constant.value.str.len);
    lcname = (char *)tmp;
    if (sizeof("__construct") - 1UL == (unsigned long )method_name->u.constant.value.str.len) {
      tmp___0 = memcmp((void const   *)lcname, (void const   *)"__construct",
                       sizeof("__construct") - 1UL);
      if (tmp___0 == 0) {
        _zval_dtor(& method_name->u.constant);
        method_name->op_type = 1 << 3;
      } else {

      }
    } else {

    }
    _efree((void *)lcname);
  } else {

  }
  if (class_name->op_type == 1) {
    tmp___1 = zend_get_class_fetch_type((char const   *)class_name->u.constant.value.str.val,
                                        (uint )class_name->u.constant.value.str.len);
    if (0 == tmp___1) {
      zend_resolve_class_name(class_name, (ulong )4, 1);
      class_node = *class_name;
      opline = get_next_op(compiler_globals.active_op_array);
    } else {
      zend_do_fetch_class(& class_node, class_name);
      opline = get_next_op(compiler_globals.active_op_array);
      opline->extended_value = (ulong )class_node.EA;
    }
  } else {
    zend_do_fetch_class(& class_node, class_name);
    opline = get_next_op(compiler_globals.active_op_array);
    opline->extended_value = (ulong )class_node.EA;
  }
  opline->opcode = (zend_uchar )113;
  if (class_node.op_type == 1) {
    opline->op1_type = (zend_uchar )1;
    tmp___2 = zend_add_class_name_literal(compiler_globals.active_op_array,
                                          (zval const   *)(& class_node.u.constant));
    opline->op1.constant = (zend_uint )tmp___2;
  } else {
    while (1) {
      opline->op1_type = (zend_uchar )class_node.op_type;
      if (class_node.op_type == 1) {
        tmp___3 = zend_add_literal(compiler_globals.active_op_array,
                                   (zval const   *)(& class_node.u.constant));
        opline->op1.constant = (zend_uint )tmp___3;
      } else {
        opline->op1 = class_node.u.op;
      }
      break;
    }
  }
  if (method_name->op_type == 1) {
    opline->op2_type = (zend_uchar )1;
    tmp___4 = zend_add_func_name_literal(compiler_globals.active_op_array,
                                         (zval const   *)(& method_name->u.constant));
    opline->op2.constant = (zend_uint )tmp___4;
    if ((int )opline->op1_type == 1) {
      while (1) {
        tmp___5 = (compiler_globals.active_op_array)->last_cache_slot;
        ((compiler_globals.active_op_array)->last_cache_slot) ++;
        ((compiler_globals.active_op_array)->literals + opline->op2.constant)->cache_slot = (zend_uint )tmp___5;
        if ((compiler_globals.active_op_array)->fn_flags & 16U) {
          if ((compiler_globals.active_op_array)->run_time_cache) {
            tmp___6 = _erealloc((void *)(compiler_globals.active_op_array)->run_time_cache,
                                (unsigned long )(compiler_globals.active_op_array)->last_cache_slot * sizeof(void *),
                                0);
            (compiler_globals.active_op_array)->run_time_cache = (void **)tmp___6;
            *((compiler_globals.active_op_array)->run_time_cache + ((compiler_globals.active_op_array)->last_cache_slot - 1)) = (void *)0;
          } else {

          }
        } else {

        }
        break;
      }
    } else {
      while (1) {
        ((compiler_globals.active_op_array)->literals + opline->op2.constant)->cache_slot = (zend_uint )(compiler_globals.active_op_array)->last_cache_slot;
        (compiler_globals.active_op_array)->last_cache_slot += 2;
        if ((compiler_globals.active_op_array)->fn_flags & 16U) {
          if ((compiler_globals.active_op_array)->run_time_cache) {
            tmp___7 = _erealloc((void *)(compiler_globals.active_op_array)->run_time_cache,
                                (unsigned long )(compiler_globals.active_op_array)->last_cache_slot * sizeof(void *),
                                0);
            (compiler_globals.active_op_array)->run_time_cache = (void **)tmp___7;
            *((compiler_globals.active_op_array)->run_time_cache + ((compiler_globals.active_op_array)->last_cache_slot - 1)) = (void *)0;
            *((compiler_globals.active_op_array)->run_time_cache + ((compiler_globals.active_op_array)->last_cache_slot - 2)) = (void *)0;
          } else {

          }
        } else {

        }
        break;
      }
    }
  } else {
    while (1) {
      opline->op2_type = (zend_uchar )method_name->op_type;
      if (method_name->op_type == 1) {
        tmp___8 = zend_add_literal(compiler_globals.active_op_array,
                                   (zval const   *)(& method_name->u.constant));
        opline->op2.constant = (zend_uint )tmp___8;
      } else {
        opline->op2 = method_name->u.op;
      }
      break;
    }
  }
  zend_stack_push(& compiler_globals.function_call_stack,
                  (void const   *)((void *)(& ptr)),
                  (int )sizeof(zend_function *));
  zend_do_extended_fcall_begin();
  return (1);
}
}
void zend_do_end_function_call(znode *function_name , znode *result ,
                               znode const   *argument_list , int is_method ,
                               int is_dynamic_fcall ) 
{ 
  zend_op *opline ;
  int tmp ;
  ulong __attribute__((__visibility__("default")))  tmp___0 ;
  int tmp___1 ;
  void __attribute__((__visibility__("default")))  *tmp___2 ;

  {
  if (is_method) {
    if (function_name) {
      if (function_name->op_type == 1 << 3) {
        if (argument_list->u.constant.value.lval != 0L) {
          zend_error(1 << 1L, "Clone method does not require arguments");
        } else {

        }
        opline = (compiler_globals.active_op_array)->opcodes + function_name->u.constant.value.lval;
      } else {
        goto _L___0;
      }
    } else {
      goto _L___0;
    }
  } else {
    _L___0: 
    opline = get_next_op(compiler_globals.active_op_array);
    if (! is_method) {
      if (! is_dynamic_fcall) {
        if (function_name->op_type == 1) {
          opline->opcode = (zend_uchar )60;
          while (1) {
            opline->op1_type = (zend_uchar )function_name->op_type;
            if (function_name->op_type == 1) {
              tmp = zend_add_literal(compiler_globals.active_op_array,
                                     (zval const   *)(& function_name->u.constant));
              opline->op1.constant = (zend_uint )tmp;
            } else {
              opline->op1 = function_name->u.op;
            }
            break;
          }
          while (1) {
            if ((unsigned long )((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
              if ((unsigned long )((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end) {
                ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant))->hash_value = ((Bucket *)(((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val - sizeof(Bucket )))->h;
              } else {
                tmp___0 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val,
                                         (uint )(((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.len + 1));
                ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant))->hash_value = (zend_ulong )tmp___0;
              }
            } else {
              tmp___0 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val,
                                       (uint )(((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.len + 1));
              ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant))->hash_value = (zend_ulong )tmp___0;
            }
            break;
          }
          while (1) {
            tmp___1 = (compiler_globals.active_op_array)->last_cache_slot;
            ((compiler_globals.active_op_array)->last_cache_slot) ++;
            ((compiler_globals.active_op_array)->literals + opline->op1.constant)->cache_slot = (zend_uint )tmp___1;
            if ((compiler_globals.active_op_array)->fn_flags & 16U) {
              if ((compiler_globals.active_op_array)->run_time_cache) {
                tmp___2 = _erealloc((void *)(compiler_globals.active_op_array)->run_time_cache,
                                    (unsigned long )(compiler_globals.active_op_array)->last_cache_slot * sizeof(void *),
                                    0);
                (compiler_globals.active_op_array)->run_time_cache = (void **)tmp___2;
                *((compiler_globals.active_op_array)->run_time_cache + ((compiler_globals.active_op_array)->last_cache_slot - 1)) = (void *)0;
              } else {

              }
            } else {

            }
            break;
          }
        } else {
          opline->opcode = (zend_uchar )61;
          opline->op1_type = (zend_uchar )(1 << 3);
        }
      } else {
        opline->opcode = (zend_uchar )61;
        opline->op1_type = (zend_uchar )(1 << 3);
      }
    } else {
      opline->opcode = (zend_uchar )61;
      opline->op1_type = (zend_uchar )(1 << 3);
    }
  }
  opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  opline->result_type = (zend_uchar )(1 << 2);
  while (1) {
    result->op_type = (int )opline->result_type;
    if (result->op_type == 1) {
      result->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      result->u.op = opline->result;
      result->EA = (zend_uint )0;
    }
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  zend_stack_del_top(& compiler_globals.function_call_stack);
  opline->extended_value = (ulong )argument_list->u.constant.value.lval;
  return;
}
}
void zend_do_pass_param(znode *param , zend_uchar op , int offset ) 
{ 
  zend_op *opline ;
  int original_op ;
  zend_function **function_ptr_ptr ;
  zend_function *function_ptr ;
  int send_by_reference ;
  int send_function ;
  unsigned int tmp ;
  zend_bool tmp___0 ;
  unsigned int tmp___2 ;
  unsigned int tmp___3 ;
  zend_bool tmp___4 ;
  int tmp___5 ;

  {
  original_op = (int )op;
  send_function = 0;
  zend_stack_top((zend_stack const   *)(& compiler_globals.function_call_stack),
                 (void **)(& function_ptr_ptr));
  function_ptr = *function_ptr_ptr;
  if (original_op == 67) {
    if (function_ptr) {
      if (function_ptr->common.function_name) {
        if ((int )function_ptr->common.type == 2) {
          if (function_ptr) {
            if (function_ptr->common.arg_info) {
              if ((zend_uint )offset <= function_ptr->common.num_args) {
                tmp = (unsigned int )((int )(function_ptr->common.arg_info + ((zend_uint )offset - 1U))->pass_by_reference & 3);
              } else {
                tmp = function_ptr->common.fn_flags & 50331648U;
              }
            } else {
              tmp = function_ptr->common.fn_flags & 50331648U;
            }
            if (tmp) {
              zend_error(1 << 6L, "Call-time pass-by-reference has been removed");
            } else {
              zend_error(1 << 6L,
                         "Call-time pass-by-reference has been removed; If you would like to pass argument by reference, modify the declaration of %s().",
                         function_ptr->common.function_name);
            }
          } else {
            zend_error(1 << 6L,
                       "Call-time pass-by-reference has been removed; If you would like to pass argument by reference, modify the declaration of %s().",
                       function_ptr->common.function_name);
          }
        } else {
          zend_error(1 << 6L, "Call-time pass-by-reference has been removed");
        }
      } else {
        zend_error(1 << 6L, "Call-time pass-by-reference has been removed");
      }
    } else {
      zend_error(1 << 6L, "Call-time pass-by-reference has been removed");
    }
    return;
  } else {

  }
  if (function_ptr) {
    if (function_ptr) {
      if (function_ptr->common.arg_info) {
        if ((zend_uint )offset <= function_ptr->common.num_args) {
          tmp___3 = (unsigned int )((int )(function_ptr->common.arg_info + ((zend_uint )offset - 1U))->pass_by_reference & 2);
        } else {
          tmp___3 = function_ptr->common.fn_flags & 33554432U;
        }
      } else {
        tmp___3 = function_ptr->common.fn_flags & 33554432U;
      }
      if (tmp___3) {
        if (param->op_type & ((1 << 2) | (1 << 4))) {
          if (original_op != 65) {
            send_by_reference = 1;
            if ((int )op == 66) {
              tmp___0 = zend_is_function_or_method_call((znode const   *)param);
              if (tmp___0) {
                op = (zend_uchar )106;
                send_function = (1 << 2) | (1 << 3);
              } else {

              }
            } else {

            }
          } else {
            op = (zend_uchar )65;
            send_by_reference = 0;
          }
        } else {
          op = (zend_uchar )65;
          send_by_reference = 0;
        }
      } else {
        goto _L;
      }
    } else
    _L: 
    if (function_ptr) {
      if (function_ptr->common.arg_info) {
        if ((zend_uint )offset <= function_ptr->common.num_args) {
          tmp___2 = (unsigned int )((int )(function_ptr->common.arg_info + ((zend_uint )offset - 1U))->pass_by_reference & 3);
        } else {
          tmp___2 = function_ptr->common.fn_flags & 50331648U;
        }
      } else {
        tmp___2 = function_ptr->common.fn_flags & 50331648U;
      }
      if (tmp___2) {
        send_by_reference = 1;
      } else {
        send_by_reference = 0;
      }
    } else {
      send_by_reference = 0;
    }
  } else {
    send_by_reference = 0;
  }
  if ((int )op == 66) {
    tmp___4 = zend_is_function_or_method_call((znode const   *)param);
    if (tmp___4) {
      op = (zend_uchar )106;
      send_function = 1 << 2;
    } else {
      goto _L___0;
    }
  } else
  _L___0: 
  if ((int )op == 65) {
    if (param->op_type & ((1 << 2) | (1 << 4))) {
      op = (zend_uchar )106;
    } else {

    }
  } else {

  }
  if ((int )op != 106) {
    if (send_by_reference == 1) {
      switch (param->op_type) {
      case 1 << 2: 
      case 1 << 4: 
      op = (zend_uchar )67;
      break;
      default: 
      zend_error(1 << 6L, "Only variables can be passed by reference");
      break;
      }
    } else {

    }
  } else {

  }
  if (original_op == 66) {
    switch ((int )op) {
    case 106: 
    zend_do_end_variable_parse(param, 0, 0);
    break;
    case 66: 
    if (function_ptr) {
      zend_do_end_variable_parse(param, 0, 0);
    } else {
      zend_do_end_variable_parse(param, 5, offset);
    }
    break;
    case 67: 
    zend_do_end_variable_parse(param, 1, 0);
    break;
    }
  } else {

  }
  opline = get_next_op(compiler_globals.active_op_array);
  if ((int )op == 106) {
    if (function_ptr) {
      opline->extended_value = (ulong )(((1 << 1) | send_by_reference) | send_function);
    } else {
      opline->extended_value = (ulong )send_function;
    }
  } else
  if (function_ptr) {
    opline->extended_value = (ulong )60;
  } else {
    opline->extended_value = (ulong )61;
  }
  opline->opcode = op;
  while (1) {
    opline->op1_type = (zend_uchar )param->op_type;
    if (param->op_type == 1) {
      tmp___5 = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& param->u.constant));
      opline->op1.constant = (zend_uint )tmp___5;
    } else {
      opline->op1 = param->u.op;
    }
    break;
  }
  opline->op2.opline_num = (zend_uint )offset;
  opline->op2_type = (zend_uchar )(1 << 3);
  return;
}
}
static int generate_free_switch_expr(zend_switch_entry const   *switch_entry ) 
{ 
  zend_op *opline ;
  int tmp ;
  znode_op __constr_expr_27 ;

  {
  if (switch_entry->cond.op_type != (int const   )(1 << 2)) {
    if (switch_entry->cond.op_type != (int const   )(1 << 1)) {
      return (switch_entry->cond.op_type == (int const   )(1 << 3));
    } else {

    }
  } else {

  }
  opline = get_next_op(compiler_globals.active_op_array);
  if (switch_entry->cond.op_type == (int const   )(1 << 1)) {
    opline->opcode = (zend_uchar )70;
  } else {
    opline->opcode = (zend_uchar )49;
  }
  while (1) {
    opline->op1_type = (zend_uchar )switch_entry->cond.op_type;
    if (switch_entry->cond.op_type == 1) {
      tmp = zend_add_literal(compiler_globals.active_op_array,
                             & switch_entry->cond.u.constant);
      opline->op1.constant = (zend_uint )tmp;
    } else {
      __constr_expr_27 = switch_entry->cond.u.op;
      opline->op1 = __constr_expr_27;
    }
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  opline->extended_value = (ulong )0;
  return (0);
}
}
static int generate_free_foreach_copy(zend_op const   *foreach_copy ) 
{ 
  zend_op *opline ;
  znode_op __constr_expr_28 ;
  znode_op __constr_expr_29 ;

  {
  if ((int const   )foreach_copy->result_type == (int const   )(1 << 3)) {
    if ((int const   )foreach_copy->op1_type == (int const   )(1 << 3)) {
      return (1);
    } else {

    }
  } else {

  }
  opline = get_next_op(compiler_globals.active_op_array);
  if ((int const   )foreach_copy->result_type == (int const   )(1 << 1)) {
    opline->opcode = (zend_uchar )70;
  } else {
    opline->opcode = (zend_uchar )49;
  }
  while (1) {
    opline->op1_type = (zend_uchar )foreach_copy->result_type;
    __constr_expr_28 = foreach_copy->result;
    opline->op1 = __constr_expr_28;
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  opline->extended_value = (ulong )1;
  if ((int const   )foreach_copy->op1_type != (int const   )(1 << 3)) {
    opline = get_next_op(compiler_globals.active_op_array);
    if ((int const   )foreach_copy->op1_type == (int const   )(1 << 1)) {
      opline->opcode = (zend_uchar )70;
    } else {
      opline->opcode = (zend_uchar )49;
    }
    while (1) {
      opline->op1_type = (zend_uchar )foreach_copy->op1_type;
      __constr_expr_29 = foreach_copy->op1;
      opline->op1 = __constr_expr_29;
      break;
    }
    opline->op2_type = (zend_uchar )(1 << 3);
    opline->extended_value = (ulong )0;
  } else {

  }
  return (0);
}
}
void zend_do_return(znode *expr , int do_end_vparse ) 
{ 
  zend_op *opline ;
  int start_op_number ;
  int end_op_number ;
  zend_bool tmp ;
  int tmp___0 ;
  zend_bool tmp___1 ;
  zval _c ;
  int tmp___2 ;

  {
  if (do_end_vparse) {
    if ((compiler_globals.active_op_array)->fn_flags & 67108864U) {
      tmp = zend_is_function_or_method_call((znode const   *)expr);
      if (tmp) {
        zend_do_end_variable_parse(expr, 0, 0);
      } else {
        zend_do_end_variable_parse(expr, 1, 0);
      }
    } else {
      zend_do_end_variable_parse(expr, 0, 0);
    }
  } else {

  }
  start_op_number = get_next_op_number(compiler_globals.active_op_array);
  zend_stack_apply(& compiler_globals.switch_cond_stack, 1,
                   (int (*)(void *element ))(& generate_free_switch_expr));
  zend_stack_apply(& compiler_globals.foreach_copy_stack, 1,
                   (int (*)(void *element ))(& generate_free_foreach_copy));
  end_op_number = get_next_op_number(compiler_globals.active_op_array);
  while (start_op_number < end_op_number) {
    ((compiler_globals.active_op_array)->opcodes + start_op_number)->extended_value |= (unsigned long )(1 << 2);
    start_op_number ++;
  }
  opline = get_next_op(compiler_globals.active_op_array);
  if ((compiler_globals.active_op_array)->fn_flags & 67108864U) {
    opline->opcode = (zend_uchar )111;
  } else {
    opline->opcode = (zend_uchar )62;
  }
  if (expr) {
    while (1) {
      opline->op1_type = (zend_uchar )expr->op_type;
      if (expr->op_type == 1) {
        tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                   (zval const   *)(& expr->u.constant));
        opline->op1.constant = (zend_uint )tmp___0;
      } else {
        opline->op1 = expr->u.op;
      }
      break;
    }
    if (do_end_vparse) {
      tmp___1 = zend_is_function_or_method_call((znode const   *)expr);
      if (tmp___1) {
        opline->extended_value = (ulong )1;
      } else {

      }
    } else {

    }
  } else {
    opline->op1_type = (zend_uchar )1;
    while (1) {
      _c = (zval )zval_used_for_init;
      tmp___2 = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& _c));
      opline->op1.constant = (zend_uint )tmp___2;
      break;
    }
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  return;
}
}
static int zend_add_try_element(zend_uint try_op ) 
{ 
  int try_catch_offset ;
  int tmp ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;

  {
  tmp = (compiler_globals.active_op_array)->last_try_catch;
  ((compiler_globals.active_op_array)->last_try_catch) ++;
  try_catch_offset = tmp;
  tmp___0 = _erealloc((void *)(compiler_globals.active_op_array)->try_catch_array,
                      sizeof(zend_try_catch_element ) * (unsigned long )(compiler_globals.active_op_array)->last_try_catch,
                      0);
  (compiler_globals.active_op_array)->try_catch_array = (zend_try_catch_element *)tmp___0;
  ((compiler_globals.active_op_array)->try_catch_array + try_catch_offset)->try_op = try_op;
  return (try_catch_offset);
}
}
static void zend_add_catch_element(int offset , zend_uint catch_op ) 
{ 


  {
  ((compiler_globals.active_op_array)->try_catch_array + offset)->catch_op = catch_op;
  return;
}
}
void zend_do_first_catch(znode *open_parentheses ) 
{ 
  int tmp ;

  {
  tmp = get_next_op_number(compiler_globals.active_op_array);
  open_parentheses->u.op.opline_num = (zend_uint )tmp;
  return;
}
}
void zend_initialize_try_catch_element(znode const   *try_token ) 
{ 
  int jmp_op_number ;
  int tmp ;
  zend_op *opline ;
  zend_op *tmp___0 ;
  zend_llist jmp_list ;
  zend_llist *jmp_list_ptr ;
  int tmp___1 ;

  {
  tmp = get_next_op_number(compiler_globals.active_op_array);
  jmp_op_number = tmp;
  tmp___0 = get_next_op(compiler_globals.active_op_array);
  opline = tmp___0;
  opline->opcode = (zend_uchar )42;
  opline->op1_type = (zend_uchar )(1 << 3);
  opline->op2_type = (zend_uchar )(1 << 3);
  zend_llist_init(& jmp_list, sizeof(int ), (void (*)(void * ))((void *)0),
                  (unsigned char)0);
  zend_stack_push(& compiler_globals.bp_stack,
                  (void const   *)((void *)(& jmp_list)),
                  (int )sizeof(zend_llist ));
  zend_stack_top((zend_stack const   *)(& compiler_globals.bp_stack),
                 (void **)(& jmp_list_ptr));
  zend_llist_add_element(jmp_list_ptr, (void *)(& jmp_op_number));
  tmp___1 = get_next_op_number(compiler_globals.active_op_array);
  zend_add_catch_element((int )try_token->u.op.opline_num, (zend_uint )tmp___1);
  return;
}
}
void zend_do_mark_last_catch(znode const   *first_catch ,
                             znode const   *last_additional_catch ) 
{ 
  int tmp ;
  int tmp___0 ;

  {
  ((compiler_globals.active_op_array)->last) --;
  zend_do_if_end();
  if (last_additional_catch->u.op.opline_num == 4294967295U) {
    ((compiler_globals.active_op_array)->opcodes + first_catch->u.op.opline_num)->result.num = (zend_uint )1;
    tmp = get_next_op_number(compiler_globals.active_op_array);
    ((compiler_globals.active_op_array)->opcodes + first_catch->u.op.opline_num)->extended_value = (ulong )tmp;
  } else {
    ((compiler_globals.active_op_array)->opcodes + last_additional_catch->u.op.opline_num)->result.num = (zend_uint )1;
    tmp___0 = get_next_op_number(compiler_globals.active_op_array);
    ((compiler_globals.active_op_array)->opcodes + last_additional_catch->u.op.opline_num)->extended_value = (ulong )tmp___0;
  }
  if ((compiler_globals.active_op_array)->fn_flags & 16U) {
    (compiler_globals.context.backpatch_count) --;
  } else {

  }
  return;
}
}
void zend_do_try(znode *try_token ) 
{ 
  int tmp ;
  int tmp___0 ;

  {
  tmp = get_next_op_number(compiler_globals.active_op_array);
  tmp___0 = zend_add_try_element((zend_uint )tmp);
  try_token->u.op.opline_num = (zend_uint )tmp___0;
  if ((compiler_globals.active_op_array)->fn_flags & 16U) {
    (compiler_globals.context.backpatch_count) ++;
  } else {

  }
  return;
}
}
void zend_do_begin_catch(znode *try_token , znode *class_name ,
                         znode *catch_var , znode *first_catch ) 
{ 
  long catch_op_number ;
  zend_op *opline ;
  znode catch_class ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;

  {
  if (class_name->op_type == 1) {
    tmp = zend_get_class_fetch_type((char const   *)class_name->u.constant.value.str.val,
                                    (uint )class_name->u.constant.value.str.len);
    if (0 == tmp) {
      zend_resolve_class_name(class_name, (ulong )4, 1);
      catch_class = *class_name;
    } else {
      zend_error(1 << 6L, "Bad class name in the catch statement");
    }
  } else {
    zend_error(1 << 6L, "Bad class name in the catch statement");
  }
  tmp___0 = get_next_op_number(compiler_globals.active_op_array);
  catch_op_number = (long )tmp___0;
  if (first_catch) {
    first_catch->u.op.opline_num = (zend_uint )catch_op_number;
  } else {

  }
  opline = get_next_op(compiler_globals.active_op_array);
  opline->opcode = (zend_uchar )107;
  opline->op1_type = (zend_uchar )1;
  tmp___1 = zend_add_class_name_literal(compiler_globals.active_op_array,
                                        (zval const   *)(& catch_class.u.constant));
  opline->op1.constant = (zend_uint )tmp___1;
  opline->op2_type = (zend_uchar )(1 << 4);
  tmp___2 = lookup_cv(compiler_globals.active_op_array,
                      catch_var->u.constant.value.str.val,
                      catch_var->u.constant.value.str.len, (ulong )0);
  opline->op2.var = (zend_uint )tmp___2;
  catch_var->u.constant.value.str.val = (char *)((compiler_globals.active_op_array)->vars + opline->op2.var)->name;
  opline->result.num = (zend_uint )0;
  try_token->u.op.opline_num = (zend_uint )catch_op_number;
  return;
}
}
void zend_do_end_catch(znode const   *try_token ) 
{ 
  int jmp_op_number ;
  int tmp ;
  zend_op *opline ;
  zend_op *tmp___0 ;
  zend_llist *jmp_list_ptr ;
  int tmp___1 ;

  {
  tmp = get_next_op_number(compiler_globals.active_op_array);
  jmp_op_number = tmp;
  tmp___0 = get_next_op(compiler_globals.active_op_array);
  opline = tmp___0;
  opline->opcode = (zend_uchar )42;
  opline->op1_type = (zend_uchar )(1 << 3);
  opline->op2_type = (zend_uchar )(1 << 3);
  zend_stack_top((zend_stack const   *)(& compiler_globals.bp_stack),
                 (void **)(& jmp_list_ptr));
  zend_llist_add_element(jmp_list_ptr, (void *)(& jmp_op_number));
  tmp___1 = get_next_op_number(compiler_globals.active_op_array);
  ((compiler_globals.active_op_array)->opcodes + try_token->u.op.opline_num)->extended_value = (ulong )tmp___1;
  return;
}
}
void zend_do_throw(znode const   *expr ) 
{ 
  zend_op *opline ;
  int tmp ;
  znode_op __constr_expr_30 ;

  {
  opline = get_next_op(compiler_globals.active_op_array);
  opline->opcode = (zend_uchar )108;
  while (1) {
    opline->op1_type = (zend_uchar )expr->op_type;
    if (expr->op_type == 1) {
      tmp = zend_add_literal(compiler_globals.active_op_array,
                             & expr->u.constant);
      opline->op1.constant = (zend_uint )tmp;
    } else {
      __constr_expr_30 = expr->u.op;
      opline->op1 = __constr_expr_30;
    }
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  return;
}
}
void __attribute__((__visibility__("default")))  function_add_ref(zend_function *function ) 
{ 
  zend_op_array *op_array ;
  HashTable *static_variables ;
  zval *tmp_zval ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  if ((int )function->type == 2) {
    op_array = & function->op_array;
    (*(op_array->refcount)) ++;
    if (op_array->static_variables) {
      static_variables = op_array->static_variables;
      tmp = _emalloc(sizeof(HashTable ));
      op_array->static_variables = (HashTable *)tmp;
      tmp___0 = zend_hash_num_elements((HashTable const   *)static_variables);
      _zend_hash_init(op_array->static_variables, (uint )tmp___0,
                      (ulong (*)(char const   *arKey , uint nKeyLength ))((void *)0),
                      (void (*)(void * ))(& _zval_ptr_dtor), (zend_bool )0);
      zend_hash_copy(op_array->static_variables, static_variables,
                     (void (*)(void *pElement ))(& zval_add_ref),
                     (void *)(& tmp_zval), (uint )sizeof(zval *));
    } else {

    }
    op_array->run_time_cache = (void **)((void *)0);
  } else {

  }
  return;
}
}
static void do_inherit_parent_constructor(zend_class_entry *ce ) 
{ 
  zend_function *function ;
  char *lc_class_name ;
  char *lc_parent_class_name ;
  char __attribute__((__visibility__("default")))  *tmp ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;
  int __attribute__((__visibility__("default")))  tmp___2 ;
  int __attribute__((__visibility__("default")))  tmp___3 ;
  int __attribute__((__visibility__("default")))  tmp___4 ;

  {
  if (! ce->parent) {
    return;
  } else {

  }
  ce->create_object = (ce->parent)->create_object;
  if (! ce->get_iterator) {
    ce->get_iterator = (ce->parent)->get_iterator;
  } else {

  }
  if (! ce->iterator_funcs.funcs) {
    ce->iterator_funcs.funcs = (ce->parent)->iterator_funcs.funcs;
  } else {

  }
  if (! ce->__get) {
    ce->__get = (ce->parent)->__get;
  } else {

  }
  if (! ce->__set) {
    ce->__set = (ce->parent)->__set;
  } else {

  }
  if (! ce->__unset) {
    ce->__unset = (ce->parent)->__unset;
  } else {

  }
  if (! ce->__isset) {
    ce->__isset = (ce->parent)->__isset;
  } else {

  }
  if (! ce->__call) {
    ce->__call = (ce->parent)->__call;
  } else {

  }
  if (! ce->__callstatic) {
    ce->__callstatic = (ce->parent)->__callstatic;
  } else {

  }
  if (! ce->__tostring) {
    ce->__tostring = (ce->parent)->__tostring;
  } else {

  }
  if (! ce->clone) {
    ce->clone = (ce->parent)->clone;
  } else {

  }
  if (! ce->serialize) {
    ce->serialize = (ce->parent)->serialize;
  } else {

  }
  if (! ce->unserialize) {
    ce->unserialize = (ce->parent)->unserialize;
  } else {

  }
  if (! ce->destructor) {
    ce->destructor = (ce->parent)->destructor;
  } else {

  }
  if (ce->constructor) {
    if ((ce->parent)->constructor) {
      if (((ce->parent)->constructor)->common.fn_flags & 4U) {
        zend_error(1, "Cannot override final %s::%s() with %s::%s()",
                   (ce->parent)->name,
                   ((ce->parent)->constructor)->common.function_name, ce->name,
                   (ce->constructor)->common.function_name);
      } else {

      }
    } else {

    }
    return;
  } else {

  }
  tmp___4 = zend_hash_find((HashTable const   *)(& (ce->parent)->function_table),
                           "__construct", (uint )sizeof("__construct"),
                           (void **)(& function));
  if (tmp___4 == (int __attribute__((__visibility__("default")))  )0) {
    _zend_hash_add_or_update(& ce->function_table, "__construct",
                             (uint )sizeof("__construct"), (void *)function,
                             (uint )sizeof(zend_function ),
                             (void **)((void *)0), 1);
    function_add_ref(function);
  } else {
    tmp = zend_str_tolower_dup(ce->name, ce->name_length);
    lc_class_name = (char *)tmp;
    tmp___3 = zend_hash_exists((HashTable const   *)(& ce->function_table),
                               (char const   *)lc_class_name,
                               ce->name_length + 1U);
    if (! tmp___3) {
      tmp___0 = zend_str_tolower_dup((ce->parent)->name,
                                     (ce->parent)->name_length);
      lc_parent_class_name = (char *)tmp___0;
      tmp___1 = zend_hash_exists((HashTable const   *)(& ce->function_table),
                                 (char const   *)lc_parent_class_name,
                                 (ce->parent)->name_length + 1U);
      if (! tmp___1) {
        tmp___2 = zend_hash_find((HashTable const   *)(& (ce->parent)->function_table),
                                 (char const   *)lc_parent_class_name,
                                 (ce->parent)->name_length + 1U,
                                 (void **)(& function));
        if (tmp___2 == (int __attribute__((__visibility__("default")))  )0) {
          if (function->common.fn_flags & 8192U) {
            _zend_hash_add_or_update(& ce->function_table,
                                     (char const   *)lc_parent_class_name,
                                     (ce->parent)->name_length + 1U,
                                     (void *)function,
                                     (uint )sizeof(zend_function ),
                                     (void **)((void *)0), 1);
            function_add_ref(function);
          } else {

          }
        } else {

        }
      } else {

      }
      _efree((void *)lc_parent_class_name);
    } else {

    }
    _efree((void *)lc_class_name);
  }
  ce->constructor = (ce->parent)->constructor;
  return;
}
}
char *zend_visibility_string(zend_uint fn_flags ) 
{ 


  {
  if (fn_flags & 1024U) {
    return ((char *)"private");
  } else {

  }
  if (fn_flags & 512U) {
    return ((char *)"protected");
  } else {

  }
  if (fn_flags & 256U) {
    return ((char *)"public");
  } else {

  }
  return ((char *)"");
}
}
static void do_inherit_method(zend_function *function ) 
{ 


  {
  function_add_ref(function);
  return;
}
}
static zend_bool zend_do_perform_implementation_check(zend_function const   *fe ,
                                                      zend_function const   *proto ) 
{ 
  zend_uint i ;
  int tmp ;
  int tmp___0 ;
  char const   *colon ;
  zend_class_entry **fe_ce ;
  zend_class_entry **proto_ce ;
  int found ;
  int found2 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;
  int __attribute__((__visibility__("default")))  tmp___2 ;
  char *tmp___4 ;
  void const   *tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;

  {
  if (! proto) {
    return ((zend_bool )1);
  } else
  if (! proto->common.arg_info) {
    if ((int const   )proto->common.type != 2) {
      return ((zend_bool )1);
    } else {

    }
  } else {

  }
  if (fe->common.fn_flags & 8192U) {
    if (((proto->common.scope)->ce_flags & 128U) == 0U) {
      if ((proto->common.fn_flags & 2U) == 0U) {
        return ((zend_bool )1);
      } else {

      }
    } else {

    }
  } else {

  }
  if (proto->common.required_num_args < fe->common.required_num_args) {
    return ((zend_bool )0);
  } else
  if (proto->common.num_args > fe->common.num_args) {
    return ((zend_bool )0);
  } else {

  }
  if ((int const   )fe->common.type != 2) {
    if ((proto->common.fn_flags & 16777216U) != 0U) {
      if ((fe->common.fn_flags & 16777216U) == 0U) {
        return ((zend_bool )0);
      } else {

      }
    } else {

    }
  } else {

  }
  if (proto->common.fn_flags & 67108864U) {
    if (! (fe->common.fn_flags & 67108864U)) {
      return ((zend_bool )0);
    } else {

    }
  } else {

  }
  i = (zend_uint )0;
  while (i < (zend_uint )proto->common.num_args) {
    if ((fe->common.arg_info + i)->class_name) {
      tmp = 1;
    } else {
      tmp = 0;
    }
    if ((proto->common.arg_info + i)->class_name) {
      tmp___0 = 1;
    } else {
      tmp___0 = 0;
    }
    if (tmp ^ tmp___0) {
      return ((zend_bool )0);
    } else {

    }
    if ((fe->common.arg_info + i)->class_name) {
      tmp___7 = strcasecmp((fe->common.arg_info + i)->class_name,
                           (proto->common.arg_info + i)->class_name);
      if (tmp___7 != 0) {
        if ((int const   )fe->common.type != 2) {
          return ((zend_bool )0);
        } else {
          tmp___4 = __builtin_strchr((char *)(proto->common.arg_info + i)->class_name,
                                     '\\');
          if ((unsigned long )tmp___4 != (unsigned long )((void *)0)) {
            goto _L;
          } else {
            tmp___5 = zend_memrchr((void const   *)(fe->common.arg_info + i)->class_name,
                                   '\\',
                                   (size_t )(fe->common.arg_info + i)->class_name_len);
            colon = (char const   *)tmp___5;
            if ((unsigned long )colon == (unsigned long )((void *)0)) {
              goto _L;
            } else {
              tmp___6 = strcasecmp(colon + 1,
                                   (proto->common.arg_info + i)->class_name);
              if (tmp___6 != 0) {
                _L: 
                tmp___1 = zend_lookup_class((fe->common.arg_info + i)->class_name,
                                            (int )(fe->common.arg_info + i)->class_name_len,
                                            & fe_ce);
                found = (int )tmp___1;
                tmp___2 = zend_lookup_class((proto->common.arg_info + i)->class_name,
                                            (int )(proto->common.arg_info + i)->class_name_len,
                                            & proto_ce);
                found2 = (int )tmp___2;
                if (found != 0) {
                  return ((zend_bool )0);
                } else
                if (found2 != 0) {
                  return ((zend_bool )0);
                } else
                if ((int )(*fe_ce)->type == 1) {
                  return ((zend_bool )0);
                } else
                if ((int )(*proto_ce)->type == 1) {
                  return ((zend_bool )0);
                } else
                if ((unsigned long )*fe_ce != (unsigned long )*proto_ce) {
                  return ((zend_bool )0);
                } else {

                }
              } else {

              }
            }
          }
        }
      } else {

      }
    } else {

    }
    if ((int )(fe->common.arg_info + i)->type_hint != (int )(proto->common.arg_info + i)->type_hint) {
      return ((zend_bool )0);
    } else {

    }
    if ((int )(fe->common.arg_info + i)->pass_by_reference != (int )(proto->common.arg_info + i)->pass_by_reference) {
      return ((zend_bool )0);
    } else {

    }
    i ++;
  }
  if (proto->common.fn_flags & 16777216U) {
    i = (zend_uint )proto->common.num_args;
    while (i < (zend_uint )fe->common.num_args) {
      if (! (fe->common.arg_info + i)->pass_by_reference) {
        return ((zend_bool )0);
      } else {

      }
      i ++;
    }
  } else {

  }
  return ((zend_bool )1);
}
}
static char *zend_get_function_declaration(zend_function *fptr ) 
{ 
  char *offset ;
  char *buf ;
  zend_uint length ;
  void __attribute__((__visibility__("default")))  *tmp ;
  char *tmp___0 ;
  char *tmp___1 ;
  char *tmp___2 ;
  char *tmp___3 ;
  size_t name_len ;
  size_t tmp___4 ;
  void __attribute__((__visibility__("default")))  *tmp___5 ;
  long tmp___6 ;
  char *tmp___7 ;
  zend_uint i ;
  zend_uint required ;
  zend_arg_info *arg_info ;
  void __attribute__((__visibility__("default")))  *tmp___8 ;
  long tmp___9 ;
  char *tmp___10 ;
  zend_uint type_name_len ;
  char *type_name ;
  char __attribute__((__visibility__("default")))  *tmp___11 ;
  size_t tmp___12 ;
  void __attribute__((__visibility__("default")))  *tmp___13 ;
  long tmp___14 ;
  char *tmp___15 ;
  char *tmp___16 ;
  char *tmp___17 ;
  void __attribute__((__visibility__("default")))  *tmp___18 ;
  long tmp___19 ;
  zend_uint idx ;
  char *tmp___20 ;
  char *tmp___21 ;
  char *tmp___22 ;
  char *tmp___23 ;
  zend_op *precv ;
  zend_uint idx___0 ;
  zend_op *op ;
  zend_op *end ;
  zval *zv ;
  zval zv_copy ;
  int use_copy ;
  void __attribute__((__visibility__("default")))  *tmp___24 ;
  char *tmp___25 ;
  int tmp___26 ;
  void __attribute__((__visibility__("default")))  *tmp___27 ;
  int tmp___28 ;
  long tmp___29 ;
  int tmp___30 ;
  int tmp___31 ;
  char *tmp___32 ;
  char *tmp___33 ;
  char *tmp___34 ;
  char *tmp___35 ;
  void __attribute__((__visibility__("default")))  *tmp___36 ;
  long tmp___37 ;
  char *tmp___38 ;
  char *tmp___39 ;
  void __attribute__((__visibility__("default")))  *tmp___40 ;
  long tmp___41 ;
  char *tmp___42 ;

  {
  length = (zend_uint )1024;
  tmp = _emalloc((unsigned long )length * sizeof(char ));
  buf = (char *)tmp;
  offset = buf;
  if (fptr->op_array.fn_flags & 67108864U) {
    tmp___0 = offset;
    offset ++;
    *tmp___0 = (char )'&';
    tmp___1 = offset;
    offset ++;
    *tmp___1 = (char )' ';
  } else {

  }
  if (fptr->common.scope) {
    memcpy((void */* __restrict  */)offset,
           (void const   */* __restrict  */)(fptr->common.scope)->name,
           (size_t )(fptr->common.scope)->name_length);
    offset += (fptr->common.scope)->name_length;
    tmp___2 = offset;
    offset ++;
    *tmp___2 = (char )':';
    tmp___3 = offset;
    offset ++;
    *tmp___3 = (char )':';
  } else {

  }
  tmp___4 = strlen(fptr->common.function_name);
  name_len = tmp___4;
  tmp___6 = __builtin_expect((long )((size_t )(offset - buf) + name_len >= (size_t )length),
                             0L);
  if (tmp___6) {
    length = (zend_uint )((size_t )length + (name_len + 1UL));
    tmp___5 = _erealloc((void *)buf, (size_t )length, 0);
    buf = (char *)tmp___5;
  } else {

  }
  memcpy((void */* __restrict  */)offset,
         (void const   */* __restrict  */)fptr->common.function_name, name_len);
  offset += name_len;
  tmp___7 = offset;
  offset ++;
  *tmp___7 = (char )'(';
  if (fptr->common.arg_info) {
    arg_info = fptr->common.arg_info;
    required = fptr->common.required_num_args;
    i = (zend_uint )0;
    while (i < fptr->common.num_args) {
      if (arg_info->class_name) {
        tmp___9 = __builtin_expect((long )((offset - buf) + (long )arg_info->class_name_len >= (long )length),
                                   0L);
        if (tmp___9) {
          length += arg_info->class_name_len + 1U;
          tmp___8 = _erealloc((void *)buf, (size_t )length, 0);
          buf = (char *)tmp___8;
        } else {

        }
        memcpy((void */* __restrict  */)offset,
               (void const   */* __restrict  */)arg_info->class_name,
               (size_t )arg_info->class_name_len);
        offset += arg_info->class_name_len;
        tmp___10 = offset;
        offset ++;
        *tmp___10 = (char )' ';
      } else
      if (arg_info->type_hint) {
        tmp___11 = zend_get_type_by_const((int )arg_info->type_hint);
        type_name = (char *)tmp___11;
        tmp___12 = strlen((char const   *)type_name);
        type_name_len = (zend_uint )tmp___12;
        tmp___14 = __builtin_expect((long )((offset - buf) + (long )type_name_len >= (long )length),
                                    0L);
        if (tmp___14) {
          length += type_name_len + 1U;
          tmp___13 = _erealloc((void *)buf, (size_t )length, 0);
          buf = (char *)tmp___13;
        } else {

        }
        memcpy((void */* __restrict  */)offset,
               (void const   */* __restrict  */)type_name,
               (size_t )type_name_len);
        offset += type_name_len;
        tmp___15 = offset;
        offset ++;
        *tmp___15 = (char )' ';
      } else {

      }
      if (arg_info->pass_by_reference) {
        tmp___16 = offset;
        offset ++;
        *tmp___16 = (char )'&';
      } else {

      }
      tmp___17 = offset;
      offset ++;
      *tmp___17 = (char )'$';
      if (arg_info->name) {
        tmp___19 = __builtin_expect((long )((offset - buf) + (long )arg_info->name_len >= (long )length),
                                    0L);
        if (tmp___19) {
          length += arg_info->name_len + 1U;
          tmp___18 = _erealloc((void *)buf, (size_t )length, 0);
          buf = (char *)tmp___18;
        } else {

        }
        memcpy((void */* __restrict  */)offset,
               (void const   */* __restrict  */)arg_info->name,
               (size_t )arg_info->name_len);
        offset += arg_info->name_len;
      } else {
        idx = i;
        memcpy((void */* __restrict  */)offset,
               (void const   */* __restrict  */)"param", (size_t )5);
        offset += 5;
        while (1) {
          tmp___20 = offset;
          offset ++;
          *tmp___20 = (char )((int )((char )(idx % 10U)) + 48);
          idx /= 10U;
          if (! (idx > 0U)) {
            break;
          } else {

          }
        }
      }
      if (i >= required) {
        tmp___21 = offset;
        offset ++;
        *tmp___21 = (char )' ';
        tmp___22 = offset;
        offset ++;
        *tmp___22 = (char )'=';
        tmp___23 = offset;
        offset ++;
        *tmp___23 = (char )' ';
        if ((int )fptr->type == 2) {
          precv = (zend_op *)((void *)0);
          idx___0 = i;
          op = ((zend_op_array *)fptr)->opcodes;
          end = op + ((zend_op_array *)fptr)->last;
          idx___0 ++;
          while ((unsigned long )op < (unsigned long )end) {
            if ((int )op->opcode == 63) {
              goto _L;
            } else
            if ((int )op->opcode == 64) {
              _L: 
              if ((long )op->op1.num == (long )idx___0) {
                precv = op;
              } else {

              }
            } else {

            }
            op ++;
          }
          if (precv) {
            if ((int )precv->opcode == 64) {
              if ((int )precv->op2_type != 1 << 3) {
                while (1) {
                  tmp___24 = _emalloc(sizeof(zval_gc_info ));
                  zv = (zval *)tmp___24;
                  ((zval_gc_info *)zv)->u.buffered = (gc_root_buffer *)((void *)0);
                  break;
                }
                *zv = *(precv->op2.zv);
                _zval_copy_ctor(zv);
                zv->refcount__gc = (zend_uint )1;
                zv->is_ref__gc = (zend_uchar )0;
                zval_update_constant_ex(& zv, (void *)1, fptr->common.scope);
                if ((int )zv->type == 3) {
                  if (zv->value.lval) {
                    memcpy((void */* __restrict  */)offset,
                           (void const   */* __restrict  */)"true", (size_t )4);
                    offset += 4;
                  } else {
                    memcpy((void */* __restrict  */)offset,
                           (void const   */* __restrict  */)"false", (size_t )5);
                    offset += 5;
                  }
                } else
                if ((int )zv->type == 0) {
                  memcpy((void */* __restrict  */)offset,
                         (void const   */* __restrict  */)"NULL", (size_t )4);
                  offset += 4;
                } else
                if ((int )zv->type == 6) {
                  tmp___25 = offset;
                  offset ++;
                  *tmp___25 = (char )'\'';
                  if (zv->value.str.len < 10) {
                    tmp___28 = zv->value.str.len;
                  } else {
                    tmp___28 = 10;
                  }
                  tmp___29 = __builtin_expect((long )((offset - buf) + (long )tmp___28 >= (long )length),
                                              0L);
                  if (tmp___29) {
                    if (zv->value.str.len < 10) {
                      tmp___26 = zv->value.str.len;
                    } else {
                      tmp___26 = 10;
                    }
                    length += (zend_uint )(tmp___26 + 1);
                    tmp___27 = _erealloc((void *)buf, (size_t )length, 0);
                    buf = (char *)tmp___27;
                  } else {

                  }
                  if (zv->value.str.len < 10) {
                    tmp___30 = zv->value.str.len;
                  } else {
                    tmp___30 = 10;
                  }
                  memcpy((void */* __restrict  */)offset,
                         (void const   */* __restrict  */)zv->value.str.val,
                         (size_t )tmp___30);
                  if (zv->value.str.len < 10) {
                    tmp___31 = zv->value.str.len;
                  } else {
                    tmp___31 = 10;
                  }
                  offset += tmp___31;
                  if (zv->value.str.len > 10) {
                    tmp___32 = offset;
                    offset ++;
                    *tmp___32 = (char )'.';
                    tmp___33 = offset;
                    offset ++;
                    *tmp___33 = (char )'.';
                    tmp___34 = offset;
                    offset ++;
                    *tmp___34 = (char )'.';
                  } else {

                  }
                  tmp___35 = offset;
                  offset ++;
                  *tmp___35 = (char )'\'';
                } else
                if ((int )zv->type == 4) {
                  memcpy((void */* __restrict  */)offset,
                         (void const   */* __restrict  */)"Array", (size_t )5);
                  offset += 5;
                } else {
                  zend_make_printable_zval(zv, & zv_copy, & use_copy);
                  tmp___37 = __builtin_expect((long )((offset - buf) + (long )zv_copy.value.str.len >= (long )length),
                                              0L);
                  if (tmp___37) {
                    length += (zend_uint )(zv_copy.value.str.len + 1);
                    tmp___36 = _erealloc((void *)buf, (size_t )length, 0);
                    buf = (char *)tmp___36;
                  } else {

                  }
                  memcpy((void */* __restrict  */)offset,
                         (void const   */* __restrict  */)zv_copy.value.str.val,
                         (size_t )zv_copy.value.str.len);
                  offset += zv_copy.value.str.len;
                  if (use_copy) {
                    _zval_dtor(& zv_copy);
                  } else {

                  }
                }
                _zval_ptr_dtor(& zv);
              } else {

              }
            } else {

            }
          } else {

          }
        } else {
          memcpy((void */* __restrict  */)offset,
                 (void const   */* __restrict  */)"NULL", (size_t )4);
          offset += 4;
        }
      } else {

      }
      i ++;
      if (i < fptr->common.num_args) {
        tmp___38 = offset;
        offset ++;
        *tmp___38 = (char )',';
        tmp___39 = offset;
        offset ++;
        *tmp___39 = (char )' ';
      } else {

      }
      arg_info ++;
      tmp___41 = __builtin_expect((long )((offset - buf) + 32L >= (long )length),
                                  0L);
      if (tmp___41) {
        length += 33U;
        tmp___40 = _erealloc((void *)buf, (size_t )length, 0);
        buf = (char *)tmp___40;
      } else {

      }
    }
  } else {

  }
  tmp___42 = offset;
  offset ++;
  *tmp___42 = (char )')';
  *offset = (char )'\000';
  return (buf);
}
}
static void do_inheritance_check_on_method(zend_function *child ,
                                           zend_function *parent ) 
{ 
  zend_uint child_flags ;
  zend_uint parent_flags ;
  char const   *tmp ;
  zend_class_entry *tmp___0 ;
  char const   *tmp___1 ;
  char const   *tmp___2 ;
  char const   *tmp___3 ;
  char const   *tmp___4 ;
  char const   *tmp___5 ;
  char const   *tmp___6 ;
  char const   *tmp___7 ;
  char const   *tmp___8 ;
  char const   *tmp___9 ;
  char *tmp___10 ;
  char const   *tmp___11 ;
  char *tmp___12 ;
  char const   *tmp___13 ;
  zend_bool tmp___14 ;
  char *method_prototype ;
  char *tmp___15 ;
  char const   *tmp___16 ;
  zend_bool tmp___17 ;

  {
  parent_flags = parent->common.fn_flags;
  __repair_del_4335__0: /* CIL Label */ ;
  if (parent_flags & 4U) {
    if (parent) {
      if (parent->common.scope) {
        tmp___1 = (parent->common.scope)->name;
      } else {
        tmp___1 = "";
      }
    } else {
      tmp___1 = "";
    }
    zend_error(1 << 6L, "Cannot override final method %s::%s()", tmp___1,
               child->common.function_name);
  } else {

  }
  child_flags = child->common.fn_flags;
  if ((child_flags & 1U) != (parent_flags & 1U)) {
    if (child->common.fn_flags & 1U) {
      if (child) {
        if (child->common.scope) {
          tmp___2 = (child->common.scope)->name;
        } else {
          tmp___2 = "";
        }
      } else {
        tmp___2 = "";
      }
      if (parent) {
        if (parent->common.scope) {
          tmp___3 = (parent->common.scope)->name;
        } else {
          tmp___3 = "";
        }
      } else {
        tmp___3 = "";
      }
      zend_error(1 << 6L,
                 "Cannot make non static method %s::%s() static in class %s",
                 tmp___3, child->common.function_name, tmp___2);
    } else {
      if (child) {
        if (child->common.scope) {
          tmp___4 = (child->common.scope)->name;
        } else {
          tmp___4 = "";
        }
      } else {
        tmp___4 = "";
      }
      if (parent) {
        if (parent->common.scope) {
          tmp___5 = (parent->common.scope)->name;
        } else {
          tmp___5 = "";
        }
      } else {
        tmp___5 = "";
      }
      zend_error(1 << 6L,
                 "Cannot make static method %s::%s() non static in class %s",
                 tmp___5, child->common.function_name, tmp___4);
    }
  } else {

  }
  if (child_flags & 2U) {
    if (! (parent_flags & 2U)) {
      if (child) {
        if (child->common.scope) {
          tmp___6 = (child->common.scope)->name;
        } else {
          tmp___6 = "";
        }
      } else {
        tmp___6 = "";
      }
      if (parent) {
        if (parent->common.scope) {
          tmp___7 = (parent->common.scope)->name;
        } else {
          tmp___7 = "";
        }
      } else {
        tmp___7 = "";
      }
      zend_error(1 << 6L,
                 "Cannot make non abstract method %s::%s() abstract in class %s",
                 tmp___7, child->common.function_name, tmp___6);
    } else {

    }
  } else {

  }
  if (parent_flags & 2048U) {
    child->common.fn_flags |= 2048U;
  } else
  if ((child_flags & 1792U) > (parent_flags & 1792U)) {
    if (parent_flags & 256U) {
      tmp___8 = "";
    } else {
      tmp___8 = " or weaker";
    }
    if (parent) {
      if (parent->common.scope) {
        tmp___9 = (parent->common.scope)->name;
      } else {
        tmp___9 = "";
      }
    } else {
      tmp___9 = "";
    }
    tmp___10 = zend_visibility_string(parent_flags);
    if (child) {
      if (child->common.scope) {
        tmp___11 = (child->common.scope)->name;
      } else {
        tmp___11 = "";
      }
    } else {
      tmp___11 = "";
    }
    zend_error(1 << 6L,
               "Access level to %s::%s() must be %s (as in class %s)%s",
               tmp___11, child->common.function_name, tmp___10, tmp___9, tmp___8);
  } else
  if ((child_flags & 1792U) < (parent_flags & 1792U)) {
    if ((parent_flags & 1792U) & 1024U) {
      child->common.fn_flags |= 2048U;
    } else {

    }
  } else {

  }
  if (parent_flags & 1024U) {
    child->common.prototype = (union _zend_function *)((void *)0);
  } else
  if (parent_flags & 2U) {
    child->common.fn_flags |= 8U;
    child->common.prototype = parent;
  } else
  if (! (parent->common.fn_flags & 8192U)) {
    goto _L;
  } else
  if (parent->common.prototype) {
    if (((parent->common.prototype)->common.scope)->ce_flags & 128U) {
      _L: 
      if (parent->common.prototype) {
        child->common.prototype = parent->common.prototype;
      } else {
        child->common.prototype = parent;
      }
    } else {

    }
  } else {

  }
  if (child->common.prototype) {
    if ((child->common.prototype)->common.fn_flags & 2U) {
      tmp___14 = zend_do_perform_implementation_check((zend_function const   *)child,
                                                      (zend_function const   *)child->common.prototype);
      if (! tmp___14) {
        tmp___12 = zend_get_function_declaration(child->common.prototype);
        if (child) {
          if (child->common.scope) {
            tmp___13 = (child->common.scope)->name;
          } else {
            tmp___13 = "";
          }
        } else {
          tmp___13 = "";
        }
        zend_error(1 << 6L,
                   "Declaration of %s::%s() must be compatible with %s",
                   tmp___13, child->common.function_name, tmp___12);
      } else {

      }
    } else {
      goto _L___1;
    }
  } else
  _L___1: 
  if (executor_globals.error_reporting & (1 << 11L)) {
    goto _L___0;
  } else
  if (executor_globals.user_error_handler) {
    _L___0: 
    tmp___17 = zend_do_perform_implementation_check((zend_function const   *)child,
                                                    (zend_function const   *)parent);
    if (! tmp___17) {
      tmp___15 = zend_get_function_declaration(child->common.prototype);
      method_prototype = tmp___15;
      if (child) {
        if (child->common.scope) {
          tmp___16 = (child->common.scope)->name;
        } else {
          tmp___16 = "";
        }
      } else {
        tmp___16 = "";
      }
      zend_error(1 << 11L,
                 "Declaration of %s::%s() should be compatible with %s",
                 tmp___16, child->common.function_name, method_prototype);
      _efree((void *)method_prototype);
    } else {

    }
  } else {

  }
  return;
}
}
static zend_bool do_inherit_method_check(HashTable *child_function_table ,
                                         zend_function *parent ,
                                         zend_hash_key const   *hash_key ,
                                         zend_class_entry *child_ce ) 
{ 
  zend_uint parent_flags ;
  zend_function *child ;
  int __attribute__((__visibility__("default")))  tmp ;

  {
  parent_flags = parent->common.fn_flags;
  tmp = zend_hash_quick_find((HashTable const   *)child_function_table,
                             (char const   *)hash_key->arKey,
                             (uint )hash_key->nKeyLength, (ulong )hash_key->h,
                             (void **)(& child));
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    if (parent_flags & 2U) {
      child_ce->ce_flags |= 16U;
    } else {

    }
    return ((zend_bool )1);
  } else {

  }
  do_inheritance_check_on_method(child, parent);
  return ((zend_bool )0);
}
}
static zend_bool do_inherit_property_access_check(HashTable *target_ht ,
                                                  zend_property_info *parent_info ,
                                                  zend_hash_key const   *hash_key ,
                                                  zend_class_entry *ce ) 
{ 
  zend_property_info *child_info ;
  zend_class_entry *parent_ce ;
  int __attribute__((__visibility__("default")))  tmp ;
  char const   *tmp___0 ;
  char const   *tmp___1 ;
  char const   *tmp___2 ;
  char *tmp___3 ;
  int __attribute__((__visibility__("default")))  tmp___4 ;

  {
  parent_ce = ce->parent;
  if (parent_info->flags & 132096U) {
    tmp = zend_hash_quick_find((HashTable const   *)(& ce->properties_info),
                               (char const   *)hash_key->arKey,
                               (uint )hash_key->nKeyLength, (ulong )hash_key->h,
                               (void **)(& child_info));
    if (tmp == (int __attribute__((__visibility__("default")))  )0) {
      child_info->flags |= 2048U;
    } else {
      _zend_hash_quick_add_or_update(& ce->properties_info,
                                     (char const   *)hash_key->arKey,
                                     (uint )hash_key->nKeyLength,
                                     (ulong )hash_key->h, (void *)parent_info,
                                     (uint )sizeof(zend_property_info ),
                                     (void **)(& child_info), 1);
      if ((int )ce->type & 1) {
        zend_duplicate_property_info_internal(child_info);
      } else {
        zend_duplicate_property_info(child_info);
      }
      child_info->flags &= 4294966271U;
      child_info->flags |= 131072U;
    }
    return ((zend_bool )0);
  } else {

  }
  tmp___4 = zend_hash_quick_find((HashTable const   *)(& ce->properties_info),
                                 (char const   *)hash_key->arKey,
                                 (uint )hash_key->nKeyLength,
                                 (ulong )hash_key->h, (void **)(& child_info));
  if (tmp___4 == (int __attribute__((__visibility__("default")))  )0) {
    if ((parent_info->flags & 1U) != (child_info->flags & 1U)) {
      if (child_info->flags & 1U) {
        tmp___0 = "static ";
      } else {
        tmp___0 = "non static ";
      }
      if (parent_info->flags & 1U) {
        tmp___1 = "static ";
      } else {
        tmp___1 = "non static ";
      }
      zend_error(1 << 6L, "Cannot redeclare %s%s::$%s as %s%s::$%s", tmp___1,
                 parent_ce->name, hash_key->arKey, tmp___0, ce->name,
                 hash_key->arKey);
    } else {

    }
    if (parent_info->flags & 2048U) {
      child_info->flags |= 2048U;
    } else {

    }
    if ((child_info->flags & 1792U) > (parent_info->flags & 1792U)) {
      if (parent_info->flags & 256U) {
        tmp___2 = "";
      } else {
        tmp___2 = " or weaker";
      }
      tmp___3 = zend_visibility_string(parent_info->flags);
      zend_error(1 << 6L,
                 "Access level to %s::$%s must be %s (as in class %s)%s",
                 ce->name, hash_key->arKey, tmp___3, parent_ce->name, tmp___2);
    } else
    if ((child_info->flags & 1U) == 0U) {
      zval_delref_p(*(ce->default_properties_table + parent_info->offset));
      *(ce->default_properties_table + parent_info->offset) = *(ce->default_properties_table + child_info->offset);
      *(ce->default_properties_table + child_info->offset) = (zval *)((void *)0);
      child_info->offset = parent_info->offset;
    } else {

    }
    return ((zend_bool )0);
  } else {
    return ((zend_bool )1);
  }
}
}
__inline static void do_implement_interface(zend_class_entry *ce ,
                                            zend_class_entry *iface ) 
{ 
  int tmp ;

  {
  if (! (ce->ce_flags & 128U)) {
    if (iface->interface_gets_implemented) {
      tmp = (*(iface->interface_gets_implemented))(iface, ce);
      if (tmp == -1) {
        zend_error(1 << 4L, "Class %s could not implement interface %s",
                   ce->name, iface->name);
      } else {

      }
    } else {

    }
  } else {

  }
  if ((unsigned long )ce == (unsigned long )iface) {
    zend_error(1, "Interface %s cannot implement itself", ce->name);
  } else {

  }
  return;
}
}
void __attribute__((__visibility__("default")))  zend_do_inherit_interfaces(zend_class_entry *ce ,
                                                                            zend_class_entry const   *iface ) 
{ 
  zend_uint i ;
  zend_uint ce_num ;
  zend_uint if_num ;
  zend_class_entry *entry ;
  void *tmp ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  zend_uint tmp___1 ;
  zend_uint tmp___2 ;
  zend_uint tmp___3 ;

  {
  if_num = (zend_uint )iface->num_interfaces;
  if (if_num == 0U) {
    return;
  } else {

  }
  ce_num = ce->num_interfaces;
  if ((int )ce->type == 1) {
    tmp = realloc((void *)ce->interfaces,
                  sizeof(zend_class_entry *) * (unsigned long )(ce_num + if_num));
    ce->interfaces = (zend_class_entry **)tmp;
  } else {
    tmp___0 = _erealloc((void *)ce->interfaces,
                        sizeof(zend_class_entry *) * (unsigned long )(ce_num + if_num),
                        0);
    ce->interfaces = (zend_class_entry **)tmp___0;
  }
  while (1) {
    tmp___2 = if_num;
    if_num --;
    if (! tmp___2) {
      break;
    } else {

    }
    entry = *(iface->interfaces + if_num);
    i = (zend_uint )0;
    while (i < ce_num) {
      if ((unsigned long )*(ce->interfaces + i) == (unsigned long )entry) {
        break;
      } else {

      }
      i ++;
    }
    if (i == ce_num) {
      tmp___1 = ce->num_interfaces;
      (ce->num_interfaces) ++;
      *(ce->interfaces + tmp___1) = entry;
    } else {

    }
  }
  while (ce_num < ce->num_interfaces) {
    tmp___3 = ce_num;
    ce_num ++;
    do_implement_interface(ce, *(ce->interfaces + tmp___3));
  }
  return;
}
}
void __attribute__((__visibility__("default")))  zend_do_inheritance(zend_class_entry *ce ,
                                                                     zend_class_entry *parent_ce ) 
{ 
  zend_property_info *property_info ;
  int i ;
  void *tmp ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  int tmp___1 ;
  int i___0 ;
  void __attribute__((__visibility__("default")))  *tmp___2 ;
  int tmp___3 ;
  zval *new_zv ;
  void __attribute__((__visibility__("default")))  *tmp___4 ;
  zend_uint tmp___5 ;
  zend_bool tmp___6 ;
  int i___1 ;
  void *tmp___7 ;
  void __attribute__((__visibility__("default")))  *tmp___8 ;
  int tmp___9 ;
  zval *new_zv___0 ;
  void __attribute__((__visibility__("default")))  *tmp___10 ;
  zend_uint tmp___11 ;
  zend_bool tmp___12 ;
  int __attribute__((__visibility__("default")))  tmp___13 ;
  void (*tmp___14)(zend_property_info *property_info ) ;

  {
  if (ce->ce_flags & 128U) {
    if (! (parent_ce->ce_flags & 128U)) {
      zend_error(1 << 6L, "Interface %s may not inherit from class (%s)",
                 ce->name, parent_ce->name);
    } else {

    }
  } else {

  }
  if (parent_ce->ce_flags & 64U) {
    zend_error(1 << 6L, "Class %s may not inherit from final class (%s)",
               ce->name, parent_ce->name);
  } else {

  }
  ce->parent = parent_ce;
  if (! ce->serialize) {
    ce->serialize = parent_ce->serialize;
  } else {

  }
  if (! ce->unserialize) {
    ce->unserialize = parent_ce->unserialize;
  } else {

  }
  zend_do_inherit_interfaces(ce, (zend_class_entry const   *)parent_ce);
  if (parent_ce->default_properties_count) {
    i = ce->default_properties_count + parent_ce->default_properties_count;
    if ((int )ce->type == 1) {
      tmp = __zend_realloc((void *)ce->default_properties_table,
                           sizeof(void *) * (unsigned long )i);
      ce->default_properties_table = (zval **)tmp;
    } else {
      tmp___0 = _erealloc((void *)ce->default_properties_table,
                          sizeof(void *) * (unsigned long )i, 0);
      ce->default_properties_table = (zval **)tmp___0;
    }
    if (ce->default_properties_count) {
      while (1) {
        tmp___1 = i;
        i --;
        if (! (tmp___1 > parent_ce->default_properties_count)) {
          break;
        } else {

        }
        *(ce->default_properties_table + i) = *(ce->default_properties_table + (i - parent_ce->default_properties_count));
      }
    } else {

    }
    i = 0;
    while (i < parent_ce->default_properties_count) {
      *(ce->default_properties_table + i) = *(parent_ce->default_properties_table + i);
      if (*(ce->default_properties_table + i)) {
        zval_addref_p(*(ce->default_properties_table + i));
      } else {

      }
      i ++;
    }
    ce->default_properties_count += parent_ce->default_properties_count;
  } else {

  }
  if ((int )parent_ce->type != (int )ce->type) {
    zend_update_class_constants(parent_ce);
    if (parent_ce->default_static_members_count) {
      i___0 = ce->default_static_members_count + parent_ce->default_static_members_count;
      tmp___2 = _erealloc((void *)ce->default_static_members_table,
                          sizeof(void *) * (unsigned long )i___0, 0);
      ce->default_static_members_table = (zval **)tmp___2;
      if (ce->default_static_members_count) {
        while (1) {
          tmp___3 = i___0;
          i___0 --;
          if (! (tmp___3 > parent_ce->default_static_members_count)) {
            break;
          } else {

          }
          *(ce->default_static_members_table + i___0) = *(ce->default_static_members_table + (i___0 - parent_ce->default_static_members_count));
        }
      } else {

      }
      i___0 = 0;
      while (i___0 < parent_ce->default_static_members_count) {
        tmp___6 = zval_isref_p(*(parent_ce->static_members_table + i___0));
        if (! tmp___6) {
          while (1) {
            tmp___5 = zval_refcount_p(*(parent_ce->static_members_table + i___0));
            if (tmp___5 > 1U) {
              zval_delref_p(*(parent_ce->static_members_table + i___0));
              while (1) {
                tmp___4 = _emalloc(sizeof(zval_gc_info ));
                new_zv = (zval *)tmp___4;
                ((zval_gc_info *)new_zv)->u.buffered = (gc_root_buffer *)((void *)0);
                break;
              }
              while (1) {
                while (1) {
                  new_zv->value = (*(parent_ce->static_members_table + i___0))->value;
                  new_zv->type = (*(parent_ce->static_members_table + i___0))->type;
                  break;
                }
                zval_set_refcount_p(new_zv, (zend_uint )1);
                zval_unset_isref_p(new_zv);
                break;
              }
              *(parent_ce->static_members_table + i___0) = new_zv;
              _zval_copy_ctor(new_zv);
            } else {

            }
            break;
          }
          zval_set_isref_p(*(parent_ce->static_members_table + i___0));
        } else {

        }
        *(ce->default_static_members_table + i___0) = *(parent_ce->static_members_table + i___0);
        zval_addref_p(*(ce->default_static_members_table + i___0));
        i___0 ++;
      }
      ce->default_static_members_count += parent_ce->default_static_members_count;
      ce->static_members_table = ce->default_static_members_table;
    } else {

    }
  } else
  if (parent_ce->default_static_members_count) {
    i___1 = ce->default_static_members_count + parent_ce->default_static_members_count;
    if ((int )ce->type == 1) {
      tmp___7 = __zend_realloc((void *)ce->default_static_members_table,
                               sizeof(void *) * (unsigned long )i___1);
      ce->default_static_members_table = (zval **)tmp___7;
    } else {
      tmp___8 = _erealloc((void *)ce->default_static_members_table,
                          sizeof(void *) * (unsigned long )i___1, 0);
      ce->default_static_members_table = (zval **)tmp___8;
    }
    if (ce->default_static_members_count) {
      while (1) {
        tmp___9 = i___1;
        i___1 --;
        if (! (tmp___9 > parent_ce->default_static_members_count)) {
          break;
        } else {

        }
        *(ce->default_static_members_table + i___1) = *(ce->default_static_members_table + (i___1 - parent_ce->default_static_members_count));
      }
    } else {

    }
    i___1 = 0;
    while (i___1 < parent_ce->default_static_members_count) {
      tmp___12 = zval_isref_p(*(parent_ce->default_static_members_table + i___1));
      if (! tmp___12) {
        while (1) {
          tmp___11 = zval_refcount_p(*(parent_ce->default_static_members_table + i___1));
          if (tmp___11 > 1U) {
            zval_delref_p(*(parent_ce->default_static_members_table + i___1));
            while (1) {
              tmp___10 = _emalloc(sizeof(zval_gc_info ));
              new_zv___0 = (zval *)tmp___10;
              ((zval_gc_info *)new_zv___0)->u.buffered = (gc_root_buffer *)((void *)0);
              break;
            }
            while (1) {
              while (1) {
                new_zv___0->value = (*(parent_ce->default_static_members_table + i___1))->value;
                new_zv___0->type = (*(parent_ce->default_static_members_table + i___1))->type;
                break;
              }
              zval_set_refcount_p(new_zv___0, (zend_uint )1);
              zval_unset_isref_p(new_zv___0);
              break;
            }
            *(parent_ce->default_static_members_table + i___1) = new_zv___0;
            _zval_copy_ctor(new_zv___0);
          } else {

          }
          break;
        }
        zval_set_isref_p(*(parent_ce->default_static_members_table + i___1));
      } else {

      }
      *(ce->default_static_members_table + i___1) = *(parent_ce->default_static_members_table + i___1);
      zval_addref_p(*(ce->default_static_members_table + i___1));
      i___1 ++;
    }
    ce->default_static_members_count += parent_ce->default_static_members_count;
    if ((int )ce->type == 2) {
      ce->static_members_table = ce->default_static_members_table;
    } else {

    }
  } else {

  }
  zend_hash_internal_pointer_reset_ex(& ce->properties_info,
                                      (HashPosition *)((void *)0));
  while (1) {
    tmp___13 = zend_hash_get_current_data_ex(& ce->properties_info,
                                             (void **)((void *)(& property_info)),
                                             (HashPosition *)((void *)0));
    if (! (tmp___13 == (int __attribute__((__visibility__("default")))  )0)) {
      break;
    } else {

    }
    if ((unsigned long )property_info->ce == (unsigned long )ce) {
      if (property_info->flags & 1U) {
        property_info->offset += parent_ce->default_static_members_count;
      } else {
        property_info->offset += parent_ce->default_properties_count;
      }
    } else {

    }
    zend_hash_move_forward_ex(& ce->properties_info, (HashPosition *)((void *)0));
  }
  if ((int )ce->type & 1) {
    tmp___14 = & zend_duplicate_property_info_internal;
  } else {
    tmp___14 = & zend_duplicate_property_info;
  }
  zend_hash_merge_ex(& ce->properties_info, & parent_ce->properties_info,
                     (void (*)(void *pElement ))tmp___14,
                     (uint )sizeof(zend_property_info ),
                     (zend_bool (*)(HashTable *target_ht , void *source_data ,
                                    zend_hash_key *hash_key , void *pParam ))(& do_inherit_property_access_check),
                     (void *)ce);
  _zend_hash_merge(& ce->constants_table, & parent_ce->constants_table,
                   (void (*)(void * ))(& zval_add_ref), (void *)0,
                   (uint )sizeof(zval *), 0);
  zend_hash_merge_ex(& ce->function_table, & parent_ce->function_table,
                     (void (*)(void *pElement ))(& do_inherit_method),
                     (uint )sizeof(zend_function ),
                     (zend_bool (*)(HashTable *target_ht , void *source_data ,
                                    zend_hash_key *hash_key , void *pParam ))(& do_inherit_method_check),
                     (void *)ce);
  do_inherit_parent_constructor(ce);
  if (ce->ce_flags & 16U) {
    if ((int )ce->type == 1) {
      ce->ce_flags |= 32U;
    } else {
      goto _L;
    }
  } else
  _L: 
  if (! (ce->ce_flags & 524288U)) {
    if (! (ce->ce_flags & 4194304U)) {
      zend_verify_abstract_class(ce);
    } else {

    }
  } else {

  }
  ce->ce_flags |= parent_ce->ce_flags & 8388608U;
  return;
}
}
static zend_bool do_inherit_constant_check(HashTable *child_constants_table ,
                                           zval const   **parent_constant ,
                                           zend_hash_key const   *hash_key ,
                                           zend_class_entry const   *iface ) 
{ 
  zval **old_constant ;
  int __attribute__((__visibility__("default")))  tmp ;

  {
  tmp = zend_hash_quick_find((HashTable const   *)child_constants_table,
                             (char const   *)hash_key->arKey,
                             (uint )hash_key->nKeyLength, (ulong )hash_key->h,
                             (void **)(& old_constant));
  if (tmp == (int __attribute__((__visibility__("default")))  )0) {
    if ((unsigned long )*old_constant != (unsigned long )*parent_constant) {
      zend_error(1 << 6L,
                 "Cannot inherit previously-inherited or override constant %s from interface %s",
                 hash_key->arKey, iface->name);
    } else {

    }
    return ((zend_bool )0);
  } else {

  }
  return ((zend_bool )1);
}
}
static int do_interface_constant_check(zval **val , int num_args ,
                                       va_list args ,
                                       zend_hash_key const   *key ) 
{ 
  zend_class_entry **iface ;
  zend_class_entry **tmp___0 ;
  zend_class_entry **tmp ;

  {
  tmp = __builtin_va_arg(args, zend_class_entry **);
  tmp___0 = tmp;
  iface = tmp___0;
  do_inherit_constant_check(& (*iface)->constants_table, (zval const   **)val,
                            key, (zend_class_entry const   *)*iface);
  return (0);
}
}
void __attribute__((__visibility__("default")))  zend_do_implement_interface(zend_class_entry *ce ,
                                                                             zend_class_entry *iface ) 
{ 
  zend_uint i ;
  zend_uint ignore ;
  zend_uint current_iface_num ;
  zend_uint parent_iface_num ;
  zend_uint tmp ;
  void *tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  zend_uint tmp___2 ;

  {
  ignore = (zend_uint )0;
  current_iface_num = ce->num_interfaces;
  if (ce->parent) {
    tmp = (ce->parent)->num_interfaces;
  } else {
    tmp = (zend_uint )0;
  }
  parent_iface_num = tmp;
  i = (zend_uint )0;
  while (i < ce->num_interfaces) {
    if ((unsigned long )*(ce->interfaces + i) == (unsigned long )((void *)0)) {
      (ce->num_interfaces) --;
      memmove((void *)(ce->interfaces + i),
              (void const   *)((ce->interfaces + i) + 1),
              sizeof(zend_class_entry *) * (unsigned long )(ce->num_interfaces - i));
      i --;
    } else
    if ((unsigned long )*(ce->interfaces + i) == (unsigned long )iface) {
      if (i < parent_iface_num) {
        ignore = (zend_uint )1;
      } else {
        zend_error(1 << 6L,
                   "Class %s cannot implement previously implemented interface %s",
                   ce->name, iface->name);
      }
    } else {

    }
    i ++;
  }
  if (ignore) {
    zend_hash_apply_with_arguments(& ce->constants_table,
                                   (int (*)(void *pDest , int num_args ,
                                            va_list args ,
                                            zend_hash_key *hash_key ))(& do_interface_constant_check),
                                   1, & iface);
  } else {
    if (ce->num_interfaces >= current_iface_num) {
      if ((int )ce->type == 1) {
        current_iface_num ++;
        tmp___0 = realloc((void *)ce->interfaces,
                          sizeof(zend_class_entry *) * (unsigned long )current_iface_num);
        ce->interfaces = (zend_class_entry **)tmp___0;
      } else {
        current_iface_num ++;
        tmp___1 = _erealloc((void *)ce->interfaces,
                            sizeof(zend_class_entry *) * (unsigned long )current_iface_num,
                            0);
        ce->interfaces = (zend_class_entry **)tmp___1;
      }
    } else {

    }
    tmp___2 = ce->num_interfaces;
    (ce->num_interfaces) ++;
    *(ce->interfaces + tmp___2) = iface;
    zend_hash_merge_ex(& ce->constants_table, & iface->constants_table,
                       (void (*)(void *pElement ))(& zval_add_ref),
                       (uint )sizeof(zval *),
                       (zend_bool (*)(HashTable *target_ht , void *source_data ,
                                      zend_hash_key *hash_key , void *pParam ))(& do_inherit_constant_check),
                       (void *)iface);
    zend_hash_merge_ex(& ce->function_table, & iface->function_table,
                       (void (*)(void *pElement ))(& do_inherit_method),
                       (uint )sizeof(zend_function ),
                       (zend_bool (*)(HashTable *target_ht , void *source_data ,
                                      zend_hash_key *hash_key , void *pParam ))(& do_inherit_method_check),
                       (void *)ce);
    do_implement_interface(ce, iface);
    zend_do_inherit_interfaces(ce, (zend_class_entry const   *)iface);
  }
  return;
}
}
void __attribute__((__visibility__("default")))  zend_do_implement_trait(zend_class_entry *ce ,
                                                                         zend_class_entry *trait ) 
{ 
  zend_uint i ;
  zend_uint ignore ;
  zend_uint current_trait_num ;
  zend_uint parent_trait_num ;
  zend_uint tmp ;
  void *tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  zend_uint tmp___2 ;

  {
  ignore = (zend_uint )0;
  current_trait_num = ce->num_traits;
  if (ce->parent) {
    tmp = (ce->parent)->num_traits;
  } else {
    tmp = (zend_uint )0;
  }
  parent_trait_num = tmp;
  i = (zend_uint )0;
  while (i < ce->num_traits) {
    if ((unsigned long )*(ce->traits + i) == (unsigned long )((void *)0)) {
      (ce->num_traits) --;
      memmove((void *)(ce->traits + i), (void const   *)((ce->traits + i) + 1),
              sizeof(zend_class_entry *) * (unsigned long )(ce->num_traits - i));
      i --;
    } else
    if ((unsigned long )*(ce->traits + i) == (unsigned long )trait) {
      if (i < parent_trait_num) {
        ignore = (zend_uint )1;
      } else {

      }
    } else {

    }
    i ++;
  }
  if (! ignore) {
    if (ce->num_traits >= current_trait_num) {
      if ((int )ce->type == 1) {
        current_trait_num ++;
        tmp___0 = realloc((void *)ce->traits,
                          sizeof(zend_class_entry *) * (unsigned long )current_trait_num);
        ce->traits = (zend_class_entry **)tmp___0;
      } else {
        current_trait_num ++;
        tmp___1 = _erealloc((void *)ce->traits,
                            sizeof(zend_class_entry *) * (unsigned long )current_trait_num,
                            0);
        ce->traits = (zend_class_entry **)tmp___1;
      }
    } else {

    }
    tmp___2 = ce->num_traits;
    (ce->num_traits) ++;
    *(ce->traits + tmp___2) = trait;
  } else {

  }
  return;
}
}
static int zend_traits_merge_functions(zend_function *fn , int num_args ,
                                       va_list args , zend_hash_key *hash_key ) 
{ 
  size_t current ;
  size_t i ;
  size_t count ;
  HashTable *resulting_table ;
  HashTable **function_tables ;
  zend_class_entry *ce ;
  size_t collision ;
  size_t abstract_solved ;
  zend_function *other_trait_fn ;
  size_t tmp ;
  size_t tmp___0 ;
  HashTable *tmp___1 ;
  HashTable **tmp___2 ;
  zend_class_entry *tmp___3 ;
  char *tmp___4 ;
  char *tmp___5 ;
  zend_bool tmp___6 ;
  zend_bool tmp___7 ;
  int __attribute__((__visibility__("default")))  tmp___8 ;
  zend_function *class_fn ;
  int __attribute__((__visibility__("default")))  tmp___9 ;
  int __attribute__((__visibility__("default")))  tmp___10 ;
  size_t tmp___11 ;
  size_t tmp___12 ;
  HashTable *tmp___13 ;
  HashTable **tmp___14 ;
  zend_class_entry *tmp___15 ;

  {
  collision = (size_t )0;
  abstract_solved = (size_t )0;
  tmp___11 = __builtin_va_arg(args, size_t );
  tmp = tmp___11;
  current = tmp;
  tmp___12 = __builtin_va_arg(args, size_t );
  tmp___0 = tmp___12;
  count = tmp___0;
  tmp___13 = __builtin_va_arg(args, HashTable *);
  tmp___1 = tmp___13;
  resulting_table = tmp___1;
  tmp___14 = __builtin_va_arg(args, HashTable **);
  tmp___2 = tmp___14;
  function_tables = tmp___2;
  tmp___15 = __builtin_va_arg(args, zend_class_entry *);
  tmp___3 = tmp___15;
  ce = tmp___3;
  i = (size_t )0;
  while (i < count) {
    if (i == current) {
      goto __Cont;
    } else {

    }
    tmp___8 = zend_hash_quick_find((HashTable const   *)*(function_tables + i),
                                   hash_key->arKey, hash_key->nKeyLength,
                                   hash_key->h, (void **)(& other_trait_fn));
    if (tmp___8 == (int __attribute__((__visibility__("default")))  )0) {
      if (other_trait_fn->common.fn_flags & 2U) {
        if (fn->common.fn_flags & 2U) {
          tmp___6 = zend_do_perform_implementation_check((zend_function const   *)fn,
                                                         (zend_function const   *)other_trait_fn);
          if (tmp___6) {
            tmp___7 = zend_do_perform_implementation_check((zend_function const   *)other_trait_fn,
                                                           (zend_function const   *)fn);
            if (! tmp___7) {
              tmp___4 = zend_get_function_declaration(other_trait_fn);
              tmp___5 = zend_get_function_declaration(fn);
              zend_error(1 << 6L,
                         "Declaration of %s must be compatible with %s",
                         tmp___5, tmp___4);
            } else {

            }
          } else {
            tmp___4 = zend_get_function_declaration(other_trait_fn);
            tmp___5 = zend_get_function_declaration(fn);
            zend_error(1 << 6L, "Declaration of %s must be compatible with %s",
                       tmp___5, tmp___4);
          }
        } else {
          do_inheritance_check_on_method(fn, other_trait_fn);
        }
        zend_function_dtor(other_trait_fn);
        zend_hash_del_key_or_index(*(function_tables + i), hash_key->arKey,
                                   hash_key->nKeyLength, hash_key->h, 2);
      } else
      if (fn->common.fn_flags & 2U) {
        do_inheritance_check_on_method(other_trait_fn, fn);
        abstract_solved = (size_t )1;
      } else {
        collision ++;
        zend_function_dtor(other_trait_fn);
        zend_hash_del_key_or_index(*(function_tables + i), hash_key->arKey,
                                   hash_key->nKeyLength, hash_key->h, 2);
      }
    } else {

    }
    __Cont: 
    i ++;
  }
  if (collision) {
    tmp___9 = zend_hash_quick_find((HashTable const   *)(& ce->function_table),
                                   hash_key->arKey, hash_key->nKeyLength,
                                   hash_key->h, (void **)(& class_fn));
    if (tmp___9 == (int __attribute__((__visibility__("default")))  )-1) {
      zend_error(1 << 6L,
                 "Trait method %s has not been applied, because there are collisions with other trait methods on %s",
                 fn->common.function_name, ce->name);
    } else
    if ((unsigned long )class_fn->common.scope != (unsigned long )ce) {
      zend_error(1 << 6L,
                 "Trait method %s has not been applied, because there are collisions with other trait methods on %s",
                 fn->common.function_name, ce->name);
    } else {

    }
    zend_function_dtor(fn);
  } else
  if (abstract_solved) {
    zend_function_dtor(fn);
  } else {
    tmp___10 = _zend_hash_quick_add_or_update(resulting_table, hash_key->arKey,
                                              hash_key->nKeyLength, hash_key->h,
                                              (void *)fn,
                                              (uint )sizeof(zend_function ),
                                              (void **)((void *)0), 1 << 1);
    if (tmp___10 == (int __attribute__((__visibility__("default")))  )-1) {
      zend_error(1 << 6L,
                 "Trait method %s has not been applied, because failure occured during updating resulting trait method table",
                 fn->common.function_name);
    } else {

    }
  }
  return (1);
}
}
static void zend_traits_duplicate_function(zend_function *fe ,
                                           zend_class_entry *target_ce ,
                                           char *newname ) 
{ 
  zend_literal *literals_copy ;
  zend_compiled_variable *dupvars ;
  zend_op *opcode_copy ;
  zval class_name_zv ;
  int class_name_literal ;
  int i ;
  int number_of_literals ;
  HashTable *tmpHash ;
  void __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  void __attribute__((__visibility__("default")))  *tmp___2 ;
  void __attribute__((__visibility__("default")))  *tmp___3 ;
  char __attribute__((__visibility__("default")))  *tmp___4 ;
  void __attribute__((__visibility__("default")))  *tmp___5 ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  char __attribute__((__visibility__("default")))  *tmp___6 ;
  char const   *__s___0 ;
  int __l___0 ;
  zval *__z___0 ;
  char __attribute__((__visibility__("default")))  *tmp___7 ;
  zend_arg_info *tmpArginfo ;
  void __attribute__((__visibility__("default")))  *tmp___8 ;
  char __attribute__((__visibility__("default")))  *tmp___9 ;
  char __attribute__((__visibility__("default")))  *tmp___10 ;
  char __attribute__((__visibility__("default")))  *tmp___11 ;
  char __attribute__((__visibility__("default")))  *tmp___12 ;
  char __attribute__((__visibility__("default")))  *tmp___13 ;

  {
  if (fe->op_array.static_variables) {
    tmp = _emalloc(sizeof(HashTable ));
    tmpHash = (HashTable *)tmp;
    tmp___0 = zend_hash_num_elements((HashTable const   *)fe->op_array.static_variables);
    _zend_hash_init(tmpHash, (uint )tmp___0,
                    (ulong (*)(char const   *arKey , uint nKeyLength ))((void *)0),
                    (void (*)(void * ))(& _zval_ptr_dtor), (zend_bool )0);
    zend_hash_apply_with_arguments(fe->op_array.static_variables,
                                   (int (*)(void *pDest , int num_args ,
                                            va_list args ,
                                            zend_hash_key *hash_key ))(& zval_copy_static_var),
                                   1, tmpHash);
    fe->op_array.static_variables = tmpHash;
  } else {

  }
  number_of_literals = fe->op_array.last_literal;
  tmp___1 = _emalloc((unsigned long )number_of_literals * sizeof(zend_literal ));
  literals_copy = (zend_literal *)tmp___1;
  i = 0;
  while (i < number_of_literals) {
    *(literals_copy + i) = *(fe->op_array.literals + i);
    _zval_copy_ctor(& (literals_copy + i)->constant);
    i ++;
  }
  fe->op_array.literals = literals_copy;
  tmp___2 = _emalloc(sizeof(zend_uint ));
  fe->op_array.refcount = (zend_uint *)tmp___2;
  *(fe->op_array.refcount) = (zend_uint )1;
  if (fe->op_array.vars) {
    i = fe->op_array.last_var;
    tmp___3 = _safe_emalloc((size_t )fe->op_array.last_var,
                            sizeof(zend_compiled_variable ), (size_t )0);
    dupvars = (zend_compiled_variable *)tmp___3;
    while (i > 0) {
      i --;
      tmp___4 = _estrndup((fe->op_array.vars + i)->name,
                          (unsigned int )(fe->op_array.vars + i)->name_len);
      (dupvars + i)->name = (char const   *)tmp___4;
      (dupvars + i)->name_len = (fe->op_array.vars + i)->name_len;
      (dupvars + i)->hash_value = (fe->op_array.vars + i)->hash_value;
    }
    fe->op_array.vars = dupvars;
  } else {
    fe->op_array.vars = (zend_compiled_variable *)((void *)0);
  }
  tmp___5 = _safe_emalloc(sizeof(zend_op ), (size_t )fe->op_array.last,
                          (size_t )0);
  opcode_copy = (zend_op *)tmp___5;
  i = 0;
  while ((zend_uint )i < fe->op_array.last) {
    *(opcode_copy + i) = *(fe->op_array.opcodes + i);
    if ((int )(opcode_copy + i)->op1_type != 1) {
      switch ((int )(opcode_copy + i)->opcode) {
      case 100: 
      case 42: 
      if ((opcode_copy + i)->op1.jmp_addr) {
        if ((unsigned long )(opcode_copy + i)->op1.jmp_addr >= (unsigned long )fe->op_array.opcodes) {
          if ((unsigned long )(opcode_copy + i)->op1.jmp_addr < (unsigned long )(fe->op_array.opcodes + fe->op_array.last)) {
            (opcode_copy + i)->op1.jmp_addr = opcode_copy + ((fe->op_array.opcodes + i)->op1.jmp_addr - fe->op_array.opcodes);
          } else {

          }
        } else {

        }
      } else {

      }
      break;
      }
    } else
    if (target_ce) {
      if ((int )((opcode_copy + i)->op1.zv)->type == 0) {
        if (((opcode_copy + i)->op1.zv)->value.lval == 288L) {
          if (288U != (target_ce->ce_flags & 288U)) {
            class_name_zv = (zval )zval_used_for_init;
            while (1) {
              __s = target_ce->name;
              __l = (int )target_ce->name_length;
              __z = & class_name_zv;
              __z->value.str.len = __l;
              tmp___6 = _estrndup(__s, (unsigned int )__l);
              __z->value.str.val = (char *)tmp___6;
              __z->type = (zend_uchar )6;
              break;
            }
            class_name_literal = zend_append_individual_literal(& fe->op_array,
                                                                (zval const   *)(& class_name_zv));
            (opcode_copy + i)->op1.zv = & (fe->op_array.literals + class_name_literal)->constant;
          } else {

          }
        } else {

        }
      } else {

      }
    } else {

    }
    if ((int )(opcode_copy + i)->op2_type != 1) {
      switch ((int )(opcode_copy + i)->opcode) {
      case 43: 
      case 44: 
      case 46: 
      case 47: 
      case 152: 
      case 158: 
      if ((opcode_copy + i)->op2.jmp_addr) {
        if ((unsigned long )(opcode_copy + i)->op2.jmp_addr >= (unsigned long )fe->op_array.opcodes) {
          if ((unsigned long )(opcode_copy + i)->op2.jmp_addr < (unsigned long )(fe->op_array.opcodes + fe->op_array.last)) {
            (opcode_copy + i)->op2.jmp_addr = opcode_copy + ((fe->op_array.opcodes + i)->op2.jmp_addr - fe->op_array.opcodes);
          } else {

          }
        } else {

        }
      } else {

      }
      break;
      }
    } else
    if (target_ce) {
      if ((int )((opcode_copy + i)->op2.zv)->type == 0) {
        if (((opcode_copy + i)->op2.zv)->value.lval == 288L) {
          if (288U != (target_ce->ce_flags & 288U)) {
            class_name_zv = (zval )zval_used_for_init;
            while (1) {
              __s___0 = target_ce->name;
              __l___0 = (int )target_ce->name_length;
              __z___0 = & class_name_zv;
              __z___0->value.str.len = __l___0;
              tmp___7 = _estrndup(__s___0, (unsigned int )__l___0);
              __z___0->value.str.val = (char *)tmp___7;
              __z___0->type = (zend_uchar )6;
              break;
            }
            class_name_literal = zend_append_individual_literal(& fe->op_array,
                                                                (zval const   *)(& class_name_zv));
            (opcode_copy + i)->op2.zv = & (fe->op_array.literals + class_name_literal)->constant;
          } else {

          }
        } else {

        }
      } else {

      }
    } else {

    }
    i ++;
  }
  fe->op_array.opcodes = opcode_copy;
  fe->op_array.function_name = (char const   *)newname;
  if (fe->op_array.arg_info) {
    tmp___8 = _safe_emalloc(sizeof(zend_arg_info ),
                            (size_t )fe->op_array.num_args, (size_t )0);
    tmpArginfo = (zend_arg_info *)tmp___8;
    i = 0;
    while ((zend_uint )i < fe->op_array.num_args) {
      *(tmpArginfo + i) = *(fe->op_array.arg_info + i);
      tmp___9 = _estrndup((tmpArginfo + i)->name, (tmpArginfo + i)->name_len);
      (tmpArginfo + i)->name = (char const   *)tmp___9;
      if ((tmpArginfo + i)->class_name) {
        tmp___10 = _estrndup((tmpArginfo + i)->class_name,
                             (tmpArginfo + i)->class_name_len);
        (tmpArginfo + i)->class_name = (char const   *)tmp___10;
      } else {

      }
      i ++;
    }
    fe->op_array.arg_info = tmpArginfo;
  } else {

  }
  tmp___11 = _estrndup(fe->op_array.doc_comment, fe->op_array.doc_comment_len);
  fe->op_array.doc_comment = (char const   *)tmp___11;
  tmp___12 = _estrndup((char const   *)((char *)fe->op_array.try_catch_array),
                       (unsigned int )(sizeof(zend_try_catch_element ) * (unsigned long )fe->op_array.last_try_catch));
  fe->op_array.try_catch_array = (zend_try_catch_element *)tmp___12;
  tmp___13 = _estrndup((char const   *)((char *)fe->op_array.brk_cont_array),
                       (unsigned int )(sizeof(zend_brk_cont_element ) * (unsigned long )fe->op_array.last_brk_cont));
  fe->op_array.brk_cont_array = (zend_brk_cont_element *)tmp___13;
  return;
}
}
static void zend_add_magic_methods(zend_class_entry *ce , char const   *mname ,
                                   uint mname_len , zend_function *fe ) 
{ 
  char *lowercase_name ;
  void __attribute__((__visibility__("default")))  *tmp ;
  char const __attribute__((__visibility__("default")))  *tmp___0 ;
  int tmp___1 ;
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp___5 ;
  int tmp___8 ;
  int tmp___9 ;
  int tmp___10 ;
  int tmp___11 ;
  int tmp___12 ;
  size_t __s1_len___0 ;
  size_t __s2_len___0 ;
  int tmp___18 ;
  int tmp___21 ;
  int tmp___22 ;
  int tmp___23 ;
  int tmp___24 ;
  int tmp___25 ;
  size_t __s1_len___1 ;
  size_t __s2_len___1 ;
  int tmp___31 ;
  int tmp___34 ;
  int tmp___35 ;
  int tmp___36 ;
  int tmp___37 ;
  int tmp___38 ;
  size_t __s1_len___2 ;
  size_t __s2_len___2 ;
  int tmp___44 ;
  int tmp___47 ;
  int tmp___48 ;
  int tmp___49 ;
  int tmp___50 ;
  int tmp___51 ;
  size_t __s1_len___3 ;
  size_t __s2_len___3 ;
  int tmp___57 ;
  int tmp___60 ;
  int tmp___61 ;
  int tmp___62 ;
  int tmp___63 ;
  int tmp___64 ;
  size_t __s1_len___4 ;
  size_t __s2_len___4 ;
  int tmp___70 ;
  int tmp___73 ;
  int tmp___74 ;
  int tmp___75 ;
  int tmp___76 ;
  int tmp___77 ;
  size_t __s1_len___5 ;
  size_t __s2_len___5 ;
  int tmp___83 ;
  int tmp___86 ;
  int tmp___87 ;
  int tmp___88 ;
  int tmp___89 ;
  int tmp___90 ;
  size_t __s1_len___6 ;
  size_t __s2_len___6 ;
  int tmp___96 ;
  int tmp___99 ;
  int tmp___100 ;
  int tmp___101 ;
  int tmp___102 ;
  int tmp___103 ;
  size_t __s1_len___7 ;
  size_t __s2_len___7 ;
  int tmp___109 ;
  int tmp___112 ;
  int tmp___113 ;
  int tmp___114 ;
  int tmp___115 ;
  int tmp___116 ;
  size_t __s1_len___8 ;
  size_t __s2_len___8 ;
  int tmp___122 ;
  int tmp___125 ;
  int tmp___126 ;
  int tmp___127 ;
  int tmp___128 ;
  int tmp___129 ;

  {
  if (0) {
    if (0) {
      __s1_len___8 = __builtin_strlen(mname);
      __s2_len___8 = __builtin_strlen("__clone");
      if (! ((size_t )((void const   *)(mname + 1)) - (size_t )((void const   *)mname) == 1UL)) {
        goto _L___18;
      } else
      if (__s1_len___8 >= 4UL) {
        _L___18: 
        if (! ((size_t )((void const   *)("__clone" + 1)) - (size_t )((void const   *)"__clone") == 1UL)) {
          tmp___127 = 1;
        } else
        if (__s2_len___8 >= 4UL) {
          tmp___127 = 1;
        } else {
          tmp___127 = 0;
        }
      } else {
        tmp___127 = 0;
      }
      if (tmp___127) {
        tmp___122 = __builtin_strcmp(mname, "__clone");
        tmp___126 = tmp___122;
      } else {
        tmp___125 = __builtin_strcmp(mname, "__clone");
        tmp___126 = tmp___125;
      }
    } else {
      tmp___125 = __builtin_strcmp(mname, "__clone");
      tmp___126 = tmp___125;
    }
    tmp___129 = tmp___126;
  } else {
    tmp___128 = strncmp(mname, "__clone", (size_t )mname_len);
    tmp___129 = tmp___128;
  }
  if (tmp___129) {
    if (0) {
      if (0) {
        __s1_len___7 = __builtin_strlen(mname);
        __s2_len___7 = __builtin_strlen("__construct");
        if (! ((size_t )((void const   *)(mname + 1)) - (size_t )((void const   *)mname) == 1UL)) {
          goto _L___16;
        } else
        if (__s1_len___7 >= 4UL) {
          _L___16: 
          if (! ((size_t )((void const   *)("__construct" + 1)) - (size_t )((void const   *)"__construct") == 1UL)) {
            tmp___114 = 1;
          } else
          if (__s2_len___7 >= 4UL) {
            tmp___114 = 1;
          } else {
            tmp___114 = 0;
          }
        } else {
          tmp___114 = 0;
        }
        if (tmp___114) {
          tmp___109 = __builtin_strcmp(mname, "__construct");
          tmp___113 = tmp___109;
        } else {
          tmp___112 = __builtin_strcmp(mname, "__construct");
          tmp___113 = tmp___112;
        }
      } else {
        tmp___112 = __builtin_strcmp(mname, "__construct");
        tmp___113 = tmp___112;
      }
      tmp___116 = tmp___113;
    } else {
      tmp___115 = strncmp(mname, "__construct", (size_t )mname_len);
      tmp___116 = tmp___115;
    }
    if (tmp___116) {
      if (0) {
        if (0) {
          __s1_len___6 = __builtin_strlen(mname);
          __s2_len___6 = __builtin_strlen("__destruct");
          if (! ((size_t )((void const   *)(mname + 1)) - (size_t )((void const   *)mname) == 1UL)) {
            goto _L___14;
          } else
          if (__s1_len___6 >= 4UL) {
            _L___14: 
            if (! ((size_t )((void const   *)("__destruct" + 1)) - (size_t )((void const   *)"__destruct") == 1UL)) {
              tmp___101 = 1;
            } else
            if (__s2_len___6 >= 4UL) {
              tmp___101 = 1;
            } else {
              tmp___101 = 0;
            }
          } else {
            tmp___101 = 0;
          }
          if (tmp___101) {
            tmp___96 = __builtin_strcmp(mname, "__destruct");
            tmp___100 = tmp___96;
          } else {
            tmp___99 = __builtin_strcmp(mname, "__destruct");
            tmp___100 = tmp___99;
          }
        } else {
          tmp___99 = __builtin_strcmp(mname, "__destruct");
          tmp___100 = tmp___99;
        }
        tmp___103 = tmp___100;
      } else {
        tmp___102 = strncmp(mname, "__destruct", (size_t )mname_len);
        tmp___103 = tmp___102;
      }
      if (tmp___103) {
        if (0) {
          if (0) {
            __s1_len___5 = __builtin_strlen(mname);
            __s2_len___5 = __builtin_strlen("__get");
            if (! ((size_t )((void const   *)(mname + 1)) - (size_t )((void const   *)mname) == 1UL)) {
              goto _L___12;
            } else
            if (__s1_len___5 >= 4UL) {
              _L___12: 
              if (! ((size_t )((void const   *)("__get" + 1)) - (size_t )((void const   *)"__get") == 1UL)) {
                tmp___88 = 1;
              } else
              if (__s2_len___5 >= 4UL) {
                tmp___88 = 1;
              } else {
                tmp___88 = 0;
              }
            } else {
              tmp___88 = 0;
            }
            if (tmp___88) {
              tmp___83 = __builtin_strcmp(mname, "__get");
              tmp___87 = tmp___83;
            } else {
              tmp___86 = __builtin_strcmp(mname, "__get");
              tmp___87 = tmp___86;
            }
          } else {
            tmp___86 = __builtin_strcmp(mname, "__get");
            tmp___87 = tmp___86;
          }
          tmp___90 = tmp___87;
        } else {
          tmp___89 = strncmp(mname, "__get", (size_t )mname_len);
          tmp___90 = tmp___89;
        }
        if (tmp___90) {
          if (0) {
            if (0) {
              __s1_len___4 = __builtin_strlen(mname);
              __s2_len___4 = __builtin_strlen("__set");
              if (! ((size_t )((void const   *)(mname + 1)) - (size_t )((void const   *)mname) == 1UL)) {
                goto _L___10;
              } else
              if (__s1_len___4 >= 4UL) {
                _L___10: 
                if (! ((size_t )((void const   *)("__set" + 1)) - (size_t )((void const   *)"__set") == 1UL)) {
                  tmp___75 = 1;
                } else
                if (__s2_len___4 >= 4UL) {
                  tmp___75 = 1;
                } else {
                  tmp___75 = 0;
                }
              } else {
                tmp___75 = 0;
              }
              if (tmp___75) {
                tmp___70 = __builtin_strcmp(mname, "__set");
                tmp___74 = tmp___70;
              } else {
                tmp___73 = __builtin_strcmp(mname, "__set");
                tmp___74 = tmp___73;
              }
            } else {
              tmp___73 = __builtin_strcmp(mname, "__set");
              tmp___74 = tmp___73;
            }
            tmp___77 = tmp___74;
          } else {
            tmp___76 = strncmp(mname, "__set", (size_t )mname_len);
            tmp___77 = tmp___76;
          }
          if (tmp___77) {
            if (0) {
              if (0) {
                __s1_len___3 = __builtin_strlen(mname);
                __s2_len___3 = __builtin_strlen("__call");
                if (! ((size_t )((void const   *)(mname + 1)) - (size_t )((void const   *)mname) == 1UL)) {
                  goto _L___8;
                } else
                if (__s1_len___3 >= 4UL) {
                  _L___8: 
                  if (! ((size_t )((void const   *)("__call" + 1)) - (size_t )((void const   *)"__call") == 1UL)) {
                    tmp___62 = 1;
                  } else
                  if (__s2_len___3 >= 4UL) {
                    tmp___62 = 1;
                  } else {
                    tmp___62 = 0;
                  }
                } else {
                  tmp___62 = 0;
                }
                if (tmp___62) {
                  tmp___57 = __builtin_strcmp(mname, "__call");
                  tmp___61 = tmp___57;
                } else {
                  tmp___60 = __builtin_strcmp(mname, "__call");
                  tmp___61 = tmp___60;
                }
              } else {
                tmp___60 = __builtin_strcmp(mname, "__call");
                tmp___61 = tmp___60;
              }
              tmp___64 = tmp___61;
            } else {
              tmp___63 = strncmp(mname, "__call", (size_t )mname_len);
              tmp___64 = tmp___63;
            }
            if (tmp___64) {
              if (0) {
                if (0) {
                  __s1_len___2 = __builtin_strlen(mname);
                  __s2_len___2 = __builtin_strlen("__unset");
                  if (! ((size_t )((void const   *)(mname + 1)) - (size_t )((void const   *)mname) == 1UL)) {
                    goto _L___6;
                  } else
                  if (__s1_len___2 >= 4UL) {
                    _L___6: 
                    if (! ((size_t )((void const   *)("__unset" + 1)) - (size_t )((void const   *)"__unset") == 1UL)) {
                      tmp___49 = 1;
                    } else
                    if (__s2_len___2 >= 4UL) {
                      tmp___49 = 1;
                    } else {
                      tmp___49 = 0;
                    }
                  } else {
                    tmp___49 = 0;
                  }
                  if (tmp___49) {
                    tmp___44 = __builtin_strcmp(mname, "__unset");
                    tmp___48 = tmp___44;
                  } else {
                    tmp___47 = __builtin_strcmp(mname, "__unset");
                    tmp___48 = tmp___47;
                  }
                } else {
                  tmp___47 = __builtin_strcmp(mname, "__unset");
                  tmp___48 = tmp___47;
                }
                tmp___51 = tmp___48;
              } else {
                tmp___50 = strncmp(mname, "__unset", (size_t )mname_len);
                tmp___51 = tmp___50;
              }
              if (tmp___51) {
                if (0) {
                  if (0) {
                    __s1_len___1 = __builtin_strlen(mname);
                    __s2_len___1 = __builtin_strlen("__isset");
                    if (! ((size_t )((void const   *)(mname + 1)) - (size_t )((void const   *)mname) == 1UL)) {
                      goto _L___4;
                    } else
                    if (__s1_len___1 >= 4UL) {
                      _L___4: 
                      if (! ((size_t )((void const   *)("__isset" + 1)) - (size_t )((void const   *)"__isset") == 1UL)) {
                        tmp___36 = 1;
                      } else
                      if (__s2_len___1 >= 4UL) {
                        tmp___36 = 1;
                      } else {
                        tmp___36 = 0;
                      }
                    } else {
                      tmp___36 = 0;
                    }
                    if (tmp___36) {
                      tmp___31 = __builtin_strcmp(mname, "__isset");
                      tmp___35 = tmp___31;
                    } else {
                      tmp___34 = __builtin_strcmp(mname, "__isset");
                      tmp___35 = tmp___34;
                    }
                  } else {
                    tmp___34 = __builtin_strcmp(mname, "__isset");
                    tmp___35 = tmp___34;
                  }
                  tmp___38 = tmp___35;
                } else {
                  tmp___37 = strncmp(mname, "__isset", (size_t )mname_len);
                  tmp___38 = tmp___37;
                }
                if (tmp___38) {
                  if (0) {
                    if (0) {
                      __s1_len___0 = __builtin_strlen(mname);
                      __s2_len___0 = __builtin_strlen("__callstatic");
                      if (! ((size_t )((void const   *)(mname + 1)) - (size_t )((void const   *)mname) == 1UL)) {
                        goto _L___2;
                      } else
                      if (__s1_len___0 >= 4UL) {
                        _L___2: 
                        if (! ((size_t )((void const   *)("__callstatic" + 1)) - (size_t )((void const   *)"__callstatic") == 1UL)) {
                          tmp___23 = 1;
                        } else
                        if (__s2_len___0 >= 4UL) {
                          tmp___23 = 1;
                        } else {
                          tmp___23 = 0;
                        }
                      } else {
                        tmp___23 = 0;
                      }
                      if (tmp___23) {
                        tmp___18 = __builtin_strcmp(mname, "__callstatic");
                        tmp___22 = tmp___18;
                      } else {
                        tmp___21 = __builtin_strcmp(mname, "__callstatic");
                        tmp___22 = tmp___21;
                      }
                    } else {
                      tmp___21 = __builtin_strcmp(mname, "__callstatic");
                      tmp___22 = tmp___21;
                    }
                    tmp___25 = tmp___22;
                  } else {
                    tmp___24 = strncmp(mname, "__callstatic", (size_t )mname_len);
                    tmp___25 = tmp___24;
                  }
                  if (tmp___25) {
                    if (0) {
                      if (0) {
                        __s1_len = __builtin_strlen(mname);
                        __s2_len = __builtin_strlen("__tostring");
                        if (! ((size_t )((void const   *)(mname + 1)) - (size_t )((void const   *)mname) == 1UL)) {
                          goto _L___0;
                        } else
                        if (__s1_len >= 4UL) {
                          _L___0: 
                          if (! ((size_t )((void const   *)("__tostring" + 1)) - (size_t )((void const   *)"__tostring") == 1UL)) {
                            tmp___10 = 1;
                          } else
                          if (__s2_len >= 4UL) {
                            tmp___10 = 1;
                          } else {
                            tmp___10 = 0;
                          }
                        } else {
                          tmp___10 = 0;
                        }
                        if (tmp___10) {
                          tmp___5 = __builtin_strcmp(mname, "__tostring");
                          tmp___9 = tmp___5;
                        } else {
                          tmp___8 = __builtin_strcmp(mname, "__tostring");
                          tmp___9 = tmp___8;
                        }
                      } else {
                        tmp___8 = __builtin_strcmp(mname, "__tostring");
                        tmp___9 = tmp___8;
                      }
                      tmp___12 = tmp___9;
                    } else {
                      tmp___11 = strncmp(mname, "__tostring", (size_t )mname_len);
                      tmp___12 = tmp___11;
                    }
                    if (tmp___12) {
                      if (ce->name_length + 1U == mname_len) {
                        tmp = _emalloc((size_t )(ce->name_length + 1U));
                        lowercase_name = (char *)tmp;
                        zend_str_tolower_copy(lowercase_name, ce->name,
                                              ce->name_length);
                        tmp___0 = (*zend_new_interned_string)((char const   *)lowercase_name,
                                                              (int )(ce->name_length + 1U),
                                                              1);
                        lowercase_name = (char *)tmp___0;
                        tmp___1 = memcmp((void const   *)mname,
                                         (void const   *)lowercase_name,
                                         (size_t )mname_len);
                        if (! tmp___1) {
                          if (ce->constructor) {
                            zend_error(1 << 6L,
                                       "%s has colliding constructor definitions coming from traits",
                                       ce->name);
                          } else {

                          }
                          ce->constructor = fe;
                          fe->common.fn_flags |= 8192U;
                        } else {

                        }
                        while (1) {
                          if ((unsigned long )lowercase_name >= (unsigned long )compiler_globals.interned_strings_start) {
                            if (! ((unsigned long )lowercase_name < (unsigned long )compiler_globals.interned_strings_end)) {
                              _efree((void *)lowercase_name);
                            } else {

                            }
                          } else {
                            _efree((void *)lowercase_name);
                          }
                          break;
                        }
                      } else {

                      }
                    } else {
                      ce->__tostring = fe;
                    }
                  } else {
                    ce->__callstatic = fe;
                  }
                } else {
                  ce->__isset = fe;
                }
              } else {
                ce->__unset = fe;
              }
            } else {
              ce->__call = fe;
            }
          } else {
            ce->__set = fe;
          }
        } else {
          ce->__get = fe;
        }
      } else {
        ce->destructor = fe;
        fe->common.fn_flags |= 16384U;
      }
    } else {
      if (ce->constructor) {
        zend_error(1 << 6L,
                   "%s has colliding constructor definitions coming from traits",
                   ce->name);
      } else {

      }
      ce->constructor = fe;
      fe->common.fn_flags |= 8192U;
    }
  } else {
    ce->clone = fe;
    fe->common.fn_flags |= 32768U;
  }
  return;
}
}
static int zend_traits_merge_functions_to_class(zend_function *fn ,
                                                int num_args , va_list args ,
                                                zend_hash_key *hash_key ) 
{ 
  zend_class_entry *ce ;
  zend_class_entry *tmp___0 ;
  int add ;
  zend_function *existing_fn ;
  zend_function fn_copy ;
  zend_function *fn_copy_p ;
  zend_function *prototype ;
  int __attribute__((__visibility__("default")))  tmp___1 ;
  zend_function *parent_function ;
  int __attribute__((__visibility__("default")))  tmp___2 ;
  char __attribute__((__visibility__("default")))  *tmp___3 ;
  int __attribute__((__visibility__("default")))  tmp___4 ;
  zend_class_entry *tmp ;

  {
  tmp = __builtin_va_arg(args, zend_class_entry *);
  tmp___0 = tmp;
  ce = tmp___0;
  add = 0;
  existing_fn = (zend_function *)((void *)0);
  prototype = (zend_function *)((void *)0);
  tmp___1 = zend_hash_quick_find((HashTable const   *)(& ce->function_table),
                                 hash_key->arKey, hash_key->nKeyLength,
                                 hash_key->h, (void **)(& existing_fn));
  if (tmp___1 == (int __attribute__((__visibility__("default")))  )-1) {
    add = 1;
  } else
  if ((unsigned long )existing_fn->common.scope != (unsigned long )ce) {
    add = 1;
  } else {

  }
  if (add) {
    if (ce->parent) {
      tmp___2 = zend_hash_quick_find((HashTable const   *)(& (ce->parent)->function_table),
                                     hash_key->arKey, hash_key->nKeyLength,
                                     hash_key->h, (void **)(& parent_function));
      if (tmp___2 != (int __attribute__((__visibility__("default")))  )-1) {
        prototype = parent_function;
        if (fn->common.fn_flags & 2U) {
          zend_function_dtor(fn);
          return (1);
        } else {

        }
      } else {

      }
    } else {

    }
    fn->common.scope = ce;
    fn->common.prototype = prototype;
    if (prototype) {
      if (prototype->common.fn_flags & 8U) {
        fn->common.fn_flags |= 8U;
      } else
      if (prototype->common.fn_flags & 2U) {
        fn->common.fn_flags |= 8U;
      } else {
        goto _L;
      }
    } else
    _L: 
    if (fn->common.fn_flags & 8U) {
      fn->common.fn_flags -= 8U;
    } else {

    }
    if (prototype) {
      do_inheritance_check_on_method(fn, prototype);
    } else {

    }
    if (existing_fn) {
      if (existing_fn->common.fn_flags & 2U) {
        do_inheritance_check_on_method(fn, existing_fn);
      } else {

      }
    } else {

    }
    if (existing_fn) {
      if ((unsigned long )existing_fn->common.scope != (unsigned long )ce) {
        if ((fn->common.fn_flags & 2U) == 0U) {
          zend_hash_del_key_or_index(& ce->function_table, hash_key->arKey,
                                     hash_key->nKeyLength, hash_key->h, 2);
        } else {

        }
      } else {

      }
    } else {

    }
    if (fn->common.fn_flags & 2U) {
      ce->ce_flags |= 16U;
    } else {

    }
    if (fn->op_array.static_variables) {
      ce->ce_flags |= 8388608U;
    } else {

    }
    fn_copy = *fn;
    tmp___3 = _estrdup(fn->common.function_name);
    zend_traits_duplicate_function(& fn_copy, ce, (char *)tmp___3);
    tmp___4 = _zend_hash_quick_add_or_update(& ce->function_table,
                                             hash_key->arKey,
                                             hash_key->nKeyLength, hash_key->h,
                                             (void *)(& fn_copy),
                                             (uint )sizeof(zend_function ),
                                             (void **)(& fn_copy_p), 1);
    if (tmp___4 == (int __attribute__((__visibility__("default")))  )-1) {
      zend_error(1 << 6L,
                 "Trait method %s has not been applied, because failure occured during updating class method table",
                 hash_key->arKey);
    } else {

    }
    zend_add_magic_methods(ce, hash_key->arKey, hash_key->nKeyLength, fn_copy_p);
    zend_function_dtor(fn);
  } else {
    zend_function_dtor(fn);
  }
  return (1);
}
}
static int zend_traits_copy_functions(zend_function *fn , int num_args ,
                                      va_list args , zend_hash_key *hash_key ) 
{ 
  HashTable *target ;
  zend_class_entry *target_ce ;
  zend_trait_alias **aliases ;
  HashTable *exclude_table ;
  char *lcname ;
  unsigned int fnname_len ;
  zend_function fn_copy ;
  void *dummy ;
  size_t i ;
  HashTable *tmp ;
  zend_class_entry *tmp___0 ;
  zend_trait_alias **tmp___1 ;
  HashTable *tmp___2 ;
  size_t tmp___3 ;
  char __attribute__((__visibility__("default")))  *tmp___4 ;
  char __attribute__((__visibility__("default")))  *tmp___5 ;
  int __attribute__((__visibility__("default")))  tmp___6 ;
  int __attribute__((__visibility__("default")))  tmp___7 ;
  char __attribute__((__visibility__("default")))  *tmp___8 ;
  char __attribute__((__visibility__("default")))  *tmp___9 ;
  int __attribute__((__visibility__("default")))  tmp___10 ;
  int __attribute__((__visibility__("default")))  tmp___11 ;
  int __attribute__((__visibility__("default")))  tmp___12 ;
  HashTable *tmp___13 ;
  zend_class_entry *tmp___14 ;
  zend_trait_alias **tmp___15 ;
  HashTable *tmp___16 ;

  {
  i = (size_t )0;
  tmp___13 = __builtin_va_arg(args, HashTable *);
  tmp = tmp___13;
  target = tmp;
  tmp___14 = __builtin_va_arg(args, zend_class_entry *);
  tmp___0 = tmp___14;
  target_ce = tmp___0;
  tmp___15 = __builtin_va_arg(args, zend_trait_alias **);
  tmp___1 = tmp___15;
  aliases = tmp___1;
  tmp___16 = __builtin_va_arg(args, HashTable *);
  tmp___2 = tmp___16;
  exclude_table = tmp___2;
  tmp___3 = strlen(fn->common.function_name);
  fnname_len = (unsigned int )tmp___3;
  if (aliases) {
    while (*(aliases + i)) {
      if ((unsigned long )(*(aliases + i))->alias != (unsigned long )((void *)0)) {
        if (! ((*(aliases + i))->trait_method)->ce) {
          goto _L;
        } else
        if ((unsigned long )fn->common.scope == (unsigned long )((*(aliases + i))->trait_method)->ce) {
          _L: 
          if (((*(aliases + i))->trait_method)->mname_len == fnname_len) {
            tmp___7 = zend_binary_strcasecmp(((*(aliases + i))->trait_method)->method_name,
                                             ((*(aliases + i))->trait_method)->mname_len,
                                             fn->common.function_name,
                                             fnname_len);
            if (tmp___7 == (int __attribute__((__visibility__("default")))  )0) {
              fn_copy = *fn;
              tmp___4 = _estrndup((*(aliases + i))->alias,
                                  (*(aliases + i))->alias_len);
              zend_traits_duplicate_function(& fn_copy,
                                             (zend_class_entry *)((void *)0),
                                             (char *)tmp___4);
              if ((*(aliases + i))->modifiers) {
                fn_copy.common.fn_flags = (*(aliases + i))->modifiers;
                if (! ((*(aliases + i))->modifiers & 1792U)) {
                  fn_copy.common.fn_flags |= 256U;
                } else {

                }
                fn_copy.common.fn_flags |= fn->common.fn_flags ^ (fn->common.fn_flags & 1792U);
              } else {

              }
              tmp___5 = zend_str_tolower_dup((*(aliases + i))->alias,
                                             (*(aliases + i))->alias_len);
              lcname = (char *)tmp___5;
              tmp___6 = _zend_hash_add_or_update(target, (char const   *)lcname,
                                                 (*(aliases + i))->alias_len + 1U,
                                                 (void *)(& fn_copy),
                                                 (uint )sizeof(zend_function ),
                                                 (void **)((void *)0), 1 << 1);
              if (tmp___6 == (int __attribute__((__visibility__("default")))  )-1) {
                zend_error(1 << 6L,
                           "Failed to add aliased trait method (%s) to the trait table. There is probably already a trait method with the same name",
                           fn_copy.common.function_name);
              } else {

              }
              _efree((void *)lcname);
              if (! ((*(aliases + i))->trait_method)->ce) {
                ((*(aliases + i))->trait_method)->ce = fn->common.scope;
              } else {

              }
            } else {

            }
          } else {

          }
        } else {

        }
      } else {

      }
      i ++;
    }
  } else {

  }
  tmp___8 = zend_str_tolower_dup(fn->common.function_name, fnname_len);
  lcname = (char *)tmp___8;
  if ((unsigned long )exclude_table == (unsigned long )((void *)0)) {
    goto _L___1;
  } else {
    tmp___12 = zend_hash_find((HashTable const   *)exclude_table,
                              (char const   *)lcname, fnname_len, & dummy);
    if (tmp___12 == (int __attribute__((__visibility__("default")))  )-1) {
      _L___1: 
      fn_copy = *fn;
      tmp___9 = _estrndup(fn->common.function_name, fnname_len);
      zend_traits_duplicate_function(& fn_copy, (zend_class_entry *)((void *)0),
                                     (char *)tmp___9);
      if (aliases) {
        i = (size_t )0;
        while (*(aliases + i)) {
          if ((unsigned long )(*(aliases + i))->alias == (unsigned long )((void *)0)) {
            if ((*(aliases + i))->modifiers != 0U) {
              if (! ((*(aliases + i))->trait_method)->ce) {
                goto _L___0;
              } else
              if ((unsigned long )fn->common.scope == (unsigned long )((*(aliases + i))->trait_method)->ce) {
                _L___0: 
                if (((*(aliases + i))->trait_method)->mname_len == fnname_len) {
                  tmp___10 = zend_binary_strcasecmp(((*(aliases + i))->trait_method)->method_name,
                                                    ((*(aliases + i))->trait_method)->mname_len,
                                                    fn->common.function_name,
                                                    fnname_len);
                  if (tmp___10 == (int __attribute__((__visibility__("default")))  )0) {
                    fn_copy.common.fn_flags = (*(aliases + i))->modifiers;
                    if (! ((*(aliases + i))->modifiers & 1792U)) {
                      fn_copy.common.fn_flags |= 256U;
                    } else {

                    }
                    fn_copy.common.fn_flags |= fn->common.fn_flags ^ (fn->common.fn_flags & 1792U);
                    if (! ((*(aliases + i))->trait_method)->ce) {
                      ((*(aliases + i))->trait_method)->ce = fn->common.scope;
                    } else {

                    }
                  } else {

                  }
                } else {

                }
              } else {

              }
            } else {

            }
          } else {

          }
          i ++;
        }
      } else {

      }
      tmp___11 = _zend_hash_add_or_update(target, (char const   *)lcname,
                                          fnname_len + 1U, (void *)(& fn_copy),
                                          (uint )sizeof(zend_function ),
                                          (void **)((void *)0), 1 << 1);
      if (tmp___11 == (int __attribute__((__visibility__("default")))  )-1) {
        zend_error(1 << 6L,
                   "Failed to add trait method (%s) to the trait table. There is probably already a trait method with the same name",
                   fn_copy.common.function_name);
      } else {

      }
    } else {

    }
  }
  _efree((void *)lcname);
  return (0);
}
}
static void zend_traits_copy_trait_function_table(HashTable *target ,
                                                  zend_class_entry *target_ce ,
                                                  HashTable *source ,
                                                  zend_trait_alias **aliases ,
                                                  HashTable *exclude_table ) 
{ 


  {
  zend_hash_apply_with_arguments(source,
                                 (int (*)(void *pDest , int num_args ,
                                          va_list args ,
                                          zend_hash_key *hash_key ))(& zend_traits_copy_functions),
                                 4, target, target_ce, aliases, exclude_table);
  return;
}
}
static void zend_traits_init_trait_structures(zend_class_entry *ce ) 
{ 
  size_t i ;
  size_t j ;
  zend_trait_precedence *cur_precedence ;
  zend_trait_method_reference *cur_method_ref ;
  char *lcname ;
  zend_bool method_exists ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp ;
  char __attribute__((__visibility__("default")))  *tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;
  char *class_name ;
  zend_uint name_length ;
  size_t tmp___2 ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp___3 ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp___4 ;
  char __attribute__((__visibility__("default")))  *tmp___5 ;
  int __attribute__((__visibility__("default")))  tmp___6 ;

  {
  j = (size_t )0;
  if (ce->trait_precedences) {
    i = (size_t )0;
    while (1) {
      cur_precedence = *(ce->trait_precedences + i);
      if (! cur_precedence) {
        break;
      } else {

      }
      if (cur_precedence->exclude_from_classes) {
        cur_method_ref = cur_precedence->trait_method;
        tmp = zend_fetch_class(cur_method_ref->class_name,
                               cur_method_ref->cname_len, 14);
        (cur_precedence->trait_method)->ce = (zend_class_entry *)tmp;
        tmp___0 = zend_str_tolower_dup(cur_method_ref->method_name,
                                       cur_method_ref->mname_len);
        lcname = (char *)tmp___0;
        tmp___1 = zend_hash_exists((HashTable const   *)(& (cur_method_ref->ce)->function_table),
                                   (char const   *)lcname,
                                   cur_method_ref->mname_len + 1U);
        method_exists = (zend_bool )tmp___1;
        _efree((void *)lcname);
        if (! method_exists) {
          zend_error(1 << 6L,
                     "A precedence rule was defined for %s::%s but this method does not exist",
                     (cur_method_ref->ce)->name, cur_method_ref->method_name);
        } else {

        }
        j = (size_t )0;
        while (*(cur_precedence->exclude_from_classes + j)) {
          class_name = (char *)*(cur_precedence->exclude_from_classes + j);
          tmp___2 = strlen((char const   *)class_name);
          name_length = (zend_uint )tmp___2;
          tmp___3 = zend_fetch_class((char const   *)class_name, name_length, 14);
          *(cur_precedence->exclude_from_classes + j) = (zend_class_entry *)tmp___3;
          _efree((void *)class_name);
          j ++;
        }
      } else {

      }
      i ++;
    }
  } else {

  }
  if (ce->trait_aliases) {
    i = (size_t )0;
    while (*(ce->trait_aliases + i)) {
      if (((*(ce->trait_aliases + i))->trait_method)->class_name) {
        cur_method_ref = (*(ce->trait_aliases + i))->trait_method;
        tmp___4 = zend_fetch_class(cur_method_ref->class_name,
                                   cur_method_ref->cname_len, 14);
        cur_method_ref->ce = (zend_class_entry *)tmp___4;
        tmp___5 = zend_str_tolower_dup(cur_method_ref->method_name,
                                       cur_method_ref->mname_len);
        lcname = (char *)tmp___5;
        tmp___6 = zend_hash_exists((HashTable const   *)(& (cur_method_ref->ce)->function_table),
                                   (char const   *)lcname,
                                   cur_method_ref->mname_len + 1U);
        method_exists = (zend_bool )tmp___6;
        _efree((void *)lcname);
        if (! method_exists) {
          zend_error(1 << 6L,
                     "An alias was defined for %s::%s but this method does not exist",
                     (cur_method_ref->ce)->name, cur_method_ref->method_name);
        } else {

        }
      } else {

      }
      i ++;
    }
  } else {

  }
  return;
}
}
static void zend_traits_compile_exclude_table(HashTable *exclude_table ,
                                              zend_trait_precedence **precedences ,
                                              zend_class_entry *trait ) 
{ 
  size_t i ;
  size_t j ;
  zend_uint lcname_len ;
  char *lcname ;
  char __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  i = (size_t )0;
  if (! precedences) {
    return;
  } else {

  }
  while (*(precedences + i)) {
    if ((*(precedences + i))->exclude_from_classes) {
      j = (size_t )0;
      while (*((*(precedences + i))->exclude_from_classes + j)) {
        if ((unsigned long )*((*(precedences + i))->exclude_from_classes + j) == (unsigned long )trait) {
          lcname_len = ((*(precedences + i))->trait_method)->mname_len;
          tmp = zend_str_tolower_dup(((*(precedences + i))->trait_method)->method_name,
                                     lcname_len);
          lcname = (char *)tmp;
          tmp___0 = _zend_hash_add_or_update(exclude_table,
                                             (char const   *)lcname, lcname_len,
                                             (void *)0, (uint )0,
                                             (void **)((void *)0), 1 << 1);
          if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
            _efree((void *)lcname);
            zend_error(1 << 6L,
                       "Failed to evaluate a trait precedence (%s). Method of trait %s was defined to be excluded multiple times",
                       ((*(precedences + i))->trait_method)->method_name,
                       trait->name);
          } else {

          }
          _efree((void *)lcname);
        } else {

        }
        j ++;
      }
    } else {

    }
    i ++;
  }
  return;
}
}
static void zend_do_traits_method_binding(zend_class_entry *ce ) 
{ 
  HashTable **function_tables ;
  HashTable *resulting_table ;
  HashTable exclude_table ;
  size_t i ;
  void *tmp ;
  void *tmp___0 ;
  void *tmp___1 ;

  {
  tmp = malloc(sizeof(HashTable *) * (unsigned long )ce->num_traits);
  function_tables = (HashTable **)tmp;
  tmp___0 = malloc(sizeof(HashTable ));
  resulting_table = (HashTable *)tmp___0;
  _zend_hash_init_ex(resulting_table, (uint )10,
                     (ulong (*)(char const   *arKey , uint nKeyLength ))((void *)0),
                     (void (*)(void *pDest ))((void *)0), (zend_bool )1,
                     (zend_bool )0);
  i = (size_t )0;
  while (i < (size_t )ce->num_traits) {
    tmp___1 = malloc(sizeof(HashTable ));
    *(function_tables + i) = (HashTable *)tmp___1;
    _zend_hash_init_ex(*(function_tables + i),
                       (*(ce->traits + i))->function_table.nNumOfElements,
                       (ulong (*)(char const   *arKey , uint nKeyLength ))((void *)0),
                       (void (*)(void *pDest ))((void *)0), (zend_bool )1,
                       (zend_bool )0);
    if (ce->trait_precedences) {
      _zend_hash_init_ex(& exclude_table, (uint )2,
                         (ulong (*)(char const   *arKey , uint nKeyLength ))((void *)0),
                         (void (*)(void *pDest ))((void *)0), (zend_bool )0,
                         (zend_bool )0);
      zend_traits_compile_exclude_table(& exclude_table, ce->trait_precedences,
                                        *(ce->traits + i));
      zend_traits_copy_trait_function_table(*(function_tables + i), ce,
                                            & (*(ce->traits + i))->function_table,
                                            ce->trait_aliases, & exclude_table);
      zend_hash_graceful_destroy(& exclude_table);
    } else {
      zend_traits_copy_trait_function_table(*(function_tables + i), ce,
                                            & (*(ce->traits + i))->function_table,
                                            ce->trait_aliases,
                                            (HashTable *)((void *)0));
    }
    i ++;
  }
  i = (size_t )0;
  while (i < (size_t )ce->num_traits) {
    zend_hash_apply_with_arguments(*(function_tables + i),
                                   (int (*)(void *pDest , int num_args ,
                                            va_list args ,
                                            zend_hash_key *hash_key ))(& zend_traits_merge_functions),
                                   5, i, ce->num_traits, resulting_table,
                                   function_tables, ce);
    i ++;
  }
  zend_hash_apply_with_arguments(resulting_table,
                                 (int (*)(void *pDest , int num_args ,
                                          va_list args ,
                                          zend_hash_key *hash_key ))(& zend_traits_merge_functions_to_class),
                                 1, ce);
  i = (size_t )0;
  while (i < (size_t )ce->num_traits) {
    zend_hash_graceful_destroy(*(function_tables + i));
    free((void *)*(function_tables + i));
    i ++;
  }
  free((void *)function_tables);
  zend_hash_graceful_destroy(resulting_table);
  free((void *)resulting_table);
  return;
}
}
static zend_class_entry *find_first_definition(zend_class_entry *ce ,
                                               size_t current_trait ,
                                               char const   *prop_name ,
                                               int prop_name_length ,
                                               ulong prop_hash ,
                                               zend_class_entry *coliding_ce ) 
{ 
  size_t i ;
  zend_property_info *coliding_prop ;
  int __attribute__((__visibility__("default")))  tmp ;

  {
  i = (size_t )0;
  while (1) {
    if (i < current_trait) {
      if (! (i < (size_t )ce->num_traits)) {
        break;
      } else {

      }
    } else {
      break;
    }
    tmp = zend_hash_quick_find((HashTable const   *)(& (*(ce->traits + i))->properties_info),
                               prop_name, (uint )(prop_name_length + 1),
                               prop_hash, (void **)(& coliding_prop));
    if (tmp == (int __attribute__((__visibility__("default")))  )0) {
      return (*(ce->traits + i));
    } else {

    }
    i ++;
  }
  return (coliding_ce);
}
}
static void zend_do_traits_property_binding(zend_class_entry *ce ) 
{ 
  size_t i ;
  zend_property_info *property_info ;
  zend_property_info *coliding_prop ;
  zval compare_result ;
  char const   *prop_name ;
  int prop_name_length ;
  ulong prop_hash ;
  char const   *class_name_unused ;
  zend_bool prop_found ;
  zend_bool not_compatible ;
  zval *prop_value ;
  int __attribute__((__visibility__("default")))  tmp ;
  size_t tmp___0 ;
  ulong __attribute__((__visibility__("default")))  tmp___1 ;
  int __attribute__((__visibility__("default")))  tmp___2 ;
  int __attribute__((__visibility__("default")))  tmp___3 ;
  int tmp___4 ;
  int __attribute__((__visibility__("default")))  tmp___5 ;
  int tmp___6 ;
  zend_class_entry *tmp___7 ;
  zend_class_entry *tmp___8 ;
  int __attribute__((__visibility__("default")))  tmp___9 ;

  {
  i = (size_t )0;
  while (i < (size_t )ce->num_traits) {
    zend_hash_internal_pointer_reset_ex(& (*(ce->traits + i))->properties_info,
                                        (HashPosition *)((void *)0));
    while (1) {
      tmp___9 = zend_hash_get_current_data_ex(& (*(ce->traits + i))->properties_info,
                                              (void **)((void *)(& property_info)),
                                              (HashPosition *)((void *)0));
      if (! (tmp___9 == (int __attribute__((__visibility__("default")))  )0)) {
        break;
      } else {

      }
      if ((property_info->flags & 1792U) == 256U) {
        prop_hash = property_info->h;
        prop_name = property_info->name;
        prop_name_length = property_info->name_length;
        tmp = zend_hash_quick_find((HashTable const   *)(& ce->properties_info),
                                   property_info->name,
                                   (uint )(property_info->name_length + 1),
                                   property_info->h, (void **)(& coliding_prop));
        prop_found = (zend_bool )(tmp == (int __attribute__((__visibility__("default")))  )0);
      } else {
        zend_unmangle_property_name(property_info->name,
                                    property_info->name_length,
                                    & class_name_unused, & prop_name);
        tmp___0 = strlen(prop_name);
        prop_name_length = (int )tmp___0;
        tmp___1 = zend_get_hash_value(prop_name, (uint )(prop_name_length + 1));
        prop_hash = (ulong )tmp___1;
        tmp___2 = zend_hash_quick_find((HashTable const   *)(& ce->properties_info),
                                       prop_name, (uint )(prop_name_length + 1),
                                       prop_hash, (void **)(& coliding_prop));
        prop_found = (zend_bool )(tmp___2 == (int __attribute__((__visibility__("default")))  )0);
      }
      if (prop_found) {
        if (coliding_prop->flags & 131072U) {
          zend_hash_quick_find((HashTable const   *)(& (coliding_prop->ce)->properties_info),
                               prop_name, (uint )(prop_name_length + 1),
                               prop_hash, (void **)(& coliding_prop));
        } else {

        }
        if ((coliding_prop->flags & 1792U) == (property_info->flags & 1792U)) {
          if (property_info->flags & 1U) {
            tmp___3 = compare_function(& compare_result,
                                       *(ce->default_static_members_table + coliding_prop->offset),
                                       *((*(ce->traits + i))->default_static_members_table + property_info->offset));
            if (-1 == (int )tmp___3) {
              tmp___4 = 1;
            } else
            if (compare_result.value.lval != 0L) {
              tmp___4 = 1;
            } else {
              tmp___4 = 0;
            }
            not_compatible = (zend_bool )tmp___4;
          } else {
            tmp___5 = compare_function(& compare_result,
                                       *(ce->default_properties_table + coliding_prop->offset),
                                       *((*(ce->traits + i))->default_properties_table + property_info->offset));
            if (-1 == (int )tmp___5) {
              tmp___6 = 1;
            } else
            if (compare_result.value.lval != 0L) {
              tmp___6 = 1;
            } else {
              tmp___6 = 0;
            }
            not_compatible = (zend_bool )tmp___6;
          }
        } else {
          not_compatible = (zend_bool )1;
        }
        if (not_compatible) {
          tmp___7 = find_first_definition(ce, i, prop_name, prop_name_length,
                                          prop_hash, coliding_prop->ce);
          zend_error(1 << 6L,
                     "%s and %s define the same property ($%s) in the composition of %s. However, the definition differs and is considered incompatible. Class was composed",
                     tmp___7->name, (property_info->ce)->name, prop_name,
                     ce->name);
        } else {
          tmp___8 = find_first_definition(ce, i, prop_name, prop_name_length,
                                          prop_hash, coliding_prop->ce);
          zend_error(1 << 11L,
                     "%s and %s define the same property ($%s) in the composition of %s. This might be incompatible, to improve maintainability consider using accessor methods in traits instead. Class was composed",
                     tmp___8->name, (property_info->ce)->name, prop_name,
                     ce->name);
        }
      } else {

      }
      if (property_info->flags & 1U) {
        prop_value = *((*(ce->traits + i))->default_static_members_table + property_info->offset);
      } else {
        prop_value = *((*(ce->traits + i))->default_properties_table + property_info->offset);
      }
      zval_addref_p(prop_value);
      zend_declare_property_ex(ce, prop_name, prop_name_length, prop_value,
                               (int )property_info->flags,
                               property_info->doc_comment,
                               property_info->doc_comment_len);
      zend_hash_move_forward_ex(& (*(ce->traits + i))->properties_info,
                                (HashPosition *)((void *)0));
    }
    i ++;
  }
  return;
}
}
static void zend_do_check_for_inconsistent_traits_aliasing(zend_class_entry *ce ) 
{ 
  int i ;
  zend_trait_alias *cur_alias ;
  char *lc_method_name ;
  char __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  i = 0;
  if (ce->trait_aliases) {
    while (*(ce->trait_aliases + i)) {
      cur_alias = *(ce->trait_aliases + i);
      if (! (cur_alias->trait_method)->ce) {
        if (cur_alias->alias) {
          zend_error(1 << 6L,
                     "An alias (%s) was defined for method %s(), but this method does not exist",
                     cur_alias->alias, (cur_alias->trait_method)->method_name);
        } else {
          tmp = zend_str_tolower_dup((cur_alias->trait_method)->method_name,
                                     (cur_alias->trait_method)->mname_len);
          lc_method_name = (char *)tmp;
          tmp___0 = zend_hash_exists((HashTable const   *)(& ce->function_table),
                                     (char const   *)lc_method_name,
                                     (cur_alias->trait_method)->mname_len + 1U);
          if (tmp___0) {
            _efree((void *)lc_method_name);
            zend_error(1 << 6L,
                       "The modifiers for the trait alias %s() need to be changed in the same statment in which the alias is defined. Error",
                       (cur_alias->trait_method)->method_name);
          } else {
            _efree((void *)lc_method_name);
            zend_error(1 << 6L,
                       "The modifiers of the trait method %s() are changed, but this method does not exist. Error",
                       (cur_alias->trait_method)->method_name);
          }
        }
      } else {

      }
      i ++;
    }
  } else {

  }
  return;
}
}
void __attribute__((__visibility__("default")))  zend_do_bind_traits(zend_class_entry *ce ) 
{ 


  {
  if (ce->num_traits <= 0U) {
    return;
  } else {

  }
  zend_traits_init_trait_structures(ce);
  zend_do_traits_method_binding(ce);
  zend_do_check_for_inconsistent_traits_aliasing(ce);
  zend_do_traits_property_binding(ce);
  zend_verify_abstract_class(ce);
  if (ce->ce_flags & 16U) {
    ce->ce_flags -= 16U;
  } else {

  }
  return;
}
}
int __attribute__((__visibility__("default")))  do_bind_function(zend_op_array const   *op_array ,
                                                                 zend_op *opline ,
                                                                 HashTable *function_table ,
                                                                 zend_bool compile_time ) 
{ 
  zend_function *function ;
  zval *op1 ;
  zval *op2 ;
  int error_level ;
  int tmp ;
  zend_function *old_function ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;

  {
  if (compile_time) {
    op1 = & (op_array->literals + opline->op1.constant)->constant;
    op2 = & (op_array->literals + opline->op2.constant)->constant;
  } else {
    op1 = opline->op1.zv;
    op2 = opline->op2.zv;
  }
  zend_hash_quick_find((HashTable const   *)function_table,
                       (char const   *)op1->value.str.val,
                       (uint )op1->value.str.len,
                       ((zend_literal *)op1)->hash_value,
                       (void **)((void *)(& function)));
  tmp___1 = _zend_hash_quick_add_or_update(function_table,
                                           (char const   *)op2->value.str.val,
                                           (uint )(op2->value.str.len + 1),
                                           ((zend_literal *)op2)->hash_value,
                                           (void *)function,
                                           (uint )sizeof(zend_function ),
                                           (void **)((void *)0), 1 << 1);
  if (tmp___1 == (int __attribute__((__visibility__("default")))  )-1) {
    if (compile_time) {
      tmp = 1 << 6L;
    } else {
      tmp = 1;
    }
    error_level = tmp;
    tmp___0 = zend_hash_quick_find((HashTable const   *)function_table,
                                   (char const   *)op2->value.str.val,
                                   (uint )(op2->value.str.len + 1),
                                   ((zend_literal *)op2)->hash_value,
                                   (void **)((void *)(& old_function)));
    if (tmp___0 == (int __attribute__((__visibility__("default")))  )0) {
      if ((int )old_function->type == 2) {
        if (old_function->op_array.last > 0U) {
          zend_error(error_level,
                     "Cannot redeclare %s() (previously declared in %s:%d)",
                     function->common.function_name,
                     old_function->op_array.filename,
                     (old_function->op_array.opcodes + 0)->lineno);
        } else {
          zend_error(error_level, "Cannot redeclare %s()",
                     function->common.function_name);
        }
      } else {
        zend_error(error_level, "Cannot redeclare %s()",
                   function->common.function_name);
      }
    } else {
      zend_error(error_level, "Cannot redeclare %s()",
                 function->common.function_name);
    }
    return ((int __attribute__((__visibility__("default")))  )-1);
  } else {
    (*(function->op_array.refcount)) ++;
    function->op_array.static_variables = (HashTable *)((void *)0);
    return ((int __attribute__((__visibility__("default")))  )0);
  }
}
}
void zend_add_trait_precedence(znode *precedence_znode ) 
{ 
  zend_class_entry *ce ;

  {
  ce = compiler_globals.active_class_entry;
  zend_add_to_list((void *)(& ce->trait_precedences), precedence_znode->u.op.ptr);
  return;
}
}
void zend_add_trait_alias(znode *alias_znode ) 
{ 
  zend_class_entry *ce ;

  {
  ce = compiler_globals.active_class_entry;
  zend_add_to_list((void *)(& ce->trait_aliases), alias_znode->u.op.ptr);
  return;
}
}
void zend_prepare_reference(znode *result , znode *class_name ,
                            znode *method_name ) 
{ 
  zend_trait_method_reference *method_ref ;
  void __attribute__((__visibility__("default")))  *tmp ;

  {
  tmp = _emalloc(sizeof(zend_trait_method_reference ));
  method_ref = (zend_trait_method_reference *)tmp;
  method_ref->ce = (zend_class_entry *)((void *)0);
  if (class_name) {
    zend_resolve_class_name(class_name, (ulong )4, 1);
    method_ref->class_name = (char const   *)class_name->u.constant.value.str.val;
    method_ref->cname_len = (unsigned int )class_name->u.constant.value.str.len;
  } else {
    method_ref->class_name = (char const   *)((void *)0);
    method_ref->cname_len = 0U;
  }
  method_ref->method_name = (char const   *)method_name->u.constant.value.str.val;
  method_ref->mname_len = (unsigned int )method_name->u.constant.value.str.len;
  result->u.op.ptr = (void *)method_ref;
  result->op_type = 1 << 1;
  return;
}
}
void zend_prepare_trait_alias(znode *result , znode *method_reference ,
                              znode *modifiers , znode *alias ) 
{ 
  zend_trait_alias *trait_alias ;
  void __attribute__((__visibility__("default")))  *tmp ;

  {
  tmp = _emalloc(sizeof(zend_trait_alias ));
  trait_alias = (zend_trait_alias *)tmp;
  trait_alias->trait_method = (zend_trait_method_reference *)method_reference->u.op.ptr;
  trait_alias->modifiers = (zend_uint )modifiers->u.constant.value.lval;
  if (modifiers->u.constant.value.lval == 1L) {
    zend_error(1 << 6L, "Cannot use \'static\' as method modifier");
    return;
  } else {

  }
  if (alias) {
    trait_alias->alias = (char const   *)alias->u.constant.value.str.val;
    trait_alias->alias_len = (unsigned int )alias->u.constant.value.str.len;
  } else {
    trait_alias->alias = (char const   *)((void *)0);
  }
  trait_alias->function = (union _zend_function *)((void *)0);
  result->u.op.ptr = (void *)trait_alias;
  return;
}
}
void zend_prepare_trait_precedence(znode *result , znode *method_reference ,
                                   znode *trait_list ) 
{ 
  zend_trait_precedence *trait_precedence ;
  void __attribute__((__visibility__("default")))  *tmp ;

  {
  tmp = _emalloc(sizeof(zend_trait_precedence ));
  trait_precedence = (zend_trait_precedence *)tmp;
  trait_precedence->trait_method = (zend_trait_method_reference *)method_reference->u.op.ptr;
  trait_precedence->exclude_from_classes = (zend_class_entry **)trait_list->u.op.ptr;
  trait_precedence->function = (union _zend_function *)((void *)0);
  result->u.op.ptr = (void *)trait_precedence;
  return;
}
}
zend_class_entry __attribute__((__visibility__("default")))  *do_bind_class(zend_op_array const   *op_array ,
                                                                            zend_op const   *opline ,
                                                                            HashTable *class_table ,
                                                                            zend_bool compile_time ) 
{ 
  zend_class_entry *ce ;
  zend_class_entry **pce ;
  zval *op1 ;
  zval *op2 ;
  int __attribute__((__visibility__("default")))  tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  if (compile_time) {
    op1 = & (op_array->literals + opline->op1.constant)->constant;
    op2 = & (op_array->literals + opline->op2.constant)->constant;
  } else {
    op1 = (zval *)opline->op1.zv;
    op2 = (zval *)opline->op2.zv;
  }
  tmp = zend_hash_quick_find((HashTable const   *)class_table,
                             (char const   *)op1->value.str.val,
                             (uint )op1->value.str.len,
                             ((zend_literal *)op1)->hash_value, (void **)(& pce));
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    zend_error(1 << 6L,
               "Internal Zend error - Missing class information for %s",
               op1->value.str.val);
    return ((zend_class_entry __attribute__((__visibility__("default")))  *)((void *)0));
  } else {
    ce = *pce;
  }
  (ce->refcount) ++;
  tmp___0 = _zend_hash_quick_add_or_update(class_table,
                                           (char const   *)op2->value.str.val,
                                           (uint )(op2->value.str.len + 1),
                                           ((zend_literal *)op2)->hash_value,
                                           (void *)(& ce),
                                           (uint )sizeof(zend_class_entry *),
                                           (void **)((void *)0), 1 << 1);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    (ce->refcount) --;
    if (! compile_time) {
      zend_error(1 << 6L, "Cannot redeclare class %s", ce->name);
    } else {

    }
    return ((zend_class_entry __attribute__((__visibility__("default")))  *)((void *)0));
  } else {
    if (! (ce->ce_flags & 524416U)) {
      zend_verify_abstract_class(ce);
    } else {

    }
    return ((zend_class_entry __attribute__((__visibility__("default")))  *)ce);
  }
}
}
zend_class_entry __attribute__((__visibility__("default")))  *do_bind_inherited_class(zend_op_array const   *op_array ,
                                                                                      zend_op const   *opline ,
                                                                                      HashTable *class_table ,
                                                                                      zend_class_entry *parent_ce ,
                                                                                      zend_bool compile_time ) 
{ 
  zend_class_entry *ce ;
  zend_class_entry **pce ;
  int found_ce ;
  zval *op1 ;
  zval *op2 ;
  int __attribute__((__visibility__("default")))  tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  if (compile_time) {
    op1 = & (op_array->literals + opline->op1.constant)->constant;
    op2 = & (op_array->literals + opline->op2.constant)->constant;
  } else {
    op1 = (zval *)opline->op1.zv;
    op2 = (zval *)opline->op2.zv;
  }
  tmp = zend_hash_quick_find((HashTable const   *)class_table,
                             (char const   *)op1->value.str.val,
                             (uint )op1->value.str.len,
                             ((zend_literal *)op1)->hash_value, (void **)(& pce));
  found_ce = (int )tmp;
  if (found_ce == -1) {
    if (! compile_time) {
      zend_error(1 << 6L, "Cannot redeclare class %s", op2->value.str.val);
    } else {

    }
    return ((zend_class_entry __attribute__((__visibility__("default")))  *)((void *)0));
  } else {
    ce = *pce;
  }
  if (parent_ce->ce_flags & 128U) {
    zend_error(1 << 6L, "Class %s cannot extend from interface %s", ce->name,
               parent_ce->name);
  } else
  if ((parent_ce->ce_flags & 288U) == 288U) {
    zend_error(1 << 6L, "Class %s cannot extend from trait %s", ce->name,
               parent_ce->name);
  } else {

  }
  zend_do_inheritance(ce, parent_ce);
  (ce->refcount) ++;
  tmp___0 = _zend_hash_quick_add_or_update(class_table,
                                           (char const   *)op2->value.str.val,
                                           (uint )(op2->value.str.len + 1),
                                           ((zend_literal *)op2)->hash_value,
                                           (void *)pce,
                                           (uint )sizeof(zend_class_entry *),
                                           (void **)((void *)0), 1 << 1);
  if (tmp___0 == (int __attribute__((__visibility__("default")))  )-1) {
    zend_error(1 << 6L, "Cannot redeclare class %s", ce->name);
  } else {

  }
  return ((zend_class_entry __attribute__((__visibility__("default")))  *)ce);
}
}
void zend_do_early_binding(void) 
{ 
  zend_op *opline ;
  HashTable *table ;
  int __attribute__((__visibility__("default")))  tmp ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp___0 ;
  zend_op *fetch_class_opline ;
  zval *parent_name ;
  zend_class_entry **pce ;
  zend_uint *opline_num ;
  int __attribute__((__visibility__("default")))  tmp___1 ;
  zend_class_entry __attribute__((__visibility__("default")))  *tmp___2 ;
  zend_uchar tmp___3 ;
  zend_uchar tmp___4 ;
  zend_uchar tmp___5 ;
  zend_uchar tmp___6 ;

  {
  opline = (compiler_globals.active_op_array)->opcodes + ((compiler_globals.active_op_array)->last - 1U);
  while (1) {
    if ((int )opline->opcode == 105) {
      if (! ((unsigned long )opline > (unsigned long )(compiler_globals.active_op_array)->opcodes)) {
        break;
      } else {

      }
    } else {
      break;
    }
    opline --;
  }
  switch ((int )opline->opcode) {
  case 141: 
  tmp = do_bind_function((zend_op_array const   *)compiler_globals.active_op_array,
                         opline, compiler_globals.function_table, (zend_bool )1);
  if (tmp == (int __attribute__((__visibility__("default")))  )-1) {
    return;
  } else {

  }
  table = compiler_globals.function_table;
  break;
  case 139: 
  tmp___0 = do_bind_class((zend_op_array const   *)compiler_globals.active_op_array,
                          (zend_op const   *)opline,
                          compiler_globals.class_table, (zend_bool )1);
  if ((unsigned long )tmp___0 == (unsigned long )((void *)0)) {
    return;
  } else {

  }
  table = compiler_globals.class_table;
  break;
  case 140: 
  fetch_class_opline = opline - 1;
  parent_name = & ((compiler_globals.active_op_array)->literals + fetch_class_opline->op2.constant)->constant;
  tmp___1 = zend_lookup_class((char const   *)parent_name->value.str.val,
                              parent_name->value.str.len, & pce);
  if (tmp___1 == (int __attribute__((__visibility__("default")))  )-1) {
    goto _L;
  } else
  if (compiler_globals.compiler_options & (unsigned int )(1 << 3)) {
    if ((int )(*pce)->type == 1) {
      _L: 
      if (compiler_globals.compiler_options & (unsigned int )(1 << 4)) {
        opline_num = & (compiler_globals.active_op_array)->early_binding;
        while (*opline_num != 4294967295U) {
          opline_num = & ((compiler_globals.active_op_array)->opcodes + *opline_num)->result.opline_num;
        }
        *opline_num = (zend_uint )(opline - (compiler_globals.active_op_array)->opcodes);
        opline->opcode = (zend_uchar )145;
        opline->result_type = (zend_uchar )(1 << 3);
        opline->result.opline_num = (zend_uint )-1;
      } else {

      }
      return;
    } else {

    }
  } else {

  }
  tmp___2 = do_bind_inherited_class((zend_op_array const   *)compiler_globals.active_op_array,
                                    (zend_op const   *)opline,
                                    compiler_globals.class_table, *pce,
                                    (zend_bool )1);
  if ((unsigned long )tmp___2 == (unsigned long )((void *)0)) {
    return;
  } else {

  }
  zend_del_literal(compiler_globals.active_op_array,
                   (int )fetch_class_opline->op2.constant);
  fetch_class_opline->opcode = (zend_uchar )0;
  memset((void *)(& fetch_class_opline->result), 0,
         sizeof(fetch_class_opline->result));
  memset((void *)(& fetch_class_opline->op1), 0, sizeof(fetch_class_opline->op1));
  memset((void *)(& fetch_class_opline->op2), 0, sizeof(fetch_class_opline->op2));
  tmp___4 = (zend_uchar )(1 << 3);
  fetch_class_opline->op2_type = tmp___4;
  tmp___3 = tmp___4;
  fetch_class_opline->op1_type = tmp___3;
  fetch_class_opline->result_type = tmp___3;
  table = compiler_globals.class_table;
  break;
  case 146: 
  case 144: 
  case 154: 
  case 155: 
  return;
  default: 
  zend_error(1 << 6L, "Invalid binding type");
  return;
  }
  zend_hash_del_key_or_index(table,
                             (char const   *)((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val,
                             (uint )((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.len,
                             ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant))->hash_value,
                             2);
  zend_del_literal(compiler_globals.active_op_array, (int )opline->op1.constant);
  zend_del_literal(compiler_globals.active_op_array, (int )opline->op2.constant);
  opline->opcode = (zend_uchar )0;
  memset((void *)(& opline->result), 0, sizeof(opline->result));
  memset((void *)(& opline->op1), 0, sizeof(opline->op1));
  memset((void *)(& opline->op2), 0, sizeof(opline->op2));
  tmp___6 = (zend_uchar )(1 << 3);
  opline->op2_type = tmp___6;
  tmp___5 = tmp___6;
  opline->op1_type = tmp___5;
  opline->result_type = tmp___5;
  return;
}
}
void __attribute__((__visibility__("default")))  zend_do_delayed_early_binding(zend_op_array const   *op_array ) 
{ 
  zend_bool orig_in_compilation ;
  zend_uint opline_num ;
  zend_class_entry **pce ;
  int __attribute__((__visibility__("default")))  tmp ;

  {
  if (op_array->early_binding != 4294967295U) {
    orig_in_compilation = compiler_globals.in_compilation;
    opline_num = (zend_uint )op_array->early_binding;
    compiler_globals.in_compilation = (zend_bool )1;
    while (opline_num != 4294967295U) {
      tmp = zend_lookup_class((char const   *)((op_array->opcodes + (opline_num - 1U))->op2.zv)->value.str.val,
                              ((op_array->opcodes + (opline_num - 1U))->op2.zv)->value.str.len,
                              & pce);
      if (tmp == (int __attribute__((__visibility__("default")))  )0) {
        do_bind_inherited_class(op_array,
                                (zend_op const   *)(op_array->opcodes + opline_num),
                                executor_globals.class_table, *pce,
                                (zend_bool )0);
      } else {

      }
      opline_num = (op_array->opcodes + opline_num)->result.opline_num;
    }
    compiler_globals.in_compilation = orig_in_compilation;
  } else {

  }
  return;
}
}
void zend_do_boolean_or_begin(znode *expr1 , znode *op_token ) 
{ 
  int next_op_number ;
  int tmp ;
  zend_op *opline ;
  zend_op *tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;

  {
  tmp = get_next_op_number(compiler_globals.active_op_array);
  next_op_number = tmp;
  tmp___0 = get_next_op(compiler_globals.active_op_array);
  opline = tmp___0;
  opline->opcode = (zend_uchar )47;
  if (expr1->op_type == 1 << 1) {
    while (1) {
      opline->result_type = (zend_uchar )expr1->op_type;
      if (expr1->op_type == 1) {
        tmp___1 = zend_add_literal(compiler_globals.active_op_array,
                                   (zval const   *)(& expr1->u.constant));
        opline->result.constant = (zend_uint )tmp___1;
      } else {
        opline->result = expr1->u.op;
      }
      break;
    }
  } else {
    opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
    opline->result_type = (zend_uchar )(1 << 1);
  }
  while (1) {
    opline->op1_type = (zend_uchar )expr1->op_type;
    if (expr1->op_type == 1) {
      tmp___2 = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& expr1->u.constant));
      opline->op1.constant = (zend_uint )tmp___2;
    } else {
      opline->op1 = expr1->u.op;
    }
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  op_token->u.op.opline_num = (zend_uint )next_op_number;
  while (1) {
    expr1->op_type = (int )opline->result_type;
    if (expr1->op_type == 1) {
      expr1->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      expr1->u.op = opline->result;
      expr1->EA = (zend_uint )0;
    }
    break;
  }
  return;
}
}
void zend_do_boolean_or_end(znode *result , znode const   *expr1 ,
                            znode const   *expr2 , znode *op_token ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  znode_op __constr_expr_31 ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  *result = (znode )*expr1;
  opline->opcode = (zend_uchar )52;
  while (1) {
    opline->result_type = (zend_uchar )result->op_type;
    if (result->op_type == 1) {
      tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& result->u.constant));
      opline->result.constant = (zend_uint )tmp___0;
    } else {
      opline->result = result->u.op;
    }
    break;
  }
  while (1) {
    opline->op1_type = (zend_uchar )expr2->op_type;
    if (expr2->op_type == 1) {
      tmp___1 = zend_add_literal(compiler_globals.active_op_array,
                                 & expr2->u.constant);
      opline->op1.constant = (zend_uint )tmp___1;
    } else {
      __constr_expr_31 = expr2->u.op;
      opline->op1 = __constr_expr_31;
    }
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  tmp___2 = get_next_op_number(compiler_globals.active_op_array);
  ((compiler_globals.active_op_array)->opcodes + op_token->u.op.opline_num)->op2.opline_num = (zend_uint )tmp___2;
  return;
}
}
void zend_do_boolean_and_begin(znode *expr1 , znode *op_token ) 
{ 
  int next_op_number ;
  int tmp ;
  zend_op *opline ;
  zend_op *tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;

  {
  tmp = get_next_op_number(compiler_globals.active_op_array);
  next_op_number = tmp;
  tmp___0 = get_next_op(compiler_globals.active_op_array);
  opline = tmp___0;
  opline->opcode = (zend_uchar )46;
  if (expr1->op_type == 1 << 1) {
    while (1) {
      opline->result_type = (zend_uchar )expr1->op_type;
      if (expr1->op_type == 1) {
        tmp___1 = zend_add_literal(compiler_globals.active_op_array,
                                   (zval const   *)(& expr1->u.constant));
        opline->result.constant = (zend_uint )tmp___1;
      } else {
        opline->result = expr1->u.op;
      }
      break;
    }
  } else {
    opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
    opline->result_type = (zend_uchar )(1 << 1);
  }
  while (1) {
    opline->op1_type = (zend_uchar )expr1->op_type;
    if (expr1->op_type == 1) {
      tmp___2 = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& expr1->u.constant));
      opline->op1.constant = (zend_uint )tmp___2;
    } else {
      opline->op1 = expr1->u.op;
    }
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  op_token->u.op.opline_num = (zend_uint )next_op_number;
  while (1) {
    expr1->op_type = (int )opline->result_type;
    if (expr1->op_type == 1) {
      expr1->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      expr1->u.op = opline->result;
      expr1->EA = (zend_uint )0;
    }
    break;
  }
  return;
}
}
void zend_do_boolean_and_end(znode *result , znode const   *expr1 ,
                             znode const   *expr2 , znode const   *op_token ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  znode_op __constr_expr_32 ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  *result = (znode )*expr1;
  opline->opcode = (zend_uchar )52;
  while (1) {
    opline->result_type = (zend_uchar )result->op_type;
    if (result->op_type == 1) {
      tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& result->u.constant));
      opline->result.constant = (zend_uint )tmp___0;
    } else {
      opline->result = result->u.op;
    }
    break;
  }
  while (1) {
    opline->op1_type = (zend_uchar )expr2->op_type;
    if (expr2->op_type == 1) {
      tmp___1 = zend_add_literal(compiler_globals.active_op_array,
                                 & expr2->u.constant);
      opline->op1.constant = (zend_uint )tmp___1;
    } else {
      __constr_expr_32 = expr2->u.op;
      opline->op1 = __constr_expr_32;
    }
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  tmp___2 = get_next_op_number(compiler_globals.active_op_array);
  ((compiler_globals.active_op_array)->opcodes + op_token->u.op.opline_num)->op2.opline_num = (zend_uint )tmp___2;
  return;
}
}
void zend_do_do_while_begin(void) 
{ 


  {
  do_begin_loop();
  if ((compiler_globals.active_op_array)->fn_flags & 16U) {
    (compiler_globals.context.backpatch_count) ++;
  } else {

  }
  return;
}
}
void zend_do_do_while_end(znode const   *do_token ,
                          znode const   *expr_open_bracket ,
                          znode const   *expr ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;
  znode_op __constr_expr_33 ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  opline->opcode = (zend_uchar )44;
  while (1) {
    opline->op1_type = (zend_uchar )expr->op_type;
    if (expr->op_type == 1) {
      tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                 & expr->u.constant);
      opline->op1.constant = (zend_uint )tmp___0;
    } else {
      __constr_expr_33 = expr->u.op;
      opline->op1 = __constr_expr_33;
    }
    break;
  }
  opline->op2.opline_num = (zend_uint )do_token->u.op.opline_num;
  opline->op2_type = (zend_uchar )(1 << 3);
  do_end_loop((int )expr_open_bracket->u.op.opline_num, 0);
  if ((compiler_globals.active_op_array)->fn_flags & 16U) {
    (compiler_globals.context.backpatch_count) --;
  } else {

  }
  return;
}
}
void zend_do_brk_cont(zend_uchar op , znode const   *expr ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  char const   *tmp___0 ;
  char const   *tmp___1 ;
  int tmp___2 ;
  zval _c ;
  zval *__z ;
  int tmp___3 ;
  znode_op __constr_expr_34 ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  opline->opcode = op;
  opline->op1.opline_num = (zend_uint )compiler_globals.context.current_brk_cont;
  opline->op1_type = (zend_uchar )(1 << 3);
  if (expr) {
    if (expr->op_type != 1) {
      if ((int )op == 50) {
        tmp___0 = "break";
      } else {
        tmp___0 = "continue";
      }
      zend_error(1 << 6L,
                 "\'%s\' operator with non-constant operand is no longer supported",
                 tmp___0);
    } else
    if ((int const   )expr->u.constant.type != 1) {
      goto _L;
    } else
    if (expr->u.constant.value.lval < 1L) {
      _L: 
      if ((int )op == 50) {
        tmp___1 = "break";
      } else {
        tmp___1 = "continue";
      }
      zend_error(1 << 6L, "\'%s\' operator accepts only positive numbers",
                 tmp___1);
    } else {

    }
    while (1) {
      opline->op2_type = (zend_uchar )expr->op_type;
      if (expr->op_type == 1) {
        tmp___2 = zend_add_literal(compiler_globals.active_op_array,
                                   & expr->u.constant);
        opline->op2.constant = (zend_uint )tmp___2;
      } else {
        __constr_expr_34 = expr->u.op;
        opline->op2 = __constr_expr_34;
      }
      break;
    }
  } else {
    while (1) {
      __z = & _c;
      __z->value.lval = 1L;
      __z->type = (zend_uchar )1;
      tmp___3 = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& _c));
      opline->op2.constant = (zend_uint )tmp___3;
      break;
    }
    opline->op2_type = (zend_uchar )1;
  }
  return;
}
}
void zend_do_switch_cond(znode const   *cond ) 
{ 
  zend_switch_entry switch_entry ;

  {
  switch_entry.cond = (znode )*cond;
  switch_entry.default_case = -1;
  switch_entry.control_var = -1;
  zend_stack_push(& compiler_globals.switch_cond_stack,
                  (void const   *)((void *)(& switch_entry)),
                  (int )sizeof(switch_entry));
  do_begin_loop();
  if ((compiler_globals.active_op_array)->fn_flags & 16U) {
    (compiler_globals.context.backpatch_count) ++;
  } else {

  }
  return;
}
}
void zend_do_switch_end(znode const   *case_list ) 
{ 
  zend_op *opline ;
  zend_switch_entry *switch_entry_ptr ;
  int next_op_number ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;

  {
  zend_stack_top((zend_stack const   *)(& compiler_globals.switch_cond_stack),
                 (void **)(& switch_entry_ptr));
  if (switch_entry_ptr->default_case != -1) {
    opline = get_next_op(compiler_globals.active_op_array);
    opline->opcode = (zend_uchar )42;
    opline->op1_type = (zend_uchar )(1 << 3);
    opline->op2_type = (zend_uchar )(1 << 3);
    opline->op1.opline_num = (zend_uint )switch_entry_ptr->default_case;
  } else {

  }
  if (case_list->op_type != (int const   )(1 << 3)) {
    tmp = get_next_op_number(compiler_globals.active_op_array);
    next_op_number = tmp;
    ((compiler_globals.active_op_array)->opcodes + case_list->u.op.opline_num)->op1.opline_num = (zend_uint )next_op_number;
  } else {

  }
  tmp___0 = get_next_op_number(compiler_globals.active_op_array);
  ((compiler_globals.active_op_array)->brk_cont_array + compiler_globals.context.current_brk_cont)->brk = tmp___0;
  ((compiler_globals.active_op_array)->brk_cont_array + compiler_globals.context.current_brk_cont)->cont = tmp___0;
  compiler_globals.context.current_brk_cont = ((compiler_globals.active_op_array)->brk_cont_array + compiler_globals.context.current_brk_cont)->parent;
  if (switch_entry_ptr->cond.op_type == 1 << 2) {
    goto _L;
  } else
  if (switch_entry_ptr->cond.op_type == 1 << 1) {
    _L: 
    opline = get_next_op(compiler_globals.active_op_array);
    if (switch_entry_ptr->cond.op_type == 1 << 1) {
      opline->opcode = (zend_uchar )70;
    } else {
      opline->opcode = (zend_uchar )49;
    }
    while (1) {
      opline->op1_type = (zend_uchar )switch_entry_ptr->cond.op_type;
      if (switch_entry_ptr->cond.op_type == 1) {
        tmp___1 = zend_add_literal(compiler_globals.active_op_array,
                                   (zval const   *)(& switch_entry_ptr->cond.u.constant));
        opline->op1.constant = (zend_uint )tmp___1;
      } else {
        opline->op1 = switch_entry_ptr->cond.u.op;
      }
      break;
    }
    opline->op2_type = (zend_uchar )(1 << 3);
  } else {

  }
  if (switch_entry_ptr->cond.op_type == 1) {
    _zval_dtor(& switch_entry_ptr->cond.u.constant);
  } else {

  }
  zend_stack_del_top(& compiler_globals.switch_cond_stack);
  if ((compiler_globals.active_op_array)->fn_flags & 16U) {
    (compiler_globals.context.backpatch_count) --;
  } else {

  }
  return;
}
}
void zend_do_case_before_statement(znode const   *case_list ,
                                   znode *case_token , znode const   *case_expr ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  int next_op_number ;
  zend_switch_entry *switch_entry_ptr ;
  znode result ;
  zend_uint tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  znode_op __constr_expr_35 ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  zend_stack_top((zend_stack const   *)(& compiler_globals.switch_cond_stack),
                 (void **)(& switch_entry_ptr));
  if (switch_entry_ptr->control_var == -1) {
    tmp___0 = get_temporary_variable(compiler_globals.active_op_array);
    switch_entry_ptr->control_var = (int )tmp___0;
  } else {

  }
  opline->opcode = (zend_uchar )48;
  opline->result.var = (zend_uint )switch_entry_ptr->control_var;
  opline->result_type = (zend_uchar )(1 << 1);
  while (1) {
    opline->op1_type = (zend_uchar )switch_entry_ptr->cond.op_type;
    if (switch_entry_ptr->cond.op_type == 1) {
      tmp___1 = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& switch_entry_ptr->cond.u.constant));
      opline->op1.constant = (zend_uint )tmp___1;
    } else {
      opline->op1 = switch_entry_ptr->cond.u.op;
    }
    break;
  }
  while (1) {
    opline->op2_type = (zend_uchar )case_expr->op_type;
    if (case_expr->op_type == 1) {
      tmp___2 = zend_add_literal(compiler_globals.active_op_array,
                                 & case_expr->u.constant);
      opline->op2.constant = (zend_uint )tmp___2;
    } else {
      __constr_expr_35 = case_expr->u.op;
      opline->op2 = __constr_expr_35;
    }
    break;
  }
  if ((int )opline->op1_type == 1) {
    _zval_copy_ctor(& ((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant);
  } else {

  }
  while (1) {
    result.op_type = (int )opline->result_type;
    if (result.op_type == 1) {
      result.u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      result.u.op = opline->result;
      result.EA = (zend_uint )0;
    }
    break;
  }
  next_op_number = get_next_op_number(compiler_globals.active_op_array);
  opline = get_next_op(compiler_globals.active_op_array);
  opline->opcode = (zend_uchar )43;
  while (1) {
    opline->op1_type = (zend_uchar )result.op_type;
    if (result.op_type == 1) {
      tmp___3 = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& result.u.constant));
      opline->op1.constant = (zend_uint )tmp___3;
    } else {
      opline->op1 = result.u.op;
    }
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  case_token->u.op.opline_num = (zend_uint )next_op_number;
  if (case_list->op_type == (int const   )(1 << 3)) {
    return;
  } else {

  }
  next_op_number = get_next_op_number(compiler_globals.active_op_array);
  ((compiler_globals.active_op_array)->opcodes + case_list->u.op.opline_num)->op1.opline_num = (zend_uint )next_op_number;
  return;
}
}
void zend_do_case_after_statement(znode *result , znode const   *case_token ) 
{ 
  int next_op_number ;
  int tmp ;
  zend_op *opline ;
  zend_op *tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;

  {
  tmp = get_next_op_number(compiler_globals.active_op_array);
  next_op_number = tmp;
  tmp___0 = get_next_op(compiler_globals.active_op_array);
  opline = tmp___0;
  opline->opcode = (zend_uchar )42;
  opline->op1_type = (zend_uchar )(1 << 3);
  opline->op2_type = (zend_uchar )(1 << 3);
  result->u.op.opline_num = (zend_uint )next_op_number;
  switch ((int )((compiler_globals.active_op_array)->opcodes + case_token->u.op.opline_num)->opcode) {
  case 42: 
  tmp___1 = get_next_op_number(compiler_globals.active_op_array);
  ((compiler_globals.active_op_array)->opcodes + case_token->u.op.opline_num)->op1.opline_num = (zend_uint )tmp___1;
  break;
  case 43: 
  tmp___2 = get_next_op_number(compiler_globals.active_op_array);
  ((compiler_globals.active_op_array)->opcodes + case_token->u.op.opline_num)->op2.opline_num = (zend_uint )tmp___2;
  break;
  }
  return;
}
}
void zend_do_default_before_statement(znode const   *case_list ,
                                      znode *default_token ) 
{ 
  int next_op_number ;
  int tmp ;
  zend_op *opline ;
  zend_op *tmp___0 ;
  zend_switch_entry *switch_entry_ptr ;

  {
  tmp = get_next_op_number(compiler_globals.active_op_array);
  next_op_number = tmp;
  tmp___0 = get_next_op(compiler_globals.active_op_array);
  opline = tmp___0;
  zend_stack_top((zend_stack const   *)(& compiler_globals.switch_cond_stack),
                 (void **)(& switch_entry_ptr));
  opline->opcode = (zend_uchar )42;
  opline->op1_type = (zend_uchar )(1 << 3);
  opline->op2_type = (zend_uchar )(1 << 3);
  default_token->u.op.opline_num = (zend_uint )next_op_number;
  next_op_number = get_next_op_number(compiler_globals.active_op_array);
  switch_entry_ptr->default_case = next_op_number;
  if (case_list->op_type == (int const   )(1 << 3)) {
    return;
  } else {

  }
  ((compiler_globals.active_op_array)->opcodes + case_list->u.op.opline_num)->op1.opline_num = (zend_uint )next_op_number;
  return;
}
}
void zend_do_begin_class_declaration(znode const   *class_token ,
                                     znode *class_name ,
                                     znode const   *parent_class_name ) 
{ 
  zend_op *opline ;
  int doing_inheritance ;
  zend_class_entry *new_class_entry ;
  char *lcname ;
  int error ;
  zval **ns_name ;
  zval key ;
  char __attribute__((__visibility__("default")))  *tmp ;
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp___1 ;
  int tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;
  size_t __s1_len___0 ;
  size_t __s2_len___0 ;
  int tmp___8 ;
  int tmp___11 ;
  int tmp___12 ;
  int tmp___13 ;
  int __attribute__((__visibility__("default")))  tmp___14 ;
  znode tmp___15 ;
  char __attribute__((__visibility__("default")))  *tmp___16 ;
  char *tmp___17 ;
  char __attribute__((__visibility__("default")))  *tmp___18 ;
  int tmp___19 ;
  void __attribute__((__visibility__("default")))  *tmp___20 ;
  char const __attribute__((__visibility__("default")))  *tmp___21 ;
  char __attribute__((__visibility__("default")))  *tmp___22 ;
  int tmp___23 ;
  ulong __attribute__((__visibility__("default")))  tmp___24 ;
  zval _c ;
  char const   *__s ;
  int __l ;
  zval *__z ;
  int tmp___26 ;
  ulong __attribute__((__visibility__("default")))  tmp___27 ;

  {
  doing_inheritance = 0;
  error = 0;
  if (compiler_globals.active_class_entry) {
    zend_error(1 << 6L, "Class declarations may not be nested");
    return;
  } else {

  }
  tmp = zend_str_tolower_dup((char const   *)class_name->u.constant.value.str.val,
                             (unsigned int )class_name->u.constant.value.str.len);
  lcname = (char *)tmp;
  if (0) {
    __s1_len = __builtin_strlen((char const   *)lcname);
    __s2_len = __builtin_strlen("self");
    if (! ((size_t )((void const   *)(lcname + 1)) - (size_t )((void const   *)lcname) == 1UL)) {
      goto _L___0;
    } else
    if (__s1_len >= 4UL) {
      _L___0: 
      if (! ((size_t )((void const   *)("self" + 1)) - (size_t )((void const   *)"self") == 1UL)) {
        tmp___6 = 1;
      } else
      if (__s2_len >= 4UL) {
        tmp___6 = 1;
      } else {
        tmp___6 = 0;
      }
    } else {
      tmp___6 = 0;
    }
    if (tmp___6) {
      tmp___1 = __builtin_strcmp((char const   *)lcname, "self");
      tmp___5 = tmp___1;
    } else {
      tmp___4 = __builtin_strcmp((char const   *)lcname, "self");
      tmp___5 = tmp___4;
    }
  } else {
    tmp___4 = __builtin_strcmp((char const   *)lcname, "self");
    tmp___5 = tmp___4;
  }
  if (tmp___5) {
    if (0) {
      __s1_len___0 = __builtin_strlen((char const   *)lcname);
      __s2_len___0 = __builtin_strlen("parent");
      if (! ((size_t )((void const   *)(lcname + 1)) - (size_t )((void const   *)lcname) == 1UL)) {
        goto _L___2;
      } else
      if (__s1_len___0 >= 4UL) {
        _L___2: 
        if (! ((size_t )((void const   *)("parent" + 1)) - (size_t )((void const   *)"parent") == 1UL)) {
          tmp___13 = 1;
        } else
        if (__s2_len___0 >= 4UL) {
          tmp___13 = 1;
        } else {
          tmp___13 = 0;
        }
      } else {
        tmp___13 = 0;
      }
      if (tmp___13) {
        tmp___8 = __builtin_strcmp((char const   *)lcname, "parent");
        tmp___12 = tmp___8;
      } else {
        tmp___11 = __builtin_strcmp((char const   *)lcname, "parent");
        tmp___12 = tmp___11;
      }
    } else {
      tmp___11 = __builtin_strcmp((char const   *)lcname, "parent");
      tmp___12 = tmp___11;
    }
    if (! tmp___12) {
      _efree((void *)lcname);
      zend_error(1 << 6L, "Cannot use \'%s\' as class name as it is reserved",
                 class_name->u.constant.value.str.val);
    } else {

    }
  } else {
    _efree((void *)lcname);
    zend_error(1 << 6L, "Cannot use \'%s\' as class name as it is reserved",
               class_name->u.constant.value.str.val);
  }
  if (compiler_globals.current_import) {
    tmp___14 = zend_hash_find((HashTable const   *)compiler_globals.current_import,
                              (char const   *)lcname,
                              (uint )(class_name->u.constant.value.str.len + 1),
                              (void **)(& ns_name));
    if (tmp___14 == (int __attribute__((__visibility__("default")))  )0) {
      error = 1;
    } else {

    }
  } else {

  }
  if (compiler_globals.current_namespace) {
    tmp___15.u.constant = *(compiler_globals.current_namespace);
    _zval_copy_ctor(& tmp___15.u.constant);
    zend_do_build_namespace_name(& tmp___15, & tmp___15, class_name);
    class_name = & tmp___15;
    _efree((void *)lcname);
    tmp___16 = zend_str_tolower_dup((char const   *)class_name->u.constant.value.str.val,
                                    (unsigned int )class_name->u.constant.value.str.len);
    lcname = (char *)tmp___16;
  } else {

  }
  if (error) {
    tmp___18 = zend_str_tolower_dup((char const   *)(*ns_name)->value.str.val,
                                    (unsigned int )(*ns_name)->value.str.len);
    tmp___17 = (char *)tmp___18;
    if ((*ns_name)->value.str.len != class_name->u.constant.value.str.len) {
      zend_error(1 << 6L,
                 "Cannot declare class %s because the name is already in use",
                 class_name->u.constant.value.str.val);
    } else {
      tmp___19 = memcmp((void const   *)tmp___17, (void const   *)lcname,
                        (size_t )class_name->u.constant.value.str.len);
      if (tmp___19) {
        zend_error(1 << 6L,
                   "Cannot declare class %s because the name is already in use",
                   class_name->u.constant.value.str.val);
      } else {

      }
    }
    _efree((void *)tmp___17);
  } else {

  }
  tmp___20 = _emalloc(sizeof(zend_class_entry ));
  new_class_entry = (zend_class_entry *)tmp___20;
  new_class_entry->type = (char)2;
  tmp___21 = (*zend_new_interned_string)((char const   *)class_name->u.constant.value.str.val,
                                         class_name->u.constant.value.str.len + 1,
                                         1);
  new_class_entry->name = (char const   *)tmp___21;
  new_class_entry->name_length = (zend_uint )class_name->u.constant.value.str.len;
  zend_initialize_class_data(new_class_entry, (zend_bool )1);
  tmp___22 = zend_get_compiled_filename();
  new_class_entry->info.user.filename = (char const   *)tmp___22;
  new_class_entry->info.user.line_start = (zend_uint )class_token->u.op.opline_num;
  new_class_entry->ce_flags |= (unsigned int )class_token->EA;
  if (parent_class_name) {
    if (parent_class_name->op_type != (int const   )(1 << 3)) {
      switch (parent_class_name->EA) {
      case 1U: 
      zend_error(1 << 6L, "Cannot use \'self\' as class name as it is reserved");
      break;
      case 2U: 
      zend_error(1 << 6L,
                 "Cannot use \'parent\' as class name as it is reserved");
      break;
      case 7U: 
      zend_error(1 << 6L,
                 "Cannot use \'static\' as class name as it is reserved");
      break;
      default: 
      break;
      }
      doing_inheritance = 1;
    } else {

    }
  } else {

  }
  opline = get_next_op(compiler_globals.active_op_array);
  opline->op1_type = (zend_uchar )1;
  build_runtime_defined_function_key(& key, (char const   *)lcname,
                                     (int )new_class_entry->name_length);
  tmp___23 = zend_add_literal(compiler_globals.active_op_array,
                              (zval const   *)(& key));
  opline->op1.constant = (zend_uint )tmp___23;
  tmp___24 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val,
                            (uint )((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.len);
  ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant))->hash_value = (zend_ulong )tmp___24;
  opline->op2_type = (zend_uchar )1;
  if (doing_inheritance) {
    if ((new_class_entry->ce_flags & 288U) == 288U) {
      zend_error(1 << 6L, "A trait (%s) cannot extend a class",
                 new_class_entry->name);
    } else {

    }
    opline->extended_value = (ulong )parent_class_name->u.op.var;
    opline->opcode = (zend_uchar )140;
  } else {
    opline->opcode = (zend_uchar )139;
  }
  while (1) {
    while (1) {
      __s = (char const   *)lcname;
      __l = (int )new_class_entry->name_length;
      __z = & _c;
      __z->value.str.len = __l;
      __z->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
      __z->type = (zend_uchar )6;
      break;
    }
    tmp___26 = zend_add_literal(compiler_globals.active_op_array,
                                (zval const   *)(& _c));
    opline->op2.constant = (zend_uint )tmp___26;
    break;
  }
  while (1) {
    if ((unsigned long )((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
      if ((unsigned long )((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end) {
        ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant))->hash_value = ((Bucket *)(((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val - sizeof(Bucket )))->h;
      } else {
        tmp___27 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val,
                                  (uint )(((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.len + 1));
        ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant))->hash_value = (zend_ulong )tmp___27;
      }
    } else {
      tmp___27 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val,
                                (uint )(((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.len + 1));
      ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant))->hash_value = (zend_ulong )tmp___27;
    }
    break;
  }
  _zend_hash_quick_add_or_update(compiler_globals.class_table,
                                 (char const   *)key.value.str.val,
                                 (uint )key.value.str.len,
                                 ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant))->hash_value,
                                 (void *)(& new_class_entry),
                                 (uint )sizeof(zend_class_entry *),
                                 (void **)((void *)0), 1);
  compiler_globals.active_class_entry = new_class_entry;
  opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  opline->result_type = (zend_uchar )(1 << 2);
  while (1) {
    compiler_globals.implementing_class.op_type = (int )opline->result_type;
    if (compiler_globals.implementing_class.op_type == 1) {
      compiler_globals.implementing_class.u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      compiler_globals.implementing_class.u.op = opline->result;
      compiler_globals.implementing_class.EA = (zend_uint )0;
    }
    break;
  }
  if (compiler_globals.doc_comment) {
    (compiler_globals.active_class_entry)->info.user.doc_comment = (char const   *)compiler_globals.doc_comment;
    (compiler_globals.active_class_entry)->info.user.doc_comment_len = compiler_globals.doc_comment_len;
    compiler_globals.doc_comment = (char *)((void *)0);
    compiler_globals.doc_comment_len = (zend_uint )0;
  } else {

  }
  return;
}
}
static void do_verify_abstract_class(void) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  opline->opcode = (zend_uchar )146;
  while (1) {
    opline->op1_type = (zend_uchar )compiler_globals.implementing_class.op_type;
    if (compiler_globals.implementing_class.op_type == 1) {
      tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& compiler_globals.implementing_class.u.constant));
      opline->op1.constant = (zend_uint )tmp___0;
    } else {
      opline->op1 = compiler_globals.implementing_class.u.op;
    }
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  return;
}
}
void zend_do_end_class_declaration(znode const   *class_token ,
                                   znode const   *parent_token ) 
{ 
  zend_class_entry *ce ;
  int __attribute__((__visibility__("default")))  tmp ;
  zend_op *opline ;
  int tmp___0 ;

  {
  ce = compiler_globals.active_class_entry;
  if (ce->constructor) {
    (ce->constructor)->common.fn_flags |= 8192U;
    if ((ce->constructor)->common.fn_flags & 1U) {
      zend_error(1 << 6L, "Constructor %s::%s() cannot be static", ce->name,
                 (ce->constructor)->common.function_name);
    } else {

    }
  } else {

  }
  if (ce->destructor) {
    (ce->destructor)->common.fn_flags |= 16384U;
    if ((ce->destructor)->common.fn_flags & 1U) {
      zend_error(1 << 6L, "Destructor %s::%s() cannot be static", ce->name,
                 (ce->destructor)->common.function_name);
    } else {

    }
  } else {

  }
  if (ce->clone) {
    (ce->clone)->common.fn_flags |= 32768U;
    if ((ce->clone)->common.fn_flags & 1U) {
      zend_error(1 << 6L, "Clone method %s::%s() cannot be static", ce->name,
                 (ce->clone)->common.function_name);
    } else {

    }
  } else {

  }
  tmp = zend_get_compiled_lineno();
  ce->info.user.line_end = (zend_uint )tmp;
  if (ce->num_traits > 0U) {
    ce->traits = (zend_class_entry **)((void *)0);
    ce->num_traits = (zend_uint )0;
    ce->ce_flags |= 4194304U;
    opline = get_next_op(compiler_globals.active_op_array);
    opline->opcode = (zend_uchar )155;
    while (1) {
      opline->op1_type = (zend_uchar )compiler_globals.implementing_class.op_type;
      if (compiler_globals.implementing_class.op_type == 1) {
        tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                   (zval const   *)(& compiler_globals.implementing_class.u.constant));
        opline->op1.constant = (zend_uint )tmp___0;
      } else {
        opline->op1 = compiler_globals.implementing_class.u.op;
      }
      break;
    }
  } else {

  }
  if (! (ce->ce_flags & 160U)) {
    if (parent_token->op_type != (int const   )(1 << 3)) {
      goto _L;
    } else
    if (ce->num_interfaces > 0U) {
      _L: 
      zend_verify_abstract_class(ce);
      if (ce->num_interfaces) {
        do_verify_abstract_class();
      } else {

      }
    } else {

    }
  } else {

  }
  if (ce->num_interfaces > 0U) {
    ce->interfaces = (zend_class_entry **)((void *)0);
    ce->num_interfaces = (zend_uint )0;
    ce->ce_flags |= 524288U;
  } else {

  }
  compiler_globals.active_class_entry = (zend_class_entry *)((void *)0);
  return;
}
}
void zend_do_implements_interface(znode *interface_name ) 
{ 
  zend_op *opline ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;

  {
  if (((compiler_globals.active_class_entry)->ce_flags & 288U) == 288U) {
    zend_error(1 << 6L,
               "Cannot use \'%s\' as interface on \'%s\' since it is a Trait",
               interface_name->u.constant.value.str.val,
               (compiler_globals.active_class_entry)->name);
  } else {

  }
  tmp = zend_get_class_fetch_type((char const   *)interface_name->u.constant.value.str.val,
                                  (uint )interface_name->u.constant.value.str.len);
  switch (tmp) {
  case 1: 
  case 2: 
  case 7: 
  zend_error(1 << 6L, "Cannot use \'%s\' as interface name as it is reserved",
             interface_name->u.constant.value.str.val);
  break;
  default: 
  break;
  }
  opline = get_next_op(compiler_globals.active_op_array);
  opline->opcode = (zend_uchar )144;
  while (1) {
    opline->op1_type = (zend_uchar )compiler_globals.implementing_class.op_type;
    if (compiler_globals.implementing_class.op_type == 1) {
      tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& compiler_globals.implementing_class.u.constant));
      opline->op1.constant = (zend_uint )tmp___0;
    } else {
      opline->op1 = compiler_globals.implementing_class.u.op;
    }
    break;
  }
  zend_resolve_class_name(interface_name, opline->extended_value, 0);
  opline->extended_value = (opline->extended_value & 0xfffffffffffffff0UL) | 6UL;
  opline->op2_type = (zend_uchar )1;
  tmp___1 = zend_add_class_name_literal(compiler_globals.active_op_array,
                                        (zval const   *)(& interface_name->u.constant));
  opline->op2.constant = (zend_uint )tmp___1;
  ((compiler_globals.active_class_entry)->num_interfaces) ++;
  return;
}
}
void zend_do_implements_trait(znode *trait_name ) 
{ 
  zend_op *opline ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;

  {
  if ((compiler_globals.active_class_entry)->ce_flags & 128U) {
    zend_error(1 << 6L,
               "Cannot use traits inside of interfaces. %s is used in %s",
               trait_name->u.constant.value.str.val,
               (compiler_globals.active_class_entry)->name);
  } else {

  }
  tmp = zend_get_class_fetch_type((char const   *)trait_name->u.constant.value.str.val,
                                  (uint )trait_name->u.constant.value.str.len);
  switch (tmp) {
  case 1: 
  case 2: 
  case 7: 
  zend_error(1 << 6L, "Cannot use \'%s\' as trait name as it is reserved",
             trait_name->u.constant.value.str.val);
  break;
  default: 
  break;
  }
  opline = get_next_op(compiler_globals.active_op_array);
  opline->opcode = (zend_uchar )154;
  while (1) {
    opline->op1_type = (zend_uchar )compiler_globals.implementing_class.op_type;
    if (compiler_globals.implementing_class.op_type == 1) {
      tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& compiler_globals.implementing_class.u.constant));
      opline->op1.constant = (zend_uint )tmp___0;
    } else {
      opline->op1 = compiler_globals.implementing_class.u.op;
    }
    break;
  }
  zend_resolve_class_name(trait_name, opline->extended_value, 0);
  opline->extended_value = (ulong )14;
  opline->op2_type = (zend_uchar )1;
  tmp___1 = zend_add_class_name_literal(compiler_globals.active_op_array,
                                        (zval const   *)(& trait_name->u.constant));
  opline->op2.constant = (zend_uint )tmp___1;
  ((compiler_globals.active_class_entry)->num_traits) ++;
  return;
}
}
void __attribute__((__visibility__("default")))  zend_mangle_property_name(char **dest ,
                                                                           int *dest_length ,
                                                                           char const   *src1 ,
                                                                           int src1_length ,
                                                                           char const   *src2 ,
                                                                           int src2_length ,
                                                                           int internal ) 
{ 
  char *prop_name ;
  int prop_name_length ;
  void *tmp ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;

  {
  prop_name_length = ((1 + src1_length) + 1) + src2_length;
  if (internal) {
    tmp = __zend_malloc((size_t )(prop_name_length + 1));
    prop_name = (char *)tmp;
  } else {
    tmp___0 = _emalloc((size_t )(prop_name_length + 1));
    prop_name = (char *)tmp___0;
  }
  *(prop_name + 0) = (char )'\000';
  memcpy((void */* __restrict  */)(prop_name + 1),
         (void const   */* __restrict  */)src1, (size_t )(src1_length + 1));
  memcpy((void */* __restrict  */)(((prop_name + 1) + src1_length) + 1),
         (void const   */* __restrict  */)src2, (size_t )(src2_length + 1));
  *dest = prop_name;
  *dest_length = prop_name_length;
  return;
}
}
static int zend_strnlen(char const   *s , int maxlen ) 
{ 
  int len ;
  char const   *tmp ;
  int tmp___0 ;

  {
  len = 0;
  while (1) {
    tmp = s;
    s ++;
    if (*tmp) {
      tmp___0 = maxlen;
      maxlen --;
      if (! tmp___0) {
        break;
      } else {

      }
    } else {
      break;
    }
    len ++;
  }
  return (len);
}
}
int __attribute__((__visibility__("default")))  zend_unmangle_property_name(char const   *mangled_property ,
                                                                            int len ,
                                                                            char const   **class_name ,
                                                                            char const   **prop_name ) 
{ 
  int class_name_len ;
  int tmp ;

  {
  *class_name = (char const   *)((void *)0);
  if ((int const   )*(mangled_property + 0) != 0) {
    *prop_name = mangled_property;
    return ((int __attribute__((__visibility__("default")))  )0);
  } else {

  }
  if (len < 3) {
    zend_error(1 << 3L, "Illegal member variable name");
    *prop_name = mangled_property;
    return ((int __attribute__((__visibility__("default")))  )-1);
  } else
  if ((int const   )*(mangled_property + 1) == 0) {
    zend_error(1 << 3L, "Illegal member variable name");
    *prop_name = mangled_property;
    return ((int __attribute__((__visibility__("default")))  )-1);
  } else {

  }
  len --;
  tmp = zend_strnlen(mangled_property + 1, len - 1);
  class_name_len = tmp + 1;
  if (class_name_len >= len) {
    zend_error(1 << 3L, "Corrupt member variable name");
    *prop_name = mangled_property;
    return ((int __attribute__((__visibility__("default")))  )-1);
  } else
  if ((int const   )*(mangled_property + class_name_len) != 0) {
    zend_error(1 << 3L, "Corrupt member variable name");
    *prop_name = mangled_property;
    return ((int __attribute__((__visibility__("default")))  )-1);
  } else {

  }
  *class_name = mangled_property + 1;
  *prop_name = *class_name + class_name_len;
  return ((int __attribute__((__visibility__("default")))  )0);
}
}
void zend_do_declare_property(znode const   *var_name , znode const   *value ,
                              zend_uint access_type ) 
{ 
  zval *property ;
  zend_property_info *existing_property_info ;
  char *comment ;
  int comment_len ;
  int __attribute__((__visibility__("default")))  tmp ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  char const __attribute__((__visibility__("default")))  *tmp___1 ;

  {
  comment = (char *)((void *)0);
  comment_len = 0;
  if ((compiler_globals.active_class_entry)->ce_flags & 128U) {
    zend_error(1 << 6L, "Interfaces may not include member variables");
  } else {

  }
  if (access_type & 2U) {
    zend_error(1 << 6L, "Properties cannot be declared abstract");
  } else {

  }
  if (access_type & 4U) {
    zend_error(1 << 6L,
               "Cannot declare property %s::$%s final, the final modifier is allowed only for methods and classes",
               (compiler_globals.active_class_entry)->name,
               var_name->u.constant.value.str.val);
  } else {

  }
  tmp = zend_hash_find((HashTable const   *)(& (compiler_globals.active_class_entry)->properties_info),
                       (char const   *)var_name->u.constant.value.str.val,
                       (uint )(var_name->u.constant.value.str.len + 1),
                       (void **)(& existing_property_info));
  if (tmp == (int __attribute__((__visibility__("default")))  )0) {
    zend_error(1 << 6L, "Cannot redeclare %s::$%s",
               (compiler_globals.active_class_entry)->name,
               var_name->u.constant.value.str.val);
  } else {

  }
  while (1) {
    tmp___0 = _emalloc(sizeof(zval_gc_info ));
    property = (zval *)tmp___0;
    ((zval_gc_info *)property)->u.buffered = (gc_root_buffer *)((void *)0);
    break;
  }
  if (value) {
    *property = (zval )value->u.constant;
  } else {
    property->refcount__gc = (zend_uint )1;
    property->is_ref__gc = (zend_uchar )0;
    property->type = (zend_uchar )0;
  }
  if (compiler_globals.doc_comment) {
    comment = compiler_globals.doc_comment;
    comment_len = (int )compiler_globals.doc_comment_len;
    compiler_globals.doc_comment = (char *)((void *)0);
    compiler_globals.doc_comment_len = (zend_uint )0;
  } else {

  }
  tmp___1 = (*zend_new_interned_string)((char const   *)var_name->u.constant.value.str.val,
                                        (int )(var_name->u.constant.value.str.len + 1),
                                        0);
  zend_declare_property_ex(compiler_globals.active_class_entry,
                           (char const   *)tmp___1,
                           (int )var_name->u.constant.value.str.len, property,
                           (int )access_type, (char const   *)comment,
                           comment_len);
  _efree((void *)var_name->u.constant.value.str.val);
  return;
}
}
void zend_do_declare_class_constant(znode *var_name , znode const   *value ) 
{ 
  zval *property ;
  char const   *cname ;
  int result ;
  void __attribute__((__visibility__("default")))  *tmp ;
  char const __attribute__((__visibility__("default")))  *tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;
  int __attribute__((__visibility__("default")))  tmp___2 ;

  {
  cname = (char const   *)((void *)0);
  if ((int const   )value->u.constant.type == 9) {
    zend_error(1 << 6L, "Arrays are not allowed in class constants");
    return;
  } else {

  }
  if (((compiler_globals.active_class_entry)->ce_flags & 288U) == 288U) {
    zend_error(1 << 6L, "Traits cannot have constants");
    return;
  } else {

  }
  while (1) {
    tmp = _emalloc(sizeof(zval_gc_info ));
    property = (zval *)tmp;
    ((zval_gc_info *)property)->u.buffered = (gc_root_buffer *)((void *)0);
    break;
  }
  *property = (zval )value->u.constant;
  tmp___0 = (*zend_new_interned_string)((char const   *)var_name->u.constant.value.str.val,
                                        var_name->u.constant.value.str.len + 1,
                                        0);
  cname = (char const   *)tmp___0;
  if ((unsigned long )cname >= (unsigned long )compiler_globals.interned_strings_start) {
    if ((unsigned long )cname < (unsigned long )compiler_globals.interned_strings_end) {
      tmp___1 = _zend_hash_quick_add_or_update(& (compiler_globals.active_class_entry)->constants_table,
                                               cname,
                                               (uint )(var_name->u.constant.value.str.len + 1),
                                               ((Bucket *)((char *)cname - sizeof(Bucket )))->h,
                                               (void *)(& property),
                                               (uint )sizeof(zval *),
                                               (void **)((void *)0), 1 << 1);
      result = (int )tmp___1;
    } else {
      tmp___2 = _zend_hash_add_or_update(& (compiler_globals.active_class_entry)->constants_table,
                                         cname,
                                         (uint )(var_name->u.constant.value.str.len + 1),
                                         (void *)(& property),
                                         (uint )sizeof(zval *),
                                         (void **)((void *)0), 1 << 1);
      result = (int )tmp___2;
    }
  } else {
    tmp___2 = _zend_hash_add_or_update(& (compiler_globals.active_class_entry)->constants_table,
                                       cname,
                                       (uint )(var_name->u.constant.value.str.len + 1),
                                       (void *)(& property),
                                       (uint )sizeof(zval *),
                                       (void **)((void *)0), 1 << 1);
    result = (int )tmp___2;
  }
  if (result == -1) {
    while (1) {
      if ((gc_root_buffer *)((zend_uintptr_t )((zval_gc_info *)property)->u.buffered & 0xfffffffffffffffcUL)) {
        gc_remove_zval_from_buffer(property);
      } else {

      }
      _efree((void *)property);
      break;
    }
    zend_error(1 << 6L, "Cannot redefine class constant %s::%s",
               (compiler_globals.active_class_entry)->name,
               var_name->u.constant.value.str.val);
  } else {

  }
  _zval_dtor(& var_name->u.constant);
  if (compiler_globals.doc_comment) {
    _efree((void *)compiler_globals.doc_comment);
    compiler_globals.doc_comment = (char *)((void *)0);
    compiler_globals.doc_comment_len = (zend_uint )0;
  } else {

  }
  return;
}
}
void zend_do_fetch_property(znode *result , znode *object ,
                            znode const   *property ) 
{ 
  zend_op opline ;
  zend_llist *fetch_list_ptr ;
  zend_llist_element *le ;
  zend_op *opline_ptr ;
  int tmp ;
  ulong __attribute__((__visibility__("default")))  tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  zend_bool tmp___2 ;
  int tmp___3 ;
  zend_bool tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;
  ulong __attribute__((__visibility__("default")))  tmp___7 ;
  void __attribute__((__visibility__("default")))  *tmp___8 ;
  znode_op __constr_expr_36 ;
  znode_op __constr_expr_37 ;

  {
  zend_stack_top((zend_stack const   *)(& compiler_globals.bp_stack),
                 (void **)(& fetch_list_ptr));
  if (object->op_type == 1 << 4) {
    if (object->u.op.var == (compiler_globals.active_op_array)->this_var) {
      object->op_type = 1 << 3;
    } else {

    }
  } else
  if (fetch_list_ptr->count == 1UL) {
    le = fetch_list_ptr->head;
    opline_ptr = (zend_op *)(le->data);
    tmp___2 = opline_is_fetch_this((zend_op const   *)opline_ptr);
    if (tmp___2) {
      zend_del_literal(compiler_globals.active_op_array,
                       (int )opline_ptr->op1.constant);
      opline_ptr->op1_type = (zend_uchar )(1 << 3);
      while (1) {
        opline_ptr->op2_type = (zend_uchar )property->op_type;
        if (property->op_type == 1) {
          tmp = zend_add_literal(compiler_globals.active_op_array,
                                 & property->u.constant);
          opline_ptr->op2.constant = (zend_uint )tmp;
        } else {
          __constr_expr_36 = property->u.op;
          opline_ptr->op2 = __constr_expr_36;
        }
        break;
      }
      switch ((int )opline_ptr->opcode) {
      case 83: 
      opline_ptr->opcode = (zend_uchar )85;
      break;
      case 80: 
      opline_ptr->opcode = (zend_uchar )82;
      break;
      case 86: 
      opline_ptr->opcode = (zend_uchar )88;
      break;
      case 89: 
      opline_ptr->opcode = (zend_uchar )91;
      break;
      case 95: 
      opline_ptr->opcode = (zend_uchar )97;
      break;
      case 92: 
      opline_ptr->opcode = (zend_uchar )94;
      break;
      }
      if ((int )opline_ptr->op2_type == 1) {
        if ((int )((compiler_globals.active_op_array)->literals + opline_ptr->op2.constant)->constant.type == 6) {
          while (1) {
            if ((unsigned long )((compiler_globals.active_op_array)->literals + opline_ptr->op2.constant)->constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
              if ((unsigned long )((compiler_globals.active_op_array)->literals + opline_ptr->op2.constant)->constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end) {
                ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline_ptr->op2.constant)->constant))->hash_value = ((Bucket *)(((compiler_globals.active_op_array)->literals + opline_ptr->op2.constant)->constant.value.str.val - sizeof(Bucket )))->h;
              } else {
                tmp___0 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline_ptr->op2.constant)->constant.value.str.val,
                                         (uint )(((compiler_globals.active_op_array)->literals + opline_ptr->op2.constant)->constant.value.str.len + 1));
                ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline_ptr->op2.constant)->constant))->hash_value = (zend_ulong )tmp___0;
              }
            } else {
              tmp___0 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline_ptr->op2.constant)->constant.value.str.val,
                                       (uint )(((compiler_globals.active_op_array)->literals + opline_ptr->op2.constant)->constant.value.str.len + 1));
              ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline_ptr->op2.constant)->constant))->hash_value = (zend_ulong )tmp___0;
            }
            break;
          }
          while (1) {
            ((compiler_globals.active_op_array)->literals + opline_ptr->op2.constant)->cache_slot = (zend_uint )(compiler_globals.active_op_array)->last_cache_slot;
            (compiler_globals.active_op_array)->last_cache_slot += 2;
            if ((compiler_globals.active_op_array)->fn_flags & 16U) {
              if ((compiler_globals.active_op_array)->run_time_cache) {
                tmp___1 = _erealloc((void *)(compiler_globals.active_op_array)->run_time_cache,
                                    (unsigned long )(compiler_globals.active_op_array)->last_cache_slot * sizeof(void *),
                                    0);
                (compiler_globals.active_op_array)->run_time_cache = (void **)tmp___1;
                *((compiler_globals.active_op_array)->run_time_cache + ((compiler_globals.active_op_array)->last_cache_slot - 1)) = (void *)0;
                *((compiler_globals.active_op_array)->run_time_cache + ((compiler_globals.active_op_array)->last_cache_slot - 2)) = (void *)0;
              } else {

              }
            } else {

            }
            break;
          }
        } else {

        }
      } else {

      }
      while (1) {
        result->op_type = (int )opline_ptr->result_type;
        if (result->op_type == 1) {
          result->u.constant = ((compiler_globals.active_op_array)->literals + opline_ptr->result.constant)->constant;
        } else {
          result->u.op = opline_ptr->result;
          result->EA = (zend_uint )0;
        }
        break;
      }
      return;
    } else {

    }
  } else {

  }
  tmp___4 = zend_is_function_or_method_call((znode const   *)object);
  if (tmp___4) {
    init_op(& opline);
    opline.opcode = (zend_uchar )156;
    while (1) {
      opline.op1_type = (zend_uchar )object->op_type;
      if (object->op_type == 1) {
        tmp___3 = zend_add_literal(compiler_globals.active_op_array,
                                   (zval const   *)(& object->u.constant));
        opline.op1.constant = (zend_uint )tmp___3;
      } else {
        opline.op1 = object->u.op;
      }
      break;
    }
    opline.op2_type = (zend_uchar )(1 << 3);
    opline.result_type = (zend_uchar )(1 << 2);
    opline.result.var = opline.op1.var;
    zend_llist_add_element(fetch_list_ptr, (void *)(& opline));
  } else {

  }
  init_op(& opline);
  opline.opcode = (zend_uchar )85;
  opline.result_type = (zend_uchar )(1 << 2);
  opline.result.var = get_temporary_variable(compiler_globals.active_op_array);
  while (1) {
    opline.op1_type = (zend_uchar )object->op_type;
    if (object->op_type == 1) {
      tmp___5 = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& object->u.constant));
      opline.op1.constant = (zend_uint )tmp___5;
    } else {
      opline.op1 = object->u.op;
    }
    break;
  }
  while (1) {
    opline.op2_type = (zend_uchar )property->op_type;
    if (property->op_type == 1) {
      tmp___6 = zend_add_literal(compiler_globals.active_op_array,
                                 & property->u.constant);
      opline.op2.constant = (zend_uint )tmp___6;
    } else {
      __constr_expr_37 = property->u.op;
      opline.op2 = __constr_expr_37;
    }
    break;
  }
  if ((int )opline.op2_type == 1) {
    if ((int )((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant.type == 6) {
      while (1) {
        if ((unsigned long )((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
          if ((unsigned long )((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end) {
            ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant))->hash_value = ((Bucket *)(((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant.value.str.val - sizeof(Bucket )))->h;
          } else {
            tmp___7 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant.value.str.val,
                                     (uint )(((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant.value.str.len + 1));
            ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant))->hash_value = (zend_ulong )tmp___7;
          }
        } else {
          tmp___7 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant.value.str.val,
                                   (uint )(((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant.value.str.len + 1));
          ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline.op2.constant)->constant))->hash_value = (zend_ulong )tmp___7;
        }
        break;
      }
      while (1) {
        ((compiler_globals.active_op_array)->literals + opline.op2.constant)->cache_slot = (zend_uint )(compiler_globals.active_op_array)->last_cache_slot;
        (compiler_globals.active_op_array)->last_cache_slot += 2;
        if ((compiler_globals.active_op_array)->fn_flags & 16U) {
          if ((compiler_globals.active_op_array)->run_time_cache) {
            tmp___8 = _erealloc((void *)(compiler_globals.active_op_array)->run_time_cache,
                                (unsigned long )(compiler_globals.active_op_array)->last_cache_slot * sizeof(void *),
                                0);
            (compiler_globals.active_op_array)->run_time_cache = (void **)tmp___8;
            *((compiler_globals.active_op_array)->run_time_cache + ((compiler_globals.active_op_array)->last_cache_slot - 1)) = (void *)0;
            *((compiler_globals.active_op_array)->run_time_cache + ((compiler_globals.active_op_array)->last_cache_slot - 2)) = (void *)0;
          } else {

          }
        } else {

        }
        break;
      }
    } else {

    }
  } else {

  }
  while (1) {
    result->op_type = (int )opline.result_type;
    if (result->op_type == 1) {
      result->u.constant = ((compiler_globals.active_op_array)->literals + opline.result.constant)->constant;
    } else {
      result->u.op = opline.result;
      result->EA = (zend_uint )0;
    }
    break;
  }
  zend_llist_add_element(fetch_list_ptr, (void *)(& opline));
  return;
}
}
void zend_do_halt_compiler_register(void) 
{ 
  char *name ;
  char *cfilename ;
  char haltoff[25] ;
  int len ;
  int clen ;
  char __attribute__((__visibility__("default")))  *tmp ;
  size_t tmp___0 ;
  size_t __attribute__((__visibility__("default")))  tmp___1 ;

  {
  haltoff[0] = (char )'_';
  haltoff[1] = (char )'_';
  haltoff[2] = (char )'C';
  haltoff[3] = (char )'O';
  haltoff[4] = (char )'M';
  haltoff[5] = (char )'P';
  haltoff[6] = (char )'I';
  haltoff[7] = (char )'L';
  haltoff[8] = (char )'E';
  haltoff[9] = (char )'R';
  haltoff[10] = (char )'_';
  haltoff[11] = (char )'H';
  haltoff[12] = (char )'A';
  haltoff[13] = (char )'L';
  haltoff[14] = (char )'T';
  haltoff[15] = (char )'_';
  haltoff[16] = (char )'O';
  haltoff[17] = (char )'F';
  haltoff[18] = (char )'F';
  haltoff[19] = (char )'S';
  haltoff[20] = (char )'E';
  haltoff[21] = (char )'T';
  haltoff[22] = (char )'_';
  haltoff[23] = (char )'_';
  haltoff[24] = (char )'\000';
  if (compiler_globals.has_bracketed_namespaces) {
    if (compiler_globals.in_namespace) {
      zend_error(1 << 6L,
                 "__HALT_COMPILER() can only be used from the outermost scope");
    } else {

    }
  } else {

  }
  tmp = zend_get_compiled_filename();
  cfilename = (char *)tmp;
  tmp___0 = strlen((char const   *)cfilename);
  clen = (int )tmp___0;
  zend_mangle_property_name(& name, & len, (char const   *)(haltoff),
                            (int )(sizeof(haltoff) - 1UL),
                            (char const   *)cfilename, clen, 0);
  tmp___1 = zend_get_scanned_file_offset();
  zend_register_long_constant((char const   *)name, (uint )(len + 1),
                              (long )tmp___1, 1, 0);
  _efree((void *)name);
  if (compiler_globals.in_namespace) {
    zend_do_end_namespace();
  } else {

  }
  return;
}
}
void zend_do_push_object(znode const   *object ) 
{ 


  {
  zend_stack_push(& compiler_globals.object_stack, (void const   *)object,
                  (int )sizeof(znode ));
  return;
}
}
void zend_do_pop_object(znode *object ) 
{ 
  znode *tmp ;

  {
  if (object) {
    zend_stack_top((zend_stack const   *)(& compiler_globals.object_stack),
                   (void **)(& tmp));
    *object = *tmp;
  } else {

  }
  zend_stack_del_top(& compiler_globals.object_stack);
  return;
}
}
void zend_do_begin_new_object(znode *new_token , znode *class_type ) 
{ 
  zend_op *opline ;
  unsigned char *ptr ;
  int tmp ;
  int tmp___0 ;

  {
  ptr = (unsigned char *)((void *)0);
  tmp = get_next_op_number(compiler_globals.active_op_array);
  new_token->u.op.opline_num = (zend_uint )tmp;
  opline = get_next_op(compiler_globals.active_op_array);
  opline->opcode = (zend_uchar )68;
  opline->result_type = (zend_uchar )(1 << 2);
  opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  while (1) {
    opline->op1_type = (zend_uchar )class_type->op_type;
    if (class_type->op_type == 1) {
      tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& class_type->u.constant));
      opline->op1.constant = (zend_uint )tmp___0;
    } else {
      opline->op1 = class_type->u.op;
    }
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  zend_stack_push(& compiler_globals.function_call_stack,
                  (void const   *)((void *)(& ptr)),
                  (int )sizeof(unsigned char *));
  return;
}
}
void zend_do_end_new_object(znode *result , znode const   *new_token ,
                            znode const   *argument_list ) 
{ 
  znode ctor_result ;
  int tmp ;

  {
  zend_do_end_function_call((znode *)((void *)0), & ctor_result, argument_list,
                            1, 0);
  zend_do_free(& ctor_result);
  tmp = get_next_op_number(compiler_globals.active_op_array);
  ((compiler_globals.active_op_array)->opcodes + new_token->u.op.opline_num)->op2.opline_num = (zend_uint )tmp;
  while (1) {
    result->op_type = (int )((compiler_globals.active_op_array)->opcodes + new_token->u.op.opline_num)->result_type;
    if (result->op_type == 1) {
      result->u.constant = ((compiler_globals.active_op_array)->literals + ((compiler_globals.active_op_array)->opcodes + new_token->u.op.opline_num)->result.constant)->constant;
    } else {
      result->u.op = ((compiler_globals.active_op_array)->opcodes + new_token->u.op.opline_num)->result;
      result->EA = (zend_uint )0;
    }
    break;
  }
  return;
}
}
static zend_constant *zend_get_ct_const(zval const   *const_name ,
                                        int all_internal_constants_substitution ) 
{ 
  zend_constant *c ;
  char *lookup_name ;
  char __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;
  char *lookup_name___0 ;
  char __attribute__((__visibility__("default")))  *tmp___2 ;
  int __attribute__((__visibility__("default")))  tmp___3 ;
  int __attribute__((__visibility__("default")))  tmp___4 ;

  {
  c = (zend_constant *)((void *)0);
  if ((int )*(const_name->value.str.val + 0) == 92) {
    tmp___1 = zend_hash_find((HashTable const   *)executor_globals.zend_constants,
                             (char const   *)(const_name->value.str.val + 1),
                             (uint )const_name->value.str.len, (void **)(& c));
    if (tmp___1 == (int __attribute__((__visibility__("default")))  )-1) {
      tmp = zend_str_tolower_dup((char const   *)(const_name->value.str.val + 1),
                                 (unsigned int )(const_name->value.str.len - 1));
      lookup_name = (char *)tmp;
      tmp___0 = zend_hash_find((HashTable const   *)executor_globals.zend_constants,
                               (char const   *)lookup_name,
                               (uint )const_name->value.str.len, (void **)(& c));
      if (tmp___0 == (int __attribute__((__visibility__("default")))  )0) {
        if (c->flags & (1 << 2)) {
          if (! (c->flags & 1)) {
            _efree((void *)lookup_name);
            return (c);
          } else {

          }
        } else {

        }
      } else {

      }
      _efree((void *)lookup_name);
      return ((zend_constant *)((void *)0));
    } else {

    }
  } else {
    tmp___4 = zend_hash_find((HashTable const   *)executor_globals.zend_constants,
                             (char const   *)const_name->value.str.val,
                             (uint )(const_name->value.str.len + 1),
                             (void **)(& c));
    if (tmp___4 == (int __attribute__((__visibility__("default")))  )-1) {
      tmp___2 = zend_str_tolower_dup((char const   *)const_name->value.str.val,
                                     (unsigned int )const_name->value.str.len);
      lookup_name___0 = (char *)tmp___2;
      tmp___3 = zend_hash_find((HashTable const   *)executor_globals.zend_constants,
                               (char const   *)lookup_name___0,
                               (uint )(const_name->value.str.len + 1),
                               (void **)(& c));
      if (tmp___3 == (int __attribute__((__visibility__("default")))  )0) {
        if (c->flags & (1 << 2)) {
          if (! (c->flags & 1)) {
            _efree((void *)lookup_name___0);
            return (c);
          } else {

          }
        } else {

        }
      } else {

      }
      _efree((void *)lookup_name___0);
      return ((zend_constant *)((void *)0));
    } else {

    }
  }
  if (c->flags & (1 << 2)) {
    return (c);
  } else {

  }
  if (all_internal_constants_substitution) {
    if (c->flags & (1 << 1)) {
      if (! (compiler_globals.compiler_options & (unsigned int )(1 << 5))) {
        if ((int )c->value.type != 8) {
          if ((int )c->value.type != 9) {
            return (c);
          } else {

          }
        } else {

        }
      } else {

      }
    } else {

    }
  } else {

  }
  return ((zend_constant *)((void *)0));
}
}
static int zend_constant_ct_subst(znode *result , zval *const_name ,
                                  int all_internal_constants_substitution ) 
{ 
  zend_constant *c ;
  zend_constant *tmp ;

  {
  tmp = zend_get_ct_const((zval const   *)const_name,
                          all_internal_constants_substitution);
  c = tmp;
  if (c) {
    _zval_dtor(const_name);
    result->op_type = 1;
    result->u.constant = c->value;
    _zval_copy_ctor(& result->u.constant);
    result->u.constant.refcount__gc = (zend_uint )1;
    result->u.constant.is_ref__gc = (zend_uchar )0;
    return (1);
  } else {

  }
  return (0);
}
}
void zend_do_fetch_constant(znode *result , znode *constant_container ,
                            znode *constant_name , int mode ,
                            zend_bool check_namespace ) 
{ 
  znode tmp ;
  zend_op *opline ;
  int type ;
  char *compound ;
  ulong fetch_type ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  ulong __attribute__((__visibility__("default")))  tmp___4 ;
  int tmp___5 ;
  void __attribute__((__visibility__("default")))  *tmp___6 ;
  void __attribute__((__visibility__("default")))  *tmp___7 ;
  void *tmp___8 ;
  int tmp___9 ;
  void *tmp___10 ;
  int tmp___11 ;
  int tmp___12 ;
  int tmp___13 ;
  int tmp___14 ;
  int tmp___15 ;
  void __attribute__((__visibility__("default")))  *tmp___16 ;

  {
  fetch_type = (ulong )0;
  if (constant_container) {
    switch (mode) {
    case 1: 
    type = zend_get_class_fetch_type((char const   *)constant_container->u.constant.value.str.val,
                                     (uint )constant_container->u.constant.value.str.len);
    if (7 == type) {
      zend_error(1, "\"static::\" is not allowed in compile-time constants");
    } else
    if (0 == type) {
      zend_resolve_class_name(constant_container, fetch_type, 1);
    } else {

    }
    zend_do_build_full_name((znode *)((void *)0), constant_container,
                            constant_name, 1);
    *result = *constant_container;
    result->u.constant.type = (zend_uchar )(8UL | fetch_type);
    break;
    case 1 << 1: 
    if (constant_container->op_type == 1) {
      tmp___0 = zend_get_class_fetch_type((char const   *)constant_container->u.constant.value.str.val,
                                          (uint )constant_container->u.constant.value.str.len);
      if (0 == tmp___0) {
        zend_resolve_class_name(constant_container, fetch_type, 1);
      } else {
        zend_do_fetch_class(& tmp, constant_container);
        constant_container = & tmp;
      }
    } else {
      zend_do_fetch_class(& tmp, constant_container);
      constant_container = & tmp;
    }
    opline = get_next_op(compiler_globals.active_op_array);
    opline->opcode = (zend_uchar )99;
    opline->result_type = (zend_uchar )(1 << 1);
    opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
    if (constant_container->op_type == 1) {
      opline->op1_type = (zend_uchar )1;
      tmp___1 = zend_add_class_name_literal(compiler_globals.active_op_array,
                                            (zval const   *)(& constant_container->u.constant));
      opline->op1.constant = (zend_uint )tmp___1;
    } else {
      while (1) {
        opline->op1_type = (zend_uchar )constant_container->op_type;
        if (constant_container->op_type == 1) {
          tmp___2 = zend_add_literal(compiler_globals.active_op_array,
                                     (zval const   *)(& constant_container->u.constant));
          opline->op1.constant = (zend_uint )tmp___2;
        } else {
          opline->op1 = constant_container->u.op;
        }
        break;
      }
    }
    while (1) {
      opline->op2_type = (zend_uchar )constant_name->op_type;
      if (constant_name->op_type == 1) {
        tmp___3 = zend_add_literal(compiler_globals.active_op_array,
                                   (zval const   *)(& constant_name->u.constant));
        opline->op2.constant = (zend_uint )tmp___3;
      } else {
        opline->op2 = constant_name->u.op;
      }
      break;
    }
    while (1) {
      if ((unsigned long )((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
        if ((unsigned long )((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end) {
          ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant))->hash_value = ((Bucket *)(((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val - sizeof(Bucket )))->h;
        } else {
          tmp___4 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val,
                                   (uint )(((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.len + 1));
          ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant))->hash_value = (zend_ulong )tmp___4;
        }
      } else {
        tmp___4 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val,
                                 (uint )(((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.len + 1));
        ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant))->hash_value = (zend_ulong )tmp___4;
      }
      break;
    }
    if ((int )opline->op1_type == 1) {
      while (1) {
        tmp___5 = (compiler_globals.active_op_array)->last_cache_slot;
        ((compiler_globals.active_op_array)->last_cache_slot) ++;
        ((compiler_globals.active_op_array)->literals + opline->op2.constant)->cache_slot = (zend_uint )tmp___5;
        if ((compiler_globals.active_op_array)->fn_flags & 16U) {
          if ((compiler_globals.active_op_array)->run_time_cache) {
            tmp___6 = _erealloc((void *)(compiler_globals.active_op_array)->run_time_cache,
                                (unsigned long )(compiler_globals.active_op_array)->last_cache_slot * sizeof(void *),
                                0);
            (compiler_globals.active_op_array)->run_time_cache = (void **)tmp___6;
            *((compiler_globals.active_op_array)->run_time_cache + ((compiler_globals.active_op_array)->last_cache_slot - 1)) = (void *)0;
          } else {

          }
        } else {

        }
        break;
      }
    } else {
      while (1) {
        ((compiler_globals.active_op_array)->literals + opline->op2.constant)->cache_slot = (zend_uint )(compiler_globals.active_op_array)->last_cache_slot;
        (compiler_globals.active_op_array)->last_cache_slot += 2;
        if ((compiler_globals.active_op_array)->fn_flags & 16U) {
          if ((compiler_globals.active_op_array)->run_time_cache) {
            tmp___7 = _erealloc((void *)(compiler_globals.active_op_array)->run_time_cache,
                                (unsigned long )(compiler_globals.active_op_array)->last_cache_slot * sizeof(void *),
                                0);
            (compiler_globals.active_op_array)->run_time_cache = (void **)tmp___7;
            *((compiler_globals.active_op_array)->run_time_cache + ((compiler_globals.active_op_array)->last_cache_slot - 1)) = (void *)0;
            *((compiler_globals.active_op_array)->run_time_cache + ((compiler_globals.active_op_array)->last_cache_slot - 2)) = (void *)0;
          } else {

          }
        } else {

        }
        break;
      }
    }
    while (1) {
      result->op_type = (int )opline->result_type;
      if (result->op_type == 1) {
        result->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
      } else {
        result->u.op = opline->result;
        result->EA = (zend_uint )0;
      }
      break;
    }
    break;
    }
    return;
  } else {

  }
  switch (mode) {
  case 1: 
  tmp___8 = memchr((void const   *)constant_name->u.constant.value.str.val,
                   '\\', (size_t )constant_name->u.constant.value.str.len);
  compound = (char *)tmp___8;
  tmp___9 = zend_constant_ct_subst(result, & constant_name->u.constant, 0);
  if (tmp___9) {
    break;
  } else {

  }
  zend_resolve_non_class_name(constant_name, check_namespace);
  if (! compound) {
    fetch_type |= 16UL;
  } else {

  }
  *result = *constant_name;
  result->u.constant.type = (zend_uchar )(8UL | fetch_type);
  break;
  case 1 << 1: 
  tmp___10 = memchr((void const   *)constant_name->u.constant.value.str.val,
                    '\\', (size_t )constant_name->u.constant.value.str.len);
  compound = (char *)tmp___10;
  zend_resolve_non_class_name(constant_name, check_namespace);
  tmp___11 = zend_constant_ct_subst(result, & constant_name->u.constant, 1);
  if (tmp___11) {
    break;
  } else {

  }
  opline = get_next_op(compiler_globals.active_op_array);
  opline->opcode = (zend_uchar )99;
  opline->result_type = (zend_uchar )(1 << 1);
  opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  while (1) {
    result->op_type = (int )opline->result_type;
    if (result->op_type == 1) {
      result->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      result->u.op = opline->result;
      result->EA = (zend_uint )0;
    }
    break;
  }
  opline->op1_type = (zend_uchar )(1 << 3);
  opline->op2_type = (zend_uchar )1;
  if (compound) {
    opline->extended_value = (ulong )0;
    tmp___12 = zend_add_const_name_literal(compiler_globals.active_op_array,
                                           (zval const   *)(& constant_name->u.constant),
                                           0);
    opline->op2.constant = (zend_uint )tmp___12;
  } else {
    opline->extended_value = (ulong )16;
    if (compiler_globals.current_namespace) {
      opline->extended_value |= 256UL;
      tmp___13 = zend_add_const_name_literal(compiler_globals.active_op_array,
                                             (zval const   *)(& constant_name->u.constant),
                                             1);
      opline->op2.constant = (zend_uint )tmp___13;
    } else {
      tmp___14 = zend_add_const_name_literal(compiler_globals.active_op_array,
                                             (zval const   *)(& constant_name->u.constant),
                                             0);
      opline->op2.constant = (zend_uint )tmp___14;
    }
  }
  while (1) {
    tmp___15 = (compiler_globals.active_op_array)->last_cache_slot;
    ((compiler_globals.active_op_array)->last_cache_slot) ++;
    ((compiler_globals.active_op_array)->literals + opline->op2.constant)->cache_slot = (zend_uint )tmp___15;
    if ((compiler_globals.active_op_array)->fn_flags & 16U) {
      if ((compiler_globals.active_op_array)->run_time_cache) {
        tmp___16 = _erealloc((void *)(compiler_globals.active_op_array)->run_time_cache,
                             (unsigned long )(compiler_globals.active_op_array)->last_cache_slot * sizeof(void *),
                             0);
        (compiler_globals.active_op_array)->run_time_cache = (void **)tmp___16;
        *((compiler_globals.active_op_array)->run_time_cache + ((compiler_globals.active_op_array)->last_cache_slot - 1)) = (void *)0;
      } else {

      }
    } else {

    }
    break;
  }
  break;
  }
  return;
}
}
void zend_do_shell_exec(znode *result , znode const   *cmd ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;
  zval _c ;
  char const   *__s ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  int __l ;
  zval *__z ;
  int tmp___3 ;
  ulong __attribute__((__visibility__("default")))  tmp___4 ;
  int tmp___5 ;
  void __attribute__((__visibility__("default")))  *tmp___6 ;
  znode_op __constr_expr_38 ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  switch (cmd->op_type) {
  case 1: 
  case (int const   )(1 << 1): 
  opline->opcode = (zend_uchar )65;
  break;
  default: 
  opline->opcode = (zend_uchar )66;
  break;
  }
  while (1) {
    opline->op1_type = (zend_uchar )cmd->op_type;
    if (cmd->op_type == 1) {
      tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                 & cmd->u.constant);
      opline->op1.constant = (zend_uint )tmp___0;
    } else {
      __constr_expr_38 = cmd->u.op;
      opline->op1 = __constr_expr_38;
    }
    break;
  }
  opline->op2.opline_num = (zend_uint )0;
  opline->extended_value = (ulong )60;
  opline->op2_type = (zend_uchar )(1 << 3);
  opline = get_next_op(compiler_globals.active_op_array);
  opline->opcode = (zend_uchar )60;
  opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  opline->result_type = (zend_uchar )(1 << 2);
  while (1) {
    while (1) {
      tmp___1 = _estrndup("shell_exec",
                          (unsigned int )(sizeof("shell_exec") - 1UL));
      __s = (char const   *)tmp___1;
      __l = (int )(sizeof("shell_exec") - 1UL);
      __z = & _c;
      __z->value.str.len = __l;
      __z->value.str.val = (char *)((char __attribute__((__visibility__("default")))  *)((char *)__s));
      __z->type = (zend_uchar )6;
      break;
    }
    tmp___3 = zend_add_literal(compiler_globals.active_op_array,
                               (zval const   *)(& _c));
    opline->op1.constant = (zend_uint )tmp___3;
    break;
  }
  while (1) {
    if ((unsigned long )((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
      if ((unsigned long )((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end) {
        ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant))->hash_value = ((Bucket *)(((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val - sizeof(Bucket )))->h;
      } else {
        tmp___4 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val,
                                 (uint )(((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.len + 1));
        ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant))->hash_value = (zend_ulong )tmp___4;
      }
    } else {
      tmp___4 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val,
                               (uint )(((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.len + 1));
      ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant))->hash_value = (zend_ulong )tmp___4;
    }
    break;
  }
  opline->op1_type = (zend_uchar )1;
  while (1) {
    tmp___5 = (compiler_globals.active_op_array)->last_cache_slot;
    ((compiler_globals.active_op_array)->last_cache_slot) ++;
    ((compiler_globals.active_op_array)->literals + opline->op1.constant)->cache_slot = (zend_uint )tmp___5;
    if ((compiler_globals.active_op_array)->fn_flags & 16U) {
      if ((compiler_globals.active_op_array)->run_time_cache) {
        tmp___6 = _erealloc((void *)(compiler_globals.active_op_array)->run_time_cache,
                            (unsigned long )(compiler_globals.active_op_array)->last_cache_slot * sizeof(void *),
                            0);
        (compiler_globals.active_op_array)->run_time_cache = (void **)tmp___6;
        *((compiler_globals.active_op_array)->run_time_cache + ((compiler_globals.active_op_array)->last_cache_slot - 1)) = (void *)0;
      } else {

      }
    } else {

    }
    break;
  }
  opline->extended_value = (ulong )1;
  opline->op2_type = (zend_uchar )(1 << 3);
  while (1) {
    result->op_type = (int )opline->result_type;
    if (result->op_type == 1) {
      result->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      result->u.op = opline->result;
      result->EA = (zend_uint )0;
    }
    break;
  }
  return;
}
}
void zend_do_init_array(znode *result , znode const   *expr ,
                        znode const   *offset , zend_bool is_ref ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;
  int tmp___1 ;
  ulong index___0 ;
  int numeric ;
  register char const   *tmp___2 ;
  char const   *end ;
  zval *__z ;
  ulong __attribute__((__visibility__("default")))  tmp___3 ;
  znode_op __constr_expr_39 ;
  znode_op __constr_expr_40 ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  opline->opcode = (zend_uchar )71;
  opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  opline->result_type = (zend_uchar )(1 << 1);
  while (1) {
    result->op_type = (int )opline->result_type;
    if (result->op_type == 1) {
      result->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      result->u.op = opline->result;
      result->EA = (zend_uint )0;
    }
    break;
  }
  if (expr) {
    while (1) {
      opline->op1_type = (zend_uchar )expr->op_type;
      if (expr->op_type == 1) {
        tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                   & expr->u.constant);
        opline->op1.constant = (zend_uint )tmp___0;
      } else {
        __constr_expr_39 = expr->u.op;
        opline->op1 = __constr_expr_39;
      }
      break;
    }
    if (offset) {
      while (1) {
        opline->op2_type = (zend_uchar )offset->op_type;
        if (offset->op_type == 1) {
          tmp___1 = zend_add_literal(compiler_globals.active_op_array,
                                     & offset->u.constant);
          opline->op2.constant = (zend_uint )tmp___1;
        } else {
          __constr_expr_40 = offset->u.op;
          opline->op2 = __constr_expr_40;
        }
        break;
      }
      if ((int )opline->op2_type == 1) {
        if ((int )((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.type == 6) {
          numeric = 0;
          while (1) {
            tmp___2 = (char const   *)((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val;
            if ((int const   )*tmp___2 == 45) {
              tmp___2 ++;
            } else {

            }
            if ((int const   )*tmp___2 >= 48) {
              if ((int const   )*tmp___2 <= 57) {
                end = (char const   *)(((((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val + ((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.len) + 1) - 1);
                if ((int const   )*end != 0) {
                  break;
                } else
                if ((int const   )*tmp___2 == 48) {
                  if (((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.len + 1 > 2) {
                    break;
                  } else {
                    goto _L;
                  }
                } else
                _L: 
                if (end - tmp___2 > 19L) {
                  break;
                } else {

                }
                index___0 = (ulong )((int const   )*tmp___2 - 48);
                while (1) {
                  tmp___2 ++;
                  if ((unsigned long )tmp___2 != (unsigned long )end) {
                    if ((int const   )*tmp___2 >= 48) {
                      if (! ((int const   )*tmp___2 <= 57)) {
                        break;
                      } else {

                      }
                    } else {
                      break;
                    }
                  } else {
                    break;
                  }
                  index___0 = index___0 * 10UL + (ulong )((int const   )*tmp___2 - 48);
                }
                if ((unsigned long )tmp___2 == (unsigned long )end) {
                  if ((int )*(((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val) == 45) {
                    if (index___0 - 1UL > 9223372036854775807UL) {
                      break;
                    } else {

                    }
                    index___0 = (ulong )(- ((long )index___0));
                  } else
                  if (index___0 > 9223372036854775807UL) {
                    break;
                  } else {

                  }
                  numeric = 1;
                } else {

                }
              } else {

              }
            } else {

            }
            break;
          }
          if (numeric) {
            _zval_dtor(& ((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant);
            __z = & ((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant;
            __z->value.lval = (long )index___0;
            __z->type = (zend_uchar )1;
          } else {
            while (1) {
              if ((unsigned long )((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
                if ((unsigned long )((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end) {
                  ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant))->hash_value = ((Bucket *)(((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val - sizeof(Bucket )))->h;
                } else {
                  tmp___3 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val,
                                           (uint )(((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.len + 1));
                  ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant))->hash_value = (zend_ulong )tmp___3;
                }
              } else {
                tmp___3 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val,
                                         (uint )(((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.len + 1));
                ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant))->hash_value = (zend_ulong )tmp___3;
              }
              break;
            }
          }
        } else {

        }
      } else {

      }
    } else {
      opline->op2_type = (zend_uchar )(1 << 3);
    }
  } else {
    opline->op1_type = (zend_uchar )(1 << 3);
    opline->op2_type = (zend_uchar )(1 << 3);
  }
  opline->extended_value = (ulong )is_ref;
  return;
}
}
void zend_do_add_array_element(znode *result , znode const   *expr ,
                               znode const   *offset , zend_bool is_ref ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  ulong index___0 ;
  int numeric ;
  register char const   *tmp___3 ;
  char const   *end ;
  zval *__z ;
  ulong __attribute__((__visibility__("default")))  tmp___4 ;
  znode_op __constr_expr_41 ;
  znode_op __constr_expr_42 ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  opline->opcode = (zend_uchar )72;
  while (1) {
    opline->result_type = (zend_uchar )result->op_type;
    if (result->op_type == 1) {
      tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& result->u.constant));
      opline->result.constant = (zend_uint )tmp___0;
    } else {
      opline->result = result->u.op;
    }
    break;
  }
  while (1) {
    opline->op1_type = (zend_uchar )expr->op_type;
    if (expr->op_type == 1) {
      tmp___1 = zend_add_literal(compiler_globals.active_op_array,
                                 & expr->u.constant);
      opline->op1.constant = (zend_uint )tmp___1;
    } else {
      __constr_expr_41 = expr->u.op;
      opline->op1 = __constr_expr_41;
    }
    break;
  }
  if (offset) {
    while (1) {
      opline->op2_type = (zend_uchar )offset->op_type;
      if (offset->op_type == 1) {
        tmp___2 = zend_add_literal(compiler_globals.active_op_array,
                                   & offset->u.constant);
        opline->op2.constant = (zend_uint )tmp___2;
      } else {
        __constr_expr_42 = offset->u.op;
        opline->op2 = __constr_expr_42;
      }
      break;
    }
    if ((int )opline->op2_type == 1) {
      if ((int )((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.type == 6) {
        numeric = 0;
        while (1) {
          tmp___3 = (char const   *)((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val;
          if ((int const   )*tmp___3 == 45) {
            tmp___3 ++;
          } else {

          }
          if ((int const   )*tmp___3 >= 48) {
            if ((int const   )*tmp___3 <= 57) {
              end = (char const   *)(((((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val + ((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.len) + 1) - 1);
              if ((int const   )*end != 0) {
                break;
              } else
              if ((int const   )*tmp___3 == 48) {
                if (((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.len + 1 > 2) {
                  break;
                } else {
                  goto _L;
                }
              } else
              _L: 
              if (end - tmp___3 > 19L) {
                break;
              } else {

              }
              index___0 = (ulong )((int const   )*tmp___3 - 48);
              while (1) {
                tmp___3 ++;
                if ((unsigned long )tmp___3 != (unsigned long )end) {
                  if ((int const   )*tmp___3 >= 48) {
                    if (! ((int const   )*tmp___3 <= 57)) {
                      break;
                    } else {

                    }
                  } else {
                    break;
                  }
                } else {
                  break;
                }
                index___0 = index___0 * 10UL + (ulong )((int const   )*tmp___3 - 48);
              }
              if ((unsigned long )tmp___3 == (unsigned long )end) {
                if ((int )*(((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val) == 45) {
                  if (index___0 - 1UL > 9223372036854775807UL) {
                    break;
                  } else {

                  }
                  index___0 = (ulong )(- ((long )index___0));
                } else
                if (index___0 > 9223372036854775807UL) {
                  break;
                } else {

                }
                numeric = 1;
              } else {

              }
            } else {

            }
          } else {

          }
          break;
        }
        if (numeric) {
          _zval_dtor(& ((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant);
          __z = & ((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant;
          __z->value.lval = (long )index___0;
          __z->type = (zend_uchar )1;
        } else {
          while (1) {
            if ((unsigned long )((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
              if ((unsigned long )((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end) {
                ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant))->hash_value = ((Bucket *)(((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val - sizeof(Bucket )))->h;
              } else {
                tmp___4 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val,
                                         (uint )(((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.len + 1));
                ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant))->hash_value = (zend_ulong )tmp___4;
              }
            } else {
              tmp___4 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.val,
                                       (uint )(((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant.value.str.len + 1));
              ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant))->hash_value = (zend_ulong )tmp___4;
            }
            break;
          }
        }
      } else {

      }
    } else {

    }
  } else {
    opline->op2_type = (zend_uchar )(1 << 3);
  }
  opline->extended_value = (ulong )is_ref;
  return;
}
}
void zend_do_add_static_array_element(znode *result , znode *offset ,
                                      znode const   *expr ) 
{ 
  zval *element ;
  void __attribute__((__visibility__("default")))  *tmp ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  long tmp___1 ;

  {
  while (1) {
    tmp = _emalloc(sizeof(zval_gc_info ));
    element = (zval *)tmp;
    ((zval_gc_info *)element)->u.buffered = (gc_root_buffer *)((void *)0);
    break;
  }
  *element = (zval )expr->u.constant;
  if (offset) {
    switch ((int )offset->u.constant.type & 15) {
    case 8: 
    element->type = (zend_uchar )((int )element->type | 128);
    tmp___0 = _erealloc((void *)offset->u.constant.value.str.val,
                        (size_t )(offset->u.constant.value.str.len + 3), 0);
    offset->u.constant.value.str.val = (char *)tmp___0;
    *(offset->u.constant.value.str.val + (offset->u.constant.value.str.len + 1)) = (char )offset->u.constant.type;
    *(offset->u.constant.value.str.val + (offset->u.constant.value.str.len + 2)) = (char)0;
    zend_symtable_update(result->u.constant.value.ht,
                         (char const   *)offset->u.constant.value.str.val,
                         (uint )(offset->u.constant.value.str.len + 3),
                         (void *)(& element), (uint )sizeof(zval *),
                         (void **)((void *)0));
    _zval_dtor(& offset->u.constant);
    break;
    case 6: 
    zend_symtable_update(result->u.constant.value.ht,
                         (char const   *)offset->u.constant.value.str.val,
                         (uint )(offset->u.constant.value.str.len + 1),
                         (void *)(& element), (uint )sizeof(zval *),
                         (void **)((void *)0));
    _zval_dtor(& offset->u.constant);
    break;
    case 0: 
    zend_symtable_update(result->u.constant.value.ht, "", (uint )1,
                         (void *)(& element), (uint )sizeof(zval *),
                         (void **)((void *)0));
    break;
    case 1: 
    case 3: 
    _zend_hash_index_update_or_next_insert(result->u.constant.value.ht,
                                           (ulong )offset->u.constant.value.lval,
                                           (void *)(& element),
                                           (uint )sizeof(zval *),
                                           (void **)((void *)0), 1);
    break;
    case 2: 
    tmp___1 = zend_dval_to_lval(offset->u.constant.value.dval);
    _zend_hash_index_update_or_next_insert(result->u.constant.value.ht,
                                           (ulong )tmp___1, (void *)(& element),
                                           (uint )sizeof(zval *),
                                           (void **)((void *)0), 1);
    break;
    case 9: 
    zend_error(1, "Illegal offset type");
    break;
    }
  } else {
    _zend_hash_index_update_or_next_insert(result->u.constant.value.ht,
                                           (ulong )0, (void *)(& element),
                                           (uint )sizeof(zval *),
                                           (void **)((void *)0), 1 << 2);
  }
  return;
}
}
void zend_do_add_list_element(znode const   *element ) 
{ 
  list_llist_element lle ;

  {
  if (element) {
    zend_check_writable_variable(element);
    lle.var = (znode )*element;
    zend_llist_copy(& lle.dimensions, & compiler_globals.dimension_llist);
    zend_llist_prepend_element(& compiler_globals.list_llist, (void *)(& lle));
  } else {

  }
  (*((int *)((compiler_globals.dimension_llist.tail)->data))) ++;
  return;
}
}
void zend_do_new_list_begin(void) 
{ 
  int current_dimension ;

  {
  current_dimension = 0;
  zend_llist_add_element(& compiler_globals.dimension_llist,
                         (void *)(& current_dimension));
  return;
}
}
void zend_do_new_list_end(void) 
{ 


  {
  zend_llist_remove_tail(& compiler_globals.dimension_llist);
  (*((int *)((compiler_globals.dimension_llist.tail)->data))) ++;
  return;
}
}
void zend_do_list_init(void) 
{ 


  {
  zend_stack_push(& compiler_globals.list_stack,
                  (void const   *)(& compiler_globals.list_llist),
                  (int )sizeof(zend_llist ));
  zend_stack_push(& compiler_globals.list_stack,
                  (void const   *)(& compiler_globals.dimension_llist),
                  (int )sizeof(zend_llist ));
  zend_llist_init(& compiler_globals.list_llist, sizeof(list_llist_element ),
                  (void (*)(void * ))((void *)0), (unsigned char)0);
  zend_llist_init(& compiler_globals.dimension_llist, sizeof(int ),
                  (void (*)(void * ))((void *)0), (unsigned char)0);
  zend_do_new_list_begin();
  return;
}
}
void zend_do_list_end(znode *result , znode *expr ) 
{ 
  zend_llist_element *le ;
  zend_llist_element *dimension ;
  zend_op *opline ;
  znode last_container ;
  zend_llist *tmp_dimension_llist ;
  int tmp ;
  zval _c ;
  zval *__z ;
  int tmp___0 ;
  zend_llist *p ;

  {
  le = compiler_globals.list_llist.head;
  while (le) {
    tmp_dimension_llist = & ((list_llist_element *)(le->data))->dimensions;
    dimension = tmp_dimension_llist->head;
    while (dimension) {
      opline = get_next_op(compiler_globals.active_op_array);
      if ((unsigned long )dimension == (unsigned long )tmp_dimension_llist->head) {
        last_container = *expr;
        switch (expr->op_type) {
        case 1 << 2: 
        case 1 << 4: 
        opline->opcode = (zend_uchar )81;
        break;
        case 1 << 1: 
        opline->opcode = (zend_uchar )98;
        break;
        case 1: 
        _zval_copy_ctor(& expr->u.constant);
        opline->opcode = (zend_uchar )98;
        break;
        }
        opline->extended_value |= 134217728UL;
      } else {
        opline->opcode = (zend_uchar )81;
      }
      opline->result_type = (zend_uchar )(1 << 2);
      opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
      while (1) {
        opline->op1_type = (zend_uchar )last_container.op_type;
        if (last_container.op_type == 1) {
          tmp = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& last_container.u.constant));
          opline->op1.constant = (zend_uint )tmp;
        } else {
          opline->op1 = last_container.u.op;
        }
        break;
      }
      opline->op2_type = (zend_uchar )1;
      while (1) {
        __z = & _c;
        __z->value.lval = (long )*((int *)(dimension->data));
        __z->type = (zend_uchar )1;
        tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                   (zval const   *)(& _c));
        opline->op2.constant = (zend_uint )tmp___0;
        break;
      }
      while (1) {
        last_container.op_type = (int )opline->result_type;
        if (last_container.op_type == 1) {
          last_container.u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
        } else {
          last_container.u.op = opline->result;
          last_container.EA = (zend_uint )0;
        }
        break;
      }
      dimension = dimension->next;
    }
    ((list_llist_element *)(le->data))->value = last_container;
    zend_llist_destroy(& ((list_llist_element *)(le->data))->dimensions);
    zend_do_assign(result, & ((list_llist_element *)(le->data))->var,
                   & ((list_llist_element *)(le->data))->value);
    zend_do_free(result);
    le = le->next;
  }
  zend_llist_destroy(& compiler_globals.dimension_llist);
  zend_llist_destroy(& compiler_globals.list_llist);
  *result = *expr;
  zend_stack_top((zend_stack const   *)(& compiler_globals.list_stack),
                 (void **)(& p));
  compiler_globals.dimension_llist = *p;
  zend_stack_del_top(& compiler_globals.list_stack);
  zend_stack_top((zend_stack const   *)(& compiler_globals.list_stack),
                 (void **)(& p));
  compiler_globals.list_llist = *p;
  zend_stack_del_top(& compiler_globals.list_stack);
  return;
}
}
void zend_init_list(void *result , void *item ) 
{ 
  void **list ;
  void __attribute__((__visibility__("default")))  *tmp ;

  {
  tmp = _emalloc(sizeof(void *) * 2UL);
  list = (void **)tmp;
  *(list + 0) = item;
  *(list + 1) = (void *)0;
  *((void **)result) = (void *)list;
  return;
}
}
void zend_add_to_list(void *result , void *item ) 
{ 
  void **list ;
  size_t n ;
  void __attribute__((__visibility__("default")))  *tmp ;

  {
  list = (void **)*((void **)result);
  n = (size_t )0;
  while (1) {
    if (list) {
      if (! *(list + n)) {
        break;
      } else {

      }
    } else {
      break;
    }
    n ++;
  }
  tmp = _erealloc((void *)list, sizeof(void *) * (n + 2UL), 0);
  list = (void **)tmp;
  *(list + n) = item;
  *(list + (n + 1UL)) = (void *)0;
  *((void **)result) = (void *)list;
  return;
}
}
void zend_do_fetch_static_variable(znode *varname ,
                                   znode const   *static_assignment ,
                                   int fetch_type ) 
{ 
  zval *tmp ;
  zend_op *opline ;
  znode lval ;
  znode result ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  int tmp___2 ;
  ulong __attribute__((__visibility__("default")))  tmp___3 ;
  znode dummy ;

  {
  while (1) {
    tmp___0 = _emalloc(sizeof(zval_gc_info ));
    tmp = (zval *)tmp___0;
    ((zval_gc_info *)tmp)->u.buffered = (gc_root_buffer *)((void *)0);
    break;
  }
  if (static_assignment) {
    *tmp = (zval )static_assignment->u.constant;
  } else {
    *tmp = (zval )zval_used_for_init;
  }
  if (! (compiler_globals.active_op_array)->static_variables) {
    if ((compiler_globals.active_op_array)->scope) {
      ((compiler_globals.active_op_array)->scope)->ce_flags |= 8388608U;
    } else {

    }
    tmp___1 = _emalloc(sizeof(HashTable ));
    (compiler_globals.active_op_array)->static_variables = (HashTable *)tmp___1;
    _zend_hash_init((compiler_globals.active_op_array)->static_variables,
                    (uint )2,
                    (ulong (*)(char const   *arKey , uint nKeyLength ))((void *)0),
                    (void (*)(void * ))(& _zval_ptr_dtor), (zend_bool )0);
  } else {

  }
  _zend_hash_add_or_update((compiler_globals.active_op_array)->static_variables,
                           (char const   *)varname->u.constant.value.str.val,
                           (uint )(varname->u.constant.value.str.len + 1),
                           (void *)(& tmp), (uint )sizeof(zval *),
                           (void **)((void *)0), 1);
  if (varname->op_type == 1) {
    if ((int )varname->u.constant.type != 6) {
      if ((int )varname->u.constant.type != 6) {
        _convert_to_string(& varname->u.constant);
      } else {

      }
    } else {

    }
  } else {

  }
  opline = get_next_op(compiler_globals.active_op_array);
  if (fetch_type == 1342177280) {
    opline->opcode = (zend_uchar )80;
  } else {
    opline->opcode = (zend_uchar )83;
  }
  opline->result_type = (zend_uchar )(1 << 2);
  opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  while (1) {
    opline->op1_type = (zend_uchar )varname->op_type;
    if (varname->op_type == 1) {
      tmp___2 = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& varname->u.constant));
      opline->op1.constant = (zend_uint )tmp___2;
    } else {
      opline->op1 = varname->u.op;
    }
    break;
  }
  if ((int )opline->op1_type == 1) {
    while (1) {
      if ((unsigned long )((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
        if ((unsigned long )((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end) {
          ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant))->hash_value = ((Bucket *)(((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val - sizeof(Bucket )))->h;
        } else {
          tmp___3 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val,
                                   (uint )(((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.len + 1));
          ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant))->hash_value = (zend_ulong )tmp___3;
        }
      } else {
        tmp___3 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val,
                                 (uint )(((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.len + 1));
        ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant))->hash_value = (zend_ulong )tmp___3;
      }
      break;
    }
  } else {

  }
  opline->op2_type = (zend_uchar )(1 << 3);
  opline->extended_value = (ulong )536870912;
  while (1) {
    result.op_type = (int )opline->result_type;
    if (result.op_type == 1) {
      result.u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      result.u.op = opline->result;
      result.EA = (zend_uint )0;
    }
    break;
  }
  if (varname->op_type == 1) {
    _zval_copy_ctor(& varname->u.constant);
  } else {

  }
  fetch_simple_variable(& lval, varname, 0);
  if (fetch_type == 1342177280) {
    zend_do_begin_variable_parse();
    zend_do_assign(& dummy, & lval, & result);
    zend_do_free(& dummy);
  } else {
    zend_do_assign_ref((znode *)((void *)0), (znode const   *)(& lval),
                       (znode const   *)(& result));
  }
  ((compiler_globals.active_op_array)->opcodes + ((compiler_globals.active_op_array)->last - 1U))->result_type = (zend_uchar )((int )((compiler_globals.active_op_array)->opcodes + ((compiler_globals.active_op_array)->last - 1U))->result_type | (1 << 5));
  return;
}
}
void zend_do_fetch_lexical_variable(znode *varname , zend_bool is_ref ) 
{ 
  znode value ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;

  {
  if ((unsigned long )varname->u.constant.value.str.len == sizeof("this") - 1UL) {
    tmp = memcmp((void const   *)varname->u.constant.value.str.val,
                 (void const   *)"this", sizeof("this") - 1UL);
    if (tmp == 0) {
      zend_error(1 << 6L, "Cannot use $this as lexical variable");
      return;
    } else {

    }
  } else {

  }
  value.op_type = 1;
  value.u.constant.type = (zend_uchar )0;
  if (is_ref) {
    tmp___0 = 64;
  } else {
    tmp___0 = 32;
  }
  value.u.constant.type = (zend_uchar )((int )value.u.constant.type | tmp___0);
  zval_set_refcount_p(& value.u.constant, (zend_uint )1);
  zval_unset_isref_p(& value.u.constant);
  if (is_ref) {
    tmp___1 = 536870912;
  } else {
    tmp___1 = 1342177280;
  }
  zend_do_fetch_static_variable(varname, (znode const   *)(& value), tmp___1);
  return;
}
}
void zend_do_fetch_global_variable(znode *varname ,
                                   znode const   *static_assignment ,
                                   int fetch_type ) 
{ 
  zend_op *opline ;
  znode lval ;
  znode result ;
  int tmp ;
  ulong __attribute__((__visibility__("default")))  tmp___0 ;

  {
  if (varname->op_type == 1) {
    if ((int )varname->u.constant.type != 6) {
      if ((int )varname->u.constant.type != 6) {
        _convert_to_string(& varname->u.constant);
      } else {

      }
    } else {

    }
  } else {

  }
  opline = get_next_op(compiler_globals.active_op_array);
  opline->opcode = (zend_uchar )83;
  opline->result_type = (zend_uchar )(1 << 2);
  opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  while (1) {
    opline->op1_type = (zend_uchar )varname->op_type;
    if (varname->op_type == 1) {
      tmp = zend_add_literal(compiler_globals.active_op_array,
                             (zval const   *)(& varname->u.constant));
      opline->op1.constant = (zend_uint )tmp;
    } else {
      opline->op1 = varname->u.op;
    }
    break;
  }
  if ((int )opline->op1_type == 1) {
    while (1) {
      if ((unsigned long )((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val >= (unsigned long )compiler_globals.interned_strings_start) {
        if ((unsigned long )((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val < (unsigned long )compiler_globals.interned_strings_end) {
          ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant))->hash_value = ((Bucket *)(((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val - sizeof(Bucket )))->h;
        } else {
          tmp___0 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val,
                                   (uint )(((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.len + 1));
          ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant))->hash_value = (zend_ulong )tmp___0;
        }
      } else {
        tmp___0 = zend_hash_func((char const   *)((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.val,
                                 (uint )(((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant.value.str.len + 1));
        ((zend_literal *)(& ((compiler_globals.active_op_array)->literals + opline->op1.constant)->constant))->hash_value = (zend_ulong )tmp___0;
      }
      break;
    }
  } else {

  }
  opline->op2_type = (zend_uchar )(1 << 3);
  opline->extended_value = (ulong )fetch_type;
  while (1) {
    result.op_type = (int )opline->result_type;
    if (result.op_type == 1) {
      result.u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      result.u.op = opline->result;
      result.EA = (zend_uint )0;
    }
    break;
  }
  if (varname->op_type == 1) {
    _zval_copy_ctor(& varname->u.constant);
  } else {

  }
  fetch_simple_variable(& lval, varname, 0);
  zend_do_assign_ref((znode *)((void *)0), (znode const   *)(& lval),
                     (znode const   *)(& result));
  ((compiler_globals.active_op_array)->opcodes + ((compiler_globals.active_op_array)->last - 1U))->result_type = (zend_uchar )((int )((compiler_globals.active_op_array)->opcodes + ((compiler_globals.active_op_array)->last - 1U))->result_type | (1 << 5));
  return;
}
}
void zend_do_cast(znode *result , znode const   *expr , int type ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;
  znode_op __constr_expr_43 ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  opline->opcode = (zend_uchar )21;
  opline->result_type = (zend_uchar )(1 << 1);
  opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  while (1) {
    opline->op1_type = (zend_uchar )expr->op_type;
    if (expr->op_type == 1) {
      tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                 & expr->u.constant);
      opline->op1.constant = (zend_uint )tmp___0;
    } else {
      __constr_expr_43 = expr->u.op;
      opline->op1 = __constr_expr_43;
    }
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  opline->extended_value = (ulong )type;
  while (1) {
    result->op_type = (int )opline->result_type;
    if (result->op_type == 1) {
      result->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      result->u.op = opline->result;
      result->EA = (zend_uint )0;
    }
    break;
  }
  return;
}
}
void zend_do_include_or_eval(int type , znode *result , znode const   *op1 ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;
  znode_op __constr_expr_44 ;

  {
  zend_do_extended_fcall_begin();
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  opline->opcode = (zend_uchar )73;
  opline->result_type = (zend_uchar )(1 << 2);
  opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  while (1) {
    opline->op1_type = (zend_uchar )op1->op_type;
    if (op1->op_type == 1) {
      tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                 & op1->u.constant);
      opline->op1.constant = (zend_uint )tmp___0;
    } else {
      __constr_expr_44 = op1->u.op;
      opline->op1 = __constr_expr_44;
    }
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  opline->extended_value = (ulong )type;
  while (1) {
    result->op_type = (int )opline->result_type;
    if (result->op_type == 1) {
      result->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      result->u.op = opline->result;
      result->EA = (zend_uint )0;
    }
    break;
  }
  zend_do_extended_fcall_end();
  return;
}
}
void zend_do_indirect_references(znode *result , znode const   *num_references ,
                                 znode *variable ) 
{ 
  int i ;
  char __attribute__((__visibility__("default")))  *tmp ;
  int tmp___0 ;

  {
  zend_do_end_variable_parse(variable, 0, 0);
  i = 1;
  while ((long const   )i < num_references->u.constant.value.lval) {
    fetch_simple_variable_ex(result, variable, 0, (zend_uchar )80);
    *variable = *result;
    i ++;
  }
  zend_do_begin_variable_parse();
  fetch_simple_variable(result, variable, 1);
  if ((compiler_globals.active_op_array)->scope) {
    if ((compiler_globals.active_op_array)->this_var == 4294967295U) {
      tmp = _estrndup("this", (unsigned int )(sizeof("this") - 1UL));
      tmp___0 = lookup_cv(compiler_globals.active_op_array, (char *)tmp,
                          (int )(sizeof("this") - 1UL), 210728972157UL);
      (compiler_globals.active_op_array)->this_var = (zend_uint )tmp___0;
    } else {

    }
  } else {

  }
  return;
}
}
void zend_do_unset(znode const   *variable ) 
{ 
  zend_op *last_op ;
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;
  int tmp___1 ;
  znode_op __constr_expr_45 ;

  {
  zend_check_writable_variable(variable);
  if (variable->op_type == (int const   )(1 << 4)) {
    tmp = get_next_op(compiler_globals.active_op_array);
    opline = tmp;
    opline->opcode = (zend_uchar )74;
    while (1) {
      opline->op1_type = (zend_uchar )variable->op_type;
      if (variable->op_type == 1) {
        tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                   & variable->u.constant);
        opline->op1.constant = (zend_uint )tmp___0;
      } else {
        __constr_expr_45 = variable->u.op;
        opline->op1 = __constr_expr_45;
      }
      break;
    }
    opline->op2_type = (zend_uchar )(1 << 3);
    opline->result_type = (zend_uchar )(1 << 3);
    opline->extended_value = (ulong )276824064;
  } else {
    tmp___1 = get_next_op_number(compiler_globals.active_op_array);
    last_op = (compiler_globals.active_op_array)->opcodes + (tmp___1 - 1);
    switch ((int )last_op->opcode) {
    case 95: 
    last_op->opcode = (zend_uchar )74;
    last_op->result_type = (zend_uchar )(1 << 3);
    break;
    case 96: 
    last_op->opcode = (zend_uchar )75;
    last_op->result_type = (zend_uchar )(1 << 3);
    break;
    case 97: 
    last_op->opcode = (zend_uchar )76;
    last_op->result_type = (zend_uchar )(1 << 3);
    break;
    }
  }
  return;
}
}
void zend_do_isset_or_isempty(int type , znode *result , znode *variable ) 
{ 
  zend_op *last_op ;
  int tmp ;
  int tmp___0 ;

  {
  zend_do_end_variable_parse(variable, 3, 0);
  zend_check_writable_variable((znode const   *)variable);
  if (variable->op_type == 1 << 4) {
    last_op = get_next_op(compiler_globals.active_op_array);
    last_op->opcode = (zend_uchar )114;
    while (1) {
      last_op->op1_type = (zend_uchar )variable->op_type;
      if (variable->op_type == 1) {
        tmp = zend_add_literal(compiler_globals.active_op_array,
                               (zval const   *)(& variable->u.constant));
        last_op->op1.constant = (zend_uint )tmp;
      } else {
        last_op->op1 = variable->u.op;
      }
      break;
    }
    last_op->op2_type = (zend_uchar )(1 << 3);
    last_op->result.var = get_temporary_variable(compiler_globals.active_op_array);
    last_op->extended_value = (ulong )276824064;
  } else {
    tmp___0 = get_next_op_number(compiler_globals.active_op_array);
    last_op = (compiler_globals.active_op_array)->opcodes + (tmp___0 - 1);
    switch ((int )last_op->opcode) {
    case 89: 
    last_op->opcode = (zend_uchar )114;
    break;
    case 90: 
    last_op->opcode = (zend_uchar )115;
    break;
    case 91: 
    last_op->opcode = (zend_uchar )148;
    break;
    }
  }
  last_op->result_type = (zend_uchar )(1 << 1);
  last_op->extended_value |= (unsigned long )type;
  while (1) {
    result->op_type = (int )last_op->result_type;
    if (result->op_type == 1) {
      result->u.constant = ((compiler_globals.active_op_array)->literals + last_op->result.constant)->constant;
    } else {
      result->u.op = last_op->result;
      result->EA = (zend_uint )0;
    }
    break;
  }
  return;
}
}
void zend_do_instanceof(znode *result , znode const   *expr ,
                        znode const   *class_znode , int type ) 
{ 
  int last_op_number ;
  int tmp ;
  zend_op *opline ;
  int tmp___0 ;
  int tmp___1 ;
  znode_op __constr_expr_46 ;
  znode_op __constr_expr_47 ;

  {
  tmp = get_next_op_number(compiler_globals.active_op_array);
  last_op_number = tmp;
  if (last_op_number > 0) {
    opline = (compiler_globals.active_op_array)->opcodes + (last_op_number - 1);
    if ((int )opline->opcode == 109) {
      opline->extended_value |= 128UL;
    } else {

    }
  } else {

  }
  if (expr->op_type == 1) {
    zend_error(1 << 6L, "instanceof expects an object instance, constant given");
  } else {

  }
  opline = get_next_op(compiler_globals.active_op_array);
  opline->opcode = (zend_uchar )138;
  opline->result_type = (zend_uchar )(1 << 1);
  opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  while (1) {
    opline->op1_type = (zend_uchar )expr->op_type;
    if (expr->op_type == 1) {
      tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                 & expr->u.constant);
      opline->op1.constant = (zend_uint )tmp___0;
    } else {
      __constr_expr_46 = expr->u.op;
      opline->op1 = __constr_expr_46;
    }
    break;
  }
  while (1) {
    opline->op2_type = (zend_uchar )class_znode->op_type;
    if (class_znode->op_type == 1) {
      tmp___1 = zend_add_literal(compiler_globals.active_op_array,
                                 & class_znode->u.constant);
      opline->op2.constant = (zend_uint )tmp___1;
    } else {
      __constr_expr_47 = class_znode->u.op;
      opline->op2 = __constr_expr_47;
    }
    break;
  }
  while (1) {
    result->op_type = (int )opline->result_type;
    if (result->op_type == 1) {
      result->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      result->u.op = opline->result;
      result->EA = (zend_uint )0;
    }
    break;
  }
  return;
}
}
void zend_do_foreach_begin(znode *foreach_token , znode *open_brackets_token ,
                           znode *array , znode *as_token , int variable ) 
{ 
  zend_op *opline ;
  zend_bool is_variable ;
  zend_bool push_container ;
  zend_op dummy_opline ;
  zend_bool tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;

  {
  push_container = (zend_bool )0;
  if (variable) {
    tmp = zend_is_function_or_method_call((znode const   *)array);
    if (tmp) {
      is_variable = (zend_bool )0;
    } else {
      is_variable = (zend_bool )1;
    }
    tmp___0 = get_next_op_number(compiler_globals.active_op_array);
    open_brackets_token->u.op.opline_num = (zend_uint )tmp___0;
    zend_do_end_variable_parse(array, 1, 0);
    if ((compiler_globals.active_op_array)->last > 0U) {
      if ((int )((compiler_globals.active_op_array)->opcodes + ((compiler_globals.active_op_array)->last - 1U))->opcode == 85) {
        if ((int )((compiler_globals.active_op_array)->opcodes + ((compiler_globals.active_op_array)->last - 1U))->op1_type == 1 << 2) {
          ((compiler_globals.active_op_array)->opcodes + ((compiler_globals.active_op_array)->last - 1U))->extended_value |= 134217728UL;
          push_container = (zend_bool )1;
        } else {

        }
      } else {

      }
    } else {

    }
  } else {
    is_variable = (zend_bool )0;
    tmp___1 = get_next_op_number(compiler_globals.active_op_array);
    open_brackets_token->u.op.opline_num = (zend_uint )tmp___1;
  }
  tmp___2 = get_next_op_number(compiler_globals.active_op_array);
  foreach_token->u.op.opline_num = (zend_uint )tmp___2;
  opline = get_next_op(compiler_globals.active_op_array);
  opline->opcode = (zend_uchar )77;
  opline->result_type = (zend_uchar )(1 << 2);
  opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  while (1) {
    opline->op1_type = (zend_uchar )array->op_type;
    if (array->op_type == 1) {
      tmp___3 = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& array->u.constant));
      opline->op1.constant = (zend_uint )tmp___3;
    } else {
      opline->op1 = array->u.op;
    }
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  if (is_variable) {
    opline->extended_value = (ulong )1;
  } else {
    opline->extended_value = (ulong )0;
  }
  while (1) {
    dummy_opline.result_type = opline->result_type;
    dummy_opline.result = opline->result;
    break;
  }
  if (push_container) {
    while (1) {
      dummy_opline.op1_type = ((compiler_globals.active_op_array)->opcodes + ((compiler_globals.active_op_array)->last - 2U))->op1_type;
      dummy_opline.op1 = ((compiler_globals.active_op_array)->opcodes + ((compiler_globals.active_op_array)->last - 2U))->op1;
      break;
    }
  } else {
    dummy_opline.op1_type = (zend_uchar )(1 << 3);
  }
  zend_stack_push(& compiler_globals.foreach_copy_stack,
                  (void const   *)((void *)(& dummy_opline)),
                  (int )sizeof(zend_op ));
  tmp___4 = get_next_op_number(compiler_globals.active_op_array);
  as_token->u.op.opline_num = (zend_uint )tmp___4;
  opline = get_next_op(compiler_globals.active_op_array);
  opline->opcode = (zend_uchar )78;
  opline->result_type = (zend_uchar )(1 << 2);
  opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  while (1) {
    opline->op1_type = dummy_opline.result_type;
    opline->op1 = dummy_opline.result;
    break;
  }
  opline->extended_value = (ulong )0;
  opline->op2_type = (zend_uchar )(1 << 3);
  opline = get_next_op(compiler_globals.active_op_array);
  opline->opcode = (zend_uchar )137;
  opline->op1_type = (zend_uchar )(1 << 3);
  opline->op2_type = (zend_uchar )(1 << 3);
  opline->result_type = (zend_uchar )(1 << 3);
  return;
}
}
void zend_do_foreach_cont(znode *foreach_token ,
                          znode const   *open_brackets_token ,
                          znode const   *as_token , znode *value , znode *key ) 
{ 
  zend_op *opline ;
  znode dummy ;
  znode value_node ;
  zend_bool assign_by_ref ;
  znode *tmp ;
  zend_op *foreach_copy ;
  zend_op *fetch ;
  zend_op *end ;
  zend_uchar tmp___0 ;
  zend_uchar tmp___1 ;
  znode key_node ;

  {
  assign_by_ref = (zend_bool )0;
  opline = (compiler_globals.active_op_array)->opcodes + as_token->u.op.opline_num;
  if (key->op_type != 1 << 3) {
    tmp = key;
    key = value;
    value = tmp;
    opline->extended_value |= 2UL;
  } else {

  }
  if (key->op_type != 1 << 3) {
    if (key->EA & (unsigned int )(1 << 5)) {
      zend_error(1 << 6L, "Key element cannot be a reference");
    } else {

    }
  } else {

  }
  if (value->EA & (unsigned int )(1 << 5)) {
    assign_by_ref = (zend_bool )1;
    if (! (opline - 1)->extended_value) {
      zend_error(1 << 6L,
                 "Cannot create references to elements of a temporary array expression");
    } else {

    }
    opline->extended_value |= 1UL;
    ((compiler_globals.active_op_array)->opcodes + foreach_token->u.op.opline_num)->extended_value |= (unsigned long )(1 << 1);
  } else {
    fetch = (compiler_globals.active_op_array)->opcodes + foreach_token->u.op.opline_num;
    end = (compiler_globals.active_op_array)->opcodes + open_brackets_token->u.op.opline_num;
    fetch->extended_value = (ulong )0;
    while ((unsigned long )fetch != (unsigned long )end) {
      fetch --;
      if ((int )fetch->opcode == 84) {
        if ((int )fetch->op2_type == 1 << 3) {
          zend_error(1 << 6L, "Cannot use [] for reading");
        } else {

        }
      } else {

      }
      if ((int )fetch->opcode == 156) {
        fetch->opcode = (zend_uchar )0;
        memset((void *)(& fetch->result), 0, sizeof(fetch->result));
        memset((void *)(& fetch->op1), 0, sizeof(fetch->op1));
        memset((void *)(& fetch->op2), 0, sizeof(fetch->op2));
        tmp___1 = (zend_uchar )(1 << 3);
        fetch->op2_type = tmp___1;
        tmp___0 = tmp___1;
        fetch->op1_type = tmp___0;
        fetch->result_type = tmp___0;
      } else {
        fetch->opcode = (zend_uchar )((int )fetch->opcode - 3);
      }
    }
    zend_stack_top((zend_stack const   *)(& compiler_globals.foreach_copy_stack),
                   (void **)(& foreach_copy));
    foreach_copy->op1_type = (zend_uchar )(1 << 3);
  }
  while (1) {
    value_node.op_type = (int )opline->result_type;
    if (value_node.op_type == 1) {
      value_node.u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      value_node.u.op = opline->result;
      value_node.EA = (zend_uint )0;
    }
    break;
  }
  if (assign_by_ref) {
    zend_do_end_variable_parse(value, 1, 0);
    zend_do_assign_ref((znode *)((void *)0), (znode const   *)value,
                       (znode const   *)(& value_node));
  } else {
    zend_do_assign(& dummy, value, & value_node);
    zend_do_free(& dummy);
  }
  if (key->op_type != 1 << 3) {
    opline = (compiler_globals.active_op_array)->opcodes + (as_token->u.op.opline_num + 1U);
    opline->result_type = (zend_uchar )(1 << 1);
    opline->result.opline_num = get_temporary_variable(compiler_globals.active_op_array);
    while (1) {
      key_node.op_type = (int )opline->result_type;
      if (key_node.op_type == 1) {
        key_node.u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
      } else {
        key_node.u.op = opline->result;
        key_node.EA = (zend_uint )0;
      }
      break;
    }
    zend_do_assign(& dummy, key, & key_node);
    zend_do_free(& dummy);
  } else {

  }
  do_begin_loop();
  if ((compiler_globals.active_op_array)->fn_flags & 16U) {
    (compiler_globals.context.backpatch_count) ++;
  } else {

  }
  return;
}
}
void zend_do_foreach_end(znode const   *foreach_token , znode const   *as_token ) 
{ 
  zend_op *container_ptr ;
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;
  int tmp___1 ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  opline->opcode = (zend_uchar )42;
  opline->op1.opline_num = (zend_uint )as_token->u.op.opline_num;
  opline->op1_type = (zend_uchar )(1 << 3);
  opline->op2_type = (zend_uchar )(1 << 3);
  tmp___0 = get_next_op_number(compiler_globals.active_op_array);
  ((compiler_globals.active_op_array)->opcodes + foreach_token->u.op.opline_num)->op2.opline_num = (zend_uint )tmp___0;
  tmp___1 = get_next_op_number(compiler_globals.active_op_array);
  ((compiler_globals.active_op_array)->opcodes + as_token->u.op.opline_num)->op2.opline_num = (zend_uint )tmp___1;
  do_end_loop((int )as_token->u.op.opline_num, 1);
  zend_stack_top((zend_stack const   *)(& compiler_globals.foreach_copy_stack),
                 (void **)(& container_ptr));
  generate_free_foreach_copy((zend_op const   *)container_ptr);
  zend_stack_del_top(& compiler_globals.foreach_copy_stack);
  if ((compiler_globals.active_op_array)->fn_flags & 16U) {
    (compiler_globals.context.backpatch_count) --;
  } else {

  }
  return;
}
}
void zend_do_declare_begin(void) 
{ 


  {
  zend_stack_push(& compiler_globals.declare_stack,
                  (void const   *)(& compiler_globals.declarables),
                  (int )sizeof(zend_declarables ));
  return;
}
}
void zend_do_declare_stmt(znode *var , znode *val ) 
{ 
  int num ;
  zend_encoding const   *new_encoding ;
  zend_encoding const   *old_encoding ;
  size_t (*old_input_filter)(unsigned char **str , size_t *str_length ,
                             unsigned char const   *buf , size_t length ) ;
  zend_encoding const __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;

  {
  tmp___1 = zend_binary_strcasecmp((char const   *)var->u.constant.value.str.val,
                                   (uint )var->u.constant.value.str.len,
                                   "ticks", (uint )(sizeof("ticks") - 1UL));
  if (tmp___1) {
    tmp___0 = zend_binary_strcasecmp((char const   *)var->u.constant.value.str.val,
                                     (uint )var->u.constant.value.str.len,
                                     "encoding",
                                     (uint )(sizeof("encoding") - 1UL));
    if (tmp___0) {
      zend_error(1 << 7L, "Unsupported declare \'%s\'",
                 var->u.constant.value.str.val);
      _zval_dtor(& val->u.constant);
    } else {
      if (((int )val->u.constant.type & 15) == 8) {
        zend_error(1 << 6L, "Cannot use constants as encoding");
      } else {

      }
      num = (int )(compiler_globals.active_op_array)->last;
      while (1) {
        if (num > 0) {
          if (! ((int )((compiler_globals.active_op_array)->opcodes + (num - 1))->opcode == 101)) {
            if (! ((int )((compiler_globals.active_op_array)->opcodes + (num - 1))->opcode == 105)) {
              break;
            } else {

            }
          } else {

          }
        } else {
          break;
        }
        num --;
      }
      if (num > 0) {
        zend_error(1 << 6L,
                   "Encoding declaration pragma must be the very first statement in the script");
      } else {

      }
      if (compiler_globals.multibyte) {
        compiler_globals.encoding_declared = (zend_bool )1;
        if ((int )val->u.constant.type != 6) {
          _convert_to_string(& val->u.constant);
        } else {

        }
        tmp = zend_multibyte_fetch_encoding((char const   *)val->u.constant.value.str.val);
        new_encoding = (zend_encoding const   *)tmp;
        if (! new_encoding) {
          zend_error(1 << 7L, "Unsupported encoding [%s]",
                     val->u.constant.value.str.val);
        } else {
          old_input_filter = language_scanner_globals.input_filter;
          old_encoding = language_scanner_globals.script_encoding;
          zend_multibyte_set_filter(new_encoding);
          if ((unsigned long )old_input_filter != (unsigned long )language_scanner_globals.input_filter) {
            zend_multibyte_yyinput_again(old_input_filter, old_encoding);
          } else
          if (old_input_filter) {
            if ((unsigned long )new_encoding != (unsigned long )old_encoding) {
              zend_multibyte_yyinput_again(old_input_filter, old_encoding);
            } else {

            }
          } else {

          }
        }
      } else {
        zend_error(1 << 7L,
                   "declare(encoding=...) ignored because Zend multibyte feature is turned off by settings");
      }
      _zval_dtor(& val->u.constant);
    }
  } else {
    convert_to_long(& val->u.constant);
    compiler_globals.declarables.ticks = val->u.constant;
  }
  _zval_dtor(& var->u.constant);
  return;
}
}
void zend_do_declare_end(znode const   *declare_token ) 
{ 
  zend_declarables *declarables ;
  int tmp ;
  int tmp___0 ;

  {
  zend_stack_top((zend_stack const   *)(& compiler_globals.declare_stack),
                 (void **)(& declarables));
  tmp = get_next_op_number(compiler_globals.active_op_array);
  if (compiler_globals.declarables.ticks.value.lval) {
    tmp___0 = 1;
  } else {
    tmp___0 = 0;
  }
  if (((zend_uint const   )tmp - declare_token->u.op.opline_num) - (zend_uint const   )tmp___0) {
    compiler_globals.declarables = *declarables;
  } else {

  }
  return;
}
}
void zend_do_exit(znode *result , znode const   *message ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;
  znode_op __constr_expr_48 ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  opline->opcode = (zend_uchar )79;
  while (1) {
    opline->op1_type = (zend_uchar )message->op_type;
    if (message->op_type == 1) {
      tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                 & message->u.constant);
      opline->op1.constant = (zend_uint )tmp___0;
    } else {
      __constr_expr_48 = message->u.op;
      opline->op1 = __constr_expr_48;
    }
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  result->op_type = 1;
  result->u.constant.type = (zend_uchar )3;
  result->u.constant.value.lval = 1L;
  return;
}
}
void zend_do_begin_silence(znode *strudel_token ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  opline->opcode = (zend_uchar )57;
  opline->result_type = (zend_uchar )(1 << 1);
  opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  opline->op1_type = (zend_uchar )(1 << 3);
  opline->op2_type = (zend_uchar )(1 << 3);
  while (1) {
    strudel_token->op_type = (int )opline->result_type;
    if (strudel_token->op_type == 1) {
      strudel_token->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      strudel_token->u.op = opline->result;
      strudel_token->EA = (zend_uint )0;
    }
    break;
  }
  return;
}
}
void zend_do_end_silence(znode const   *strudel_token ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;
  znode_op __constr_expr_49 ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  opline->opcode = (zend_uchar )58;
  while (1) {
    opline->op1_type = (zend_uchar )strudel_token->op_type;
    if (strudel_token->op_type == 1) {
      tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                 & strudel_token->u.constant);
      opline->op1.constant = (zend_uint )tmp___0;
    } else {
      __constr_expr_49 = strudel_token->u.op;
      opline->op1 = __constr_expr_49;
    }
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  return;
}
}
void zend_do_jmp_set(znode const   *value , znode *jmp_token ,
                     znode *colon_token ) 
{ 
  int op_number ;
  int tmp ;
  zend_op *opline ;
  zend_op *tmp___0 ;
  int tmp___1 ;
  znode_op __constr_expr_50 ;

  {
  tmp = get_next_op_number(compiler_globals.active_op_array);
  op_number = tmp;
  tmp___0 = get_next_op(compiler_globals.active_op_array);
  opline = tmp___0;
  if (value->op_type == (int const   )(1 << 2)) {
    opline->opcode = (zend_uchar )158;
    opline->result_type = (zend_uchar )(1 << 2);
  } else
  if (value->op_type == (int const   )(1 << 4)) {
    opline->opcode = (zend_uchar )158;
    opline->result_type = (zend_uchar )(1 << 2);
  } else {
    opline->opcode = (zend_uchar )152;
    opline->result_type = (zend_uchar )(1 << 1);
  }
  opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  while (1) {
    opline->op1_type = (zend_uchar )value->op_type;
    if (value->op_type == 1) {
      tmp___1 = zend_add_literal(compiler_globals.active_op_array,
                                 & value->u.constant);
      opline->op1.constant = (zend_uint )tmp___1;
    } else {
      __constr_expr_50 = value->u.op;
      opline->op1 = __constr_expr_50;
    }
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  while (1) {
    colon_token->op_type = (int )opline->result_type;
    if (colon_token->op_type == 1) {
      colon_token->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      colon_token->u.op = opline->result;
      colon_token->EA = (zend_uint )0;
    }
    break;
  }
  jmp_token->u.op.opline_num = (zend_uint )op_number;
  if ((compiler_globals.active_op_array)->fn_flags & 16U) {
    (compiler_globals.context.backpatch_count) ++;
  } else {

  }
  return;
}
}
void zend_do_jmp_set_else(znode *result , znode const   *false_value ,
                          znode const   *jmp_token , znode const   *colon_token ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  znode_op __constr_expr_51 ;
  znode_op __constr_expr_52 ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  while (1) {
    opline->result_type = (zend_uchar )colon_token->op_type;
    if (colon_token->op_type == 1) {
      tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                 & colon_token->u.constant);
      opline->result.constant = (zend_uint )tmp___0;
    } else {
      __constr_expr_51 = colon_token->u.op;
      opline->result = __constr_expr_51;
    }
    break;
  }
  if (colon_token->op_type == (int const   )(1 << 1)) {
    if (false_value->op_type == (int const   )(1 << 2)) {
      ((compiler_globals.active_op_array)->opcodes + jmp_token->u.op.opline_num)->opcode = (zend_uchar )158;
      ((compiler_globals.active_op_array)->opcodes + jmp_token->u.op.opline_num)->result_type = (zend_uchar )(1 << 2);
      opline->opcode = (zend_uchar )157;
      opline->result_type = (zend_uchar )(1 << 2);
    } else
    if (false_value->op_type == (int const   )(1 << 4)) {
      ((compiler_globals.active_op_array)->opcodes + jmp_token->u.op.opline_num)->opcode = (zend_uchar )158;
      ((compiler_globals.active_op_array)->opcodes + jmp_token->u.op.opline_num)->result_type = (zend_uchar )(1 << 2);
      opline->opcode = (zend_uchar )157;
      opline->result_type = (zend_uchar )(1 << 2);
    } else {
      opline->opcode = (zend_uchar )22;
    }
  } else {
    opline->opcode = (zend_uchar )157;
  }
  opline->extended_value = (ulong )0;
  while (1) {
    opline->op1_type = (zend_uchar )false_value->op_type;
    if (false_value->op_type == 1) {
      tmp___1 = zend_add_literal(compiler_globals.active_op_array,
                                 & false_value->u.constant);
      opline->op1.constant = (zend_uint )tmp___1;
    } else {
      __constr_expr_52 = false_value->u.op;
      opline->op1 = __constr_expr_52;
    }
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  while (1) {
    result->op_type = (int )opline->result_type;
    if (result->op_type == 1) {
      result->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      result->u.op = opline->result;
      result->EA = (zend_uint )0;
    }
    break;
  }
  tmp___2 = get_next_op_number(compiler_globals.active_op_array);
  ((compiler_globals.active_op_array)->opcodes + jmp_token->u.op.opline_num)->op2.opline_num = (zend_uint )tmp___2;
  if ((compiler_globals.active_op_array)->fn_flags & 16U) {
    (compiler_globals.context.backpatch_count) --;
  } else {

  }
  return;
}
}
void zend_do_begin_qm_op(znode const   *cond , znode *qm_token ) 
{ 
  int jmpz_op_number ;
  int tmp ;
  zend_op *opline ;
  int tmp___0 ;
  znode_op __constr_expr_53 ;

  {
  tmp = get_next_op_number(compiler_globals.active_op_array);
  jmpz_op_number = tmp;
  opline = get_next_op(compiler_globals.active_op_array);
  opline->opcode = (zend_uchar )43;
  while (1) {
    opline->op1_type = (zend_uchar )cond->op_type;
    if (cond->op_type == 1) {
      tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                 & cond->u.constant);
      opline->op1.constant = (zend_uint )tmp___0;
    } else {
      __constr_expr_53 = cond->u.op;
      opline->op1 = __constr_expr_53;
    }
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  opline->op2.opline_num = (zend_uint )jmpz_op_number;
  while (1) {
    qm_token->op_type = (int )opline->op2_type;
    if (qm_token->op_type == 1) {
      qm_token->u.constant = ((compiler_globals.active_op_array)->literals + opline->op2.constant)->constant;
    } else {
      qm_token->u.op = opline->op2;
      qm_token->EA = (zend_uint )0;
    }
    break;
  }
  if ((compiler_globals.active_op_array)->fn_flags & 16U) {
    (compiler_globals.context.backpatch_count) ++;
  } else {

  }
  return;
}
}
void zend_do_qm_true(znode const   *true_value , znode *qm_token ,
                     znode *colon_token ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  znode_op __constr_expr_54 ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  tmp___0 = get_next_op_number(compiler_globals.active_op_array);
  ((compiler_globals.active_op_array)->opcodes + qm_token->u.op.opline_num)->op2.opline_num = (zend_uint )(tmp___0 + 1);
  if (true_value->op_type == (int const   )(1 << 2)) {
    opline->opcode = (zend_uchar )157;
    opline->result_type = (zend_uchar )(1 << 2);
  } else
  if (true_value->op_type == (int const   )(1 << 4)) {
    opline->opcode = (zend_uchar )157;
    opline->result_type = (zend_uchar )(1 << 2);
  } else {
    opline->opcode = (zend_uchar )22;
    opline->result_type = (zend_uchar )(1 << 1);
  }
  opline->result.var = get_temporary_variable(compiler_globals.active_op_array);
  while (1) {
    opline->op1_type = (zend_uchar )true_value->op_type;
    if (true_value->op_type == 1) {
      tmp___1 = zend_add_literal(compiler_globals.active_op_array,
                                 & true_value->u.constant);
      opline->op1.constant = (zend_uint )tmp___1;
    } else {
      __constr_expr_54 = true_value->u.op;
      opline->op1 = __constr_expr_54;
    }
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  while (1) {
    qm_token->op_type = (int )opline->result_type;
    if (qm_token->op_type == 1) {
      qm_token->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      qm_token->u.op = opline->result;
      qm_token->EA = (zend_uint )0;
    }
    break;
  }
  tmp___2 = get_next_op_number(compiler_globals.active_op_array);
  colon_token->u.op.opline_num = (zend_uint )tmp___2;
  opline = get_next_op(compiler_globals.active_op_array);
  opline->opcode = (zend_uchar )42;
  opline->op1_type = (zend_uchar )(1 << 3);
  opline->op2_type = (zend_uchar )(1 << 3);
  return;
}
}
void zend_do_qm_false(znode *result , znode const   *false_value ,
                      znode const   *qm_token , znode const   *colon_token ) 
{ 
  zend_op *opline ;
  zend_op *tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  znode_op __constr_expr_55 ;
  znode_op __constr_expr_56 ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  while (1) {
    opline->result_type = (zend_uchar )qm_token->op_type;
    if (qm_token->op_type == 1) {
      tmp___0 = zend_add_literal(compiler_globals.active_op_array,
                                 & qm_token->u.constant);
      opline->result.constant = (zend_uint )tmp___0;
    } else {
      __constr_expr_55 = qm_token->u.op;
      opline->result = __constr_expr_55;
    }
    break;
  }
  if (qm_token->op_type == (int const   )(1 << 1)) {
    if (false_value->op_type == (int const   )(1 << 2)) {
      ((compiler_globals.active_op_array)->opcodes + (colon_token->u.op.opline_num - 1U))->opcode = (zend_uchar )157;
      ((compiler_globals.active_op_array)->opcodes + (colon_token->u.op.opline_num - 1U))->result_type = (zend_uchar )(1 << 2);
      opline->opcode = (zend_uchar )157;
      opline->result_type = (zend_uchar )(1 << 2);
    } else
    if (false_value->op_type == (int const   )(1 << 4)) {
      ((compiler_globals.active_op_array)->opcodes + (colon_token->u.op.opline_num - 1U))->opcode = (zend_uchar )157;
      ((compiler_globals.active_op_array)->opcodes + (colon_token->u.op.opline_num - 1U))->result_type = (zend_uchar )(1 << 2);
      opline->opcode = (zend_uchar )157;
      opline->result_type = (zend_uchar )(1 << 2);
    } else {
      opline->opcode = (zend_uchar )22;
    }
  } else {
    opline->opcode = (zend_uchar )157;
  }
  while (1) {
    opline->op1_type = (zend_uchar )false_value->op_type;
    if (false_value->op_type == 1) {
      tmp___1 = zend_add_literal(compiler_globals.active_op_array,
                                 & false_value->u.constant);
      opline->op1.constant = (zend_uint )tmp___1;
    } else {
      __constr_expr_56 = false_value->u.op;
      opline->op1 = __constr_expr_56;
    }
    break;
  }
  opline->op2_type = (zend_uchar )(1 << 3);
  tmp___2 = get_next_op_number(compiler_globals.active_op_array);
  ((compiler_globals.active_op_array)->opcodes + colon_token->u.op.opline_num)->op1.opline_num = (zend_uint )tmp___2;
  while (1) {
    result->op_type = (int )opline->result_type;
    if (result->op_type == 1) {
      result->u.constant = ((compiler_globals.active_op_array)->literals + opline->result.constant)->constant;
    } else {
      result->u.op = opline->result;
      result->EA = (zend_uint )0;
    }
    break;
  }
  if ((compiler_globals.active_op_array)->fn_flags & 16U) {
    (compiler_globals.context.backpatch_count) --;
  } else {

  }
  return;
}
}
void zend_do_extended_info(void) 
{ 
  zend_op *opline ;

  {
  if (! (compiler_globals.compiler_options & 1U)) {
    return;
  } else {

  }
  opline = get_next_op(compiler_globals.active_op_array);
  opline->opcode = (zend_uchar )101;
  opline->op1_type = (zend_uchar )(1 << 3);
  opline->op2_type = (zend_uchar )(1 << 3);
  return;
}
}
void zend_do_extended_fcall_begin(void) 
{ 
  zend_op *opline ;

  {
  if (! (compiler_globals.compiler_options & 1U)) {
    return;
  } else {

  }
  opline = get_next_op(compiler_globals.active_op_array);
  opline->opcode = (zend_uchar )102;
  opline->op1_type = (zend_uchar )(1 << 3);
  opline->op2_type = (zend_uchar )(1 << 3);
  return;
}
}
void zend_do_extended_fcall_end(void) 
{ 
  zend_op *opline ;

  {
  if (! (compiler_globals.compiler_options & 1U)) {
    return;
  } else {

  }
  opline = get_next_op(compiler_globals.active_op_array);
  opline->opcode = (zend_uchar )103;
  opline->op1_type = (zend_uchar )(1 << 3);
  opline->op2_type = (zend_uchar )(1 << 3);
  return;
}
}
void zend_do_ticks(void) 
{ 
  zend_op *opline ;
  zend_op *tmp ;

  {
  tmp = get_next_op(compiler_globals.active_op_array);
  opline = tmp;
  opline->opcode = (zend_uchar )105;
  opline->op1_type = (zend_uchar )(1 << 3);
  opline->op2_type = (zend_uchar )(1 << 3);
  opline->extended_value = (ulong )compiler_globals.declarables.ticks.value.lval;
  return;
}
}
zend_bool __attribute__((__visibility__("default")))  zend_is_auto_global_quick(char const   *name ,
                                                                                uint name_len ,
                                                                                ulong hashval ) 
{ 
  zend_auto_global *auto_global ;
  ulong hash ;
  ulong __attribute__((__visibility__("default")))  tmp ;
  ulong tmp___0 ;
  int __attribute__((__visibility__("default")))  tmp___1 ;

  {
  if (hashval) {
    tmp___0 = hashval;
  } else {
    tmp = zend_hash_func(name, name_len + 1U);
    tmp___0 = (ulong )tmp;
  }
  hash = tmp___0;
  tmp___1 = zend_hash_quick_find((HashTable const   *)compiler_globals.auto_globals,
                                 name, name_len + 1U, hash,
                                 (void **)(& auto_global));
  if (tmp___1 == (int __attribute__((__visibility__("default")))  )0) {
    if (auto_global->armed) {
      auto_global->armed = (*(auto_global->auto_global_callback))(auto_global->name,
                                                                  auto_global->name_len);
    } else {

    }
    return ((zend_bool __attribute__((__visibility__("default")))  )1);
  } else {

  }
  return ((zend_bool __attribute__((__visibility__("default")))  )0);
}
}
zend_bool __attribute__((__visibility__("default")))  zend_is_auto_global(char const   *name ,
                                                                          uint name_len ) 
{ 
  zend_bool __attribute__((__visibility__("default")))  tmp ;

  {
  tmp = zend_is_auto_global_quick(name, name_len, (ulong )0);
  return (tmp);
}
}
int __attribute__((__visibility__("default")))  zend_register_auto_global(char const   *name ,
                                                                          uint name_len ,
                                                                          zend_bool jit ,
                                                                          zend_bool (*auto_global_callback)(char const   *name ,
                                                                                                            uint name_len ) ) 
{ 
  zend_auto_global auto_global ;
  char const __attribute__((__visibility__("default")))  *tmp ;
  int __attribute__((__visibility__("default")))  tmp___0 ;

  {
  tmp = (*zend_new_interned_string)((char const   *)((char *)name),
                                    (int )(name_len + 1U), 0);
  auto_global.name = (char const   *)tmp;
  auto_global.name_len = name_len;
  auto_global.auto_global_callback = auto_global_callback;
  auto_global.jit = jit;
  tmp___0 = _zend_hash_add_or_update(compiler_globals.auto_globals, name,
                                     name_len + 1U, (void *)(& auto_global),
                                     (uint )sizeof(zend_auto_global ),
                                     (void **)((void *)0), 1 << 1);
  return (tmp___0);
}
}
static int zend_auto_global_init(zend_auto_global *auto_global ) 
{ 


  {
  if (auto_global->jit) {
    auto_global->armed = (zend_bool )1;
  } else
  if (auto_global->auto_global_callback) {
    auto_global->armed = (*(auto_global->auto_global_callback))(auto_global->name,
                                                                auto_global->name_len);
  } else {
    auto_global->armed = (zend_bool )0;
  }
  return (0);
}
}
void __attribute__((__visibility__("default")))  zend_activate_auto_globals(void) 
{ 


  {
  zend_hash_apply(compiler_globals.auto_globals,
                  (int (*)(void *pDest ))(& zend_auto_global_init));
  return;
}
}
int zendlex(znode *zendlval ) 
{ 
  int retval ;
  int __attribute__((__visibility__("default")))  tmp ;

  {
  if (compiler_globals.increment_lineno) {
    (compiler_globals.zend_lineno) ++;
    compiler_globals.increment_lineno = (zend_bool )0;
  } else {

  }
  again: 
  zendlval->u.constant.type = (zend_uchar )1;
  tmp = lex_scan(& zendlval->u.constant);
  retval = (int )tmp;
  switch (retval) {
  case 370: 
  case 371: 
  case 372: 
  case 375: 
  goto again;
  case 374: 
  if ((int )*(language_scanner_globals.yy_text + (language_scanner_globals.yy_leng - 1U)) != 62) {
    compiler_globals.increment_lineno = (zend_bool )1;
  } else {

  }
  if (compiler_globals.has_bracketed_namespaces) {
    if (! compiler_globals.in_namespace) {
      goto again;
    } else {

    }
  } else {

  }
  retval = ';';
  break;
  case 373: 
  retval = 316;
  break;
  case 377: 
  _efree((void *)zendlval->u.constant.value.str.val);
  break;
  }
  zendlval->u.constant.refcount__gc = (zend_uint )1;
  zendlval->u.constant.is_ref__gc = (zend_uchar )0;
  zendlval->op_type = 1;
  return (retval);
}
}
void __attribute__((__visibility__("default")))  zend_initialize_class_data(zend_class_entry *ce ,
                                                                            zend_bool nullify_handlers ) 
{ 
  zend_bool persistent_hashes ;
  int tmp ;
  void (*zval_ptr_dtor_func)(void *pDest ) ;
  void (*tmp___0)(void * ) ;
  void (*tmp___1)(zend_property_info *property_info ) ;

  {
  if ((int )ce->type == 1) {
    tmp = 1;
  } else {
    tmp = 0;
  }
  persistent_hashes = (zend_bool )tmp;
  if (persistent_hashes) {
    tmp___0 = (void (*)(void * ))(& _zval_internal_ptr_dtor);
  } else {
    tmp___0 = (void (*)(void * ))(& _zval_ptr_dtor);
  }
  zval_ptr_dtor_func = tmp___0;
  ce->refcount = 1;
  ce->ce_flags = (zend_uint )0;
  ce->default_properties_table = (zval **)((void *)0);
  ce->default_static_members_table = (zval **)((void *)0);
  if (persistent_hashes) {
    tmp___1 = & zend_destroy_property_info_internal;
  } else {
    tmp___1 = & zend_destroy_property_info;
  }
  _zend_hash_init_ex(& ce->properties_info, (uint )0,
                     (ulong (*)(char const   *arKey , uint nKeyLength ))((void *)0),
                     (void (*)(void *pDest ))tmp___1, persistent_hashes,
                     (zend_bool )0);
  _zend_hash_init_ex(& ce->constants_table, (uint )0,
                     (ulong (*)(char const   *arKey , uint nKeyLength ))((void *)0),
                     zval_ptr_dtor_func, persistent_hashes, (zend_bool )0);
  _zend_hash_init_ex(& ce->function_table, (uint )0,
                     (ulong (*)(char const   *arKey , uint nKeyLength ))((void *)0),
                     (void (*)(void * ))(& zend_function_dtor),
                     persistent_hashes, (zend_bool )0);
  if ((int )ce->type == 1) {
    ce->static_members_table = (zval **)((void *)0);
  } else {
    ce->static_members_table = ce->default_static_members_table;
    ce->info.user.doc_comment = (char const   *)((void *)0);
    ce->info.user.doc_comment_len = (zend_uint )0;
  }
  ce->default_properties_count = 0;
  ce->default_static_members_count = 0;
  if (nullify_handlers) {
    ce->constructor = (union _zend_function *)((void *)0);
    ce->destructor = (union _zend_function *)((void *)0);
    ce->clone = (union _zend_function *)((void *)0);
    ce->__get = (union _zend_function *)((void *)0);
    ce->__set = (union _zend_function *)((void *)0);
    ce->__unset = (union _zend_function *)((void *)0);
    ce->__isset = (union _zend_function *)((void *)0);
    ce->__call = (union _zend_function *)((void *)0);
    ce->__callstatic = (union _zend_function *)((void *)0);
    ce->__tostring = (union _zend_function *)((void *)0);
    ce->create_object = (zend_object_value (*)(zend_class_entry *class_type ))((void *)0);
    ce->get_iterator = (zend_object_iterator *(*)(zend_class_entry *ce ,
                                                  zval *object , int by_ref ))((void *)0);
    ce->iterator_funcs.funcs = (zend_object_iterator_funcs *)((void *)0);
    ce->interface_gets_implemented = (int (*)(zend_class_entry *iface ,
                                              zend_class_entry *class_type ))((void *)0);
    ce->get_static_method = (union _zend_function *(*)(zend_class_entry *ce ,
                                                       char *method ,
                                                       int method_len ))((void *)0);
    ce->parent = (struct _zend_class_entry *)((void *)0);
    ce->num_interfaces = (zend_uint )0;
    ce->interfaces = (zend_class_entry **)((void *)0);
    ce->num_traits = (zend_uint )0;
    ce->traits = (zend_class_entry **)((void *)0);
    ce->trait_aliases = (zend_trait_alias **)((void *)0);
    ce->trait_precedences = (zend_trait_precedence **)((void *)0);
    ce->serialize = (int (*)(zval *object , unsigned char **buffer ,
                             zend_uint *buf_len , zend_serialize_data *data ))((void *)0);
    ce->unserialize = (int (*)(zval **object , zend_class_entry *ce ,
                               unsigned char const   *buf , zend_uint buf_len ,
                               zend_unserialize_data *data ))((void *)0);
    ce->serialize_func = (union _zend_function *)((void *)0);
    ce->unserialize_func = (union _zend_function *)((void *)0);
    if ((int )ce->type == 1) {
      ce->info.internal.module = (struct _zend_module_entry *)((void *)0);
      ce->info.internal.builtin_functions = (struct _zend_function_entry  const  *)((void *)0);
    } else {

    }
  } else {

  }
  return;
}
}
int zend_get_class_fetch_type(char const   *class_name , uint class_name_len ) 
{ 
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;

  {
  if ((unsigned long )class_name_len == sizeof("self") - 1UL) {
    tmp___1 = memcmp((void const   *)class_name, (void const   *)"self",
                     sizeof("self") - 1UL);
    if (tmp___1) {
      goto _L___0;
    } else {
      return (1);
    }
  } else
  _L___0: 
  if ((unsigned long )class_name_len == sizeof("parent") - 1UL) {
    tmp___0 = memcmp((void const   *)class_name, (void const   *)"parent",
                     sizeof("parent") - 1UL);
    if (tmp___0) {
      goto _L;
    } else {
      return (2);
    }
  } else
  _L: 
  if ((unsigned long )class_name_len == sizeof("static") - 1UL) {
    tmp = memcmp((void const   *)class_name, (void const   *)"static",
                 sizeof("static") - 1UL);
    if (tmp) {
      return (0);
    } else {
      return (7);
    }
  } else {
    return (0);
  }
}
}
char const __attribute__((__visibility__("default")))  *zend_get_compiled_variable_name(zend_op_array const   *op_array ,
                                                                                        zend_uint var ,
                                                                                        int *name_len ) 
{ 


  {
  if (name_len) {
    *name_len = (op_array->vars + var)->name_len;
  } else {

  }
  return ((char const __attribute__((__visibility__("default")))  *)(op_array->vars + var)->name);
}
}
void zend_do_build_namespace_name(znode *result , znode *prefix , znode *name ) 
{ 
  znode tmp ;

  {
  if (prefix) {
    *result = *prefix;
    if ((int )result->u.constant.type == 6) {
      if (result->u.constant.value.str.len == 0) {
        if (compiler_globals.current_namespace) {
          _zval_dtor(& result->u.constant);
          tmp.op_type = 1;
          tmp.u.constant = *(compiler_globals.current_namespace);
          _zval_copy_ctor(& tmp.u.constant);
          zend_do_build_namespace_name(result, (znode *)((void *)0), & tmp);
        } else {

        }
      } else {

      }
    } else {

    }
  } else {
    result->op_type = 1;
    result->u.constant.type = (zend_uchar )6;
    result->u.constant.value.str.val = (char *)((void *)0);
    result->u.constant.value.str.len = 0;
  }
  zend_do_build_full_name((znode *)((void *)0), result, name, 0);
  return;
}
}
void zend_do_begin_namespace(znode const   *name , zend_bool with_bracket ) 
{ 
  char *lcname ;
  int num ;
  char __attribute__((__visibility__("default")))  *tmp ;
  int tmp___0 ;
  int tmp___1 ;
  void __attribute__((__visibility__("default")))  *tmp___2 ;

  {
  if (! compiler_globals.has_bracketed_namespaces) {
    if (compiler_globals.current_namespace) {
      if (with_bracket) {
        zend_error(1 << 6L,
                   "Cannot mix bracketed namespace declarations with unbracketed namespace declarations");
      } else {

      }
    } else {

    }
  } else
  if (! with_bracket) {
    zend_error(1 << 6L,
               "Cannot mix bracketed namespace declarations with unbracketed namespace declarations");
  } else
  if (compiler_globals.current_namespace) {
    zend_error(1 << 6L, "Namespace declarations cannot be nested");
  } else
  if (compiler_globals.in_namespace) {
    zend_error(1 << 6L, "Namespace declarations cannot be nested");
  } else {

  }
  if (! with_bracket) {
    if (! compiler_globals.current_namespace) {
      goto _L;
    } else {
      goto _L___0;
    }
  } else
  _L___0: 
  if (with_bracket) {
    if (! compiler_globals.has_bracketed_namespaces) {
      _L: 
      if ((compiler_globals.active_op_array)->last > 0U) {
        num = (int )(compiler_globals.active_op_array)->last;
        while (1) {
          if (num > 0) {
            if (! ((int )((compiler_globals.active_op_array)->opcodes + (num - 1))->opcode == 101)) {
              if (! ((int )((compiler_globals.active_op_array)->opcodes + (num - 1))->opcode == 105)) {
                break;
              } else {

              }
            } else {

            }
          } else {
            break;
          }
          num --;
        }
        if (num > 0) {
          zend_error(1 << 6L,
                     "Namespace declaration statement has to be the very first statement in the script");
        } else {

        }
      } else {

      }
    } else {

    }
  } else {

  }
  compiler_globals.in_namespace = (zend_bool )1;
  if (with_bracket) {
    compiler_globals.has_bracketed_namespaces = (zend_bool )1;
  } else {

  }
  if (name) {
    tmp = zend_str_tolower_dup((char const   *)name->u.constant.value.str.val,
                               (unsigned int )name->u.constant.value.str.len);
    lcname = (char *)tmp;
    if ((unsigned long )name->u.constant.value.str.len == sizeof("self") - 1UL) {
      tmp___0 = memcmp((void const   *)lcname, (void const   *)"self",
                       sizeof("self") - 1UL);
      if (tmp___0) {
        goto _L___1;
      } else {
        zend_error(1 << 6L, "Cannot use \'%s\' as namespace name",
                   name->u.constant.value.str.val);
      }
    } else
    _L___1: 
    if ((unsigned long )name->u.constant.value.str.len == sizeof("parent") - 1UL) {
      tmp___1 = memcmp((void const   *)lcname, (void const   *)"parent",
                       sizeof("parent") - 1UL);
      if (! tmp___1) {
        zend_error(1 << 6L, "Cannot use \'%s\' as namespace name",
                   name->u.constant.value.str.val);
      } else {

      }
    } else {

    }
    _efree((void *)lcname);
    if (compiler_globals.current_namespace) {
      _zval_dtor(compiler_globals.current_namespace);
    } else {
      while (1) {
        tmp___2 = _emalloc(sizeof(zval_gc_info ));
        compiler_globals.current_namespace = (zval *)tmp___2;
        ((zval_gc_info *)compiler_globals.current_namespace)->u.buffered = (gc_root_buffer *)((void *)0);
        break;
      }
    }
    *(compiler_globals.current_namespace) = (zval )name->u.constant;
  } else
  if (compiler_globals.current_namespace) {
    _zval_dtor(compiler_globals.current_namespace);
    while (1) {
      if ((gc_root_buffer *)((zend_uintptr_t )((zval_gc_info *)compiler_globals.current_namespace)->u.buffered & 0xfffffffffffffffcUL)) {
        gc_remove_zval_from_buffer(compiler_globals.current_namespace);
      } else {

      }
      _efree((void *)compiler_globals.current_namespace);
      break;
    }
    compiler_globals.current_namespace = (zval *)((void *)0);
  } else {

  }
  if (compiler_globals.current_import) {
    zend_hash_destroy(compiler_globals.current_import);
    _efree((void *)compiler_globals.current_import);
    compiler_globals.current_import = (HashTable *)((void *)0);
  } else {

  }
  if (compiler_globals.doc_comment) {
    _efree((void *)compiler_globals.doc_comment);
    compiler_globals.doc_comment = (char *)((void *)0);
    compiler_globals.doc_comment_len = (zend_uint )0;
  } else {

  }
  return;
}
}
void zend_do_use(znode *ns_name , znode *new_name , int is_global ) 
{ 
  char *lcname ;
  zval *name ;
  zval *ns ;
  zval tmp ;
  zend_bool warn ;
  zend_class_entry **pce ;
  void __attribute__((__visibility__("default")))  *tmp___0 ;
  void __attribute__((__visibility__("default")))  *tmp___1 ;
  char const   *p ;
  void const   *tmp___2 ;
  char const   *__s ;
  zval *__z ;
  size_t tmp___3 ;
  char __attribute__((__visibility__("default")))  *tmp___4 ;
  int tmp___5 ;
  char __attribute__((__visibility__("default")))  *tmp___6 ;
  int tmp___7 ;
  int tmp___8 ;
  char *c_ns_name ;
  void __attribute__((__visibility__("default")))  *tmp___9 ;
  char *tmp2 ;
  char __attribute__((__visibility__("default")))  *tmp___10 ;
  int tmp___11 ;
  int __attribute__((__visibility__("default")))  tmp___12 ;
  char *c_tmp ;
  char __attribute__((__visibility__("default")))  *tmp___13 ;
  int tmp___14 ;
  int __attribute__((__visibility__("default")))  tmp___15 ;
  int __attribute__((__visibility__("default")))  tmp___16 ;
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp___18 ;
  int tmp___21 ;
  int tmp___22 ;
  int tmp___23 ;

  {
  warn = (zend_bool )0;
  if (! compiler_globals.current_import) {
    tmp___0 = _emalloc(sizeof(HashTable ));
    compiler_globals.current_import = (HashTable *)tmp___0;
    _zend_hash_init(compiler_globals.current_import, (uint )0,
                    (ulong (*)(char const   *arKey , uint nKeyLength ))((void *)0),
                    (void (*)(void * ))(& _zval_ptr_dtor), (zend_bool )0);
  } else {

  }
  while (1) {
    tmp___1 = _emalloc(sizeof(zval_gc_info ));
    ns = (zval *)tmp___1;
    ((zval_gc_info *)ns)->u.buffered = (gc_root_buffer *)((void *)0);
    break;
  }
  *ns = ns_name->u.constant;
  if (new_name) {
    name = & new_name->u.constant;
  } else {
    name = & tmp;
    tmp___2 = zend_memrchr((void const   *)ns->value.str.val, '\\',
                           (size_t )ns->value.str.len);
    p = (char const   *)tmp___2;
    if (p) {
      while (1) {
        __s = p + 1;
        __z = name;
        tmp___3 = strlen(__s);
        __z->value.str.len = (int )tmp___3;
        tmp___4 = _estrndup(__s, (unsigned int )__z->value.str.len);
        __z->value.str.val = (char *)tmp___4;
        __z->type = (zend_uchar )6;
        break;
      }
    } else {
      *name = *ns;
      _zval_copy_ctor(name);
      if (! is_global) {
        if (! compiler_globals.current_namespace) {
          tmp___5 = 1;
        } else {
          tmp___5 = 0;
        }
      } else {
        tmp___5 = 0;
      }
      warn = (zend_bool )tmp___5;
    }
  }
  tmp___6 = zend_str_tolower_dup((char const   *)name->value.str.val,
                                 (unsigned int )name->value.str.len);
  lcname = (char *)tmp___6;
  if ((unsigned long )name->value.str.len == sizeof("self") - 1UL) {
    tmp___7 = memcmp((void const   *)lcname, (void const   *)"self",
                     sizeof("self") - 1UL);
    if (tmp___7) {
      goto _L;
    } else {
      zend_error(1 << 6L,
                 "Cannot use %s as %s because \'%s\' is a special class name",
                 ns->value.str.val, name->value.str.val, name->value.str.val);
    }
  } else
  _L: 
  if ((unsigned long )name->value.str.len == sizeof("parent") - 1UL) {
    tmp___8 = memcmp((void const   *)lcname, (void const   *)"parent",
                     sizeof("parent") - 1UL);
    if (! tmp___8) {
      zend_error(1 << 6L,
                 "Cannot use %s as %s because \'%s\' is a special class name",
                 ns->value.str.val, name->value.str.val, name->value.str.val);
    } else {

    }
  } else {

  }
  if (compiler_globals.current_namespace) {
    tmp___9 = _emalloc((size_t )((((compiler_globals.current_namespace)->value.str.len + 1) + name->value.str.len) + 1));
    c_ns_name = (char *)tmp___9;
    zend_str_tolower_copy(c_ns_name,
                          (char const   *)(compiler_globals.current_namespace)->value.str.val,
                          (unsigned int )(compiler_globals.current_namespace)->value.str.len);
    *(c_ns_name + (compiler_globals.current_namespace)->value.str.len) = (char )'\\';
    memcpy((void */* __restrict  */)((c_ns_name + (compiler_globals.current_namespace)->value.str.len) + 1),
           (void const   */* __restrict  */)lcname,
           (size_t )(name->value.str.len + 1));
    tmp___12 = zend_hash_exists((HashTable const   *)compiler_globals.class_table,
                                (char const   *)c_ns_name,
                                (uint )((((compiler_globals.current_namespace)->value.str.len + 1) + name->value.str.len) + 1));
    if (tmp___12) {
      tmp___10 = zend_str_tolower_dup((char const   *)ns->value.str.val,
                                      (unsigned int )ns->value.str.len);
      tmp2 = (char *)tmp___10;
      if (ns->value.str.len != ((compiler_globals.current_namespace)->value.str.len + 1) + name->value.str.len) {
        zend_error(1 << 6L,
                   "Cannot use %s as %s because the name is already in use",
                   ns->value.str.val, name->value.str.val);
      } else {
        tmp___11 = memcmp((void const   *)tmp2, (void const   *)c_ns_name,
                          (size_t )ns->value.str.len);
        if (tmp___11) {
          zend_error(1 << 6L,
                     "Cannot use %s as %s because the name is already in use",
                     ns->value.str.val, name->value.str.val);
        } else {

        }
      }
      _efree((void *)tmp2);
    } else {

    }
    _efree((void *)c_ns_name);
  } else {
    tmp___15 = zend_hash_find((HashTable const   *)compiler_globals.class_table,
                              (char const   *)lcname,
                              (uint )(name->value.str.len + 1), (void **)(& pce));
    if (tmp___15 == (int __attribute__((__visibility__("default")))  )0) {
      if ((int )(*pce)->type == 2) {
        if ((unsigned long )(*pce)->info.user.filename == (unsigned long )compiler_globals.compiled_filename) {
          tmp___13 = zend_str_tolower_dup((char const   *)ns->value.str.val,
                                          (unsigned int )ns->value.str.len);
          c_tmp = (char *)tmp___13;
          if (ns->value.str.len != name->value.str.len) {
            zend_error(1 << 6L,
                       "Cannot use %s as %s because the name is already in use",
                       ns->value.str.val, name->value.str.val);
          } else {
            tmp___14 = memcmp((void const   *)c_tmp, (void const   *)lcname,
                              (size_t )ns->value.str.len);
            if (tmp___14) {
              zend_error(1 << 6L,
                         "Cannot use %s as %s because the name is already in use",
                         ns->value.str.val, name->value.str.val);
            } else {

            }
          }
          _efree((void *)c_tmp);
        } else {

        }
      } else {

      }
    } else {

    }
  }
  tmp___16 = _zend_hash_add_or_update(compiler_globals.current_import,
                                      (char const   *)lcname,
                                      (uint )(name->value.str.len + 1),
                                      (void *)(& ns), (uint )sizeof(zval *),
                                      (void **)((void *)0), 1 << 1);
  if (tmp___16 != (int __attribute__((__visibility__("default")))  )0) {
    zend_error(1 << 6L,
               "Cannot use %s as %s because the name is already in use",
               ns->value.str.val, name->value.str.val);
  } else {

  }
  if (warn) {
    if (0) {
      __s1_len = __builtin_strlen((char const   *)name->value.str.val);
      __s2_len = __builtin_strlen("strict");
      if (! ((size_t )((void const   *)(name->value.str.val + 1)) - (size_t )((void const   *)name->value.str.val) == 1UL)) {
        goto _L___1;
      } else
      if (__s1_len >= 4UL) {
        _L___1: 
        if (! ((size_t )((void const   *)("strict" + 1)) - (size_t )((void const   *)"strict") == 1UL)) {
          tmp___23 = 1;
        } else
        if (__s2_len >= 4UL) {
          tmp___23 = 1;
        } else {
          tmp___23 = 0;
        }
      } else {
        tmp___23 = 0;
      }
      if (tmp___23) {
        tmp___18 = __builtin_strcmp((char const   *)name->value.str.val,
                                    "strict");
        tmp___22 = tmp___18;
      } else {
        tmp___21 = __builtin_strcmp((char const   *)name->value.str.val,
                                    "strict");
        tmp___22 = tmp___21;
      }
    } else {
      tmp___21 = __builtin_strcmp((char const   *)name->value.str.val, "strict");
      tmp___22 = tmp___21;
    }
    if (! tmp___22) {
      zend_error(1 << 6L, "You seem to be trying to use a different language...");
    } else {

    }
    zend_error(1 << 1L,
               "The use statement with non-compound name \'%s\' has no effect",
               name->value.str.val);
  } else {

  }
  _efree((void *)lcname);
  _zval_dtor(name);
  return;
}
}
void zend_do_declare_constant(znode *name , znode *value ) 
{ 
  zend_op *opline ;
  zend_constant *tmp ;
  znode tmp___0 ;
  char __attribute__((__visibility__("default")))  *tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;

  {
  if ((int )value->u.constant.type == 9) {
    zend_error(1 << 6L, "Arrays are not allowed as constants");
  } else {

  }
  tmp = zend_get_ct_const((zval const   *)(& name->u.constant), 0);
  if (tmp) {
    zend_error(1 << 6L, "Cannot redeclare constant \'%s\'",
               name->u.constant.value.str.val);
  } else {

  }
  if (compiler_globals.current_namespace) {
    tmp___0.op_type = 1;
    tmp___0.u.constant = *(compiler_globals.current_namespace);
    tmp___1 = zend_str_tolower_dup((char const   *)tmp___0.u.constant.value.str.val,
                                   (unsigned int )tmp___0.u.constant.value.str.len);
    tmp___0.u.constant.value.str.val = (char *)tmp___1;
    zend_do_build_namespace_name(& tmp___0, & tmp___0, name);
    *name = tmp___0;
  } else {

  }
  opline = get_next_op(compiler_globals.active_op_array);
  opline->opcode = (zend_uchar )143;
  opline->result_type = (zend_uchar )(1 << 3);
  while (1) {
    opline->op1_type = (zend_uchar )name->op_type;
    if (name->op_type == 1) {
      tmp___2 = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& name->u.constant));
      opline->op1.constant = (zend_uint )tmp___2;
    } else {
      opline->op1 = name->u.op;
    }
    break;
  }
  while (1) {
    opline->op2_type = (zend_uchar )value->op_type;
    if (value->op_type == 1) {
      tmp___3 = zend_add_literal(compiler_globals.active_op_array,
                                 (zval const   *)(& value->u.constant));
      opline->op2.constant = (zend_uint )tmp___3;
    } else {
      opline->op2 = value->u.op;
    }
    break;
  }
  return;
}
}
void zend_verify_namespace(void) 
{ 


  {
  if (compiler_globals.has_bracketed_namespaces) {
    if (! compiler_globals.in_namespace) {
      zend_error(1 << 6L, "No code may exist outside of namespace {}");
    } else {

    }
  } else {

  }
  return;
}
}
void zend_do_end_namespace(void) 
{ 


  {
  compiler_globals.in_namespace = (zend_bool )0;
  if (compiler_globals.current_namespace) {
    _zval_dtor(compiler_globals.current_namespace);
    while (1) {
      if ((gc_root_buffer *)((zend_uintptr_t )((zval_gc_info *)compiler_globals.current_namespace)->u.buffered & 0xfffffffffffffffcUL)) {
        gc_remove_zval_from_buffer(compiler_globals.current_namespace);
      } else {

      }
      _efree((void *)compiler_globals.current_namespace);
      break;
    }
    compiler_globals.current_namespace = (zval *)((void *)0);
  } else {

  }
  if (compiler_globals.current_import) {
    zend_hash_destroy(compiler_globals.current_import);
    _efree((void *)compiler_globals.current_import);
    compiler_globals.current_import = (HashTable *)((void *)0);
  } else {

  }
  return;
}
}
void zend_do_end_compilation(void) 
{ 


  {
  compiler_globals.has_bracketed_namespaces = (zend_bool )0;
  zend_do_end_namespace();
  return;
}
}
size_t __attribute__((__visibility__("default")))  zend_dirname(char *path ,
                                                                size_t len ) 
{ 
  register char *end ;
  unsigned int len_adjust ;

  {
  end = (path + len) - 1;
  len_adjust = 0U;
  if (len == 0UL) {
    return ((size_t __attribute__((__visibility__("default")))  )0);
  } else {

  }
  while (1) {
    if ((unsigned long )end >= (unsigned long )path) {
      if (! ((int )*end == 47)) {
        break;
      } else {

      }
    } else {
      break;
    }
    end --;
  }
  if ((unsigned long )end < (unsigned long )path) {
    *(path + 0) = (char )'/';
    *(path + 1) = (char )'\000';
    return ((size_t __attribute__((__visibility__("default")))  )(1U + len_adjust));
  } else {

  }
  while (1) {
    if ((unsigned long )end >= (unsigned long )path) {
      if (! (! ((int )*end == 47))) {
        break;
      } else {

      }
    } else {
      break;
    }
    end --;
  }
  if ((unsigned long )end < (unsigned long )path) {
    *(path + 0) = (char )'.';
    *(path + 1) = (char )'\000';
    return ((size_t __attribute__((__visibility__("default")))  )(1U + len_adjust));
  } else {

  }
  while (1) {
    if ((unsigned long )end >= (unsigned long )path) {
      if (! ((int )*end == 47)) {
        break;
      } else {

      }
    } else {
      break;
    }
    end --;
  }
  if ((unsigned long )end < (unsigned long )path) {
    *(path + 0) = (char )'/';
    *(path + 1) = (char )'\000';
    return ((size_t __attribute__((__visibility__("default")))  )(1U + len_adjust));
  } else {

  }
  *(end + 1) = (char )'\000';
  return ((size_t __attribute__((__visibility__("default")))  )((size_t )((end + 1) - path) + (size_t )len_adjust));
}
}
