typedef unsigned long size_t;
typedef long __off_t;
typedef long __off64_t;
typedef long __time_t;
struct _IO_FILE;
struct _IO_FILE;
struct _IO_FILE;
typedef struct _IO_FILE FILE;
typedef __builtin_va_list __gnuc_va_list;
struct _IO_FILE;
typedef void _IO_lock_t;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
struct _IO_FILE {
   int _flags ;
   char *_IO_read_ptr ;
   char *_IO_read_end ;
   char *_IO_read_base ;
   char *_IO_write_base ;
   char *_IO_write_ptr ;
   char *_IO_write_end ;
   char *_IO_buf_base ;
   char *_IO_buf_end ;
   char *_IO_save_base ;
   char *_IO_backup_base ;
   char *_IO_save_end ;
   struct _IO_marker *_markers ;
   struct _IO_FILE *_chain ;
   int _fileno ;
   int _flags2 ;
   __off_t _old_offset ;
   unsigned short _cur_column ;
   signed char _vtable_offset ;
   char _shortbuf[1] ;
   _IO_lock_t *_lock ;
   __off64_t _offset ;
   void *__pad1 ;
   void *__pad2 ;
   void *__pad3 ;
   void *__pad4 ;
   size_t __pad5 ;
   int _mode ;
   char _unused2[(15UL * sizeof(int ) - 4UL * sizeof(void *)) - sizeof(size_t )] ;
};
typedef __time_t time_t;
struct tm {
   int tm_sec ;
   int tm_min ;
   int tm_hour ;
   int tm_mday ;
   int tm_mon ;
   int tm_year ;
   int tm_wday ;
   int tm_yday ;
   int tm_isdst ;
   long __tm_gmtoff ;
   char const   *__tm_zone ;
};
typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned int uint32;
typedef unsigned long uint64;
struct __anonstruct_TIFFHeaderCommon_15 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
};
typedef struct __anonstruct_TIFFHeaderCommon_15 TIFFHeaderCommon;
struct __anonstruct_TIFFHeaderClassic_16 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
   uint32 tiff_diroff ;
};
typedef struct __anonstruct_TIFFHeaderClassic_16 TIFFHeaderClassic;
struct __anonstruct_TIFFHeaderBig_17 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
   uint16 tiff_offsetsize ;
   uint16 tiff_unused ;
   uint64 tiff_diroff ;
};
typedef struct __anonstruct_TIFFHeaderBig_17 TIFFHeaderBig;
enum __anonenum_TIFFDataType_18 {
    TIFF_NOTYPE = 0,
    TIFF_BYTE = 1,
    TIFF_ASCII = 2,
    TIFF_SHORT = 3,
    TIFF_LONG = 4,
    TIFF_RATIONAL = 5,
    TIFF_SBYTE = 6,
    TIFF_UNDEFINED = 7,
    TIFF_SSHORT = 8,
    TIFF_SLONG = 9,
    TIFF_SRATIONAL = 10,
    TIFF_FLOAT = 11,
    TIFF_DOUBLE = 12,
    TIFF_IFD = 13,
    TIFF_LONG8 = 16,
    TIFF_SLONG8 = 17,
    TIFF_IFD8 = 18
} ;
typedef enum __anonenum_TIFFDataType_18 TIFFDataType;
struct tiff;
struct tiff;
typedef struct tiff TIFF;
typedef long tmsize_t;
typedef uint64 toff_t;
typedef uint16 tdir_t;
typedef uint32 tstrile_t;
typedef tstrile_t tstrip_t;
typedef tstrile_t ttile_t;
typedef tmsize_t tsize_t;
typedef void *tdata_t;
typedef void *thandle_t;
typedef __gnuc_va_list va_list;
typedef tmsize_t (*TIFFReadWriteProc)(thandle_t  , void * , tmsize_t  );
typedef toff_t (*TIFFSeekProc)(thandle_t  , toff_t  , int  );
struct _TIFFField;
struct _TIFFField;
typedef struct _TIFFField TIFFField;
struct _TIFFFieldArray;
struct _TIFFFieldArray;
typedef struct _TIFFFieldArray TIFFFieldArray;
struct __anonstruct_TIFFTagMethods_24 {
   int (*vsetfield)(TIFF * , uint32  , va_list  ) ;
   int (*vgetfield)(TIFF * , uint32  , va_list  ) ;
   void (*printdir)(TIFF * , FILE * , long  ) ;
};
typedef struct __anonstruct_TIFFTagMethods_24 TIFFTagMethods;
struct __anonstruct_TIFFTagValue_26 {
   TIFFField const   *info ;
   int count ;
   void *value ;
};
typedef struct __anonstruct_TIFFTagValue_26 TIFFTagValue;
struct __anonstruct_TIFFDirectory_27 {
   unsigned long td_fieldsset[4] ;
   uint32 td_imagewidth ;
   uint32 td_imagelength ;
   uint32 td_imagedepth ;
   uint32 td_tilewidth ;
   uint32 td_tilelength ;
   uint32 td_tiledepth ;
   uint32 td_subfiletype ;
   uint16 td_bitspersample ;
   uint16 td_sampleformat ;
   uint16 td_compression ;
   uint16 td_photometric ;
   uint16 td_threshholding ;
   uint16 td_fillorder ;
   uint16 td_orientation ;
   uint16 td_samplesperpixel ;
   uint32 td_rowsperstrip ;
   uint16 td_minsamplevalue ;
   uint16 td_maxsamplevalue ;
   double td_sminsamplevalue ;
   double td_smaxsamplevalue ;
   float td_xresolution ;
   float td_yresolution ;
   uint16 td_resolutionunit ;
   uint16 td_planarconfig ;
   float td_xposition ;
   float td_yposition ;
   uint16 td_pagenumber[2] ;
   uint16 *td_colormap[3] ;
   uint16 td_halftonehints[2] ;
   uint16 td_extrasamples ;
   uint16 *td_sampleinfo ;
   uint32 td_stripsperimage ;
   uint32 td_nstrips ;
   uint64 *td_stripoffset ;
   uint64 *td_stripbytecount ;
   int td_stripbytecountsorted ;
   uint16 td_nsubifd ;
   uint64 *td_subifd ;
   uint16 td_ycbcrsubsampling[2] ;
   uint16 td_ycbcrpositioning ;
   uint16 *td_transferfunction[3] ;
   float *td_refblackwhite ;
   int td_inknameslen ;
   char *td_inknames ;
   int td_customValueCount ;
   TIFFTagValue *td_customValues ;
};
typedef struct __anonstruct_TIFFDirectory_27 TIFFDirectory;
enum __anonenum_TIFFSetGetFieldType_28 {
    TIFF_SETGET_UNDEFINED = 0,
    TIFF_SETGET_ASCII = 1,
    TIFF_SETGET_UINT8 = 2,
    TIFF_SETGET_SINT8 = 3,
    TIFF_SETGET_UINT16 = 4,
    TIFF_SETGET_SINT16 = 5,
    TIFF_SETGET_UINT32 = 6,
    TIFF_SETGET_SINT32 = 7,
    TIFF_SETGET_UINT64 = 8,
    TIFF_SETGET_SINT64 = 9,
    TIFF_SETGET_FLOAT = 10,
    TIFF_SETGET_DOUBLE = 11,
    TIFF_SETGET_IFD8 = 12,
    TIFF_SETGET_INT = 13,
    TIFF_SETGET_UINT16_PAIR = 14,
    TIFF_SETGET_C0_ASCII = 15,
    TIFF_SETGET_C0_UINT8 = 16,
    TIFF_SETGET_C0_SINT8 = 17,
    TIFF_SETGET_C0_UINT16 = 18,
    TIFF_SETGET_C0_SINT16 = 19,
    TIFF_SETGET_C0_UINT32 = 20,
    TIFF_SETGET_C0_SINT32 = 21,
    TIFF_SETGET_C0_UINT64 = 22,
    TIFF_SETGET_C0_SINT64 = 23,
    TIFF_SETGET_C0_FLOAT = 24,
    TIFF_SETGET_C0_DOUBLE = 25,
    TIFF_SETGET_C0_IFD8 = 26,
    TIFF_SETGET_C16_ASCII = 27,
    TIFF_SETGET_C16_UINT8 = 28,
    TIFF_SETGET_C16_SINT8 = 29,
    TIFF_SETGET_C16_UINT16 = 30,
    TIFF_SETGET_C16_SINT16 = 31,
    TIFF_SETGET_C16_UINT32 = 32,
    TIFF_SETGET_C16_SINT32 = 33,
    TIFF_SETGET_C16_UINT64 = 34,
    TIFF_SETGET_C16_SINT64 = 35,
    TIFF_SETGET_C16_FLOAT = 36,
    TIFF_SETGET_C16_DOUBLE = 37,
    TIFF_SETGET_C16_IFD8 = 38,
    TIFF_SETGET_C32_ASCII = 39,
    TIFF_SETGET_C32_UINT8 = 40,
    TIFF_SETGET_C32_SINT8 = 41,
    TIFF_SETGET_C32_UINT16 = 42,
    TIFF_SETGET_C32_SINT16 = 43,
    TIFF_SETGET_C32_UINT32 = 44,
    TIFF_SETGET_C32_SINT32 = 45,
    TIFF_SETGET_C32_UINT64 = 46,
    TIFF_SETGET_C32_SINT64 = 47,
    TIFF_SETGET_C32_FLOAT = 48,
    TIFF_SETGET_C32_DOUBLE = 49,
    TIFF_SETGET_C32_IFD8 = 50,
    TIFF_SETGET_OTHER = 51
} ;
typedef enum __anonenum_TIFFSetGetFieldType_28 TIFFSetGetFieldType;
enum __anonenum_TIFFFieldArrayType_29 {
    tfiatImage = 0,
    tfiatExif = 1,
    tfiatOther = 2
} ;
typedef enum __anonenum_TIFFFieldArrayType_29 TIFFFieldArrayType;
struct _TIFFFieldArray {
   TIFFFieldArrayType type ;
   uint32 allocated_size ;
   uint32 count ;
   TIFFField *fields ;
};
struct _TIFFField {
   uint32 field_tag ;
   short field_readcount ;
   short field_writecount ;
   TIFFDataType field_type ;
   uint32 reserved ;
   TIFFSetGetFieldType set_field_type ;
   TIFFSetGetFieldType get_field_type ;
   unsigned short field_bit ;
   unsigned char field_oktochange ;
   unsigned char field_passcount ;
   char *field_name ;
   TIFFFieldArray *field_subfields ;
};
struct client_info {
   struct client_info *next ;
   void *data ;
   char *name ;
};
typedef struct client_info TIFFClientInfoLink;
union __anonunion_tif_header_32 {
   TIFFHeaderCommon common ;
   TIFFHeaderClassic classic ;
   TIFFHeaderBig big ;
};
struct tiff {
   char *tif_name ;
   int tif_fd ;
   int tif_mode ;
   uint32 tif_flags ;
   uint64 tif_diroff ;
   uint64 tif_nextdiroff ;
   uint64 *tif_dirlist ;
   uint16 tif_dirlistsize ;
   uint16 tif_dirnumber ;
   TIFFDirectory tif_dir ;
   TIFFDirectory tif_customdir ;
   union __anonunion_tif_header_32 tif_header ;
   uint16 tif_header_size ;
   uint32 tif_row ;
   uint16 tif_curdir ;
   uint32 tif_curstrip ;
   uint64 tif_curoff ;
   uint64 tif_dataoff ;
   uint16 tif_nsubifd ;
   uint64 tif_subifdoff ;
   uint32 tif_col ;
   uint32 tif_curtile ;
   tmsize_t tif_tilesize ;
   int tif_decodestatus ;
   int (*tif_fixuptags)(TIFF * ) ;
   int (*tif_setupdecode)(TIFF * ) ;
   int (*tif_predecode)(TIFF * , uint16  ) ;
   int (*tif_setupencode)(TIFF * ) ;
   int tif_encodestatus ;
   int (*tif_preencode)(TIFF * , uint16  ) ;
   int (*tif_postencode)(TIFF * ) ;
   int (*tif_decoderow)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_encoderow)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_decodestrip)(TIFF *tif , uint8 *buf , tmsize_t size ,
                          uint16 sample ) ;
   int (*tif_encodestrip)(TIFF *tif , uint8 *buf , tmsize_t size ,
                          uint16 sample ) ;
   int (*tif_decodetile)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_encodetile)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   void (*tif_close)(TIFF * ) ;
   int (*tif_seek)(TIFF * , uint32  ) ;
   void (*tif_cleanup)(TIFF * ) ;
   uint32 (*tif_defstripsize)(TIFF * , uint32  ) ;
   void (*tif_deftilesize)(TIFF * , uint32 * , uint32 * ) ;
   uint8 *tif_data ;
   tmsize_t tif_scanlinesize ;
   tmsize_t tif_scanlineskew ;
   uint8 *tif_rawdata ;
   tmsize_t tif_rawdatasize ;
   tmsize_t tif_rawdataoff ;
   tmsize_t tif_rawdataloaded ;
   uint8 *tif_rawcp ;
   tmsize_t tif_rawcc ;
   uint8 *tif_base ;
   tmsize_t tif_size ;
   int (*tif_mapproc)(thandle_t  , void **base , toff_t *size ) ;
   void (*tif_unmapproc)(thandle_t  , void *base , toff_t size ) ;
   thandle_t tif_clientdata ;
   tmsize_t (*tif_readproc)(thandle_t  , void * , tmsize_t  ) ;
   tmsize_t (*tif_writeproc)(thandle_t  , void * , tmsize_t  ) ;
   toff_t (*tif_seekproc)(thandle_t  , toff_t  , int  ) ;
   int (*tif_closeproc)(thandle_t  ) ;
   toff_t (*tif_sizeproc)(thandle_t  ) ;
   void (*tif_postdecode)(TIFF *tif , uint8 *buf , tmsize_t size ) ;
   TIFFField **tif_fields ;
   size_t tif_nfields ;
   TIFFField const   *tif_foundfield ;
   TIFFTagMethods tif_tagmethods ;
   TIFFClientInfoLink *tif_clientinfo ;
   TIFFFieldArray *tif_fieldscompat ;
   size_t tif_nfieldscompat ;
};
enum __anonenum_t2p_cs_t_33 {
    T2P_CS_BILEVEL = 1,
    T2P_CS_GRAY = 2,
    T2P_CS_RGB = 4,
    T2P_CS_CMYK = 8,
    T2P_CS_LAB = 16,
    T2P_CS_PALETTE = 4096,
    T2P_CS_CALGRAY = 32,
    T2P_CS_CALRGB = 64,
    T2P_CS_ICCBASED = 128
} ;
typedef enum __anonenum_t2p_cs_t_33 t2p_cs_t;
enum __anonenum_t2p_compress_t_34 {
    T2P_COMPRESS_NONE = 0,
    T2P_COMPRESS_G4 = 1
} ;
typedef enum __anonenum_t2p_compress_t_34 t2p_compress_t;
enum __anonenum_t2p_transcode_t_35 {
    T2P_TRANSCODE_RAW = 1,
    T2P_TRANSCODE_ENCODE = 2
} ;
typedef enum __anonenum_t2p_transcode_t_35 t2p_transcode_t;
enum __anonenum_t2p_sample_t_36 {
    T2P_SAMPLE_NOTHING = 0,
    T2P_SAMPLE_ABGR_TO_RGB = 1,
    T2P_SAMPLE_RGBA_TO_RGB = 2,
    T2P_SAMPLE_RGBAA_TO_RGB = 4,
    T2P_SAMPLE_YCBCR_TO_RGB = 8,
    T2P_SAMPLE_YCBCR_TO_LAB = 16,
    T2P_SAMPLE_REALIZE_PALETTE = 32,
    T2P_SAMPLE_SIGNED_TO_UNSIGNED = 64,
    T2P_SAMPLE_LAB_SIGNED_TO_UNSIGNED = 64,
    T2P_SAMPLE_PLANAR_SEPARATE_TO_CONTIG = 256
} ;
typedef enum __anonenum_t2p_sample_t_36 t2p_sample_t;
enum __anonenum_t2p_err_t_37 {
    T2P_ERR_OK = 0,
    T2P_ERR_ERROR = 1
} ;
typedef enum __anonenum_t2p_err_t_37 t2p_err_t;
struct __anonstruct_T2P_PAGE_38 {
   tdir_t page_directory ;
   uint32 page_number ;
   ttile_t page_tilecount ;
   uint32 page_extra ;
};
typedef struct __anonstruct_T2P_PAGE_38 T2P_PAGE;
struct __anonstruct_T2P_BOX_39 {
   float x1 ;
   float y1 ;
   float x2 ;
   float y2 ;
   float mat[9] ;
};
typedef struct __anonstruct_T2P_BOX_39 T2P_BOX;
struct __anonstruct_T2P_TILE_40 {
   T2P_BOX tile_box ;
};
typedef struct __anonstruct_T2P_TILE_40 T2P_TILE;
struct __anonstruct_T2P_TILES_41 {
   ttile_t tiles_tilecount ;
   uint32 tiles_tilewidth ;
   uint32 tiles_tilelength ;
   uint32 tiles_tilecountx ;
   uint32 tiles_tilecounty ;
   uint32 tiles_edgetilewidth ;
   uint32 tiles_edgetilelength ;
   T2P_TILE *tiles_tiles ;
};
typedef struct __anonstruct_T2P_TILES_41 T2P_TILES;
struct __anonstruct_T2P_42 {
   t2p_err_t t2p_error ;
   T2P_PAGE *tiff_pages ;
   T2P_TILES *tiff_tiles ;
   tdir_t tiff_pagecount ;
   uint16 tiff_compression ;
   uint16 tiff_photometric ;
   uint16 tiff_fillorder ;
   uint16 tiff_bitspersample ;
   uint16 tiff_samplesperpixel ;
   uint16 tiff_planar ;
   uint32 tiff_width ;
   uint32 tiff_length ;
   float tiff_xres ;
   float tiff_yres ;
   uint16 tiff_orientation ;
   toff_t tiff_dataoffset ;
   tsize_t tiff_datasize ;
   uint16 tiff_resunit ;
   uint16 pdf_centimeters ;
   uint16 pdf_overrideres ;
   uint16 pdf_overridepagesize ;
   float pdf_defaultxres ;
   float pdf_defaultyres ;
   float pdf_xres ;
   float pdf_yres ;
   float pdf_defaultpagewidth ;
   float pdf_defaultpagelength ;
   float pdf_pagewidth ;
   float pdf_pagelength ;
   float pdf_imagewidth ;
   float pdf_imagelength ;
   T2P_BOX pdf_mediabox ;
   T2P_BOX pdf_imagebox ;
   uint16 pdf_majorversion ;
   uint16 pdf_minorversion ;
   uint32 pdf_catalog ;
   uint32 pdf_pages ;
   uint32 pdf_info ;
   uint32 pdf_palettecs ;
   uint16 pdf_fitwindow ;
   uint32 pdf_startxref ;
   char pdf_fileid[33] ;
   char pdf_datetime[17] ;
   char pdf_creator[512] ;
   char pdf_author[512] ;
   char pdf_title[512] ;
   char pdf_subject[512] ;
   char pdf_keywords[512] ;
   t2p_cs_t pdf_colorspace ;
   uint16 pdf_colorspace_invert ;
   uint16 pdf_switchdecode ;
   uint16 pdf_palettesize ;
   unsigned char *pdf_palette ;
   int pdf_labrange[4] ;
   t2p_compress_t pdf_defaultcompression ;
   uint16 pdf_defaultcompressionquality ;
   t2p_compress_t pdf_compression ;
   uint16 pdf_compressionquality ;
   uint16 pdf_nopassthrough ;
   t2p_transcode_t pdf_transcode ;
   t2p_sample_t pdf_sample ;
   uint32 *pdf_xrefoffsets ;
   uint32 pdf_xrefcount ;
   tdir_t pdf_page ;
   float tiff_whitechromaticities[2] ;
   float tiff_primarychromaticities[6] ;
   float tiff_referenceblackwhite[2] ;
   float *tiff_transferfunction[3] ;
   int pdf_image_interpolate ;
   uint16 tiff_transferfunctioncount ;
   uint32 pdf_icccs ;
   uint32 tiff_iccprofilelength ;
   tdata_t tiff_iccprofile ;
   FILE *outputfile ;
   int outputdisable ;
   tsize_t outputwritten ;
};
typedef struct __anonstruct_T2P_42 T2P;
extern struct _IO_FILE *stdout ;
extern struct _IO_FILE *stderr ;
extern FILE *fopen(char const   * __restrict  __filename ,
                   char const   * __restrict  __modes ) ;
extern int fprintf(FILE * __restrict  __stream ,
                   char const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int sprintf(char * __restrict  __s ,
                                                 char const   * __restrict  __format 
                                                 , ...) ;
extern  __attribute__((__nothrow__)) int snprintf(char * __restrict  __s ,
                                                  size_t __maxlen ,
                                                  char const   * __restrict  __format 
                                                  , ...) ;
extern size_t fwrite(void const   * __restrict  __ptr , size_t __size ,
                     size_t __n , FILE * __restrict  __s ) ;
extern int fseek(FILE *__stream , long __off , int __whence ) ;
extern  __attribute__((__nothrow__)) double ( __attribute__((__nonnull__(1),
__leaf__)) atof)(char const   *__nptr )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1),
__leaf__)) atoi)(char const   *__nptr )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__leaf__)) rand)(void) ;
extern void ( __attribute__((__nonnull__(1,4))) qsort)(void *__base ,
                                                       size_t __nmemb ,
                                                       size_t __size ,
                                                       int (*__compar)(void const   * ,
                                                                       void const   * ) ) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1,2),
__leaf__)) memcpy)(void * __restrict  __dest ,
                   void const   * __restrict  __src , size_t __n ) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1),
__leaf__)) memset)(void *__s , int __c , size_t __n ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1,2),
__leaf__)) strncpy)(char * __restrict  __dest ,
                    char const   * __restrict  __src , size_t __n ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2),
__leaf__)) strcmp)(char const   *__s1 , char const   *__s2 )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__nonnull__(1),
__leaf__)) strlen)(char const   *__s )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__leaf__)) strerror)(int __errnum ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__leaf__)) toupper)(int __c ) ;
extern  __attribute__((__nothrow__)) time_t ( __attribute__((__leaf__)) time)(time_t *__timer ) ;
extern  __attribute__((__nothrow__)) struct tm *( __attribute__((__leaf__)) localtime)(time_t const   *__timer ) ;
extern  __attribute__((__nothrow__)) int *( __attribute__((__leaf__)) __errno_location)(void)  __attribute__((__const__)) ;
extern char const   *TIFFGetVersion(void) ;
extern int TIFFIsCODECConfigured(uint16  ) ;
extern void *_TIFFmalloc(tmsize_t s ) ;
extern void *_TIFFrealloc(void *p , tmsize_t s ) ;
extern void _TIFFmemset(void *p , int v , tmsize_t c ) ;
extern void _TIFFmemcpy(void *d , void const   *s , tmsize_t c ) ;
extern void _TIFFfree(void *p ) ;
extern void TIFFClose(TIFF *tif ) ;
extern int TIFFGetField(TIFF *tif , uint32 tag  , ...) ;
extern int TIFFGetFieldDefaulted(TIFF *tif , uint32 tag  , ...) ;
extern tmsize_t TIFFScanlineSize(TIFF *tif ) ;
extern tmsize_t TIFFStripSize(TIFF *tif ) ;
extern tmsize_t TIFFTileRowSize(TIFF *tif ) ;
extern tmsize_t TIFFTileSize(TIFF *tif ) ;
extern thandle_t TIFFClientdata(TIFF * ) ;
extern int TIFFIsTiled(TIFF * ) ;
extern TIFFReadWriteProc TIFFGetWriteProc(TIFF * ) ;
extern TIFFSeekProc TIFFGetSeekProc(TIFF * ) ;
extern uint16 TIFFNumberOfDirectories(TIFF * ) ;
extern int TIFFSetDirectory(TIFF * , uint16  ) ;
extern int TIFFSetField(TIFF * , uint32   , ...) ;
extern int TIFFWriteDirectory(TIFF * ) ;
extern int TIFFReadRGBAImageOriented(TIFF * , uint32  , uint32  , uint32 * ,
                                     int  , int  ) ;
extern TIFF *TIFFOpen(char const   * , char const   * ) ;
extern TIFF *TIFFClientOpen(char const   * , char const   * , thandle_t  ,
                            tmsize_t (*)(thandle_t  , void * , tmsize_t  ) ,
                            tmsize_t (*)(thandle_t  , void * , tmsize_t  ) ,
                            toff_t (*)(thandle_t  , toff_t  , int  ) ,
                            int (*)(thandle_t  ) , toff_t (*)(thandle_t  ) ,
                            int (*)(thandle_t  , void **base , toff_t *size ) ,
                            void (*)(thandle_t  , void *base , toff_t size ) ) ;
extern char const   *TIFFFileName(TIFF * ) ;
extern void TIFFError(char const   * , char const   *  , ...) ;
extern void TIFFWarning(char const   * , char const   *  , ...) ;
extern uint32 TIFFNumberOfTiles(TIFF * ) ;
extern uint32 TIFFNumberOfStrips(TIFF * ) ;
extern tmsize_t TIFFReadEncodedStrip(TIFF *tif , uint32 strip , void *buf ,
                                     tmsize_t size ) ;
extern tmsize_t TIFFReadRawStrip(TIFF *tif , uint32 strip , void *buf ,
                                 tmsize_t size ) ;
extern tmsize_t TIFFReadEncodedTile(TIFF *tif , uint32 tile , void *buf ,
                                    tmsize_t size ) ;
extern tmsize_t TIFFReadRawTile(TIFF *tif , uint32 tile , void *buf ,
                                tmsize_t size ) ;
extern tmsize_t TIFFWriteEncodedStrip(TIFF *tif , uint32 strip , void *data ,
                                      tmsize_t cc ) ;
extern void TIFFReverseBits(uint8 *cp , tmsize_t n ) ;
void tiff2pdf_usage(void) ;
int tiff2pdf_match_paper_size(float *width , float *length , char *papersize ) ;
T2P *t2p_init(void) ;
void t2p_validate(T2P *t2p ) ;
tsize_t t2p_write_pdf(T2P *t2p , TIFF *input , TIFF *output ) ;
void t2p_free(T2P *t2p ) ;
void t2p_read_tiff_init(T2P *t2p , TIFF *input ) ;
int t2p_cmp_t2p_page(void const   *e1 , void const   *e2 ) ;
void t2p_read_tiff_data(T2P *t2p , TIFF *input ) ;
void t2p_read_tiff_size(T2P *t2p , TIFF *input ) ;
void t2p_read_tiff_size_tile(T2P *t2p , TIFF *input , ttile_t tile ) ;
int t2p_tile_is_right_edge(T2P_TILES tiles , ttile_t tile ) ;
int t2p_tile_is_bottom_edge(T2P_TILES tiles , ttile_t tile ) ;
int t2p_tile_is_edge(T2P_TILES tiles , ttile_t tile ) ;
int t2p_tile_is_corner_edge(T2P_TILES tiles , ttile_t tile ) ;
tsize_t t2p_readwrite_pdf_image(T2P *t2p , TIFF *input , TIFF *output ) ;
tsize_t t2p_readwrite_pdf_image_tile(T2P *t2p , TIFF *input , TIFF *output ,
                                     ttile_t tile ) ;
void t2p_tile_collapse_left(tdata_t buffer , tsize_t scanwidth ,
                            uint32 tilewidth , uint32 edgetilewidth ,
                            uint32 tilelength ) ;
void t2p_write_advance_directory(T2P *t2p , TIFF *output ) ;
tsize_t t2p_sample_planar_separate_to_contig(T2P *t2p , unsigned char *buffer ,
                                             unsigned char *samplebuffer ,
                                             tsize_t samplebuffersize ) ;
tsize_t t2p_sample_realize_palette(T2P *t2p , unsigned char *buffer ) ;
tsize_t t2p_sample_abgr_to_rgb(tdata_t data , uint32 samplecount ) ;
tsize_t t2p_sample_rgba_to_rgb(tdata_t data , uint32 samplecount ) ;
tsize_t t2p_sample_rgbaa_to_rgb(tdata_t data , uint32 samplecount ) ;
tsize_t t2p_sample_lab_signed_to_unsigned(tdata_t buffer , uint32 samplecount ) ;
tsize_t t2p_write_pdf_header(T2P *t2p , TIFF *output ) ;
tsize_t t2p_write_pdf_obj_start(uint32 number , TIFF *output ) ;
tsize_t t2p_write_pdf_obj_end(TIFF *output ) ;
tsize_t t2p_write_pdf_name(unsigned char *name , TIFF *output ) ;
tsize_t t2p_write_pdf_string(char *pdfstr , TIFF *output ) ;
tsize_t t2p_write_pdf_stream(tdata_t buffer , tsize_t len , TIFF *output ) ;
tsize_t t2p_write_pdf_stream_start(TIFF *output ) ;
tsize_t t2p_write_pdf_stream_end(TIFF *output ) ;
tsize_t t2p_write_pdf_stream_dict(tsize_t len , uint32 number , TIFF *output ) ;
tsize_t t2p_write_pdf_stream_dict_start(TIFF *output ) ;
tsize_t t2p_write_pdf_stream_dict_end(TIFF *output ) ;
tsize_t t2p_write_pdf_stream_length(tsize_t len , TIFF *output ) ;
tsize_t t2p_write_pdf_catalog(T2P *t2p , TIFF *output ) ;
tsize_t t2p_write_pdf_info(T2P *t2p , TIFF *input , TIFF *output ) ;
void t2p_pdf_currenttime(T2P *t2p ) ;
void t2p_pdf_tifftime(T2P *t2p , TIFF *input ) ;
tsize_t t2p_write_pdf_pages(T2P *t2p , TIFF *output ) ;
tsize_t t2p_write_pdf_page(uint32 object , T2P *t2p , TIFF *output ) ;
void t2p_compose_pdf_page(T2P *t2p ) ;
void t2p_compose_pdf_page_orient(T2P_BOX *boxp , uint16 orientation ) ;
void t2p_compose_pdf_page_orient_flip(T2P_BOX *boxp , uint16 orientation ) ;
tsize_t t2p_write_pdf_xobject_stream_dict(ttile_t tile , T2P *t2p ,
                                          TIFF *output ) ;
tsize_t t2p_write_pdf_xobject_cs(T2P *t2p , TIFF *output ) ;
tsize_t t2p_write_pdf_transfer(T2P *t2p , TIFF *output ) ;
tsize_t t2p_write_pdf_transfer_dict(T2P *t2p , TIFF *output , uint16 i ) ;
tsize_t t2p_write_pdf_transfer_stream(T2P *t2p , TIFF *output , uint16 i ) ;
tsize_t t2p_write_pdf_xobject_calcs(T2P *t2p , TIFF *output ) ;
tsize_t t2p_write_pdf_xobject_icccs(T2P *t2p , TIFF *output ) ;
tsize_t t2p_write_pdf_xobject_icccs_dict(T2P *t2p , TIFF *output ) ;
tsize_t t2p_write_pdf_xobject_icccs_stream(T2P *t2p , TIFF *output ) ;
tsize_t t2p_write_pdf_xobject_decode(T2P *t2p , TIFF *output ) ;
tsize_t t2p_write_pdf_xobject_stream_filter(ttile_t tile , T2P *t2p ,
                                            TIFF *output ) ;
tsize_t t2p_write_pdf_xreftable(T2P *t2p , TIFF *output ) ;
tsize_t t2p_write_pdf_trailer(T2P *t2p , TIFF *output ) ;
static void t2p_disable(TIFF *tif ) 
{ 
  T2P *t2p ;
  thandle_t tmp ;

  {
  tmp = TIFFClientdata(tif);
  t2p = (T2P *)tmp;
  t2p->outputdisable = 1;
  return;
}
}
static void t2p_enable(TIFF *tif ) 
{ 
  T2P *t2p ;
  thandle_t tmp ;

  {
  tmp = TIFFClientdata(tif);
  t2p = (T2P *)tmp;
  t2p->outputdisable = 0;
  return;
}
}
static tmsize_t t2pWriteFile(TIFF *tif , tdata_t data , tmsize_t size ) 
{ 
  thandle_t client ;
  thandle_t tmp ;
  tmsize_t (*proc)(thandle_t  , void * , tmsize_t  ) ;
  tmsize_t (*tmp___0)(thandle_t  , void * , tmsize_t  ) ;
  tmsize_t tmp___1 ;

  {
  tmp = TIFFClientdata(tif);
  client = tmp;
  tmp___0 = TIFFGetWriteProc(tif);
  proc = tmp___0;
  if (proc) {
    tmp___1 = (*proc)(client, data, size);
    return (tmp___1);
  } else {

  }
  return ((tmsize_t )-1);
}
}
static uint64 t2pSeekFile(TIFF *tif , toff_t offset , int whence ) 
{ 
  thandle_t client ;
  thandle_t tmp ;
  toff_t (*proc)(thandle_t  , toff_t  , int  ) ;
  toff_t (*tmp___0)(thandle_t  , toff_t  , int  ) ;
  toff_t tmp___1 ;

  {
  tmp = TIFFClientdata(tif);
  client = tmp;
  tmp___0 = TIFFGetSeekProc(tif);
  proc = tmp___0;
  if (proc) {
    tmp___1 = (*proc)(client, offset, whence);
    return (tmp___1);
  } else {

  }
  return ((uint64 )-1);
}
}
static tmsize_t t2p_readproc(thandle_t handle , tdata_t data , tmsize_t size ) 
{ 


  {
  return ((tmsize_t )-1);
}
}
static tmsize_t t2p_writeproc(thandle_t handle , tdata_t data , tmsize_t size ) 
{ 
  T2P *t2p ;
  tsize_t written ;
  size_t tmp ;

  {
  t2p = (T2P *)handle;
  if (t2p->outputdisable <= 0) {
    if (t2p->outputfile) {
      tmp = fwrite((void const   */* __restrict  */)data, (size_t )1,
                   (size_t )size, (FILE */* __restrict  */)t2p->outputfile);
      written = (tsize_t )tmp;
      t2p->outputwritten += written;
      return (written);
    } else {

    }
  } else {

  }
  return (size);
}
}
static uint64 t2p_seekproc(thandle_t handle , uint64 offset , int whence ) 
{ 
  T2P *t2p ;
  int tmp ;

  {
  t2p = (T2P *)handle;
  if (t2p->outputdisable <= 0) {
    if (t2p->outputfile) {
      tmp = fseek(t2p->outputfile, (long )offset, whence);
      return ((uint64 )tmp);
    } else {

    }
  } else {

  }
  return (offset);
}
}
static int t2p_closeproc(thandle_t handle ) 
{ 


  {
  return (0);
}
}
static uint64 t2p_sizeproc(thandle_t handle ) 
{ 


  {
  return ((uint64 )-1);
}
}
static int t2p_mapproc(thandle_t handle , void **data , toff_t *offset ) 
{ 


  {
  return (-1);
}
}
static void t2p_unmapproc(thandle_t handle , void *data , toff_t offset ) 
{ 


  {
  return;
}
}
extern char *optarg ;
extern int optind ;
extern int getopt() ;
int main(int argc , char **argv ) 
{ 
  char const   *outfilename ;
  T2P *t2p ;
  TIFF *input ;
  TIFF *output ;
  tsize_t written ;
  int c ;
  int ret ;
  int tmp ;
  double tmp___0 ;
  float tmp___1 ;
  double tmp___2 ;
  float tmp___3 ;
  double tmp___4 ;
  float tmp___5 ;
  double tmp___6 ;
  float tmp___7 ;
  int tmp___8 ;
  size_t tmp___9 ;
  int tmp___10 ;

  {
  outfilename = (char const   *)((void *)0);
  t2p = (T2P *)((void *)0);
  input = (TIFF *)((void *)0);
  output = (TIFF *)((void *)0);
  written = (tsize_t )0;
  ret = 0;
  t2p = t2p_init();
  if ((unsigned long )t2p == (unsigned long )((void *)0)) {
    TIFFError("tiff2pdf", "Can\'t initialize context");
    goto fail;
  } else {

  }
  while (1) {
    if (argv) {
      c = getopt(argc, argv, "o:q:u:x:y:w:l:r:p:e:c:a:t:s:k:jzndifbh");
      if (! (c != -1)) {
        break;
      } else {

      }
    } else {
      break;
    }
    switch (c) {
    case 111: 
    outfilename = (char const   *)optarg;
    break;
    case 106: 
    TIFFWarning("tiff2pdf",
                "JPEG support in libtiff required for JPEG compression, ignoring option");
    break;
    case 122: 
    TIFFWarning("tiff2pdf",
                "Zip support in libtiff required for Zip compression, ignoring option");
    break;
    case 113: 
    tmp = atoi((char const   *)optarg);
    t2p->pdf_defaultcompressionquality = (uint16 )tmp;
    break;
    case 110: 
    t2p->pdf_nopassthrough = (uint16 )1;
    break;
    case 100: 
    t2p->pdf_defaultcompression = (t2p_compress_t )0;
    break;
    case 117: 
    if ((int )*(optarg + 0) == 109) {
      t2p->pdf_centimeters = (uint16 )1;
    } else {

    }
    break;
    case 120: 
    tmp___0 = atof((char const   *)optarg);
    if (t2p->pdf_centimeters) {
      tmp___1 = 2.54F;
    } else {
      tmp___1 = 1.0F;
    }
    t2p->pdf_defaultxres = (float )tmp___0 / tmp___1;
    break;
    case 121: 
    tmp___2 = atof((char const   *)optarg);
    if (t2p->pdf_centimeters) {
      tmp___3 = 2.54F;
    } else {
      tmp___3 = 1.0F;
    }
    t2p->pdf_defaultyres = (float )tmp___2 / tmp___3;
    break;
    case 119: 
    t2p->pdf_overridepagesize = (uint16 )1;
    tmp___4 = atof((char const   *)optarg);
    if (t2p->pdf_centimeters) {
      tmp___5 = 2.54F;
    } else {
      tmp___5 = 1.0F;
    }
    t2p->pdf_defaultpagewidth = ((float )tmp___4 * 72.0F) / tmp___5;
    break;
    case 108: 
    t2p->pdf_overridepagesize = (uint16 )1;
    tmp___6 = atof((char const   *)optarg);
    if (t2p->pdf_centimeters) {
      tmp___7 = 2.54F;
    } else {
      tmp___7 = 1.0F;
    }
    t2p->pdf_defaultpagelength = ((float )tmp___6 * 72.0F) / tmp___7;
    break;
    case 114: 
    if ((int )*(optarg + 0) == 111) {
      t2p->pdf_overrideres = (uint16 )1;
    } else {

    }
    break;
    case 112: 
    tmp___8 = tiff2pdf_match_paper_size(& t2p->pdf_defaultpagewidth,
                                        & t2p->pdf_defaultpagelength, optarg);
    if (tmp___8) {
      t2p->pdf_overridepagesize = (uint16 )1;
    } else {
      TIFFWarning("tiff2pdf", "Unknown paper size %s, ignoring option", optarg);
    }
    break;
    case 105: 
    t2p->pdf_colorspace_invert = (uint16 )1;
    break;
    case 102: 
    t2p->pdf_fitwindow = (uint16 )1;
    break;
    case 101: 
    tmp___9 = strlen((char const   *)optarg);
    if (tmp___9 == 0UL) {
      t2p->pdf_datetime[0] = (char )'\000';
    } else {
      t2p->pdf_datetime[0] = (char )'D';
      t2p->pdf_datetime[1] = (char )':';
      strncpy((char */* __restrict  */)(t2p->pdf_datetime + 2),
              (char const   */* __restrict  */)optarg,
              sizeof(t2p->pdf_datetime) - 3UL);
      t2p->pdf_datetime[sizeof(t2p->pdf_datetime) - 1UL] = (char )'\000';
    }
    break;
    case 99: 
    strncpy((char */* __restrict  */)(t2p->pdf_creator),
            (char const   */* __restrict  */)optarg,
            sizeof(t2p->pdf_creator) - 1UL);
    t2p->pdf_creator[sizeof(t2p->pdf_creator) - 1UL] = (char )'\000';
    break;
    case 97: 
    strncpy((char */* __restrict  */)(t2p->pdf_author),
            (char const   */* __restrict  */)optarg,
            sizeof(t2p->pdf_author) - 1UL);
    t2p->pdf_author[sizeof(t2p->pdf_author) - 1UL] = (char )'\000';
    break;
    case 116: 
    strncpy((char */* __restrict  */)(t2p->pdf_title),
            (char const   */* __restrict  */)optarg,
            sizeof(t2p->pdf_title) - 1UL);
    t2p->pdf_title[sizeof(t2p->pdf_title) - 1UL] = (char )'\000';
    break;
    case 115: 
    strncpy((char */* __restrict  */)(t2p->pdf_subject),
            (char const   */* __restrict  */)optarg,
            sizeof(t2p->pdf_subject) - 1UL);
    t2p->pdf_subject[sizeof(t2p->pdf_subject) - 1UL] = (char )'\000';
    break;
    case 107: 
    strncpy((char */* __restrict  */)(t2p->pdf_keywords),
            (char const   */* __restrict  */)optarg,
            sizeof(t2p->pdf_keywords) - 1UL);
    t2p->pdf_keywords[sizeof(t2p->pdf_keywords) - 1UL] = (char )'\000';
    break;
    case 98: 
    t2p->pdf_image_interpolate = 1;
    break;
    case 104: 
    case 63: 
    tiff2pdf_usage();
    goto success;
    break;
    }
  }
  if (argc > optind) {
    tmp___10 = optind;
    optind ++;
    input = TIFFOpen((char const   *)*(argv + tmp___10), "r");
    if ((unsigned long )input == (unsigned long )((void *)0)) {
      TIFFError("tiff2pdf", "Can\'t open input file %s for reading",
                *(argv + (optind - 1)));
      goto fail;
    } else {

    }
  } else {
    TIFFError("tiff2pdf", "No input file specified");
    tiff2pdf_usage();
    goto fail;
  }
  if (argc > optind) {
    TIFFError("tiff2pdf", "No support for multiple input files");
    tiff2pdf_usage();
    goto fail;
  } else {

  }
  t2p->outputdisable = 0;
  if (outfilename) {
    t2p->outputfile = fopen((char const   */* __restrict  */)outfilename,
                            (char const   */* __restrict  */)"wb");
    if ((unsigned long )t2p->outputfile == (unsigned long )((void *)0)) {
      TIFFError("tiff2pdf", "Can\'t open output file %s for writing",
                outfilename);
      goto fail;
    } else {

    }
  } else {
    outfilename = "-";
    t2p->outputfile = stdout;
  }
  output = TIFFClientOpen(outfilename, "w", (thandle_t )t2p, & t2p_readproc,
                          & t2p_writeproc, & t2p_seekproc, & t2p_closeproc,
                          & t2p_sizeproc, & t2p_mapproc, & t2p_unmapproc);
  if ((unsigned long )output == (unsigned long )((void *)0)) {
    TIFFError("tiff2pdf", "Can\'t initialize output descriptor");
    goto fail;
  } else {

  }
  t2p_validate(t2p);
  t2pSeekFile(output, (toff_t )0, 0);
  written = t2p_write_pdf(t2p, input, output);
  if ((unsigned int )t2p->t2p_error != 0U) {
    TIFFError("tiff2pdf", "An error occurred creating output PDF file");
    goto fail;
  } else {

  }
  __repair_del_190__0: /* CIL Label */ 
  fail: ;
  success: 
  if ((unsigned long )input != (unsigned long )((void *)0)) {
    TIFFClose(input);
  } else {

  }
  if ((unsigned long )output != (unsigned long )((void *)0)) {
    TIFFClose(output);
  } else {

  }
  if ((unsigned long )t2p != (unsigned long )((void *)0)) {
    t2p_free(t2p);
  } else {

  }
  return (ret);
}
}
void tiff2pdf_usage(void) 
{ 
  char *lines[24] ;
  int i ;
  char const   *tmp ;

  {
  lines[0] = (char *)"usage:  tiff2pdf [options] input.tiff";
  lines[1] = (char *)"options:";
  lines[2] = (char *)" -o: output to file name";
  lines[3] = (char *)" -q: compression quality";
  lines[4] = (char *)" -n: no compressed data passthrough";
  lines[5] = (char *)" -d: do not compress (decompress)";
  lines[6] = (char *)" -i: invert colors";
  lines[7] = (char *)" -u: set distance unit, \'i\' for inch, \'m\' for centimeter";
  lines[8] = (char *)" -x: set x resolution default in dots per unit";
  lines[9] = (char *)" -y: set y resolution default in dots per unit";
  lines[10] = (char *)" -w: width in units";
  lines[11] = (char *)" -l: length in units";
  lines[12] = (char *)" -r: \'d\' for resolution default, \'o\' for resolution override";
  lines[13] = (char *)" -p: paper size, eg \"letter\", \"legal\", \"A4\"";
  lines[14] = (char *)" -f: set PDF \"Fit Window\" user preference";
  lines[15] = (char *)" -e: date, overrides image or current date/time default, YYYYMMDDHHMMSS";
  lines[16] = (char *)" -c: sets document creator, overrides image software default";
  lines[17] = (char *)" -a: sets document author, overrides image artist default";
  lines[18] = (char *)" -t: sets document title, overrides image document name default";
  lines[19] = (char *)" -s: sets document subject, overrides image image description default";
  lines[20] = (char *)" -k: sets document keywords";
  lines[21] = (char *)" -b: set PDF \"Interpolate\" user preference";
  lines[22] = (char *)" -h: usage";
  lines[23] = (char *)((void *)0);
  i = 0;
  tmp = TIFFGetVersion();
  fprintf((FILE */* __restrict  */)stderr,
          (char const   */* __restrict  */)"%s\n\n", tmp);
  i = 0;
  while ((unsigned long )lines[i] != (unsigned long )((void *)0)) {
    fprintf((FILE */* __restrict  */)stderr,
            (char const   */* __restrict  */)"%s\n", lines[i]);
    i ++;
  }
  return;
}
}
int tiff2pdf_match_paper_size(float *width , float *length , char *papersize ) 
{ 
  size_t i ;
  size_t len ;
  char const   *sizes[80] ;
  int widths[80] ;
  int lengths[80] ;
  int tmp ;
  int tmp___0 ;

  {
  sizes[0] = "LETTER";
  sizes[1] = "A4";
  sizes[2] = "LEGAL";
  sizes[3] = "EXECUTIVE";
  sizes[4] = "LETTER";
  sizes[5] = "LEGAL";
  sizes[6] = "LEDGER";
  sizes[7] = "TABLOID";
  sizes[8] = "A";
  sizes[9] = "B";
  sizes[10] = "C";
  sizes[11] = "D";
  sizes[12] = "E";
  sizes[13] = "F";
  sizes[14] = "G";
  sizes[15] = "H";
  sizes[16] = "J";
  sizes[17] = "K";
  sizes[18] = "A10";
  sizes[19] = "A9";
  sizes[20] = "A8";
  sizes[21] = "A7";
  sizes[22] = "A6";
  sizes[23] = "A5";
  sizes[24] = "A4";
  sizes[25] = "A3";
  sizes[26] = "A2";
  sizes[27] = "A1";
  sizes[28] = "A0";
  sizes[29] = "2A0";
  sizes[30] = "4A0";
  sizes[31] = "2A";
  sizes[32] = "4A";
  sizes[33] = "B10";
  sizes[34] = "B9";
  sizes[35] = "B8";
  sizes[36] = "B7";
  sizes[37] = "B6";
  sizes[38] = "B5";
  sizes[39] = "B4";
  sizes[40] = "B3";
  sizes[41] = "B2";
  sizes[42] = "B1";
  sizes[43] = "B0";
  sizes[44] = "JISB10";
  sizes[45] = "JISB9";
  sizes[46] = "JISB8";
  sizes[47] = "JISB7";
  sizes[48] = "JISB6";
  sizes[49] = "JISB5";
  sizes[50] = "JISB4";
  sizes[51] = "JISB3";
  sizes[52] = "JISB2";
  sizes[53] = "JISB1";
  sizes[54] = "JISB0";
  sizes[55] = "C10";
  sizes[56] = "C9";
  sizes[57] = "C8";
  sizes[58] = "C7";
  sizes[59] = "C6";
  sizes[60] = "C5";
  sizes[61] = "C4";
  sizes[62] = "C3";
  sizes[63] = "C2";
  sizes[64] = "C1";
  sizes[65] = "C0";
  sizes[66] = "RA2";
  sizes[67] = "RA1";
  sizes[68] = "RA0";
  sizes[69] = "SRA4";
  sizes[70] = "SRA3";
  sizes[71] = "SRA2";
  sizes[72] = "SRA1";
  sizes[73] = "SRA0";
  sizes[74] = "A3EXTRA";
  sizes[75] = "A4EXTRA";
  sizes[76] = "STATEMENT";
  sizes[77] = "FOLIO";
  sizes[78] = "QUARTO";
  sizes[79] = (char const   *)((void *)0);
  widths[0] = 612;
  widths[1] = 595;
  widths[2] = 612;
  widths[3] = 522;
  widths[4] = 612;
  widths[5] = 612;
  widths[6] = 792;
  widths[7] = 792;
  widths[8] = 612;
  widths[9] = 792;
  widths[10] = 1224;
  widths[11] = 1584;
  widths[12] = 2448;
  widths[13] = 2016;
  widths[14] = 792;
  widths[15] = 2016;
  widths[16] = 2448;
  widths[17] = 2880;
  widths[18] = 74;
  widths[19] = 105;
  widths[20] = 147;
  widths[21] = 210;
  widths[22] = 298;
  widths[23] = 420;
  widths[24] = 595;
  widths[25] = 842;
  widths[26] = 1191;
  widths[27] = 1684;
  widths[28] = 2384;
  widths[29] = 3370;
  widths[30] = 4768;
  widths[31] = 3370;
  widths[32] = 4768;
  widths[33] = 88;
  widths[34] = 125;
  widths[35] = 176;
  widths[36] = 249;
  widths[37] = 354;
  widths[38] = 499;
  widths[39] = 709;
  widths[40] = 1001;
  widths[41] = 1417;
  widths[42] = 2004;
  widths[43] = 2835;
  widths[44] = 91;
  widths[45] = 128;
  widths[46] = 181;
  widths[47] = 258;
  widths[48] = 363;
  widths[49] = 516;
  widths[50] = 729;
  widths[51] = 1032;
  widths[52] = 1460;
  widths[53] = 2064;
  widths[54] = 2920;
  widths[55] = 79;
  widths[56] = 113;
  widths[57] = 162;
  widths[58] = 230;
  widths[59] = 323;
  widths[60] = 459;
  widths[61] = 649;
  widths[62] = 918;
  widths[63] = 1298;
  widths[64] = 1298;
  widths[65] = 2599;
  widths[66] = 1219;
  widths[67] = 1729;
  widths[68] = 2438;
  widths[69] = 638;
  widths[70] = 907;
  widths[71] = 1276;
  widths[72] = 1814;
  widths[73] = 2551;
  widths[74] = 914;
  widths[75] = 667;
  widths[76] = 396;
  widths[77] = 612;
  widths[78] = 609;
  widths[79] = 0;
  lengths[0] = 792;
  lengths[1] = 842;
  lengths[2] = 1008;
  lengths[3] = 756;
  lengths[4] = 792;
  lengths[5] = 1008;
  lengths[6] = 1224;
  lengths[7] = 1224;
  lengths[8] = 792;
  lengths[9] = 1224;
  lengths[10] = 1584;
  lengths[11] = 2448;
  lengths[12] = 3168;
  lengths[13] = 2880;
  lengths[14] = 6480;
  lengths[15] = 10296;
  lengths[16] = 12672;
  lengths[17] = 10296;
  lengths[18] = 105;
  lengths[19] = 147;
  lengths[20] = 210;
  lengths[21] = 298;
  lengths[22] = 420;
  lengths[23] = 595;
  lengths[24] = 842;
  lengths[25] = 1191;
  lengths[26] = 1684;
  lengths[27] = 2384;
  lengths[28] = 3370;
  lengths[29] = 4768;
  lengths[30] = 6741;
  lengths[31] = 4768;
  lengths[32] = 6741;
  lengths[33] = 125;
  lengths[34] = 176;
  lengths[35] = 249;
  lengths[36] = 354;
  lengths[37] = 499;
  lengths[38] = 709;
  lengths[39] = 1001;
  lengths[40] = 1417;
  lengths[41] = 2004;
  lengths[42] = 2835;
  lengths[43] = 4008;
  lengths[44] = 128;
  lengths[45] = 181;
  lengths[46] = 258;
  lengths[47] = 363;
  lengths[48] = 516;
  lengths[49] = 729;
  lengths[50] = 1032;
  lengths[51] = 1460;
  lengths[52] = 2064;
  lengths[53] = 2920;
  lengths[54] = 4127;
  lengths[55] = 113;
  lengths[56] = 162;
  lengths[57] = 230;
  lengths[58] = 323;
  lengths[59] = 459;
  lengths[60] = 649;
  lengths[61] = 918;
  lengths[62] = 1298;
  lengths[63] = 1837;
  lengths[64] = 1837;
  lengths[65] = 3677;
  lengths[66] = 1729;
  lengths[67] = 2438;
  lengths[68] = 3458;
  lengths[69] = 907;
  lengths[70] = 1276;
  lengths[71] = 1814;
  lengths[72] = 2551;
  lengths[73] = 3628;
  lengths[74] = 1262;
  lengths[75] = 914;
  lengths[76] = 612;
  lengths[77] = 936;
  lengths[78] = 780;
  lengths[79] = 0;
  len = strlen((char const   *)papersize);
  i = (size_t )0;
  while (i < len) {
    tmp = toupper((int )*(papersize + i));
    *(papersize + i) = (char )tmp;
    i ++;
  }
  i = (size_t )0;
  while ((unsigned long )sizes[i] != (unsigned long )((void *)0)) {
    tmp___0 = strcmp((char const   *)papersize, sizes[i]);
    if (tmp___0 == 0) {
      *width = (float )widths[i];
      *length = (float )lengths[i];
      return (1);
    } else {

    }
    i ++;
  }
  return (0);
}
}
T2P *t2p_init(void) 
{ 
  T2P *t2p ;
  void *tmp ;

  {
  tmp = _TIFFmalloc((tmsize_t )sizeof(T2P ));
  t2p = (T2P *)tmp;
  if ((unsigned long )t2p == (unsigned long )((void *)0)) {
    TIFFError("tiff2pdf", "Can\'t allocate %lu bytes of memory for t2p_init",
              sizeof(T2P ));
    return ((T2P *)((void *)0));
  } else {

  }
  _TIFFmemset((void *)t2p, 0, (tmsize_t )sizeof(T2P ));
  t2p->pdf_majorversion = (uint16 )1;
  t2p->pdf_minorversion = (uint16 )1;
  t2p->pdf_defaultxres = (float )300.0;
  t2p->pdf_defaultyres = (float )300.0;
  t2p->pdf_defaultpagewidth = (float )612.0;
  t2p->pdf_defaultpagelength = (float )792.0;
  t2p->pdf_xrefcount = (uint32 )3;
  return (t2p);
}
}
void t2p_free(T2P *t2p ) 
{ 
  int i ;

  {
  i = 0;
  if ((unsigned long )t2p != (unsigned long )((void *)0)) {
    if ((unsigned long )t2p->pdf_xrefoffsets != (unsigned long )((void *)0)) {
      _TIFFfree((tdata_t )t2p->pdf_xrefoffsets);
    } else {

    }
    if ((unsigned long )t2p->tiff_pages != (unsigned long )((void *)0)) {
      _TIFFfree((tdata_t )t2p->tiff_pages);
    } else {

    }
    i = 0;
    while (i < (int )t2p->tiff_pagecount) {
      if ((unsigned long )(t2p->tiff_tiles + i)->tiles_tiles != (unsigned long )((void *)0)) {
        _TIFFfree((tdata_t )(t2p->tiff_tiles + i)->tiles_tiles);
      } else {

      }
      i ++;
    }
    if ((unsigned long )t2p->tiff_tiles != (unsigned long )((void *)0)) {
      _TIFFfree((tdata_t )t2p->tiff_tiles);
    } else {

    }
    if ((unsigned long )t2p->pdf_palette != (unsigned long )((void *)0)) {
      _TIFFfree((tdata_t )t2p->pdf_palette);
    } else {

    }
    _TIFFfree((tdata_t )t2p);
  } else {

  }
  return;
}
}
void t2p_validate(T2P *t2p ) 
{ 


  {
  return;
}
}
void t2p_read_tiff_init(T2P *t2p , TIFF *input ) 
{ 
  tdir_t directorycount ;
  tdir_t i ;
  uint16 pagen ;
  uint16 paged ;
  uint16 xuint16 ;
  void *tmp ;
  char const   *tmp___0 ;
  void *tmp___1 ;
  char const   *tmp___2 ;
  uint32 subfiletype ;
  char const   *tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;
  int tmp___8 ;
  int tmp___9 ;
  int tmp___10 ;
  int tmp___11 ;
  int tmp___12 ;
  int tmp___13 ;
  void *tmp___14 ;
  char const   *tmp___15 ;

  {
  directorycount = (tdir_t )0;
  i = (tdir_t )0;
  pagen = (uint16 )0;
  paged = (uint16 )0;
  xuint16 = (uint16 )0;
  directorycount = TIFFNumberOfDirectories(input);
  tmp = _TIFFmalloc((tmsize_t )((unsigned long )directorycount * sizeof(T2P_PAGE )));
  t2p->tiff_pages = (T2P_PAGE *)tmp;
  if ((unsigned long )t2p->tiff_pages == (unsigned long )((void *)0)) {
    tmp___0 = TIFFFileName(input);
    TIFFError("tiff2pdf",
              "Can\'t allocate %lu bytes of memory for tiff_pages array, %s",
              (unsigned long )directorycount * sizeof(T2P_PAGE ), tmp___0);
    t2p->t2p_error = (t2p_err_t )1;
    return;
  } else {

  }
  _TIFFmemset((void *)t2p->tiff_pages, 0,
              (tmsize_t )((unsigned long )directorycount * sizeof(T2P_PAGE )));
  tmp___1 = _TIFFmalloc((tmsize_t )((unsigned long )directorycount * sizeof(T2P_TILES )));
  t2p->tiff_tiles = (T2P_TILES *)tmp___1;
  if ((unsigned long )t2p->tiff_tiles == (unsigned long )((void *)0)) {
    tmp___2 = TIFFFileName(input);
    TIFFError("tiff2pdf",
              "Can\'t allocate %lu bytes of memory for tiff_tiles array, %s",
              (unsigned long )directorycount * sizeof(T2P_TILES ), tmp___2);
    t2p->t2p_error = (t2p_err_t )1;
    return;
  } else {

  }
  _TIFFmemset((void *)t2p->tiff_tiles, 0,
              (tmsize_t )((unsigned long )directorycount * sizeof(T2P_TILES )));
  i = (tdir_t )0;
  while ((int )i < (int )directorycount) {
    subfiletype = (uint32 )0;
    tmp___4 = TIFFSetDirectory(input, i);
    if (! tmp___4) {
      tmp___3 = TIFFFileName(input);
      TIFFError("tiff2pdf", "Can\'t set directory %u of input file %s", (int )i,
                tmp___3);
      return;
    } else {

    }
    tmp___5 = TIFFGetField(input, (uint32 )297, & pagen, & paged);
    if (tmp___5) {
      if ((int )pagen > (int )paged) {
        if ((int )paged != 0) {
          (t2p->tiff_pages + (int )t2p->tiff_pagecount)->page_number = (uint32 )paged;
        } else {
          (t2p->tiff_pages + (int )t2p->tiff_pagecount)->page_number = (uint32 )pagen;
        }
      } else {
        (t2p->tiff_pages + (int )t2p->tiff_pagecount)->page_number = (uint32 )pagen;
      }
      goto ispage2;
    } else {

    }
    tmp___6 = TIFFGetField(input, (uint32 )254, & subfiletype);
    if (tmp___6) {
      if ((subfiletype & 2U) != 0U) {
        goto ispage;
      } else
      if (subfiletype == 0U) {
        goto ispage;
      } else {
        goto isnotpage;
      }
    } else {

    }
    tmp___7 = TIFFGetField(input, (uint32 )255, & subfiletype);
    if (tmp___7) {
      if (subfiletype == 1U) {
        goto ispage;
      } else
      if (subfiletype == 3U) {
        goto ispage;
      } else
      if (subfiletype == 0U) {
        goto ispage;
      } else {
        goto isnotpage;
      }
    } else {

    }
    ispage: 
    (t2p->tiff_pages + (int )t2p->tiff_pagecount)->page_number = (uint32 )t2p->tiff_pagecount;
    ispage2: 
    (t2p->tiff_pages + (int )t2p->tiff_pagecount)->page_directory = i;
    tmp___8 = TIFFIsTiled(input);
    if (tmp___8) {
      (t2p->tiff_pages + (int )t2p->tiff_pagecount)->page_tilecount = TIFFNumberOfTiles(input);
    } else {

    }
    t2p->tiff_pagecount = (tdir_t )((int )t2p->tiff_pagecount + 1);
    isnotpage: 
    i = (tdir_t )((int )i + 1);
  }
  qsort((void *)t2p->tiff_pages, (size_t )t2p->tiff_pagecount,
        sizeof(T2P_PAGE ), & t2p_cmp_t2p_page);
  i = (tdir_t )0;
  while ((int )i < (int )t2p->tiff_pagecount) {
    t2p->pdf_xrefcount += 5U;
    TIFFSetDirectory(input, (t2p->tiff_pages + (int )i)->page_directory);
    tmp___9 = TIFFGetField(input, (uint32 )262, & xuint16);
    if (tmp___9) {
      if ((int )xuint16 == 3) {
        ((t2p->tiff_pages + (int )i)->page_extra) ++;
        (t2p->pdf_xrefcount) ++;
      } else {
        goto _L;
      }
    } else {
      _L: 
      tmp___10 = TIFFGetField(input, (uint32 )346, & xuint16);
      if (tmp___10) {
        ((t2p->tiff_pages + (int )i)->page_extra) ++;
        (t2p->pdf_xrefcount) ++;
      } else {

      }
    }
    tmp___11 = TIFFGetField(input, (uint32 )301,
                            & t2p->tiff_transferfunction[0],
                            & t2p->tiff_transferfunction[1],
                            & t2p->tiff_transferfunction[2]);
    if (tmp___11) {
      if ((unsigned long )t2p->tiff_transferfunction[1] != (unsigned long )t2p->tiff_transferfunction[0]) {
        t2p->tiff_transferfunctioncount = (uint16 )3;
        (t2p->tiff_pages + (int )i)->page_extra += 4U;
        t2p->pdf_xrefcount += 4U;
      } else {
        t2p->tiff_transferfunctioncount = (uint16 )1;
        (t2p->tiff_pages + (int )i)->page_extra += 2U;
        t2p->pdf_xrefcount += 2U;
      }
      if ((int )t2p->pdf_minorversion < 2) {
        t2p->pdf_minorversion = (uint16 )2;
      } else {

      }
    } else {
      t2p->tiff_transferfunctioncount = (uint16 )0;
    }
    tmp___12 = TIFFGetField(input, (uint32 )34675, & t2p->tiff_iccprofilelength,
                            & t2p->tiff_iccprofile);
    if (tmp___12 != 0) {
      ((t2p->tiff_pages + (int )i)->page_extra) ++;
      (t2p->pdf_xrefcount) ++;
      if ((int )t2p->pdf_minorversion < 3) {
        t2p->pdf_minorversion = (uint16 )3;
      } else {

      }
    } else {

    }
    (t2p->tiff_tiles + (int )i)->tiles_tilecount = (t2p->tiff_pages + (int )i)->page_tilecount;
    tmp___13 = TIFFGetField(input, (uint32 )284, & xuint16);
    if (tmp___13 != 0) {
      if ((int )xuint16 == 2) {
        TIFFGetField(input, (uint32 )277, & xuint16);
        (t2p->tiff_tiles + (int )i)->tiles_tilecount /= (ttile_t )xuint16;
      } else {

      }
    } else {

    }
    if ((t2p->tiff_tiles + (int )i)->tiles_tilecount > 0U) {
      t2p->pdf_xrefcount += ((t2p->tiff_tiles + (int )i)->tiles_tilecount - 1U) * 2U;
      TIFFGetField(input, (uint32 )322,
                   & (t2p->tiff_tiles + (int )i)->tiles_tilewidth);
      TIFFGetField(input, (uint32 )323,
                   & (t2p->tiff_tiles + (int )i)->tiles_tilelength);
      tmp___14 = _TIFFmalloc((tmsize_t )((unsigned long )(t2p->tiff_tiles + (int )i)->tiles_tilecount * sizeof(T2P_TILE )));
      (t2p->tiff_tiles + (int )i)->tiles_tiles = (T2P_TILE *)tmp___14;
      if ((unsigned long )(t2p->tiff_tiles + (int )i)->tiles_tiles == (unsigned long )((void *)0)) {
        tmp___15 = TIFFFileName(input);
        TIFFError("tiff2pdf",
                  "Can\'t allocate %lu bytes of memory for t2p_read_tiff_init, %s",
                  (unsigned long )(t2p->tiff_tiles + (int )i)->tiles_tilecount * sizeof(T2P_TILE ),
                  tmp___15);
        t2p->t2p_error = (t2p_err_t )1;
        return;
      } else {

      }
    } else {

    }
    i = (tdir_t )((int )i + 1);
  }
  return;
}
}
int t2p_cmp_t2p_page(void const   *e1 , void const   *e2 ) 
{ 


  {
  return ((int )(((T2P_PAGE *)e1)->page_number - ((T2P_PAGE *)e2)->page_number));
}
}
void t2p_read_tiff_data(T2P *t2p , TIFF *input ) 
{ 
  int i ;
  uint16 *r ;
  uint16 *g ;
  uint16 *b ;
  uint16 *a ;
  uint16 xuint16 ;
  uint16 *xuint16p ;
  float *xfloatp ;
  char const   *tmp ;
  char const   *tmp___0 ;
  char const   *tmp___1 ;
  int tmp___2 ;
  char const   *tmp___3 ;
  int tmp___4 ;
  char const   *tmp___5 ;
  char const   *tmp___6 ;
  char const   *tmp___7 ;
  char const   *tmp___8 ;
  char const   *tmp___9 ;
  int tmp___10 ;
  char const   *tmp___11 ;
  int tmp___12 ;
  int tmp___13 ;
  char const   *tmp___14 ;
  int tmp___15 ;
  char const   *tmp___16 ;
  char const   *tmp___17 ;
  char const   *tmp___18 ;
  char const   *tmp___19 ;
  char const   *tmp___20 ;
  int tmp___21 ;
  void *tmp___22 ;
  char const   *tmp___23 ;
  int tmp___24 ;
  char const   *tmp___25 ;
  int tmp___26 ;
  char const   *tmp___27 ;
  char const   *tmp___28 ;
  char const   *tmp___29 ;
  int tmp___30 ;
  void *tmp___31 ;
  char const   *tmp___32 ;
  char const   *tmp___33 ;
  char const   *tmp___34 ;
  char const   *tmp___35 ;
  char const   *tmp___36 ;
  char const   *tmp___37 ;
  int tmp___38 ;
  char const   *tmp___39 ;
  int tmp___40 ;
  int tmp___41 ;
  int tmp___42 ;
  uint32 tmp___43 ;
  int tmp___44 ;
  int tmp___45 ;
  int tmp___46 ;
  int tmp___47 ;
  int tmp___48 ;

  {
  i = 0;
  t2p->pdf_transcode = (t2p_transcode_t )2;
  t2p->pdf_sample = (t2p_sample_t )0;
  t2p->pdf_switchdecode = t2p->pdf_colorspace_invert;
  TIFFSetDirectory(input,
                   (t2p->tiff_pages + (int )t2p->pdf_page)->page_directory);
  TIFFGetField(input, (uint32 )256, & t2p->tiff_width);
  if (t2p->tiff_width == 0U) {
    tmp = TIFFFileName(input);
    TIFFError("tiff2pdf", "No support for %s with zero width", tmp);
    t2p->t2p_error = (t2p_err_t )1;
    return;
  } else {

  }
  TIFFGetField(input, (uint32 )257, & t2p->tiff_length);
  if (t2p->tiff_length == 0U) {
    tmp___0 = TIFFFileName(input);
    TIFFError("tiff2pdf", "No support for %s with zero length", tmp___0);
    t2p->t2p_error = (t2p_err_t )1;
    return;
  } else {

  }
  tmp___2 = TIFFGetField(input, (uint32 )259, & t2p->tiff_compression);
  if (tmp___2 == 0) {
    tmp___1 = TIFFFileName(input);
    TIFFError("tiff2pdf", "No support for %s with no compression tag", tmp___1);
    t2p->t2p_error = (t2p_err_t )1;
    return;
  } else {

  }
  tmp___4 = TIFFIsCODECConfigured(t2p->tiff_compression);
  if (tmp___4 == 0) {
    tmp___3 = TIFFFileName(input);
    TIFFError("tiff2pdf",
              "No support for %s with compression type %u:  not configured",
              tmp___3, (int )t2p->tiff_compression);
    t2p->t2p_error = (t2p_err_t )1;
    return;
  } else {

  }
  TIFFGetFieldDefaulted(input, (uint32 )258, & t2p->tiff_bitspersample);
  switch ((int )t2p->tiff_bitspersample) {
  case 1: 
  case 2: 
  case 4: 
  case 8: 
  break;
  case 0: 
  tmp___5 = TIFFFileName(input);
  TIFFWarning("tiff2pdf", "Image %s has 0 bits per sample, assuming 1", tmp___5);
  t2p->tiff_bitspersample = (uint16 )1;
  break;
  default: 
  tmp___6 = TIFFFileName(input);
  TIFFError("tiff2pdf", "No support for %s with %u bits per sample", tmp___6,
            (int )t2p->tiff_bitspersample);
  t2p->t2p_error = (t2p_err_t )1;
  return;
  }
  TIFFGetFieldDefaulted(input, (uint32 )277, & t2p->tiff_samplesperpixel);
  if ((int )t2p->tiff_samplesperpixel > 4) {
    tmp___7 = TIFFFileName(input);
    TIFFError("tiff2pdf", "No support for %s with %u samples per pixel",
              tmp___7, (int )t2p->tiff_samplesperpixel);
    t2p->t2p_error = (t2p_err_t )1;
    return;
  } else {

  }
  if ((int )t2p->tiff_samplesperpixel == 0) {
    tmp___8 = TIFFFileName(input);
    TIFFWarning("tiff2pdf", "Image %s has 0 samples per pixel, assuming 1",
                tmp___8);
    t2p->tiff_samplesperpixel = (uint16 )1;
  } else {

  }
  tmp___10 = TIFFGetField(input, (uint32 )339, & xuint16);
  if (tmp___10 != 0) {
    switch ((int )xuint16) {
    case 0: 
    case 1: 
    case 4: 
    break;
    default: 
    tmp___9 = TIFFFileName(input);
    TIFFError("tiff2pdf", "No support for %s with sample format %u", tmp___9,
              (int )xuint16);
    t2p->t2p_error = (t2p_err_t )1;
    return;
    break;
    }
  } else {

  }
  TIFFGetFieldDefaulted(input, (uint32 )266, & t2p->tiff_fillorder);
  tmp___12 = TIFFGetField(input, (uint32 )262, & t2p->tiff_photometric);
  if (tmp___12 == 0) {
    tmp___11 = TIFFFileName(input);
    TIFFError("tiff2pdf",
              "No support for %s with no photometric interpretation tag",
              tmp___11);
    t2p->t2p_error = (t2p_err_t )1;
    return;
  } else {

  }
  switch ((int )t2p->tiff_photometric) {
  case 0: 
  case 1: 
  if ((int )t2p->tiff_bitspersample == 1) {
    t2p->pdf_colorspace = (t2p_cs_t )1;
    if ((int )t2p->tiff_photometric == 0) {
      t2p->pdf_switchdecode = (uint16 )((int )t2p->pdf_switchdecode ^ 1);
    } else {

    }
  } else {
    t2p->pdf_colorspace = (t2p_cs_t )2;
    if ((int )t2p->tiff_photometric == 0) {
      t2p->pdf_switchdecode = (uint16 )((int )t2p->pdf_switchdecode ^ 1);
    } else {

    }
  }
  break;
  case 2: 
  t2p->pdf_colorspace = (t2p_cs_t )4;
  if ((int )t2p->tiff_samplesperpixel == 3) {
    break;
  } else {

  }
  tmp___13 = TIFFGetField(input, (uint32 )346, & xuint16);
  if (tmp___13) {
    if ((int )xuint16 == 1) {
      goto photometric_palette;
    } else {

    }
  } else {

  }
  if ((int )t2p->tiff_samplesperpixel > 3) {
    if ((int )t2p->tiff_samplesperpixel == 4) {
      t2p->pdf_colorspace = (t2p_cs_t )4;
      tmp___15 = TIFFGetField(input, (uint32 )338, & xuint16, & xuint16p);
      if (tmp___15) {
        if ((int )xuint16 == 1) {
          if ((int )*(xuint16p + 0) == 1) {
            t2p->pdf_sample = (t2p_sample_t )4;
            break;
          } else {

          }
          if ((int )*(xuint16p + 0) == 2) {
            t2p->pdf_sample = (t2p_sample_t )2;
            break;
          } else {

          }
          tmp___14 = TIFFFileName(input);
          TIFFWarning("tiff2pdf",
                      "RGB image %s has 4 samples per pixel, assuming RGBA",
                      tmp___14);
          break;
        } else {

        }
      } else {

      }
      t2p->pdf_colorspace = (t2p_cs_t )8;
      t2p->pdf_switchdecode = (uint16 )((int )t2p->pdf_switchdecode ^ 1);
      tmp___16 = TIFFFileName(input);
      TIFFWarning("tiff2pdf",
                  "RGB image %s has 4 samples per pixel, assuming inverse CMYK",
                  tmp___16);
      break;
    } else {
      tmp___17 = TIFFFileName(input);
      TIFFError("tiff2pdf",
                "No support for RGB image %s with %u samples per pixel",
                tmp___17, (int )t2p->tiff_samplesperpixel);
      t2p->t2p_error = (t2p_err_t )1;
      break;
    }
  } else {
    tmp___18 = TIFFFileName(input);
    TIFFError("tiff2pdf",
              "No support for RGB image %s with %u samples per pixel", tmp___18,
              (int )t2p->tiff_samplesperpixel);
    t2p->t2p_error = (t2p_err_t )1;
    break;
  }
  case 3: 
  photometric_palette: 
  if ((int )t2p->tiff_samplesperpixel != 1) {
    tmp___19 = TIFFFileName(input);
    TIFFError("tiff2pdf",
              "No support for palettized image %s with not one sample per pixel",
              tmp___19);
    t2p->t2p_error = (t2p_err_t )1;
    return;
  } else {

  }
  t2p->pdf_colorspace = (t2p_cs_t )4100;
  t2p->pdf_palettesize = (uint16 )(1 << (int )t2p->tiff_bitspersample);
  tmp___21 = TIFFGetField(input, (uint32 )320, & r, & g, & b);
  if (! tmp___21) {
    tmp___20 = TIFFFileName(input);
    TIFFError("tiff2pdf", "Palettized image %s has no color map", tmp___20);
    t2p->t2p_error = (t2p_err_t )1;
    return;
  } else {

  }
  if ((unsigned long )t2p->pdf_palette != (unsigned long )((void *)0)) {
    _TIFFfree((void *)t2p->pdf_palette);
    t2p->pdf_palette = (unsigned char *)((void *)0);
  } else {

  }
  tmp___22 = _TIFFmalloc((tmsize_t )((int )t2p->pdf_palettesize * 3));
  t2p->pdf_palette = (unsigned char *)tmp___22;
  if ((unsigned long )t2p->pdf_palette == (unsigned long )((void *)0)) {
    tmp___23 = TIFFFileName(input);
    TIFFError("tiff2pdf",
              "Can\'t allocate %u bytes of memory for t2p_read_tiff_image, %s",
              (int )t2p->pdf_palettesize, tmp___23);
    t2p->t2p_error = (t2p_err_t )1;
    return;
  } else {

  }
  i = 0;
  while (i < (int )t2p->pdf_palettesize) {
    *(t2p->pdf_palette + i * 3) = (unsigned char )((int )*(r + i) >> 8);
    *(t2p->pdf_palette + (i * 3 + 1)) = (unsigned char )((int )*(g + i) >> 8);
    *(t2p->pdf_palette + (i * 3 + 2)) = (unsigned char )((int )*(b + i) >> 8);
    i ++;
  }
  t2p->pdf_palettesize = (uint16 )((int )t2p->pdf_palettesize * 3);
  break;
  case 5: 
  tmp___24 = TIFFGetField(input, (uint32 )346, & xuint16);
  if (tmp___24) {
    if ((int )xuint16 == 1) {
      goto photometric_palette_cmyk;
    } else {

    }
  } else {

  }
  tmp___26 = TIFFGetField(input, (uint32 )332, & xuint16);
  if (tmp___26) {
    if ((int )xuint16 != 1) {
      tmp___25 = TIFFFileName(input);
      TIFFError("tiff2pdf", "No support for %s because its inkset is not CMYK",
                tmp___25);
      t2p->t2p_error = (t2p_err_t )1;
      return;
    } else {

    }
  } else {

  }
  if ((int )t2p->tiff_samplesperpixel == 4) {
    t2p->pdf_colorspace = (t2p_cs_t )8;
  } else {
    tmp___27 = TIFFFileName(input);
    TIFFError("tiff2pdf",
              "No support for %s because it has %u samples per pixel", tmp___27,
              (int )t2p->tiff_samplesperpixel);
    t2p->t2p_error = (t2p_err_t )1;
    return;
  }
  break;
  photometric_palette_cmyk: 
  if ((int )t2p->tiff_samplesperpixel != 1) {
    tmp___28 = TIFFFileName(input);
    TIFFError("tiff2pdf",
              "No support for palettized CMYK image %s with not one sample per pixel",
              tmp___28);
    t2p->t2p_error = (t2p_err_t )1;
    return;
  } else {

  }
  t2p->pdf_colorspace = (t2p_cs_t )4104;
  t2p->pdf_palettesize = (uint16 )(1 << (int )t2p->tiff_bitspersample);
  tmp___30 = TIFFGetField(input, (uint32 )320, & r, & g, & b, & a);
  if (! tmp___30) {
    tmp___29 = TIFFFileName(input);
    TIFFError("tiff2pdf", "Palettized image %s has no color map", tmp___29);
    t2p->t2p_error = (t2p_err_t )1;
    return;
  } else {

  }
  if ((unsigned long )t2p->pdf_palette != (unsigned long )((void *)0)) {
    _TIFFfree((void *)t2p->pdf_palette);
    t2p->pdf_palette = (unsigned char *)((void *)0);
  } else {

  }
  tmp___31 = _TIFFmalloc((tmsize_t )((int )t2p->pdf_palettesize * 4));
  t2p->pdf_palette = (unsigned char *)tmp___31;
  if ((unsigned long )t2p->pdf_palette == (unsigned long )((void *)0)) {
    tmp___32 = TIFFFileName(input);
    TIFFError("tiff2pdf",
              "Can\'t allocate %u bytes of memory for t2p_read_tiff_image, %s",
              (int )t2p->pdf_palettesize, tmp___32);
    t2p->t2p_error = (t2p_err_t )1;
    return;
  } else {

  }
  i = 0;
  while (i < (int )t2p->pdf_palettesize) {
    *(t2p->pdf_palette + i * 4) = (unsigned char )((int )*(r + i) >> 8);
    *(t2p->pdf_palette + (i * 4 + 1)) = (unsigned char )((int )*(g + i) >> 8);
    *(t2p->pdf_palette + (i * 4 + 2)) = (unsigned char )((int )*(b + i) >> 8);
    *(t2p->pdf_palette + (i * 4 + 3)) = (unsigned char )((int )*(a + i) >> 8);
    i ++;
  }
  t2p->pdf_palettesize = (uint16 )((int )t2p->pdf_palettesize * 4);
  break;
  case 6: 
  t2p->pdf_colorspace = (t2p_cs_t )4;
  if ((int )t2p->tiff_samplesperpixel == 1) {
    t2p->pdf_colorspace = (t2p_cs_t )2;
    t2p->tiff_photometric = (uint16 )1;
    break;
  } else {

  }
  t2p->pdf_sample = (t2p_sample_t )8;
  break;
  case 8: 
  t2p->pdf_labrange[0] = -127;
  t2p->pdf_labrange[1] = 127;
  t2p->pdf_labrange[2] = -127;
  t2p->pdf_labrange[3] = 127;
  t2p->pdf_sample = (t2p_sample_t )64;
  t2p->pdf_colorspace = (t2p_cs_t )16;
  break;
  case 9: 
  t2p->pdf_labrange[0] = 0;
  t2p->pdf_labrange[1] = 255;
  t2p->pdf_labrange[2] = 0;
  t2p->pdf_labrange[3] = 255;
  t2p->pdf_colorspace = (t2p_cs_t )16;
  break;
  case 10: 
  t2p->pdf_labrange[0] = -85;
  t2p->pdf_labrange[1] = 85;
  t2p->pdf_labrange[2] = -75;
  t2p->pdf_labrange[3] = 124;
  t2p->pdf_sample = (t2p_sample_t )64;
  t2p->pdf_colorspace = (t2p_cs_t )16;
  break;
  case 32844: 
  case 32845: 
  tmp___33 = TIFFFileName(input);
  TIFFError("tiff2pdf",
            "No support for %s with photometric interpretation LogL/LogLuv",
            tmp___33);
  t2p->t2p_error = (t2p_err_t )1;
  return;
  default: 
  tmp___34 = TIFFFileName(input);
  TIFFError("tiff2pdf", "No support for %s with photometric interpretation %u",
            tmp___34, (int )t2p->tiff_photometric);
  t2p->t2p_error = (t2p_err_t )1;
  return;
  }
  tmp___38 = TIFFGetField(input, (uint32 )284, & t2p->tiff_planar);
  if (tmp___38) {
    switch ((int )t2p->tiff_planar) {
    case 0: 
    tmp___35 = TIFFFileName(input);
    TIFFWarning("tiff2pdf", "Image %s has planar configuration 0, assuming 1",
                tmp___35);
    t2p->tiff_planar = (uint16 )1;
    case 1: 
    break;
    case 2: 
    t2p->pdf_sample = (t2p_sample_t )256;
    if ((int )t2p->tiff_bitspersample != 8) {
      tmp___36 = TIFFFileName(input);
      TIFFError("tiff2pdf",
                "No support for %s with separated planar configuration and %u bits per sample",
                tmp___36, (int )t2p->tiff_bitspersample);
      t2p->t2p_error = (t2p_err_t )1;
      return;
    } else {

    }
    break;
    default: 
    tmp___37 = TIFFFileName(input);
    TIFFError("tiff2pdf", "No support for %s with planar configuration %u",
              tmp___37, (int )t2p->tiff_planar);
    t2p->t2p_error = (t2p_err_t )1;
    return;
    }
  } else {

  }
  TIFFGetFieldDefaulted(input, (uint32 )274, & t2p->tiff_orientation);
  if ((int )t2p->tiff_orientation > 8) {
    tmp___39 = TIFFFileName(input);
    TIFFWarning("tiff2pdf", "Image %s has orientation %u, assuming 0", tmp___39,
                (int )t2p->tiff_orientation);
    t2p->tiff_orientation = (uint16 )0;
  } else {

  }
  tmp___40 = TIFFGetField(input, (uint32 )282, & t2p->tiff_xres);
  if (tmp___40 == 0) {
    t2p->tiff_xres = (float )0.0;
  } else {

  }
  tmp___41 = TIFFGetField(input, (uint32 )283, & t2p->tiff_yres);
  if (tmp___41 == 0) {
    t2p->tiff_yres = (float )0.0;
  } else {

  }
  TIFFGetFieldDefaulted(input, (uint32 )296, & t2p->tiff_resunit);
  if ((int )t2p->tiff_resunit == 3) {
    t2p->tiff_xres *= 2.54F;
    t2p->tiff_yres *= 2.54F;
  } else
  if ((int )t2p->tiff_resunit != 2) {
    if ((int )t2p->pdf_centimeters != 0) {
      t2p->tiff_xres *= 2.54F;
      t2p->tiff_yres *= 2.54F;
    } else {

    }
  } else {

  }
  t2p_compose_pdf_page(t2p);
  t2p->pdf_transcode = (t2p_transcode_t )2;
  if ((int )t2p->pdf_nopassthrough == 0) {
    if ((int )t2p->tiff_compression == 4) {
      tmp___42 = TIFFIsTiled(input);
      if (tmp___42) {
        t2p->pdf_transcode = (t2p_transcode_t )1;
        t2p->pdf_compression = (t2p_compress_t )1;
      } else {
        tmp___43 = TIFFNumberOfStrips(input);
        if (tmp___43 == 1U) {
          t2p->pdf_transcode = (t2p_transcode_t )1;
          t2p->pdf_compression = (t2p_compress_t )1;
        } else {

        }
      }
    } else {

    }
  } else {

  }
  if ((unsigned int )t2p->pdf_transcode != 1U) {
    t2p->pdf_compression = t2p->pdf_defaultcompression;
  } else {

  }
  if ((unsigned int )t2p->pdf_sample & 32U) {
    if ((unsigned int )t2p->pdf_colorspace & 8U) {
      t2p->tiff_samplesperpixel = (uint16 )4;
      t2p->tiff_photometric = (uint16 )5;
    } else {
      t2p->tiff_samplesperpixel = (uint16 )3;
      t2p->tiff_photometric = (uint16 )2;
    }
  } else {

  }
  tmp___44 = TIFFGetField(input, (uint32 )301, & t2p->tiff_transferfunction[0],
                          & t2p->tiff_transferfunction[1],
                          & t2p->tiff_transferfunction[2]);
  if (tmp___44) {
    if ((unsigned long )t2p->tiff_transferfunction[1] != (unsigned long )t2p->tiff_transferfunction[0]) {
      t2p->tiff_transferfunctioncount = (uint16 )3;
    } else {
      t2p->tiff_transferfunctioncount = (uint16 )1;
    }
  } else {
    t2p->tiff_transferfunctioncount = (uint16 )0;
  }
  tmp___45 = TIFFGetField(input, (uint32 )318, & xfloatp);
  if (tmp___45 != 0) {
    t2p->tiff_whitechromaticities[0] = *(xfloatp + 0);
    t2p->tiff_whitechromaticities[1] = *(xfloatp + 1);
    if ((unsigned int )t2p->pdf_colorspace & 2U) {
      t2p->pdf_colorspace = (t2p_cs_t )((unsigned int )t2p->pdf_colorspace | 32U);
    } else {

    }
    if ((unsigned int )t2p->pdf_colorspace & 4U) {
      t2p->pdf_colorspace = (t2p_cs_t )((unsigned int )t2p->pdf_colorspace | 64U);
    } else {

    }
  } else {

  }
  tmp___46 = TIFFGetField(input, (uint32 )319, & xfloatp);
  if (tmp___46 != 0) {
    t2p->tiff_primarychromaticities[0] = *(xfloatp + 0);
    t2p->tiff_primarychromaticities[1] = *(xfloatp + 1);
    t2p->tiff_primarychromaticities[2] = *(xfloatp + 2);
    t2p->tiff_primarychromaticities[3] = *(xfloatp + 3);
    t2p->tiff_primarychromaticities[4] = *(xfloatp + 4);
    t2p->tiff_primarychromaticities[5] = *(xfloatp + 5);
    if ((unsigned int )t2p->pdf_colorspace & 4U) {
      t2p->pdf_colorspace = (t2p_cs_t )((unsigned int )t2p->pdf_colorspace | 64U);
    } else {

    }
  } else {

  }
  if ((unsigned int )t2p->pdf_colorspace & 16U) {
    tmp___47 = TIFFGetField(input, (uint32 )318, & xfloatp);
    if (tmp___47 != 0) {
      t2p->tiff_whitechromaticities[0] = *(xfloatp + 0);
      t2p->tiff_whitechromaticities[1] = *(xfloatp + 1);
    } else {
      t2p->tiff_whitechromaticities[0] = 0.3457F;
      t2p->tiff_whitechromaticities[1] = 0.3585F;
    }
  } else {

  }
  tmp___48 = TIFFGetField(input, (uint32 )34675, & t2p->tiff_iccprofilelength,
                          & t2p->tiff_iccprofile);
  if (tmp___48 != 0) {
    t2p->pdf_colorspace = (t2p_cs_t )((unsigned int )t2p->pdf_colorspace | 128U);
  } else {
    t2p->tiff_iccprofilelength = (uint32 )0;
    t2p->tiff_iccprofile = (void *)0;
  }
  if ((int )t2p->tiff_bitspersample == 1) {
    if ((int )t2p->tiff_samplesperpixel == 1) {
      t2p->pdf_compression = (t2p_compress_t )1;
    } else {

    }
  } else {

  }
  return;
}
}
void t2p_read_tiff_size(T2P *t2p , TIFF *input ) 
{ 
  uint64 *sbc ;
  tmsize_t tmp ;

  {
  sbc = (uint64 *)((void *)0);
  if ((unsigned int )t2p->pdf_transcode == 1U) {
    if ((unsigned int )t2p->pdf_compression == 1U) {
      TIFFGetField(input, (uint32 )279, & sbc);
      t2p->tiff_datasize = (tmsize_t )*(sbc + 0);
      return;
    } else {

    }
  } else {

  }
  tmp = TIFFScanlineSize(input);
  t2p->tiff_datasize = tmp * (tmsize_t )t2p->tiff_length;
  if ((int )t2p->tiff_planar == 2) {
    t2p->tiff_datasize *= (tsize_t )t2p->tiff_samplesperpixel;
  } else {

  }
  return;
}
}
void t2p_read_tiff_size_tile(T2P *t2p , TIFF *input , ttile_t tile ) 
{ 
  uint64 *tbc ;
  uint16 edge ;
  int tmp ;
  int tmp___0 ;

  {
  tbc = (uint64 *)((void *)0);
  edge = (uint16 )0;
  tmp = t2p_tile_is_right_edge(*(t2p->tiff_tiles + (int )t2p->pdf_page), tile);
  edge = (uint16 )((int )edge | tmp);
  tmp___0 = t2p_tile_is_bottom_edge(*(t2p->tiff_tiles + (int )t2p->pdf_page),
                                    tile);
  edge = (uint16 )((int )edge | tmp___0);
  if ((unsigned int )t2p->pdf_transcode == 1U) {
    if (edge) {
      t2p->tiff_datasize = TIFFTileSize(input);
      return;
    } else {
      TIFFGetField(input, (uint32 )325, & tbc);
      t2p->tiff_datasize = (tmsize_t )*(tbc + tile);
      return;
    }
  } else {

  }
  t2p->tiff_datasize = TIFFTileSize(input);
  if ((int )t2p->tiff_planar == 2) {
    t2p->tiff_datasize *= (tsize_t )t2p->tiff_samplesperpixel;
  } else {

  }
  return;
}
}
int t2p_tile_is_right_edge(T2P_TILES tiles , ttile_t tile ) 
{ 


  {
  if ((tile + 1U) % tiles.tiles_tilecountx == 0U) {
    if (tiles.tiles_edgetilewidth != 0U) {
      return (1);
    } else {
      return (0);
    }
  } else {
    return (0);
  }
}
}
int t2p_tile_is_bottom_edge(T2P_TILES tiles , ttile_t tile ) 
{ 


  {
  if (tile + 1U > tiles.tiles_tilecount - tiles.tiles_tilecountx) {
    if (tiles.tiles_edgetilelength != 0U) {
      return (1);
    } else {
      return (0);
    }
  } else {
    return (0);
  }
}
}
int t2p_tile_is_edge(T2P_TILES tiles , ttile_t tile ) 
{ 
  int tmp ;
  int tmp___0 ;

  {
  tmp = t2p_tile_is_right_edge(tiles, tile);
  tmp___0 = t2p_tile_is_bottom_edge(tiles, tile);
  return (tmp | tmp___0);
}
}
int t2p_tile_is_corner_edge(T2P_TILES tiles , ttile_t tile ) 
{ 
  int tmp ;
  int tmp___0 ;

  {
  tmp = t2p_tile_is_right_edge(tiles, tile);
  tmp___0 = t2p_tile_is_bottom_edge(tiles, tile);
  return (tmp & tmp___0);
}
}
tsize_t t2p_readwrite_pdf_image(T2P *t2p , TIFF *input , TIFF *output ) 
{ 
  tsize_t written ;
  unsigned char *buffer ;
  unsigned char *samplebuffer ;
  tsize_t bufferoffset ;
  tsize_t samplebufferoffset ;
  tsize_t read___0 ;
  tstrip_t i ;
  tstrip_t j ;
  tstrip_t stripcount ;
  tsize_t stripsize ;
  tsize_t sepstripcount ;
  tsize_t sepstripsize ;
  void *tmp ;
  char const   *tmp___0 ;
  void *tmp___1 ;
  char const   *tmp___2 ;
  char const   *tmp___3 ;
  uint32 tmp___4 ;
  void *tmp___5 ;
  char const   *tmp___6 ;
  void *tmp___7 ;
  char const   *tmp___8 ;
  char const   *tmp___9 ;
  void *tmp___10 ;
  char const   *tmp___11 ;
  char const   *tmp___12 ;
  void *tmp___13 ;
  char const   *tmp___14 ;
  void *tmp___15 ;
  char const   *tmp___16 ;
  char const   *tmp___17 ;
  int tmp___18 ;
  char const   *tmp___19 ;

  {
  written = (tsize_t )0;
  buffer = (unsigned char *)((void *)0);
  samplebuffer = (unsigned char *)((void *)0);
  bufferoffset = (tsize_t )0;
  samplebufferoffset = (tsize_t )0;
  read___0 = (tsize_t )0;
  i = (tstrip_t )0;
  j = (tstrip_t )0;
  stripcount = (tstrip_t )0;
  stripsize = (tsize_t )0;
  sepstripcount = (tsize_t )0;
  sepstripsize = (tsize_t )0;
  if ((unsigned int )t2p->pdf_transcode == 1U) {
    if ((unsigned int )t2p->pdf_compression == 1U) {
      tmp = _TIFFmalloc(t2p->tiff_datasize);
      buffer = (unsigned char *)tmp;
      if ((unsigned long )buffer == (unsigned long )((void *)0)) {
        tmp___0 = TIFFFileName(input);
        TIFFError("tiff2pdf",
                  "Can\'t allocate %lu bytes of memory for t2p_readwrite_pdf_image, %s",
                  (unsigned long )t2p->tiff_datasize, tmp___0);
        t2p->t2p_error = (t2p_err_t )1;
        return ((tsize_t )0);
      } else {

      }
      TIFFReadRawStrip(input, (uint32 )0, (tdata_t )buffer, t2p->tiff_datasize);
      if ((int )t2p->tiff_fillorder == 2) {
        TIFFReverseBits(buffer, t2p->tiff_datasize);
      } else {

      }
      t2pWriteFile(output, (tdata_t )buffer, t2p->tiff_datasize);
      _TIFFfree((void *)buffer);
      return (t2p->tiff_datasize);
    } else {

    }
  } else {

  }
  if ((unsigned int )t2p->pdf_sample == 0U) {
    tmp___1 = _TIFFmalloc(t2p->tiff_datasize);
    buffer = (unsigned char *)tmp___1;
    if ((unsigned long )buffer == (unsigned long )((void *)0)) {
      tmp___2 = TIFFFileName(input);
      TIFFError("tiff2pdf",
                "Can\'t allocate %lu bytes of memory for t2p_readwrite_pdf_image, %s",
                (unsigned long )t2p->tiff_datasize, tmp___2);
      t2p->t2p_error = (t2p_err_t )1;
      return ((tsize_t )0);
    } else {

    }
    memset((void *)buffer, 0, (size_t )t2p->tiff_datasize);
    stripsize = TIFFStripSize(input);
    stripcount = TIFFNumberOfStrips(input);
    i = (tstrip_t )0;
    while (i < stripcount) {
      read___0 = TIFFReadEncodedStrip(input, i,
                                      (tdata_t )(buffer + bufferoffset),
                                      stripsize);
      if (read___0 == -1L) {
        tmp___3 = TIFFFileName(input);
        TIFFError("tiff2pdf", "Error on decoding strip %u of %s", i, tmp___3);
        _TIFFfree((void *)buffer);
        t2p->t2p_error = (t2p_err_t )1;
        return ((tsize_t )0);
      } else {

      }
      bufferoffset += read___0;
      i ++;
    }
  } else {
    if ((unsigned int )t2p->pdf_sample & 256U) {
      sepstripsize = TIFFStripSize(input);
      tmp___4 = TIFFNumberOfStrips(input);
      sepstripcount = (tsize_t )tmp___4;
      stripsize = sepstripsize * (tsize_t )t2p->tiff_samplesperpixel;
      stripcount = (tstrip_t )(sepstripcount / (tsize_t )t2p->tiff_samplesperpixel);
      tmp___5 = _TIFFmalloc(t2p->tiff_datasize);
      buffer = (unsigned char *)tmp___5;
      if ((unsigned long )buffer == (unsigned long )((void *)0)) {
        tmp___6 = TIFFFileName(input);
        TIFFError("tiff2pdf",
                  "Can\'t allocate %lu bytes of memory for t2p_readwrite_pdf_image, %s",
                  (unsigned long )t2p->tiff_datasize, tmp___6);
        t2p->t2p_error = (t2p_err_t )1;
        return ((tsize_t )0);
      } else {

      }
      memset((void *)buffer, 0, (size_t )t2p->tiff_datasize);
      tmp___7 = _TIFFmalloc(stripsize);
      samplebuffer = (unsigned char *)tmp___7;
      if ((unsigned long )samplebuffer == (unsigned long )((void *)0)) {
        tmp___8 = TIFFFileName(input);
        TIFFError("tiff2pdf",
                  "Can\'t allocate %lu bytes of memory for t2p_readwrite_pdf_image, %s",
                  (unsigned long )t2p->tiff_datasize, tmp___8);
        t2p->t2p_error = (t2p_err_t )1;
        return ((tsize_t )0);
      } else {

      }
      i = (tstrip_t )0;
      while (i < stripcount) {
        samplebufferoffset = (tsize_t )0;
        j = (tstrip_t )0;
        while (j < (tstrip_t )t2p->tiff_samplesperpixel) {
          read___0 = TIFFReadEncodedStrip(input, i + j * stripcount,
                                          (tdata_t )(samplebuffer + samplebufferoffset),
                                          sepstripsize);
          if (read___0 == -1L) {
            tmp___9 = TIFFFileName(input);
            TIFFError("tiff2pdf", "Error on decoding strip %u of %s",
                      i + j * stripcount, tmp___9);
            _TIFFfree((void *)buffer);
            t2p->t2p_error = (t2p_err_t )1;
            return ((tsize_t )0);
          } else {

          }
          samplebufferoffset += read___0;
          j ++;
        }
        t2p_sample_planar_separate_to_contig(t2p, buffer + bufferoffset,
                                             samplebuffer, samplebufferoffset);
        bufferoffset += samplebufferoffset;
        i ++;
      }
      _TIFFfree((void *)samplebuffer);
      goto dataready;
    } else {

    }
    tmp___10 = _TIFFmalloc(t2p->tiff_datasize);
    buffer = (unsigned char *)tmp___10;
    if ((unsigned long )buffer == (unsigned long )((void *)0)) {
      tmp___11 = TIFFFileName(input);
      TIFFError("tiff2pdf",
                "Can\'t allocate %lu bytes of memory for t2p_readwrite_pdf_image, %s",
                (unsigned long )t2p->tiff_datasize, tmp___11);
      t2p->t2p_error = (t2p_err_t )1;
      return ((tsize_t )0);
    } else {

    }
    memset((void *)buffer, 0, (size_t )t2p->tiff_datasize);
    stripsize = TIFFStripSize(input);
    stripcount = TIFFNumberOfStrips(input);
    i = (tstrip_t )0;
    while (i < stripcount) {
      read___0 = TIFFReadEncodedStrip(input, i,
                                      (tdata_t )(buffer + bufferoffset),
                                      stripsize);
      if (read___0 == -1L) {
        tmp___12 = TIFFFileName(input);
        TIFFError("tiff2pdf", "Error on decoding strip %u of %s", i, tmp___12);
        _TIFFfree((void *)samplebuffer);
        _TIFFfree((void *)buffer);
        t2p->t2p_error = (t2p_err_t )1;
        return ((tsize_t )0);
      } else {

      }
      bufferoffset += read___0;
      i ++;
    }
    if ((unsigned int )t2p->pdf_sample & 32U) {
      tmp___13 = _TIFFrealloc((tdata_t )buffer,
                              t2p->tiff_datasize * (tsize_t )t2p->tiff_samplesperpixel);
      samplebuffer = (unsigned char *)tmp___13;
      if ((unsigned long )samplebuffer == (unsigned long )((void *)0)) {
        tmp___14 = TIFFFileName(input);
        TIFFError("tiff2pdf",
                  "Can\'t allocate %lu bytes of memory for t2p_readwrite_pdf_image, %s",
                  (unsigned long )t2p->tiff_datasize, tmp___14);
        t2p->t2p_error = (t2p_err_t )1;
        _TIFFfree((void *)buffer);
      } else {
        buffer = samplebuffer;
        t2p->tiff_datasize *= (tsize_t )t2p->tiff_samplesperpixel;
      }
      t2p_sample_realize_palette(t2p, buffer);
    } else {

    }
    if ((unsigned int )t2p->pdf_sample & 2U) {
      t2p->tiff_datasize = t2p_sample_rgba_to_rgb((tdata_t )buffer,
                                                  t2p->tiff_width * t2p->tiff_length);
    } else {

    }
    if ((unsigned int )t2p->pdf_sample & 4U) {
      t2p->tiff_datasize = t2p_sample_rgbaa_to_rgb((tdata_t )buffer,
                                                   t2p->tiff_width * t2p->tiff_length);
    } else {

    }
    if ((unsigned int )t2p->pdf_sample & 8U) {
      tmp___15 = _TIFFrealloc((tdata_t )buffer,
                              (tmsize_t )((t2p->tiff_width * t2p->tiff_length) * 4U));
      samplebuffer = (unsigned char *)tmp___15;
      if ((unsigned long )samplebuffer == (unsigned long )((void *)0)) {
        tmp___16 = TIFFFileName(input);
        TIFFError("tiff2pdf",
                  "Can\'t allocate %lu bytes of memory for t2p_readwrite_pdf_image, %s",
                  (unsigned long )t2p->tiff_datasize, tmp___16);
        t2p->t2p_error = (t2p_err_t )1;
        _TIFFfree((void *)buffer);
        return ((tsize_t )0);
      } else {
        buffer = samplebuffer;
      }
      tmp___18 = TIFFReadRGBAImageOriented(input, t2p->tiff_width,
                                           t2p->tiff_length, (uint32 *)buffer,
                                           1, 0);
      if (! tmp___18) {
        tmp___17 = TIFFFileName(input);
        TIFFError("tiff2pdf",
                  "Can\'t use TIFFReadRGBAImageOriented to extract RGB image from %s",
                  tmp___17);
        t2p->t2p_error = (t2p_err_t )1;
        return ((tsize_t )0);
      } else {

      }
      t2p->tiff_datasize = t2p_sample_abgr_to_rgb((tdata_t )buffer,
                                                  t2p->tiff_width * t2p->tiff_length);
    } else {

    }
    if ((unsigned int )t2p->pdf_sample & 64U) {
      t2p->tiff_datasize = t2p_sample_lab_signed_to_unsigned((tdata_t )buffer,
                                                             t2p->tiff_width * t2p->tiff_length);
    } else {

    }
  }
  dataready: 
  t2p_disable(output);
  TIFFSetField(output, (uint32 )262, (int )t2p->tiff_photometric);
  TIFFSetField(output, (uint32 )258, (int )t2p->tiff_bitspersample);
  TIFFSetField(output, (uint32 )277, (int )t2p->tiff_samplesperpixel);
  TIFFSetField(output, (uint32 )256, t2p->tiff_width);
  TIFFSetField(output, (uint32 )257, t2p->tiff_length);
  TIFFSetField(output, (uint32 )278, t2p->tiff_length);
  TIFFSetField(output, (uint32 )284, 1);
  TIFFSetField(output, (uint32 )266, 1);
  switch ((unsigned int )t2p->pdf_compression) {
  case 0U: 
  TIFFSetField(output, (uint32 )259, 1);
  break;
  case 1U: 
  TIFFSetField(output, (uint32 )259, 4);
  break;
  default: 
  break;
  }
  t2p_enable(output);
  t2p->outputwritten = (tsize_t )0;
  bufferoffset = TIFFWriteEncodedStrip(output, (tstrip_t )0, (void *)buffer,
                                       t2p->tiff_datasize);
  if ((unsigned long )buffer != (unsigned long )((void *)0)) {
    _TIFFfree((void *)buffer);
    buffer = (unsigned char *)((void *)0);
  } else {

  }
  if (bufferoffset == -1L) {
    tmp___19 = TIFFFileName(output);
    TIFFError("tiff2pdf", "Error writing encoded strip to output PDF %s",
              tmp___19);
    t2p->t2p_error = (t2p_err_t )1;
    return ((tsize_t )0);
  } else {

  }
  written = t2p->outputwritten;
  return (written);
}
}
tsize_t t2p_readwrite_pdf_image_tile(T2P *t2p , TIFF *input , TIFF *output ,
                                     ttile_t tile ) 
{ 
  uint16 edge ;
  tsize_t written ;
  unsigned char *buffer ;
  tsize_t bufferoffset ;
  unsigned char *samplebuffer ;
  tsize_t samplebufferoffset ;
  tsize_t read___0 ;
  uint16 i ;
  ttile_t tilecount ;
  tsize_t tilesize ;
  ttile_t septilecount ;
  tsize_t septilesize ;
  int tmp ;
  int tmp___0 ;
  void *tmp___1 ;
  char const   *tmp___2 ;
  void *tmp___3 ;
  char const   *tmp___4 ;
  char const   *tmp___5 ;
  void *tmp___6 ;
  char const   *tmp___7 ;
  void *tmp___8 ;
  char const   *tmp___9 ;
  char const   *tmp___10 ;
  void *tmp___11 ;
  char const   *tmp___12 ;
  char const   *tmp___13 ;
  char const   *tmp___14 ;
  tmsize_t tmp___15 ;
  int tmp___16 ;
  int tmp___17 ;
  int tmp___18 ;
  tmsize_t tmp___19 ;
  char const   *tmp___20 ;

  {
  edge = (uint16 )0;
  written = (tsize_t )0;
  buffer = (unsigned char *)((void *)0);
  bufferoffset = (tsize_t )0;
  samplebuffer = (unsigned char *)((void *)0);
  samplebufferoffset = (tsize_t )0;
  read___0 = (tsize_t )0;
  i = (uint16 )0;
  tilecount = (ttile_t )0;
  tilesize = (tsize_t )0;
  septilecount = (ttile_t )0;
  septilesize = (tsize_t )0;
  tmp = t2p_tile_is_right_edge(*(t2p->tiff_tiles + (int )t2p->pdf_page), tile);
  edge = (uint16 )((int )edge | tmp);
  tmp___0 = t2p_tile_is_bottom_edge(*(t2p->tiff_tiles + (int )t2p->pdf_page),
                                    tile);
  edge = (uint16 )((int )edge | tmp___0);
  if ((unsigned int )t2p->pdf_transcode == 1U) {
    if ((int )edge == 0) {
      if ((unsigned int )t2p->pdf_compression == 1U) {
        tmp___1 = _TIFFmalloc(t2p->tiff_datasize);
        buffer = (unsigned char *)tmp___1;
        if ((unsigned long )buffer == (unsigned long )((void *)0)) {
          tmp___2 = TIFFFileName(input);
          TIFFError("tiff2pdf",
                    "Can\'t allocate %lu bytes of memory for t2p_readwrite_pdf_image_tile, %s",
                    (unsigned long )t2p->tiff_datasize, tmp___2);
          t2p->t2p_error = (t2p_err_t )1;
          return ((tsize_t )0);
        } else {

        }
        TIFFReadRawTile(input, tile, (tdata_t )buffer, t2p->tiff_datasize);
        if ((int )t2p->tiff_fillorder == 2) {
          TIFFReverseBits(buffer, t2p->tiff_datasize);
        } else {

        }
        t2pWriteFile(output, (tdata_t )buffer, t2p->tiff_datasize);
        _TIFFfree((void *)buffer);
        return (t2p->tiff_datasize);
      } else {

      }
    } else {

    }
  } else {

  }
  if ((unsigned int )t2p->pdf_sample == 0U) {
    tmp___3 = _TIFFmalloc(t2p->tiff_datasize);
    buffer = (unsigned char *)tmp___3;
    if ((unsigned long )buffer == (unsigned long )((void *)0)) {
      tmp___4 = TIFFFileName(input);
      TIFFError("tiff2pdf",
                "Can\'t allocate %lu bytes of memory for t2p_readwrite_pdf_image_tile, %s",
                (unsigned long )t2p->tiff_datasize, tmp___4);
      t2p->t2p_error = (t2p_err_t )1;
      return ((tsize_t )0);
    } else {

    }
    read___0 = TIFFReadEncodedTile(input, tile,
                                   (tdata_t )(buffer + bufferoffset),
                                   t2p->tiff_datasize);
    if (read___0 == -1L) {
      tmp___5 = TIFFFileName(input);
      TIFFError("tiff2pdf", "Error on decoding tile %u of %s", tile, tmp___5);
      _TIFFfree((void *)buffer);
      t2p->t2p_error = (t2p_err_t )1;
      return ((tsize_t )0);
    } else {

    }
  } else {
    if ((unsigned int )t2p->pdf_sample == 256U) {
      septilesize = TIFFTileSize(input);
      septilecount = TIFFNumberOfTiles(input);
      tilesize = septilesize * (tsize_t )t2p->tiff_samplesperpixel;
      tilecount = septilecount / (ttile_t )t2p->tiff_samplesperpixel;
      tmp___6 = _TIFFmalloc(t2p->tiff_datasize);
      buffer = (unsigned char *)tmp___6;
      if ((unsigned long )buffer == (unsigned long )((void *)0)) {
        tmp___7 = TIFFFileName(input);
        TIFFError("tiff2pdf",
                  "Can\'t allocate %lu bytes of memory for t2p_readwrite_pdf_image_tile, %s",
                  (unsigned long )t2p->tiff_datasize, tmp___7);
        t2p->t2p_error = (t2p_err_t )1;
        return ((tsize_t )0);
      } else {

      }
      tmp___8 = _TIFFmalloc(t2p->tiff_datasize);
      samplebuffer = (unsigned char *)tmp___8;
      if ((unsigned long )samplebuffer == (unsigned long )((void *)0)) {
        tmp___9 = TIFFFileName(input);
        TIFFError("tiff2pdf",
                  "Can\'t allocate %lu bytes of memory for t2p_readwrite_pdf_image_tile, %s",
                  (unsigned long )t2p->tiff_datasize, tmp___9);
        t2p->t2p_error = (t2p_err_t )1;
        return ((tsize_t )0);
      } else {

      }
      samplebufferoffset = (tsize_t )0;
      i = (uint16 )0;
      while ((int )i < (int )t2p->tiff_samplesperpixel) {
        read___0 = TIFFReadEncodedTile(input, tile + (ttile_t )i * tilecount,
                                       (tdata_t )(samplebuffer + samplebufferoffset),
                                       septilesize);
        if (read___0 == -1L) {
          tmp___10 = TIFFFileName(input);
          TIFFError("tiff2pdf", "Error on decoding tile %u of %s",
                    tile + (ttile_t )i * tilecount, tmp___10);
          _TIFFfree((void *)samplebuffer);
          _TIFFfree((void *)buffer);
          t2p->t2p_error = (t2p_err_t )1;
          return ((tsize_t )0);
        } else {

        }
        samplebufferoffset += read___0;
        i = (uint16 )((int )i + 1);
      }
      t2p_sample_planar_separate_to_contig(t2p, buffer + bufferoffset,
                                           samplebuffer, samplebufferoffset);
      bufferoffset += samplebufferoffset;
      _TIFFfree((void *)samplebuffer);
    } else {

    }
    if ((unsigned long )buffer == (unsigned long )((void *)0)) {
      tmp___11 = _TIFFmalloc(t2p->tiff_datasize);
      buffer = (unsigned char *)tmp___11;
      if ((unsigned long )buffer == (unsigned long )((void *)0)) {
        tmp___12 = TIFFFileName(input);
        TIFFError("tiff2pdf",
                  "Can\'t allocate %lu bytes of memory for t2p_readwrite_pdf_image_tile, %s",
                  (unsigned long )t2p->tiff_datasize, tmp___12);
        t2p->t2p_error = (t2p_err_t )1;
        return ((tsize_t )0);
      } else {

      }
      read___0 = TIFFReadEncodedTile(input, tile,
                                     (tdata_t )(buffer + bufferoffset),
                                     t2p->tiff_datasize);
      if (read___0 == -1L) {
        tmp___13 = TIFFFileName(input);
        TIFFError("tiff2pdf", "Error on decoding tile %u of %s", tile, tmp___13);
        _TIFFfree((void *)buffer);
        t2p->t2p_error = (t2p_err_t )1;
        return ((tsize_t )0);
      } else {

      }
    } else {

    }
    if ((unsigned int )t2p->pdf_sample & 2U) {
      t2p->tiff_datasize = t2p_sample_rgba_to_rgb((tdata_t )buffer,
                                                  (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilewidth * (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilelength);
    } else {

    }
    if ((unsigned int )t2p->pdf_sample & 4U) {
      t2p->tiff_datasize = t2p_sample_rgbaa_to_rgb((tdata_t )buffer,
                                                   (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilewidth * (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilelength);
    } else {

    }
    if ((unsigned int )t2p->pdf_sample & 8U) {
      tmp___14 = TIFFFileName(input);
      TIFFError("tiff2pdf", "No support for YCbCr to RGB in tile for %s",
                tmp___14);
      _TIFFfree((void *)buffer);
      t2p->t2p_error = (t2p_err_t )1;
      return ((tsize_t )0);
    } else {

    }
    if ((unsigned int )t2p->pdf_sample & 64U) {
      t2p->tiff_datasize = t2p_sample_lab_signed_to_unsigned((tdata_t )buffer,
                                                             (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilewidth * (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilelength);
    } else {

    }
  }
  tmp___16 = t2p_tile_is_right_edge(*(t2p->tiff_tiles + (int )t2p->pdf_page),
                                    tile);
  if (tmp___16 != 0) {
    tmp___15 = TIFFTileRowSize(input);
    t2p_tile_collapse_left((tdata_t )buffer, tmp___15,
                           (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilewidth,
                           (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_edgetilewidth,
                           (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilelength);
  } else {

  }
  t2p_disable(output);
  TIFFSetField(output, (uint32 )262, (int )t2p->tiff_photometric);
  TIFFSetField(output, (uint32 )258, (int )t2p->tiff_bitspersample);
  TIFFSetField(output, (uint32 )277, (int )t2p->tiff_samplesperpixel);
  tmp___17 = t2p_tile_is_right_edge(*(t2p->tiff_tiles + (int )t2p->pdf_page),
                                    tile);
  if (tmp___17 == 0) {
    TIFFSetField(output, (uint32 )256,
                 (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilewidth);
  } else {
    TIFFSetField(output, (uint32 )256,
                 (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_edgetilewidth);
  }
  tmp___18 = t2p_tile_is_bottom_edge(*(t2p->tiff_tiles + (int )t2p->pdf_page),
                                     tile);
  if (tmp___18 == 0) {
    TIFFSetField(output, (uint32 )257,
                 (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilelength);
    TIFFSetField(output, (uint32 )278,
                 (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilelength);
  } else {
    TIFFSetField(output, (uint32 )257,
                 (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_edgetilelength);
    TIFFSetField(output, (uint32 )278,
                 (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_edgetilelength);
  }
  TIFFSetField(output, (uint32 )284, 1);
  TIFFSetField(output, (uint32 )266, 1);
  switch ((unsigned int )t2p->pdf_compression) {
  case 0U: 
  TIFFSetField(output, (uint32 )259, 1);
  break;
  case 1U: 
  TIFFSetField(output, (uint32 )259, 4);
  break;
  default: 
  break;
  }
  t2p_enable(output);
  t2p->outputwritten = (tsize_t )0;
  tmp___19 = TIFFStripSize(output);
  bufferoffset = TIFFWriteEncodedStrip(output, (tstrip_t )0, (void *)buffer,
                                       tmp___19);
  if ((unsigned long )buffer != (unsigned long )((void *)0)) {
    _TIFFfree((void *)buffer);
    buffer = (unsigned char *)((void *)0);
  } else {

  }
  if (bufferoffset == -1L) {
    tmp___20 = TIFFFileName(output);
    TIFFError("tiff2pdf", "Error writing encoded tile to output PDF %s",
              tmp___20);
    t2p->t2p_error = (t2p_err_t )1;
    return ((tsize_t )0);
  } else {

  }
  written = t2p->outputwritten;
  return (written);
}
}
void t2p_tile_collapse_left(tdata_t buffer , tsize_t scanwidth ,
                            uint32 tilewidth , uint32 edgetilewidth ,
                            uint32 tilelength ) 
{ 
  uint32 i ;
  tsize_t edgescanwidth ;

  {
  i = (uint32 )0;
  edgescanwidth = (tsize_t )0;
  edgescanwidth = (scanwidth * (tsize_t )edgetilewidth + (tsize_t )(tilewidth - 1U)) / (tsize_t )tilewidth;
  i = i;
  while (i < tilelength) {
    _TIFFmemcpy((void *)((char *)buffer + edgescanwidth * (tsize_t )i),
                (void const   *)((char *)buffer + scanwidth * (tsize_t )i),
                edgescanwidth);
    i ++;
  }
  return;
}
}
void t2p_write_advance_directory(T2P *t2p , TIFF *output ) 
{ 
  char const   *tmp ;
  int tmp___0 ;

  {
  t2p_disable(output);
  tmp___0 = TIFFWriteDirectory(output);
  if (! tmp___0) {
    tmp = TIFFFileName(output);
    TIFFError("tiff2pdf", "Error writing virtual directory to output PDF %s",
              tmp);
    t2p->t2p_error = (t2p_err_t )1;
    return;
  } else {

  }
  t2p_enable(output);
  return;
}
}
tsize_t t2p_sample_planar_separate_to_contig(T2P *t2p , unsigned char *buffer ,
                                             unsigned char *samplebuffer ,
                                             tsize_t samplebuffersize ) 
{ 
  tsize_t stride ;
  tsize_t i ;
  tsize_t j ;

  {
  stride = (tsize_t )0;
  i = (tsize_t )0;
  j = (tsize_t )0;
  stride = samplebuffersize / (tsize_t )t2p->tiff_samplesperpixel;
  i = (tsize_t )0;
  while (i < stride) {
    j = (tsize_t )0;
    while (j < (tsize_t )t2p->tiff_samplesperpixel) {
      *(buffer + (i * (tsize_t )t2p->tiff_samplesperpixel + j)) = *(samplebuffer + (i + j * stride));
      j ++;
    }
    i ++;
  }
  return (samplebuffersize);
}
}
tsize_t t2p_sample_realize_palette(T2P *t2p , unsigned char *buffer ) 
{ 
  uint32 sample_count ;
  uint16 component_count ;
  uint32 palette_offset ;
  uint32 sample_offset ;
  uint32 i ;
  uint32 j ;

  {
  sample_count = (uint32 )0;
  component_count = (uint16 )0;
  palette_offset = (uint32 )0;
  sample_offset = (uint32 )0;
  i = (uint32 )0;
  j = (uint32 )0;
  sample_count = t2p->tiff_width * t2p->tiff_length;
  component_count = t2p->tiff_samplesperpixel;
  i = sample_count;
  while (i > 0U) {
    palette_offset = (uint32 )((int )*(buffer + (i - 1U)) * (int )component_count);
    sample_offset = (i - 1U) * (uint32 )component_count;
    j = (uint32 )0;
    while (j < (uint32 )component_count) {
      *(buffer + (sample_offset + j)) = *(t2p->pdf_palette + (palette_offset + j));
      j ++;
    }
    i --;
  }
  return ((tsize_t )0);
}
}
tsize_t t2p_sample_abgr_to_rgb(tdata_t data , uint32 samplecount ) 
{ 
  uint32 i ;
  uint32 sample ;

  {
  i = (uint32 )0;
  sample = (uint32 )0;
  i = (uint32 )0;
  while (i < samplecount) {
    sample = *((uint32 *)data + i);
    *((char *)data + i * 3U) = (char )(sample & 255U);
    *((char *)data + (i * 3U + 1U)) = (char )((sample >> 8) & 255U);
    *((char *)data + (i * 3U + 2U)) = (char )((sample >> 16) & 255U);
    i ++;
  }
  return ((tsize_t )(i * 3U));
}
}
tsize_t t2p_sample_rgbaa_to_rgb(tdata_t data , uint32 samplecount ) 
{ 
  uint32 i ;

  {
  i = (uint32 )0;
  while (i < samplecount) {
    memcpy((void */* __restrict  */)((uint8 *)data + i * 3U),
           (void const   */* __restrict  */)((uint8 *)data + i * 4U), (size_t )3);
    i ++;
  }
  return ((tsize_t )(i * 3U));
}
}
tsize_t t2p_sample_rgba_to_rgb(tdata_t data , uint32 samplecount ) 
{ 
  uint32 i ;
  uint32 sample ;
  uint8 alpha ;

  {
  i = (uint32 )0;
  sample = (uint32 )0;
  alpha = (uint8 )0;
  i = (uint32 )0;
  while (i < samplecount) {
    sample = *((uint32 *)data + i);
    alpha = (uint8 )(255U - (sample & 255U));
    *((uint8 *)data + i * 3U) = (uint8 )((int )((uint8 )((sample >> 24) & 255U)) + (int )alpha);
    *((uint8 *)data + (i * 3U + 1U)) = (uint8 )((int )((uint8 )((sample >> 16) & 255U)) + (int )alpha);
    *((uint8 *)data + (i * 3U + 2U)) = (uint8 )((int )((uint8 )((sample >> 8) & 255U)) + (int )alpha);
    i ++;
  }
  return ((tsize_t )(i * 3U));
}
}
tsize_t t2p_sample_lab_signed_to_unsigned(tdata_t buffer , uint32 samplecount ) 
{ 
  uint32 i ;

  {
  i = (uint32 )0;
  i = (uint32 )0;
  while (i < samplecount) {
    if (((int )*((unsigned char *)buffer + (i * 3U + 1U)) & 128) != 0) {
      *((unsigned char *)buffer + (i * 3U + 1U)) = (unsigned char )(128 + (int )*((char *)buffer + (i * 3U + 1U)));
    } else {
      *((unsigned char *)buffer + (i * 3U + 1U)) = (unsigned char )((int )*((unsigned char *)buffer + (i * 3U + 1U)) | 128);
    }
    if (((int )*((unsigned char *)buffer + (i * 3U + 2U)) & 128) != 0) {
      *((unsigned char *)buffer + (i * 3U + 2U)) = (unsigned char )(128 + (int )*((char *)buffer + (i * 3U + 2U)));
    } else {
      *((unsigned char *)buffer + (i * 3U + 2U)) = (unsigned char )((int )*((unsigned char *)buffer + (i * 3U + 2U)) | 128);
    }
    i ++;
  }
  return ((tsize_t )(samplecount * 3U));
}
}
tsize_t t2p_write_pdf_header(T2P *t2p , TIFF *output ) 
{ 
  tsize_t written ;
  char buffer[16] ;
  int buflen ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;

  {
  written = (tsize_t )0;
  buflen = 0;
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%%PDF-%u.%u ",
                   (int )t2p->pdf_majorversion & 255,
                   (int )t2p->pdf_minorversion & 255);
  tmp = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
  written += tmp;
  tmp___0 = t2pWriteFile(output, (tdata_t )"\n%\342\343\317\323\n", (tmsize_t )7);
  written += tmp___0;
  return (written);
}
}
tsize_t t2p_write_pdf_obj_start(uint32 number , TIFF *output ) 
{ 
  tsize_t written ;
  char buffer[16] ;
  int buflen ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;

  {
  written = (tsize_t )0;
  buflen = 0;
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%lu",
                   (unsigned long )number);
  tmp = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
  written += tmp;
  tmp___0 = t2pWriteFile(output, (tdata_t )" 0 obj\n", (tmsize_t )7);
  written += tmp___0;
  return (written);
}
}
tsize_t t2p_write_pdf_obj_end(TIFF *output ) 
{ 
  tsize_t written ;
  tmsize_t tmp ;

  {
  written = (tsize_t )0;
  tmp = t2pWriteFile(output, (tdata_t )"endobj\n", (tmsize_t )7);
  written += tmp;
  return (written);
}
}
tsize_t t2p_write_pdf_name(unsigned char *name , TIFF *output ) 
{ 
  tsize_t written ;
  uint32 i ;
  char buffer[64] ;
  uint16 nextchar ;
  size_t namelen ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  tmsize_t tmp___4 ;
  tmsize_t tmp___5 ;
  tmsize_t tmp___6 ;
  tmsize_t tmp___7 ;
  tmsize_t tmp___8 ;
  tmsize_t tmp___9 ;
  tmsize_t tmp___10 ;
  tmsize_t tmp___11 ;
  tmsize_t tmp___12 ;
  tmsize_t tmp___13 ;
  tmsize_t tmp___14 ;

  {
  written = (tsize_t )0;
  i = (uint32 )0;
  nextchar = (uint16 )0;
  namelen = (size_t )0;
  namelen = strlen((char const   *)((char *)name));
  if (namelen > 126UL) {
    namelen = (size_t )126;
  } else {

  }
  tmp = t2pWriteFile(output, (tdata_t )"/", (tmsize_t )1);
  written += tmp;
  i = (uint32 )0;
  while ((size_t )i < namelen) {
    if ((int )*(name + i) < 33) {
      sprintf((char */* __restrict  */)(buffer),
              (char const   */* __restrict  */)"#%.2X", (int )*(name + i));
      buffer[sizeof(buffer) - 1UL] = (char )'\000';
      tmp___0 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )3);
      written += tmp___0;
      nextchar = (uint16 )1;
    } else {

    }
    if ((int )*(name + i) > 126) {
      sprintf((char */* __restrict  */)(buffer),
              (char const   */* __restrict  */)"#%.2X", (int )*(name + i));
      buffer[sizeof(buffer) - 1UL] = (char )'\000';
      tmp___1 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )3);
      written += tmp___1;
      nextchar = (uint16 )1;
    } else {

    }
    if ((int )nextchar == 0) {
      switch ((int )*(name + i)) {
      case 35: 
      sprintf((char */* __restrict  */)(buffer),
              (char const   */* __restrict  */)"#%.2X", (int )*(name + i));
      buffer[sizeof(buffer) - 1UL] = (char )'\000';
      tmp___2 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )3);
      written += tmp___2;
      break;
      case 37: 
      sprintf((char */* __restrict  */)(buffer),
              (char const   */* __restrict  */)"#%.2X", (int )*(name + i));
      buffer[sizeof(buffer) - 1UL] = (char )'\000';
      tmp___3 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )3);
      written += tmp___3;
      break;
      case 40: 
      sprintf((char */* __restrict  */)(buffer),
              (char const   */* __restrict  */)"#%.2X", (int )*(name + i));
      buffer[sizeof(buffer) - 1UL] = (char )'\000';
      tmp___4 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )3);
      written += tmp___4;
      break;
      case 41: 
      sprintf((char */* __restrict  */)(buffer),
              (char const   */* __restrict  */)"#%.2X", (int )*(name + i));
      buffer[sizeof(buffer) - 1UL] = (char )'\000';
      tmp___5 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )3);
      written += tmp___5;
      break;
      case 47: 
      sprintf((char */* __restrict  */)(buffer),
              (char const   */* __restrict  */)"#%.2X", (int )*(name + i));
      buffer[sizeof(buffer) - 1UL] = (char )'\000';
      tmp___6 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )3);
      written += tmp___6;
      break;
      case 60: 
      sprintf((char */* __restrict  */)(buffer),
              (char const   */* __restrict  */)"#%.2X", (int )*(name + i));
      buffer[sizeof(buffer) - 1UL] = (char )'\000';
      tmp___7 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )3);
      written += tmp___7;
      break;
      case 62: 
      sprintf((char */* __restrict  */)(buffer),
              (char const   */* __restrict  */)"#%.2X", (int )*(name + i));
      buffer[sizeof(buffer) - 1UL] = (char )'\000';
      tmp___8 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )3);
      written += tmp___8;
      break;
      case 91: 
      sprintf((char */* __restrict  */)(buffer),
              (char const   */* __restrict  */)"#%.2X", (int )*(name + i));
      buffer[sizeof(buffer) - 1UL] = (char )'\000';
      tmp___9 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )3);
      written += tmp___9;
      break;
      case 93: 
      sprintf((char */* __restrict  */)(buffer),
              (char const   */* __restrict  */)"#%.2X", (int )*(name + i));
      buffer[sizeof(buffer) - 1UL] = (char )'\000';
      tmp___10 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )3);
      written += tmp___10;
      break;
      case 123: 
      sprintf((char */* __restrict  */)(buffer),
              (char const   */* __restrict  */)"#%.2X", (int )*(name + i));
      buffer[sizeof(buffer) - 1UL] = (char )'\000';
      tmp___11 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )3);
      written += tmp___11;
      break;
      case 125: 
      sprintf((char */* __restrict  */)(buffer),
              (char const   */* __restrict  */)"#%.2X", (int )*(name + i));
      buffer[sizeof(buffer) - 1UL] = (char )'\000';
      tmp___12 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )3);
      written += tmp___12;
      break;
      default: 
      tmp___13 = t2pWriteFile(output, (tdata_t )(name + i), (tmsize_t )1);
      written += tmp___13;
      }
    } else {

    }
    nextchar = (uint16 )0;
    i ++;
  }
  tmp___14 = t2pWriteFile(output, (tdata_t )" ", (tmsize_t )1);
  written += tmp___14;
  return (written);
}
}
tsize_t t2p_write_pdf_string(char *pdfstr , TIFF *output ) 
{ 
  tsize_t written ;
  uint32 i ;
  char buffer[64] ;
  size_t len ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  tmsize_t tmp___4 ;
  tmsize_t tmp___5 ;
  tmsize_t tmp___6 ;
  tmsize_t tmp___7 ;
  tmsize_t tmp___8 ;
  tmsize_t tmp___9 ;
  tmsize_t tmp___10 ;

  {
  written = (tsize_t )0;
  i = (uint32 )0;
  len = (size_t )0;
  len = strlen((char const   *)pdfstr);
  tmp = t2pWriteFile(output, (tdata_t )"(", (tmsize_t )1);
  written += tmp;
  i = (uint32 )0;
  while ((size_t )i < len) {
    if ((int )*(pdfstr + i) & 128) {
      snprintf((char */* __restrict  */)(buffer), sizeof(buffer),
               (char const   */* __restrict  */)"\\%.3hho", (int )*(pdfstr + i));
      tmp___0 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )4);
      written += tmp___0;
    } else
    if ((int )*(pdfstr + i) == 127) {
      snprintf((char */* __restrict  */)(buffer), sizeof(buffer),
               (char const   */* __restrict  */)"\\%.3hho", (int )*(pdfstr + i));
      tmp___0 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )4);
      written += tmp___0;
    } else
    if ((int )*(pdfstr + i) < 32) {
      snprintf((char */* __restrict  */)(buffer), sizeof(buffer),
               (char const   */* __restrict  */)"\\%.3hho", (int )*(pdfstr + i));
      tmp___0 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )4);
      written += tmp___0;
    } else {
      switch ((int )*(pdfstr + i)) {
      case 8: 
      tmp___1 = t2pWriteFile(output, (tdata_t )"\\b", (tmsize_t )2);
      written += tmp___1;
      break;
      case 9: 
      tmp___2 = t2pWriteFile(output, (tdata_t )"\\t", (tmsize_t )2);
      written += tmp___2;
      break;
      case 10: 
      tmp___3 = t2pWriteFile(output, (tdata_t )"\\n", (tmsize_t )2);
      written += tmp___3;
      break;
      case 12: 
      tmp___4 = t2pWriteFile(output, (tdata_t )"\\f", (tmsize_t )2);
      written += tmp___4;
      break;
      case 13: 
      tmp___5 = t2pWriteFile(output, (tdata_t )"\\r", (tmsize_t )2);
      written += tmp___5;
      break;
      case 40: 
      tmp___6 = t2pWriteFile(output, (tdata_t )"\\(", (tmsize_t )2);
      written += tmp___6;
      break;
      case 41: 
      tmp___7 = t2pWriteFile(output, (tdata_t )"\\)", (tmsize_t )2);
      written += tmp___7;
      break;
      case 92: 
      tmp___8 = t2pWriteFile(output, (tdata_t )"\\\\", (tmsize_t )2);
      written += tmp___8;
      break;
      default: 
      tmp___9 = t2pWriteFile(output, (tdata_t )(pdfstr + i), (tmsize_t )1);
      written += tmp___9;
      }
    }
    i ++;
  }
  tmp___10 = t2pWriteFile(output, (tdata_t )") ", (tmsize_t )1);
  written += tmp___10;
  return (written);
}
}
tsize_t t2p_write_pdf_stream(tdata_t buffer , tsize_t len , TIFF *output ) 
{ 
  tsize_t written ;
  tmsize_t tmp ;

  {
  written = (tsize_t )0;
  tmp = t2pWriteFile(output, buffer, len);
  written += tmp;
  return (written);
}
}
tsize_t t2p_write_pdf_stream_start(TIFF *output ) 
{ 
  tsize_t written ;
  tmsize_t tmp ;

  {
  written = (tsize_t )0;
  tmp = t2pWriteFile(output, (tdata_t )"stream\n", (tmsize_t )7);
  written += tmp;
  return (written);
}
}
tsize_t t2p_write_pdf_stream_end(TIFF *output ) 
{ 
  tsize_t written ;
  tmsize_t tmp ;

  {
  written = (tsize_t )0;
  tmp = t2pWriteFile(output, (tdata_t )"\nendstream\n", (tmsize_t )11);
  written += tmp;
  return (written);
}
}
tsize_t t2p_write_pdf_stream_dict(tsize_t len , uint32 number , TIFF *output ) 
{ 
  tsize_t written ;
  char buffer[16] ;
  int buflen ;
  tmsize_t tmp ;
  tsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;

  {
  written = (tsize_t )0;
  buflen = 0;
  tmp = t2pWriteFile(output, (tdata_t )"/Length ", (tmsize_t )8);
  written += tmp;
  if (len != 0L) {
    tmp___0 = t2p_write_pdf_stream_length(len, output);
    written += tmp___0;
  } else {
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )number);
    tmp___1 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
    written += tmp___1;
    tmp___2 = t2pWriteFile(output, (tdata_t )" 0 R \n", (tmsize_t )6);
    written += tmp___2;
  }
  return (written);
}
}
tsize_t t2p_write_pdf_stream_dict_start(TIFF *output ) 
{ 
  tsize_t written ;
  tmsize_t tmp ;

  {
  written = (tsize_t )0;
  tmp = t2pWriteFile(output, (tdata_t )"<< \n", (tmsize_t )4);
  written += tmp;
  return (written);
}
}
tsize_t t2p_write_pdf_stream_dict_end(TIFF *output ) 
{ 
  tsize_t written ;
  tmsize_t tmp ;

  {
  written = (tsize_t )0;
  tmp = t2pWriteFile(output, (tdata_t )" >>\n", (tmsize_t )4);
  written += tmp;
  return (written);
}
}
tsize_t t2p_write_pdf_stream_length(tsize_t len , TIFF *output ) 
{ 
  tsize_t written ;
  char buffer[16] ;
  int buflen ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;

  {
  written = (tsize_t )0;
  buflen = 0;
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%lu", (unsigned long )len);
  tmp = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
  written += tmp;
  tmp___0 = t2pWriteFile(output, (tdata_t )"\n", (tmsize_t )1);
  written += tmp___0;
  return (written);
}
}
tsize_t t2p_write_pdf_catalog(T2P *t2p , TIFF *output ) 
{ 
  tsize_t written ;
  char buffer[16] ;
  int buflen ;
  tmsize_t tmp ;
  size_t tmp___0 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  tmsize_t tmp___4 ;

  {
  written = (tsize_t )0;
  buflen = 0;
  tmp = t2pWriteFile(output, (tdata_t )"<< \n/Type /Catalog \n/Pages ",
                     (tmsize_t )27);
  written += tmp;
  buflen = snprintf((char */* __restrict  */)(buffer), sizeof(buffer),
                    (char const   */* __restrict  */)"%lu",
                    (unsigned long )t2p->pdf_pages);
  if ((size_t )buflen < sizeof(buffer) - 1UL) {
    tmp___0 = (size_t )buflen;
  } else {
    tmp___0 = sizeof(buffer) - 1UL;
  }
  tmp___1 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )tmp___0);
  written += tmp___1;
  tmp___2 = t2pWriteFile(output, (tdata_t )" 0 R \n", (tmsize_t )6);
  written += tmp___2;
  if (t2p->pdf_fitwindow) {
    tmp___3 = t2pWriteFile(output,
                           (tdata_t )"/ViewerPreferences <</FitWindow true>>\n",
                           (tmsize_t )39);
    written += tmp___3;
  } else {

  }
  tmp___4 = t2pWriteFile(output, (tdata_t )">>\n", (tmsize_t )3);
  written += tmp___4;
  return (written);
}
}
tsize_t t2p_write_pdf_info(T2P *t2p , TIFF *input , TIFF *output ) 
{ 
  tsize_t written ;
  char *info ;
  char buffer[512] ;
  tmsize_t tmp ;
  tsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tsize_t tmp___2 ;
  size_t tmp___3 ;
  tmsize_t tmp___4 ;
  tsize_t tmp___5 ;
  tmsize_t tmp___6 ;
  tmsize_t tmp___7 ;
  tsize_t tmp___8 ;
  tmsize_t tmp___9 ;
  size_t tmp___10 ;
  tmsize_t tmp___11 ;
  tsize_t tmp___12 ;
  tmsize_t tmp___13 ;
  int tmp___14 ;
  tmsize_t tmp___15 ;
  tsize_t tmp___16 ;
  tmsize_t tmp___17 ;
  size_t tmp___18 ;
  tmsize_t tmp___19 ;
  tsize_t tmp___20 ;
  tmsize_t tmp___21 ;
  int tmp___22 ;
  int tmp___23 ;
  tmsize_t tmp___24 ;
  tsize_t tmp___25 ;
  tmsize_t tmp___26 ;
  size_t tmp___27 ;
  tmsize_t tmp___28 ;
  tsize_t tmp___29 ;
  tmsize_t tmp___30 ;
  int tmp___31 ;
  tmsize_t tmp___32 ;
  tsize_t tmp___33 ;
  tmsize_t tmp___34 ;
  size_t tmp___35 ;
  tmsize_t tmp___36 ;
  tsize_t tmp___37 ;
  tmsize_t tmp___38 ;
  int tmp___39 ;
  tmsize_t tmp___40 ;
  tsize_t tmp___41 ;
  tmsize_t tmp___42 ;
  tmsize_t tmp___43 ;

  {
  written = (tsize_t )0;
  if ((int )t2p->pdf_datetime[0] == 0) {
    t2p_pdf_tifftime(t2p, input);
  } else {

  }
  tmp___3 = strlen((char const   *)(t2p->pdf_datetime));
  if (tmp___3 > 0UL) {
    tmp = t2pWriteFile(output, (tdata_t )"<< \n/CreationDate ", (tmsize_t )18);
    written += tmp;
    tmp___0 = t2p_write_pdf_string(t2p->pdf_datetime, output);
    written += tmp___0;
    tmp___1 = t2pWriteFile(output, (tdata_t )"\n/ModDate ", (tmsize_t )10);
    written += tmp___1;
    tmp___2 = t2p_write_pdf_string(t2p->pdf_datetime, output);
    written += tmp___2;
  } else {

  }
  tmp___4 = t2pWriteFile(output, (tdata_t )"\n/Producer ", (tmsize_t )11);
  written += tmp___4;
  _TIFFmemset((tdata_t )(buffer), 0, (tmsize_t )sizeof(buffer));
  snprintf((char */* __restrict  */)(buffer), sizeof(buffer),
           (char const   */* __restrict  */)"libtiff / tiff2pdf - %d", 20100611);
  tmp___5 = t2p_write_pdf_string(buffer, output);
  written += tmp___5;
  tmp___6 = t2pWriteFile(output, (tdata_t )"\n", (tmsize_t )1);
  written += tmp___6;
  if ((int )t2p->pdf_creator[0] != 0) {
    tmp___7 = t2pWriteFile(output, (tdata_t )"/Creator ", (tmsize_t )9);
    written += tmp___7;
    tmp___8 = t2p_write_pdf_string(t2p->pdf_creator, output);
    written += tmp___8;
    tmp___9 = t2pWriteFile(output, (tdata_t )"\n", (tmsize_t )1);
    written += tmp___9;
  } else {
    tmp___14 = TIFFGetField(input, (uint32 )305, & info);
    if (tmp___14 != 0) {
      if (info) {
        tmp___10 = strlen((char const   *)info);
        if (tmp___10 >= sizeof(t2p->pdf_creator)) {
          *(info + (sizeof(t2p->pdf_creator) - 1UL)) = (char )'\000';
        } else {

        }
        tmp___11 = t2pWriteFile(output, (tdata_t )"/Creator ", (tmsize_t )9);
        written += tmp___11;
        tmp___12 = t2p_write_pdf_string(info, output);
        written += tmp___12;
        tmp___13 = t2pWriteFile(output, (tdata_t )"\n", (tmsize_t )1);
        written += tmp___13;
      } else {

      }
    } else {

    }
  }
  if ((int )t2p->pdf_author[0] != 0) {
    tmp___15 = t2pWriteFile(output, (tdata_t )"/Author ", (tmsize_t )8);
    written += tmp___15;
    tmp___16 = t2p_write_pdf_string(t2p->pdf_author, output);
    written += tmp___16;
    tmp___17 = t2pWriteFile(output, (tdata_t )"\n", (tmsize_t )1);
    written += tmp___17;
  } else {
    tmp___22 = TIFFGetField(input, (uint32 )315, & info);
    if (tmp___22 != 0) {
      goto _L;
    } else {
      tmp___23 = TIFFGetField(input, (uint32 )33432, & info);
      if (tmp___23 != 0) {
        _L: 
        if (info) {
          tmp___18 = strlen((char const   *)info);
          if (tmp___18 >= sizeof(t2p->pdf_author)) {
            *(info + (sizeof(t2p->pdf_author) - 1UL)) = (char )'\000';
          } else {

          }
          tmp___19 = t2pWriteFile(output, (tdata_t )"/Author ", (tmsize_t )8);
          written += tmp___19;
          tmp___20 = t2p_write_pdf_string(info, output);
          written += tmp___20;
          tmp___21 = t2pWriteFile(output, (tdata_t )"\n", (tmsize_t )1);
          written += tmp___21;
        } else {

        }
      } else {

      }
    }
  }
  if ((int )t2p->pdf_title[0] != 0) {
    tmp___24 = t2pWriteFile(output, (tdata_t )"/Title ", (tmsize_t )7);
    written += tmp___24;
    tmp___25 = t2p_write_pdf_string(t2p->pdf_title, output);
    written += tmp___25;
    tmp___26 = t2pWriteFile(output, (tdata_t )"\n", (tmsize_t )1);
    written += tmp___26;
  } else {
    tmp___31 = TIFFGetField(input, (uint32 )269, & info);
    if (tmp___31 != 0) {
      tmp___27 = strlen((char const   *)info);
      if (tmp___27 > 511UL) {
        *(info + 512) = (char )'\000';
      } else {

      }
      tmp___28 = t2pWriteFile(output, (tdata_t )"/Title ", (tmsize_t )7);
      written += tmp___28;
      tmp___29 = t2p_write_pdf_string(info, output);
      written += tmp___29;
      tmp___30 = t2pWriteFile(output, (tdata_t )"\n", (tmsize_t )1);
      written += tmp___30;
    } else {

    }
  }
  if ((int )t2p->pdf_subject[0] != 0) {
    tmp___32 = t2pWriteFile(output, (tdata_t )"/Subject ", (tmsize_t )9);
    written += tmp___32;
    tmp___33 = t2p_write_pdf_string(t2p->pdf_subject, output);
    written += tmp___33;
    tmp___34 = t2pWriteFile(output, (tdata_t )"\n", (tmsize_t )1);
    written += tmp___34;
  } else {
    tmp___39 = TIFFGetField(input, (uint32 )270, & info);
    if (tmp___39 != 0) {
      if (info) {
        tmp___35 = strlen((char const   *)info);
        if (tmp___35 >= sizeof(t2p->pdf_subject)) {
          *(info + (sizeof(t2p->pdf_subject) - 1UL)) = (char )'\000';
        } else {

        }
        tmp___36 = t2pWriteFile(output, (tdata_t )"/Subject ", (tmsize_t )9);
        written += tmp___36;
        tmp___37 = t2p_write_pdf_string(info, output);
        written += tmp___37;
        tmp___38 = t2pWriteFile(output, (tdata_t )"\n", (tmsize_t )1);
        written += tmp___38;
      } else {

      }
    } else {

    }
  }
  if ((int )t2p->pdf_keywords[0] != 0) {
    tmp___40 = t2pWriteFile(output, (tdata_t )"/Keywords ", (tmsize_t )10);
    written += tmp___40;
    tmp___41 = t2p_write_pdf_string(t2p->pdf_keywords, output);
    written += tmp___41;
    tmp___42 = t2pWriteFile(output, (tdata_t )"\n", (tmsize_t )1);
    written += tmp___42;
  } else {

  }
  tmp___43 = t2pWriteFile(output, (tdata_t )">> \n", (tmsize_t )4);
  written += tmp___43;
  return (written);
}
}
void t2p_pdf_currenttime(T2P *t2p ) 
{ 
  struct tm *currenttime ;
  time_t timenow ;
  int *tmp ;
  char *tmp___0 ;
  time_t tmp___1 ;

  {
  tmp___1 = time(& timenow);
  if (tmp___1 == -1L) {
    tmp = __errno_location();
    tmp___0 = strerror(*tmp);
    TIFFError("tiff2pdf", "Can\'t get the current time: %s", tmp___0);
    timenow = (time_t )0;
  } else {

  }
  currenttime = localtime((time_t const   *)(& timenow));
  snprintf((char */* __restrict  */)(t2p->pdf_datetime),
           sizeof(t2p->pdf_datetime),
           (char const   */* __restrict  */)"D:%.4d%.2d%.2d%.2d%.2d%.2d",
           (currenttime->tm_year + 1900) % 65536,
           (currenttime->tm_mon + 1) % 256, currenttime->tm_mday % 256,
           currenttime->tm_hour % 256, currenttime->tm_min % 256,
           currenttime->tm_sec % 256);
  return;
}
}
void t2p_pdf_tifftime(T2P *t2p , TIFF *input ) 
{ 
  char *datetime ;
  int tmp ;
  size_t tmp___0 ;

  {
  tmp = TIFFGetField(input, (uint32 )306, & datetime);
  if (tmp != 0) {
    tmp___0 = strlen((char const   *)datetime);
    if (tmp___0 >= 19UL) {
      t2p->pdf_datetime[0] = (char )'D';
      t2p->pdf_datetime[1] = (char )':';
      t2p->pdf_datetime[2] = *(datetime + 0);
      t2p->pdf_datetime[3] = *(datetime + 1);
      t2p->pdf_datetime[4] = *(datetime + 2);
      t2p->pdf_datetime[5] = *(datetime + 3);
      t2p->pdf_datetime[6] = *(datetime + 5);
      t2p->pdf_datetime[7] = *(datetime + 6);
      t2p->pdf_datetime[8] = *(datetime + 8);
      t2p->pdf_datetime[9] = *(datetime + 9);
      t2p->pdf_datetime[10] = *(datetime + 11);
      t2p->pdf_datetime[11] = *(datetime + 12);
      t2p->pdf_datetime[12] = *(datetime + 14);
      t2p->pdf_datetime[13] = *(datetime + 15);
      t2p->pdf_datetime[14] = *(datetime + 17);
      t2p->pdf_datetime[15] = *(datetime + 18);
      t2p->pdf_datetime[16] = (char )'\000';
    } else {
      t2p_pdf_currenttime(t2p);
    }
  } else {
    t2p_pdf_currenttime(t2p);
  }
  return;
}
}
tsize_t t2p_write_pdf_pages(T2P *t2p , TIFF *output ) 
{ 
  tsize_t written ;
  tdir_t i ;
  char buffer[16] ;
  int buflen ;
  int page ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  tmsize_t tmp___4 ;
  tmsize_t tmp___5 ;

  {
  written = (tsize_t )0;
  i = (tdir_t )0;
  buflen = 0;
  page = 0;
  tmp = t2pWriteFile(output, (tdata_t )"<< \n/Type /Pages \n/Kids [ ",
                     (tmsize_t )26);
  written += tmp;
  page = (int )(t2p->pdf_pages + 1U);
  i = (tdir_t )0;
  while ((int )i < (int )t2p->tiff_pagecount) {
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%d", page);
    tmp___0 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
    written += tmp___0;
    tmp___1 = t2pWriteFile(output, (tdata_t )" 0 R ", (tmsize_t )5);
    written += tmp___1;
    if (((int )i + 1) % 8 == 0) {
      tmp___2 = t2pWriteFile(output, (tdata_t )"\n", (tmsize_t )1);
      written += tmp___2;
    } else {

    }
    page += 3;
    page = (int )((uint32 )page + (t2p->tiff_pages + (int )i)->page_extra);
    if ((t2p->tiff_pages + (int )i)->page_tilecount > 0U) {
      page = (int )((ttile_t )page + 2U * (t2p->tiff_pages + (int )i)->page_tilecount);
    } else {
      page += 2;
    }
    i = (tdir_t )((int )i + 1);
  }
  tmp___3 = t2pWriteFile(output, (tdata_t )"] \n/Count ", (tmsize_t )10);
  written += tmp___3;
  _TIFFmemset((void *)(buffer), 0, (tmsize_t )16);
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%d",
                   (int )t2p->tiff_pagecount);
  tmp___4 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
  written += tmp___4;
  tmp___5 = t2pWriteFile(output, (tdata_t )" \n>> \n", (tmsize_t )6);
  written += tmp___5;
  return (written);
}
}
tsize_t t2p_write_pdf_page(uint32 object , T2P *t2p , TIFF *output ) 
{ 
  unsigned int i ;
  tsize_t written ;
  char buffer[16] ;
  int buflen ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  tmsize_t tmp___4 ;
  tmsize_t tmp___5 ;
  tmsize_t tmp___6 ;
  tmsize_t tmp___7 ;
  tmsize_t tmp___8 ;
  tmsize_t tmp___9 ;
  tmsize_t tmp___10 ;
  tmsize_t tmp___11 ;
  tmsize_t tmp___12 ;
  tmsize_t tmp___13 ;
  tmsize_t tmp___14 ;
  tmsize_t tmp___15 ;
  tmsize_t tmp___16 ;
  tmsize_t tmp___17 ;
  tmsize_t tmp___18 ;
  tmsize_t tmp___19 ;
  tmsize_t tmp___20 ;
  tmsize_t tmp___21 ;
  tmsize_t tmp___22 ;
  tmsize_t tmp___23 ;
  tmsize_t tmp___24 ;
  tmsize_t tmp___25 ;
  tmsize_t tmp___26 ;
  tmsize_t tmp___27 ;
  tmsize_t tmp___28 ;
  tmsize_t tmp___29 ;
  tmsize_t tmp___30 ;
  tmsize_t tmp___31 ;
  tmsize_t tmp___32 ;
  tmsize_t tmp___33 ;
  tmsize_t tmp___34 ;
  tmsize_t tmp___35 ;
  tmsize_t tmp___36 ;
  tmsize_t tmp___37 ;
  tmsize_t tmp___38 ;
  tmsize_t tmp___39 ;
  tmsize_t tmp___40 ;

  {
  i = 0U;
  written = (tsize_t )0;
  buflen = 0;
  tmp = t2pWriteFile(output, (tdata_t )"<<\n/Type /Page \n/Parent ",
                     (tmsize_t )24);
  written += tmp;
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%lu",
                   (unsigned long )t2p->pdf_pages);
  tmp___0 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
  written += tmp___0;
  tmp___1 = t2pWriteFile(output, (tdata_t )" 0 R \n", (tmsize_t )6);
  written += tmp___1;
  tmp___2 = t2pWriteFile(output, (tdata_t )"/MediaBox [", (tmsize_t )11);
  written += tmp___2;
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%.4f",
                   (double )t2p->pdf_mediabox.x1);
  tmp___3 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
  written += tmp___3;
  tmp___4 = t2pWriteFile(output, (tdata_t )" ", (tmsize_t )1);
  written += tmp___4;
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%.4f",
                   (double )t2p->pdf_mediabox.y1);
  tmp___5 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
  written += tmp___5;
  tmp___6 = t2pWriteFile(output, (tdata_t )" ", (tmsize_t )1);
  written += tmp___6;
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%.4f",
                   (double )t2p->pdf_mediabox.x2);
  tmp___7 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
  written += tmp___7;
  tmp___8 = t2pWriteFile(output, (tdata_t )" ", (tmsize_t )1);
  written += tmp___8;
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%.4f",
                   (double )t2p->pdf_mediabox.y2);
  tmp___9 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
  written += tmp___9;
  tmp___10 = t2pWriteFile(output, (tdata_t )"] \n", (tmsize_t )3);
  written += tmp___10;
  tmp___11 = t2pWriteFile(output, (tdata_t )"/Contents ", (tmsize_t )10);
  written += tmp___11;
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%lu",
                   (unsigned long )(object + 1U));
  tmp___12 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
  written += tmp___12;
  tmp___13 = t2pWriteFile(output, (tdata_t )" 0 R \n", (tmsize_t )6);
  written += tmp___13;
  tmp___14 = t2pWriteFile(output, (tdata_t )"/Resources << \n", (tmsize_t )15);
  written += tmp___14;
  if ((t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilecount != 0U) {
    tmp___15 = t2pWriteFile(output, (tdata_t )"/XObject <<\n", (tmsize_t )12);
    written += tmp___15;
    i = 0U;
    while (i < (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilecount) {
      tmp___16 = t2pWriteFile(output, (tdata_t )"/Im", (tmsize_t )3);
      written += tmp___16;
      buflen = sprintf((char */* __restrict  */)(buffer),
                       (char const   */* __restrict  */)"%u",
                       (int )t2p->pdf_page + 1);
      tmp___17 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
      written += tmp___17;
      tmp___18 = t2pWriteFile(output, (tdata_t )"_", (tmsize_t )1);
      written += tmp___18;
      buflen = sprintf((char */* __restrict  */)(buffer),
                       (char const   */* __restrict  */)"%u", i + 1U);
      tmp___19 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
      written += tmp___19;
      tmp___20 = t2pWriteFile(output, (tdata_t )" ", (tmsize_t )1);
      written += tmp___20;
      buflen = sprintf((char */* __restrict  */)(buffer),
                       (char const   */* __restrict  */)"%lu",
                       (unsigned long )(((object + 3U) + 2U * i) + (t2p->tiff_pages + (int )t2p->pdf_page)->page_extra));
      tmp___21 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
      written += tmp___21;
      tmp___22 = t2pWriteFile(output, (tdata_t )" 0 R ", (tmsize_t )5);
      written += tmp___22;
      if (i % 4U == 3U) {
        tmp___23 = t2pWriteFile(output, (tdata_t )"\n", (tmsize_t )1);
        written += tmp___23;
      } else {

      }
      i ++;
    }
    tmp___24 = t2pWriteFile(output, (tdata_t )">>\n", (tmsize_t )3);
    written += tmp___24;
  } else {
    tmp___25 = t2pWriteFile(output, (tdata_t )"/XObject <<\n", (tmsize_t )12);
    written += tmp___25;
    tmp___26 = t2pWriteFile(output, (tdata_t )"/Im", (tmsize_t )3);
    written += tmp___26;
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%u",
                     (int )t2p->pdf_page + 1);
    tmp___27 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
    written += tmp___27;
    tmp___28 = t2pWriteFile(output, (tdata_t )" ", (tmsize_t )1);
    written += tmp___28;
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )(((object + 3U) + 2U * i) + (t2p->tiff_pages + (int )t2p->pdf_page)->page_extra));
    tmp___29 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
    written += tmp___29;
    tmp___30 = t2pWriteFile(output, (tdata_t )" 0 R ", (tmsize_t )5);
    written += tmp___30;
    tmp___31 = t2pWriteFile(output, (tdata_t )">>\n", (tmsize_t )3);
    written += tmp___31;
  }
  if ((int )t2p->tiff_transferfunctioncount != 0) {
    tmp___32 = t2pWriteFile(output, (tdata_t )"/ExtGState <<", (tmsize_t )13);
    written += tmp___32;
    t2pWriteFile(output, (tdata_t )"/GS1 ", (tmsize_t )5);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )(object + 3U));
    tmp___33 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
    written += tmp___33;
    tmp___34 = t2pWriteFile(output, (tdata_t )" 0 R ", (tmsize_t )5);
    written += tmp___34;
    tmp___35 = t2pWriteFile(output, (tdata_t )">> \n", (tmsize_t )4);
    written += tmp___35;
  } else {

  }
  tmp___36 = t2pWriteFile(output, (tdata_t )"/ProcSet [ ", (tmsize_t )11);
  written += tmp___36;
  if ((unsigned int )t2p->pdf_colorspace == 1U) {
    tmp___37 = t2pWriteFile(output, (tdata_t )"/ImageB ", (tmsize_t )8);
    written += tmp___37;
  } else
  if ((unsigned int )t2p->pdf_colorspace == 2U) {
    tmp___37 = t2pWriteFile(output, (tdata_t )"/ImageB ", (tmsize_t )8);
    written += tmp___37;
  } else {
    tmp___38 = t2pWriteFile(output, (tdata_t )"/ImageC ", (tmsize_t )8);
    written += tmp___38;
    if ((unsigned int )t2p->pdf_colorspace & 4096U) {
      tmp___39 = t2pWriteFile(output, (tdata_t )"/ImageI ", (tmsize_t )8);
      written += tmp___39;
    } else {

    }
  }
  tmp___40 = t2pWriteFile(output, (tdata_t )"]\n>>\n>>\n", (tmsize_t )8);
  written += tmp___40;
  return (written);
}
}
void t2p_compose_pdf_page(T2P *t2p ) 
{ 
  uint32 i ;
  uint32 i2 ;
  T2P_TILE *tiles ;
  T2P_BOX *boxp ;
  uint32 tilecountx ;
  uint32 tilecounty ;
  uint32 tilewidth ;
  uint32 tilelength ;
  int istiled ;
  float f ;

  {
  i = (uint32 )0;
  i2 = (uint32 )0;
  tiles = (T2P_TILE *)((void *)0);
  boxp = (T2P_BOX *)((void *)0);
  tilecountx = (uint32 )0;
  tilecounty = (uint32 )0;
  tilewidth = (uint32 )0;
  tilelength = (uint32 )0;
  istiled = 0;
  f = (float )0;
  t2p->pdf_xres = t2p->tiff_xres;
  t2p->pdf_yres = t2p->tiff_yres;
  if (t2p->pdf_overrideres) {
    t2p->pdf_xres = t2p->pdf_defaultxres;
    t2p->pdf_yres = t2p->pdf_defaultyres;
  } else {

  }
  if ((double )t2p->pdf_xres == 0.0) {
    t2p->pdf_xres = t2p->pdf_defaultxres;
  } else {

  }
  if ((double )t2p->pdf_yres == 0.0) {
    t2p->pdf_yres = t2p->pdf_defaultyres;
  } else {

  }
  if ((int )t2p->tiff_resunit != 3) {
    if ((int )t2p->tiff_resunit != 2) {
      t2p->pdf_imagewidth = (float )t2p->tiff_width / t2p->pdf_xres;
      t2p->pdf_imagelength = (float )t2p->tiff_length / t2p->pdf_yres;
    } else {
      t2p->pdf_imagewidth = ((float )t2p->tiff_width * 72.0F) / t2p->pdf_xres;
      t2p->pdf_imagelength = ((float )t2p->tiff_length * 72.0F) / t2p->pdf_yres;
    }
  } else {
    t2p->pdf_imagewidth = ((float )t2p->tiff_width * 72.0F) / t2p->pdf_xres;
    t2p->pdf_imagelength = ((float )t2p->tiff_length * 72.0F) / t2p->pdf_yres;
  }
  if ((int )t2p->pdf_overridepagesize != 0) {
    t2p->pdf_pagewidth = t2p->pdf_defaultpagewidth;
    t2p->pdf_pagelength = t2p->pdf_defaultpagelength;
  } else {
    t2p->pdf_pagewidth = t2p->pdf_imagewidth;
    t2p->pdf_pagelength = t2p->pdf_imagelength;
  }
  t2p->pdf_mediabox.x1 = (float )0.0;
  t2p->pdf_mediabox.y1 = (float )0.0;
  t2p->pdf_mediabox.x2 = t2p->pdf_pagewidth;
  t2p->pdf_mediabox.y2 = t2p->pdf_pagelength;
  t2p->pdf_imagebox.x1 = (float )0.0;
  t2p->pdf_imagebox.y1 = (float )0.0;
  t2p->pdf_imagebox.x2 = t2p->pdf_imagewidth;
  t2p->pdf_imagebox.y2 = t2p->pdf_imagelength;
  if ((int )t2p->pdf_overridepagesize != 0) {
    t2p->pdf_imagebox.x1 += (t2p->pdf_pagewidth - t2p->pdf_imagewidth) / 2.0F;
    t2p->pdf_imagebox.y1 += (t2p->pdf_pagelength - t2p->pdf_imagelength) / 2.0F;
    t2p->pdf_imagebox.x2 += (t2p->pdf_pagewidth - t2p->pdf_imagewidth) / 2.0F;
    t2p->pdf_imagebox.y2 += (t2p->pdf_pagelength - t2p->pdf_imagelength) / 2.0F;
  } else {

  }
  if ((int )t2p->tiff_orientation > 4) {
    f = t2p->pdf_mediabox.x2;
    t2p->pdf_mediabox.x2 = t2p->pdf_mediabox.y2;
    t2p->pdf_mediabox.y2 = f;
  } else {

  }
  if ((t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilecount == 0U) {
    istiled = 0;
  } else {
    istiled = 1;
  }
  if (istiled == 0) {
    t2p_compose_pdf_page_orient(& t2p->pdf_imagebox, t2p->tiff_orientation);
    return;
  } else {
    tilewidth = (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilewidth;
    tilelength = (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilelength;
    tilecountx = ((t2p->tiff_width + tilewidth) - 1U) / tilewidth;
    (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilecountx = tilecountx;
    tilecounty = ((t2p->tiff_length + tilelength) - 1U) / tilelength;
    (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilecounty = tilecounty;
    (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_edgetilewidth = t2p->tiff_width % tilewidth;
    (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_edgetilelength = t2p->tiff_length % tilelength;
    tiles = (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tiles;
    i2 = (uint32 )0;
    while (i2 < tilecounty - 1U) {
      i = (uint32 )0;
      while (i < tilecountx - 1U) {
        boxp = & (tiles + (i2 * tilecountx + i))->tile_box;
        boxp->x1 = t2p->pdf_imagebox.x1 + ((t2p->pdf_imagewidth * (float )i) * (float )tilewidth) / (float )t2p->tiff_width;
        boxp->x2 = t2p->pdf_imagebox.x1 + ((t2p->pdf_imagewidth * (float )(i + 1U)) * (float )tilewidth) / (float )t2p->tiff_width;
        boxp->y1 = t2p->pdf_imagebox.y2 - ((t2p->pdf_imagelength * (float )(i2 + 1U)) * (float )tilelength) / (float )t2p->tiff_length;
        boxp->y2 = t2p->pdf_imagebox.y2 - ((t2p->pdf_imagelength * (float )i2) * (float )tilelength) / (float )t2p->tiff_length;
        i ++;
      }
      boxp = & (tiles + (i2 * tilecountx + i))->tile_box;
      boxp->x1 = t2p->pdf_imagebox.x1 + ((t2p->pdf_imagewidth * (float )i) * (float )tilewidth) / (float )t2p->tiff_width;
      boxp->x2 = t2p->pdf_imagebox.x2;
      boxp->y1 = t2p->pdf_imagebox.y2 - ((t2p->pdf_imagelength * (float )(i2 + 1U)) * (float )tilelength) / (float )t2p->tiff_length;
      boxp->y2 = t2p->pdf_imagebox.y2 - ((t2p->pdf_imagelength * (float )i2) * (float )tilelength) / (float )t2p->tiff_length;
      i2 ++;
    }
    i = (uint32 )0;
    while (i < tilecountx - 1U) {
      boxp = & (tiles + (i2 * tilecountx + i))->tile_box;
      boxp->x1 = t2p->pdf_imagebox.x1 + ((t2p->pdf_imagewidth * (float )i) * (float )tilewidth) / (float )t2p->tiff_width;
      boxp->x2 = t2p->pdf_imagebox.x1 + ((t2p->pdf_imagewidth * (float )(i + 1U)) * (float )tilewidth) / (float )t2p->tiff_width;
      boxp->y1 = t2p->pdf_imagebox.y1;
      boxp->y2 = t2p->pdf_imagebox.y2 - ((t2p->pdf_imagelength * (float )i2) * (float )tilelength) / (float )t2p->tiff_length;
      i ++;
    }
    boxp = & (tiles + (i2 * tilecountx + i))->tile_box;
    boxp->x1 = t2p->pdf_imagebox.x1 + ((t2p->pdf_imagewidth * (float )i) * (float )tilewidth) / (float )t2p->tiff_width;
    boxp->x2 = t2p->pdf_imagebox.x2;
    boxp->y1 = t2p->pdf_imagebox.y1;
    boxp->y2 = t2p->pdf_imagebox.y2 - ((t2p->pdf_imagelength * (float )i2) * (float )tilelength) / (float )t2p->tiff_length;
  }
  if ((int )t2p->tiff_orientation == 0) {
    goto _L;
  } else
  if ((int )t2p->tiff_orientation == 1) {
    _L: 
    i = (uint32 )0;
    while (i < (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilecount) {
      t2p_compose_pdf_page_orient(& (tiles + i)->tile_box, (uint16 )0);
      i ++;
    }
    return;
  } else {

  }
  i = (uint32 )0;
  while (i < (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilecount) {
    boxp = & (tiles + i)->tile_box;
    boxp->x1 -= t2p->pdf_imagebox.x1;
    boxp->x2 -= t2p->pdf_imagebox.x1;
    boxp->y1 -= t2p->pdf_imagebox.y1;
    boxp->y2 -= t2p->pdf_imagebox.y1;
    if ((int )t2p->tiff_orientation == 2) {
      boxp->x1 = (t2p->pdf_imagebox.x2 - t2p->pdf_imagebox.x1) - boxp->x1;
      boxp->x2 = (t2p->pdf_imagebox.x2 - t2p->pdf_imagebox.x1) - boxp->x2;
    } else
    if ((int )t2p->tiff_orientation == 3) {
      boxp->x1 = (t2p->pdf_imagebox.x2 - t2p->pdf_imagebox.x1) - boxp->x1;
      boxp->x2 = (t2p->pdf_imagebox.x2 - t2p->pdf_imagebox.x1) - boxp->x2;
    } else {

    }
    if ((int )t2p->tiff_orientation == 3) {
      boxp->y1 = (t2p->pdf_imagebox.y2 - t2p->pdf_imagebox.y1) - boxp->y1;
      boxp->y2 = (t2p->pdf_imagebox.y2 - t2p->pdf_imagebox.y1) - boxp->y2;
    } else
    if ((int )t2p->tiff_orientation == 4) {
      boxp->y1 = (t2p->pdf_imagebox.y2 - t2p->pdf_imagebox.y1) - boxp->y1;
      boxp->y2 = (t2p->pdf_imagebox.y2 - t2p->pdf_imagebox.y1) - boxp->y2;
    } else {

    }
    if ((int )t2p->tiff_orientation == 8) {
      boxp->y1 = (t2p->pdf_imagebox.y2 - t2p->pdf_imagebox.y1) - boxp->y1;
      boxp->y2 = (t2p->pdf_imagebox.y2 - t2p->pdf_imagebox.y1) - boxp->y2;
    } else
    if ((int )t2p->tiff_orientation == 5) {
      boxp->y1 = (t2p->pdf_imagebox.y2 - t2p->pdf_imagebox.y1) - boxp->y1;
      boxp->y2 = (t2p->pdf_imagebox.y2 - t2p->pdf_imagebox.y1) - boxp->y2;
    } else {

    }
    if ((int )t2p->tiff_orientation == 5) {
      boxp->x1 = (t2p->pdf_imagebox.x2 - t2p->pdf_imagebox.x1) - boxp->x1;
      boxp->x2 = (t2p->pdf_imagebox.x2 - t2p->pdf_imagebox.x1) - boxp->x2;
    } else
    if ((int )t2p->tiff_orientation == 6) {
      boxp->x1 = (t2p->pdf_imagebox.x2 - t2p->pdf_imagebox.x1) - boxp->x1;
      boxp->x2 = (t2p->pdf_imagebox.x2 - t2p->pdf_imagebox.x1) - boxp->x2;
    } else {

    }
    if ((int )t2p->tiff_orientation > 4) {
      f = boxp->x1;
      boxp->x1 = boxp->y1;
      boxp->y1 = f;
      f = boxp->x2;
      boxp->x2 = boxp->y2;
      boxp->y2 = f;
      t2p_compose_pdf_page_orient_flip(boxp, t2p->tiff_orientation);
    } else {
      t2p_compose_pdf_page_orient(boxp, t2p->tiff_orientation);
    }
    i ++;
  }
  return;
}
}
void t2p_compose_pdf_page_orient(T2P_BOX *boxp , uint16 orientation ) 
{ 
  float m1[9] ;
  float f ;

  {
  f = (float )0.0;
  if (boxp->x1 > boxp->x2) {
    f = boxp->x1;
    boxp->x1 = boxp->x2;
    boxp->x2 = f;
  } else {

  }
  if (boxp->y1 > boxp->y2) {
    f = boxp->y1;
    boxp->y1 = boxp->y2;
    boxp->y2 = f;
  } else {

  }
  m1[0] = boxp->x2 - boxp->x1;
  boxp->mat[0] = m1[0];
  m1[1] = (float )0.0;
  boxp->mat[1] = m1[1];
  m1[2] = (float )0.0;
  boxp->mat[2] = m1[2];
  m1[3] = (float )0.0;
  boxp->mat[3] = m1[3];
  m1[4] = boxp->y2 - boxp->y1;
  boxp->mat[4] = m1[4];
  m1[5] = (float )0.0;
  boxp->mat[5] = m1[5];
  m1[6] = boxp->x1;
  boxp->mat[6] = m1[6];
  m1[7] = boxp->y1;
  boxp->mat[7] = m1[7];
  m1[8] = (float )1.0;
  boxp->mat[8] = m1[8];
  switch ((int )orientation) {
  case 0: 
  case 1: 
  break;
  case 2: 
  boxp->mat[0] = 0.0F - m1[0];
  boxp->mat[6] += m1[0];
  break;
  case 3: 
  boxp->mat[0] = 0.0F - m1[0];
  boxp->mat[4] = 0.0F - m1[4];
  boxp->mat[6] += m1[0];
  boxp->mat[7] += m1[4];
  break;
  case 4: 
  boxp->mat[4] = 0.0F - m1[4];
  boxp->mat[7] += m1[4];
  break;
  case 5: 
  boxp->mat[0] = 0.0F;
  boxp->mat[1] = 0.0F - m1[0];
  boxp->mat[3] = 0.0F - m1[4];
  boxp->mat[4] = 0.0F;
  boxp->mat[6] += m1[4];
  boxp->mat[7] += m1[0];
  break;
  case 6: 
  boxp->mat[0] = 0.0F;
  boxp->mat[1] = 0.0F - m1[0];
  boxp->mat[3] = m1[4];
  boxp->mat[4] = 0.0F;
  boxp->mat[7] += m1[0];
  break;
  case 7: 
  boxp->mat[0] = 0.0F;
  boxp->mat[1] = m1[0];
  boxp->mat[3] = m1[4];
  boxp->mat[4] = 0.0F;
  break;
  case 8: 
  boxp->mat[0] = 0.0F;
  boxp->mat[1] = m1[0];
  boxp->mat[3] = 0.0F - m1[4];
  boxp->mat[4] = 0.0F;
  boxp->mat[6] += m1[4];
  break;
  }
  return;
}
}
void t2p_compose_pdf_page_orient_flip(T2P_BOX *boxp , uint16 orientation ) 
{ 
  float m1[9] ;
  float f ;

  {
  f = (float )0.0;
  if (boxp->x1 > boxp->x2) {
    f = boxp->x1;
    boxp->x1 = boxp->x2;
    boxp->x2 = f;
  } else {

  }
  if (boxp->y1 > boxp->y2) {
    f = boxp->y1;
    boxp->y1 = boxp->y2;
    boxp->y2 = f;
  } else {

  }
  m1[0] = boxp->x2 - boxp->x1;
  boxp->mat[0] = m1[0];
  m1[1] = 0.0F;
  boxp->mat[1] = m1[1];
  m1[2] = 0.0F;
  boxp->mat[2] = m1[2];
  m1[3] = 0.0F;
  boxp->mat[3] = m1[3];
  m1[4] = boxp->y2 - boxp->y1;
  boxp->mat[4] = m1[4];
  m1[5] = 0.0F;
  boxp->mat[5] = m1[5];
  m1[6] = boxp->x1;
  boxp->mat[6] = m1[6];
  m1[7] = boxp->y1;
  boxp->mat[7] = m1[7];
  m1[8] = 1.0F;
  boxp->mat[8] = m1[8];
  switch ((int )orientation) {
  case 5: 
  boxp->mat[0] = 0.0F;
  boxp->mat[1] = 0.0F - m1[4];
  boxp->mat[3] = 0.0F - m1[0];
  boxp->mat[4] = 0.0F;
  boxp->mat[6] += m1[0];
  boxp->mat[7] += m1[4];
  break;
  case 6: 
  boxp->mat[0] = 0.0F;
  boxp->mat[1] = 0.0F - m1[4];
  boxp->mat[3] = m1[0];
  boxp->mat[4] = 0.0F;
  boxp->mat[7] += m1[4];
  break;
  case 7: 
  boxp->mat[0] = 0.0F;
  boxp->mat[1] = m1[4];
  boxp->mat[3] = m1[0];
  boxp->mat[4] = 0.0F;
  break;
  case 8: 
  boxp->mat[0] = 0.0F;
  boxp->mat[1] = m1[4];
  boxp->mat[3] = 0.0F - m1[0];
  boxp->mat[4] = 0.0F;
  boxp->mat[6] += m1[0];
  break;
  }
  return;
}
}
tsize_t t2p_write_pdf_page_content_stream(T2P *t2p , TIFF *output ) 
{ 
  tsize_t written ;
  ttile_t i ;
  char buffer[512] ;
  int buflen ;
  T2P_BOX box ;
  char const   *tmp ;
  tsize_t tmp___0 ;
  char const   *tmp___1 ;
  tsize_t tmp___2 ;

  {
  written = (tsize_t )0;
  i = (ttile_t )0;
  buflen = 0;
  if ((t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilecount > 0U) {
    i = (ttile_t )0;
    while (i < (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilecount) {
      box = ((t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tiles + i)->tile_box;
      if (t2p->tiff_transferfunctioncount) {
        tmp = "/GS1 gs ";
      } else {
        tmp = "";
      }
      buflen = sprintf((char */* __restrict  */)(buffer),
                       (char const   */* __restrict  */)"q %s %.4f %.4f %.4f %.4f %.4f %.4f cm /Im%d_%ld Do Q\n",
                       tmp, (double )box.mat[0], (double )box.mat[1],
                       (double )box.mat[3], (double )box.mat[4],
                       (double )box.mat[6], (double )box.mat[7],
                       (int )t2p->pdf_page + 1, (long )(i + 1U));
      tmp___0 = t2p_write_pdf_stream((tdata_t )(buffer), (tsize_t )buflen,
                                     output);
      written += tmp___0;
      i ++;
    }
  } else {
    box = t2p->pdf_imagebox;
    if (t2p->tiff_transferfunctioncount) {
      tmp___1 = "/GS1 gs ";
    } else {
      tmp___1 = "";
    }
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"q %s %.4f %.4f %.4f %.4f %.4f %.4f cm /Im%d Do Q\n",
                     tmp___1, (double )box.mat[0], (double )box.mat[1],
                     (double )box.mat[3], (double )box.mat[4],
                     (double )box.mat[6], (double )box.mat[7],
                     (int )t2p->pdf_page + 1);
    tmp___2 = t2p_write_pdf_stream((tdata_t )(buffer), (tsize_t )buflen, output);
    written += tmp___2;
  }
  return (written);
}
}
tsize_t t2p_write_pdf_xobject_stream_dict(ttile_t tile , T2P *t2p ,
                                          TIFF *output ) 
{ 
  tsize_t written ;
  char buffer[16] ;
  int buflen ;
  tsize_t tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  tmsize_t tmp___4 ;
  int tmp___5 ;
  tmsize_t tmp___6 ;
  tmsize_t tmp___7 ;
  int tmp___8 ;
  tmsize_t tmp___9 ;
  tmsize_t tmp___10 ;
  tmsize_t tmp___11 ;
  tmsize_t tmp___12 ;
  tsize_t tmp___13 ;
  tmsize_t tmp___14 ;
  tsize_t tmp___15 ;
  tsize_t tmp___16 ;

  {
  written = (tsize_t )0;
  buflen = 0;
  tmp = t2p_write_pdf_stream_dict((tsize_t )0, t2p->pdf_xrefcount + 1U, output);
  written += tmp;
  tmp___0 = t2pWriteFile(output,
                         (tdata_t )"/Type /XObject \n/Subtype /Image \n/Name /Im",
                         (tmsize_t )42);
  written += tmp___0;
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%u",
                   (int )t2p->pdf_page + 1);
  tmp___1 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
  written += tmp___1;
  if (tile != 0U) {
    tmp___2 = t2pWriteFile(output, (tdata_t )"_", (tmsize_t )1);
    written += tmp___2;
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )tile);
    tmp___3 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
    written += tmp___3;
  } else {

  }
  tmp___4 = t2pWriteFile(output, (tdata_t )"\n/Width ", (tmsize_t )8);
  written += tmp___4;
  _TIFFmemset((tdata_t )(buffer), 0, (tmsize_t )16);
  if (tile == 0U) {
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )t2p->tiff_width);
  } else {
    tmp___5 = t2p_tile_is_right_edge(*(t2p->tiff_tiles + (int )t2p->pdf_page),
                                     tile - 1U);
    if (tmp___5 != 0) {
      buflen = sprintf((char */* __restrict  */)(buffer),
                       (char const   */* __restrict  */)"%lu",
                       (unsigned long )(t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_edgetilewidth);
    } else {
      buflen = sprintf((char */* __restrict  */)(buffer),
                       (char const   */* __restrict  */)"%lu",
                       (unsigned long )(t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilewidth);
    }
  }
  tmp___6 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
  written += tmp___6;
  tmp___7 = t2pWriteFile(output, (tdata_t )"\n/Height ", (tmsize_t )9);
  written += tmp___7;
  _TIFFmemset((tdata_t )(buffer), 0, (tmsize_t )16);
  if (tile == 0U) {
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )t2p->tiff_length);
  } else {
    tmp___8 = t2p_tile_is_bottom_edge(*(t2p->tiff_tiles + (int )t2p->pdf_page),
                                      tile - 1U);
    if (tmp___8 != 0) {
      buflen = sprintf((char */* __restrict  */)(buffer),
                       (char const   */* __restrict  */)"%lu",
                       (unsigned long )(t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_edgetilelength);
    } else {
      buflen = sprintf((char */* __restrict  */)(buffer),
                       (char const   */* __restrict  */)"%lu",
                       (unsigned long )(t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilelength);
    }
  }
  tmp___9 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
  written += tmp___9;
  tmp___10 = t2pWriteFile(output, (tdata_t )"\n/BitsPerComponent ",
                          (tmsize_t )19);
  written += tmp___10;
  _TIFFmemset((tdata_t )(buffer), 0, (tmsize_t )16);
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%u",
                   (int )t2p->tiff_bitspersample);
  tmp___11 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
  written += tmp___11;
  tmp___12 = t2pWriteFile(output, (tdata_t )"\n/ColorSpace ", (tmsize_t )13);
  written += tmp___12;
  tmp___13 = t2p_write_pdf_xobject_cs(t2p, output);
  written += tmp___13;
  if (t2p->pdf_image_interpolate) {
    tmp___14 = t2pWriteFile(output, (tdata_t )"\n/Interpolate true",
                            (tmsize_t )18);
    written += tmp___14;
  } else {

  }
  if ((int )t2p->pdf_switchdecode != 0) {
    if ((unsigned int )t2p->pdf_colorspace == 1U) {
      if (! ((unsigned int )t2p->pdf_compression == 1U)) {
        tmp___15 = t2p_write_pdf_xobject_decode(t2p, output);
        written += tmp___15;
      } else {

      }
    } else {
      tmp___15 = t2p_write_pdf_xobject_decode(t2p, output);
      written += tmp___15;
    }
  } else {

  }
  tmp___16 = t2p_write_pdf_xobject_stream_filter(tile, t2p, output);
  written += tmp___16;
  return (written);
}
}
tsize_t t2p_write_pdf_xobject_cs(T2P *t2p , TIFF *output ) 
{ 
  tsize_t written ;
  char buffer[128] ;
  int buflen ;
  float X_W ;
  float Y_W ;
  float Z_W ;
  tsize_t tmp ;
  tmsize_t tmp___0 ;
  tsize_t tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  tmsize_t tmp___4 ;
  tmsize_t tmp___5 ;
  tmsize_t tmp___6 ;
  tsize_t tmp___7 ;
  tmsize_t tmp___8 ;
  tsize_t tmp___9 ;
  tmsize_t tmp___10 ;
  tmsize_t tmp___11 ;
  tmsize_t tmp___12 ;
  tmsize_t tmp___13 ;
  tmsize_t tmp___14 ;
  tmsize_t tmp___15 ;
  tmsize_t tmp___16 ;
  tmsize_t tmp___17 ;
  tmsize_t tmp___18 ;

  {
  written = (tsize_t )0;
  buflen = 0;
  X_W = (float )1.0;
  Y_W = (float )1.0;
  Z_W = (float )1.0;
  if (((unsigned int )t2p->pdf_colorspace & 128U) != 0U) {
    tmp = t2p_write_pdf_xobject_icccs(t2p, output);
    written += tmp;
    return (written);
  } else {

  }
  if (((unsigned int )t2p->pdf_colorspace & 4096U) != 0U) {
    tmp___0 = t2pWriteFile(output, (tdata_t )"[ /Indexed ", (tmsize_t )11);
    written += tmp___0;
    t2p->pdf_colorspace = (t2p_cs_t )((unsigned int )t2p->pdf_colorspace ^ 4096U);
    tmp___1 = t2p_write_pdf_xobject_cs(t2p, output);
    written += tmp___1;
    t2p->pdf_colorspace = (t2p_cs_t )((unsigned int )t2p->pdf_colorspace | 4096U);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%u",
                     (1 << (int )t2p->tiff_bitspersample) - 1);
    tmp___2 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
    written += tmp___2;
    tmp___3 = t2pWriteFile(output, (tdata_t )" ", (tmsize_t )1);
    written += tmp___3;
    _TIFFmemset((void *)(buffer), 0, (tmsize_t )16);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )t2p->pdf_palettecs);
    tmp___4 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
    written += tmp___4;
    tmp___5 = t2pWriteFile(output, (tdata_t )" 0 R ]\n", (tmsize_t )7);
    written += tmp___5;
    return (written);
  } else {

  }
  if ((unsigned int )t2p->pdf_colorspace & 1U) {
    tmp___6 = t2pWriteFile(output, (tdata_t )"/DeviceGray \n", (tmsize_t )13);
    written += tmp___6;
  } else {

  }
  if ((unsigned int )t2p->pdf_colorspace & 2U) {
    if ((unsigned int )t2p->pdf_colorspace & 32U) {
      tmp___7 = t2p_write_pdf_xobject_calcs(t2p, output);
      written += tmp___7;
    } else {
      tmp___8 = t2pWriteFile(output, (tdata_t )"/DeviceGray \n", (tmsize_t )13);
      written += tmp___8;
    }
  } else {

  }
  if ((unsigned int )t2p->pdf_colorspace & 4U) {
    if ((unsigned int )t2p->pdf_colorspace & 64U) {
      tmp___9 = t2p_write_pdf_xobject_calcs(t2p, output);
      written += tmp___9;
    } else {
      tmp___10 = t2pWriteFile(output, (tdata_t )"/DeviceRGB \n", (tmsize_t )12);
      written += tmp___10;
    }
  } else {

  }
  if ((unsigned int )t2p->pdf_colorspace & 8U) {
    tmp___11 = t2pWriteFile(output, (tdata_t )"/DeviceCMYK \n", (tmsize_t )13);
    written += tmp___11;
  } else {

  }
  if ((unsigned int )t2p->pdf_colorspace & 16U) {
    tmp___12 = t2pWriteFile(output, (tdata_t )"[/Lab << \n", (tmsize_t )10);
    written += tmp___12;
    tmp___13 = t2pWriteFile(output, (tdata_t )"/WhitePoint ", (tmsize_t )12);
    written += tmp___13;
    X_W = t2p->tiff_whitechromaticities[0];
    Y_W = t2p->tiff_whitechromaticities[1];
    Z_W = 1.0F - (X_W + Y_W);
    X_W /= Y_W;
    Z_W /= Y_W;
    Y_W = 1.0F;
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"[%.4f %.4f %.4f] \n",
                     (double )X_W, (double )Y_W, (double )Z_W);
    tmp___14 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
    written += tmp___14;
    X_W = 0.3457F;
    Y_W = 0.3585F;
    Z_W = 1.0F - (X_W + Y_W);
    X_W /= Y_W;
    Z_W /= Y_W;
    Y_W = 1.0F;
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"[%.4f %.4f %.4f] \n",
                     (double )X_W, (double )Y_W, (double )Z_W);
    tmp___15 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
    written += tmp___15;
    tmp___16 = t2pWriteFile(output, (tdata_t )"/Range ", (tmsize_t )7);
    written += tmp___16;
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"[%d %d %d %d] \n",
                     t2p->pdf_labrange[0], t2p->pdf_labrange[1],
                     t2p->pdf_labrange[2], t2p->pdf_labrange[3]);
    tmp___17 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
    written += tmp___17;
    tmp___18 = t2pWriteFile(output, (tdata_t )">>] \n", (tmsize_t )5);
    written += tmp___18;
  } else {

  }
  return (written);
}
}
tsize_t t2p_write_pdf_transfer(T2P *t2p , TIFF *output ) 
{ 
  tsize_t written ;
  char buffer[16] ;
  int buflen ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  tmsize_t tmp___4 ;
  tmsize_t tmp___5 ;
  tmsize_t tmp___6 ;
  tmsize_t tmp___7 ;
  tmsize_t tmp___8 ;
  tmsize_t tmp___9 ;
  tmsize_t tmp___10 ;

  {
  written = (tsize_t )0;
  buflen = 0;
  tmp = t2pWriteFile(output, (tdata_t )"<< /Type /ExtGState \n/TR ",
                     (tmsize_t )25);
  written += tmp;
  if ((int )t2p->tiff_transferfunctioncount == 1) {
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )(t2p->pdf_xrefcount + 1U));
    tmp___0 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
    written += tmp___0;
    tmp___1 = t2pWriteFile(output, (tdata_t )" 0 R ", (tmsize_t )5);
    written += tmp___1;
  } else {
    tmp___2 = t2pWriteFile(output, (tdata_t )"[ ", (tmsize_t )2);
    written += tmp___2;
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )(t2p->pdf_xrefcount + 1U));
    tmp___3 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
    written += tmp___3;
    tmp___4 = t2pWriteFile(output, (tdata_t )" 0 R ", (tmsize_t )5);
    written += tmp___4;
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )(t2p->pdf_xrefcount + 2U));
    tmp___5 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
    written += tmp___5;
    tmp___6 = t2pWriteFile(output, (tdata_t )" 0 R ", (tmsize_t )5);
    written += tmp___6;
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )(t2p->pdf_xrefcount + 3U));
    tmp___7 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
    written += tmp___7;
    tmp___8 = t2pWriteFile(output, (tdata_t )" 0 R ", (tmsize_t )5);
    written += tmp___8;
    tmp___9 = t2pWriteFile(output, (tdata_t )"/Identity ] ", (tmsize_t )12);
    written += tmp___9;
  }
  tmp___10 = t2pWriteFile(output, (tdata_t )" >> \n", (tmsize_t )5);
  written += tmp___10;
  return (written);
}
}
tsize_t t2p_write_pdf_transfer_dict(T2P *t2p , TIFF *output , uint16 i ) 
{ 
  tsize_t written ;
  char buffer[32] ;
  int buflen ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  tsize_t tmp___4 ;

  {
  written = (tsize_t )0;
  buflen = 0;
  tmp = t2pWriteFile(output, (tdata_t )"/FunctionType 0 \n", (tmsize_t )17);
  written += tmp;
  tmp___0 = t2pWriteFile(output, (tdata_t )"/Domain [0.0 1.0] \n", (tmsize_t )19);
  written += tmp___0;
  tmp___1 = t2pWriteFile(output, (tdata_t )"/Range [0.0 1.0] \n", (tmsize_t )18);
  written += tmp___1;
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"/Size [%u] \n",
                   1 << (int )t2p->tiff_bitspersample);
  tmp___2 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
  written += tmp___2;
  tmp___3 = t2pWriteFile(output, (tdata_t )"/BitsPerSample 16 \n", (tmsize_t )19);
  written += tmp___3;
  tmp___4 = t2p_write_pdf_stream_dict(1L << ((int )t2p->tiff_bitspersample + 1),
                                      (uint32 )0, output);
  written += tmp___4;
  return (written);
}
}
tsize_t t2p_write_pdf_transfer_stream(T2P *t2p , TIFF *output , uint16 i ) 
{ 
  tsize_t written ;
  tsize_t tmp ;

  {
  written = (tsize_t )0;
  tmp = t2p_write_pdf_stream((tdata_t )t2p->tiff_transferfunction[i],
                             1L << ((int )t2p->tiff_bitspersample + 1), output);
  written += tmp;
  return (written);
}
}
tsize_t t2p_write_pdf_xobject_calcs(T2P *t2p , TIFF *output ) 
{ 
  tsize_t written ;
  char buffer[128] ;
  int buflen ;
  float X_W ;
  float Y_W ;
  float Z_W ;
  float X_R ;
  float Y_R ;
  float Z_R ;
  float X_G ;
  float Y_G ;
  float Z_G ;
  float X_B ;
  float Y_B ;
  float Z_B ;
  float x_w ;
  float y_w ;
  float z_w ;
  float x_r ;
  float y_r ;
  float x_g ;
  float y_g ;
  float x_b ;
  float y_b ;
  float R ;
  float G ;
  float B ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  tmsize_t tmp___4 ;
  tmsize_t tmp___5 ;
  tmsize_t tmp___6 ;
  tmsize_t tmp___7 ;
  tmsize_t tmp___8 ;
  tmsize_t tmp___9 ;
  tmsize_t tmp___10 ;
  tmsize_t tmp___11 ;

  {
  written = (tsize_t )0;
  buflen = 0;
  X_W = (float )0.0;
  Y_W = (float )0.0;
  Z_W = (float )0.0;
  X_R = (float )0.0;
  Y_R = (float )0.0;
  Z_R = (float )0.0;
  X_G = (float )0.0;
  Y_G = (float )0.0;
  Z_G = (float )0.0;
  X_B = (float )0.0;
  Y_B = (float )0.0;
  Z_B = (float )0.0;
  x_w = (float )0.0;
  y_w = (float )0.0;
  z_w = (float )0.0;
  x_r = (float )0.0;
  y_r = (float )0.0;
  x_g = (float )0.0;
  y_g = (float )0.0;
  x_b = (float )0.0;
  y_b = (float )0.0;
  R = (float )1.0;
  G = (float )1.0;
  B = (float )1.0;
  tmp = t2pWriteFile(output, (tdata_t )"[", (tmsize_t )1);
  written += tmp;
  if ((unsigned int )t2p->pdf_colorspace & 32U) {
    tmp___0 = t2pWriteFile(output, (tdata_t )"/CalGray ", (tmsize_t )9);
    written += tmp___0;
    X_W = t2p->tiff_whitechromaticities[0];
    Y_W = t2p->tiff_whitechromaticities[1];
    Z_W = 1.0F - (X_W + Y_W);
    X_W /= Y_W;
    Z_W /= Y_W;
    Y_W = 1.0F;
  } else {

  }
  if ((unsigned int )t2p->pdf_colorspace & 64U) {
    tmp___1 = t2pWriteFile(output, (tdata_t )"/CalRGB ", (tmsize_t )8);
    written += tmp___1;
    x_w = t2p->tiff_whitechromaticities[0];
    y_w = t2p->tiff_whitechromaticities[1];
    x_r = t2p->tiff_primarychromaticities[0];
    y_r = t2p->tiff_primarychromaticities[1];
    x_g = t2p->tiff_primarychromaticities[2];
    y_g = t2p->tiff_primarychromaticities[3];
    x_b = t2p->tiff_primarychromaticities[4];
    y_b = t2p->tiff_primarychromaticities[5];
    z_w = y_w * (((x_g - x_b) * y_r - (x_r - x_b) * y_g) + (x_r - x_g) * y_b);
    Y_R = ((y_r / R) * (((x_g - x_b) * y_w - (x_w - x_b) * y_g) + (x_w - x_g) * y_b)) / z_w;
    X_R = (Y_R * x_r) / y_r;
    Z_R = Y_R * (((float )1 - x_r) / y_r - (float )1);
    Y_G = (((0.0F - y_g) / G) * (((x_r - x_b) * y_w - (x_w - x_b) * y_r) + (x_w - x_r) * y_b)) / z_w;
    X_G = (Y_G * x_g) / y_g;
    Z_G = Y_G * (((float )1 - x_g) / y_g - (float )1);
    Y_B = ((y_b / B) * (((x_r - x_g) * y_w - (x_w - x_g) * y_r) + (x_w - x_r) * y_g)) / z_w;
    X_B = (Y_B * x_b) / y_b;
    Z_B = Y_B * (((float )1 - x_b) / y_b - (float )1);
    X_W = (X_R * R + X_G * G) + X_B * B;
    Y_W = (Y_R * R + Y_G * G) + Y_B * B;
    Z_W = (Z_R * R + Z_G * G) + Z_B * B;
    X_W /= Y_W;
    Z_W /= Y_W;
    Y_W = (float )1.0;
  } else {

  }
  tmp___2 = t2pWriteFile(output, (tdata_t )"<< \n", (tmsize_t )4);
  written += tmp___2;
  if ((unsigned int )t2p->pdf_colorspace & 32U) {
    tmp___3 = t2pWriteFile(output, (tdata_t )"/WhitePoint ", (tmsize_t )12);
    written += tmp___3;
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"[%.4f %.4f %.4f] \n",
                     (double )X_W, (double )Y_W, (double )Z_W);
    tmp___4 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
    written += tmp___4;
    tmp___5 = t2pWriteFile(output, (tdata_t )"/Gamma 2.2 \n", (tmsize_t )12);
    written += tmp___5;
  } else {

  }
  if ((unsigned int )t2p->pdf_colorspace & 64U) {
    tmp___6 = t2pWriteFile(output, (tdata_t )"/WhitePoint ", (tmsize_t )12);
    written += tmp___6;
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"[%.4f %.4f %.4f] \n",
                     (double )X_W, (double )Y_W, (double )Z_W);
    tmp___7 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
    written += tmp___7;
    tmp___8 = t2pWriteFile(output, (tdata_t )"/Matrix ", (tmsize_t )8);
    written += tmp___8;
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"[%.4f %.4f %.4f %.4f %.4f %.4f %.4f %.4f %.4f] \n",
                     (double )X_R, (double )Y_R, (double )Z_R, (double )X_G,
                     (double )Y_G, (double )Z_G, (double )X_B, (double )Y_B,
                     (double )Z_B);
    tmp___9 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
    written += tmp___9;
    tmp___10 = t2pWriteFile(output, (tdata_t )"/Gamma [2.2 2.2 2.2] \n",
                            (tmsize_t )22);
    written += tmp___10;
  } else {

  }
  tmp___11 = t2pWriteFile(output, (tdata_t )">>] \n", (tmsize_t )5);
  written += tmp___11;
  return (written);
}
}
tsize_t t2p_write_pdf_xobject_icccs(T2P *t2p , TIFF *output ) 
{ 
  tsize_t written ;
  char buffer[16] ;
  int buflen ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;

  {
  written = (tsize_t )0;
  buflen = 0;
  tmp = t2pWriteFile(output, (tdata_t )"[/ICCBased ", (tmsize_t )11);
  written += tmp;
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%lu",
                   (unsigned long )t2p->pdf_icccs);
  tmp___0 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
  written += tmp___0;
  tmp___1 = t2pWriteFile(output, (tdata_t )" 0 R] \n", (tmsize_t )7);
  written += tmp___1;
  return (written);
}
}
tsize_t t2p_write_pdf_xobject_icccs_dict(T2P *t2p , TIFF *output ) 
{ 
  tsize_t written ;
  char buffer[16] ;
  int buflen ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tsize_t tmp___2 ;
  tsize_t tmp___3 ;

  {
  written = (tsize_t )0;
  buflen = 0;
  tmp = t2pWriteFile(output, (tdata_t )"/N ", (tmsize_t )3);
  written += tmp;
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%u \n",
                   (int )t2p->tiff_samplesperpixel);
  tmp___0 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
  written += tmp___0;
  tmp___1 = t2pWriteFile(output, (tdata_t )"/Alternate ", (tmsize_t )11);
  written += tmp___1;
  t2p->pdf_colorspace = (t2p_cs_t )((unsigned int )t2p->pdf_colorspace ^ 128U);
  tmp___2 = t2p_write_pdf_xobject_cs(t2p, output);
  written += tmp___2;
  t2p->pdf_colorspace = (t2p_cs_t )((unsigned int )t2p->pdf_colorspace | 128U);
  tmp___3 = t2p_write_pdf_stream_dict((tsize_t )t2p->tiff_iccprofilelength,
                                      (uint32 )0, output);
  written += tmp___3;
  return (written);
}
}
tsize_t t2p_write_pdf_xobject_icccs_stream(T2P *t2p , TIFF *output ) 
{ 
  tsize_t written ;
  tsize_t tmp ;

  {
  written = (tsize_t )0;
  tmp = t2p_write_pdf_stream(t2p->tiff_iccprofile,
                             (tsize_t )t2p->tiff_iccprofilelength, output);
  written += tmp;
  return (written);
}
}
tsize_t t2p_write_pdf_xobject_palettecs_stream(T2P *t2p , TIFF *output ) 
{ 
  tsize_t written ;
  tsize_t tmp ;

  {
  written = (tsize_t )0;
  tmp = t2p_write_pdf_stream((tdata_t )t2p->pdf_palette,
                             (tsize_t )t2p->pdf_palettesize, output);
  written += tmp;
  return (written);
}
}
tsize_t t2p_write_pdf_xobject_decode(T2P *t2p , TIFF *output ) 
{ 
  tsize_t written ;
  int i ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;

  {
  written = (tsize_t )0;
  i = 0;
  tmp = t2pWriteFile(output, (tdata_t )"/Decode [ ", (tmsize_t )10);
  written += tmp;
  i = 0;
  while (i < (int )t2p->tiff_samplesperpixel) {
    tmp___0 = t2pWriteFile(output, (tdata_t )"1 0 ", (tmsize_t )4);
    written += tmp___0;
    i ++;
  }
  tmp___1 = t2pWriteFile(output, (tdata_t )"]\n", (tmsize_t )2);
  written += tmp___1;
  return (written);
}
}
tsize_t t2p_write_pdf_xobject_stream_filter(ttile_t tile , T2P *t2p ,
                                            TIFF *output ) 
{ 
  tsize_t written ;
  char buffer[16] ;
  int buflen ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  tmsize_t tmp___4 ;
  tmsize_t tmp___5 ;
  tmsize_t tmp___6 ;
  tmsize_t tmp___7 ;
  tmsize_t tmp___8 ;
  tmsize_t tmp___9 ;
  tmsize_t tmp___10 ;
  int tmp___11 ;
  tmsize_t tmp___12 ;
  tmsize_t tmp___13 ;
  tmsize_t tmp___14 ;
  tmsize_t tmp___15 ;
  int tmp___16 ;
  tmsize_t tmp___17 ;
  tmsize_t tmp___18 ;

  {
  written = (tsize_t )0;
  buflen = 0;
  if ((unsigned int )t2p->pdf_compression == 0U) {
    return (written);
  } else {

  }
  tmp = t2pWriteFile(output, (tdata_t )"/Filter ", (tmsize_t )8);
  written += tmp;
  switch ((unsigned int )t2p->pdf_compression) {
  case 1U: 
  tmp___0 = t2pWriteFile(output, (tdata_t )"/CCITTFaxDecode ", (tmsize_t )16);
  written += tmp___0;
  tmp___1 = t2pWriteFile(output, (tdata_t )"/DecodeParms ", (tmsize_t )13);
  written += tmp___1;
  tmp___2 = t2pWriteFile(output, (tdata_t )"<< /K -1 ", (tmsize_t )9);
  written += tmp___2;
  if (tile == 0U) {
    tmp___3 = t2pWriteFile(output, (tdata_t )"/Columns ", (tmsize_t )9);
    written += tmp___3;
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )t2p->tiff_width);
    tmp___4 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
    written += tmp___4;
    tmp___5 = t2pWriteFile(output, (tdata_t )" /Rows ", (tmsize_t )7);
    written += tmp___5;
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )t2p->tiff_length);
    tmp___6 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
    written += tmp___6;
  } else {
    tmp___11 = t2p_tile_is_right_edge(*(t2p->tiff_tiles + (int )t2p->pdf_page),
                                      tile - 1U);
    if (tmp___11 == 0) {
      tmp___7 = t2pWriteFile(output, (tdata_t )"/Columns ", (tmsize_t )9);
      written += tmp___7;
      buflen = sprintf((char */* __restrict  */)(buffer),
                       (char const   */* __restrict  */)"%lu",
                       (unsigned long )(t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilewidth);
      tmp___8 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
      written += tmp___8;
    } else {
      tmp___9 = t2pWriteFile(output, (tdata_t )"/Columns ", (tmsize_t )9);
      written += tmp___9;
      buflen = sprintf((char */* __restrict  */)(buffer),
                       (char const   */* __restrict  */)"%lu",
                       (unsigned long )(t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_edgetilewidth);
      tmp___10 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
      written += tmp___10;
    }
    tmp___16 = t2p_tile_is_bottom_edge(*(t2p->tiff_tiles + (int )t2p->pdf_page),
                                       tile - 1U);
    if (tmp___16 == 0) {
      tmp___12 = t2pWriteFile(output, (tdata_t )" /Rows ", (tmsize_t )7);
      written += tmp___12;
      buflen = sprintf((char */* __restrict  */)(buffer),
                       (char const   */* __restrict  */)"%lu",
                       (unsigned long )(t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilelength);
      tmp___13 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
      written += tmp___13;
    } else {
      tmp___14 = t2pWriteFile(output, (tdata_t )" /Rows ", (tmsize_t )7);
      written += tmp___14;
      buflen = sprintf((char */* __restrict  */)(buffer),
                       (char const   */* __restrict  */)"%lu",
                       (unsigned long )(t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_edgetilelength);
      tmp___15 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
      written += tmp___15;
    }
  }
  if ((int )t2p->pdf_switchdecode == 0) {
    tmp___17 = t2pWriteFile(output, (tdata_t )" /BlackIs1 true ", (tmsize_t )16);
    written += tmp___17;
  } else {

  }
  tmp___18 = t2pWriteFile(output, (tdata_t )">>\n", (tmsize_t )3);
  written += tmp___18;
  break;
  default: 
  break;
  }
  return (written);
}
}
tsize_t t2p_write_pdf_xreftable(T2P *t2p , TIFF *output ) 
{ 
  tsize_t written ;
  char buffer[21] ;
  int buflen ;
  uint32 i ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;

  {
  written = (tsize_t )0;
  buflen = 0;
  i = (uint32 )0;
  tmp = t2pWriteFile(output, (tdata_t )"xref\n0 ", (tmsize_t )7);
  written += tmp;
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%lu",
                   (unsigned long )(t2p->pdf_xrefcount + 1U));
  tmp___0 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
  written += tmp___0;
  tmp___1 = t2pWriteFile(output, (tdata_t )" \n0000000000 65535 f \n",
                         (tmsize_t )22);
  written += tmp___1;
  i = (uint32 )0;
  while (i < t2p->pdf_xrefcount) {
    sprintf((char */* __restrict  */)(buffer),
            (char const   */* __restrict  */)"%.10lu 00000 n \n",
            (unsigned long )*(t2p->pdf_xrefoffsets + i));
    tmp___2 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )20);
    written += tmp___2;
    i ++;
  }
  return (written);
}
}
tsize_t t2p_write_pdf_trailer(T2P *t2p , TIFF *output ) 
{ 
  tsize_t written ;
  char buffer[32] ;
  int buflen ;
  size_t i ;
  int tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  tmsize_t tmp___4 ;
  tmsize_t tmp___5 ;
  tmsize_t tmp___6 ;
  tmsize_t tmp___7 ;
  tmsize_t tmp___8 ;
  tmsize_t tmp___9 ;
  tmsize_t tmp___10 ;
  tmsize_t tmp___11 ;
  tmsize_t tmp___12 ;

  {
  written = (tsize_t )0;
  buflen = 0;
  i = (size_t )0;
  i = (size_t )0;
  while (i < sizeof(t2p->pdf_fileid) - 8UL) {
    tmp = rand();
    snprintf((char */* __restrict  */)(t2p->pdf_fileid + i), (size_t )9,
             (char const   */* __restrict  */)"%.8X", tmp);
    i += 8UL;
  }
  tmp___0 = t2pWriteFile(output, (tdata_t )"trailer\n<<\n/Size ", (tmsize_t )17);
  written += tmp___0;
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%lu",
                   (unsigned long )(t2p->pdf_xrefcount + 1U));
  tmp___1 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
  written += tmp___1;
  _TIFFmemset((void *)(buffer), 0, (tmsize_t )32);
  tmp___2 = t2pWriteFile(output, (tdata_t )"\n/Root ", (tmsize_t )7);
  written += tmp___2;
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%lu",
                   (unsigned long )t2p->pdf_catalog);
  tmp___3 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
  written += tmp___3;
  _TIFFmemset((void *)(buffer), 0, (tmsize_t )32);
  tmp___4 = t2pWriteFile(output, (tdata_t )" 0 R \n/Info ", (tmsize_t )12);
  written += tmp___4;
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%lu",
                   (unsigned long )t2p->pdf_info);
  tmp___5 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
  written += tmp___5;
  _TIFFmemset((void *)(buffer), 0, (tmsize_t )32);
  tmp___6 = t2pWriteFile(output, (tdata_t )" 0 R \n/ID[<", (tmsize_t )11);
  written += tmp___6;
  tmp___7 = t2pWriteFile(output, (tdata_t )(t2p->pdf_fileid),
                         (tmsize_t )(sizeof(t2p->pdf_fileid) - 1UL));
  written += tmp___7;
  tmp___8 = t2pWriteFile(output, (tdata_t )"><", (tmsize_t )2);
  written += tmp___8;
  tmp___9 = t2pWriteFile(output, (tdata_t )(t2p->pdf_fileid),
                         (tmsize_t )(sizeof(t2p->pdf_fileid) - 1UL));
  written += tmp___9;
  tmp___10 = t2pWriteFile(output, (tdata_t )">]\n>>\nstartxref\n", (tmsize_t )16);
  written += tmp___10;
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%lu",
                   (unsigned long )t2p->pdf_startxref);
  tmp___11 = t2pWriteFile(output, (tdata_t )(buffer), (tmsize_t )buflen);
  written += tmp___11;
  _TIFFmemset((void *)(buffer), 0, (tmsize_t )32);
  tmp___12 = t2pWriteFile(output, (tdata_t )"\n%%EOF\n", (tmsize_t )7);
  written += tmp___12;
  return (written);
}
}
tsize_t t2p_write_pdf(T2P *t2p , TIFF *input , TIFF *output ) 
{ 
  tsize_t written ;
  ttile_t i2 ;
  tsize_t streamlen ;
  uint16 i ;
  void *tmp ;
  tsize_t tmp___0 ;
  uint32 tmp___1 ;
  tsize_t tmp___2 ;
  tsize_t tmp___3 ;
  tsize_t tmp___4 ;
  uint32 tmp___5 ;
  tsize_t tmp___6 ;
  tsize_t tmp___7 ;
  tsize_t tmp___8 ;
  uint32 tmp___9 ;
  tsize_t tmp___10 ;
  tsize_t tmp___11 ;
  tsize_t tmp___12 ;
  uint32 tmp___13 ;
  tsize_t tmp___14 ;
  tsize_t tmp___15 ;
  tsize_t tmp___16 ;
  uint32 tmp___17 ;
  tsize_t tmp___18 ;
  tsize_t tmp___19 ;
  tsize_t tmp___20 ;
  tsize_t tmp___21 ;
  tsize_t tmp___22 ;
  tsize_t tmp___23 ;
  tsize_t tmp___24 ;
  tsize_t tmp___25 ;
  uint32 tmp___26 ;
  tsize_t tmp___27 ;
  tsize_t tmp___28 ;
  tsize_t tmp___29 ;
  uint32 tmp___30 ;
  tsize_t tmp___31 ;
  tsize_t tmp___32 ;
  tsize_t tmp___33 ;
  uint32 tmp___34 ;
  tsize_t tmp___35 ;
  tsize_t tmp___36 ;
  tsize_t tmp___37 ;
  tsize_t tmp___38 ;
  tsize_t tmp___39 ;
  tsize_t tmp___40 ;
  tsize_t tmp___41 ;
  tsize_t tmp___42 ;
  uint32 tmp___43 ;
  tsize_t tmp___44 ;
  tsize_t tmp___45 ;
  tsize_t tmp___46 ;
  tsize_t tmp___47 ;
  tsize_t tmp___48 ;
  tsize_t tmp___49 ;
  tsize_t tmp___50 ;
  tsize_t tmp___51 ;
  uint32 tmp___52 ;
  tsize_t tmp___53 ;
  tsize_t tmp___54 ;
  tsize_t tmp___55 ;
  tsize_t tmp___56 ;
  tsize_t tmp___57 ;
  tsize_t tmp___58 ;
  tsize_t tmp___59 ;
  tsize_t tmp___60 ;
  uint32 tmp___61 ;
  tsize_t tmp___62 ;
  tsize_t tmp___63 ;
  tsize_t tmp___64 ;
  tsize_t tmp___65 ;
  tsize_t tmp___66 ;
  tsize_t tmp___67 ;
  tsize_t tmp___68 ;
  tsize_t tmp___69 ;
  uint32 tmp___70 ;
  tsize_t tmp___71 ;
  tsize_t tmp___72 ;
  tsize_t tmp___73 ;
  uint32 tmp___74 ;
  tsize_t tmp___75 ;
  tsize_t tmp___76 ;
  tsize_t tmp___77 ;
  tsize_t tmp___78 ;
  tsize_t tmp___79 ;
  tsize_t tmp___80 ;
  tsize_t tmp___81 ;
  tsize_t tmp___82 ;
  uint32 tmp___83 ;
  tsize_t tmp___84 ;
  tsize_t tmp___85 ;
  tsize_t tmp___86 ;
  tsize_t tmp___87 ;
  tsize_t tmp___88 ;

  {
  written = (tsize_t )0;
  i2 = (ttile_t )0;
  streamlen = (tsize_t )0;
  i = (uint16 )0;
  t2p_read_tiff_init(t2p, input);
  if ((unsigned int )t2p->t2p_error != 0U) {
    return ((tsize_t )0);
  } else {

  }
  tmp = _TIFFmalloc((tmsize_t )((unsigned long )t2p->pdf_xrefcount * sizeof(uint32 )));
  t2p->pdf_xrefoffsets = (uint32 *)tmp;
  if ((unsigned long )t2p->pdf_xrefoffsets == (unsigned long )((void *)0)) {
    TIFFError("tiff2pdf",
              "Can\'t allocate %u bytes of memory for t2p_write_pdf",
              (unsigned int )((unsigned long )t2p->pdf_xrefcount * sizeof(uint32 )));
    return (written);
  } else {

  }
  t2p->pdf_xrefcount = (uint32 )0;
  t2p->pdf_catalog = (uint32 )1;
  t2p->pdf_info = (uint32 )2;
  t2p->pdf_pages = (uint32 )3;
  tmp___0 = t2p_write_pdf_header(t2p, output);
  written += tmp___0;
  tmp___1 = t2p->pdf_xrefcount;
  (t2p->pdf_xrefcount) ++;
  *(t2p->pdf_xrefoffsets + tmp___1) = (uint32 )written;
  t2p->pdf_catalog = t2p->pdf_xrefcount;
  tmp___2 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
  written += tmp___2;
  tmp___3 = t2p_write_pdf_catalog(t2p, output);
  written += tmp___3;
  tmp___4 = t2p_write_pdf_obj_end(output);
  written += tmp___4;
  tmp___5 = t2p->pdf_xrefcount;
  (t2p->pdf_xrefcount) ++;
  *(t2p->pdf_xrefoffsets + tmp___5) = (uint32 )written;
  t2p->pdf_info = t2p->pdf_xrefcount;
  tmp___6 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
  written += tmp___6;
  tmp___7 = t2p_write_pdf_info(t2p, input, output);
  written += tmp___7;
  tmp___8 = t2p_write_pdf_obj_end(output);
  written += tmp___8;
  tmp___9 = t2p->pdf_xrefcount;
  (t2p->pdf_xrefcount) ++;
  *(t2p->pdf_xrefoffsets + tmp___9) = (uint32 )written;
  t2p->pdf_pages = t2p->pdf_xrefcount;
  tmp___10 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
  written += tmp___10;
  tmp___11 = t2p_write_pdf_pages(t2p, output);
  written += tmp___11;
  tmp___12 = t2p_write_pdf_obj_end(output);
  written += tmp___12;
  t2p->pdf_page = (tdir_t )0;
  while ((int )t2p->pdf_page < (int )t2p->tiff_pagecount) {
    t2p_read_tiff_data(t2p, input);
    if ((unsigned int )t2p->t2p_error != 0U) {
      return ((tsize_t )0);
    } else {

    }
    tmp___13 = t2p->pdf_xrefcount;
    (t2p->pdf_xrefcount) ++;
    *(t2p->pdf_xrefoffsets + tmp___13) = (uint32 )written;
    tmp___14 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
    written += tmp___14;
    tmp___15 = t2p_write_pdf_page(t2p->pdf_xrefcount, t2p, output);
    written += tmp___15;
    tmp___16 = t2p_write_pdf_obj_end(output);
    written += tmp___16;
    tmp___17 = t2p->pdf_xrefcount;
    (t2p->pdf_xrefcount) ++;
    *(t2p->pdf_xrefoffsets + tmp___17) = (uint32 )written;
    tmp___18 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
    written += tmp___18;
    tmp___19 = t2p_write_pdf_stream_dict_start(output);
    written += tmp___19;
    tmp___20 = t2p_write_pdf_stream_dict((tsize_t )0, t2p->pdf_xrefcount + 1U,
                                         output);
    written += tmp___20;
    tmp___21 = t2p_write_pdf_stream_dict_end(output);
    written += tmp___21;
    tmp___22 = t2p_write_pdf_stream_start(output);
    written += tmp___22;
    streamlen = written;
    tmp___23 = t2p_write_pdf_page_content_stream(t2p, output);
    written += tmp___23;
    streamlen = written - streamlen;
    tmp___24 = t2p_write_pdf_stream_end(output);
    written += tmp___24;
    tmp___25 = t2p_write_pdf_obj_end(output);
    written += tmp___25;
    tmp___26 = t2p->pdf_xrefcount;
    (t2p->pdf_xrefcount) ++;
    *(t2p->pdf_xrefoffsets + tmp___26) = (uint32 )written;
    tmp___27 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
    written += tmp___27;
    tmp___28 = t2p_write_pdf_stream_length(streamlen, output);
    written += tmp___28;
    tmp___29 = t2p_write_pdf_obj_end(output);
    written += tmp___29;
    if ((int )t2p->tiff_transferfunctioncount != 0) {
      tmp___30 = t2p->pdf_xrefcount;
      (t2p->pdf_xrefcount) ++;
      *(t2p->pdf_xrefoffsets + tmp___30) = (uint32 )written;
      tmp___31 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
      written += tmp___31;
      tmp___32 = t2p_write_pdf_transfer(t2p, output);
      written += tmp___32;
      tmp___33 = t2p_write_pdf_obj_end(output);
      written += tmp___33;
      i = (uint16 )0;
      while ((int )i < (int )t2p->tiff_transferfunctioncount) {
        tmp___34 = t2p->pdf_xrefcount;
        (t2p->pdf_xrefcount) ++;
        *(t2p->pdf_xrefoffsets + tmp___34) = (uint32 )written;
        tmp___35 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
        written += tmp___35;
        tmp___36 = t2p_write_pdf_stream_dict_start(output);
        written += tmp___36;
        tmp___37 = t2p_write_pdf_transfer_dict(t2p, output, i);
        written += tmp___37;
        tmp___38 = t2p_write_pdf_stream_dict_end(output);
        written += tmp___38;
        tmp___39 = t2p_write_pdf_stream_start(output);
        written += tmp___39;
        streamlen = written;
        tmp___40 = t2p_write_pdf_transfer_stream(t2p, output, i);
        written += tmp___40;
        streamlen = written - streamlen;
        tmp___41 = t2p_write_pdf_stream_end(output);
        written += tmp___41;
        tmp___42 = t2p_write_pdf_obj_end(output);
        written += tmp___42;
        i = (uint16 )((int )i + 1);
      }
    } else {

    }
    if (((unsigned int )t2p->pdf_colorspace & 4096U) != 0U) {
      tmp___43 = t2p->pdf_xrefcount;
      (t2p->pdf_xrefcount) ++;
      *(t2p->pdf_xrefoffsets + tmp___43) = (uint32 )written;
      t2p->pdf_palettecs = t2p->pdf_xrefcount;
      tmp___44 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
      written += tmp___44;
      tmp___45 = t2p_write_pdf_stream_dict_start(output);
      written += tmp___45;
      tmp___46 = t2p_write_pdf_stream_dict((tsize_t )t2p->pdf_palettesize,
                                           (uint32 )0, output);
      written += tmp___46;
      tmp___47 = t2p_write_pdf_stream_dict_end(output);
      written += tmp___47;
      tmp___48 = t2p_write_pdf_stream_start(output);
      written += tmp___48;
      streamlen = written;
      tmp___49 = t2p_write_pdf_xobject_palettecs_stream(t2p, output);
      written += tmp___49;
      streamlen = written - streamlen;
      tmp___50 = t2p_write_pdf_stream_end(output);
      written += tmp___50;
      tmp___51 = t2p_write_pdf_obj_end(output);
      written += tmp___51;
    } else {

    }
    if (((unsigned int )t2p->pdf_colorspace & 128U) != 0U) {
      tmp___52 = t2p->pdf_xrefcount;
      (t2p->pdf_xrefcount) ++;
      *(t2p->pdf_xrefoffsets + tmp___52) = (uint32 )written;
      t2p->pdf_icccs = t2p->pdf_xrefcount;
      tmp___53 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
      written += tmp___53;
      tmp___54 = t2p_write_pdf_stream_dict_start(output);
      written += tmp___54;
      tmp___55 = t2p_write_pdf_xobject_icccs_dict(t2p, output);
      written += tmp___55;
      tmp___56 = t2p_write_pdf_stream_dict_end(output);
      written += tmp___56;
      tmp___57 = t2p_write_pdf_stream_start(output);
      written += tmp___57;
      streamlen = written;
      tmp___58 = t2p_write_pdf_xobject_icccs_stream(t2p, output);
      written += tmp___58;
      streamlen = written - streamlen;
      tmp___59 = t2p_write_pdf_stream_end(output);
      written += tmp___59;
      tmp___60 = t2p_write_pdf_obj_end(output);
      written += tmp___60;
    } else {

    }
    if ((t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilecount != 0U) {
      i2 = (ttile_t )0;
      while (i2 < (t2p->tiff_tiles + (int )t2p->pdf_page)->tiles_tilecount) {
        tmp___61 = t2p->pdf_xrefcount;
        (t2p->pdf_xrefcount) ++;
        *(t2p->pdf_xrefoffsets + tmp___61) = (uint32 )written;
        tmp___62 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
        written += tmp___62;
        tmp___63 = t2p_write_pdf_stream_dict_start(output);
        written += tmp___63;
        tmp___64 = t2p_write_pdf_xobject_stream_dict(i2 + 1U, t2p, output);
        written += tmp___64;
        tmp___65 = t2p_write_pdf_stream_dict_end(output);
        written += tmp___65;
        tmp___66 = t2p_write_pdf_stream_start(output);
        written += tmp___66;
        streamlen = written;
        t2p_read_tiff_size_tile(t2p, input, i2);
        tmp___67 = t2p_readwrite_pdf_image_tile(t2p, input, output, i2);
        written += tmp___67;
        t2p_write_advance_directory(t2p, output);
        if ((unsigned int )t2p->t2p_error != 0U) {
          return ((tsize_t )0);
        } else {

        }
        streamlen = written - streamlen;
        tmp___68 = t2p_write_pdf_stream_end(output);
        written += tmp___68;
        tmp___69 = t2p_write_pdf_obj_end(output);
        written += tmp___69;
        tmp___70 = t2p->pdf_xrefcount;
        (t2p->pdf_xrefcount) ++;
        *(t2p->pdf_xrefoffsets + tmp___70) = (uint32 )written;
        tmp___71 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
        written += tmp___71;
        tmp___72 = t2p_write_pdf_stream_length(streamlen, output);
        written += tmp___72;
        tmp___73 = t2p_write_pdf_obj_end(output);
        written += tmp___73;
        i2 ++;
      }
    } else {
      tmp___74 = t2p->pdf_xrefcount;
      (t2p->pdf_xrefcount) ++;
      *(t2p->pdf_xrefoffsets + tmp___74) = (uint32 )written;
      tmp___75 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
      written += tmp___75;
      tmp___76 = t2p_write_pdf_stream_dict_start(output);
      written += tmp___76;
      tmp___77 = t2p_write_pdf_xobject_stream_dict((ttile_t )0, t2p, output);
      written += tmp___77;
      tmp___78 = t2p_write_pdf_stream_dict_end(output);
      written += tmp___78;
      tmp___79 = t2p_write_pdf_stream_start(output);
      written += tmp___79;
      streamlen = written;
      t2p_read_tiff_size(t2p, input);
      tmp___80 = t2p_readwrite_pdf_image(t2p, input, output);
      written += tmp___80;
      t2p_write_advance_directory(t2p, output);
      if ((unsigned int )t2p->t2p_error != 0U) {
        return ((tsize_t )0);
      } else {

      }
      streamlen = written - streamlen;
      tmp___81 = t2p_write_pdf_stream_end(output);
      written += tmp___81;
      tmp___82 = t2p_write_pdf_obj_end(output);
      written += tmp___82;
      tmp___83 = t2p->pdf_xrefcount;
      (t2p->pdf_xrefcount) ++;
      *(t2p->pdf_xrefoffsets + tmp___83) = (uint32 )written;
      tmp___84 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
      written += tmp___84;
      tmp___85 = t2p_write_pdf_stream_length(streamlen, output);
      written += tmp___85;
      tmp___86 = t2p_write_pdf_obj_end(output);
      written += tmp___86;
    }
    t2p->pdf_page = (tdir_t )((int )t2p->pdf_page + 1);
  }
  t2p->pdf_startxref = (uint32 )written;
  tmp___87 = t2p_write_pdf_xreftable(t2p, output);
  written += tmp___87;
  tmp___88 = t2p_write_pdf_trailer(t2p, output);
  written += tmp___88;
  t2p_disable(output);
  return (written);
}
}
